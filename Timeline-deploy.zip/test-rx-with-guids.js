#!/usr/bin/env node

/**
 * Test the 400-returning RX endpoints with GUIDs instead of legacy IDs
 * These endpoints exist but expect UUID format!
 */

console.log('🎯 TESTING RX ENDPOINTS WITH GUIDS (Not Legacy IDs)');
console.log('════════════════════════════════════════════════════════════════════════');

const testPatientGuids = [
  'ecab1a6c-5aba-457a-870a-2743822de084',
  '34f9334e-2dcd-4190-9190-e87709fad676',
];

const formatValue = (value) => {
  if (value === null || value === undefined) return '⚪ null';
  if (value === '') return '⚪ empty';
  return value;
};

const displayRxData = (rxItems, guid) => {
  console.log(`\n💊 RX DATA FOR GUID ${guid} (${rxItems.length} items):`);
  console.log('═'.repeat(80));
  
  if (rxItems.length > 0) {
    rxItems.forEach((rx, i) => {
      console.log(`\n📋 Prescription ${i + 1}:`);
      console.log('─'.repeat(60));
      console.log(`   RX Number................: ${formatValue(rx.RxNumber)}`);
      console.log(`   Date Prescribed..........: ${formatValue(rx.DatePrescribed)}`);
      console.log(`   Product Type.............: ${formatValue(rx.Product)}`);
      console.log(`   Status...................: ${formatValue(rx.Status)}`);
      console.log(`   Provider.................: ${formatValue(rx.ProviderName)}`);
      console.log(`   OD Sphere................: ${formatValue(rx.OdSphere)}`);
      console.log(`   OD Cylinder..............: ${formatValue(rx.OdCylinder)}`);
      console.log(`   OD Axis..................: ${formatValue(rx.OdAxis)}`);
      console.log(`   OS Sphere................: ${formatValue(rx.OsSphere)}`);
      console.log(`   OS Cylinder..............: ${formatValue(rx.OsCylinder)}`);
      console.log(`   OS Axis..................: ${formatValue(rx.OsAxis)}`);
      console.log(`   Add Power................: ${formatValue(rx.AddPower)}`);
      console.log(`   PD.......................: ${formatValue(rx.PupillaryDistance || rx.PD)}`);
      console.log(`   Expiration Date..........: ${formatValue(rx.ExpirationDate)}`);
    });
    
    return true;
  } else {
    console.log('   📭 No prescriptions found for this patient');
    return false;
  }
};

const testRxEndpointWithGuid = async (endpoint, guid) => {
  try {
    console.log(`\n🧪 Testing: ${endpoint}`);
    console.log(`   GUID: ${guid}`);
    
    let url;
    if (endpoint.includes('?id=')) {
      url = endpoint.replace('?id=GUID', `?id=${guid}`);
    } else if (endpoint.includes('?patientId=')) {
      url = endpoint.replace('?patientId=GUID', `?patientId=${guid}`);
    } else {
      url = endpoint.replace('GUID', guid);
    }
    
    const fullUrl = `https://patientcare-teal.vercel.app${url}&page=1&pageSize=500`;
    console.log(`   URL: ${fullUrl}`);
    
    const response = await fetch(fullUrl);
    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    if (response.ok) {
      const data = await response.json();
      const rxItems = data.items || data || [];
      
      console.log(`   🎉 SUCCESS! RX endpoint works with GUID!`);
      const hasData = displayRxData(rxItems, guid);
      
      return { 
        success: true, 
        endpoint: url, 
        guid, 
        rxCount: rxItems.length, 
        hasData,
        data 
      };
    } else if (response.status === 400) {
      const text = await response.text();
      console.log(`   ⚠️  Bad Request: ${text.substring(0, 200)}`);
      return { success: false, endpoint: url, guid, status: 400, error: text };
    } else {
      console.log(`   ❌ Failed: ${response.status}`);
      return { success: false, endpoint: url, guid, status: response.status };
    }
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
    return { success: false, endpoint: url, guid, error: error.message };
  }
};

const runGuidRxTests = async () => {
  console.log('\n🚀 Testing RX endpoints that returned 400 - now with GUIDs');
  console.log('═'.repeat(80));
  
  // These are the endpoints that returned 400 (exist but wrong parameters)
  const workingEndpoints = [
    '/api/eyefinity/v2patients/rx?id=GUID',
    '/api/eyefinity/v2patients/rx?patientId=GUID',
  ];
  
  const allResults = [];
  
  for (const guid of testPatientGuids) {
    console.log(`\n👤 Testing Patient GUID: ${guid}`);
    console.log('─'.repeat(80));
    
    for (const endpoint of workingEndpoints) {
      const result = await testRxEndpointWithGuid(endpoint, guid);
      allResults.push(result);
      console.log('─'.repeat(60));
    }
  }
  
  console.log('\n\n🎯 GUID RX TEST RESULTS:');
  console.log('═'.repeat(80));
  
  const successful = allResults.filter(r => r.success);
  const withData = allResults.filter(r => r.success && r.hasData);
  
  console.log(`\n📊 RESULTS SUMMARY:`);
  console.log(`   Total Tests: ${allResults.length}`);
  console.log(`   ✅ Successful (200): ${successful.length}`);
  console.log(`   📦 With RX Data: ${withData.length}`);
  
  if (withData.length > 0) {
    console.log(`\n🎉 FOUND WORKING RX ENDPOINTS WITH DATA!`);
    withData.forEach(r => {
      console.log(`   🏆 ${r.endpoint} - ${r.rxCount} prescriptions`);
    });
    
    console.log(`\n💡 SOLUTION FOUND:`);
    const workingEndpoint = withData[0];
    console.log(`   ✅ RX API Format: ${workingEndpoint.endpoint.replace(workingEndpoint.guid, '{patientGuid}')}`);
    console.log(`   ✅ Use patient GUID, not legacy ID`);
    console.log(`   ✅ Ready to update EyefinityService!`);
    
  } else if (successful.length > 0) {
    console.log(`\n✅ RX ENDPOINTS WORK (but no data for these patients):`);
    successful.forEach(r => {
      console.log(`   ✅ ${r.endpoint} - endpoint works`);
    });
    
    console.log(`\n💡 RX API CONFIRMED WORKING:`);
    const workingEndpoint = successful[0];
    console.log(`   Format: ${workingEndpoint.endpoint.replace(workingEndpoint.guid, '{patientGuid}')}`);
    console.log(`   Need patients with RX data to test further`);
    
  } else {
    console.log(`\n❌ RX endpoints still not working with GUIDs`);
    console.log(`   Need to investigate further or try different approach`);
  }
  
  // Show any 400 errors for debugging
  const badRequests = allResults.filter(r => r.status === 400);
  if (badRequests.length > 0) {
    console.log(`\n⚠️  BAD REQUEST DETAILS:`);
    badRequests.forEach(r => {
      console.log(`   ${r.endpoint}: ${r.error?.substring(0, 150) || 'Bad Request'}`);
    });
  }
};

runGuidRxTests().catch(console.error);
