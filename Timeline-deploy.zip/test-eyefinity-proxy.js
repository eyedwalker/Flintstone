/**
 * Test script for Eyefinity proxy with database credentials
 * 
 * Tests:
 * 1. Database connection and credential fetch
 * 2. OAuth flow with company credentials
 * 3. Token caching
 * 4. API request through proxy
 */

import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_KEY; // Use service role key for backend

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase credentials');
  console.log('Needed: SUPABASE_URL and SUPABASE_SERVICE_KEY');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function testDatabaseCredentials() {
  console.log('\n📊 Test 1: Fetch credentials from database');
  console.log('==========================================');
  
  try {
    // Find a company with Eyefinity credentials
    const { data: companies, error } = await supabase
      .from('companies')
      .select('id, name, eyefinity_api_key, eyefinity_api_secret, tenant_uid, oauth_host, api_base_url')
      .not('eyefinity_api_key', 'is', null)
      .limit(5);
    
    if (error) {
      console.error('❌ Database query failed:', error.message);
      return null;
    }
    
    if (!companies || companies.length === 0) {
      console.log('⚠️  No companies with Eyefinity credentials found');
      console.log('   Please save credentials via the UI first');
      return null;
    }
    
    console.log(`✅ Found ${companies.length} company(s) with credentials:`);
    companies.forEach(c => {
      console.log(`   - ${c.name} (${c.id})`);
      console.log(`     Client ID: ${c.eyefinity_api_key ? '✓' : '✗'}`);
      console.log(`     Client Secret: ${c.eyefinity_api_secret ? '✓' : '✗'}`);
      console.log(`     Tenant UID: ${c.tenant_uid ? '✓' : '✗'}`);
      console.log(`     OAuth Host: ${c.oauth_host || 'not set'}`);
      console.log(`     API Base URL: ${c.api_base_url || 'not set'}`);
    });
    
    return companies[0]; // Return first company for testing
    
  } catch (err) {
    console.error('❌ Test failed:', err.message);
    return null;
  }
}

async function testOAuthFlow(company) {
  console.log('\n🔐 Test 2: OAuth Flow');
  console.log('=====================');
  
  const clientId = company.eyefinity_api_key || process.env.EPM_CLIENT_ID;
  const clientSecret = company.eyefinity_api_secret || process.env.EPM_CLIENT_SECRET;
  const tenantUid = company.tenant_uid || process.env.TENANT_UID;
  const oauthHost = company.oauth_host || process.env.OAUTH_HOST || 'api-sandbox.eyefinity.com';
  
  if (!clientId || !clientSecret || !tenantUid) {
    console.error('❌ Missing OAuth credentials');
    console.log('   Client ID:', clientId ? '✓' : '✗');
    console.log('   Client Secret:', clientSecret ? '✓' : '✗');
    console.log('   Tenant UID:', tenantUid ? '✓' : '✗');
    return null;
  }
  
  try {
    console.log(`📍 OAuth Host: ${oauthHost}`);
    console.log(`📍 Client ID: ${clientId}`);
    console.log(`📍 Tenant UID: ${tenantUid}`);
    
    // Step 1: Client Credentials
    console.log('\n  Step 1: Client Credentials...');
    const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
    const scopes = 'auth_epm ef.pm_pe_patient_rx ef.pm_pe_resource ef.pm_pe_insurance ef.pm_pe_appointment ef.pm_pe_office_recallreport ef.pm_pe_staff ef.pm_pe_office ef.pm_pe_company ef.pm_pe_order ef.pm_pe_provider ef.pm_pe_patient';
    
    const ccResponse = await fetch(`https://${oauthHost}/as/token.oauth2`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: `grant_type=client_credentials&scope=${encodeURIComponent(scopes)}`,
    });
    
    if (!ccResponse.ok) {
      const error = await ccResponse.text();
      console.error(`  ❌ Client credentials failed: ${ccResponse.status}`);
      console.error(`     ${error}`);
      return null;
    }
    
    const ccData = await ccResponse.json();
    const ccToken = ccData.access_token || ccData.accesstoken;
    console.log(`  ✅ Client credentials token obtained (${ccToken.substring(0, 20)}...)`);
    
    // Step 2: Token Exchange
    console.log('\n  Step 2: Token Exchange...');
    const exchangeBody = new URLSearchParams({
      'grant_type': 'urn:ietf:params:oauth:grant-type:token-exchange',
      'subject_token': ccToken,
      'subject_token_type': 'urn:ietf:params:oauth:token-type:access_token',
      'scope': scopes,
      'resource': 'https://VspEpmToken',
    });
    
    const exchangeResponse = await fetch(`https://${oauthHost}/as/token.oauth2`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'tenantuid': tenantUid,
      },
      body: exchangeBody.toString(),
    });
    
    if (!exchangeResponse.ok) {
      const error = await exchangeResponse.text();
      console.error(`  ❌ Token exchange failed: ${exchangeResponse.status}`);
      console.error(`     ${error}`);
      return null;
    }
    
    const exchangeData = await exchangeResponse.json();
    const epmToken = exchangeData.access_token || exchangeData.accesstoken;
    console.log(`  ✅ EPM token obtained (${epmToken.substring(0, 20)}...)`);
    console.log(`     Expires in: ${exchangeData.expires_in || 1799}s`);
    
    return epmToken;
    
  } catch (err) {
    console.error('❌ OAuth test failed:', err.message);
    return null;
  }
}

async function testProxyRequest(company, token) {
  console.log('\n🌐 Test 3: Proxy API Request');
  console.log('============================');
  
  const apiBaseUrl = company.api_base_url || process.env.EYEFINITY_API_URL || 'https://api-sandbox.eyefinity.com';
  
  // We don't have the eyefinity_company_id yet, so just test token validity
  // by trying to fetch companies endpoint
  const testUrl = `${apiBaseUrl}/al-pe/v2/companies`;
  
  console.log(`📍 Testing: ${testUrl}`);
  
  try {
    const response = await fetch(testUrl, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json',
      },
    });
    
    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    if (response.ok) {
      const data = await response.json();
      console.log(`   ✅ API request successful`);
      console.log(`   📦 Response:`, JSON.stringify(data, null, 2).substring(0, 200) + '...');
      return true;
    } else {
      const error = await response.text();
      console.log(`   ❌ API request failed`);
      console.log(`   Error: ${error.substring(0, 200)}`);
      return false;
    }
    
  } catch (err) {
    console.error('❌ Proxy test failed:', err.message);
    return false;
  }
}

async function runAllTests() {
  console.log('\n🧪 Eyefinity Proxy Integration Tests');
  console.log('====================================');
  
  // Test 1: Database credentials
  const company = await testDatabaseCredentials();
  if (!company) {
    console.log('\n❌ Cannot continue - no company credentials found');
    console.log('   Save credentials via Admin Dashboard > Settings first');
    process.exit(1);
  }
  
  // Test 2: OAuth flow
  const token = await testOAuthFlow(company);
  if (!token) {
    console.log('\n❌ OAuth flow failed - check credentials and OAuth host');
    process.exit(1);
  }
  
  // Test 3: API request
  const apiSuccess = await testProxyRequest(company, token);
  
  console.log('\n📊 Test Summary');
  console.log('===============');
  console.log(`Database credentials: ✅`);
  console.log(`OAuth flow: ✅`);
  console.log(`API request: ${apiSuccess ? '✅' : '❌'}`);
  
  if (apiSuccess) {
    console.log('\n✅ All tests passed! Proxy should work in UI.');
    console.log(`   Company ID for testing: ${company.id}`);
  } else {
    console.log('\n⚠️  OAuth works but API request failed');
    console.log('   Check API base URL and company ID');
  }
}

runAllTests().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
