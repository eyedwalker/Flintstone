-- =====================================================
-- Complete Database Migration for Eyefinity PRC
-- Target: PostgreSQL 16 on apps-server
-- Database: eyefinity_prc
-- =====================================================

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
-- gen_random_uuid() is built-in to PG13+, no extension needed

-- =====================================================
-- CORE ORGANIZATIONAL ENTITIES
-- =====================================================

CREATE TABLE IF NOT EXISTS accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'cancelled')),
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  eyefinity_company_id TEXT,
  eyefinity_base_url TEXT,
  eyefinity_api_key TEXT,
  eyefinity_api_secret TEXT,
  eyefinity_tenant_uid TEXT,
  oauth_token TEXT,
  oauth_refresh_token TEXT,
  oauth_token_expires_at TIMESTAMPTZ,
  twilio_account_sid TEXT,
  twilio_auth_token TEXT,
  twilio_phone_number TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS offices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  eyefinity_location_id TEXT,
  phone TEXT,
  email TEXT,
  timezone TEXT DEFAULT 'America/Chicago',
  address JSONB DEFAULT '{}',
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS staff (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  eyefinity_staff_id TEXT,
  eyefinity_provider_id TEXT,
  email TEXT,
  phone TEXT,
  role TEXT NOT NULL CHECK (role IN ('doctor', 'technician', 'optician', 'front_desk', 'manager', 'other')),
  specialty TEXT,
  active BOOLEAN DEFAULT true,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS staff_offices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_id UUID NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  is_primary BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(staff_id, office_id)
);

-- =====================================================
-- PATIENT MANAGEMENT
-- =====================================================

CREATE TABLE IF NOT EXISTS patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  eyefinity_patient_id TEXT,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  date_of_birth DATE,
  gender TEXT CHECK (gender IN ('male', 'female', 'other', 'unknown')),
  email TEXT,
  phone TEXT,
  mobile_phone TEXT,
  address JSONB DEFAULT '{}',
  emergency_contact JSONB DEFAULT '{}',
  preferred_language TEXT DEFAULT 'en',
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'deceased')),
  notes TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS patient_insurance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  eyefinity_insurance_id TEXT,
  carrier_name TEXT NOT NULL,
  policy_number TEXT,
  group_number TEXT,
  subscriber_name TEXT,
  subscriber_dob DATE,
  relationship_to_subscriber TEXT,
  priority TEXT DEFAULT 'primary' CHECK (priority IN ('primary', 'secondary', 'tertiary')),
  effective_date DATE,
  termination_date DATE,
  is_active BOOLEAN DEFAULT true,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- APPOINTMENTS & SCHEDULING
-- =====================================================

CREATE TABLE IF NOT EXISTS appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  provider_id UUID REFERENCES staff(id) ON DELETE SET NULL,
  eyefinity_appointment_id TEXT,
  appointment_date TIMESTAMPTZ NOT NULL,
  duration_minutes INTEGER DEFAULT 30,
  appointment_type TEXT NOT NULL,
  status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'confirmed', 'checked_in', 'in_progress', 'completed', 'cancelled', 'no_show')),
  reason_for_visit TEXT,
  notes TEXT,
  reminder_sent BOOLEAN DEFAULT false,
  reminder_sent_at TIMESTAMPTZ,
  checked_in_at TIMESTAMPTZ,
  checked_out_at TIMESTAMPTZ,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- CLINICAL DATA
-- =====================================================

CREATE TABLE IF NOT EXISTS encounters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  provider_id UUID REFERENCES staff(id) ON DELETE SET NULL,
  encounter_date TIMESTAMPTZ NOT NULL,
  encounter_type TEXT NOT NULL,
  chief_complaint TEXT,
  subjective TEXT,
  objective TEXT,
  assessment TEXT,
  plan TEXT,
  status TEXT DEFAULT 'open' CHECK (status IN ('open', 'signed', 'amended', 'corrected')),
  signed_at TIMESTAMPTZ,
  signed_by UUID REFERENCES staff(id) ON DELETE SET NULL,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS exams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  encounter_id UUID NOT NULL REFERENCES encounters(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  eyefinity_exam_id TEXT,
  exam_date DATE NOT NULL,
  exam_type TEXT NOT NULL,
  visual_acuity JSONB DEFAULT '{}',
  refraction JSONB DEFAULT '{}',
  intraocular_pressure JSONB DEFAULT '{}',
  dilated BOOLEAN DEFAULT false,
  findings TEXT,
  diagnosis_codes TEXT[],
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS prescriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES encounters(id) ON DELETE SET NULL,
  provider_id UUID REFERENCES staff(id) ON DELETE SET NULL,
  eyefinity_rx_id TEXT,
  prescription_date DATE NOT NULL,
  prescription_type TEXT NOT NULL CHECK (prescription_type IN ('eyeglasses', 'contact_lenses', 'medication')),
  od_sphere DECIMAL(5,2),
  od_cylinder DECIMAL(5,2),
  od_axis INTEGER,
  od_add DECIMAL(4,2),
  os_sphere DECIMAL(5,2),
  os_cylinder DECIMAL(5,2),
  os_axis INTEGER,
  os_add DECIMAL(4,2),
  pd DECIMAL(4,1),
  expiration_date DATE,
  medication_name TEXT,
  medication_dosage TEXT,
  medication_instructions TEXT,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'expired', 'replaced', 'cancelled')),
  notes TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- ORDERS & INVENTORY
-- =====================================================

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  prescription_id UUID REFERENCES prescriptions(id) ON DELETE SET NULL,
  eyefinity_order_id TEXT,
  order_date DATE NOT NULL,
  order_type TEXT NOT NULL,
  frame_description TEXT,
  lens_type TEXT,
  lens_material TEXT,
  coatings TEXT[],
  total_price DECIMAL(10,2),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'ordered', 'received', 'ready', 'dispensed', 'cancelled')),
  ordered_date DATE,
  expected_date DATE,
  received_date DATE,
  dispensed_date DATE,
  notes TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- RECALLS & REMINDERS
-- =====================================================

CREATE TABLE IF NOT EXISTS recalls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  recall_type TEXT NOT NULL,
  due_date DATE NOT NULL,
  last_exam_date DATE,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'contacted', 'scheduled', 'completed', 'declined', 'cancelled')),
  contact_method TEXT,
  contacted_at TIMESTAMPTZ,
  notes TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- SYNC & INTEGRATION LOGGING
-- =====================================================

CREATE TABLE IF NOT EXISTS sync_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  sync_type TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  eyefinity_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('success', 'partial', 'failed', 'skipped')),
  records_processed INTEGER DEFAULT 0,
  records_created INTEGER DEFAULT 0,
  records_updated INTEGER DEFAULT 0,
  records_failed INTEGER DEFAULT 0,
  error_message TEXT,
  metadata JSONB DEFAULT '{}',
  started_at TIMESTAMPTZ NOT NULL,
  completed_at TIMESTAMPTZ,
  duration_ms INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- INSURANCE BENEFIT VERIFICATION
-- =====================================================

CREATE TABLE IF NOT EXISTS payer_credentials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  office_id UUID REFERENCES offices(id) ON DELETE CASCADE,
  payer_type TEXT NOT NULL CHECK (payer_type IN ('vsp', 'eyemed', 'davis-vision', 'spectera', 'superior-vision')),
  portal_username TEXT NOT NULL,
  portal_password_encrypted TEXT NOT NULL,
  mfa_method TEXT CHECK (mfa_method IN ('none', 'email', 'sms', 'totp')),
  mfa_secret_encrypted TEXT,
  portal_url TEXT,
  last_login_at TIMESTAMPTZ,
  last_login_status TEXT,
  is_active BOOLEAN DEFAULT true,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(company_id, office_id, payer_type)
);

CREATE TABLE IF NOT EXISTS verification_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  office_id UUID REFERENCES offices(id),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
  payer_type TEXT NOT NULL,
  member_id TEXT NOT NULL,
  subscriber_dob DATE,
  patient_dob DATE,
  relationship TEXT DEFAULT 'self',
  status TEXT NOT NULL DEFAULT 'queued' CHECK (status IN (
    'queued', 'in_progress', 'mfa_waiting', 'completed', 'failed', 'expired'
  )),
  priority INTEGER DEFAULT 5,
  attempts INTEGER DEFAULT 0,
  max_attempts INTEGER DEFAULT 3,
  last_error TEXT,
  worker_id TEXT,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  mfa_requested_at TIMESTAMPTZ,
  mfa_code TEXT,
  triggered_by TEXT DEFAULT 'manual',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS verification_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES verification_jobs(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  payer_type TEXT NOT NULL,
  is_eligible BOOLEAN NOT NULL,
  eligibility_status TEXT,
  plan_name TEXT,
  plan_type TEXT,
  effective_date DATE,
  termination_date DATE,
  exam_copay DECIMAL(8,2),
  frames_allowance DECIMAL(8,2),
  frames_copay DECIMAL(8,2),
  lenses_copay DECIMAL(8,2),
  contacts_allowance DECIMAL(8,2),
  contacts_copay DECIMAL(8,2),
  exam_eligible_date DATE,
  frames_eligible_date DATE,
  lenses_eligible_date DATE,
  contacts_eligible_date DATE,
  raw_benefits JSONB DEFAULT '{}',
  raw_html TEXT,
  parsed_by TEXT DEFAULT 'claude',
  confidence_score DECIMAL(3,2),
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- TASKS TABLE
-- =====================================================

CREATE TABLE IF NOT EXISTS tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID,
  office_id UUID,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL,
  priority TEXT NOT NULL DEFAULT 'medium',
  status TEXT NOT NULL DEFAULT 'pending',
  patient_id UUID,
  journey_id UUID,
  assigned_to UUID,
  due_date DATE,
  due_time TIME,
  completed_at TIMESTAMPTZ,
  notes TEXT,
  tags TEXT[],
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- FORM SUBMISSIONS CACHE
-- =====================================================

CREATE TABLE IF NOT EXISTS form_submissions_cache (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  submission_id TEXT NOT NULL,
  access_token TEXT UNIQUE NOT NULL,
  submission_data JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- CALL ENRICHMENTS (AI VOICE)
-- =====================================================

CREATE TABLE IF NOT EXISTS call_enrichments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  office_id UUID REFERENCES offices(id) ON DELETE SET NULL,
  call_sid TEXT NOT NULL UNIQUE,
  from_phone TEXT,
  to_phone TEXT,
  direction TEXT,
  duration_seconds INTEGER,
  sentiment_score NUMERIC(3,1),
  emotion TEXT,
  emotion_confidence NUMERIC(3,2),
  escalation_needed BOOLEAN DEFAULT FALSE,
  escalation_reason TEXT,
  ai_performance_score NUMERIC(3,1),
  staff_rating TEXT CHECK (staff_rating IN ('thumbs_up', 'thumbs_down')),
  staff_notes TEXT,
  reviewed_by TEXT,
  reviewed_at TIMESTAMPTZ,
  transcript TEXT,
  recording_url TEXT,
  call_started_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- VOICE SETTINGS
-- =====================================================

CREATE TABLE IF NOT EXISTS voice_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  office_id UUID REFERENCES offices(id) ON DELETE SET NULL,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- AUDIT LOGS (ANALYTICS)
-- =====================================================

CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  journey_id TEXT NOT NULL,
  step_id TEXT NOT NULL,
  step_title TEXT,
  patient_id TEXT NOT NULL,
  patient_name TEXT,
  event_type TEXT NOT NULL,
  event_timestamp TIMESTAMPTZ NOT NULL,
  performed_by TEXT,
  performed_by_name TEXT,
  location TEXT,
  step_start_time TIMESTAMPTZ,
  step_end_time TIMESTAMPTZ,
  step_duration NUMERIC,
  wait_time NUMERIC,
  room_id TEXT,
  room_name TEXT,
  room_type TEXT,
  external_system_action TEXT,
  external_system_url TEXT,
  external_patient_id TEXT,
  external_appointment_id TEXT,
  journey_phase TEXT CHECK (journey_phase IN ('pre-visit', 'in-office', 'post-visit')),
  metadata JSONB DEFAULT '{}'::jsonb,
  provider_id TEXT,
  provider_name TEXT,
  office_id TEXT,
  office_name TEXT,
  company_id TEXT,
  outcome TEXT CHECK (outcome IN ('success', 'failed', 'skipped', 'cancelled')),
  error_message TEXT,
  is_overtime BOOLEAN DEFAULT false,
  expected_duration NUMERIC,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- FRAME SCANNER TABLES
-- =====================================================

CREATE TABLE IF NOT EXISTS frame_catalog (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  upc_code VARCHAR(13) UNIQUE NOT NULL,
  manufacturer VARCHAR(255),
  brand VARCHAR(255),
  model_name VARCHAR(255),
  model_number VARCHAR(100),
  color_name VARCHAR(100),
  color_code VARCHAR(50),
  lens_width INTEGER,
  bridge_width INTEGER,
  temple_length INTEGER,
  frame_width INTEGER,
  material VARCHAR(100),
  frame_type VARCHAR(50),
  shape VARCHAR(50),
  wholesale_price DECIMAL(10,2),
  retail_price DECIMAL(10,2),
  image_url TEXT,
  additional_images JSONB DEFAULT '[]',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS patient_favorite_frames (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  upc_code VARCHAR(13) NOT NULL,
  frame_name VARCHAR(255),
  frame_manufacturer VARCHAR(255),
  frame_model VARCHAR(255),
  frame_color VARCHAR(100),
  frame_size VARCHAR(50),
  scanned_at TIMESTAMP DEFAULT NOW(),
  image_url TEXT,
  notes TEXT,
  is_purchased BOOLEAN DEFAULT FALSE,
  purchased_at TIMESTAMP,
  UNIQUE(patient_id, upc_code)
);

CREATE TABLE IF NOT EXISTS patient_measurements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  measured_at TIMESTAMP DEFAULT NOW(),
  pd_right DECIMAL(4,1),
  pd_left DECIMAL(4,1),
  pd_total DECIMAL(4,1),
  seg_height_right DECIMAL(4,1),
  seg_height_left DECIMAL(4,1),
  oc_height_right DECIMAL(4,1),
  oc_height_left DECIMAL(4,1),
  frame_id UUID REFERENCES patient_favorite_frames(id) ON DELETE SET NULL,
  measurement_method VARCHAR(50),
  calibration_factor DECIMAL(8,4),
  confidence_score DECIMAL(3,2),
  device_type VARCHAR(100),
  device_model VARCHAR(100),
  has_lidar BOOLEAN DEFAULT FALSE,
  browser_info TEXT,
  face_landmarks JSONB,
  frame_markers JSONB,
  calibration_data JSONB,
  image_url TEXT,
  verified_by_staff UUID REFERENCES staff(id) ON DELETE SET NULL,
  verified_at TIMESTAMP,
  is_approved BOOLEAN DEFAULT FALSE,
  staff_notes TEXT,
  notes TEXT,
  movement_sequence JSONB,
  depth_map JSONB,
  has_3d_data BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS patient_scanner_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  token VARCHAR(255) UNIQUE NOT NULL,
  token_type VARCHAR(50) DEFAULT 'frame-scanner',
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  last_used_at TIMESTAMP,
  uses_count INTEGER DEFAULT 0,
  max_uses INTEGER,
  is_revoked BOOLEAN DEFAULT FALSE,
  revoked_at TIMESTAMP,
  revoked_by UUID REFERENCES staff(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS patient_face_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  face_width DECIMAL(5,1),
  face_height DECIMAL(5,1),
  jaw_width DECIMAL(5,1),
  cheekbone_width DECIMAL(5,1),
  forehead_width DECIMAL(5,1),
  face_shape VARCHAR(20),
  face_shape_confidence DECIMAL(3,2),
  pd_total DECIMAL(4,1),
  pd_right DECIMAL(4,1),
  pd_left DECIMAL(4,1),
  outline_points JSONB,
  face_svg TEXT,
  measurement_id UUID REFERENCES patient_measurements(id) ON DELETE SET NULL,
  recommended_frame_widths JSONB,
  recommended_bridge_widths JSONB,
  recommended_temple_lengths JSONB,
  is_active BOOLEAN DEFAULT TRUE,
  source VARCHAR(50),
  notes TEXT,
  depth_enhanced_geometry JSONB,
  movement_quality_score FLOAT,
  reference_frame_id VARCHAR,
  UNIQUE(patient_id, company_id)
);

CREATE TABLE IF NOT EXISTS patient_movement_frames (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id VARCHAR NOT NULL,
  company_id VARCHAR NOT NULL,
  measurement_id UUID REFERENCES patient_measurements(id),
  frame_index INTEGER NOT NULL,
  timestamp BIGINT NOT NULL,
  movement_type VARCHAR NOT NULL,
  landmarks JSONB NOT NULL,
  head_pose JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT unique_movement_frame UNIQUE(measurement_id, frame_index)
);

-- =====================================================
-- ALL INDEXES
-- =====================================================

-- Core organizational
CREATE INDEX IF NOT EXISTS idx_accounts_status ON accounts(status);
CREATE INDEX IF NOT EXISTS idx_companies_account_id ON companies(account_id);
CREATE INDEX IF NOT EXISTS idx_offices_company_id ON offices(company_id);
CREATE INDEX IF NOT EXISTS idx_staff_offices_staff_id ON staff_offices(staff_id);
CREATE INDEX IF NOT EXISTS idx_staff_offices_office_id ON staff_offices(office_id);

-- Eyefinity integration
CREATE INDEX IF NOT EXISTS idx_staff_eyefinity_staff_id ON staff(eyefinity_staff_id);
CREATE INDEX IF NOT EXISTS idx_staff_eyefinity_provider_id ON staff(eyefinity_provider_id);
CREATE INDEX IF NOT EXISTS idx_offices_eyefinity_location_id ON offices(eyefinity_location_id);
CREATE INDEX IF NOT EXISTS idx_patients_eyefinity_patient_id ON patients(eyefinity_patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_eyefinity_id ON appointments(eyefinity_appointment_id);
CREATE INDEX IF NOT EXISTS idx_exams_eyefinity_exam_id ON exams(eyefinity_exam_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_eyefinity_rx_id ON prescriptions(eyefinity_rx_id);
CREATE INDEX IF NOT EXISTS idx_orders_eyefinity_order_id ON orders(eyefinity_order_id);

-- Patient management
CREATE INDEX IF NOT EXISTS idx_patients_company_id ON patients(company_id);
CREATE INDEX IF NOT EXISTS idx_patients_last_name ON patients(last_name);
CREATE INDEX IF NOT EXISTS idx_patients_status ON patients(status);
CREATE INDEX IF NOT EXISTS idx_patient_insurance_patient_id ON patient_insurance(patient_id);
CREATE INDEX IF NOT EXISTS idx_patient_insurance_active ON patient_insurance(is_active);

-- Appointments
CREATE INDEX IF NOT EXISTS idx_appointments_company_id ON appointments(company_id);
CREATE INDEX IF NOT EXISTS idx_appointments_office_id ON appointments(office_id);
CREATE INDEX IF NOT EXISTS idx_appointments_patient_id ON appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_provider_id ON appointments(provider_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON appointments(status);

-- Clinical
CREATE INDEX IF NOT EXISTS idx_encounters_patient_id ON encounters(patient_id);
CREATE INDEX IF NOT EXISTS idx_encounters_appointment_id ON encounters(appointment_id);
CREATE INDEX IF NOT EXISTS idx_encounters_date ON encounters(encounter_date);
CREATE INDEX IF NOT EXISTS idx_exams_patient_id ON exams(patient_id);
CREATE INDEX IF NOT EXISTS idx_exams_encounter_id ON exams(encounter_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_patient_id ON prescriptions(patient_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_status ON prescriptions(status);

-- Orders
CREATE INDEX IF NOT EXISTS idx_orders_patient_id ON orders(patient_id);
CREATE INDEX IF NOT EXISTS idx_orders_office_id ON orders(office_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_order_date ON orders(order_date);

-- Recalls
CREATE INDEX IF NOT EXISTS idx_recalls_patient_id ON recalls(patient_id);
CREATE INDEX IF NOT EXISTS idx_recalls_office_id ON recalls(office_id);
CREATE INDEX IF NOT EXISTS idx_recalls_due_date ON recalls(due_date);
CREATE INDEX IF NOT EXISTS idx_recalls_status ON recalls(status);

-- Sync logs
CREATE INDEX IF NOT EXISTS idx_sync_logs_company_id ON sync_logs(company_id);
CREATE INDEX IF NOT EXISTS idx_sync_logs_entity_type ON sync_logs(entity_type);
CREATE INDEX IF NOT EXISTS idx_sync_logs_started_at ON sync_logs(started_at DESC);
CREATE INDEX IF NOT EXISTS idx_sync_logs_status ON sync_logs(status);

-- Insurance verification
CREATE INDEX IF NOT EXISTS idx_payer_credentials_company ON payer_credentials(company_id);
CREATE INDEX IF NOT EXISTS idx_payer_credentials_active ON payer_credentials(is_active);
CREATE INDEX IF NOT EXISTS idx_verification_jobs_status ON verification_jobs(status);
CREATE INDEX IF NOT EXISTS idx_verification_jobs_patient ON verification_jobs(patient_id);
CREATE INDEX IF NOT EXISTS idx_verification_jobs_priority ON verification_jobs(priority, created_at);
CREATE INDEX IF NOT EXISTS idx_verification_jobs_appointment ON verification_jobs(appointment_id);
CREATE INDEX IF NOT EXISTS idx_verification_results_patient ON verification_results(patient_id);
CREATE INDEX IF NOT EXISTS idx_verification_results_job ON verification_results(job_id);
CREATE INDEX IF NOT EXISTS idx_verification_results_expires ON verification_results(expires_at);

-- Tasks
CREATE INDEX IF NOT EXISTS idx_tasks_company ON tasks(company_id);
CREATE INDEX IF NOT EXISTS idx_tasks_office ON tasks(office_id);
CREATE INDEX IF NOT EXISTS idx_tasks_patient ON tasks(patient_id);
CREATE INDEX IF NOT EXISTS idx_tasks_journey ON tasks(journey_id);
CREATE INDEX IF NOT EXISTS idx_tasks_assigned ON tasks(assigned_to);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_due_date ON tasks(due_date);
CREATE INDEX IF NOT EXISTS idx_tasks_category ON tasks(category);

-- Form submissions
CREATE INDEX IF NOT EXISTS idx_form_submissions_token ON form_submissions_cache(access_token);

-- Call enrichments
CREATE INDEX IF NOT EXISTS idx_call_enrichments_call_sid ON call_enrichments(call_sid);
CREATE INDEX IF NOT EXISTS idx_call_enrichments_company_id ON call_enrichments(company_id);
CREATE INDEX IF NOT EXISTS idx_call_enrichments_created_at ON call_enrichments(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_call_enrichments_escalation ON call_enrichments(escalation_needed) WHERE escalation_needed = TRUE;

-- Audit logs
CREATE INDEX IF NOT EXISTS idx_audit_logs_office_id ON audit_logs(office_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_event_timestamp ON audit_logs(event_timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_logs_journey_id ON audit_logs(journey_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_patient_id ON audit_logs(patient_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_event_type ON audit_logs(event_type);
CREATE INDEX IF NOT EXISTS idx_audit_logs_company_id ON audit_logs(company_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_provider_id ON audit_logs(provider_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_office_timestamp ON audit_logs(office_id, event_timestamp DESC);

-- Frame scanner
CREATE INDEX IF NOT EXISTS idx_frame_catalog_upc ON frame_catalog(upc_code);
CREATE INDEX IF NOT EXISTS idx_frame_catalog_brand ON frame_catalog(brand);
CREATE INDEX IF NOT EXISTS idx_frame_catalog_manufacturer ON frame_catalog(manufacturer);
CREATE INDEX IF NOT EXISTS idx_patient_favorites_patient ON patient_favorite_frames(patient_id);
CREATE INDEX IF NOT EXISTS idx_patient_favorites_company ON patient_favorite_frames(company_id);
CREATE INDEX IF NOT EXISTS idx_patient_favorites_upc ON patient_favorite_frames(upc_code);
CREATE INDEX IF NOT EXISTS idx_patient_measurements_patient ON patient_measurements(patient_id);
CREATE INDEX IF NOT EXISTS idx_patient_measurements_company ON patient_measurements(company_id);
CREATE INDEX IF NOT EXISTS idx_patient_measurements_date ON patient_measurements(measured_at);
CREATE INDEX IF NOT EXISTS idx_patient_measurements_has_3d_data ON patient_measurements(has_3d_data);
CREATE INDEX IF NOT EXISTS idx_scanner_tokens_token ON patient_scanner_tokens(token);
CREATE INDEX IF NOT EXISTS idx_scanner_tokens_patient ON patient_scanner_tokens(patient_id);
CREATE INDEX IF NOT EXISTS idx_scanner_tokens_expires ON patient_scanner_tokens(expires_at);
CREATE INDEX IF NOT EXISTS idx_face_profiles_patient ON patient_face_profiles(patient_id);
CREATE INDEX IF NOT EXISTS idx_face_profiles_company ON patient_face_profiles(company_id);
CREATE INDEX IF NOT EXISTS idx_face_profiles_shape ON patient_face_profiles(face_shape);
CREATE INDEX IF NOT EXISTS idx_patient_movement_frames_measurement_id ON patient_movement_frames(measurement_id);

-- =====================================================
-- TRIGGERS
-- =====================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_accounts_updated_at BEFORE UPDATE ON accounts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_companies_updated_at BEFORE UPDATE ON companies FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_offices_updated_at BEFORE UPDATE ON offices FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_staff_updated_at BEFORE UPDATE ON staff FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_patients_updated_at BEFORE UPDATE ON patients FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_patient_insurance_updated_at BEFORE UPDATE ON patient_insurance FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON appointments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_encounters_updated_at BEFORE UPDATE ON encounters FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_exams_updated_at BEFORE UPDATE ON exams FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_prescriptions_updated_at BEFORE UPDATE ON prescriptions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_recalls_updated_at BEFORE UPDATE ON recalls FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_payer_credentials_updated_at BEFORE UPDATE ON payer_credentials FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_verification_jobs_updated_at BEFORE UPDATE ON verification_jobs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON tasks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_call_enrichments_updated_at BEFORE UPDATE ON call_enrichments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- TENANT CONTEXT (for future RLS enforcement)
-- =====================================================

CREATE OR REPLACE FUNCTION set_tenant_context(p_account_id UUID)
RETURNS void AS $$
BEGIN
  PERFORM set_config('app.current_account_id', p_account_id::text, false);
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- SEED DATA
-- =====================================================

INSERT INTO accounts (name, status, settings)
VALUES ('Demo Account', 'active', '{"tier": "trial"}'::jsonb)
ON CONFLICT DO NOTHING;

DO $$
DECLARE
  demo_account_id UUID;
BEGIN
  SELECT id INTO demo_account_id FROM accounts WHERE name = 'Demo Account' LIMIT 1;
  IF demo_account_id IS NOT NULL THEN
    INSERT INTO companies (account_id, name, eyefinity_company_id, eyefinity_base_url, settings)
    VALUES (
      demo_account_id,
      'Demo Eye Care Center',
      '936',
      'https://api-integration.eyefinity.com',
      '{"business_hours": {"monday": "9:00-17:00"}}'::jsonb
    )
    ON CONFLICT DO NOTHING;
  END IF;
END $$;

-- Sample frame catalog
INSERT INTO frame_catalog (upc_code, manufacturer, brand, model_name, color_name, lens_width, bridge_width, temple_length, material, frame_type, shape, retail_price)
VALUES
  ('123456789012', 'Ray-Ban', 'Ray-Ban', 'Wayfarer Classic', 'Black', 50, 22, 150, 'Acetate', 'full-rim', 'wayfarer', 154.00),
  ('123456789013', 'Oakley', 'Oakley', 'Holbrook', 'Matte Black', 55, 18, 137, 'O-Matter', 'full-rim', 'rectangle', 173.00),
  ('123456789014', 'Warby Parker', 'Warby Parker', 'Haskell', 'Crystal', 49, 20, 145, 'Acetate', 'full-rim', 'round', 95.00)
ON CONFLICT (upc_code) DO NOTHING;
