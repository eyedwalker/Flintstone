/**
 * Migrate data from Supabase to local PostgreSQL
 *
 * Uses Supabase REST API (HTTPS) to fetch data and pg to insert into local DB.
 * Handles foreign key ordering automatically.
 */

import { createClient } from '@supabase/supabase-js';
import pg from 'pg';
const { Pool } = pg;

const SUPABASE_URL = process.env.SUPABASE_URL || 'https://sdxinswwxtuuyeurkqec.supabase.co';
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY;
const DATABASE_URL = process.env.DATABASE_URL;

if (!SUPABASE_KEY) {
  console.error('SUPABASE_SERVICE_KEY or SUPABASE_ANON_KEY required');
  process.exit(1);
}
if (!DATABASE_URL) {
  console.error('DATABASE_URL required (target PostgreSQL)');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
});

const pool = new Pool({ connectionString: DATABASE_URL });

// Tables in dependency order (parents first)
const TABLES = [
  'accounts',
  'companies',
  'offices',
  'staff',
  'staff_offices',
  'patients',
  'patient_insurance',
  'appointments',
  'encounters',
  'exams',
  'prescriptions',
  'orders',
  'recalls',
  'sync_logs',
  'payer_credentials',
  'verification_jobs',
  'verification_results',
  'tasks',
  'form_submissions_cache',
  'call_enrichments',
  'voice_settings',
  'audit_logs',
  'frame_catalog',
  'patient_favorite_frames',
  'patient_measurements',
  'patient_scanner_tokens',
  'patient_face_profiles',
  'patient_movement_frames',
];

async function fetchAll(table) {
  // Supabase limits to 1000 rows by default, paginate
  let allRows = [];
  let offset = 0;
  const pageSize = 1000;

  while (true) {
    const { data, error } = await supabase
      .from(table)
      .select('*')
      .range(offset, offset + pageSize - 1)
      .order('created_at', { ascending: true });

    if (error) {
      // Table might not exist in Supabase or has no created_at
      // Try without ordering
      const { data: data2, error: error2 } = await supabase
        .from(table)
        .select('*')
        .range(offset, offset + pageSize - 1);

      if (error2) {
        console.warn(`  [Skip] ${table}: ${error2.message}`);
        return [];
      }
      if (!data2 || data2.length === 0) break;
      allRows.push(...data2);
      if (data2.length < pageSize) break;
      offset += pageSize;
      continue;
    }

    if (!data || data.length === 0) break;
    allRows.push(...data);
    if (data.length < pageSize) break;
    offset += pageSize;
  }

  return allRows;
}

async function insertRows(table, rows) {
  if (rows.length === 0) return 0;

  const client = await pool.connect();
  try {
    let inserted = 0;
    for (const row of rows) {
      const keys = Object.keys(row).filter(k => row[k] !== undefined);
      const values = keys.map(k => row[k]);
      const placeholders = keys.map((_, i) => `$${i + 1}`).join(', ');
      const cols = keys.map(k => `"${k}"`).join(', ');

      try {
        await client.query(
          `INSERT INTO "${table}" (${cols}) VALUES (${placeholders}) ON CONFLICT DO NOTHING`,
          values
        );
        inserted++;
      } catch (err) {
        // Auto-add missing columns
        const colMatch = err.message.match(/column "(.+?)" of relation "(.+?)" does not exist/);
        if (colMatch) {
          const missingCol = colMatch[1];
          const val = row[missingCol];
          const pgType = typeof val === 'number' ? 'NUMERIC' : typeof val === 'boolean' ? 'BOOLEAN' : 'TEXT';
          console.warn(`  [Auto-fix] Adding column "${missingCol}" (${pgType}) to ${table}`);
          await client.query(`ALTER TABLE "${table}" ADD COLUMN IF NOT EXISTS "${missingCol}" ${pgType}`);
          // Retry insert
          try {
            await client.query(
              `INSERT INTO "${table}" (${cols}) VALUES (${placeholders}) ON CONFLICT DO NOTHING`,
              values
            );
            inserted++;
          } catch (retryErr) {
            console.warn(`  [Row Error] ${table}: ${retryErr.message}`);
          }
        } else {
          console.warn(`  [Row Error] ${table}: ${err.message}`);
        }
      }
    }

    return inserted;
  } finally {
    client.release();
  }
}

async function migrate() {
  console.log('=== Supabase → PostgreSQL Data Migration ===');
  console.log(`Source: ${SUPABASE_URL}`);
  console.log(`Target: ${DATABASE_URL.replace(/:[^@]+@/, ':***@')}`);
  console.log('');

  let totalRows = 0;

  for (const table of TABLES) {
    process.stdout.write(`${table}... `);
    const rows = await fetchAll(table);

    if (rows.length === 0) {
      console.log('0 rows (empty or not found)');
      continue;
    }

    const inserted = await insertRows(table, rows);
    console.log(`${inserted}/${rows.length} rows migrated`);
    totalRows += inserted;
  }

  console.log('');
  console.log(`=== Migration complete: ${totalRows} total rows ===`);

  await pool.end();
}

migrate().catch(err => {
  console.error('Migration failed:', err);
  process.exit(1);
});
