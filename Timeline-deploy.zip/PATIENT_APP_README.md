# Patient Mobile App - Quick Start Guide

## 🚀 Overview

The **MyEyeCare Journey** patient app is a complete mobile/web application that allows patients to track their office visit in real-time, view their prescription, manage billing, make payments, and receive personalized product recommendations.

---

## ✨ Features

### 1. **Authentication**
- No account creation needed
- Login with Appointment ID + Date of Birth
- Magic link support (via SMS/email)
- Session-based authentication (24-hour validity)

### 2. **Dashboard**
- Real-time journey tracking
- Visual progress bar showing visit completion
- Current step and status
- Quick action buttons to all features

### 3. **Wait Time Tracker**
- Live queue position
- Estimated wait time in minutes
- Auto-refreshes every 30 seconds
- Suggested activities while waiting

### 4. **My Prescription (Rx)**
- Current prescription display (OD/OS, SPH, CYL, AXIS, ADD, PD)
- Educational tooltips explaining each value
- Prescription history (last 5 years)
- Expiry date tracking with warnings
- Download PDF
- Share prescription

### 5. **Billing & Payments** 💳
- View all invoices and outstanding balances
- Invoice details with line items
- **Payment Methods:**
  - Apple Pay
  - Google Pay
  - Credit/Debit Cards (Stripe)
- Receipt generation and download
- Payment history

### 6. **Personalized Recommendations**
- Reuses existing recommendation engine
- Display location: `patient-app-feed`
- Save favorites
- Share recommendations
- Track impressions and clicks

---

## 📱 Routes

| Route | Description |
|-------|-------------|
| `/patient/login` | Authentication page |
| `/patient/dashboard` | Main visit tracking view |
| `/patient/wait` | Live wait time & queue position |
| `/patient/rx` | Prescription viewer |
| `/patient/billing` | Invoices & payment processing |
| `/patient/recommendations` | Personalized product feed |

---

## 🧪 Testing the App

### **Option 1: Direct Login**

1. Navigate to `/patient/login`
2. Enter credentials:
   - **Appointment ID**: Any journey ID from PatientJourneyService
   - **Date of Birth**: Format `YYYY-MM-DD` (must match patient DOB in Eyefinity)

**Example Test Credentials:**
```
Appointment ID: [Get from journey board - any patient ID]
Date of Birth: 2001-06-21
```

### **Option 2: Magic Link**

Generate a magic link for a patient:
```javascript
const session = await PatientAppService.authenticatePatient('appointment-id', '2001-06-21');
const magicLink = `/patient/login?token=${session.sessionToken}&appointmentId=${session.appointmentId}`;
```

Send this link via SMS/email - patient clicks and auto-authenticates!

---

## 🔧 Key Services

### **PatientAppService** (`src/lib/services/patient-app-service.ts`)

```typescript
// Authenticate patient
const session = await PatientAppService.authenticatePatient(appointmentId, dob);

// Get current session
const session = PatientAppService.getCurrentSession();

// Get journey status
const status = PatientAppService.getJourneyStatus(session);

// Get wait time info
const waitInfo = PatientAppService.getWaitTimeInfo(session);

// Get invoices
const invoices = await PatientAppService.getInvoices(patientId);

// Create payment intent
const paymentIntent = await PatientAppService.createPaymentIntent(invoiceId, amount, patientId);

// Record payment
const payment = await PatientAppService.recordPayment(invoiceId, patientId, paymentData);
```

---

## 💳 Payment Integration

### **Current State (Demo)**
- Mock payment processing with 2-second delay
- Local storage for demo receipts
- Returns fake Stripe payment intents

### **Production Setup Required:**

1. **Add Stripe SDK:**
```bash
npm install @stripe/stripe-js @stripe/react-stripe-js
```

2. **Backend API Endpoints:**
```
POST /api/payments/create-intent
POST /api/payments/record
GET  /api/payments/receipt/:id
```

3. **Update `PatientAppService.createPaymentIntent()`:**
```typescript
static async createPaymentIntent(invoiceId: string, amount: number, patientId: string) {
  const response = await fetch('/api/payments/create-intent', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ invoiceId, amount, patientId })
  });
  return response.json();
}
```

4. **Implement Stripe Elements in PatientBilling.jsx**

---

## 🎨 Customization

### **Branding**
Update colors in `PatientAppLayout.jsx` and individual pages:
```javascript
// Primary gradient
from-blue-500 via-purple-500 to-pink-500

// Accent color
text-blue-600 bg-blue-100
```

### **Add New Pages**
1. Create page in `src/patient-app/pages/`
2. Add route in `src/main.jsx`
3. Add nav item in `PatientAppLayout.jsx`

### **Customize Recommendations**
Add new recommendation rules in Recommendations Admin panel targeting `patient-app-feed` location.

---

## 📊 Analytics & Tracking

Track patient engagement:
```javascript
// Recommendation impressions
RecommendationService.trackEvent(recId, patientId, 'impression', 'patient-app-feed');

// Recommendation clicks
RecommendationService.trackEvent(recId, patientId, 'click', 'patient-app-feed');

// Payment events
// Add custom tracking in PatientBilling.jsx
```

---

## 🚀 Deployment

### **PWA Setup (Progressive Web App)**

1. **Add manifest.json:**
```json
{
  "name": "MyEyeCare Journey",
  "short_name": "MyEyeCare",
  "description": "Track your eye care visit",
  "start_url": "/patient/dashboard",
  "display": "standalone",
  "background_color": "#ffffff",
  "theme_color": "#3b82f6",
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
```

2. **Add Service Worker** (with Vite PWA plugin)
3. **Enable HTTPS** (required for PWA)
4. **Test on mobile devices**

### **SMS Magic Links**

Integrate with Twilio to send magic links:
```javascript
// When appointment is confirmed
const session = await PatientAppService.authenticatePatient(appointmentId, dob);
const magicLink = `https://yourapp.com/patient/login?token=${session.sessionToken}`;

await TwilioService.sendSMS(patientPhone, 
  `Your appointment is today! Track your visit: ${magicLink}`
);
```

---

## 🎯 Next Steps

### **Phase 2 Features:**
- [ ] Frame gallery and browsing
- [ ] Virtual try-on (AR camera integration)
- [ ] Chat with staff (reuse existing chat service)
- [ ] Appointment scheduling
- [ ] Family account linking

### **Phase 3 Enhancements:**
- [ ] Push notifications for step transitions
- [ ] Geofence alerts ("You're 5 min away")
- [ ] Voice commands ("Show my prescription")
- [ ] Health tracking (screen time, symptoms)
- [ ] Loyalty rewards program

---

## 📞 Support

**Test Access:**
- Login: `/patient/login`
- Use any journey from the patient journey board as appointment ID
- DOB must match patient record in Eyefinity

**Demo Patients:**
- Smith Test: ID from journey board, DOB: `2001-06-21`

**Issues?**
Check browser console for detailed error messages from PatientAppService.

---

## 🎨 Design System

**Mobile-First:** All layouts optimized for phones first, then scale up
**Bottom Navigation:** Fixed bottom nav for easy thumb access
**Gradient Accents:** Blue → Purple → Pink for modern feel
**Card-Based:** White cards on gradient backgrounds
**Clear CTAs:** Large, accessible action buttons

---

**Built with:** React 18, TypeScript, TailwindCSS, Lucide Icons
**Integrates with:** Eyefinity API, Recommendation Engine, Journey Service
**Ready for:** Stripe, Apple Pay, Google Pay
