#!/usr/bin/env node

/**
 * Test working Eyefinity endpoints to understand the correct API structure
 */

const testPatientId = 'ecab1a6c-5aba-457a-870a-2743822de084';

// Test known working endpoints first
const workingEndpoints = [
  {
    name: 'Patient Details (v2)',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testPatientId}`
  },
  {
    name: 'Patient Appointments (v2)', 
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testPatientId}/appointments`
  }
];

// Test potential alternative RX/Orders endpoints
const alternativeEndpoints = [
  {
    name: 'Prescriptions (plural)',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testPatientId}/prescriptions`
  },
  {
    name: 'Patient Prescriptions',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/prescriptions?patientId=${testPatientId}`
  },
  {
    name: 'Patient Orders (alternative)',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/orders?patientId=${testPatientId}`
  },
  {
    name: 'V2 Prescriptions',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2prescriptions?patientId=${testPatientId}`
  },
  {
    name: 'V2 Orders',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2orders?patientId=${testPatientId}`
  }
];

const testEndpoint = async (endpoint) => {
  try {
    console.log(`\n🧪 ${endpoint.name}:`);
    console.log(`   ${endpoint.url}`);
    
    const response = await fetch(endpoint.url);
    console.log(`   Status: ${response.status}`);
    
    if (response.status === 200) {
      try {
        const data = await response.json();
        const itemCount = data.items?.length || (Array.isArray(data) ? data.length : 'N/A');
        console.log(`   ✅ SUCCESS - Items: ${itemCount}`);
        if (data.items && data.items.length > 0) {
          console.log(`   Sample keys: ${Object.keys(data.items[0]).slice(0, 5).join(', ')}`);
        }
      } catch (e) {
        console.log(`   ✅ SUCCESS - Non-JSON response`);
      }
    } else if (response.status === 404) {
      console.log(`   ❌ NOT FOUND`);
    } else {
      console.log(`   ⚠️  Error: ${response.status}`);
    }
    
    return response.status;
  } catch (error) {
    console.log(`   ❌ FETCH ERROR: ${error.message}`);
    return 'ERROR';
  }
};

const runTests = async () => {
  console.log('🔍 TESTING WORKING ENDPOINTS FIRST:');
  console.log('════════════════════════════════════════');
  
  for (const endpoint of workingEndpoints) {
    await testEndpoint(endpoint);
  }
  
  console.log('\n🔍 TESTING ALTERNATIVE RX/ORDERS ENDPOINTS:');
  console.log('══════════════════════════════════════════');
  
  for (const endpoint of alternativeEndpoints) {
    await testEndpoint(endpoint);
  }
  
  console.log('\n💡 RECOMMENDATIONS:');
  console.log('════════════════════');
  console.log('1. Check Eyefinity API documentation for correct RX/Orders endpoints');
  console.log('2. RX data might be included in patient details response');
  console.log('3. Orders might use different endpoint structure');
  console.log('4. Consider using search/query endpoints instead of direct patient endpoints');
};

runTests().catch(console.error);
