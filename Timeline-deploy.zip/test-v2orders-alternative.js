#!/usr/bin/env node

/**
 * Test alternative v2orders endpoint structure based on Swagger docs
 */

const testPatientId = 'ecab1a6c-5aba-457a-870a-2743822de084';
const dateRange = {
  fromStatusChangedDate: '2020-01-01',
  toStatusChangedDate: '2026-01-27'
};

// Test v2orders endpoint with query parameters (from Swagger docs)
const alternativeEndpoints = [
  {
    name: 'V2Orders with patientId query',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2orders?patientId=${testPatientId}&fromStatusChangedDate=${dateRange.fromStatusChangedDate}&toStatusChangedDate=${dateRange.toStatusChangedDate}&page=1&pageSize=100`
  },
  {
    name: 'V2Orders minimal params',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2orders?fromStatusChangedDate=${dateRange.fromStatusChangedDate}&toStatusChangedDate=${dateRange.toStatusChangedDate}&page=1&pageSize=100`
  },
  {
    name: 'V2Prescriptions (if exists)',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2prescriptions?patientId=${testPatientId}&page=1&pageSize=100`
  },
  {
    name: 'RX search endpoint (alternative)',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/rx?patientId=${testPatientId}&page=1&pageSize=100`
  }
];

const testEndpoint = async (endpoint) => {
  try {
    console.log(`\n🧪 ${endpoint.name}:`);
    console.log(`   ${endpoint.url}`);
    
    const response = await fetch(endpoint.url);
    console.log(`   Status: ${response.status}`);
    
    if (response.status === 200) {
      try {
        const data = await response.json();
        const itemCount = data.items?.length || (Array.isArray(data) ? data.length : 'N/A');
        console.log(`   ✅ SUCCESS - Items: ${itemCount}`);
        if (data.items && data.items.length > 0) {
          console.log(`   Sample keys: ${Object.keys(data.items[0]).slice(0, 5).join(', ')}`);
        }
        return { status: 200, data };
      } catch (e) {
        console.log(`   ✅ SUCCESS - Non-JSON response`);
        return { status: 200 };
      }
    } else if (response.status === 400) {
      const text = await response.text();
      console.log(`   ⚠️  Bad Request - might need different parameters`);
      console.log(`   Response: ${text.substring(0, 100)}`);
      return { status: 400, error: text };
    } else if (response.status === 404) {
      console.log(`   ❌ NOT FOUND`);
      return { status: 404 };
    } else {
      console.log(`   ⚠️  Error: ${response.status}`);
      const text = await response.text();
      console.log(`   Response: ${text.substring(0, 100)}`);
      return { status: response.status, error: text };
    }
  } catch (error) {
    console.log(`   ❌ FETCH ERROR: ${error.message}`);
    return { status: 'ERROR', error: error.message };
  }
};

const runTests = async () => {
  console.log('🔍 TESTING ALTERNATIVE ENDPOINT STRUCTURES:');
  console.log('═══════════════════════════════════════════');
  
  const results = {};
  
  for (const endpoint of alternativeEndpoints) {
    results[endpoint.name] = await testEndpoint(endpoint);
  }
  
  console.log('\n📊 RESULTS SUMMARY:');
  console.log('═══════════════════');
  
  const workingEndpoints = [];
  Object.entries(results).forEach(([name, result]) => {
    const statusIcon = result.status === 200 ? '✅' : result.status === 400 ? '⚠️' : result.status === 404 ? '❌' : '🔴';
    console.log(`${statusIcon} ${name}: ${result.status}`);
    if (result.status === 200) {
      workingEndpoints.push(name);
    }
  });
  
  if (workingEndpoints.length > 0) {
    console.log('\n🎉 FOUND WORKING ENDPOINTS:');
    workingEndpoints.forEach(name => console.log(`   ✅ ${name}`));
  }
  
  console.log('\n💡 NEXT STEPS:');
  console.log('═════════════');
  console.log('1. Update EyefinityService to use working endpoint structure');
  console.log('2. Test with the corrected endpoints');
  console.log('3. Handle any parameter requirements properly');
};

runTests().catch(console.error);
