import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const apiProxyTarget = env.VITE_API_PROXY_TARGET || env.VITE_AUTH_PROXY_TARGET || 'https://patientcare-real.vercel.app'
  
  return {
    plugins: [react()],
    optimizeDeps: {
      exclude: ['zxing-wasm'],
    },
    assetsInclude: ['**/*.wasm'],
    define: {
      'import.meta.env.VITE_ANTHROPIC_API_KEY': JSON.stringify(env.ANTHROPIC_API_KEY || env.VITE_ANTHROPIC_API_KEY),
      'import.meta.env.VITE_EYEFINITY_ACCESS_TOKEN': JSON.stringify(env.NEXT_PUBLIC_EYEFINITY_TOKEN || env.VITE_EYEFINITY_ACCESS_TOKEN),
    },
    server: {
      proxy: {
        '/api/auth': {
          target: apiProxyTarget,
          changeOrigin: true,
          secure: false,
        },
        '/api/communications': {
          target: apiProxyTarget,
          changeOrigin: true,
          secure: false,
        },
        '/api/voice': {
          target: apiProxyTarget,
          changeOrigin: true,
          secure: false,
        },
        '/api/eyefinity': {
          target: 'http://localhost:3099',
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace(/^\/api\/eyefinity/, '/al-pe'),
        },
        '/proxy': {
          target: 'http://localhost:3099',
          changeOrigin: true,
        }
      }
    }
  }
})
