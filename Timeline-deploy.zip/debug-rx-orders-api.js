#!/usr/bin/env node

/**
 * Debug RX and Orders API Endpoints
 * Test the actual API paths and responses to identify 404 issues
 */

console.log('🔍 DEBUGGING RX AND ORDERS API ENDPOINTS\n');

const testPatientId = 'ecab1a6c-5aba-457a-870a-2743822de084'; // From the error logs

// Test the proxy path construction
const testEndpoints = [
  {
    name: 'Patient RX (v2patients)',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testPatientId}/rx?page=1&pageSize=100`,
    expectedProxyPath: `v2patients/${testPatientId}/rx`
  },
  {
    name: 'Patient Orders (v2patients)', 
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testPatientId}/orders?fromStatusChangedDate=2020-01-01&toStatusChangedDate=2026-01-27&page=1&pageSize=100`,
    expectedProxyPath: `v2patients/${testPatientId}/orders`
  },
  {
    name: 'Patient RX (v1 patients - alternative)',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/patients/${testPatientId}/rx?page=1&pageSize=100`,
    expectedProxyPath: `patients/${testPatientId}/rx`
  },
  {
    name: 'Patient Orders (v1 patients - alternative)',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/patients/${testPatientId}/orders?fromStatusChangedDate=2020-01-01&toStatusChangedDate=2026-01-27&page=1&pageSize=100`,
    expectedProxyPath: `patients/${testPatientId}/orders`
  }
];

console.log('📋 TESTING API ENDPOINTS:');
console.log('═══════════════════════════════════════════════════════════════════════');

// Test each endpoint
const testEndpoint = async (endpoint) => {
  try {
    console.log(`\n🧪 Testing: ${endpoint.name}`);
    console.log(`   URL: ${endpoint.url}`);
    console.log(`   Expected Proxy Path: ${endpoint.expectedProxyPath}`);
    
    const startTime = Date.now();
    const response = await fetch(endpoint.url);
    const duration = Date.now() - startTime;
    
    console.log(`   Status: ${response.status} ${response.statusText}`);
    console.log(`   Response Time: ${duration}ms`);
    
    if (response.status === 404) {
      console.log(`   ❌ 404 ERROR - Endpoint not found`);
    } else if (response.status === 200) {
      const data = await response.json();
      console.log(`   ✅ SUCCESS - Items: ${data.items?.length || 0}`);
    } else {
      console.log(`   ⚠️  Other Error: ${response.status}`);
      const text = await response.text();
      console.log(`   Response: ${text.substring(0, 200)}`);
    }
    
    return { status: response.status, duration };
    
  } catch (error) {
    console.log(`   ❌ FETCH ERROR: ${error.message}`);
    return { status: 'ERROR', error: error.message };
  }
};

// Test all endpoints
const runTests = async () => {
  const results = {};
  
  for (const endpoint of testEndpoints) {
    results[endpoint.name] = await testEndpoint(endpoint);
  }
  
  console.log('\n📊 SUMMARY:');
  console.log('═══════════════════════════════════════════════════════════════════════');
  
  Object.entries(results).forEach(([name, result]) => {
    const statusIcon = result.status === 200 ? '✅' : result.status === 404 ? '❌' : '⚠️';
    console.log(`${statusIcon} ${name}: ${result.status}`);
  });
  
  console.log('\n🔧 DIAGNOSIS:');
  console.log('═══════════════════════════════════════════════════════════════════════');
  
  const v2RxStatus = results['Patient RX (v2patients)']?.status;
  const v2OrdersStatus = results['Patient Orders (v2patients)']?.status;
  const v1RxStatus = results['Patient RX (v1 patients - alternative)']?.status;
  const v1OrdersStatus = results['Patient Orders (v1 patients - alternative)']?.status;
  
  if (v2RxStatus === 404 && v2OrdersStatus === 404) {
    console.log('❌ ISSUE: v2patients endpoints not found');
    if (v1RxStatus === 200 || v1OrdersStatus === 200) {
      console.log('✅ SOLUTION: Use v1 patients endpoints instead');
    } else {
      console.log('❌ DEEPER ISSUE: Neither v1 nor v2 endpoints work');
    }
  } else if (v2RxStatus === 200 && v2OrdersStatus === 200) {
    console.log('✅ v2patients endpoints working correctly');
  }
  
  console.log('\n🔗 NEXT STEPS:');
  console.log('1. Check which endpoints return 200 status');
  console.log('2. Update EyefinityService to use working endpoints');
  console.log('3. Test with different patient IDs if needed');
  console.log('4. Verify API scopes and permissions');
};

// Run the tests
runTests().catch(console.error);
