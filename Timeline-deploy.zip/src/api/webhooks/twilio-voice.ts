/**
 * Twilio Voice Webhook Handler
 * 
 * Handles inbound voice calls with AI-powered conversation.
 * Supports:
 * - Inbound call answering with AI greeting
 * - Speech recognition via Twilio/Deepgram
 * - AI response generation
 * - Call recording
 * - Call transfer to staff
 * - Escalation queue integration
 * 
 * Configure in Twilio Console:
 * Phone Numbers → Your Number → Voice → "A Call Comes In" → POST to your webhook URL
 */

import { UnifiedAIResponseService, PatientContext } from '../../services/ai/unified-ai-response-service';
import { DeepgramService } from '../../services/ai/deepgram-service';
import { ElevenLabsService } from '../../services/ai/elevenlabs-service';
import { getOrCreateDefaultPersona } from '../../services/ai/ai-persona';

// ==================== TYPES ====================

export interface TwilioVoiceWebhookBody {
  CallSid: string;
  AccountSid: string;
  From: string;
  To: string;
  CallStatus: 'ringing' | 'in-progress' | 'completed' | 'busy' | 'failed' | 'no-answer' | 'canceled';
  Direction: 'inbound' | 'outbound-api' | 'outbound-dial';
  ForwardedFrom?: string;
  CallerName?: string;
  // Speech recognition results
  SpeechResult?: string;
  Confidence?: string;
  // Recording results
  RecordingUrl?: string;
  RecordingDuration?: string;
  RecordingSid?: string;
  // Gather/DTMF
  Digits?: string;
}

export interface VoiceWebhookResult {
  twiml: string;
  callId: string;
  action: 'greeting' | 'respond' | 'transfer' | 'escalate' | 'end';
  transcription?: string;
  aiResponse?: string;
  error?: string;
}

export interface CallSession {
  callSid: string;
  patientId?: string;
  patientContext?: PatientContext;
  conversationHistory: Array<{
    role: 'patient' | 'assistant';
    content: string;
    timestamp: Date;
  }>;
  recordingUrl?: string;
  transcriptions: string[];
  startTime: Date;
  escalated: boolean;
  transferred: boolean;
  officeId: string;
}

// In-memory call sessions (in production, use Redis/database)
const activeCalls = new Map<string, CallSession>();

// ==================== CONFIGURATION ====================

const OFFICE_ID = '936';
const OFFICE_PHONE = process.env.TWILIO_OFFICE_FORWARD_NUMBER || '+15551234567';
const RECORD_CALLS = process.env.TWILIO_RECORD_CALLS !== 'false';
const AI_VOICE = process.env.TWILIO_AI_VOICE || 'Polly.Joanna';
const SPEECH_TIMEOUT = '3'; // seconds
const MAX_CONVERSATION_TURNS = 10;

// ==================== TwiML GENERATORS ====================

function escapeXml(unsafe: string): string {
  return unsafe.replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '&': return '&amp;';
      case '\'': return '&apos;';
      case '"': return '&quot;';
      default: return c;
    }
  });
}

/**
 * Generate TwiML for initial greeting
 */
export function generateGreetingTwiML(
  greeting: string,
  callbackUrl: string,
  voice: string = AI_VOICE
): string {
  return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${RECORD_CALLS ? '<Record action="' + callbackUrl + '/recording" recordingStatusCallback="' + callbackUrl + '/recording-status" maxLength="3600" transcribe="false" />' : ''}
  <Say voice="${voice}">${escapeXml(greeting)}</Say>
  <Gather input="speech" action="${callbackUrl}/respond" method="POST" speechTimeout="${SPEECH_TIMEOUT}" language="en-US">
    <Say voice="${voice}">How may I help you today?</Say>
  </Gather>
  <Say voice="${voice}">I didn't hear anything. Please call back if you need assistance. Goodbye.</Say>
</Response>`;
}

/**
 * Generate TwiML for AI response with continued listening
 */
export function generateResponseTwiML(
  response: string,
  callbackUrl: string,
  voice: string = AI_VOICE,
  continueConversation: boolean = true
): string {
  if (!continueConversation) {
    return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="${voice}">${escapeXml(response)}</Say>
  <Hangup />
</Response>`;
  }

  return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="${voice}">${escapeXml(response)}</Say>
  <Gather input="speech" action="${callbackUrl}/respond" method="POST" speechTimeout="${SPEECH_TIMEOUT}" language="en-US">
    <Say voice="${voice}">Is there anything else I can help you with?</Say>
  </Gather>
  <Say voice="${voice}">Thank you for calling. Goodbye!</Say>
</Response>`;
}

/**
 * Generate TwiML for call transfer
 */
export function generateTransferTwiML(
  transferMessage: string,
  transferTo: string,
  callbackUrl: string,
  voice: string = AI_VOICE
): string {
  return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="${voice}">${escapeXml(transferMessage)}</Say>
  <Dial action="${callbackUrl}/transfer-complete" timeout="30" callerId="${process.env.TWILIO_PHONE_NUMBER}">
    <Number>${transferTo}</Number>
  </Dial>
  <Say voice="${voice}">I'm sorry, but I wasn't able to connect you. Please try calling back later.</Say>
</Response>`;
}

/**
 * Generate TwiML for voicemail
 */
export function generateVoicemailTwiML(
  voicemailPrompt: string,
  callbackUrl: string,
  voice: string = AI_VOICE
): string {
  return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="${voice}">${escapeXml(voicemailPrompt)}</Say>
  <Record action="${callbackUrl}/voicemail" maxLength="120" transcribe="true" transcribeCallback="${callbackUrl}/voicemail-transcription" />
  <Say voice="${voice}">I didn't receive a message. Goodbye.</Say>
</Response>`;
}

// ==================== MAIN HANDLERS ====================

/**
 * Handle initial inbound call
 */
export async function handleInboundCall(
  body: TwilioVoiceWebhookBody,
  callbackUrl: string,
  lookupPatient: (phone: string) => Promise<PatientContext | null>
): Promise<VoiceWebhookResult> {
  const { CallSid: callSid, From: fromPhone, CallerName: callerName } = body;

  console.log(`[Voice Webhook] Inbound call ${callSid} from ${fromPhone} (${callerName || 'Unknown'})`);

  // Look up patient by phone number
  const patientContext = await lookupPatient(fromPhone);
  
  // Get AI persona for greeting
  const persona = getOrCreateDefaultPersona(OFFICE_ID, 'Eye Care Center');
  const officeName = patientContext?.officeName || 'our office';

  // Create call session
  const session: CallSession = {
    callSid,
    patientId: patientContext?.patientId,
    patientContext: patientContext || {
      firstName: callerName?.split(' ')[0] || 'there',
      lastName: callerName?.split(' ').slice(1).join(' ') || '',
      phone: fromPhone,
    },
    conversationHistory: [],
    transcriptions: [],
    startTime: new Date(),
    escalated: false,
    transferred: false,
    officeId: OFFICE_ID,
  };
  activeCalls.set(callSid, session);

  // Generate personalized greeting
  let greeting: string;
  if (patientContext) {
    greeting = `Hello ${patientContext.firstName}! Thank you for calling ${officeName}. This is ${persona.name}, your virtual assistant.`;
    
    // Add appointment context if available
    if (patientContext.appointmentDateTime) {
      const aptDate = new Date(patientContext.appointmentDateTime);
      greeting += ` I see you have an appointment scheduled for ${aptDate.toLocaleDateString()} at ${aptDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`;
    }
  } else {
    greeting = `Hello! Thank you for calling ${officeName}. This is ${persona.name}, your virtual assistant.`;
  }

  // Add greeting to history
  session.conversationHistory.push({
    role: 'assistant',
    content: greeting,
    timestamp: new Date(),
  });

  return {
    twiml: generateGreetingTwiML(greeting, callbackUrl, AI_VOICE),
    callId: callSid,
    action: 'greeting',
    aiResponse: greeting,
  };
}

/**
 * Handle speech input and generate AI response
 */
export async function handleSpeechInput(
  body: TwilioVoiceWebhookBody,
  callbackUrl: string
): Promise<VoiceWebhookResult> {
  const { CallSid: callSid, SpeechResult: speechResult, Confidence: confidence } = body;

  console.log(`[Voice Webhook] Speech received for ${callSid}: "${speechResult}" (confidence: ${confidence})`);

  const session = activeCalls.get(callSid);
  if (!session) {
    console.error(`[Voice Webhook] No session found for call ${callSid}`);
    return {
      twiml: generateResponseTwiML(
        "I'm sorry, there was an error. Please call back.",
        callbackUrl,
        AI_VOICE,
        false
      ),
      callId: callSid,
      action: 'end',
      error: 'Session not found',
    };
  }

  // Check for max conversation turns
  if (session.conversationHistory.length >= MAX_CONVERSATION_TURNS * 2) {
    return {
      twiml: generateTransferTwiML(
        "Thank you for your patience. Let me connect you with a staff member who can help further.",
        OFFICE_PHONE,
        callbackUrl
      ),
      callId: callSid,
      action: 'transfer',
    };
  }

  const transcript = speechResult || '';
  session.transcriptions.push(transcript);
  
  // Add to conversation history
  session.conversationHistory.push({
    role: 'patient',
    content: transcript,
    timestamp: new Date(),
  });

  // Update patient context with conversation history
  const contextWithHistory: PatientContext = {
    ...session.patientContext!,
    previousMessages: session.conversationHistory.map(h => ({
      role: h.role,
      content: h.content,
      timestamp: h.timestamp.toISOString(),
    })),
  };

  try {
    // Generate AI response
    const aiResult = await UnifiedAIResponseService.generateResponse(
      transcript,
      contextWithHistory,
      session.officeId,
      { channel: 'voice', generateAudio: false }
    );

    // Add AI response to history
    session.conversationHistory.push({
      role: 'assistant',
      content: aiResult.text,
      timestamp: new Date(),
    });

    // Check if escalation required
    if (aiResult.escalationRequired) {
      session.escalated = true;
      
      // Create escalation alert (would integrate with CommunicationService)
      console.log(`[Voice Webhook] Escalation triggered: ${aiResult.escalationReason}`);
      
      return {
        twiml: generateTransferTwiML(
          aiResult.text,
          OFFICE_PHONE,
          callbackUrl
        ),
        callId: callSid,
        action: 'escalate',
        transcription: transcript,
        aiResponse: aiResult.text,
      };
    }

    // Check if conversation should end
    const shouldEnd = 
      transcript.toLowerCase().includes('goodbye') ||
      transcript.toLowerCase().includes('thank you') && transcript.toLowerCase().includes('bye') ||
      aiResult.intent.primary === 'end_call';

    return {
      twiml: generateResponseTwiML(
        aiResult.text,
        callbackUrl,
        AI_VOICE,
        !shouldEnd
      ),
      callId: callSid,
      action: 'respond',
      transcription: transcript,
      aiResponse: aiResult.text,
    };
  } catch (error: any) {
    console.error('[Voice Webhook] AI response error:', error);
    
    return {
      twiml: generateTransferTwiML(
        "I apologize, I'm having some technical difficulties. Let me connect you with a staff member.",
        OFFICE_PHONE,
        callbackUrl
      ),
      callId: callSid,
      action: 'transfer',
      error: error?.message,
    };
  }
}

/**
 * Handle recording callback
 */
export async function handleRecordingCallback(
  body: TwilioVoiceWebhookBody
): Promise<void> {
  const { CallSid: callSid, RecordingUrl: recordingUrl, RecordingDuration: duration } = body;

  console.log(`[Voice Webhook] Recording for ${callSid}: ${recordingUrl} (${duration}s)`);

  const session = activeCalls.get(callSid);
  if (session) {
    session.recordingUrl = recordingUrl;
  }
}

/**
 * Handle call completion
 */
export async function handleCallComplete(
  body: TwilioVoiceWebhookBody,
  saveCallRecord: (record: CallRecord) => Promise<void>,
  createEscalation?: (escalation: EscalationData) => Promise<void>
): Promise<void> {
  const { CallSid: callSid, CallStatus: status } = body;

  console.log(`[Voice Webhook] Call ${callSid} completed with status: ${status}`);

  const session = activeCalls.get(callSid);
  if (!session) return;

  const endTime = new Date();
  const duration = Math.round((endTime.getTime() - session.startTime.getTime()) / 1000);

  // Build full transcript
  const fullTranscript = session.conversationHistory
    .map(h => `${h.role === 'patient' ? 'Patient' : 'AI'}: ${h.content}`)
    .join('\n');

  // Save call record
  const callRecord: CallRecord = {
    id: callSid,
    patientId: session.patientId || 'unknown',
    patientName: `${session.patientContext?.firstName || ''} ${session.patientContext?.lastName || ''}`.trim() || 'Unknown Caller',
    phoneNumber: session.patientContext?.phone || '',
    direction: 'inbound',
    status: status === 'completed' ? 'completed' : 'failed',
    startTime: session.startTime,
    endTime,
    duration,
    recordingUrl: session.recordingUrl,
    transcription: fullTranscript,
    callType: 'patient',
    escalated: session.escalated,
    transferred: session.transferred,
  };

  await saveCallRecord(callRecord);

  // Create escalation if needed
  if (session.escalated && createEscalation) {
    await createEscalation({
      patientId: session.patientId || 'unknown',
      patientName: callRecord.patientName,
      reason: 'Call escalated by AI agent',
      priority: 'high',
      source: 'ai',
      transcript: fullTranscript,
      callDuration: duration,
      callRecordingUrl: session.recordingUrl,
      communicationId: callSid,
    });
  }

  // Clean up session
  activeCalls.delete(callSid);
}

/**
 * Handle transfer completion
 */
export function handleTransferComplete(body: TwilioVoiceWebhookBody): string {
  const { CallSid: callSid, DialCallStatus } = body as TwilioVoiceWebhookBody & { DialCallStatus?: string };

  console.log(`[Voice Webhook] Transfer for ${callSid} completed: ${DialCallStatus}`);

  const session = activeCalls.get(callSid);
  if (session) {
    session.transferred = true;
  }

  if (DialCallStatus === 'completed') {
    return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="${AI_VOICE}">Thank you for calling. Have a great day!</Say>
  <Hangup />
</Response>`;
  }

  // Transfer failed - offer voicemail
  return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="${AI_VOICE}">I'm sorry, but no one is available right now. Would you like to leave a message?</Say>
  <Gather input="speech dtmf" action="/api/webhooks/twilio-voice/voicemail-choice" method="POST" numDigits="1" timeout="5">
    <Say voice="${AI_VOICE}">Press 1 or say yes to leave a message, or press 2 or say no to end the call.</Say>
  </Gather>
  <Say voice="${AI_VOICE}">Goodbye!</Say>
  <Hangup />
</Response>`;
}

// ==================== TYPES FOR EXTERNAL INTEGRATION ====================

export interface CallRecord {
  id: string;
  patientId: string;
  patientName: string;
  phoneNumber: string;
  direction: 'inbound' | 'outbound';
  status: 'completed' | 'failed' | 'busy' | 'no-answer';
  startTime: Date;
  endTime: Date;
  duration: number;
  recordingUrl?: string;
  transcription?: string;
  callType: 'patient' | 'office';
  escalated: boolean;
  transferred: boolean;
}

export interface EscalationData {
  patientId: string;
  patientName: string;
  reason: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  source: 'ai' | 'patient' | 'staff' | 'system';
  transcript?: string;
  callDuration?: number;
  callRecordingUrl?: string;
  communicationId?: string;
}

// ==================== HELPER FUNCTIONS ====================

export function getActiveCallSession(callSid: string): CallSession | undefined {
  return activeCalls.get(callSid);
}

export function getActiveCallCount(): number {
  return activeCalls.size;
}

/**
 * Express route handlers example:
 * 
 * app.post('/api/webhooks/twilio-voice', async (req, res) => {
 *   const result = await handleInboundCall(req.body, getCallbackUrl(req), lookupPatientByPhone);
 *   res.set('Content-Type', 'text/xml');
 *   res.send(result.twiml);
 * });
 * 
 * app.post('/api/webhooks/twilio-voice/respond', async (req, res) => {
 *   const result = await handleSpeechInput(req.body, getCallbackUrl(req));
 *   res.set('Content-Type', 'text/xml');
 *   res.send(result.twiml);
 * });
 * 
 * app.post('/api/webhooks/twilio-voice/recording', async (req, res) => {
 *   await handleRecordingCallback(req.body);
 *   res.status(200).send('OK');
 * });
 * 
 * app.post('/api/webhooks/twilio-voice/status', async (req, res) => {
 *   await handleCallComplete(req.body, saveCallRecord, createEscalation);
 *   res.status(200).send('OK');
 * });
 * 
 * app.post('/api/webhooks/twilio-voice/transfer-complete', (req, res) => {
 *   const twiml = handleTransferComplete(req.body);
 *   res.set('Content-Type', 'text/xml');
 *   res.send(twiml);
 * });
 */
