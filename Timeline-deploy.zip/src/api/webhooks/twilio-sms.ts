/**
 * Twilio SMS Webhook Handler
 * 
 * This handler processes inbound SMS messages from Twilio.
 * Deploy this with an Express server or serverless function.
 * 
 * Configure in Twilio Console:
 * Phone Numbers → Your Number → Messaging → "A Message Comes In" → POST to your webhook URL
 */

import { EnhancedAISMSService, PatientContext } from '../../lib/services/enhanced-ai-sms-service';
import { sendSMS } from '../../lib/twilio';

export interface TwilioSMSWebhookBody {
  MessageSid: string;
  AccountSid: string;
  MessagingServiceSid?: string;
  From: string;
  To: string;
  Body: string;
  NumMedia?: string;
  NumSegments?: string;
}

export interface SMSWebhookResult {
  success: boolean;
  messageId?: string;
  intent?: string;
  reply?: string;
  error?: string;
}

/**
 * Process inbound SMS from Twilio webhook
 */
export async function handleInboundSMS(
  body: TwilioSMSWebhookBody,
  lookupPatient: (phone: string) => Promise<PatientContext | null>
): Promise<SMSWebhookResult> {
  try {
    const { From: fromPhone, Body: messageBody, MessageSid: messageSid } = body;

    console.log(`[SMS Webhook] Received from ${fromPhone}: ${messageBody}`);

    // Look up patient by phone number
    const patientContext = await lookupPatient(fromPhone);

    if (!patientContext) {
      // Unknown sender - send generic response
      const genericReply = "Thank you for your message. Please call our office for assistance.";
      await sendSMS(fromPhone, genericReply);
      return {
        success: true,
        messageId: messageSid,
        reply: genericReply
      };
    }

    // Check if AI SMS replies are enabled
    if (process.env.ENABLE_AI_SMS_REPLY === 'true') {
      // Generate AI-powered reply
      const aiResult = await EnhancedAISMSService.generateEnhancedReply(
        messageBody,
        patientContext,
        { 
          tone: 'friendly', 
          maxLength: 160,
          personalize: true,
          includeNextSteps: true
        }
      );

      console.log(`[SMS Webhook] Intent: ${aiResult.intent.intent}, Mode: ${aiResult.mode}`);

      // Handle booking requests specially
      if (EnhancedAISMSService.isBookingRequest(aiResult.intent)) {
        // Could integrate with Eyefinity to check availability
        console.log('[SMS Webhook] Booking request detected:', aiResult.intent.bookingDetails);
      }

      // Send AI reply
      const smsResult = await sendSMS(fromPhone, aiResult.reply);

      return {
        success: smsResult.success,
        messageId: messageSid,
        intent: aiResult.intent.intent,
        reply: aiResult.reply
      };
    } else {
      // AI disabled - send acknowledgment
      const ackReply = `Hi ${patientContext.firstName}! We received your message and will respond during business hours.`;
      await sendSMS(fromPhone, ackReply);
      return {
        success: true,
        messageId: messageSid,
        reply: ackReply
      };
    }
  } catch (error: any) {
    console.error('[SMS Webhook] Error:', error);
    return {
      success: false,
      error: error?.message || 'Failed to process SMS'
    };
  }
}

/**
 * Generate TwiML response (for synchronous webhook response)
 */
export function generateTwiMLResponse(message?: string): string {
  if (message) {
    return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Message>${escapeXml(message)}</Message>
</Response>`;
  }
  return `<?xml version="1.0" encoding="UTF-8"?><Response></Response>`;
}

function escapeXml(unsafe: string): string {
  return unsafe.replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '&': return '&amp;';
      case '\'': return '&apos;';
      case '"': return '&quot;';
      default: return c;
    }
  });
}

/**
 * Express route handler example:
 * 
 * app.post('/api/webhooks/twilio/sms', async (req, res) => {
 *   const result = await handleInboundSMS(req.body, lookupPatientByPhone);
 *   res.set('Content-Type', 'text/xml');
 *   res.send(generateTwiMLResponse());
 * });
 */
