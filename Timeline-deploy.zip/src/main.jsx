import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './contexts/AuthContext.jsx'
import { CompanyProvider } from './contexts/CompanyContext.jsx'
import ProtectedRoute from './components/ProtectedRoute.jsx'
import Login from './pages/Login.jsx'
import { LoginPage, RegisterPage, MFASetupPage, InviteManagementPage, ChangePasswordPage } from './pages/auth'
import App from './App.jsx'
import PatientReadinessCenter from './pages/PatientReadinessCenter.jsx'
import AdminConfig from './pages/AdminConfig.jsx'
import ApiTest from './pages/ApiTest.jsx'
import AICommunicationTest from './pages/AICommunicationTest.jsx'
import PatientJourneyPage from './pages/PatientJourneyPage.jsx'
import JourneyAdmin from './pages/JourneyAdmin.jsx'
import AICommunicationSettings from './pages/AICommunicationSettings.jsx'
import FormsLandingPage from './pages/FormsLandingPage.jsx'
import PatientFormPage from './pages/PatientFormPage.jsx'
import FormsAdminPage from './pages/FormsAdminPage.jsx'
import AIKnowledgeBase from './pages/AIKnowledgeBase.jsx'
import HelpDocumentation from './pages/HelpDocumentation.jsx'
import MobileCheckinPage from './pages/MobileCheckinPage.jsx'
import RecommendationsAdmin from './pages/RecommendationsAdmin.jsx'
import InsuranceVerificationSettings from './pages/InsuranceVerificationSettings.jsx'
import AnalyticsDashboard from './pages/AnalyticsDashboard.jsx'
import AdminDashboard from './components/admin/AdminDashboard.jsx'
import { initializeSampleRules } from './lib/data/sample-recommendation-rules'

// Patient App Pages
import PatientLogin from './patient-app/pages/PatientLogin.jsx'
import PatientDashboard from './patient-app/pages/PatientDashboard.jsx'
import PatientWaitTime from './patient-app/pages/PatientWaitTime.jsx'
import PatientRx from './patient-app/pages/PatientRx.jsx'
import PatientBilling from './patient-app/pages/PatientBilling.jsx'
import PatientRecommendations from './patient-app/pages/PatientRecommendations.jsx'
import FrameScanner from './pages/patient/FrameScanner.jsx'
import Measurements from './pages/patient/Measurements.jsx'

import './index.css'

// Fetch interceptor: auto-attach Bearer token to all /api/ requests
const _originalFetch = window.fetch;
window.fetch = function(input, init) {
  const url = typeof input === 'string' ? input : input instanceof Request ? input.url : '';
  if (url.startsWith('/api/')) {
    const session = localStorage.getItem('auth_session');
    if (session) {
      try {
        const { token } = JSON.parse(session);
        if (token) {
          init = init || {};
          init.headers = new Headers(init.headers || {});
          if (!init.headers.has('Authorization')) {
            init.headers.set('Authorization', `Bearer ${token}`);
          }
        }
      } catch (e) { /* ignore parse errors */ }
    }
  }
  return _originalFetch.call(this, input, init);
};

// Initialize sample recommendation rules on app startup
initializeSampleRules();

function Root() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <CompanyProvider>
          <Routes>
          {/* Auth Routes */}
          <Route path="/login" element={<LoginPage />} />
          <Route path="/login-legacy" element={<Login />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route 
            path="/mfa-setup" 
            element={
              <ProtectedRoute>
                <MFASetupPage />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/user-management" 
            element={
              <ProtectedRoute requireAdmin={true}>
                <InviteManagementPage />
              </ProtectedRoute>
            } 
          />
          <Route path="/change-password" element={<ChangePasswordPage />} />
          <Route path="/" element={<Navigate to="/prc" replace />} />
          <Route 
            path="/timeline" 
            element={
              <ProtectedRoute>
                <App />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/prc" 
            element={
              <ProtectedRoute>
                <PatientReadinessCenter />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/api-test" 
            element={
              <ProtectedRoute requireAdmin={true}>
                <ApiTest />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/ai-test" 
            element={
              <ProtectedRoute requireAdmin={true}>
                <AICommunicationTest />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/journey" 
            element={
              <ProtectedRoute>
                <PatientJourneyPage />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/journey-admin" 
            element={
              <ProtectedRoute requireAdmin={true}>
                <JourneyAdmin />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/ai-communication-settings" 
            element={
              <ProtectedRoute requireAdmin={true}>
                <AICommunicationSettings />
              </ProtectedRoute>
            } 
          />
          {/* Forms Admin (Protected) */}
          <Route 
            path="/forms-admin" 
            element={
              <ProtectedRoute>
                <FormsAdminPage />
              </ProtectedRoute>
            } 
          />
          {/* Admin Dashboard - Company & Office Management */}
          <Route 
            path="/admin" 
            element={
              <ProtectedRoute requireAdmin={true}>
                <AdminDashboard />
              </ProtectedRoute>
            } 
          />
          {/* AI Knowledge Base */}
          <Route 
            path="/ai-knowledge-base" 
            element={
              <ProtectedRoute requireAdmin={true}>
                <AIKnowledgeBase />
              </ProtectedRoute>
            } 
          />
          {/* Recommendations Admin */}
          <Route
            path="/recommendations-admin"
            element={
              <ProtectedRoute requireAdmin={true}>
                <RecommendationsAdmin />
              </ProtectedRoute>
            }
          />
          {/* Insurance Verification Settings */}
          <Route
            path="/insurance-settings"
            element={
              <ProtectedRoute requireAdmin={true}>
                <InsuranceVerificationSettings />
              </ProtectedRoute>
            }
          />
          {/* Analytics Dashboard */}
          <Route
            path="/analytics"
            element={
              <ProtectedRoute requireAdmin={true}>
                <AnalyticsDashboard />
              </ProtectedRoute>
            }
          />
          {/* Help & Documentation */}
          <Route
            path="/help"
            element={
              <ProtectedRoute>
                <HelpDocumentation />
              </ProtectedRoute>
            }
          />
          {/* Account & Company Setup */}
          <Route 
            path="/account-setup" 
            element={
              <ProtectedRoute requireAdmin={true}>
                <AdminDashboard />
              </ProtectedRoute>
            } 
          />
          {/* Patient Portal Routes (Public - No Auth Required) */}
          <Route path="/forms" element={<FormsLandingPage />} />
          <Route path="/forms/patient/:token" element={<PatientFormPage />} />
          <Route path="/checkin" element={<MobileCheckinPage />} />
          
          {/* Patient App Routes (Public - Session Auth) */}
          <Route path="/patient/login" element={<PatientLogin />} />
          <Route path="/patient/dashboard" element={<PatientDashboard />} />
          <Route path="/patient/wait" element={<PatientWaitTime />} />
          <Route path="/patient/rx" element={<PatientRx />} />
          <Route path="/patient/billing" element={<PatientBilling />} />
          <Route path="/patient/recommendations" element={<PatientRecommendations />} />
          
          {/* Patient Frame Scanner & Measurements (Public - Token Auth) */}
          <Route path="/patient/frame-scanner" element={<FrameScanner />} />
          <Route path="/patient/measurements" element={<Measurements />} />
        </Routes>
        </CompanyProvider>
      </AuthProvider>
    </BrowserRouter>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Root />
  </React.StrictMode>,
)
