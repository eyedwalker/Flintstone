/**
 * Patient Wait Time Page
 * Real-time queue position and estimated wait time
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Clock, 
  Users, 
  CheckCircle,
  Coffee,
  Book,
  Smartphone,
  RefreshCw
} from 'lucide-react';
import { PatientAppService } from '../../lib/services/patient-app-service';
import PatientAppLayout from '../layouts/PatientAppLayout';

export default function PatientWaitTime() {
  const navigate = useNavigate();
  const [session, setSession] = useState(null);
  const [waitInfo, setWaitInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadWaitTime();
    
    // Auto-refresh every 30 seconds
    const interval = setInterval(() => {
      loadWaitTime(true);
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const loadWaitTime = async (silent = false) => {
    if (!silent) setLoading(true);
    
    const currentSession = PatientAppService.getCurrentSession();
    if (!currentSession) {
      navigate('/patient/login');
      return;
    }

    setSession(currentSession);
    const info = PatientAppService.getWaitTimeInfo(currentSession);
    setWaitInfo(info);
    setLoading(false);
    setRefreshing(false);
  };

  const handleRefresh = () => {
    setRefreshing(true);
    loadWaitTime(true);
  };

  if (loading) {
    return (
      <PatientAppLayout>
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </PatientAppLayout>
    );
  }

  const suggestions = [
    {
      icon: Coffee,
      title: 'Grab a Coffee',
      description: 'Café in the lobby',
      time: '2-3 min'
    },
    {
      icon: Book,
      title: 'Browse Frames',
      description: 'Check out new styles',
      action: () => navigate('/patient/recommendations')
    },
    {
      icon: Smartphone,
      title: 'View Recommendations',
      description: 'Personalized for you',
      action: () => navigate('/patient/recommendations')
    }
  ];

  return (
    <PatientAppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Wait Time</h1>
            <p className="text-gray-600 mt-1">Your current position</p>
          </div>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="p-2 hover:bg-white rounded-lg transition-colors"
          >
            <RefreshCw className={`w-5 h-5 text-gray-600 ${refreshing ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Main Wait Time Card */}
        <div className="bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 rounded-2xl p-8 text-white shadow-lg">
          <div className="text-center">
            {waitInfo?.estimatedMinutes === 0 ? (
              <>
                <CheckCircle className="w-16 h-16 mx-auto mb-4" />
                <div className="text-3xl font-bold mb-2">You're Ready!</div>
                <div className="text-white/90 text-lg">
                  Please wait nearby, we'll call you shortly
                </div>
              </>
            ) : (
              <>
                <Clock className="w-16 h-16 mx-auto mb-4" />
                <div className="text-6xl font-bold mb-2">
                  {waitInfo?.estimatedMinutes || 0}
                </div>
                <div className="text-2xl font-semibold mb-1">minutes</div>
                <div className="text-white/90 text-lg">
                  {waitInfo?.message || 'Estimated wait time'}
                </div>
              </>
            )}
          </div>

          {/* Progress Animation */}
          {waitInfo?.estimatedMinutes > 0 && (
            <div className="mt-6">
              <div className="h-2 bg-white/30 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-white rounded-full transition-all duration-1000"
                  style={{ width: `${Math.max(20, 100 - (waitInfo.estimatedMinutes * 5))}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Queue Position */}
        {waitInfo?.queuePosition > 1 && (
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <div className="text-sm text-gray-600">Your Position</div>
                  <div className="text-2xl font-bold text-gray-900">
                    #{waitInfo.queuePosition}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-600">Status</div>
                <div className="text-lg font-semibold text-blue-600 capitalize">
                  {waitInfo.status}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* While You Wait */}
        {waitInfo?.estimatedMinutes > 5 && (
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <h2 className="text-lg font-bold text-gray-900 mb-4">
              💡 While You Wait
            </h2>
            <div className="space-y-3">
              {suggestions.map((suggestion, index) => {
                const Icon = suggestion.icon;
                return (
                  <button
                    key={index}
                    onClick={suggestion.action}
                    className="w-full flex items-center gap-4 p-4 rounded-xl border-2 border-gray-100 hover:border-blue-200 hover:bg-blue-50 transition-all text-left"
                  >
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-gray-900">{suggestion.title}</div>
                      <div className="text-sm text-gray-600">{suggestion.description}</div>
                    </div>
                    {suggestion.time && (
                      <div className="text-sm text-gray-500">{suggestion.time}</div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Info Notice */}
        <div className="bg-blue-50 rounded-xl p-4 flex items-start gap-3">
          <Clock className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-blue-900">
            <div className="font-semibold mb-1">Wait times are estimates</div>
            <div className="text-blue-700">
              Actual wait may vary based on patient needs. We'll update you in real-time.
            </div>
          </div>
        </div>

        {/* Last Updated */}
        <div className="text-center text-sm text-gray-500">
          Auto-refreshing every 30 seconds
        </div>
      </div>
    </PatientAppLayout>
  );
}
