/**
 * Patient Dashboard
 * Main view showing visit status, journey progress, and quick actions
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Clock, 
  MapPin, 
  CheckCircle, 
  AlertCircle,
  ArrowRight,
  Calendar,
  User as UserIcon,
  Sparkles,
  CreditCard,
  MessageSquare,
  FileText
} from 'lucide-react';
import { PatientAppService } from '../../lib/services/patient-app-service';
import PatientAppLayout from '../layouts/PatientAppLayout';

export default function PatientDashboard() {
  const navigate = useNavigate();
  const [session, setSession] = useState(null);
  const [journeyStatus, setJourneyStatus] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = () => {
    const currentSession = PatientAppService.getCurrentSession();
    if (!currentSession) {
      navigate('/patient/login');
      return;
    }

    setSession(currentSession);
    const status = PatientAppService.getJourneyStatus(currentSession);
    setJourneyStatus(status);
    setLoading(false);
  };

  if (loading) {
    return (
      <PatientAppLayout>
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </PatientAppLayout>
    );
  }

  const phaseConfig = {
    'pre-visit': { label: 'Pre-Visit', color: 'purple', icon: Calendar },
    'in-office': { label: 'In Office', color: 'green', icon: MapPin },
    'post-visit': { label: 'Post-Visit', color: 'blue', icon: CheckCircle },
    'completed': { label: 'Completed', color: 'gray', icon: CheckCircle }
  };

  const currentPhase = journeyStatus?.phase || 'pre-visit';
  const phaseInfo = phaseConfig[currentPhase];
  const PhaseIcon = phaseInfo?.icon || AlertCircle;

  const quickActions = [
    { 
      icon: Clock, 
      label: 'Wait Time', 
      path: '/patient/wait',
      color: 'blue',
      description: 'See your position'
    },
    { 
      icon: Sparkles, 
      label: 'For You', 
      path: '/patient/recommendations',
      color: 'purple',
      description: '2 new recommendations',
      badge: '2'
    },
    { 
      icon: FileText, 
      label: 'My Rx', 
      path: '/patient/rx',
      color: 'green',
      description: 'View prescription'
    },
    { 
      icon: CreditCard, 
      label: 'Pay Bill', 
      path: '/patient/billing',
      color: 'orange',
      description: 'View & pay invoice'
    }
  ];

  return (
    <PatientAppLayout>
      <div className="space-y-6">
        {/* Welcome Header */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                👋 Hi {session?.patientName?.split(' ')[0]}!
              </h1>
              <p className="text-gray-600 mt-1">Here's your visit status</p>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-medium bg-${phaseInfo?.color}-100 text-${phaseInfo?.color}-700 flex items-center gap-1`}>
              <PhaseIcon className="w-4 h-4" />
              {phaseInfo?.label}
            </div>
          </div>

          {journeyStatus && (
            <div className="space-y-4">
              {/* Current Status */}
              <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl">
                <div className="w-12 h-12 rounded-full bg-white shadow-sm flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <div className="text-sm text-gray-600">Currently At</div>
                  <div className="font-semibold text-gray-900">
                    {journeyStatus.currentStep?.title || 'Check-in'}
                  </div>
                </div>
                {journeyStatus.currentStep?.status === 'in-progress' && (
                  <div className="animate-pulse">
                    <div className="w-2 h-2 rounded-full bg-green-500"></div>
                  </div>
                )}
              </div>

              {/* Progress Bar */}
              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-600">Visit Progress</span>
                  <span className="font-semibold text-gray-900">{journeyStatus.progress}%</span>
                </div>
                <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full transition-all duration-500"
                    style={{ width: `${journeyStatus.progress}%` }}
                  />
                </div>
              </div>

              {/* Estimated Time */}
              {journeyStatus.estimatedTimeRemaining > 0 && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Clock className="w-4 h-4" />
                  <span>About {journeyStatus.estimatedTimeRemaining} minutes remaining</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Journey Timeline */}
        {journeyStatus?.journey?.steps && (
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <h2 className="text-lg font-bold text-gray-900 mb-4">Your Journey</h2>
            <div className="space-y-3">
              {journeyStatus.journey.steps.map((step, index) => {
                const isCompleted = step.status === 'completed';
                const isCurrent = step.id === journeyStatus.currentStep?.id;
                const isPending = step.status === 'pending';

                return (
                  <div 
                    key={step.id}
                    className={`flex items-center gap-3 p-3 rounded-lg transition-all ${
                      isCurrent ? 'bg-blue-50 border-2 border-blue-200' : 
                      isCompleted ? 'bg-green-50' : 
                      'bg-gray-50'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      isCompleted ? 'bg-green-500' :
                      isCurrent ? 'bg-blue-500' :
                      'bg-gray-300'
                    }`}>
                      {isCompleted ? (
                        <CheckCircle className="w-5 h-5 text-white" />
                      ) : (
                        <span className="text-white text-sm font-bold">{index + 1}</span>
                      )}
                    </div>
                    <div className="flex-1">
                      <div className={`font-medium ${
                        isCurrent ? 'text-blue-900' :
                        isCompleted ? 'text-green-900' :
                        'text-gray-600'
                      }`}>
                        {step.title}
                      </div>
                      {isCurrent && (
                        <div className="text-xs text-blue-600 font-medium mt-0.5">
                          In Progress...
                        </div>
                      )}
                    </div>
                    {isCurrent && (
                      <ArrowRight className="w-5 h-5 text-blue-600 animate-pulse" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Quick Actions */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <button
                  key={action.path}
                  onClick={() => navigate(action.path)}
                  className="relative p-4 rounded-xl border-2 border-gray-100 hover:border-gray-200 hover:shadow-md transition-all text-left group"
                >
                  {action.badge && (
                    <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                      {action.badge}
                    </div>
                  )}
                  <div className={`w-10 h-10 rounded-lg bg-${action.color}-100 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                    <Icon className={`w-5 h-5 text-${action.color}-600`} />
                  </div>
                  <div className="font-semibold text-gray-900">{action.label}</div>
                  <div className="text-xs text-gray-500 mt-1">{action.description}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Appointment Info */}
        {session && (
          <div className="bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl p-6">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center flex-shrink-0">
                <Calendar className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <div className="font-semibold text-purple-900">Today's Appointment</div>
                <div className="text-sm text-purple-700 mt-1">
                  {session.patientName}
                </div>
                {session.patientEmail && (
                  <div className="text-xs text-purple-600 mt-1">
                    {session.patientEmail}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </PatientAppLayout>
  );
}
