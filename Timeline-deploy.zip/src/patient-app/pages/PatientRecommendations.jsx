/**
 * Patient Recommendations Page
 * Personalized product and service recommendations
 */

import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, Heart, Share2, X, ShoppingCart } from 'lucide-react';
import { PatientAppService } from '../../lib/services/patient-app-service';
import { RecommendationService } from '../../lib/services/recommendation-service';
import { EyefinityService } from '../../services/eyefinityService';
import PatientAppLayout from '../layouts/PatientAppLayout';
import RecommendationCard from '../../components/recommendations/RecommendationCard';

export default function PatientRecommendations() {
  const navigate = useNavigate();
  const [session, setSession] = useState(null);
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    loadRecommendations();
  }, []);

  const loadRecommendations = async () => {
    const currentSession = PatientAppService.getCurrentSession();
    if (!currentSession) {
      navigate('/patient/login');
      return;
    }

    setSession(currentSession);

    try {
      // Get journey status for context
      const journeyStatus = PatientAppService.getJourneyStatus(currentSession);
      
      // Fetch patient demographics for age and lifestyle
      const demographics = await EyefinityService.getPatientById(currentSession.patientId);
      
      // Build recommendation context
      const context = {
        patient: {
          id: currentSession.patientId,
          firstName: demographics.firstName || currentSession.patientName?.split(' ')[0],
          lastName: demographics.lastName || currentSession.patientName?.split(' ').slice(1).join(' '),
          age: demographics.age || 0,
          dateOfBirth: demographics.dob ? new Date(demographics.dob) : new Date(),
          lifestyle: {},
          preferences: {}
        },
        journey: journeyStatus ? {
          id: journeyStatus.journey.id,
          journeyPhase: journeyStatus.journey.journeyPhase,
          currentStep: journeyStatus.currentStep?.title,
          status: journeyStatus.journey.status
        } : undefined,
        appointment: currentSession.appointmentId ? {
          id: currentSession.appointmentId,
          date: new Date(),
          type: 'Annual Exam',
          status: 'scheduled'
        } : undefined,
        purchaseHistory: [],
        insuranceInfo: demographics.insurances?.[0] ? {
          carrier: demographics.insurances[0].carrier || demographics.insurances[0].planName,
          planName: demographics.insurances[0].planName
        } : undefined
      };

      // Generate recommendations
      const recs = RecommendationService.generateRecommendations(
        context,
        'patient-app-feed'
      );

      setRecommendations(recs);

      // Track impressions
      recs.forEach(rec => {
        RecommendationService.trackEvent(
          rec.id,
          currentSession.patientId,
          'impression',
          'patient-app-feed',
          { source: 'patient-app' }
        );
      });

      // Load favorites from localStorage
      const savedFavorites = localStorage.getItem(`patient_favorites_${currentSession.patientId}`);
      if (savedFavorites) {
        setFavorites(JSON.parse(savedFavorites));
      }
    } catch (error) {
      console.error('Error loading recommendations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDismiss = (recommendation) => {
    RecommendationService.dismissRecommendation(
      recommendation.id,
      session.patientId,
      'patient-app-feed'
    );
    setRecommendations(prev => prev.filter(r => r.id !== recommendation.id));
  };

  const handleClick = (recommendation) => {
    RecommendationService.trackEvent(
      recommendation.id,
      session.patientId,
      'click',
      'patient-app-feed',
      { source: 'patient-app' }
    );

    // Open CTA URL if available
    if (recommendation.ctaUrl) {
      window.open(recommendation.ctaUrl, '_blank');
    }
  };

  const handleToggleFavorite = (recommendation) => {
    const newFavorites = favorites.includes(recommendation.id)
      ? favorites.filter(id => id !== recommendation.id)
      : [...favorites, recommendation.id];
    
    setFavorites(newFavorites);
    localStorage.setItem(`patient_favorites_${session.patientId}`, JSON.stringify(newFavorites));
  };

  const handleShare = (recommendation) => {
    if (navigator.share) {
      navigator.share({
        title: recommendation.title,
        text: recommendation.description,
        url: recommendation.ctaUrl || window.location.href
      });
    } else {
      alert('Share link copied to clipboard!');
    }
  };

  if (loading) {
    return (
      <PatientAppLayout>
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </PatientAppLayout>
    );
  }

  return (
    <PatientAppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 mb-3">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">For You</h1>
          <p className="text-gray-600 mt-1">Personalized recommendations</p>
        </div>

        {/* Recommendations Grid */}
        {recommendations.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-sm p-12 text-center">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-100 to-pink-100 mx-auto mb-4 flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-purple-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Recommendations Yet</h3>
            <p className="text-gray-600">Check back after your exam for personalized suggestions</p>
          </div>
        ) : (
          <div className="space-y-4">
            {recommendations.map((rec) => {
              const isFavorite = favorites.includes(rec.id);
              
              return (
                <div 
                  key={rec.id}
                  className="bg-white rounded-2xl shadow-sm overflow-hidden hover:shadow-md transition-all"
                >
                  {/* Recommendation Content */}
                  <div className="p-6">
                    {/* Header */}
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className={`inline-flex px-2 py-1 rounded-full text-xs font-medium mb-2 ${
                          rec.type === 'product' ? 'bg-blue-100 text-blue-700' :
                          rec.type === 'service' ? 'bg-purple-100 text-purple-700' :
                          'bg-pink-100 text-pink-700'
                        }`}>
                          {rec.type}
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-2">
                          {rec.title}
                        </h3>
                        <p className="text-gray-600 leading-relaxed">
                          {rec.description}
                        </p>
                      </div>
                      <button
                        onClick={() => handleDismiss(rec)}
                        className="ml-2 p-1 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100 transition-colors"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Media */}
                    {rec.mediaContent && rec.mediaType === 'image' && (
                      <div className="mb-4 rounded-xl overflow-hidden bg-gray-100">
                        <img 
                          src={rec.mediaContent} 
                          alt={rec.title}
                          className="w-full h-48 object-cover"
                          onError={(e) => e.target.style.display = 'none'}
                        />
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex items-center gap-2 mt-4">
                      <button
                        onClick={() => handleClick(rec)}
                        className="flex-1 py-3 px-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all shadow-sm flex items-center justify-center gap-2"
                      >
                        <ShoppingCart className="w-4 h-4" />
                        {rec.ctaText || 'Learn More'}
                      </button>
                      <button
                        onClick={() => handleToggleFavorite(rec)}
                        className={`p-3 rounded-xl border-2 transition-all ${
                          isFavorite 
                            ? 'bg-pink-50 border-pink-200 text-pink-600' 
                            : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300'
                        }`}
                      >
                        <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
                      </button>
                      <button
                        onClick={() => handleShare(rec)}
                        className="p-3 rounded-xl border-2 border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50 transition-all"
                      >
                        <Share2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>

                  {/* Priority Badge */}
                  {rec.priority >= 80 && (
                    <div className="px-6 py-2 bg-gradient-to-r from-yellow-50 to-orange-50 border-t border-yellow-100">
                      <div className="text-xs font-medium text-yellow-800 flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        Highly Recommended
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Info Notice */}
        <div className="bg-purple-50 rounded-xl p-4 flex items-start gap-3">
          <Sparkles className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-purple-900">
            <div className="font-semibold mb-1">Personalized for You</div>
            <div className="text-purple-700">
              These recommendations are based on your age, lifestyle, and visit history. Swipe to dismiss or tap the heart to save favorites.
            </div>
          </div>
        </div>
      </div>
    </PatientAppLayout>
  );
}
