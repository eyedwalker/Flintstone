/**
 * Patient Rx Page
 * View prescription details with educational tooltips
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FileText, 
  Download, 
  Share2, 
  Eye,
  Info,
  Calendar,
  AlertCircle,
  CheckCircle,
  QrCode
} from 'lucide-react';
import { PatientAppService } from '../../lib/services/patient-app-service';
import { EyefinityService } from '../../services/eyefinityService';
import PatientAppLayout from '../layouts/PatientAppLayout';

export default function PatientRx() {
  const navigate = useNavigate();
  const [session, setSession] = useState(null);
  const [rxData, setRxData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showEducation, setShowEducation] = useState(null);

  useEffect(() => {
    loadRx();
  }, []);

  const loadRx = async () => {
    const currentSession = PatientAppService.getCurrentSession();
    if (!currentSession) {
      navigate('/patient/login');
      return;
    }

    setSession(currentSession);

    try {
      const rx = await EyefinityService.getPatientRx(currentSession.patientId);
      setRxData(rx);
    } catch (error) {
      console.error('Error loading Rx:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'My Prescription',
        text: 'Here is my current prescription',
        url: window.location.href
      });
    } else {
      alert('Prescription details copied to clipboard!');
    }
  };

  const educationContent = {
    SPH: {
      title: 'Sphere (SPH)',
      description: 'Corrects nearsightedness (minus sign) or farsightedness (plus sign). Higher numbers mean stronger correction needed.',
      icon: Eye
    },
    CYL: {
      title: 'Cylinder (CYL)',
      description: 'Corrects astigmatism. The number indicates how much your cornea curves irregularly.',
      icon: Eye
    },
    AXIS: {
      title: 'Axis',
      description: 'The orientation of astigmatism correction, measured in degrees from 1 to 180.',
      icon: Eye
    },
    ADD: {
      title: 'Addition (ADD)',
      description: 'Extra magnifying power for reading, needed for bifocals or progressives. Usually increases with age.',
      icon: Eye
    },
    PD: {
      title: 'Pupillary Distance (PD)',
      description: 'Distance between your pupils in millimeters. Important for proper lens alignment.',
      icon: Eye
    }
  };

  if (loading) {
    return (
      <PatientAppLayout>
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </PatientAppLayout>
    );
  }

  if (!rxData || rxData.length === 0) {
    return (
      <PatientAppLayout>
        <div className="space-y-6">
          <h1 className="text-2xl font-bold text-gray-900">My Prescription</h1>
          <div className="bg-white rounded-2xl shadow-sm p-12 text-center">
            <div className="w-16 h-16 rounded-full bg-gray-100 mx-auto mb-4 flex items-center justify-center">
              <FileText className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Prescription Yet</h3>
            <p className="text-gray-600">Your prescription will appear here after your exam</p>
          </div>
        </div>
      </PatientAppLayout>
    );
  }

  const latestRx = rxData[0];
  const rxDate = new Date(latestRx.examDate || latestRx.date);
  const expiryDate = new Date(rxDate);
  expiryDate.setFullYear(expiryDate.getFullYear() + 1);
  const daysUntilExpiry = Math.floor((expiryDate - new Date()) / (1000 * 60 * 60 * 24));
  const isExpiringSoon = daysUntilExpiry < 90;

  return (
    <PatientAppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Prescription</h1>
          <p className="text-gray-600 mt-1">Current eyeglass prescription</p>
        </div>

        {/* Expiry Warning */}
        {isExpiringSoon && (
          <div className={`rounded-xl p-4 flex items-start gap-3 ${
            daysUntilExpiry < 0 ? 'bg-red-50' : 'bg-yellow-50'
          }`}>
            <AlertCircle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
              daysUntilExpiry < 0 ? 'text-red-600' : 'text-yellow-600'
            }`} />
            <div className={`text-sm ${
              daysUntilExpiry < 0 ? 'text-red-900' : 'text-yellow-900'
            }`}>
              <div className="font-semibold mb-1">
                {daysUntilExpiry < 0 ? 'Prescription Expired' : 'Expiring Soon'}
              </div>
              <div className={daysUntilExpiry < 0 ? 'text-red-700' : 'text-yellow-700'}>
                {daysUntilExpiry < 0 
                  ? 'Your prescription has expired. Schedule an exam to renew it.'
                  : `Expires in ${daysUntilExpiry} days. Consider scheduling your next exam.`
                }
              </div>
            </div>
          </div>
        )}

        {/* Rx Details Card */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-6 text-white">
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="text-sm opacity-90 mb-1">Last Updated</div>
                <div className="text-2xl font-bold">{rxDate.toLocaleDateString()}</div>
              </div>
              <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                daysUntilExpiry < 0 ? 'bg-red-500' :
                isExpiringSoon ? 'bg-yellow-500' :
                'bg-green-500'
              }`}>
                {daysUntilExpiry < 0 ? 'Expired' :
                 isExpiringSoon ? 'Expiring Soon' :
                 'Valid'}
              </div>
            </div>
            <div className="text-sm opacity-75">
              Expires: {expiryDate.toLocaleDateString()}
            </div>
          </div>

          {/* Prescription Table */}
          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-2 text-sm font-semibold text-gray-600">Eye</th>
                    <th className="text-center py-3 px-2 text-sm font-semibold text-gray-600">
                      <button 
                        onClick={() => setShowEducation(showEducation === 'SPH' ? null : 'SPH')}
                        className="flex items-center gap-1 hover:text-blue-600"
                      >
                        SPH <Info className="w-3 h-3" />
                      </button>
                    </th>
                    <th className="text-center py-3 px-2 text-sm font-semibold text-gray-600">
                      <button 
                        onClick={() => setShowEducation(showEducation === 'CYL' ? null : 'CYL')}
                        className="flex items-center gap-1 hover:text-blue-600"
                      >
                        CYL <Info className="w-3 h-3" />
                      </button>
                    </th>
                    <th className="text-center py-3 px-2 text-sm font-semibold text-gray-600">
                      <button 
                        onClick={() => setShowEducation(showEducation === 'AXIS' ? null : 'AXIS')}
                        className="flex items-center gap-1 hover:text-blue-600"
                      >
                        AXIS <Info className="w-3 h-3" />
                      </button>
                    </th>
                    <th className="text-center py-3 px-2 text-sm font-semibold text-gray-600">
                      <button 
                        onClick={() => setShowEducation(showEducation === 'ADD' ? null : 'ADD')}
                        className="flex items-center gap-1 hover:text-blue-600"
                      >
                        ADD <Info className="w-3 h-3" />
                      </button>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-100">
                    <td className="py-4 px-2 font-semibold text-gray-900">OD (Right)</td>
                    <td className="py-4 px-2 text-center text-gray-900">{latestRx.odSphere || '-'}</td>
                    <td className="py-4 px-2 text-center text-gray-900">{latestRx.odCylinder || '-'}</td>
                    <td className="py-4 px-2 text-center text-gray-900">{latestRx.odAxis || '-'}</td>
                    <td className="py-4 px-2 text-center text-gray-900">{latestRx.odAdd || '-'}</td>
                  </tr>
                  <tr>
                    <td className="py-4 px-2 font-semibold text-gray-900">OS (Left)</td>
                    <td className="py-4 px-2 text-center text-gray-900">{latestRx.osSphere || '-'}</td>
                    <td className="py-4 px-2 text-center text-gray-900">{latestRx.osCylinder || '-'}</td>
                    <td className="py-4 px-2 text-center text-gray-900">{latestRx.osAxis || '-'}</td>
                    <td className="py-4 px-2 text-center text-gray-900">{latestRx.osAdd || '-'}</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* PD */}
            {latestRx.pd && (
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <button 
                  onClick={() => setShowEducation(showEducation === 'PD' ? null : 'PD')}
                  className="flex items-center gap-2 text-sm font-semibold text-blue-900 hover:text-blue-700"
                >
                  <Eye className="w-4 h-4" />
                  Pupillary Distance (PD): {latestRx.pd} mm
                  <Info className="w-3 h-3" />
                </button>
              </div>
            )}

            {/* Education Tooltip */}
            {showEducation && educationContent[showEducation] && (
              <div className="mt-4 p-4 bg-purple-50 rounded-lg border border-purple-200">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                    <Info className="w-4 h-4 text-purple-600" />
                  </div>
                  <div>
                    <div className="font-semibold text-purple-900 mb-1">
                      {educationContent[showEducation].title}
                    </div>
                    <div className="text-sm text-purple-700">
                      {educationContent[showEducation].description}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => window.print()}
            className="py-3 px-4 bg-white border-2 border-gray-200 text-gray-700 font-semibold rounded-xl hover:border-gray-300 hover:shadow-md transition-all flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            Download
          </button>
          <button
            onClick={handleShare}
            className="py-3 px-4 bg-white border-2 border-gray-200 text-gray-700 font-semibold rounded-xl hover:border-gray-300 hover:shadow-md transition-all flex items-center justify-center gap-2"
          >
            <Share2 className="w-4 h-4" />
            Share
          </button>
        </div>

        {/* History */}
        {rxData.length > 1 && (
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Prescription History
            </h2>
            <div className="space-y-2">
              {rxData.slice(1, 6).map((rx, index) => {
                const date = new Date(rx.examDate || rx.date);
                return (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <div className="font-medium text-gray-900">{date.toLocaleDateString()}</div>
                      <div className="text-sm text-gray-600">
                        OD: {rx.odSphere} / OS: {rx.osSphere}
                      </div>
                    </div>
                    <CheckCircle className="w-5 h-5 text-gray-400" />
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Info Notice */}
        <div className="bg-blue-50 rounded-xl p-4 flex items-start gap-3">
          <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-blue-900">
            <div className="font-semibold mb-1">About Your Prescription</div>
            <div className="text-blue-700">
              Prescriptions are typically valid for 1-2 years. Tap any column header to learn what the values mean.
            </div>
          </div>
        </div>
      </div>
    </PatientAppLayout>
  );
}
