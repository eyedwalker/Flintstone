/**
 * Patient Billing Page
 * View invoices, receipts, and make payments (Apple Pay, Google Pay, Credit Card)
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  CreditCard, 
  Download, 
  CheckCircle, 
  AlertCircle,
  Clock,
  ChevronRight,
  ArrowLeft,
  Apple,
  Smartphone,
  Loader2
} from 'lucide-react';
import { PatientAppService } from '../../lib/services/patient-app-service';
import PatientAppLayout from '../layouts/PatientAppLayout';

export default function PatientBilling() {
  const navigate = useNavigate();
  const [session, setSession] = useState(null);
  const [invoices, setInvoices] = useState([]);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [loading, setLoading] = useState(true);
  const [paymentMode, setPaymentMode] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState(null);
  const [processingPayment, setProcessingPayment] = useState(false);

  useEffect(() => {
    loadBilling();
  }, []);

  const loadBilling = async () => {
    const currentSession = PatientAppService.getCurrentSession();
    if (!currentSession) {
      navigate('/patient/login');
      return;
    }

    setSession(currentSession);
    const patientInvoices = await PatientAppService.getInvoices(currentSession.patientId);
    setInvoices(patientInvoices);
    setLoading(false);
  };

  const handleSelectInvoice = (invoice) => {
    setSelectedInvoice(invoice);
    setPaymentMode(false);
    setPaymentMethod(null);
  };

  const handleInitiatePayment = (invoice) => {
    setSelectedInvoice(invoice);
    setPaymentMode(true);
  };

  const handlePayment = async (method) => {
    if (!selectedInvoice) return;

    setPaymentMethod(method);
    setProcessingPayment(true);

    try {
      // Create payment intent
      const paymentIntent = await PatientAppService.createPaymentIntent(
        selectedInvoice.id,
        selectedInvoice.amountDue,
        session.patientId
      );

      // In production, this would integrate with Stripe SDK
      // For demo, simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Record payment
      const payment = await PatientAppService.recordPayment(
        selectedInvoice.id,
        session.patientId,
        {
          paymentDate: new Date(),
          amount: selectedInvoice.amountDue,
          method: method,
          lastFour: method === 'credit_card' ? '4242' : undefined,
          transactionId: paymentIntent.id,
          status: 'completed'
        }
      );

      // Show success and reload
      alert('Payment successful! Receipt sent to your email.');
      await loadBilling();
      setPaymentMode(false);
      setSelectedInvoice(null);
    } catch (error) {
      console.error('Payment failed:', error);
      alert('Payment failed. Please try again.');
    } finally {
      setProcessingPayment(false);
    }
  };

  const handleDownloadReceipt = (invoice) => {
    // In production, would download actual PDF
    const payment = invoice.payments[invoice.payments.length - 1];
    if (payment) {
      const receiptUrl = PatientAppService.generateReceipt(invoice, payment);
      window.open(receiptUrl, '_blank');
    }
  };

  if (loading) {
    return (
      <PatientAppLayout>
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </PatientAppLayout>
    );
  }

  // Invoice Detail View
  if (selectedInvoice && !paymentMode) {
    return (
      <PatientAppLayout>
        <div className="space-y-6">
          {/* Header */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSelectedInvoice(null)}
              className="p-2 hover:bg-white rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <h1 className="text-2xl font-bold text-gray-900">Invoice Details</h1>
          </div>

          {/* Invoice Info Card */}
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="text-sm text-gray-500">Invoice Number</div>
                <div className="text-xl font-bold text-gray-900">{selectedInvoice.invoiceNumber}</div>
                <div className="text-sm text-gray-500 mt-1">
                  {selectedInvoice.invoiceDate.toLocaleDateString()}
                </div>
              </div>
              <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                selectedInvoice.status === 'paid' ? 'bg-green-100 text-green-700' :
                selectedInvoice.status === 'partial' ? 'bg-yellow-100 text-yellow-700' :
                'bg-red-100 text-red-700'
              }`}>
                {selectedInvoice.status === 'paid' ? '✓ Paid' :
                 selectedInvoice.status === 'partial' ? 'Partially Paid' :
                 'Outstanding'}
              </div>
            </div>

            {/* Items */}
            <div className="border-t border-gray-200 pt-4">
              <div className="text-sm font-semibold text-gray-900 mb-3">Services & Products</div>
              <div className="space-y-3">
                {selectedInvoice.items.map((item) => (
                  <div key={item.id} className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{item.description}</div>
                      <div className="text-sm text-gray-500">Qty: {item.quantity}</div>
                    </div>
                    <div className="font-semibold text-gray-900">
                      ${item.totalPrice.toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Totals */}
            <div className="border-t border-gray-200 mt-6 pt-4 space-y-2">
              <div className="flex items-center justify-between text-gray-600">
                <span>Subtotal</span>
                <span>${selectedInvoice.totalAmount.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between text-green-600">
                <span>Paid</span>
                <span>-${selectedInvoice.amountPaid.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between text-xl font-bold text-gray-900 pt-2 border-t">
                <span>Amount Due</span>
                <span>${selectedInvoice.amountDue.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          {selectedInvoice.amountDue > 0 && (
            <button
              onClick={() => handleInitiatePayment(selectedInvoice)}
              className="w-full py-4 px-6 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg"
            >
              Pay ${selectedInvoice.amountDue.toFixed(2)} Now
            </button>
          )}

          {selectedInvoice.payments.length > 0 && (
            <button
              onClick={() => handleDownloadReceipt(selectedInvoice)}
              className="w-full py-4 px-6 bg-white border-2 border-gray-200 text-gray-700 font-semibold rounded-xl hover:border-gray-300 hover:shadow-md transition-all flex items-center justify-center gap-2"
            >
              <Download className="w-5 h-5" />
              Download Receipt
            </button>
          )}
        </div>
      </PatientAppLayout>
    );
  }

  // Payment Method Selection
  if (paymentMode && selectedInvoice) {
    return (
      <PatientAppLayout>
        <div className="space-y-6">
          {/* Header */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setPaymentMode(false)}
              className="p-2 hover:bg-white rounded-lg transition-colors"
              disabled={processingPayment}
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <h1 className="text-2xl font-bold text-gray-900">Select Payment Method</h1>
          </div>

          {/* Amount Card */}
          <div className="bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl p-6 text-white">
            <div className="text-sm opacity-90 mb-2">Amount to Pay</div>
            <div className="text-4xl font-bold">${selectedInvoice.amountDue.toFixed(2)}</div>
            <div className="text-sm opacity-75 mt-2">Invoice #{selectedInvoice.invoiceNumber}</div>
          </div>

          {/* Payment Methods */}
          <div className="space-y-3">
            {/* Apple Pay */}
            <button
              onClick={() => handlePayment('apple_pay')}
              disabled={processingPayment}
              className="w-full p-6 bg-white rounded-xl border-2 border-gray-200 hover:border-blue-300 hover:shadow-md transition-all text-left flex items-center gap-4 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <div className="w-12 h-12 rounded-full bg-black flex items-center justify-center">
                <Apple className="w-7 h-7 text-white" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-gray-900">Apple Pay</div>
                <div className="text-sm text-gray-500">Touch ID • Face ID</div>
              </div>
              {processingPayment && paymentMethod === 'apple_pay' ? (
                <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
              ) : (
                <ChevronRight className="w-5 h-5 text-gray-400" />
              )}
            </button>

            {/* Google Pay */}
            <button
              onClick={() => handlePayment('google_pay')}
              disabled={processingPayment}
              className="w-full p-6 bg-white rounded-xl border-2 border-gray-200 hover:border-blue-300 hover:shadow-md transition-all text-left flex items-center gap-4 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-green-500 flex items-center justify-center">
                <Smartphone className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-gray-900">Google Pay</div>
                <div className="text-sm text-gray-500">Fast & Secure</div>
              </div>
              {processingPayment && paymentMethod === 'google_pay' ? (
                <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
              ) : (
                <ChevronRight className="w-5 h-5 text-gray-400" />
              )}
            </button>

            {/* Credit Card */}
            <button
              onClick={() => handlePayment('credit_card')}
              disabled={processingPayment}
              className="w-full p-6 bg-white rounded-xl border-2 border-gray-200 hover:border-blue-300 hover:shadow-md transition-all text-left flex items-center gap-4 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-gray-900">Credit / Debit Card</div>
                <div className="text-sm text-gray-500">Visa • Mastercard • Amex</div>
              </div>
              {processingPayment && paymentMethod === 'credit_card' ? (
                <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
              ) : (
                <ChevronRight className="w-5 h-5 text-gray-400" />
              )}
            </button>
          </div>

          {/* Security Notice */}
          <div className="bg-blue-50 rounded-xl p-4 flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-blue-900">
              <div className="font-semibold mb-1">Secure Payment</div>
              <div className="text-blue-700">
                Your payment is encrypted and processed securely. We never store your card details.
              </div>
            </div>
          </div>
        </div>
      </PatientAppLayout>
    );
  }

  // Invoice List View
  return (
    <PatientAppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Billing & Payments</h1>
          <p className="text-gray-600 mt-1">View invoices and manage payments</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="text-sm text-gray-600 mb-1">Total Balance</div>
            <div className="text-2xl font-bold text-gray-900">
              ${invoices.reduce((sum, inv) => sum + inv.amountDue, 0).toFixed(2)}
            </div>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="text-sm text-gray-600 mb-1">Outstanding</div>
            <div className="text-2xl font-bold text-orange-600">
              {invoices.filter(inv => inv.status !== 'paid').length}
            </div>
          </div>
        </div>

        {/* Invoices List */}
        {invoices.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-sm p-12 text-center">
            <div className="w-16 h-16 rounded-full bg-gray-100 mx-auto mb-4 flex items-center justify-center">
              <CreditCard className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Invoices Yet</h3>
            <p className="text-gray-600">Your billing history will appear here</p>
          </div>
        ) : (
          <div className="space-y-3">
            {invoices.map((invoice) => {
              const statusConfig = {
                paid: { icon: CheckCircle, color: 'green', label: 'Paid' },
                partial: { icon: Clock, color: 'yellow', label: 'Partial' },
                pending: { icon: AlertCircle, color: 'red', label: 'Due' },
                overdue: { icon: AlertCircle, color: 'red', label: 'Overdue' }
              };
              const status = statusConfig[invoice.status];
              const StatusIcon = status.icon;

              return (
                <button
                  key={invoice.id}
                  onClick={() => handleSelectInvoice(invoice)}
                  className="w-full bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-all text-left"
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-full bg-${status.color}-100 flex items-center justify-center flex-shrink-0`}>
                      <StatusIcon className={`w-5 h-5 text-${status.color}-600`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-gray-900">
                        Invoice #{invoice.invoiceNumber}
                      </div>
                      <div className="text-sm text-gray-500 mt-0.5">
                        {invoice.invoiceDate.toLocaleDateString()}
                      </div>
                      <div className="text-sm text-gray-600 mt-1">
                        {invoice.items.length} item{invoice.items.length !== 1 ? 's' : ''}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-gray-900">
                        ${invoice.amountDue.toFixed(2)}
                      </div>
                      <div className={`text-xs font-medium text-${status.color}-600 mt-1`}>
                        {status.label}
                      </div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </PatientAppLayout>
  );
}
