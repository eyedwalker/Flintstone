/**
 * Patient App Layout
 * Mobile-first responsive layout for patient-facing app
 */

import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  Home, 
  Clock, 
  FileText, 
  CreditCard, 
  MessageSquare,
  User,
  LogOut,
  Sparkles
} from 'lucide-react';
import { PatientAppService } from '../../lib/services/patient-app-service';

export default function PatientAppLayout({ children }) {
  const navigate = useNavigate();
  const session = PatientAppService.getCurrentSession();

  const handleLogout = () => {
    PatientAppService.logout();
    navigate('/patient/login');
  };

  if (!session) {
    navigate('/patient/login');
    return null;
  }

  const navItems = [
    { path: '/patient/dashboard', icon: Home, label: 'Home' },
    { path: '/patient/wait', icon: Clock, label: 'Wait Time' },
    { path: '/patient/rx', icon: FileText, label: 'My Rx' },
    { path: '/patient/billing', icon: CreditCard, label: 'Billing' },
    { path: '/patient/recommendations', icon: Sparkles, label: 'For You' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-semibold text-gray-900">{session.patientName}</div>
                <div className="text-xs text-gray-500">MyEyeCare Journey</div>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              title="Logout"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-6 pb-24">
        {children}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
        <div className="max-w-7xl mx-auto px-2">
          <div className="flex items-center justify-around py-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    `flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all ${
                      isActive
                        ? 'text-blue-600 bg-blue-50'
                        : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                    }`
                  }
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-xs font-medium">{item.label}</span>
                </NavLink>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
