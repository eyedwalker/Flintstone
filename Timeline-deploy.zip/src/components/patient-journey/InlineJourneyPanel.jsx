/**
 * InlineJourneyPanel
 * Compact, collapsible journey management panel for embedding in the PRC right panel.
 * Shows journey steps, room assignment, and action buttons inline.
 */

import React, { useState, useMemo, useEffect } from 'react';
import {
  ChevronDown, ChevronUp, CheckCircle, Circle, Play,
  SkipForward, Clock, MapPin, ArrowRight, XCircle
} from 'lucide-react';
import { OfficeRoomsService } from '../../lib/services/office-rooms-service';
import { RoomWorkflowService } from '../../lib/services/room-workflow-service';

const PHASE_CONFIG = {
  'pre-visit': { label: 'Pre-Visit', color: 'bg-blue-100 text-blue-800' },
  'in-office': { label: 'In Office', color: 'bg-green-100 text-green-800' },
  'post-visit': { label: 'Post-Visit', color: 'bg-purple-100 text-purple-800' },
  'completed': { label: 'Complete', color: 'bg-gray-100 text-gray-600' },
};

const STEP_STATUS_ICON = {
  completed: <CheckCircle size={14} className="text-green-500" />,
  'in-progress': <Play size={14} className="text-blue-500 fill-blue-500" />,
  pending: <Circle size={14} className="text-gray-300" />,
  skipped: <SkipForward size={14} className="text-gray-400" />,
  cancelled: <XCircle size={14} className="text-red-400" />,
};

function formatDuration(minutes) {
  if (!minutes || minutes < 1) return '<1m';
  if (minutes < 60) return `${Math.round(minutes)}m`;
  const h = Math.floor(minutes / 60);
  const m = Math.round(minutes % 60);
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

function getElapsedMinutes(startTime) {
  if (!startTime) return 0;
  const start = new Date(startTime);
  return (Date.now() - start.getTime()) / 60000;
}

export default function InlineJourneyPanel({
  journey,
  officeId,
  rooms = [],
  onStepAction,
  onAssignRoom,
  onTransitionPhase,
  collapsed = false,
  onToggleCollapse,
}) {
  const [showRoomDropdown, setShowRoomDropdown] = useState(false);
  const [elapsed, setElapsed] = useState(0);

  const currentStep = journey.steps?.find(s => s.id === journey.currentStepId);
  const currentRoom = rooms.find(r => r.currentJourneyId === journey.id);
  const phaseConfig = PHASE_CONFIG[journey.journeyPhase] || PHASE_CONFIG['in-office'];

  // Count steps for progress
  const inOfficeSteps = journey.steps?.filter(s => s.stepType === 'in-office') || [];
  const completedSteps = inOfficeSteps.filter(s => s.status === 'completed' || s.status === 'skipped').length;
  const totalSteps = inOfficeSteps.length;
  const progressPct = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0;

  // Available rooms sorted by workflow preference
  const sortedAvailableRooms = useMemo(() => {
    const available = rooms.filter(r => r.isActive && r.status === 'available');
    if (!currentStep) return available;

    const preferred = RoomWorkflowService.getPreferredRoomForStep(currentStep.id);
    return [...available].sort((a, b) => {
      const aP = preferred.includes(a.type) ? 0 : 1;
      const bP = preferred.includes(b.type) ? 0 : 1;
      return aP - bP;
    });
  }, [rooms, currentStep]);

  // Update elapsed timer for current step
  useEffect(() => {
    if (!currentStep || currentStep.status !== 'in-progress' || !currentStep.startTime) return;

    const update = () => setElapsed(getElapsedMinutes(currentStep.startTime));
    update();
    const interval = setInterval(update, 30000);
    return () => clearInterval(interval);
  }, [currentStep?.id, currentStep?.status, currentStep?.startTime]);

  const handleCompleteAndMove = () => {
    if (!currentStep) return;
    onStepAction(journey.id, currentStep.id, 'complete');

    // If there's a current room, suggest next room
    if (currentRoom) {
      const availableRooms = rooms.filter(r => r.status === 'available' && r.isActive);
      const nextRoom = RoomWorkflowService.findBestNextRoom(currentRoom.type, availableRooms, journey);
      if (nextRoom) {
        // Auto-assign to suggested next room
        onAssignRoom(journey.id, nextRoom.id);
      }
    }
  };

  if (collapsed) {
    return (
      <div
        id="prc-inline-journey"
        className="border border-gray-200 rounded-lg bg-white cursor-pointer hover:bg-gray-50 transition-colors"
        onClick={onToggleCollapse}
      >
        <div className="px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ChevronDown size={16} className="text-gray-400" />
            <span className="text-sm font-medium text-gray-700">Patient Journey</span>
            <span className={`text-xs px-2 py-0.5 rounded-full ${phaseConfig.color}`}>
              {phaseConfig.label}
            </span>
          </div>
          <div className="flex items-center gap-3">
            {currentRoom && (
              <span className="text-xs text-gray-500 flex items-center gap-1">
                <MapPin size={12} /> {currentRoom.shortName || currentRoom.name}
              </span>
            )}
            <span className="text-xs text-gray-500">{completedSteps}/{totalSteps} steps</span>
            <div className="w-16 h-1.5 bg-gray-200 rounded-full overflow-hidden">
              <div className="h-full bg-blue-500 rounded-full transition-all" style={{ width: `${progressPct}%` }} />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div id="prc-inline-journey" className="border border-gray-200 rounded-lg bg-white">
      {/* Header */}
      <div
        className="px-4 py-3 flex items-center justify-between border-b border-gray-100 cursor-pointer hover:bg-gray-50"
        onClick={onToggleCollapse}
      >
        <div className="flex items-center gap-3">
          <ChevronUp size={16} className="text-gray-400" />
          <span className="text-sm font-medium text-gray-700">Patient Journey</span>
          <span className={`text-xs px-2 py-0.5 rounded-full ${phaseConfig.color}`}>
            {phaseConfig.label}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-gray-500">{completedSteps}/{totalSteps} steps</span>
          <div className="w-20 h-1.5 bg-gray-200 rounded-full overflow-hidden">
            <div className="h-full bg-blue-500 rounded-full transition-all" style={{ width: `${progressPct}%` }} />
          </div>
          <span className="text-xs font-medium text-gray-600">{progressPct}%</span>
        </div>
      </div>

      {/* Room Assignment */}
      <div className="px-4 py-2 border-b border-gray-100 flex items-center justify-between bg-gray-50">
        <div className="flex items-center gap-2">
          <MapPin size={14} className="text-gray-400" />
          <span className="text-xs text-gray-600">
            {currentRoom ? (
              <span className="font-medium text-gray-800">{currentRoom.shortName || currentRoom.name}</span>
            ) : (
              <span className="text-gray-400 italic">No room assigned</span>
            )}
          </span>
          {currentRoom?.occupiedSince && (
            <span className="text-xs text-gray-400 ml-1">
              ({formatDuration(getElapsedMinutes(currentRoom.occupiedSince))})
            </span>
          )}
        </div>
        <div className="relative">
          <button
            onClick={(e) => { e.stopPropagation(); setShowRoomDropdown(!showRoomDropdown); }}
            className="text-xs px-2 py-1 rounded bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors"
          >
            {currentRoom ? 'Change Room' : 'Assign Room'}
          </button>
          {showRoomDropdown && (
            <div className="absolute right-0 top-full mt-1 z-20 w-48 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto">
              {sortedAvailableRooms.length === 0 ? (
                <div className="px-3 py-2 text-xs text-gray-400">No rooms available</div>
              ) : (
                sortedAvailableRooms.map(room => {
                  const preferred = currentStep
                    ? RoomWorkflowService.getPreferredRoomForStep(currentStep.id)
                    : [];
                  const isPreferred = preferred.includes(room.type);
                  return (
                    <button
                      key={room.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        onAssignRoom(journey.id, room.id);
                        setShowRoomDropdown(false);
                      }}
                      className="w-full px-3 py-2 text-left text-xs hover:bg-blue-50 flex items-center justify-between"
                    >
                      <span className={isPreferred ? 'font-medium text-blue-700' : 'text-gray-700'}>
                        {room.shortName || room.name}
                      </span>
                      {isPreferred && (
                        <span className="text-[10px] text-blue-500 bg-blue-50 px-1 rounded">Recommended</span>
                      )}
                    </button>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>

      {/* Steps List */}
      <div className="px-4 py-2 space-y-1">
        {(journey.steps || [])
          .filter(s => s.stepType === 'in-office')
          .map(step => {
            const isActive = step.id === journey.currentStepId;
            const stepElapsed = step.status === 'in-progress' && step.startTime
              ? getElapsedMinutes(step.startTime)
              : step.duration;

            return (
              <div
                key={step.id}
                className={`flex items-center justify-between py-1.5 px-2 rounded ${
                  isActive ? 'bg-blue-50' : ''
                }`}
              >
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  {STEP_STATUS_ICON[step.status] || STEP_STATUS_ICON.pending}
                  <span className={`text-xs truncate ${
                    step.status === 'completed' ? 'text-gray-400 line-through' :
                    step.status === 'skipped' ? 'text-gray-400' :
                    isActive ? 'text-blue-700 font-medium' : 'text-gray-600'
                  }`}>
                    {step.title}
                  </span>
                </div>
                <div className="flex items-center gap-2 ml-2 flex-shrink-0">
                  {stepElapsed != null && stepElapsed > 0 && (
                    <span className="text-[10px] text-gray-400 flex items-center gap-0.5">
                      <Clock size={10} /> {formatDuration(stepElapsed)}
                    </span>
                  )}
                  {step.status === 'pending' && isActive && (
                    <button
                      onClick={() => onStepAction(journey.id, step.id, 'start')}
                      className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500 text-white hover:bg-blue-600"
                    >
                      Start
                    </button>
                  )}
                  {step.status === 'in-progress' && (
                    <>
                      <button
                        onClick={() => onStepAction(journey.id, step.id, 'complete')}
                        className="text-[10px] px-1.5 py-0.5 rounded bg-green-500 text-white hover:bg-green-600"
                      >
                        Done
                      </button>
                      <button
                        onClick={() => onStepAction(journey.id, step.id, 'skip')}
                        className="text-[10px] px-1.5 py-0.5 rounded bg-gray-200 text-gray-600 hover:bg-gray-300"
                      >
                        Skip
                      </button>
                    </>
                  )}
                  {step.status === 'pending' && !isActive && (
                    <button
                      onClick={() => onStepAction(journey.id, step.id, 'start')}
                      className="text-[10px] px-1.5 py-0.5 rounded bg-gray-100 text-gray-500 hover:bg-gray-200"
                    >
                      Start
                    </button>
                  )}
                </div>
              </div>
            );
          })}
      </div>

      {/* Action Bar */}
      <div className="px-4 py-3 border-t border-gray-100 flex items-center gap-2">
        {currentStep?.status === 'in-progress' && currentRoom && (
          <button
            onClick={handleCompleteAndMove}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-500 text-white text-xs font-medium hover:bg-blue-600 transition-colors"
          >
            <ArrowRight size={12} />
            Complete & Move to Next Room
          </button>
        )}
        {currentStep?.status === 'in-progress' && !currentRoom && (
          <button
            onClick={() => onStepAction(journey.id, currentStep.id, 'complete')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-500 text-white text-xs font-medium hover:bg-green-600 transition-colors"
          >
            <CheckCircle size={12} />
            Complete Step
          </button>
        )}
        {journey.journeyPhase === 'in-office' && completedSteps === totalSteps && totalSteps > 0 && (
          <button
            onClick={() => onTransitionPhase(journey.id, 'post-visit')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-500 text-white text-xs font-medium hover:bg-purple-600 transition-colors"
          >
            Checkout — Move to Post-Visit
          </button>
        )}
      </div>
    </div>
  );
}
