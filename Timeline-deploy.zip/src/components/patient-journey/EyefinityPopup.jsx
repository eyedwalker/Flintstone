/**
 * Encompass Popup Component
 * Displays an iframe with Encompass content and allows completing journey steps
 */

import React, { useState, useEffect } from 'react';
import { X, CheckCircle, ExternalLink } from 'lucide-react';

export default function EncompassPopup({ 
  url, 
  journey, 
  step, 
  onComplete, 
  onClose 
}) {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Reset loading state when URL changes
    setIsLoading(true);
  }, [url]);

  const handleIframeLoad = () => {
    setIsLoading(false);
  };

  const handleComplete = () => {
    if (onComplete) {
      onComplete(journey, step);
    }
  };

  const handleOpenInNewTab = () => {
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-6xl h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-4 border-b flex items-center justify-between bg-gray-50 rounded-t-xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <span className="text-purple-600 font-semibold text-sm">
                Encompass
              </span>
            </div>
            <div>
              <h2 className="text-lg font-semibold text-gray-900">
                {journey?.patientName || 'Patient'}: {step?.title || 'Journey Step'}
              </h2>
              <p className="text-sm text-gray-500">
                {step?.description || 'Complete this step in Encompass'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleOpenInNewTab}
              className="p-2 hover:bg-gray-100 rounded-lg text-gray-600"
              title="Open in new tab"
            >
              <ExternalLink size={20} />
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg text-gray-600"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Iframe Container */}
        <div className="flex-1 relative bg-gray-100">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-white">
              <div className="text-center">
                <div className="w-12 h-12 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-gray-600">Loading Encompass...</p>
              </div>
            </div>
          )}
          <iframe
            src={url}
            className="w-full h-full border-0"
            onLoad={handleIframeLoad}
            title="Encompass"
            sandbox="allow-same-origin allow-scripts allow-forms allow-popups"
          />
        </div>

        {/* Footer with Actions */}
        <div className="p-4 border-t bg-gray-50 flex items-center justify-between rounded-b-xl">
          <div className="text-sm text-gray-600">
            Once you're done in Encompass, click "Complete Step" to continue the patient journey.
          </div>
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100 text-gray-700"
            >
              Skip Step
            </button>
            <button
              onClick={handleComplete}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
            >
              <CheckCircle size={18} />
              Complete Step
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
