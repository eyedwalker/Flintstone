/**
 * Patient Journey Card
 * Displays a patient's journey progress in the board - TaskApp style
 */

import React from 'react';
import { 
  Clock, 
  AlertCircle,
  Calendar
} from 'lucide-react';

// Get patient initials from name
const getInitials = (name) => {
  if (!name) return '??';
  const parts = name.split(' ');
  if (parts.length >= 2) {
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }
  return name.slice(0, 2).toUpperCase();
};

// Format wait time
const formatWaitTime = (minutes) => {
  if (!minutes || minutes < 1) return '0m';
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${hours}h ${mins}m`;
};

// Format total time from check-in
const formatTotalTime = (checkInTime) => {
  if (!checkInTime) return '0m';
  const checkIn = new Date(checkInTime);
  const now = new Date();
  const totalMinutes = Math.floor((now - checkIn) / (1000 * 60));
  if (totalMinutes < 60) return `${totalMinutes}m`;
  const hours = Math.floor(totalMinutes / 60);
  const mins = totalMinutes % 60;
  return `${hours}h ${mins}m`;
};

export default function PatientJourneyCard({ 
  journey, 
  onClick, 
  onDoubleClick,
  isSelected,
  onStepAction,
  compact = false
}) {
  const initials = getInitials(journey.patientName);
  const waitTime = journey.waitTime || 0;
  const isWaitingLong = waitTime > 30; // More than 30 minutes = red
  const isWaitingMedium = waitTime > 15 && waitTime <= 30; // 15-30 min = orange
  const totalTime = formatTotalTime(journey.checkInTime);
  
  // Get progress color based on percentage
  const progressPercent = journey.progressPercentage || 0;
  const getProgressColor = () => {
    if (progressPercent < 25) return 'bg-red-400';
    if (progressPercent < 50) return 'bg-orange-400';
    if (progressPercent < 75) return 'bg-yellow-400';
    return 'bg-green-500';
  };

  if (compact) {
    // Compact card for board view - matches TaskApp style
    return (
      <div
        onClick={onClick}
        onDoubleClick={() => onDoubleClick && onDoubleClick(journey)}
        className={`
          p-3 bg-white rounded-lg border cursor-pointer transition-all
          ${isSelected ? 'ring-2 ring-purple-500 border-purple-500' : 'border-gray-200 hover:border-gray-300 hover:shadow-sm'}
        `}
      >
        {/* Patient Info Row */}
        <div className="flex items-start gap-3 mb-2">
          {/* Avatar with initials */}
          <div className="w-9 h-9 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-sm font-medium text-gray-600">{initials}</span>
          </div>
          
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-gray-900 text-sm truncate">{journey.patientName}</h3>
            <p className="text-xs text-gray-500 truncate">
              {journey.reasonForVisit || 'No reason specified'}
            </p>
          </div>
        </div>

        {/* Wait & Total Time Row */}
        <div className="flex items-center gap-3 text-xs mb-2">
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-gray-400" />
            <span className={`font-medium ${isWaitingLong ? 'text-red-600' : isWaitingMedium ? 'text-orange-500' : 'text-gray-600'}`}>
              Wait: {formatWaitTime(waitTime)}
            </span>
          </div>
          <div className="flex items-center gap-1 text-gray-500">
            <Calendar className="w-3 h-3" />
            <span>Total: {totalTime}</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
          <div 
            className={`h-full ${getProgressColor()} transition-all`}
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>
    );
  }

  // Full card (not currently used but kept for flexibility)
  return (
    <div
      onClick={onClick}
      className={`
        p-4 bg-white rounded-lg border cursor-pointer transition-all
        ${isSelected ? 'ring-2 ring-purple-500 border-purple-500' : 'border-gray-200 hover:border-gray-300 hover:shadow-sm'}
      `}
    >
      {/* Patient Info Row */}
      <div className="flex items-start gap-3 mb-3">
        <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
          <span className="text-sm font-semibold text-gray-600">{initials}</span>
        </div>
        
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-gray-900 truncate">{journey.patientName}</h3>
          <p className="text-sm text-gray-500 truncate">
            {journey.reasonForVisit || 'No reason specified'}
          </p>
        </div>
      </div>

      {/* Wait & Total Time Row */}
      <div className="flex items-center gap-4 text-sm mb-3">
        <div className="flex items-center gap-1.5">
          {isWaitingLong && <AlertCircle className="w-4 h-4 text-red-500" />}
          <Clock className="w-4 h-4 text-gray-400" />
          <span className={`font-medium ${isWaitingLong ? 'text-red-600' : isWaitingMedium ? 'text-orange-500' : 'text-gray-600'}`}>
            Wait: {formatWaitTime(waitTime)}
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-gray-500">
          <Calendar className="w-4 h-4" />
          <span>Total: {totalTime}</span>
        </div>
      </div>

      {/* Progress Bar */}
      <div>
        <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
          <span>Progress</span>
          <span>{progressPercent}%</span>
        </div>
        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
          <div 
            className={`h-full ${getProgressColor()} transition-all`}
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>
    </div>
  );
}
