/**
 * Patient Journey Board
 * Kanban-style board showing patients grouped by current step
 * Includes Board view and Wait Times table view
 */

import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePatientJourney } from '../../contexts/PatientJourneyContext';
import PatientJourneyCard from './PatientJourneyCard';
import PatientJourneyDetails from './PatientJourneyDetails';
import RoomConfiguration from '../rooms/RoomConfiguration';
import CheckoutTaskModal from '../tasks/CheckoutTaskModal';
import EncompassPopup from './EyefinityPopup';
import { OfficeRoomsService } from '../../lib/services/office-rooms-service';
import { ROOM_TYPE_CONFIG } from '../../lib/types/office-rooms';
import { RoomWorkflowService } from '../../lib/services/room-workflow-service';
import { taskManager, TASK_CATEGORY_CONFIG, TaskStatus } from '../../lib/services/task-management-service';
import { checkoutDetection } from '../../lib/services/checkout-detection-service';
import { buildUrlFromTemplate, extractContextFromJourney } from '../../lib/utils/url-builder';
import { getJourneyRulesService } from '../../lib/services/journey-rules-service';
import { AppointmentRoomService } from '../../lib/services/appointment-room-service';
import { 
  Clock, 
  Users,
  RefreshCw,
  Filter,
  Search,
  ChevronLeft,
  ChevronRight,
  Lock,
  LayoutGrid,
  Table2,
  DoorOpen,
  AlertTriangle,
  Settings,
  Eye,
  Activity,
  CreditCard,
  Circle,
  Glasses,
  Package,
  ArrowRight,
  UserPlus,
  LogOut,
  Edit,
  X,
  MoreVertical,
  Move,
  XCircle,
  CheckCircle,
  CalendarClock,
  Calendar,
  CheckSquare,
  Bot,
  Zap,
  Play,
  UserCircle,
  ExternalLink
} from 'lucide-react';

// Step colors for column headers
const STEP_COLORS = {
  'Complete Patient Forms': 'text-purple-700',
  'Confirm Appointment': 'text-gray-800',
  'Doctor Examination': 'text-gray-800',
  'Insurance Information': 'text-red-600',
  'Optical Consultation': 'text-gray-800',
  'Recall Reminder': 'text-purple-700',
  'default': 'text-gray-800'
};

// Phase badge colors
const PHASE_BADGES = {
  'pre-visit': { label: 'Pre-visit', bg: 'bg-purple-100', text: 'text-purple-700' },
  'in-office': { label: 'In office', bg: 'bg-green-100', text: 'text-green-700' },
  'post-visit': { label: 'Post visit', bg: 'bg-blue-100', text: 'text-blue-700' },
  'completed': { label: 'Completed', bg: 'bg-gray-100', text: 'text-gray-700' }
};

// Room icon map
const ROOM_ICONS = {
  waiting: Users,
  'pre-testing': Activity,
  'exam-room': Eye,
  dilation: Clock,
  optical: Glasses,
  'contact-lens': Circle,
  'doctor-office': Users,
  dispensary: Package,
  checkout: CreditCard,
  other: Circle,
};

export default function PatientJourneyBoard({ onCreateJourney, officeId = 'office-1' }) {
  const navigate = useNavigate();
  const { 
    journeys, 
    selectedJourney, 
    setSelectedJourney, 
    loading, 
    loadJourneys,
    startStep,
    completeStep,
    skipStep,
    transitionPhase
  } = usePatientJourney();

  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState('board'); // 'board' | 'waitTimes' | 'rooms'
  const [workflowView, setWorkflowView] = useState('all'); // 'all' | 'pre-visit' | 'in-office' | 'post-visit'
  const [detailsPanelWidth, setDetailsPanelWidth] = useState(480); // Wider default
  const [isResizing, setIsResizing] = useState(false);
  const [rooms, setRooms] = useState([]);
  const [roomConfig, setRoomConfig] = useState(null);
  const [draggedPatient, setDraggedPatient] = useState(null);
  const [showPatientActions, setShowPatientActions] = useState(null);
  const [showRoomConfig, setShowRoomConfig] = useState(false);
  const [showRoomActions, setShowRoomActions] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const [activeFilters, setActiveFilters] = useState({
    phase: 'all',
    priority: 'all',
    roomStatus: 'all',
    step: 'all'
  });
  const [showCheckoutTasks, setShowCheckoutTasks] = useState(false);
  const [checkoutPatient, setCheckoutPatient] = useState(null);
  const [checkoutJourney, setCheckoutJourney] = useState(null);
  const [encompassPopup, setEncompassPopup] = useState(null); // { journey, step, url }
  const [showPatientSelector, setShowPatientSelector] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [contextMenu, setContextMenu] = useState(null); // { x, y, room, journey }
  const [checkInReadyPatients, setCheckInReadyPatients] = useState([]);
  const [showAppointmentSelector, setShowAppointmentSelector] = useState(false);
  const [appointmentSearch, setAppointmentSearch] = useState('');
  const [searchStartDate, setSearchStartDate] = useState('');
  const [searchEndDate, setSearchEndDate] = useState('');
  const [isSearching, setIsSearching] = useState(false);

  // Handle panel resize
  const handleMouseDown = (e) => {
    e.preventDefault();
    setIsResizing(true);
  };

  useEffect(() => {
    const handleMouseMove = (e) => {
      if (!isResizing) return;
      const newWidth = window.innerWidth - e.clientX;
      // Constrain between 380px and 700px
      setDetailsPanelWidth(Math.min(700, Math.max(380, newWidth)));
    };

    const handleMouseUp = () => {
      setIsResizing(false);
    };

    if (isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isResizing]);

  // Load room configuration and appointments
  useEffect(() => {
    let config = OfficeRoomsService.getOfficeConfig(officeId);
    if (!config) {
      config = OfficeRoomsService.initializeOffice(officeId, 'Main Office', 'medium');
    }
    setRoomConfig(config);
    setRooms(config.rooms || []);
    
    // Load check-in ready patients from appointments
    loadCheckInReadyPatients();
  }, [officeId]);
  
  // Load patients ready for check-in from appointments
  const loadCheckInReadyPatients = async () => {
    try {
      const patients = await AppointmentRoomService.getPatientsReadyForCheckIn();
      setCheckInReadyPatients(patients);
      console.log('Loaded check-in ready patients:', patients.length, patients);
    } catch (error) {
      console.error('Error loading check-in ready patients:', error);
    }
  };
  
  // Search appointments by name or date range
  const handleAppointmentSearch = async () => {
    setIsSearching(true);
    try {
      const appointments = await AppointmentRoomService.searchAppointments(
        appointmentSearch,
        searchStartDate,
        searchEndDate
      );
      const patients = await AppointmentRoomService.convertAppointmentsToCheckInReady(appointments);
      setCheckInReadyPatients(patients);
      console.log('Search found:', patients.length, 'patients');
    } catch (error) {
      console.error('Error searching appointments:', error);
    } finally {
      setIsSearching(false);
    }
  };
  
  // Reset search and load today's appointments
  const handleResetSearch = () => {
    setAppointmentSearch('');
    setSearchStartDate('');
    setSearchEndDate('');
    loadCheckInReadyPatients();
  };

  // Set up checkout detection listeners
  useEffect(() => {
    const handleCheckoutEvent = (event) => {
      console.log('Checkout event received:', event);
      
      // Show checkout task modal for any checkout event
      const patient = journeys.find(j => j.id === event.patientId);
      if (patient) {
        setCheckoutPatient(patient);
        setCheckoutJourney(patient);
        setShowCheckoutTasks(true);
      }
    };

    // Register checkout event listener
    checkoutDetection.onCheckoutDetected(handleCheckoutEvent);

    // Cleanup listener on unmount
    return () => {
      checkoutDetection.removeCheckoutCallback(handleCheckoutEvent);
    };
  }, [journeys]);

  // Close menus when clicking elsewhere
  useEffect(() => {
    const handleClickOutside = () => {
      setShowRoomActions(null);
      setShowPatientActions(null);
      setShowFilters(false);
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  // Synchronized refresh for rooms and journeys
  const refreshRoomsAndJourneys = useCallback(() => {
    const config = OfficeRoomsService.getOfficeConfig(officeId);
    if (config) {
      setRooms(config.rooms || []);
    }
    loadJourneys();
  }, [officeId, loadJourneys]);

  // Refresh rooms periodically
  useEffect(() => {
    if (viewMode !== 'rooms') return;

    const interval = setInterval(() => {
      refreshRoomsAndJourneys();
    }, 5000);

    return () => clearInterval(interval);
  }, [viewMode, refreshRoomsAndJourneys]);

  // Get current step title for a journey
  const getCurrentStepTitle = (journey) => {
    const currentStep = journey.steps?.find(s => s.id === journey.currentStepId);
    return currentStep?.title || 'Unknown Step';
  };

  // Group journeys by current step title
  const journeysByStep = useMemo(() => {
    let filtered = journeys;

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(j => 
        j.patientName.toLowerCase().includes(query) ||
        j.reasonForVisit?.toLowerCase().includes(query) ||
        j.providerName?.toLowerCase().includes(query)
      );
    }

    // Group by current step title
    const grouped = {};
    filtered.forEach(journey => {
      const stepTitle = getCurrentStepTitle(journey);
      if (!grouped[stepTitle]) {
        grouped[stepTitle] = [];
      }
      grouped[stepTitle].push(journey);
    });

    return grouped;
  }, [journeys, searchQuery]);

  // Filter journeys based on search query, workflow view, and active filters
  const filteredJourneys = useMemo(() => {
    let filtered = journeys;

    // Apply workflow view filter first based on step phase mapping
    if (workflowView !== 'all') {
      filtered = filtered.filter(journey => {
        // Get current step title
        const currentStep = journey.steps?.find(s => s.id === journey.currentStepId);
        const stepTitle = currentStep?.title || 'Unknown';
        
        // Check if step phase matches selected workflow view
        const stepPhase = STEP_PHASE_MAP[stepTitle] || journey.journeyPhase;
        return stepPhase === workflowView;
      });
    }

    // Apply search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      filtered = filtered.filter(journey => 
        journey.patientName?.toLowerCase().includes(query) ||
        journey.reasonForVisit?.toLowerCase().includes(query) ||
        journey.currentStepId?.toLowerCase().includes(query)
      );
    }

    // Apply phase filter
    if (activeFilters.phase !== 'all') {
      filtered = filtered.filter(journey => journey.journeyPhase === activeFilters.phase);
    }

    // Apply priority filter
    if (activeFilters.priority !== 'all') {
      filtered = filtered.filter(journey => journey.priority === activeFilters.priority);
    }

    // Apply step filter
    if (activeFilters.step !== 'all') {
      filtered = filtered.filter(journey => {
        const currentStep = journey.steps?.find(s => s.id === journey.currentStepId);
        return currentStep?.title === activeFilters.step;
      });
    }

    return filtered;
  }, [journeys, searchQuery, activeFilters, workflowView]);

  // Step phase mapping - used to determine which steps belong to which phase
  const STEP_PHASE_MAP = {
    // Pre-visit steps
    'Confirm Appointment': 'pre-visit',
    'Complete Medical History': 'pre-visit', 
    'Verify Insurance': 'pre-visit',
    'Insurance Verification': 'pre-visit',
    'Complete Patient Forms': 'pre-visit',
    
    // In-office steps
    'Check-in': 'in-office',
    'Pre-Testing': 'in-office',
    'Dilation': 'in-office',
    'Retinal Imaging': 'in-office',
    'Doctor Examination': 'in-office',
    'Contact Lens Evaluation': 'in-office',
    'Contact Lens Training': 'in-office', 
    'Optical Consultation': 'in-office',
    'Checkout': 'in-office',
    'Optical Dispensary': 'in-office',
    'Dispensary': 'in-office',
    
    // Post-visit steps
    'Patient Satisfaction Survey': 'post-visit',
    'Glasses Order Status': 'post-visit',
    'Pickup Reminder': 'post-visit',
    'Recall Reminder': 'post-visit',
    'Follow-up Care': 'post-visit',
    'Order Status': 'post-visit'
  };
  
  // Get workflow-filtered journeys grouped by step
  const workflowFilteredJourneysByStep = useMemo(() => {
    let filtered = journeys;

    // Apply workflow view filter based on step phase mapping
    if (workflowView !== 'all') {
      filtered = filtered.filter(journey => {
        // Get current step title
        const currentStep = journey.steps?.find(s => s.id === journey.currentStepId);
        const stepTitle = currentStep?.title || 'Unknown';
        
        // Check if step phase matches selected workflow view
        const stepPhase = STEP_PHASE_MAP[stepTitle] || journey.journeyPhase;
        return stepPhase === workflowView;
      });
    }

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(j => 
        j.patientName.toLowerCase().includes(query) ||
        j.reasonForVisit?.toLowerCase().includes(query) ||
        j.providerName?.toLowerCase().includes(query)
      );
    }

    // Group by current step title
    const grouped = {};
    filtered.forEach(journey => {
      const stepTitle = getCurrentStepTitle(journey);
      if (!grouped[stepTitle]) {
        grouped[stepTitle] = [];
      }
      grouped[stepTitle].push(journey);
    });

    return grouped;
  }, [journeys, searchQuery, workflowView]);

  // Get workflow-specific step columns
  const workflowStepColumns = useMemo(() => {
    // Define step order by workflow phase based on templates
    const preVisitSteps = [
      'Confirm Appointment', 
      'Complete Medical History',
      'Complete Patient Forms',
      'Verify Insurance',
      'Insurance Verification'
    ];
    
    const inOfficeSteps = [
      'Check-in',
      'Pre-Testing', 
      'Dilation', 
      'Retinal Imaging',
      'Doctor Examination', 
      'Contact Lens Evaluation',
      'Contact Lens Training',
      'Optical Consultation',
      'Optical Dispensary',
      'Dispensary',
      'Checkout'
    ];
    
    const postVisitSteps = [
      'Patient Satisfaction Survey', 
      'Glasses Order Status',
      'Pickup Reminder',
      'Recall Reminder',
      'Follow-up Care',
      'Order Status'
    ];
    
    // Get relevant steps based on selected workflow view
    let relevantSteps = [];
    if (workflowView === 'pre-visit') {
      relevantSteps = preVisitSteps;
    } else if (workflowView === 'in-office') {
      relevantSteps = inOfficeSteps;
    } else if (workflowView === 'post-visit') {
      relevantSteps = postVisitSteps;
    } else {
      // All - use default order
      relevantSteps = [...preVisitSteps, ...inOfficeSteps, ...postVisitSteps];
    }
    
    // Get all unique steps from filtered journeys
    const allSteps = new Set(Object.keys(workflowFilteredJourneysByStep));
    
    // Order: first the relevant ones that exist, then any others
    const ordered = relevantSteps.filter(s => allSteps.has(s));
    allSteps.forEach(s => {
      if (!ordered.includes(s)) {
        ordered.push(s);
      }
    });
    
    return ordered;
  }, [workflowFilteredJourneysByStep, workflowView]);

  // Get ordered step columns
  const stepColumns = useMemo(() => {
    const defaultOrder = [
      'Complete Patient Forms',
      'Confirm Appointment',
      'Doctor Examination',
      'Insurance Information',
      'Optical Consultation',
      'Recall Reminder'
    ];
    
    // Get all unique steps from journeys
    const allSteps = new Set(Object.keys(journeysByStep));
    
    // Order: first the default ones that exist, then any others
    const ordered = defaultOrder.filter(s => allSteps.has(s));
    allSteps.forEach(s => {
      if (!ordered.includes(s)) {
        ordered.push(s);
      }
    });
    
    return ordered;
  }, [journeysByStep]);

  const handleCardClick = (journey) => {
    setSelectedJourney(journey);
  };

  const handleStepAction = (journeyId, stepId, action) => {
    const journey = journeys.find(j => j.id === journeyId);
    const step = journey?.steps?.find(s => s.id === stepId);
    
    if (action === 'start') {
      startStep(journeyId, stepId, { startedBy: 'user', location: 'board' });
    } else if (action === 'complete') {
      completeStep(journeyId, stepId, { completedBy: 'user', location: 'board' });
      
      // Check if this step completion should trigger checkout
      if (step && journey) {
        checkoutDetection.triggerStepCheckout(step, journey, 'step-completion');
      }
    } else if (action === 'skip') {
      skipStep(journeyId, stepId, { skippedBy: 'user', reason: 'Manual skip from board' });
    }
  };

  const handlePhaseTransition = (journeyId, newPhase) => {
    transitionPhase(journeyId, newPhase);
  };

  // Handle double-click on journey tile or step to open Encompass popup
  const handleJourneyDoubleClick = (journey, step = null) => {
    const rulesService = getJourneyRulesService();
    const templates = rulesService.getAllStepTemplates();
    
    // Find the step template to get the URL
    let stepTemplate = null;
    if (step) {
      // Match by templateId first, then fall back to id or title matching
      stepTemplate = templates.find(t => 
        t.id === step.templateId || 
        t.id === step.id || 
        t.title === step.title
      );
    } else if (journey.currentStepId) {
      const currentStep = journey.steps?.find(s => s.id === journey.currentStepId);
      if (currentStep) {
        stepTemplate = templates.find(t => 
          t.id === currentStep.templateId || 
          t.id === currentStep.id || 
          t.title === currentStep.title
        );
        step = currentStep;
      }
    }

    // If step template has a URL, build it and open popup
    if (stepTemplate?.url) {
      const context = extractContextFromJourney(journey);
      const url = buildUrlFromTemplate(stepTemplate.url, context);
      
      setEncompassPopup({
        journey,
        step: step || journey.steps?.find(s => s.id === journey.currentStepId),
        url
      });
    }
  };

  // Handle completing a step from the Encompass popup
  const handlePopupComplete = (journey, step) => {
    if (journey && step) {
      completeStep(journey.id, step.id, { 
        completedBy: 'user', 
        location: 'encompass-popup',
        completedVia: 'encompass'
      });
      
      // Check if this step completion should trigger checkout
      checkoutDetection.triggerStepCheckout(step, journey, 'encompass-completion');
    }
    setEncompassPopup(null);
  };

  // Handle clicking an empty room to assign a patient
  const handleRoomClick = (room, e) => {
    if (e.detail === 1) { // Single click
      if (room.status === 'available') {
        setSelectedRoom(room);
        // Load journey patients
        loadJourneyPatientsForRoom();
        // Show patient selector
        setShowAppointmentSelector(true);
      }
    }
  };
  
  // Load journey patients ready for room assignment (includes pre-visit + in-office)
  const loadJourneyPatientsForRoom = () => {
    const journeyPatients = journeys
      .filter(j => j.journeyPhase === 'in-office' || j.journeyPhase === 'pre-visit')
      .map(j => ({
        source: 'journey',
        journeyId: j.id,
        patientId: j.patientId,
        patientName: j.patientName,
        providerId: j.providerId,
        providerName: j.providerName,
        status: j.status,
        reasonForVisit: j.reasonForVisit,
        currentStep: j.currentStep,
        hasActiveJourney: true
      }));

    setCheckInReadyPatients(journeyPatients);
    console.log('Loaded journey patients for room:', journeyPatients.length);
  };

  // Handle double-clicking an occupied room to launch Encompass
  const handleRoomDoubleClick = (room, journey) => {
    if (room.status === 'occupied' && journey) {
      handleJourneyDoubleClick(journey);
    }
  };

  // Handle assigning patient to room from modal (journey-based)
  const handleAssignPatientToRoom = (patient) => {
    if (selectedRoom && patient) {
      const journey = journeys.find(j => j.id === patient.id);
      if (journey) {
        assignPatientToRoom(journey, selectedRoom);
      }
    }
    setShowPatientSelector(false);
    setSelectedRoom(null);
  };
  
  // Handle quick add from appointment to room
  const handleQuickAddToRoom = async (patient) => {
    if (!selectedRoom) return;
    
    try {
      // Check if patient is already in another room and release them first
      const currentRoom = rooms.find(r => r.currentJourneyId === patient.journeyId);
      if (currentRoom && currentRoom.id !== selectedRoom.id) {
        console.log('Releasing patient from current room:', currentRoom.name);
        OfficeRoomsService.releasePatientFromRoom(officeId, currentRoom.id);
      }
      
      const result = await AppointmentRoomService.quickAddPatientToRoom(
        patient,
        selectedRoom.id,
        officeId
      );
      
      console.log('Quick added patient to room:', result);
      
      // Refresh data
      refreshRoomsAndJourneys();
      loadCheckInReadyPatients();
      
      setShowAppointmentSelector(false);
      setSelectedRoom(null);
    } catch (error) {
      console.error('Error adding patient to room:', error);
      alert(`Failed to add patient to room: ${error.message}`);
    }
  };

  // Handle right-click context menu
  const handleRoomContextMenu = (e, room, journey) => {
    e.preventDefault();
    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      room,
      journey
    });
  };

  // Close context menu on click
  useEffect(() => {
    const handleClickOutside = () => setContextMenu(null);
    if (contextMenu) {
      document.addEventListener('click', handleClickOutside);
      return () => document.removeEventListener('click', handleClickOutside);
    }
  }, [contextMenu]);

  // Format wait time with color
  const formatWaitTime = (minutes) => {
    if (!minutes || minutes < 1) return { text: '0 min', isLong: false };
    if (minutes < 60) return { text: `${minutes} min`, isLong: minutes > 30 };
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return { text: `${hours}h ${mins}m`, isLong: true };
  };

  // Format total time
  const formatTotalTime = (journey) => {
    const checkIn = new Date(journey.checkInTime);
    const now = new Date();
    const totalMinutes = Math.floor((now - checkIn) / (1000 * 60));
    if (totalMinutes < 60) return `${totalMinutes}m`;
    const hours = Math.floor(totalMinutes / 60);
    const mins = totalMinutes % 60;
    return `${hours}h ${mins}m`;
  };

  // Get patient initials
  const getInitials = (name) => {
    if (!name) return '?';
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  // Render column for board view
  const renderColumn = (stepTitle, journeysData = journeysByStep) => {
    const stepJourneys = journeysData[stepTitle] || [];
    const headerColor = STEP_COLORS[stepTitle] || STEP_COLORS.default;

    return (
      <div 
        key={stepTitle}
        className="flex-shrink-0 w-[280px] bg-white rounded-lg border border-gray-200"
      >
        {/* Column Header */}
        <div className="px-4 py-3 border-b border-gray-200 flex items-center justify-between">
          <span className={`font-semibold text-sm ${headerColor}`}>{stepTitle}</span>
          <span className="px-2 py-0.5 bg-gray-100 rounded-full text-xs text-gray-600">
            {stepJourneys.length}
          </span>
        </div>

        {/* Column Content */}
        <div className="p-2 space-y-2 max-h-[calc(100vh-280px)] overflow-y-auto">
          {stepJourneys.length === 0 ? (
            <div className="text-center py-8 text-gray-400 text-sm">
              No patients
            </div>
          ) : (
            stepJourneys.map(journey => (
              <PatientJourneyCard
                key={journey.id}
                journey={journey}
                onClick={() => handleCardClick(journey)}
                onDoubleClick={(j) => handleJourneyDoubleClick(j)}
                isSelected={selectedJourney?.id === journey.id}
                onStepAction={handleStepAction}
                compact
              />
            ))
          )}
        </div>
      </div>
    );
  };

  // Render post-visit column with task management
  const renderPostVisitColumn = () => {
    const postVisitPatients = journeys.filter(j => j.journeyPhase === 'post-visit');
    const allTasks = taskManager.getAllTasks();
    
    // Debug logging
    console.log('Post-visit panel render:');
    console.log('- Post-visit patients:', postVisitPatients.map(p => ({ id: p.id, name: p.patientName })));
    console.log('- All tasks:', allTasks.map(t => ({ id: t.id, patientId: t.patientId, journeyId: t.journeyId, title: t.title })));
    
    // More flexible task matching - check both patientId and journeyId
    const postVisitTasks = allTasks.filter(task => 
      postVisitPatients.some(p => p.id === task.patientId || p.id === task.journeyId)
    );
    
    console.log('- Matched post-visit tasks:', postVisitTasks.map(t => ({ id: t.id, title: t.title, patientId: t.patientId })));
    
    // Group tasks by patient - try both patientId and journeyId as keys
    const tasksByPatient = postVisitTasks.reduce((acc, task) => {
      // Use patientId as primary key
      const primaryKey = task.patientId;
      const secondaryKey = task.journeyId;
      
      // Add task under primary key
      if (primaryKey) {
        if (!acc[primaryKey]) {
          acc[primaryKey] = [];
        }
        acc[primaryKey].push(task);
      }
      
      // Also add under secondary key if different (for flexibility)
      if (secondaryKey && secondaryKey !== primaryKey) {
        if (!acc[secondaryKey]) {
          acc[secondaryKey] = [];
        }
        acc[secondaryKey].push(task);
      }
      
      return acc;
    }, {});
    
    console.log('- Tasks grouped by patient:', tasksByPatient);
    
    return (
      <div key="post-visit" className="flex-shrink-0 w-80">
        <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-t-xl p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
                <CalendarClock className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Post-Visit Tasks</h3>
                <p className="text-blue-100 text-sm">
                  {postVisitTasks.length} active task{postVisitTasks.length !== 1 ? 's' : ''}
                </p>
              </div>
            </div>
            {postVisitTasks.length > 0 && (
              <div className="text-white/80 text-xs">
                {postVisitTasks.filter(t => t.status === TaskStatus.PENDING).length} pending
              </div>
            )}
          </div>
        </div>
        
        <div className="bg-white border-x border-b border-gray-200 rounded-b-xl min-h-[600px] max-h-[600px] overflow-y-auto">
          {postVisitPatients.length === 0 && postVisitTasks.length === 0 ? (
            <div className="flex items-center justify-center h-32 text-gray-500">
              <div className="text-center">
                <CalendarClock className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                <p className="text-sm">No post-visit patients</p>
                <div className="mt-2 space-y-1">
                  <button 
                    onClick={() => {
                      console.log('Debug button clicked');
                      import('../../lib/utils/task-debug').then(({ TaskDebugger }) => {
                        TaskDebugger.debugTaskSystem();
                      });
                    }}
                    className="block text-xs text-blue-600 hover:text-blue-800"
                  >
                    Debug Tasks
                  </button>
                  
                  {/* Manual checkout trigger for testing */}
                  <button 
                    onClick={() => {
                      const testPatient = journeys[0]; // Use first available patient
                      if (testPatient) {
                        console.log('Manual checkout trigger for:', testPatient.patientName);
                        checkoutDetection.triggerManualCheckout(testPatient, 'manual-test');
                      }
                    }}
                    className="block text-xs text-green-600 hover:text-green-800"
                  >
                    Test Checkout Modal
                  </button>
                  
                  <button 
                    onClick={() => {
                      import('../../lib/utils/task-debug').then(({ TaskDebugger }) => {
                        TaskDebugger.clearAllTasks();
                      });
                    }}
                    className="block text-xs text-red-600 hover:text-red-800"
                  >
                    Clear All Tasks
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-3 space-y-4">
              {postVisitPatients.map(journey => {
                const patientTasks = tasksByPatient[journey.id] || [];
                const pendingTasks = patientTasks.filter(t => t.status === TaskStatus.PENDING);
                const completedTasks = patientTasks.filter(t => t.status === TaskStatus.COMPLETED);
                const overdueTasks = patientTasks.filter(t => taskManager.isTaskOverdue(t));
                
                return (
                  <div 
                    key={journey.id}
                    className="border border-gray-200 rounded-lg overflow-hidden"
                  >
                    {/* Patient Header */}
                    <div className="bg-gray-50 px-3 py-2 border-b border-gray-200">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold">
                            {getInitials(journey.patientName)}
                          </div>
                          <span className="font-medium text-gray-900 text-sm">{journey.patientName}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          {overdueTasks.length > 0 && (
                            <span className="flex items-center gap-1 text-xs text-red-600">
                              <AlertTriangle className="w-3 h-3" />
                              {overdueTasks.length}
                            </span>
                          )}
                          <span className="text-xs text-gray-500">
                            {patientTasks.length} task{patientTasks.length !== 1 ? 's' : ''}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    {/* Tasks List */}
                    <div className="p-3">
                      {patientTasks.length === 0 ? (
                        <div className="text-center py-4">
                          <CheckSquare className="w-6 h-6 text-gray-300 mx-auto mb-1" />
                          <p className="text-xs text-gray-500">No follow-up tasks</p>
                          <button
                            onClick={() => transitionPhase(journey.id, 'completed')}
                            className="mt-2 px-3 py-1 bg-green-100 text-green-700 text-xs rounded hover:bg-green-200"
                          >
                            Mark Complete
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {patientTasks.slice(0, 3).map(task => {
                            const categoryConfig = TASK_CATEGORY_CONFIG[task.category];
                            const isOverdue = taskManager.isTaskOverdue(task);
                            const daysUntilDue = taskManager.getDaysUntilDue(task);
                            
                            return (
                              <div 
                                key={task.id}
                                className={`p-2 rounded border ${
                                  task.status === TaskStatus.COMPLETED 
                                    ? 'bg-green-50 border-green-200' 
                                    : isOverdue
                                    ? 'bg-red-50 border-red-200'
                                    : 'bg-white border-gray-200'
                                }`}
                              >
                                <div className="flex items-start justify-between">
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2">
                                      <span className="text-xs">{categoryConfig.icon}</span>
                                      <span className={`text-xs font-medium ${
                                        task.status === TaskStatus.COMPLETED 
                                          ? 'text-green-700 line-through' 
                                          : 'text-gray-900'
                                      }`}>
                                        {task.title}
                                      </span>
                                    </div>
                                    <div className="flex items-center gap-2 mt-1">
                                      <span className={`text-xs px-1.5 py-0.5 rounded ${categoryConfig.bgColor} ${categoryConfig.color}`}>
                                        {categoryConfig.label}
                                      </span>
                                      {task.dueDate && (
                                        <span className={`text-xs ${
                                          isOverdue ? 'text-red-600' : 'text-gray-500'
                                        }`}>
                                          {isOverdue ? 'Overdue' : `${daysUntilDue}d`}
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-1">
                                    {/* AI Completion Button */}
                                    {task.aiCompletable && task.status === TaskStatus.PENDING && (
                                      <button
                                        onClick={async () => {
                                          const result = await taskManager.processAITask(task.id);
                                          if (result.success) {
                                            alert(result.message);
                                          } else {
                                            alert(`AI completion failed: ${result.message}`);
                                          }
                                        }}
                                        className="w-6 h-4 px-1 bg-purple-100 text-purple-600 rounded border border-purple-200 hover:bg-purple-200 flex items-center justify-center"
                                        title="Complete with AI"
                                      >
                                        <Bot className="w-3 h-3" />
                                      </button>
                                    )}
                                    
                                    {/* Manual Completion Button */}
                                    <button
                                      onClick={() => {
                                        if (task.status === TaskStatus.COMPLETED) {
                                          taskManager.updateTask(task.id, { status: TaskStatus.PENDING });
                                        } else {
                                          taskManager.completeTask(task.id);
                                        }
                                      }}
                                      className={`w-4 h-4 rounded border flex items-center justify-center ${
                                        task.status === TaskStatus.COMPLETED
                                          ? 'bg-green-500 border-green-500'
                                          : 'border-gray-300 hover:border-gray-400'
                                      }`}
                                    >
                                      {task.status === TaskStatus.COMPLETED && (
                                        <CheckSquare className="w-3 h-3 text-white" />
                                      )}
                                    </button>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                          {patientTasks.length > 3 && (
                            <div className="text-center">
                              <button className="text-xs text-blue-600 hover:text-blue-800">
                                Show {patientTasks.length - 3} more...
                              </button>
                            </div>
                          )}
                          
                          {/* Completion Button */}
                          {completedTasks.length === patientTasks.length && patientTasks.length > 0 && (
                            <div className="pt-2 border-t border-gray-200">
                              <button
                                onClick={() => transitionPhase(journey.id, 'completed')}
                                className="w-full px-3 py-1.5 bg-green-100 text-green-700 text-xs rounded hover:bg-green-200"
                              >
                                All Tasks Complete - Finish Journey
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    );
  };

  // Render Wait Times table view
  const renderWaitTimesTable = () => {
    return (
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">Patient</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">Priority</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">Current Step</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">Wait Time</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">Room</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">Progress</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filteredJourneys.map(journey => {
              const currentStep = journey.steps?.find(s => s.id === journey.currentStepId);
              const waitTime = formatWaitTime(journey.waitTime);
              const phase = PHASE_BADGES[journey.journeyPhase] || PHASE_BADGES['pre-visit'];
              
              return (
                <tr 
                  key={journey.id}
                  onClick={() => handleCardClick(journey)}
                  className={`cursor-pointer hover:bg-gray-50 ${selectedJourney?.id === journey.id ? 'bg-blue-50' : ''}`}
                >
                  <td className="px-4 py-3">
                    <span className="font-medium text-gray-900">{journey.patientName}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-xs text-gray-500 uppercase">
                      {journey.priority === 'normal' ? 'NORMAL' : journey.priority?.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${phase.bg} ${phase.text}`}>
                        {phase.label}
                      </span>
                      <span className="text-sm text-gray-700">{currentStep?.title || 'Unknown'}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-sm font-medium ${waitTime.isLong ? 'text-red-600' : 'text-gray-600'}`}>
                      {waitTime.text}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-gray-500">
                      {currentStep?.room || 'Not assigned'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-500 rounded-full"
                        style={{ width: `${journey.progressPercentage || 0}%` }}
                      />
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {filteredJourneys.length === 0 && (
          <div className="text-center py-12 text-gray-400">
            No patients found
          </div>
        )}
      </div>
    );
  };

  // Calculate room occupancy time
  const getRoomOccupancyTime = (room) => {
    if (!room.occupiedSince) return null;
    const minutes = Math.floor((Date.now() - new Date(room.occupiedSince).getTime()) / 60000);
    return minutes;
  };

  // Check if room is overtime
  const isRoomOvertime = (room) => {
    if (!room.expectedEndTime) return false;
    return new Date() > new Date(room.expectedEndTime);
  };

  // Handle drag start
  const handleDragStart = (e, patient) => {
    setDraggedPatient(patient);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', patient.id);
  };

  // Handle drag end
  const handleDragEnd = () => {
    setDraggedPatient(null);
  };

  // Handle drag over
  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  // Handle drop on room
  const handleDropOnRoom = (e, room) => {
    e.preventDefault();
    if (!draggedPatient) return;

    // Move patient to this room
    assignPatientToRoom(draggedPatient, room);
    setDraggedPatient(null);
  };

  // Assign patient to room
  const assignPatientToRoom = (patient, room) => {
    if (room.status === 'occupied') {
      alert('Room is currently occupied');
      return;
    }

    // Auto-transition pre-visit patients to in-office when assigned to a room
    let activePatient = patient;
    if (patient.journeyPhase === 'pre-visit') {
      const transitioned = transitionPhase(patient.id, 'in-office');
      if (transitioned) {
        activePatient = transitioned;
      }
    }

    // Find current step for patient
    const currentStep = activePatient.steps?.find(s => s.id === activePatient.currentStepId);

    // Check if patient is already in another room
    const currentRoom = rooms.find(r => r.currentJourneyId === activePatient.id);
    if (currentRoom && currentRoom.id !== room.id) {
      // Release from current room first - no confirmation needed
      OfficeRoomsService.releasePatientFromRoom(officeId, currentRoom.id);
    }

    // Update room assignment in services
    OfficeRoomsService.assignPatientToRoom(
      officeId,
      room.id,
      activePatient.patientId || activePatient.id,
      activePatient.patientName,
      activePatient.id,
      currentStep?.id || '',
      currentStep?.title || 'Unknown Step'
    );

    // Start the current step if not already started
    if (currentStep && currentStep.status === 'pending') {
      startStep(activePatient.id, currentStep.id, { room: room.shortName || room.name });
    }

    // Refresh rooms and journeys in sync
    refreshRoomsAndJourneys();
  };

  // Move patient to next room with smart assignment
  const movePatientToNextRoom = (patient) => {
    // Complete current step
    const currentStep = patient.steps?.find(s => s.id === patient.currentStepId);
    if (currentStep && currentStep.status === 'in-progress') {
      completeStep(patient.id, currentStep.id);
    }

    // Find current room
    const currentRoom = rooms.find(r => r.currentJourneyId === patient.id);
    
    if (currentRoom) {
      // Check if patient should move to post-visit phase
      if (RoomWorkflowService.shouldMoveToPostVisit(currentRoom.type, patient)) {
        console.log('=== TRIGGERING CHECKOUT MODAL ===');
        console.log('Current room type:', currentRoom.type);
        console.log('Patient:', patient);
        console.log('Should move to post-visit:', true);
        
        // Show checkout task collection modal
        setCheckoutPatient(patient);
        setCheckoutJourney(patient);
        setShowCheckoutTasks(true);
        
        console.log('Checkout modal should now be visible');
        return;
      }

      // Find best next room using workflow logic
      const availableRooms = rooms.filter(r => r.status === 'available' && r.isActive);
      const nextRoom = RoomWorkflowService.findBestNextRoom(currentRoom.type, availableRooms, patient);
      
      if (nextRoom) {
        // Move to specific next room
        OfficeRoomsService.releasePatientFromRoom(officeId, currentRoom.id);

        // Auto-assign to the recommended room
        assignPatientToRoom(patient, nextRoom);
        alert(`${patient.patientName} moved from ${currentRoom.shortName || currentRoom.name} to ${nextRoom.shortName || nextRoom.name}`);
      } else {
        // No available rooms, show options
        const suggestions = RoomWorkflowService.getNextRoomSuggestions(currentRoom.type, patient);
        if (suggestions.length > 0) {
          const suggestionNames = suggestions.map(type => ROOM_TYPE_CONFIG[type]?.label || type).join(', ');
          alert(`${patient.patientName} ready to move from ${currentRoom.shortName || currentRoom.name}.\nRecommended next rooms: ${suggestionNames}\nPlease drag them to an available room.`);
        }
        
        // Release from current room anyway
        OfficeRoomsService.releasePatientFromRoom(officeId, currentRoom.id);
      }
    }

    // Refresh rooms and journeys
    refreshRoomsAndJourneys();
  };

  // Handle checkout task creation
  const handleCheckoutTasksCreated = (tasks) => {
    console.log('=== CHECKOUT TASK CREATION ===');
    console.log('Created tasks:', tasks);
    console.log('Checkout patient:', checkoutPatient);
    
    // Move patient to post-visit phase
    if (checkoutPatient) {
      // Find and release patient from current room
      const currentRoom = rooms.find(r => r.currentJourneyId === checkoutPatient.id);
      if (currentRoom) {
        console.log('Releasing patient from room:', currentRoom.name);
        OfficeRoomsService.releasePatientFromRoom(officeId, currentRoom.id);
      }
      
      // Transition to post-visit phase
      console.log('Transitioning patient to post-visit phase:', checkoutPatient.id);
      transitionPhase(checkoutPatient.id, 'post-visit');
      
      // Debug: Check task linkage after creation
      setTimeout(() => {
        console.log('=== POST-CHECKOUT TASK VERIFICATION ===');
        console.log('Checkout patient ID:', checkoutPatient.id);
        console.log('Checkout patient name:', checkoutPatient.patientName);
        
        const allTasks = taskManager.getAllTasks();
        console.log('Total tasks in system:', allTasks.length);
        
        // Log all task patient IDs
        allTasks.forEach(task => {
          console.log(`Task "${task.title}": patientId=${task.patientId}, journeyId=${task.journeyId}, patientName=${task.patientName}`);
        });
        
        const patientTasks = allTasks.filter(t => 
          t.patientId === checkoutPatient.id || 
          t.journeyId === checkoutPatient.id
        );
        console.log('Matching patient tasks:', patientTasks);
        
        // Check current patient journey phase
        const updatedJourneys = JSON.parse(localStorage.getItem('patient-journeys') || '[]');
        const updatedPatient = updatedJourneys.find(j => j.id === checkoutPatient.id);
        console.log('Updated patient journey phase:', updatedPatient?.journeyPhase);
        
        // Force UI re-render without page refresh
        window.dispatchEvent(new CustomEvent('tasks-updated'));
      }, 300);
    }
    
    // Refresh rooms and journeys
    refreshRoomsAndJourneys();

    // Show success message
    const taskCount = tasks.length;
    if (taskCount > 0) {
      alert(`${checkoutPatient?.patientName} moved to post-visit with ${taskCount} follow-up task${taskCount !== 1 ? 's' : ''}`);
    } else {
      alert(`${checkoutPatient?.patientName} moved to post-visit - no follow-up tasks needed`);
    }
    
    // Reset checkout state
    setCheckoutPatient(null);
    setCheckoutJourney(null);
    
    console.log('=== END CHECKOUT PROCESS ===');
  };

  // Get patients ready for check-in OR already checked in (for drag-drop in Rooms view)
  const getCheckInPatients = () => {
    // Include both pre-visit (ready to check in) and in-office (checked in) patients
    // This allows staff to see all actionable patients and drag them to rooms
    const roomsConfig = OfficeRoomsService.getOfficeConfig(officeId);
    const occupiedJourneyIds = new Set(
      (roomsConfig?.rooms || [])
        .filter(r => r.status === 'occupied' && r.currentJourneyId)
        .map(r => r.currentJourneyId)
    );

    let checkInReady = journeys.filter(j =>
      (j.journeyPhase === 'in-office' || j.journeyPhase === 'pre-visit') &&
      !occupiedJourneyIds.has(j.id)
    );

    // Mark each with their check-in status for UI differentiation
    checkInReady = checkInReady.map(j => ({
      ...j,
      _checkInStatus: j.journeyPhase === 'in-office' ? 'checked-in' : 'ready'
    }));

    console.log('Check-in patients available:', checkInReady.length, checkInReady.map(p => `${p.patientName} (${p._checkInStatus})`));

    return checkInReady;
  };

  // Render Rooms view
  const renderRoomsView = () => {
    const activeRooms = rooms.filter(r => r.isActive);
    const roomsByType = {};
    
    activeRooms.forEach(room => {
      if (!roomsByType[room.type]) {
        roomsByType[room.type] = [];
      }
      roomsByType[room.type].push(room);
    });

    const roomStats = OfficeRoomsService.getRoomStats(officeId);
    const checkInPatients = getCheckInPatients();

    return (
      <div className="space-y-6">

        {/* Stats Bar */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="grid grid-cols-5 gap-6">
            <div>
              <div className="text-2xl font-bold text-gray-900">{roomStats.totalRooms}</div>
              <div className="text-sm text-gray-500">Total Rooms</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">{roomStats.available}</div>
              <div className="text-sm text-gray-500">Available</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-600">{roomStats.occupied}</div>
              <div className="text-sm text-gray-500">Occupied</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-orange-600">{checkInPatients.length}</div>
              <div className="text-sm text-gray-500">Check-in Ready</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-600">{roomStats.avgOccupancyTime}m</div>
              <div className="text-sm text-gray-500">Avg Time</div>
            </div>
          </div>
        </div>

        {/* Patients Ready for Check-in / Checked In - Drag & Drop Bar */}
        {checkInPatients.length > 0 && (
          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <div className="px-4 py-3 bg-blue-50 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-blue-600" />
                  Patients Ready ({checkInPatients.length})
                </h3>
                <div className="flex items-center gap-3 text-xs text-gray-500">
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-green-500" /> Checked In
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-amber-500" /> Ready
                  </span>
                  <span className="text-gray-400 ml-2">Drag to assign rooms</span>
                </div>
              </div>
            </div>
            <div className="p-4">
              <div className="flex items-center gap-3 overflow-x-auto pb-2">
                {checkInPatients.map(patient => {
                  const isCheckedIn = patient._checkInStatus === 'checked-in';
                  return (
                    <div
                      key={patient.id}
                      draggable
                      onDragStart={(e) => handleDragStart(e, patient)}
                      onDragEnd={handleDragEnd}
                      onClick={() => {
                        setDraggedPatient(patient);
                        setTimeout(() => setDraggedPatient(null), 3000);
                      }}
                      className={`group relative flex items-center gap-2 px-3 py-2.5 bg-white rounded-lg hover:shadow-sm transition-all cursor-move flex-shrink-0 ${
                        isCheckedIn
                          ? 'border border-green-300 hover:border-green-400'
                          : 'border border-amber-300 hover:border-amber-400'
                      }`}
                      title={isCheckedIn ? 'Checked in — drag to room' : 'Ready to check in — drag to room (will auto check-in)'}
                    >
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold ${
                        isCheckedIn
                          ? 'bg-gradient-to-br from-green-500 to-emerald-600'
                          : 'bg-gradient-to-br from-amber-500 to-orange-600'
                      }`}>
                        {getInitials(patient.patientName)}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900 whitespace-nowrap">
                          {patient.patientName}
                        </div>
                        <div className="text-[10px] text-gray-500">
                          {isCheckedIn ? 'Checked In' : 'Ready'}
                        </div>
                      </div>
                      {draggedPatient?.id === patient.id && (
                        <div className="absolute inset-0 bg-blue-400 bg-opacity-20 rounded-lg border border-blue-500 animate-pulse pointer-events-none" />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Rooms Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {activeRooms.sort((a, b) => a.displayOrder - b.displayOrder).map(room => {
            const RoomIcon = ROOM_ICONS[room.type] || Circle;
            const typeConfig = ROOM_TYPE_CONFIG[room.type] || { label: 'Room', color: '#9CA3AF' };
            const occupancyTime = getRoomOccupancyTime(room);
            const isOvertime = isRoomOvertime(room);
            // Find patient journey - check both journey ID and patient ID
            const patientJourney = room.currentJourneyId 
              ? journeys.find(j => j.id === room.currentJourneyId || j.id === room.currentPatientId)
              : null;
            
            // Debug logging to help troubleshoot
            if (room.status === 'occupied' && !patientJourney) {
              console.log('No journey found for occupied room:', {
                roomId: room.id,
                roomName: room.name,
                currentJourneyId: room.currentJourneyId,
                currentPatientId: room.currentPatientId,
                availableJourneys: journeys.map(j => ({ id: j.id, name: j.patientName }))
              });
            }

            return (
              <div
                key={room.id}
                onClick={(e) => {
                  if (room.status === 'occupied' && patientJourney) {
                    handleCardClick(patientJourney);
                  } else {
                    handleRoomClick(room, e);
                  }
                }}
                onDoubleClick={() => handleRoomDoubleClick(room, patientJourney)}
                onContextMenu={(e) => handleRoomContextMenu(e, room, patientJourney)}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDropOnRoom(e, room)}
                className={`relative rounded-xl border-2 p-4 transition-all ${
                  room.status === 'occupied'
                    ? isOvertime
                      ? 'border-red-300 bg-red-50 cursor-pointer hover:border-red-400'
                      : 'border-blue-300 bg-blue-50 cursor-pointer hover:border-blue-400'
                    : room.status === 'cleaning'
                    ? 'border-yellow-300 bg-yellow-50'
                    : room.status === 'maintenance'
                    ? 'border-gray-400 bg-gray-100'
                    : draggedPatient 
                    ? 'border-dashed border-2 border-blue-400 bg-blue-50 cursor-copy' 
                    : 'border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50 cursor-pointer'
                }`}
                title={room.status === 'available' ? 'Click to assign patient • Drag patient here • Right-click for options' : room.status === 'occupied' ? 'Click for details • Double-click to launch Encompass • Right-click for options' : ''}
              >
                {/* Room Header */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: room.color || typeConfig.color }}
                    >
                      <RoomIcon className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900 text-sm">{room.shortName || room.name}</div>
                      <div className="text-[10px] text-gray-500">{typeConfig.label}</div>
                    </div>
                  </div>
                  {isOvertime && (
                    <AlertTriangle className="w-5 h-5 text-red-500 animate-pulse" />
                  )}
                </div>

                {/* Room Content */}
                {room.status === 'occupied' && room.currentPatientName ? (
                  <div className="space-y-2">
                    {/* Timer Display */}
                    {occupancyTime > 0 && (
                      <div className={`flex items-center gap-1.5 text-xs font-medium px-2 py-1 rounded ${
                        isOvertime ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
                      }`}>
                        <Clock className="w-3 h-3" />
                        <span>{occupancyTime} min</span>
                        {isOvertime && <span className="text-[10px]">OVER</span>}
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold">
                        {getInitials(room.currentPatientName)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-gray-900 text-sm truncate">
                          {room.currentPatientName}
                        </div>
                        {patientJourney && (
                          <div className="text-[10px] text-gray-500 truncate">
                            {getCurrentStepTitle(patientJourney)}
                          </div>
                        )}
                      </div>
                      {/* Room Actions Menu */}
                      <div className="relative">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowRoomActions(showRoomActions === room.id ? null : room.id);
                          }}
                          className="p-1 rounded-full hover:bg-white/50 transition-colors"
                        >
                          <MoreVertical className="w-4 h-4 text-gray-500" />
                        </button>
                        {showRoomActions === room.id && (
                          <div className="absolute top-6 right-0 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-10 min-w-[140px]">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                // Try to find patient journey, or create fallback
                                const targetPatient = patientJourney || {
                                  id: room.currentJourneyId || room.currentPatientId,
                                  patientName: room.currentPatientName,
                                  currentStepId: 'current-step',
                                  steps: [{ id: 'current-step', title: 'In Progress', status: 'in-progress' }]
                                };
                                
                                if (targetPatient) {
                                  handleCardClick(targetPatient);
                                } else {
                                  alert(`Patient details not available for ${room.currentPatientName}`);
                                }
                                setShowRoomActions(null);
                              }}
                              className="w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                            >
                              <Edit className="w-3 h-3" />
                              View Details
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                // Try to find patient journey, or create fallback
                                const targetPatient = patientJourney || {
                                  id: room.currentJourneyId || room.currentPatientId,
                                  patientName: room.currentPatientName,
                                  currentStepId: 'current-step',
                                  steps: [{ id: 'current-step', title: 'In Progress', status: 'in-progress' }]
                                };
                                
                                if (targetPatient) {
                                  // Release from current room and move to next step
                                  movePatientToNextRoom(targetPatient);
                                } else {
                                  // Fallback: just release the room
                                  OfficeRoomsService.releasePatientFromRoom(officeId, room.id);
                                  setTimeout(() => {
                                    const updatedConfig = OfficeRoomsService.getOfficeConfig(officeId);
                                    if (updatedConfig) {
                                      setRooms(updatedConfig.rooms || []);
                                    }
                                  }, 100);
                                  alert(`${room.currentPatientName} moved to next step`);
                                }
                                setShowRoomActions(null);
                              }}
                              className="w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                            >
                              <ArrowRight className="w-3 h-3" />
                              Next Step
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                OfficeRoomsService.releasePatientFromRoom(officeId, room.id);
                                setTimeout(() => {
                                  const updatedConfig = OfficeRoomsService.getOfficeConfig(officeId);
                                  if (updatedConfig) {
                                    setRooms(updatedConfig.rooms || []);
                                  }
                                }, 100);
                                setShowRoomActions(null);
                              }}
                              className="w-full px-3 py-2 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
                            >
                              <XCircle className="w-3 h-3" />
                              Release Room
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {/* Time in Room */}
                    <div className={`flex items-center justify-between text-xs ${isOvertime ? 'text-red-600' : 'text-gray-500'}`}>
                      <span>Time in room:</span>
                      <span className="font-medium">
                        {occupancyTime !== null ? `${occupancyTime}m` : '-'}
                        {room.defaultDurationMinutes && (
                          <span className="text-gray-400"> / {room.defaultDurationMinutes}m</span>
                        )}
                      </span>
                    </div>

                    {/* Progress bar */}
                    {room.defaultDurationMinutes && occupancyTime !== null && (
                      <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${isOvertime ? 'bg-red-500' : 'bg-blue-500'}`}
                          style={{ width: `${Math.min(100, (occupancyTime / room.defaultDurationMinutes) * 100)}%` }}
                        />
                      </div>
                    )}
                  </div>
                ) : room.status === 'cleaning' ? (
                  <div className="text-center py-2">
                    <div className="text-yellow-600 font-medium text-sm">Cleaning</div>
                    <div className="text-xs text-gray-500">In progress</div>
                  </div>
                ) : room.status === 'maintenance' ? (
                  <div className="text-center py-2">
                    <div className="text-gray-600 font-medium text-sm">Maintenance</div>
                    <div className="text-xs text-gray-500">Unavailable</div>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <div className="text-green-600 font-medium text-sm">Available</div>
                  </div>
                )}

                {/* Status Badge */}
                <div className={`absolute top-2 right-2 w-2 h-2 rounded-full ${
                  room.status === 'occupied' 
                    ? isOvertime ? 'bg-red-500' : 'bg-blue-500'
                    : room.status === 'cleaning' ? 'bg-yellow-500'
                    : room.status === 'maintenance' ? 'bg-gray-500'
                    : 'bg-green-500'
                }`} />
              </div>
            );
          })}
        </div>

        {/* Room Configuration Link */}
        <div className="flex justify-end">
          <button
            onClick={() => navigate('/journey-admin?tab=rooms')}
            className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700"
          >
            <Settings className="w-4 h-4" />
            Configure Rooms
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center gap-4 mb-1">
          <button 
            onClick={() => navigate(-1)}
            className="text-gray-500 hover:text-gray-700 flex items-center gap-1 text-sm"
          >
            <ChevronLeft className="w-4 h-4" />
            Back
          </button>
        </div>
        <h1 className="text-xl font-bold text-gray-900">Patient Journey Board</h1>
        <p className="text-sm text-gray-500">Track all patients currently in the office</p>
      </div>

      {/* Toolbar */}
      <div className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search patients..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm w-64 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          {/* Workflow Quick-Switch Buttons */}
          <div className="flex items-center bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setWorkflowView('all')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                workflowView === 'all' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setWorkflowView('pre-visit')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                workflowView === 'pre-visit' ? 'bg-purple-500 text-white shadow-sm' : 'text-purple-600 hover:bg-purple-50'
              }`}
            >
              Pre-Visit
            </button>
            <button
              onClick={() => setWorkflowView('in-office')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                workflowView === 'in-office' ? 'bg-green-500 text-white shadow-sm' : 'text-green-600 hover:bg-green-50'
              }`}
            >
              In-Office
            </button>
            <button
              onClick={() => setWorkflowView('post-visit')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                workflowView === 'post-visit' ? 'bg-blue-500 text-white shadow-sm' : 'text-blue-600 hover:bg-blue-50'
              }`}
            >
              Post-Visit
            </button>
          </div>

          {/* Filter Button */}
          <div className="relative">
            <button 
              onClick={(e) => {
                e.stopPropagation();
                setShowFilters(!showFilters);
              }}
              className={`flex items-center gap-2 px-3 py-2 border rounded-lg text-sm transition-colors ${
                showFilters || Object.values(activeFilters).some(f => f !== 'all')
                  ? 'border-blue-500 bg-blue-50 text-blue-700'
                  : 'border-gray-300 text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Filter className="w-4 h-4" />
              {Object.values(activeFilters).some(f => f !== 'all') && (
                <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
              )}
            </button>
            
            {showFilters && (
              <div 
                className="absolute top-10 left-0 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50 min-w-[220px]"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="px-3 py-2 border-b border-gray-100">
                  <h4 className="font-medium text-gray-900 text-sm">Filter Patients</h4>
                </div>
                
                {/* Phase Filter */}
                <div className="px-3 py-2">
                  <label className="block text-xs font-medium text-gray-700 mb-1">Phase</label>
                  <select
                    value={activeFilters.phase}
                    onChange={(e) => setActiveFilters(prev => ({ ...prev, phase: e.target.value }))}
                    className="w-full text-sm border border-gray-300 rounded px-2 py-1"
                  >
                    <option value="all">All Phases</option>
                    <option value="pre-visit">Pre-Visit</option>
                    <option value="in-office">In Office</option>
                    <option value="post-visit">Post-Visit</option>
                    <option value="completed">Completed</option>
                  </select>
                </div>
                
                {/* Priority Filter */}
                <div className="px-3 py-2">
                  <label className="block text-xs font-medium text-gray-700 mb-1">Priority</label>
                  <select
                    value={activeFilters.priority}
                    onChange={(e) => setActiveFilters(prev => ({ ...prev, priority: e.target.value }))}
                    className="w-full text-sm border border-gray-300 rounded px-2 py-1"
                  >
                    <option value="all">All Priorities</option>
                    <option value="high">High</option>
                    <option value="normal">Normal</option>
                    <option value="low">Low</option>
                  </select>
                </div>
                
                {/* Step Filter */}
                <div className="px-3 py-2">
                  <label className="block text-xs font-medium text-gray-700 mb-1">Current Step</label>
                  <select
                    value={activeFilters.step}
                    onChange={(e) => setActiveFilters(prev => ({ ...prev, step: e.target.value }))}
                    className="w-full text-sm border border-gray-300 rounded px-2 py-1"
                  >
                    <option value="all">All Steps</option>
                    <option value="Complete Patient Forms">Complete Forms</option>
                    <option value="Confirm Appointment">Confirm Appointment</option>
                    <option value="Pre-Testing">Pre-Testing</option>
                    <option value="Doctor Examination">Doctor Exam</option>
                    <option value="Dilation">Dilation</option>
                    <option value="Optical Consultation">Optical</option>
                    <option value="Contact Lens">Contact Lens</option>
                    <option value="Dispensary">Dispensary</option>
                    <option value="Checkout">Checkout</option>
                  </select>
                </div>
                
                {/* Clear Filters */}
                <div className="px-3 py-2 border-t border-gray-100">
                  <button
                    onClick={() => setActiveFilters({
                      phase: 'all',
                      priority: 'all',
                      roomStatus: 'all',
                      step: 'all'
                    })}
                    className="w-full px-2 py-1 text-xs text-gray-600 hover:text-gray-800 hover:bg-gray-50 rounded"
                  >
                    Clear All Filters
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* View Toggle */}
          <div className="flex items-center bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode('board')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                viewMode === 'board' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
              Board
            </button>
            <button
              onClick={() => setViewMode('rooms')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                viewMode === 'rooms' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <DoorOpen className="w-4 h-4" />
              Rooms
            </button>
            <button
              onClick={() => setViewMode('waitTimes')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                viewMode === 'waitTimes' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Clock className="w-4 h-4" />
              Wait Times
            </button>
          </div>

          {/* Configure Rooms (only show in rooms view) */}
          {viewMode === 'rooms' && (
            <button
              onClick={() => setShowRoomConfig(true)}
              className="flex items-center gap-2 px-3 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
              title="Configure Rooms"
            >
              <Settings className="w-4 h-4" />
              Configure Rooms
            </button>
          )}

          {/* Refresh */}
          <button
            onClick={loadJourneys}
            disabled={loading}
            className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg"
            title="Refresh"
          >
            <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Main Board/Table Area */}
        <div className="flex-1 overflow-auto p-4">
          {viewMode === 'board' ? (
            <div className="flex gap-4 min-w-max pb-4">
              {workflowStepColumns.map(stepTitle => renderColumn(stepTitle, workflowFilteredJourneysByStep))}
              {/* Only show post visit column in post-visit view or all view if it's needed */}
              {workflowView === 'post-visit' && renderPostVisitColumn()}
            </div>
          ) : viewMode === 'rooms' ? (
            renderRoomsView()
          ) : (
            renderWaitTimesTable()
          )}
        </div>

        {/* Resizable Details Panel (Right Side) */}
        {selectedJourney && (
          <>
            {/* Resize Handle */}
            <div
              onMouseDown={handleMouseDown}
              className={`w-1 bg-gray-200 hover:bg-blue-400 cursor-col-resize transition-colors flex-shrink-0 ${
                isResizing ? 'bg-blue-500' : ''
              }`}
              title="Drag to resize"
            />
            <div 
              className="bg-white border-l border-gray-200 flex flex-col overflow-hidden"
              style={{ width: `${detailsPanelWidth}px`, minWidth: '380px', maxWidth: '700px' }}
            >
              <div className="flex-1 overflow-y-auto">
                <PatientJourneyDetails
                  journey={selectedJourney}
                  onClose={() => setSelectedJourney(null)}
                  onStepAction={handleStepAction}
                  onPhaseTransition={handlePhaseTransition}
                  embedded
                />
              </div>
            </div>
          </>
        )}
      </div>

      {/* Footer */}
      <div className="bg-white border-t border-gray-200 px-6 py-2 flex items-center justify-end">
        <button className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700">
          <Lock className="w-4 h-4" />
          Lock Application
        </button>
      </div>

      {/* Room Configuration Modal */}
      {showRoomConfig && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Configure Rooms</h2>
              <button
                onClick={() => setShowRoomConfig(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-80px)]">
              <RoomConfiguration
                officeId={officeId}
                officeName={roomConfig?.officeName || 'Main Office'}
                onSave={(config) => {
                  setRoomConfig(config);
                  setRooms(config.rooms || []);
                  setShowRoomConfig(false);
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Checkout Task Modal */}
      <CheckoutTaskModal
        isOpen={showCheckoutTasks}
        onClose={() => {
          setShowCheckoutTasks(false);
          setCheckoutPatient(null);
          setCheckoutJourney(null);
        }}
        patient={checkoutPatient}
        journey={checkoutJourney}
        onTasksCreated={handleCheckoutTasksCreated}
      />

      {/* Encompass Popup */}
      {encompassPopup && (
        <EncompassPopup
          url={encompassPopup.url}
          journey={encompassPopup.journey}
          step={encompassPopup.step}
          onComplete={handlePopupComplete}
          onClose={() => setEncompassPopup(null)}
        />
      )}

      {/* Appointment Selection Modal (Quick Add from Appointments) */}
      {showAppointmentSelector && selectedRoom && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-3xl w-full max-h-[85vh] flex flex-col">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">
                    Assign Patient to {selectedRoom.name}
                  </h2>
                  <p className="text-sm text-gray-500">Select a patient from your active journeys</p>
                </div>
                <button
                  onClick={() => {
                    setShowAppointmentSelector(false);
                    setSelectedRoom(null);
                  }}
                  className="text-gray-400 hover:text-gray-500"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 overflow-y-auto">
              {checkInReadyPatients.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Users className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                  <p className="mb-2 text-lg font-semibold">No patients ready</p>
                  <p className="text-sm">All journey patients are already in rooms or have completed their visit</p>
                </div>
              ) : (
                <div className="grid gap-3">
                  {checkInReadyPatients.map(patient => (
                    <button
                      key={patient.patientId}
                      onClick={() => handleQuickAddToRoom(patient)}
                      className="p-4 border-2 border-blue-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold">
                          {getInitials(patient.patientName)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <div className="font-semibold text-gray-900 group-hover:text-blue-600">
                              {patient.patientName}
                            </div>
                            <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded">
                              {patient.currentStep || 'Active Journey'}
                            </span>
                          </div>
                          <div className="flex items-center gap-3 text-sm text-gray-600 mt-1">
                            {patient.providerName && (
                              <span>{patient.providerName}</span>
                            )}
                          </div>
                          {patient.reasonForVisit && (
                            <div className="text-xs text-gray-500 mt-1">
                              {patient.reasonForVisit}
                            </div>
                          )}
                        </div>
                        <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-blue-600" />
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Context Menu */}
      {contextMenu && (
        <div
          className="fixed bg-white rounded-lg shadow-xl border border-gray-200 py-1 z-50 min-w-[200px]"
          style={{
            left: `${contextMenu.x}px`,
            top: `${contextMenu.y}px`
          }}
        >
          {contextMenu.room.status === 'occupied' && contextMenu.journey && (
            <>
              <button
                onClick={() => {
                  handleCardClick(contextMenu.journey);
                  setContextMenu(null);
                }}
                className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
              >
                <UserCircle className="w-4 h-4" />
                View Patient Details
              </button>
              <button
                onClick={() => {
                  handleJourneyDoubleClick(contextMenu.journey);
                  setContextMenu(null);
                }}
                className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
              >
                <ExternalLink className="w-4 h-4" />
                Launch Encompass
              </button>
              <button
                onClick={() => {
                  movePatientToNextRoom(contextMenu.journey);
                  setContextMenu(null);
                }}
                className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
              >
                <ArrowRight className="w-4 h-4" />
                Move to Next Step
              </button>
              <div className="border-t border-gray-100 my-1"></div>
              <button
                onClick={() => {
                  RoomWorkflowService.clearRoom(officeId, contextMenu.room.id);
                  const updatedRooms = OfficeRoomsService.getOfficeConfig(officeId).rooms;
                  setRooms(updatedRooms);
                  setContextMenu(null);
                }}
                className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
              >
                <X className="w-4 h-4" />
                Clear Room
              </button>
            </>
          )}
          {contextMenu.room.status === 'available' && (
            <button
              onClick={() => {
                setSelectedRoom(contextMenu.room);
                setShowPatientSelector(true);
                setContextMenu(null);
              }}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
            >
              <UserPlus className="w-4 h-4" />
              Assign Patient
            </button>
          )}
        </div>
      )}
    </div>
  );
}
