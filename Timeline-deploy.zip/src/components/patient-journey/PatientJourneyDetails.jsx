/**
 * Patient Journey Details
 * Right panel showing full journey details - TaskApp style
 */

import React, { useState, useMemo, useEffect } from 'react';
import { 
  X, 
  Clock, 
  User, 
  Calendar,
  MapPin,
  CheckCircle,
  MessageSquare,
  Mail,
  Phone,
  Settings,
  ClipboardList,
  ExternalLink,
  Smartphone,
  Loader2,
  Send,
  Camera,
  Ruler
} from 'lucide-react';
import { PatientAppService } from '../../lib/services/patient-app-service';
import { UnifiedCommunicationService } from '../../lib/services/unified-communication-service';
import CheckoutTaskModal from '../tasks/CheckoutTaskModal';
import RecommendationList from '../recommendations/RecommendationList';
import { taskManager } from '../../lib/services/task-management-service';
import { getJourneyRulesService } from '../../lib/services/journey-rules-service';
import { buildUrlFromTemplate, extractContextFromJourney } from '../../lib/utils/url-builder';
import { EyefinityService } from '../../services/eyefinityService';

// Define animation keyframes
const fadeInKeyframes = `
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
`;

// Phase badge configuration
const PHASE_BADGES = {
  'pre-visit': { label: 'Pre-visit', bg: 'bg-purple-100', text: 'text-purple-700' },
  'in-office': { label: 'In office', bg: 'bg-green-100', text: 'text-green-700' },
  'post-visit': { label: 'Post visit', bg: 'bg-blue-100', text: 'text-blue-700' },
  'completed': { label: 'Completed', bg: 'bg-gray-100', text: 'text-gray-700' }
};

// Communication channel icons
const CHANNEL_CONFIG = {
  sms: { icon: MessageSquare, label: 'SMS' },
  email: { icon: Mail, label: 'EMAIL' },
  voice: { icon: Phone, label: 'VOICE' }
};

// Get patient initials
const getInitials = (name) => {
  if (!name) return '??';
  const parts = name.split(' ');
  if (parts.length >= 2) {
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }
  return name.slice(0, 2).toUpperCase();
};

// Format date/time
const formatDateTime = (date) => {
  if (!date) return 'N/A';
  const d = new Date(date);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + 
         ' ' + d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
};

export default function PatientJourneyDetails({
  journey,
  onClose,
  onStepAction,
  onPhaseTransition,
  embedded = false
}) {
  const initials = getInitials(journey.patientName);
  const [showCheckoutTasks, setShowCheckoutTasks] = useState(false);
  const [patientDemographics, setPatientDemographics] = useState(null);
  const [sendingVisitLink, setSendingVisitLink] = useState(false);
  const [visitLinkSent, setVisitLinkSent] = useState(false);
  const [showSentAgainNotification, setShowSentAgainNotification] = useState(false);

  // Send patient the My Visit app link via SMS
  const handleSendVisitLink = async () => {
    if (!journey?.patientId || !patientDemographics?.phone) {
      alert('Patient phone number not available. Please update patient demographics.');
      return;
    }

    setSendingVisitLink(true);
    try {
      // Create a session token for the patient
      const dob = patientDemographics.dob || journey.patientDob;
      if (!dob) {
        alert('Patient date of birth not available.');
        setSendingVisitLink(false);
        return;
      }

      // Generate magic link
      const baseUrl = window.location.origin;
      const magicLink = `${baseUrl}/patient/login?appointmentId=${journey.id}&patientId=${journey.patientId}`;

      // Send SMS via unified communication service
      const message = `Hi ${journey.patientName?.split(' ')[0] || 'there'}! Track your visit in real-time with MyEyeCare Journey: ${magicLink}`;
      
      await UnifiedCommunicationService.sendSMS({
        to: patientDemographics.phone,
        message,
        patientId: journey.patientId,
        patientName: journey.patientName,
        sentBy: 'Patient Portal'
      });
      
      // Log to console for debugging
      console.log('[SMS Debug] Sent message to:', patientDemographics.phone);
      
      // If this is a repeat send, show the notification briefly
      if (visitLinkSent) {
        setShowSentAgainNotification(true);
        setTimeout(() => setShowSentAgainNotification(false), 3000); // Hide after 3 seconds
      }

      setVisitLinkSent(true);
      console.log('Visit link sent to:', patientDemographics.phone);
    } catch (error) {
      console.error('Error sending visit link:', error);
      alert('Failed to send visit link. Please try again.');
    } finally {
      setSendingVisitLink(false);
    }
  };

  // Fetch patient demographics for recommendations
  useEffect(() => {
    const fetchPatientData = async () => {
      if (journey?.patientId) {
        try {
          const demographics = await EyefinityService.getPatientById(journey.patientId);
          setPatientDemographics(demographics);
        } catch (error) {
          console.error('Error fetching patient demographics:', error);
        }
      }
    };
    fetchPatientData();
  }, [journey?.patientId]);

  if (!journey) return null;

  const currentStep = journey.steps?.find(s => s.id === journey.currentStepId);
  const phase = PHASE_BADGES[journey.journeyPhase] || PHASE_BADGES['pre-visit'];

  // Build recommendation context
  const recommendationContext = useMemo(() => {
    const calculateAge = (dob) => {
      if (!dob) return 0;
      const today = new Date();
      const birthDate = new Date(dob);
      let age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      return age;
    };

    // Use fetched demographics if available, fallback to journey data
    const patientAge = patientDemographics?.age || calculateAge(patientDemographics?.dob || journey.patientDob);
    const firstName = patientDemographics?.firstName || journey.patientName?.split(' ')[0] || '';
    const lastName = patientDemographics?.lastName || journey.patientName?.split(' ').slice(1).join(' ') || '';

    return {
      patient: {
        id: journey.patientId,
        firstName,
        lastName,
        age: patientAge,
        dateOfBirth: patientDemographics?.dob ? new Date(patientDemographics.dob) : (journey.patientDob ? new Date(journey.patientDob) : new Date()),
        lifestyle: journey.lifestyleInfo || {},
        preferences: journey.preferences || {}
      },
      journey: {
        id: journey.id,
        journeyPhase: journey.journeyPhase,
        currentStep: currentStep?.title,
        status: journey.status,
        checkInTime: journey.checkInTime ? new Date(journey.checkInTime) : undefined
      },
      appointment: journey.appointmentDate ? {
        id: journey.appointmentId || journey.id,
        date: new Date(journey.appointmentDate),
        type: journey.appointmentType || 'Annual Exam',
        status: journey.status,
        provider: {
          id: journey.providerId || '',
          name: journey.providerName || ''
        }
      } : undefined,
      purchaseHistory: journey.purchaseHistory || [],
      insuranceInfo: patientDemographics?.insurances?.[0] ? {
        carrier: patientDemographics.insurances[0].carrier || patientDemographics.insurances[0].planName,
        planName: patientDemographics.insurances[0].planName
      } : undefined,
      customData: {
        reasonForVisit: journey.reasonForVisit
      }
    };
  }, [journey, currentStep, patientDemographics]);

  // Determine if patient is on time (check-in within 10 minutes of scheduled)
  const isOnTime = true; // Simplified - would calculate based on scheduled vs actual

  // Get all steps for display
  const allSteps = journey.steps || [];

  // Check if checkout step is completed
  const checkoutStep = allSteps.find(step => 
    step.title?.toLowerCase().includes('checkout') && step.status === 'completed'
  );
  const isCheckoutCompleted = !!checkoutStep;

  // Handle checkout task creation
  const handleCheckoutTasksCreated = (tasks) => {
    console.log('Created checkout tasks:', tasks);
    
    // Move patient to post-visit phase
    if (onPhaseTransition) {
      onPhaseTransition(journey.id, 'post-visit');
    }
    
    // Show success message
    const taskCount = tasks.length;
    if (taskCount > 0) {
      alert(`${journey.patientName} moved to post-visit with ${taskCount} follow-up task${taskCount !== 1 ? 's' : ''}`);
    } else {
      alert(`${journey.patientName} moved to post-visit - no follow-up tasks needed`);
    }
    
    setShowCheckoutTasks(false);
  };

  // Launch Encompass for a step
  const handleLaunchEncompass = (step) => {
    const rulesService = getJourneyRulesService();
    const templates = rulesService.getAllStepTemplates();
    // Match by templateId first, then fall back to id or title matching
    const stepTemplate = templates.find(t => 
      t.id === step.templateId || 
      t.id === step.id || 
      t.title === step.title
    );
    
    if (stepTemplate?.url) {
      const context = extractContextFromJourney(journey);
      const url = buildUrlFromTemplate(stepTemplate.url, context);
      window.open(url, '_blank');
    }
  };

  // Render a single step card
  const renderStepCard = (step) => {
    const stepPhase = PHASE_BADGES[step.stepType] || PHASE_BADGES['pre-visit'];
    const isCurrentStep = step.id === journey.currentStepId;
    const channel = step.communicationType || 'sms';
    const ChannelIcon = CHANNEL_CONFIG[channel]?.icon || MessageSquare;
    
    // Check if step has Encompass URL configured
    const rulesService = getJourneyRulesService();
    const templates = rulesService.getAllStepTemplates();
    // Match by templateId first, then fall back to id or title matching
    const stepTemplate = templates.find(t => 
      t.id === step.templateId || 
      t.id === step.id || 
      t.title === step.title
    );
    const hasEncompassUrl = !!stepTemplate?.url;
    
    // Debug logging
    if (step.title?.toLowerCase().includes('insurance')) {
      console.log('Step matching debug:', {
        stepId: step.id,
        stepTitle: step.title,
        stepTemplateId: step.templateId,
        foundTemplate: stepTemplate?.id,
        hasUrl: hasEncompassUrl,
        templateUrl: stepTemplate?.url,
        allTemplateIds: templates.map(t => ({ id: t.id, title: t.title, hasUrl: !!t.url }))
      });
    }
    
    return (
      <div 
        key={step.id}
        className={`border rounded-lg p-4 ${isCurrentStep ? 'border-purple-300 bg-purple-50' : 'border-gray-200 bg-white'}`}
      >
        {/* Step Header */}
        <div className="flex items-start justify-between mb-2">
          <h4 className="font-semibold text-gray-900">{step.title}</h4>
        </div>

        {/* Status and Phase badges */}
        <div className="flex items-center gap-2 mb-2">
          <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-xs font-medium">
            {step.status}
          </span>
          <span className={`px-2 py-0.5 rounded text-xs font-medium ${stepPhase.bg} ${stepPhase.text}`}>
            {stepPhase.label}
          </span>
        </div>

        {/* Step Description */}
        {step.description && (
          <p className="text-sm text-gray-600 mb-2">{step.description}</p>
        )}

        {/* Communication info */}
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <ChannelIcon className="w-3 h-3" />
          <span>Via: {CHANNEL_CONFIG[channel]?.label || 'SMS'}</span>
          <span className="text-gray-300">|</span>
          <span className={step.responseReceived ? 'text-green-600' : 'text-orange-500'}>
            {step.responseReceived ? 'Response received' : 'Awaiting response'}
          </span>
        </div>

        {/* Success Notification for resending */}
        {showSentAgainNotification && (
          <div className="bg-green-100 text-green-700 border border-green-300 p-2 rounded text-xs flex items-center gap-1 mt-2" 
            style={{ animation: 'fadeIn 0.3s ease-in-out' }}>
            <CheckCircle size={12} className="mr-1" />
            Link sent again successfully!
          </div>
        )}

        {/* Step Actions - Always visible */}
        <div className="mt-3 pt-3 border-t border-gray-200 flex flex-wrap gap-2">
          {/* Frame Scanner & Measurement links - show on Doctor Examination, Optical, Dispensary steps */}
          {(step.title?.toLowerCase().includes('doctor') ||
            step.title?.toLowerCase().includes('exam') ||
            step.title?.toLowerCase().includes('optical') ||
            step.title?.toLowerCase().includes('dispensary') ||
            step.title?.toLowerCase().includes('contact lens')) && (
            <>
              <button
                onClick={() => {
                  const patientId = journey.patientId || journey.id;
                  const companyId = journey.companyId || 'default';
                  const payload = btoa(JSON.stringify({ patientId, companyId, type: 'frame-scanner', exp: Date.now() + 7 * 24 * 60 * 60 * 1000 }));
                  const link = `${window.location.origin}/patient/frame-scanner?token=${payload}`;
                  navigator.clipboard.writeText(link);
                  alert('Frame Scanner link copied to clipboard!\n\n' + link);
                }}
                className="px-3 py-1.5 bg-purple-600 text-white rounded text-xs hover:bg-purple-700 flex items-center gap-1.5"
                title="Send frame scanner link to patient"
              >
                <Camera size={14} />
                Frame Scanner
              </button>
              <button
                onClick={() => {
                  const patientId = journey.patientId || journey.id;
                  const companyId = journey.companyId || 'default';
                  const payload = btoa(JSON.stringify({ patientId, companyId, type: 'measurements', exp: Date.now() + 7 * 24 * 60 * 60 * 1000 }));
                  const link = `${window.location.origin}/patient/measurements?token=${payload}`;
                  navigator.clipboard.writeText(link);
                  alert('Measurement link copied to clipboard!\n\n' + link);
                }}
                className="px-3 py-1.5 bg-indigo-600 text-white rounded text-xs hover:bg-indigo-700 flex items-center gap-1.5"
                title="Send measurement link to patient"
              >
                <Ruler size={14} />
                Measurements
              </button>
            </>
          )}
          {/* Send Visit Link button - show on check-in related steps */}
          {(step.title?.toLowerCase().includes('check') || 
            step.title?.toLowerCase().includes('arrival') ||
            step.title?.toLowerCase().includes('welcome')) && (
            <button
              onClick={handleSendVisitLink}
              disabled={sendingVisitLink}
              className={`px-3 py-1.5 rounded text-xs flex items-center gap-1.5 ${
                visitLinkSent 
                  ? 'bg-green-100 text-green-700 border border-green-300 hover:bg-green-200' 
                  : 'bg-gradient-to-r from-blue-500 to-purple-500 text-white hover:from-blue-600 hover:to-purple-600'
              } disabled:opacity-70`}
            >
              {sendingVisitLink ? (
                <>
                  <Loader2 size={14} className="animate-spin" />
                  Sending...
                </>
              ) : visitLinkSent ? (
                <>
                  <Send size={14} />
                  Send Again
                </>
              ) : (
                <>
                  <Smartphone size={14} />
                  Send Visit Link
                </>
              )}
            </button>
          )}
          {hasEncompassUrl && (
            <button
              onClick={() => handleLaunchEncompass(step)}
              className="px-3 py-1.5 bg-purple-600 text-white rounded text-xs hover:bg-purple-700 flex items-center gap-1.5"
            >
              <ExternalLink size={14} />
              Launch Encompass
            </button>
          )}
          {step.status === 'pending' && (
            <button
              onClick={() => onStepAction(journey.id, step.id, 'start')}
              className="px-3 py-1.5 bg-blue-600 text-white rounded text-xs hover:bg-blue-700"
            >
              Start Step
            </button>
          )}
          {step.status === 'in-progress' && (
            <button
              onClick={() => onStepAction(journey.id, step.id, 'complete')}
              className="px-3 py-1.5 bg-green-600 text-white rounded text-xs hover:bg-green-700"
            >
              Complete
            </button>
          )}
          {['pending', 'in-progress'].includes(step.status) && (
            <button
              onClick={() => onStepAction(journey.id, step.id, 'skip')}
              className="px-3 py-1.5 border border-gray-300 text-gray-700 rounded text-xs hover:bg-gray-50"
            >
              Skip Step
            </button>
          )}
        </div>
      </div>
    );
  };

  const content = (
    <>
      {/* Patient Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-start gap-3">
          {/* Avatar */}
          <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-lg font-semibold text-purple-700">{initials}</span>
          </div>
          
          <div className="flex-1 min-w-0">
            <h2 className="font-bold text-gray-900 text-lg">{journey.patientName}</h2>
            <p className="text-sm text-gray-500 truncate">
              {journey.reasonForVisit || 'Modified reason, same IDs'}
            </p>
          </div>

          {!embedded && (
            <button
              onClick={onClose}
              className="p-1 text-gray-400 hover:text-gray-600"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Status Tabs */}
        <div className="flex items-center gap-2 mt-4">
          <button className="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-md text-sm font-medium">
            Active
          </button>
          <button className="px-3 py-1.5 text-gray-500 hover:bg-gray-50 rounded-md text-sm">
            {currentStep?.title || 'Confirm Appointment'}
          </button>
          <span className={`px-2 py-0.5 rounded text-xs font-medium ${phase.bg} ${phase.text}`}>
            {phase.label}
          </span>
          
          {/* On time badge */}
          <div className="ml-auto">
            <span className={`px-2 py-1 rounded text-xs font-medium ${isOnTime ? 'bg-gray-100 text-gray-700' : 'bg-red-100 text-red-700'}`}>
              {isOnTime ? 'On time' : 'Late'}
            </span>
          </div>
        </div>
      </div>

      {/* Patient Details Grid */}
      <div className="p-4 border-b border-gray-200">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="flex items-center gap-2 text-gray-500 mb-1">
              <Clock className="w-4 h-4" />
              <span>Wait: {journey.waitTime || 0} min</span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 text-gray-500 mb-1">
              <Calendar className="w-4 h-4" />
              <span>Pre-visit: {formatDateTime(journey.preVisitStartDate || journey.createdAt)}</span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 text-gray-500 mb-1">
              <Clock className="w-4 h-4" />
              <span>Check-in: {formatDateTime(journey.checkInTime)}</span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 text-gray-500 mb-1">
              <User className="w-4 h-4" />
              <span>Provider: {journey.providerName || 'Not assigned'}</span>
            </div>
          </div>
        </div>

        {/* Progress */}
        <div className="mt-4 flex items-center gap-2">
          <span className="text-sm text-gray-500">Progress:</span>
          <span className="text-sm font-medium text-gray-700">{journey.progressPercentage || 0}%</span>
        </div>
      </div>

      {/* Content Scrollable Area */}
      <div className="flex-1 overflow-hidden flex flex-col">
        <div className="overflow-y-auto flex-1">
          {/* Recommendations Section */}
          <div className="p-4 border-b border-gray-200 bg-gradient-to-br from-purple-50 to-blue-50">
            <RecommendationList
              patientId={journey.patientId}
              journeyId={journey.id}
              displayLocation="patient-details-sidebar"
              context={recommendationContext}
              compact={true}
              maxDisplay={3}
              title="Personalized Recommendations"
            />
          </div>

          {/* Checkout Action */}
          {isCheckoutCompleted && journey.journeyPhase === 'in-office' && (
            <div className="p-4 border-b border-gray-200 bg-blue-50">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ClipboardList className="w-5 h-5 text-blue-600" />
                  <div>
                    <h3 className="font-medium text-blue-900">Checkout Complete</h3>
                    <p className="text-sm text-blue-700">Ready to collect follow-up tasks</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowCheckoutTasks(true)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700"
                >
                  Add Follow-ups
                </button>
              </div>
            </div>
          )}

          {/* Journey Steps */}
          <div className="p-4">
            <h3 className="font-semibold text-gray-900 mb-4">Journey Steps</h3>
            <div className="space-y-3">
              {allSteps.map(step => renderStepCard(step))}
            </div>
          </div>
        </div>
      </div>
    </>
  );

  // Embedded mode (right panel in board)
  if (embedded) {
    return (
      <div className="h-full flex flex-col overflow-hidden">
        <style>{fadeInKeyframes}</style>
        {content}
      </div>
    );
  }

  // Floating panel mode
  return (
    <>
      <style>{fadeInKeyframes}</style>
      <div className="fixed inset-y-0 right-0 w-[400px] bg-white shadow-xl z-50 flex flex-col">
        {content}
      </div>
      
      {/* Checkout Task Modal */}
      <CheckoutTaskModal
        isOpen={showCheckoutTasks}
        onClose={() => setShowCheckoutTasks(false)}
        patient={journey}
        journey={journey}
        onTasksCreated={handleCheckoutTasksCreated}
      />
    </>
  );
}
