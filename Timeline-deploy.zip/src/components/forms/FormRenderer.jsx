/**
 * FormRenderer Component
 * Renders a dynamic form based on a form template
 * Supports all field types: text, textarea, select, radio, checkbox, date, email, phone, signature, file
 */

import React, { useState, useRef, Suspense, lazy } from 'react';
import {
  ChevronRight,
  ChevronLeft,
  Check,
  Upload,
  X,
  AlertCircle,
  FileText,
  Camera,
  CreditCard,
  Loader
} from 'lucide-react';

const DriversLicenseScanner = lazy(() => import('../scanner/DriversLicenseScanner'));

// Signature Pad Component
function SignaturePad({ value, onChange, disabled }) {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);

  const startDrawing = (e) => {
    if (disabled) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX || e.touches?.[0]?.clientX) - rect.left;
    const y = (e.clientY || e.touches?.[0]?.clientY) - rect.top;
    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
  };

  const draw = (e) => {
    if (!isDrawing || disabled) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX || e.touches?.[0]?.clientX) - rect.left;
    const y = (e.clientY || e.touches?.[0]?.clientY) - rect.top;
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (isDrawing) {
      setIsDrawing(false);
      const canvas = canvasRef.current;
      onChange(canvas.toDataURL());
    }
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    onChange('');
  };

  return (
    <div className="space-y-2">
      <div className="border-2 border-dashed border-gray-300 rounded-lg bg-white">
        <canvas
          ref={canvasRef}
          width={400}
          height={150}
          className="w-full touch-none cursor-crosshair"
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
        />
      </div>
      <div className="flex justify-between items-center">
        <p className="text-xs text-gray-500">Sign above using mouse or touch</p>
        <button
          type="button"
          onClick={clearSignature}
          className="text-sm text-red-600 hover:text-red-700"
        >
          Clear
        </button>
      </div>
    </div>
  );
}

// File Upload Field Component
function FileUploadField({ field, value, onChange, error }) {
  const [preview, setPreview] = useState(null);
  const [fileName, setFileName] = useState('');
  const fileInputRef = useRef(null);

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file size
    const maxSize = field.validation?.maxSize || 10 * 1024 * 1024;
    if (file.size > maxSize) {
      alert(`File size exceeds ${Math.round(maxSize / 1024 / 1024)}MB limit`);
      return;
    }

    // Validate file type
    const allowedTypes = field.validation?.allowedTypes;
    if (allowedTypes && !allowedTypes.includes(file.type)) {
      alert(`File type not allowed. Allowed types: ${allowedTypes.join(', ')}`);
      return;
    }

    setFileName(file.name);

    // Create preview for images
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreview(e.target.result);
        onChange({
          name: file.name,
          size: file.size,
          type: file.type,
          dataUrl: e.target.result,
        });
      };
      reader.readAsDataURL(file);
    } else {
      onChange({
        name: file.name,
        size: file.size,
        type: file.type,
      });
    }
  };

  const clearFile = () => {
    setPreview(null);
    setFileName('');
    onChange(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-2">
      <input
        ref={fileInputRef}
        type="file"
        accept={field.validation?.allowedTypes?.join(',')}
        onChange={handleFileChange}
        className="hidden"
        id={`file-${field.id}`}
      />
      
      {!value ? (
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-purple-400 hover:bg-purple-50 transition-colors"
        >
          <div className="flex flex-col items-center gap-2">
            <div className="flex gap-2">
              <Upload className="w-8 h-8 text-gray-400" />
              <Camera className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-sm text-gray-600">{field.placeholder || 'Click to upload or drag file here'}</p>
            <p className="text-xs text-gray-400">
              {field.validation?.allowedTypes 
                ? `Allowed: ${field.validation.allowedTypes.map(t => t.split('/')[1]).join(', ')}`
                : 'PDF, JPG, PNG'}
            </p>
          </div>
        </div>
      ) : (
        <div className="border rounded-lg p-4 bg-gray-50">
          <div className="flex items-start gap-3">
            {preview ? (
              <img src={preview} alt="Preview" className="w-20 h-20 object-cover rounded" />
            ) : (
              <div className="w-20 h-20 bg-gray-200 rounded flex items-center justify-center">
                <FileText className="w-8 h-8 text-gray-400" />
              </div>
            )}
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-900">{fileName}</p>
              <p className="text-xs text-gray-500">
                {value.size ? `${Math.round(value.size / 1024)} KB` : ''}
              </p>
            </div>
            <button
              type="button"
              onClick={clearFile}
              className="p-1 text-gray-400 hover:text-red-500"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
      
      {error && (
        <p className="text-sm text-red-600 flex items-center gap-1">
          <AlertCircle className="w-4 h-4" />
          {error}
        </p>
      )}
    </div>
  );
}

// Main FormRenderer Component
export default function FormRenderer({ 
  template, 
  initialResponses = {}, 
  onSubmit, 
  onSaveProgress,
  readOnly = false,
  showSectionProgress = true 
}) {
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
  const [responses, setResponses] = useState(initialResponses);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [scannerOpen, setScannerOpen] = useState(false);

  if (!template || !template.sections) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>Form template not found</p>
      </div>
    );
  }

  const sections = template.sections;
  const currentSection = sections[currentSectionIndex];
  const isFirstSection = currentSectionIndex === 0;
  const isLastSection = currentSectionIndex === sections.length - 1;

  // Update a response
  const updateResponse = (fieldId, value) => {
    setResponses(prev => ({
      ...prev,
      [fieldId]: value,
    }));
    // Clear error when field is updated
    if (errors[fieldId]) {
      setErrors(prev => {
        const next = { ...prev };
        delete next[fieldId];
        return next;
      });
    }
  };

  // Bulk update responses (used by DL barcode scanner to fill multiple fields at once)
  const bulkUpdateResponses = (fieldValues) => {
    setResponses(prev => ({ ...prev, ...fieldValues }));
    setErrors(prev => {
      const next = { ...prev };
      Object.keys(fieldValues).forEach(k => delete next[k]);
      return next;
    });
  };

  // Check if a section contains demographics fields (firstName + lastName = scannable)
  const isDemographicsSection = (section) => {
    const fieldIds = (section?.fields || []).map(f => f.id);
    return fieldIds.includes('firstName') && fieldIds.includes('lastName');
  };

  const canUseCamera = typeof navigator !== 'undefined' && !!navigator.mediaDevices?.getUserMedia;

  // Validate current section
  const validateSection = () => {
    const sectionErrors = {};
    
    currentSection.fields.forEach(field => {
      if (field.required && !field.readOnly) {
        const value = responses[field.id];
        if (value === undefined || value === null || value === '' || 
            (Array.isArray(value) && value.length === 0)) {
          sectionErrors[field.id] = 'This field is required';
        }
      }
      
      // Additional validation
      if (field.validation && responses[field.id]) {
        const value = responses[field.id];
        if (field.validation.pattern && typeof value === 'string') {
          const regex = new RegExp(field.validation.pattern);
          if (!regex.test(value)) {
            sectionErrors[field.id] = 'Invalid format';
          }
        }
        if (field.validation.minLength && typeof value === 'string' && value.length < field.validation.minLength) {
          sectionErrors[field.id] = `Minimum ${field.validation.minLength} characters required`;
        }
        if (field.validation.maxLength && typeof value === 'string' && value.length > field.validation.maxLength) {
          sectionErrors[field.id] = `Maximum ${field.validation.maxLength} characters allowed`;
        }
      }
    });

    setErrors(sectionErrors);
    return Object.keys(sectionErrors).length === 0;
  };

  // Go to next section
  const handleNext = () => {
    if (validateSection()) {
      if (onSaveProgress) {
        onSaveProgress(responses);
      }
      setCurrentSectionIndex(prev => Math.min(prev + 1, sections.length - 1));
    }
  };

  // Go to previous section
  const handlePrevious = () => {
    setCurrentSectionIndex(prev => Math.max(prev - 1, 0));
  };

  // Submit form
  const handleSubmit = async () => {
    if (!validateSection()) return;

    setIsSubmitting(true);
    try {
      await onSubmit?.(responses);
    } catch (error) {
      console.error('Form submission error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Render a field based on its type
  const renderField = (field) => {
    const value = responses[field.id];
    const error = errors[field.id];
    const isDisabled = readOnly || field.readOnly;

    const commonInputClasses = `w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 ${
      error ? 'border-red-300 bg-red-50' : 'border-gray-300'
    } ${isDisabled ? 'bg-gray-100 cursor-not-allowed' : ''}`;

    switch (field.type) {
      case 'text':
      case 'email':
      case 'phone':
        return (
          <input
            type={field.type === 'phone' ? 'tel' : field.type}
            value={value || ''}
            onChange={(e) => updateResponse(field.id, e.target.value)}
            placeholder={field.placeholder}
            disabled={isDisabled}
            className={commonInputClasses}
          />
        );

      case 'number':
        return (
          <input
            type="number"
            value={value || ''}
            onChange={(e) => updateResponse(field.id, e.target.value)}
            placeholder={field.placeholder}
            disabled={isDisabled}
            min={field.validation?.min}
            max={field.validation?.max}
            className={commonInputClasses}
          />
        );

      case 'textarea':
        return (
          <textarea
            value={value || ''}
            onChange={(e) => updateResponse(field.id, e.target.value)}
            placeholder={field.placeholder}
            disabled={isDisabled}
            rows={4}
            className={commonInputClasses}
          />
        );

      case 'date':
        return (
          <input
            type="date"
            value={value || ''}
            onChange={(e) => updateResponse(field.id, e.target.value)}
            disabled={isDisabled}
            className={commonInputClasses}
          />
        );

      case 'select':
        return (
          <select
            value={value || ''}
            onChange={(e) => updateResponse(field.id, e.target.value)}
            disabled={isDisabled}
            className={commonInputClasses}
          >
            <option value="">Select an option...</option>
            {field.options?.map(opt => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        );

      case 'radio':
        return (
          <div className="space-y-2">
            {field.options?.map(opt => (
              <label key={opt.value} className="flex items-center gap-3 cursor-pointer">
                <input
                  type="radio"
                  name={field.id}
                  value={opt.value}
                  checked={value === opt.value}
                  onChange={(e) => updateResponse(field.id, e.target.value)}
                  disabled={isDisabled}
                  className="w-4 h-4 text-purple-600 focus:ring-purple-500"
                />
                <span className="text-gray-700">{opt.label}</span>
              </label>
            ))}
          </div>
        );

      case 'checkbox':
        const checkedValues = Array.isArray(value) ? value : [];
        return (
          <div className="space-y-2">
            {field.options?.map(opt => (
              <label key={opt.value} className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  value={opt.value}
                  checked={checkedValues.includes(opt.value)}
                  onChange={(e) => {
                    const newValues = e.target.checked
                      ? [...checkedValues, opt.value]
                      : checkedValues.filter(v => v !== opt.value);
                    updateResponse(field.id, newValues);
                  }}
                  disabled={isDisabled}
                  className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
                />
                <span className="text-gray-700">{opt.label}</span>
              </label>
            ))}
          </div>
        );

      case 'signature':
        return (
          <SignaturePad
            value={value}
            onChange={(sig) => updateResponse(field.id, sig)}
            disabled={isDisabled}
          />
        );

      case 'file':
      case 'idDocument':
        return (
          <FileUploadField
            field={field}
            value={value}
            onChange={(file) => updateResponse(field.id, file)}
            error={error}
          />
        );

      default:
        return (
          <input
            type="text"
            value={value || ''}
            onChange={(e) => updateResponse(field.id, e.target.value)}
            placeholder={field.placeholder}
            disabled={isDisabled}
            className={commonInputClasses}
          />
        );
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      {/* Progress indicator */}
      {showSectionProgress && sections.length > 1 && (
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-500">
              Section {currentSectionIndex + 1} of {sections.length}
            </span>
            <span className="text-sm font-medium text-purple-600">
              {Math.round(((currentSectionIndex + 1) / sections.length) * 100)}% Complete
            </span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-purple-600 transition-all duration-300"
              style={{ width: `${((currentSectionIndex + 1) / sections.length) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* Section header */}
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-900">{currentSection.title}</h2>
        {currentSection.description && (
          <p className="mt-1 text-gray-600">{currentSection.description}</p>
        )}
      </div>

      {/* Driver's License Scanner trigger */}
      {!readOnly && canUseCamera && isDemographicsSection(currentSection) && (
        <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <CreditCard className="w-5 h-5 text-blue-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-blue-900 text-sm">Speed up your intake</p>
              <p className="text-xs text-blue-700">Scan the barcode on the back of your driver's license to auto-fill</p>
            </div>
            <button
              type="button"
              onClick={() => setScannerOpen(true)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 flex items-center gap-2 flex-shrink-0"
            >
              <Camera className="w-4 h-4" />
              Scan
            </button>
          </div>
        </div>
      )}

      {/* Fields */}
      <div className="space-y-6">
        {currentSection.fields.map(field => (
          <div key={field.id}>
            <label className="block mb-2">
              <span className="text-sm font-medium text-gray-700">
                {field.label}
                {field.required && <span className="text-red-500 ml-1">*</span>}
              </span>
              {field.description && (
                <span className="block text-xs text-gray-500 mt-0.5">{field.description}</span>
              )}
            </label>
            {renderField(field)}
            {errors[field.id] && field.type !== 'file' && (
              <p className="mt-1 text-sm text-red-600 flex items-center gap-1">
                <AlertCircle className="w-4 h-4" />
                {errors[field.id]}
              </p>
            )}
          </div>
        ))}
      </div>

      {/* Navigation buttons */}
      <div className="flex justify-between mt-8 pt-6 border-t">
        <button
          type="button"
          onClick={handlePrevious}
          disabled={isFirstSection}
          className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-colors ${
            isFirstSection
              ? 'text-gray-400 cursor-not-allowed'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <ChevronLeft className="w-5 h-5" />
          Previous
        </button>

        {isLastSection ? (
          <button
            type="button"
            onClick={handleSubmit}
            disabled={isSubmitting || readOnly}
            className="flex items-center gap-2 px-8 py-3 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Submitting...
              </>
            ) : (
              <>
                <Check className="w-5 h-5" />
                Submit Form
              </>
            )}
          </button>
        ) : (
          <button
            type="button"
            onClick={handleNext}
            className="flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700"
          >
            Next
            <ChevronRight className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Driver's License Scanner Modal */}
      {scannerOpen && (
        <Suspense fallback={
          <div className="fixed inset-0 z-50 bg-black flex items-center justify-center">
            <div className="text-center text-white">
              <Loader className="w-8 h-8 animate-spin mx-auto mb-3" />
              <p className="text-sm">Loading scanner...</p>
            </div>
          </div>
        }>
          <DriversLicenseScanner
            isOpen={scannerOpen}
            onClose={() => setScannerOpen(false)}
            onScanComplete={(data) => {
              bulkUpdateResponses(data);
              setScannerOpen(false);
            }}
          />
        </Suspense>
      )}
    </div>
  );
}
