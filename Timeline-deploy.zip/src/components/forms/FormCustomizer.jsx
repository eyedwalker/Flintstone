/**
 * Form Customizer Component
 * UI for customizing form templates - hide fields, change labels, add branding
 */

import React, { useState, useEffect } from 'react';
import { FormSubmissionService } from '../../lib/services/form-submission-service';
import FormCustomizationService from '../../lib/services/form-customization-service';
import {
  X,
  Save,
  Eye,
  EyeOff,
  Edit3,
  Plus,
  Trash2,
  ChevronDown,
  ChevronRight,
  Settings,
  Palette,
  FileText,
  Check,
  AlertCircle,
  Building,
  Image,
  Type,
} from 'lucide-react';

export default function FormCustomizer({ templateId, officeId = 'default', onClose, onSave }) {
  const [template, setTemplate] = useState(null);
  const [override, setOverride] = useState(null);
  const [branding, setBranding] = useState({});
  const [expandedSections, setExpandedSections] = useState({});
  const [activeTab, setActiveTab] = useState('fields');
  const [previewMode, setPreviewMode] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState(null);

  useEffect(() => {
    loadTemplate();
  }, [templateId]);

  const loadTemplate = () => {
    const tmpl = FormSubmissionService.getTemplateById(templateId);
    if (tmpl) {
      setTemplate(tmpl);
      
      // Load existing customization or create blank
      const existingOverride = FormCustomizationService.getFormOverride(officeId, templateId);
      setOverride(existingOverride || FormCustomizationService.createBlankOverride(templateId));
      
      // Load branding
      const customization = FormCustomizationService.getOfficeCustomization(officeId);
      setBranding(customization?.branding || {});
      
      // Expand first section by default
      if (tmpl.sections?.length > 0) {
        setExpandedSections({ [tmpl.sections[0].id]: true });
      }
    }
  };

  const toggleSection = (sectionId) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  const toggleFieldHidden = (fieldId) => {
    setOverride(prev => {
      const hiddenFields = prev.hiddenFields.includes(fieldId)
        ? prev.hiddenFields.filter(f => f !== fieldId)
        : [...prev.hiddenFields, fieldId];
      return { ...prev, hiddenFields };
    });
  };

  const toggleFieldRequired = (fieldId, currentRequired) => {
    setOverride(prev => {
      let requiredFields = [...prev.requiredFields];
      let optionalFields = [...prev.optionalFields];
      
      if (currentRequired) {
        // Make it optional
        requiredFields = requiredFields.filter(f => f !== fieldId);
        if (!optionalFields.includes(fieldId)) {
          optionalFields.push(fieldId);
        }
      } else {
        // Make it required
        optionalFields = optionalFields.filter(f => f !== fieldId);
        if (!requiredFields.includes(fieldId)) {
          requiredFields.push(fieldId);
        }
      }
      
      return { ...prev, requiredFields, optionalFields };
    });
  };

  const updateFieldLabel = (fieldId, label) => {
    setOverride(prev => ({
      ...prev,
      fieldLabels: { ...prev.fieldLabels, [fieldId]: label }
    }));
  };

  const updateFieldPlaceholder = (fieldId, placeholder) => {
    setOverride(prev => ({
      ...prev,
      fieldPlaceholders: { ...prev.fieldPlaceholders, [fieldId]: placeholder }
    }));
  };

  const updateBranding = (key, value) => {
    setBranding(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Save the override
      FormCustomizationService.saveFormOverride(officeId, override);
      
      // Save branding
      let customization = FormCustomizationService.getOfficeCustomization(officeId);
      if (!customization) {
        customization = {
          officeId,
          officeName: 'My Office',
          branding: {},
          formOverrides: {},
          createdAt: new Date(),
          updatedAt: new Date(),
        };
      }
      customization.branding = branding;
      FormCustomizationService.saveOfficeCustomization(customization);
      
      setSaveMessage({ type: 'success', text: 'Customizations saved!' });
      setTimeout(() => setSaveMessage(null), 3000);
      
      onSave?.();
    } catch (error) {
      setSaveMessage({ type: 'error', text: 'Failed to save customizations' });
    } finally {
      setIsSaving(false);
    }
  };

  const isFieldHidden = (fieldId) => override?.hiddenFields?.includes(fieldId);
  
  const isFieldRequired = (fieldId, originalRequired) => {
    if (override?.requiredFields?.includes(fieldId)) return true;
    if (override?.optionalFields?.includes(fieldId)) return false;
    return originalRequired;
  };

  const getFieldLabel = (fieldId, originalLabel) => {
    return override?.fieldLabels?.[fieldId] || originalLabel;
  };

  if (!template) {
    return (
      <div className="p-8 text-center text-gray-500">
        Loading template...
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Customize Form</h2>
            <p className="text-sm text-gray-500">{template.title}</p>
          </div>
          <div className="flex items-center gap-2">
            {saveMessage && (
              <span className={`text-sm ${saveMessage.type === 'success' ? 'text-green-600' : 'text-red-600'}`}>
                {saveMessage.text}
              </span>
            )}
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
            >
              {isSaving ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              Save
            </button>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-2 bg-gray-50 border-b border-gray-200">
          <button
            onClick={() => setActiveTab('fields')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'fields'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <FileText className="w-4 h-4" />
            Fields
          </button>
          <button
            onClick={() => setActiveTab('branding')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'branding'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <Palette className="w-4 h-4" />
            Branding
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'settings'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <Settings className="w-4 h-4" />
            Settings
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {/* Fields Tab */}
          {activeTab === 'fields' && (
            <div className="space-y-4">
              <p className="text-sm text-gray-600 mb-4">
                Click on fields to hide/show them, change labels, or modify requirements.
              </p>
              
              {template.sections.map(section => (
                <div key={section.id} className="border border-gray-200 rounded-lg overflow-hidden">
                  {/* Section Header */}
                  <button
                    onClick={() => toggleSection(section.id)}
                    className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      {expandedSections[section.id] ? (
                        <ChevronDown className="w-5 h-5 text-gray-400" />
                      ) : (
                        <ChevronRight className="w-5 h-5 text-gray-400" />
                      )}
                      <div className="text-left">
                        <h3 className="font-medium text-gray-900">{section.title}</h3>
                        <p className="text-sm text-gray-500">{section.fields.length} fields</p>
                      </div>
                    </div>
                    <span className="text-xs text-gray-400">
                      {section.fields.filter(f => isFieldHidden(f.id)).length} hidden
                    </span>
                  </button>

                  {/* Section Fields */}
                  {expandedSections[section.id] && (
                    <div className="divide-y divide-gray-100">
                      {section.fields.map(field => {
                        const hidden = isFieldHidden(field.id);
                        const required = isFieldRequired(field.id, field.required);
                        const label = getFieldLabel(field.id, field.label);
                        
                        return (
                          <div
                            key={field.id}
                            className={`p-4 ${hidden ? 'bg-gray-50 opacity-60' : 'bg-white'}`}
                          >
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-2">
                                  <input
                                    type="text"
                                    value={override?.fieldLabels?.[field.id] || ''}
                                    onChange={(e) => updateFieldLabel(field.id, e.target.value)}
                                    placeholder={field.label}
                                    className="font-medium text-gray-900 border-b border-transparent hover:border-gray-300 focus:border-purple-500 focus:outline-none px-1 py-0.5"
                                  />
                                  {required && (
                                    <span className="text-red-500 text-xs">Required</span>
                                  )}
                                  <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded">
                                    {field.type}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <input
                                    type="text"
                                    value={override?.fieldPlaceholders?.[field.id] || ''}
                                    onChange={(e) => updateFieldPlaceholder(field.id, e.target.value)}
                                    placeholder={field.placeholder || 'Add placeholder text...'}
                                    className="text-sm text-gray-500 border-b border-transparent hover:border-gray-300 focus:border-purple-500 focus:outline-none px-1 py-0.5 w-64"
                                  />
                                </div>
                              </div>
                              
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() => toggleFieldRequired(field.id, required)}
                                  className={`p-2 rounded-lg text-sm ${
                                    required
                                      ? 'bg-red-50 text-red-600 hover:bg-red-100'
                                      : 'bg-gray-50 text-gray-400 hover:bg-gray-100'
                                  }`}
                                  title={required ? 'Make optional' : 'Make required'}
                                >
                                  {required ? 'Required' : 'Optional'}
                                </button>
                                <button
                                  onClick={() => toggleFieldHidden(field.id)}
                                  className={`p-2 rounded-lg ${
                                    hidden
                                      ? 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                                      : 'bg-gray-50 text-gray-400 hover:bg-gray-100'
                                  }`}
                                  title={hidden ? 'Show field' : 'Hide field'}
                                >
                                  {hidden ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Branding Tab */}
          {activeTab === 'branding' && (
            <div className="space-y-6">
              <p className="text-sm text-gray-600">
                Customize how this form looks for your office.
              </p>

              <div className="grid md:grid-cols-2 gap-6">
                {/* Logo URL */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Image className="w-4 h-4 inline mr-2" />
                    Logo URL
                  </label>
                  <input
                    type="url"
                    value={branding.logoUrl || ''}
                    onChange={(e) => updateBranding('logoUrl', e.target.value)}
                    placeholder="https://example.com/logo.png"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  />
                </div>

                {/* Primary Color */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Palette className="w-4 h-4 inline mr-2" />
                    Primary Color
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      value={branding.primaryColor || '#6B21A8'}
                      onChange={(e) => updateBranding('primaryColor', e.target.value)}
                      className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={branding.primaryColor || ''}
                      onChange={(e) => updateBranding('primaryColor', e.target.value)}
                      placeholder="#6B21A8"
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                </div>

                {/* Header Text */}
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Type className="w-4 h-4 inline mr-2" />
                    Header Text
                  </label>
                  <input
                    type="text"
                    value={branding.headerText || ''}
                    onChange={(e) => updateBranding('headerText', e.target.value)}
                    placeholder="Your Office Name"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>

                {/* Footer Text */}
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Type className="w-4 h-4 inline mr-2" />
                    Footer Text
                  </label>
                  <textarea
                    value={branding.footerText || ''}
                    onChange={(e) => updateBranding('footerText', e.target.value)}
                    placeholder="Thank you for choosing our practice..."
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>
              </div>

              {/* Preview */}
              {(branding.logoUrl || branding.headerText) && (
                <div className="mt-6 p-6 border border-gray-200 rounded-lg bg-gray-50">
                  <h4 className="text-sm font-medium text-gray-700 mb-4">Preview</h4>
                  <div 
                    className="bg-white p-6 rounded-lg border"
                    style={{ borderTopColor: branding.primaryColor, borderTopWidth: '4px' }}
                  >
                    {branding.logoUrl && (
                      <img 
                        src={branding.logoUrl} 
                        alt="Logo" 
                        className="h-12 mb-4"
                        onError={(e) => e.target.style.display = 'none'}
                      />
                    )}
                    {branding.headerText && (
                      <h3 className="text-xl font-bold" style={{ color: branding.primaryColor }}>
                        {branding.headerText}
                      </h3>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Settings Tab */}
          {activeTab === 'settings' && (
            <div className="space-y-6">
              <p className="text-sm text-gray-600">
                Additional form settings and options.
              </p>

              <div className="space-y-4">
                {/* Custom Title */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Custom Form Title
                  </label>
                  <input
                    type="text"
                    value={override?.customTitle || ''}
                    onChange={(e) => setOverride(prev => ({ ...prev, customTitle: e.target.value }))}
                    placeholder={template.title}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                  <p className="text-xs text-gray-500 mt-1">Leave blank to use default: {template.title}</p>
                </div>

                {/* Custom Description */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Custom Form Description
                  </label>
                  <textarea
                    value={override?.customDescription || ''}
                    onChange={(e) => setOverride(prev => ({ ...prev, customDescription: e.target.value }))}
                    placeholder={template.description}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>

                {/* Stats */}
                <div className="mt-8 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-3">Customization Summary</h4>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold text-purple-600">{override?.hiddenFields?.length || 0}</p>
                      <p className="text-sm text-gray-500">Hidden Fields</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-purple-600">{Object.keys(override?.fieldLabels || {}).length}</p>
                      <p className="text-sm text-gray-500">Custom Labels</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-purple-600">{override?.requiredFields?.length || 0}</p>
                      <p className="text-sm text-gray-500">Added Required</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
