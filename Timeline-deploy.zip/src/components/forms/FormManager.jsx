/**
 * FormManager Component
 * Staff interface to send forms to patients and manage form submissions
 */

import React, { useState, useEffect } from 'react';
import { FormSubmissionService } from '../../lib/services/form-submission-service';
import { 
  FileText, 
  Send, 
  Clock, 
  CheckCircle, 
  Eye, 
  RefreshCw,
  Mail,
  MessageSquare,
  Copy,
  ExternalLink,
  AlertCircle,
  X,
  Search,
  Filter
} from 'lucide-react';

// Status badge configuration
const STATUS_CONFIG = {
  sent: { label: 'Sent', bg: 'bg-blue-100', text: 'text-blue-700', icon: Send },
  viewed: { label: 'Viewed', bg: 'bg-yellow-100', text: 'text-yellow-700', icon: Eye },
  in_progress: { label: 'In Progress', bg: 'bg-purple-100', text: 'text-purple-700', icon: Clock },
  completed: { label: 'Completed', bg: 'bg-green-100', text: 'text-green-700', icon: CheckCircle },
  expired: { label: 'Expired', bg: 'bg-gray-100', text: 'text-gray-700', icon: AlertCircle },
};

export default function FormManager({ patientId, patientName, patientEmail, patientPhone, onFormSent }) {
  const [templates, setTemplates] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [showSendModal, setShowSendModal] = useState(false);
  const [sendMethod, setSendMethod] = useState({ email: true, sms: true });
  const [isSending, setIsSending] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [copiedLink, setCopiedLink] = useState(null);

  useEffect(() => {
    loadData();
  }, [patientId]);

  const loadData = () => {
    const allTemplates = FormSubmissionService.getTemplates();
    setTemplates(allTemplates.filter(t => t.isPublished && !t.isArchived));
    
    if (patientId) {
      const patientSubmissions = FormSubmissionService.getSubmissionsByPatientId(patientId);
      setSubmissions(patientSubmissions);
    } else {
      const allSubmissions = FormSubmissionService.getAllSubmissions();
      setSubmissions(allSubmissions);
    }
  };

  const handleSendForm = async () => {
    if (!selectedTemplate) return;

    setIsSending(true);
    try {
      const submission = FormSubmissionService.createSubmission({
        patientId: patientId || 'unknown',
        patientName,
        patientEmail,
        patientPhone,
        templateId: selectedTemplate.id,
      });

      // Send notifications
      await FormSubmissionService.sendFormToPatient(
        submission.submissionId,
        sendMethod.email ? patientEmail : undefined,
        sendMethod.sms ? patientPhone : undefined
      );

      setShowSendModal(false);
      setSelectedTemplate(null);
      loadData();
      onFormSent?.(submission);
    } catch (error) {
      console.error('Error sending form:', error);
    } finally {
      setIsSending(false);
    }
  };

  const handleResendForm = async (submissionId) => {
    await FormSubmissionService.resendForm(submissionId);
    loadData();
  };

  const handleCopyLink = (accessLink) => {
    navigator.clipboard.writeText(accessLink);
    setCopiedLink(accessLink);
    setTimeout(() => setCopiedLink(null), 2000);
  };

  const filteredSubmissions = submissions.filter(s => {
    if (statusFilter !== 'all' && s.status !== statusFilter) return false;
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        s.formTitle.toLowerCase().includes(query) ||
        s.patientName?.toLowerCase().includes(query)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header with Send Form Button */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Patient Forms</h3>
          <p className="text-sm text-gray-500">Send and manage forms for this patient</p>
        </div>
        <button
          onClick={() => setShowSendModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
        >
          <Send className="w-4 h-4" />
          Send Form
        </button>
      </div>

      {/* Quick Form Templates */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {templates.slice(0, 4).map(template => (
          <button
            key={template.id}
            onClick={() => {
              setSelectedTemplate(template);
              setShowSendModal(true);
            }}
            className="p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-colors text-left"
          >
            <FileText className="w-5 h-5 text-purple-600 mb-2" />
            <h4 className="font-medium text-gray-900 text-sm truncate">{template.title}</h4>
            <p className="text-xs text-gray-500 mt-1">{template.sections?.length || 0} sections</p>
          </button>
        ))}
      </div>

      {/* Submissions List */}
      {submissions.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-medium text-gray-900">Form History</h4>
            <div className="flex items-center gap-2">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search forms..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 pr-4 py-1.5 border border-gray-300 rounded-lg text-sm w-48"
                />
              </div>
              
              {/* Status Filter */}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm"
              >
                <option value="all">All Status</option>
                <option value="sent">Sent</option>
                <option value="viewed">Viewed</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
                <option value="expired">Expired</option>
              </select>
            </div>
          </div>

          <div className="space-y-3">
            {filteredSubmissions.map(submission => {
              const status = STATUS_CONFIG[submission.status] || STATUS_CONFIG.sent;
              const StatusIcon = status.icon;
              
              return (
                <div
                  key={submission.submissionId}
                  className="p-4 border border-gray-200 rounded-lg hover:border-gray-300"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${status.bg}`}>
                        <StatusIcon className={`w-4 h-4 ${status.text}`} />
                      </div>
                      <div>
                        <h5 className="font-medium text-gray-900">{submission.formTitle}</h5>
                        <div className="flex items-center gap-2 mt-1">
                          <span className={`px-2 py-0.5 rounded text-xs font-medium ${status.bg} ${status.text}`}>
                            {status.label}
                          </span>
                          {submission.viewCount > 0 && (
                            <span className="text-xs text-gray-500">
                              Viewed {submission.viewCount} time{submission.viewCount > 1 ? 's' : ''}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          Sent {new Date(submission.createdAt).toLocaleDateString()}
                          {submission.expiresAt && ` · Expires ${new Date(submission.expiresAt).toLocaleDateString()}`}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {submission.status !== 'completed' && submission.status !== 'expired' && (
                        <>
                          <button
                            onClick={() => handleCopyLink(submission.accessLink)}
                            className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg"
                            title="Copy link"
                          >
                            {copiedLink === submission.accessLink ? (
                              <CheckCircle className="w-4 h-4 text-green-600" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </button>
                          <button
                            onClick={() => window.open(submission.accessLink, '_blank')}
                            className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg"
                            title="Open form"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleResendForm(submission.submissionId)}
                            className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg"
                            title="Resend"
                          >
                            <RefreshCw className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                  
                  {submission.status === 'completed' && submission.completedAt && (
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <p className="text-xs text-green-600">
                        <CheckCircle className="w-3 h-3 inline mr-1" />
                        Completed on {new Date(submission.completedAt).toLocaleString()}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Empty State */}
      {submissions.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
          <p>No forms sent yet</p>
          <p className="text-sm mt-1">Send a form to get started</p>
        </div>
      )}

      {/* Send Form Modal */}
      {showSendModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Send Form</h3>
                <button
                  onClick={() => {
                    setShowSendModal(false);
                    setSelectedTemplate(null);
                  }}
                  className="p-1 text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Template Selection */}
              {!selectedTemplate ? (
                <div className="space-y-3">
                  <p className="text-sm text-gray-600 mb-4">Select a form template to send:</p>
                  {templates.map(template => (
                    <button
                      key={template.id}
                      onClick={() => setSelectedTemplate(template)}
                      className="w-full p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 text-left"
                    >
                      <div className="flex items-center gap-3">
                        <FileText className="w-5 h-5 text-purple-600" />
                        <div>
                          <h4 className="font-medium text-gray-900">{template.title}</h4>
                          {template.description && (
                            <p className="text-sm text-gray-500">{template.description}</p>
                          )}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Selected Template */}
                  <div className="p-4 bg-purple-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-purple-600" />
                      <div>
                        <h4 className="font-medium text-gray-900">{selectedTemplate.title}</h4>
                        <p className="text-sm text-purple-700">{selectedTemplate.sections?.length || 0} sections</p>
                      </div>
                    </div>
                  </div>

                  {/* Patient Info */}
                  <div className="space-y-3">
                    <h4 className="font-medium text-gray-900">Send to Patient</h4>
                    {patientName && (
                      <p className="text-sm text-gray-600">{patientName}</p>
                    )}
                  </div>

                  {/* Delivery Method */}
                  <div className="space-y-3">
                    <h4 className="font-medium text-gray-900">Delivery Method</h4>
                    
                    <label className="flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <input
                        type="checkbox"
                        checked={sendMethod.email}
                        onChange={(e) => setSendMethod(prev => ({ ...prev, email: e.target.checked }))}
                        className="w-4 h-4 text-purple-600 rounded"
                      />
                      <Mail className="w-5 h-5 text-gray-500" />
                      <div className="flex-1">
                        <span className="text-sm font-medium text-gray-700">Email</span>
                        {patientEmail && (
                          <p className="text-xs text-gray-500">{patientEmail}</p>
                        )}
                      </div>
                    </label>

                    <label className="flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <input
                        type="checkbox"
                        checked={sendMethod.sms}
                        onChange={(e) => setSendMethod(prev => ({ ...prev, sms: e.target.checked }))}
                        className="w-4 h-4 text-purple-600 rounded"
                      />
                      <MessageSquare className="w-5 h-5 text-gray-500" />
                      <div className="flex-1">
                        <span className="text-sm font-medium text-gray-700">SMS</span>
                        {patientPhone && (
                          <p className="text-xs text-gray-500">{patientPhone}</p>
                        )}
                      </div>
                    </label>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3">
                    <button
                      onClick={() => setSelectedTemplate(null)}
                      className="flex-1 py-2 px-4 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                    >
                      Back
                    </button>
                    <button
                      onClick={handleSendForm}
                      disabled={isSending || (!sendMethod.email && !sendMethod.sms)}
                      className="flex-1 py-2 px-4 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                      {isSending ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          Send Form
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
