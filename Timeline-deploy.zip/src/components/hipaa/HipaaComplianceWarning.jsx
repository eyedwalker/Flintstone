import React from 'react';
import { AlertTriangle, AlertCircle, CheckCircle, Shield, Clock } from 'lucide-react';
import HipaaComplianceService from '../../services/hipaaComplianceService';

const HipaaComplianceWarning = ({ 
  patientId, 
  onRequestSignature,
  compact = false 
}) => {
  const status = HipaaComplianceService.getComplianceStatus(patientId);
  const checkResult = HipaaComplianceService.canProceedToExam(patientId);

  // If valid and not expiring soon, show success or nothing
  if (status.isValid && !checkResult.warningMessage) {
    if (compact) return null;
    return (
      <div className="flex items-center gap-2 px-3 py-2 bg-green-50 border border-green-200 rounded-lg">
        <CheckCircle size={16} className="text-green-600 flex-shrink-0" />
        <span className="text-sm text-green-700 font-medium">HIPAA Signature Valid</span>
        {status.daysUntilExpiration && (
          <span className="text-xs text-green-600 ml-auto">
            Expires in {status.daysUntilExpiration} days
          </span>
        )}
      </div>
    );
  }

  // Expiring soon warning (non-blocking)
  if (status.isValid && checkResult.warningMessage) {
    return (
      <div className={`${compact ? 'p-2' : 'p-3'} bg-amber-50 border border-amber-200 rounded-lg`}>
        <div className="flex items-start gap-2">
          <Clock size={compact ? 16 : 20} className="text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className={`font-medium text-amber-800 ${compact ? 'text-xs' : 'text-sm'}`}>
              {checkResult.warningMessage}
            </p>
            <button
              onClick={onRequestSignature}
              className={`mt-2 px-3 py-1.5 bg-amber-600 text-white rounded font-medium hover:bg-amber-700 transition-colors ${compact ? 'text-xs' : 'text-sm'}`}
            >
              Renew Now
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Blocking - no signature or expired
  if (!checkResult.canProceed) {
    return (
      <div className={`${compact ? 'p-2' : 'p-3'} bg-red-50 border border-red-200 rounded-lg`}>
        <div className="flex items-start gap-2">
          <AlertCircle size={compact ? 16 : 20} className="text-red-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className={`font-semibold text-red-800 ${compact ? 'text-xs' : 'text-sm'}`}>
              {compact ? 'HIPAA Required' : checkResult.blockingReason}
            </p>
            {!compact && (
              <p className="text-sm text-red-700 mt-1">{checkResult.warningMessage}</p>
            )}
            <button
              onClick={onRequestSignature}
              className={`mt-2 flex items-center gap-1 px-3 py-1.5 bg-red-600 text-white rounded font-medium hover:bg-red-700 transition-colors ${compact ? 'text-xs' : 'text-sm'}`}
            >
              <Shield size={14} />
              {status.isExpired ? 'Renew Signature' : 'Get Signature'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
};

export const HipaaSignatureStatus = ({ patientId }) => {
  const status = HipaaComplianceService.getComplianceStatus(patientId);

  if (status.isValid) {
    if (status.daysUntilExpiration && status.daysUntilExpiration <= 30) {
      return (
        <div className="flex items-center gap-1">
          <Clock size={12} className="text-amber-500" />
          <span className="text-xs text-amber-600 font-medium">
            Expires in {status.daysUntilExpiration}d
          </span>
        </div>
      );
    }
    return (
      <div className="flex items-center gap-1">
        <CheckCircle size={12} className="text-green-600" />
        <span className="text-xs text-green-700 font-medium">Valid</span>
      </div>
    );
  }

  if (status.isExpired) {
    return (
      <div className="flex items-center gap-1">
        <AlertTriangle size={12} className="text-red-500" />
        <span className="text-xs text-red-600 font-medium">Expired</span>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1">
      <AlertCircle size={12} className="text-red-500" />
      <span className="text-xs text-red-600 font-medium">Required</span>
    </div>
  );
};

export default HipaaComplianceWarning;
