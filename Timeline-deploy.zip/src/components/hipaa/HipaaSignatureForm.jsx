import React, { useState, useEffect } from 'react';
import { X, Shield, Check, AlertTriangle, User } from 'lucide-react';
import HipaaComplianceService from '../../services/hipaaComplianceService';
import SignatureCapture from '../ui/SignatureCapture';

const HipaaSignatureForm = ({ 
  patient, 
  onComplete, 
  onCancel,
  storeNumber,
  storeId,
  associateId,
  associateName
}) => {
  const [signatureData, setSignatureData] = useState(null);
  const [associateSupervised, setAssociateSupervised] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [clientIp, setClientIp] = useState('');
  const [deviceId, setDeviceId] = useState('');
  const [deviceType, setDeviceType] = useState('unknown');
  const [existingRecord, setExistingRecord] = useState(null);

  useEffect(() => {
    // Get client IP and device info on mount
    HipaaComplianceService.getClientIp().then(ip => setClientIp(ip));
    setDeviceId(HipaaComplianceService.generateDeviceId());
    setDeviceType(HipaaComplianceService.detectDeviceType());
    
    // Check for existing record
    const patientId = patient?.id || patient?.patientId || patient?.PatientId;
    if (patientId) {
      const record = HipaaComplianceService.getPatientRecord(patientId);
      setExistingRecord(record);
    }
  }, [patient]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    if (!signatureData?.isValid) {
      setError('Please provide the patient signature');
      return;
    }

    if (!associateSupervised) {
      setError('Please confirm that you supervised this signature');
      return;
    }

    setIsSubmitting(true);

    try {
      const patientId = patient.id || patient.patientId || patient.PatientId;
      const patientName = `${patient.firstName || patient.FirstName || ''} ${patient.lastName || patient.LastName || ''}`.trim();

      const record = HipaaComplianceService.captureSignature({
        patientId: patientId,
        patientUid: patient.uid || patient.patientUid || patient.PatientUid,
        patientName: patientName,
        signatureImage: signatureData.drawnSignature,
        signatureTyped: signatureData.typedSignature,
        signatureMethod: signatureData.method,
        deviceId: deviceId,
        deviceType: deviceType,
        ipAddress: clientIp,
        userAgent: navigator.userAgent,
        associateId: associateId || 'unknown',
        associateName: associateName || 'Unknown Associate',
        associateSupervised: associateSupervised,
        storeNumber: storeNumber,
        storeId: storeId,
      });

      console.log('[HIPAA] Signature captured:', record);
      onComplete?.(record);
    } catch (err) {
      console.error('[HIPAA] Error capturing signature:', err);
      setError('Failed to save signature. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const patientName = `${patient?.firstName || patient?.FirstName || ''} ${patient?.lastName || patient?.LastName || ''}`.trim();
  const isRenewal = existingRecord?.isExpired;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-[#1a5f7a]">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Shield size={20} />
            HIPAA Authorization Signature
          </h2>
          <button
            onClick={onCancel}
            className="text-white hover:text-gray-200 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Renewal Notice */}
        {isRenewal && (
          <div className="p-4 bg-amber-50 border-b border-amber-100">
            <div className="flex gap-2">
              <AlertTriangle size={20} className="text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-amber-800">
                <p className="font-semibold">Annual Renewal Required</p>
                <p className="mt-1">
                  The previous HIPAA signature has expired. Patient must sign again to continue.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* HIPAA Notice */}
        <div className="p-4 bg-blue-50 border-b border-blue-100">
          <div className="text-sm text-blue-800">
            <p className="font-semibold mb-2">Notice of Privacy Practices</p>
            <p>
              By signing below, I acknowledge that I have received a copy of this practice's 
              Notice of Privacy Practices, which describes how my health information may be 
              used and disclosed.
            </p>
            <p className="mt-2 text-xs text-blue-600">
              This authorization is valid for one (1) year from the date of signature.
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-5">
          {/* Patient Info */}
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-500">Patient</p>
                <p className="font-semibold text-gray-900">{patientName}</p>
              </div>
              <div>
                <p className="text-gray-500">Date</p>
                <p className="font-semibold text-gray-900">
                  {new Date().toLocaleDateString()}
                </p>
              </div>
            </div>
          </div>

          {/* HIPAA Agreement Text */}
          <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 max-h-40 overflow-y-auto text-xs text-gray-700">
            <p className="font-semibold mb-2">HIPAA Authorization Agreement:</p>
            <ul className="space-y-1 list-disc list-inside">
              <li>I understand that my health information is protected under HIPAA.</li>
              <li>I have been given the opportunity to review the Notice of Privacy Practices.</li>
              <li>I understand how my information may be used for treatment, payment, and healthcare operations.</li>
              <li>I understand my rights regarding my health information.</li>
              <li>I authorize this practice to use and disclose my health information as described.</li>
            </ul>
          </div>

          {/* Signature */}
          <SignatureCapture
            label="Patient Signature"
            signerName={patientName}
            allowedMethods={['draw', 'type']}
            requireBothMethods={false}
            height={140}
            onSignatureComplete={(data) => setSignatureData(data)}
            onClear={() => setSignatureData(null)}
          />

          {/* Associate Supervision Checkbox */}
          <div 
            onClick={() => setAssociateSupervised(!associateSupervised)}
            className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
              associateSupervised 
                ? 'border-[#1a5f7a] bg-[#1a5f7a]/5' 
                : 'border-gray-300 hover:border-gray-400'
            }`}
          >
            <div className="flex items-start gap-3">
              <div className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 mt-0.5 ${
                associateSupervised ? 'border-[#1a5f7a] bg-[#1a5f7a]' : 'border-gray-300'
              }`}>
                {associateSupervised && <Check size={12} className="text-white" />}
              </div>
              <div>
                <p className="font-semibold text-gray-900 flex items-center gap-2">
                  <User size={14} />
                  Associate Supervision Confirmation
                </p>
                <p className="text-sm text-gray-600 mt-1">
                  I, <strong>{associateName || 'Associate'}</strong>, confirm that I personally 
                  supervised this patient signing the HIPAA authorization.
                </p>
              </div>
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              {error}
            </div>
          )}

          {/* Submit */}
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !signatureData?.isValid || !associateSupervised}
              className="flex-1 px-4 py-3 bg-[#1a5f7a] text-white rounded-lg font-medium hover:bg-[#15505f] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? 'Saving...' : 'Complete Signature'}
            </button>
          </div>

          {/* Device Info */}
          <div className="text-xs text-gray-400 text-center space-y-1">
            <p>This signature is valid for 1 year from today.</p>
            <p>
              Device: {deviceType.toUpperCase()} | ID: {deviceId?.slice(0, 12)}... | IP: {clientIp || 'Detecting...'}
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default HipaaSignatureForm;
