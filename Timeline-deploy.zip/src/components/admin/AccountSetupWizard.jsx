/**
 * Account Setup Wizard
 * Multi-step onboarding flow for new accounts and companies
 */

import React, { useState } from 'react';
import { Building2, Globe, Key, Users, Check, ArrowRight, ArrowLeft } from 'lucide-react';
import { accountAccessor } from '../../lib/accessors/AccountAccessor';
import { companyAccessor } from '../../lib/accessors/CompanyAccessor';
import EyefinityIntegrationService from '../../lib/services/eyefinity-integration-service';

const STEPS = [
  { id: 'account', title: 'Account Setup', icon: Building2 },
  { id: 'company', title: 'Company Setup', icon: Globe },
  { id: 'eyefinity', title: 'Eyefinity Connection', icon: Key },
  { id: 'sync', title: 'Import Data', icon: Users },
];

export default function AccountSetupWizard({ onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  // Form data
  const [accountData, setAccountData] = useState({
    name: '',
    status: 'active',
  });
  
  const [companyData, setCompanyData] = useState({
    name: '',
    eyefinity_company_id: '',
    eyefinity_base_url: 'https://api-integration.eyefinity.com',
  });
  
  const [eyefinityAuth, setEyefinityAuth] = useState({
    auth_method: 'oauth', // 'oauth' or 'static'
    client_id: '',
    client_secret: '',
    company_key: '',
    oauth_host: 'pm-ci.eyefinity.com',
    api_url: 'https://pm-ci.eyefinity.com',
    api_path: 'al-pe',
    static_token: '',
  });
  
  const [syncResults, setSyncResults] = useState(null);
  const [createdAccountId, setCreatedAccountId] = useState(null);
  const [createdCompanyId, setCreatedCompanyId] = useState(null);

  // Step 1: Create Account
  const handleCreateAccount = async () => {
    setLoading(true);
    setError('');
    
    try {
      const result = await accountAccessor.create({
        name: accountData.name,
        status: accountData.status,
        settings: {},
      });
      
      if (!result.success) {
        throw new Error(result.error);
      }
      
      setCreatedAccountId(result.data.id);
      setCurrentStep(1);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Step 2: Create Company
  const handleCreateCompany = async () => {
    setLoading(true);
    setError('');
    
    try {
      const result = await companyAccessor.create({
        account_id: createdAccountId,
        name: companyData.name,
        eyefinity_company_id: companyData.eyefinity_company_id,
        eyefinity_base_url: companyData.eyefinity_base_url,
        settings: {},
      });
      
      if (!result.success) {
        throw new Error(result.error);
      }
      
      setCreatedCompanyId(result.data.id);
      setCurrentStep(2);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Step 3: Authenticate with Eyefinity
  const handleEyefinityAuth = async () => {
    setLoading(true);
    setError('');
    
    try {
      if (eyefinityAuth.auth_method === 'oauth') {
        // OAuth Flow: Authenticate to get tokens
        const tokenData = await EyefinityIntegrationService.authenticate(
          eyefinityAuth.client_id,
          eyefinityAuth.client_secret,
          eyefinityAuth.company_key,
          eyefinityAuth.oauth_host
        );
        
        // Update company with OAuth credentials and tokens
        await companyAccessor.update(createdCompanyId, {
          eyefinity_api_key: eyefinityAuth.client_id,
          eyefinity_api_secret: eyefinityAuth.client_secret,
          tenant_uid: eyefinityAuth.company_key,
          oauth_host: eyefinityAuth.oauth_host,
          api_base_url: eyefinityAuth.api_url,
          api_path: eyefinityAuth.api_path || 'al-pe',
          oauth_token: tokenData.access_token,
          oauth_refresh_token: tokenData.refresh_token,
          oauth_token_expires_at: new Date(
            Date.now() + tokenData.expires_in * 1000
          ).toISOString(),
        });
      } else {
        // Static Token: Just save the token
        await companyAccessor.update(createdCompanyId, {
          oauth_token: eyefinityAuth.static_token,
          api_base_url: eyefinityAuth.api_url || 'https://pm-ci.eyefinity.com',
          api_path: eyefinityAuth.api_path || 'al-pe',
          // No refresh token for static tokens
          oauth_refresh_token: null,
          oauth_token_expires_at: null,
        });
      }
      
      setCurrentStep(3);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Step 4: Import Data from Eyefinity
  const handleImportData = async () => {
    setLoading(true);
    setError('');
    
    try {
      const results = await EyefinityIntegrationService.fullSync(createdCompanyId);
      setSyncResults(results);
      
      // Wait a moment to show results
      setTimeout(() => {
        if (onComplete) {
          onComplete({
            accountId: createdAccountId,
            companyId: createdCompanyId,
          });
        }
      }, 3000);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const renderStepIndicator = () => (
    <div className="flex items-center justify-between mb-8">
      {STEPS.map((step, index) => {
        const Icon = step.icon;
        const isActive = index === currentStep;
        const isCompleted = index < currentStep;
        
        return (
          <React.Fragment key={step.id}>
            <div className="flex flex-col items-center">
              <div
                className={`w-12 h-12 rounded-full flex items-center justify-center border-2 ${
                  isCompleted
                    ? 'bg-green-500 border-green-500 text-white'
                    : isActive
                    ? 'bg-blue-500 border-blue-500 text-white'
                    : 'bg-gray-100 border-gray-300 text-gray-400'
                }`}
              >
                {isCompleted ? <Check className="w-6 h-6" /> : <Icon className="w-6 h-6" />}
              </div>
              <div className="mt-2 text-sm font-medium text-gray-700">{step.title}</div>
            </div>
            {index < STEPS.length - 1 && (
              <div
                className={`flex-1 h-0.5 mx-4 ${
                  isCompleted ? 'bg-green-500' : 'bg-gray-300'
                }`}
              />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );

  const renderAccountStep = () => (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-gray-900">Create Account</h2>
      <p className="text-gray-600">
        Set up your main account. This is the top-level organization that will contain all your companies and offices.
      </p>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Account Name *
        </label>
        <input
          type="text"
          value={accountData.name}
          onChange={(e) => setAccountData({ ...accountData, name: e.target.value })}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="e.g., Vision Care Group"
        />
      </div>
      
      <div className="flex justify-end gap-3 pt-4">
        <button
          onClick={handleCreateAccount}
          disabled={!accountData.name || loading}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2"
        >
          {loading ? 'Creating...' : 'Continue'}
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );

  const renderCompanyStep = () => (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-gray-900">Create Company</h2>
      <p className="text-gray-600">
        Add your first company/practice. Each company can have multiple office locations.
      </p>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Company Name *
        </label>
        <input
          type="text"
          value={companyData.name}
          onChange={(e) => setCompanyData({ ...companyData, name: e.target.value })}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="e.g., Downtown Eye Care"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Eyefinity Company ID *
        </label>
        <input
          type="text"
          value={companyData.eyefinity_company_id}
          onChange={(e) => setCompanyData({ ...companyData, eyefinity_company_id: e.target.value })}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="e.g., 936"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Eyefinity API URL
        </label>
        <input
          type="text"
          value={companyData.eyefinity_base_url}
          onChange={(e) => setCompanyData({ ...companyData, eyefinity_base_url: e.target.value })}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>
      
      <div className="flex justify-between gap-3 pt-4">
        <button
          onClick={() => setCurrentStep(0)}
          className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
        <button
          onClick={handleCreateCompany}
          disabled={!companyData.name || !companyData.eyefinity_company_id || loading}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2"
        >
          {loading ? 'Creating...' : 'Continue'}
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );

  const renderEyefinityStep = () => (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-gray-900">Connect to Eyefinity</h2>
      <p className="text-gray-600">
        Choose your authentication method and enter credentials.
      </p>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Authentication Method *
        </label>
        <div className="flex gap-4">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              value="oauth"
              checked={eyefinityAuth.auth_method === 'oauth'}
              onChange={(e) => setEyefinityAuth({ ...eyefinityAuth, auth_method: e.target.value })}
              className="w-4 h-4 text-blue-600"
            />
            <span>OAuth Flow (Client ID + Secret)</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              value="static"
              checked={eyefinityAuth.auth_method === 'static'}
              onChange={(e) => setEyefinityAuth({ ...eyefinityAuth, auth_method: e.target.value })}
              className="w-4 h-4 text-blue-600"
            />
            <span>Static Access Token</span>
          </label>
        </div>
      </div>
      
      {eyefinityAuth.auth_method === 'oauth' ? (
        <>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              EPM Client ID *
            </label>
            <input
              type="text"
              value={eyefinityAuth.client_id}
              onChange={(e) => setEyefinityAuth({ ...eyefinityAuth, client_id: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="ef-productmgmt-test-client"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              EPM Client Secret *
            </label>
            <input
              type="password"
              value={eyefinityAuth.client_secret}
              onChange={(e) => setEyefinityAuth({ ...eyefinityAuth, client_secret: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tenant UID *
            </label>
            <input
              type="text"
              value={eyefinityAuth.company_key}
              onChange={(e) => setEyefinityAuth({ ...eyefinityAuth, company_key: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="12345678-1234-1234-1234-123456789012"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              OAuth Host *
            </label>
            <input
              type="text"
              value={eyefinityAuth.oauth_host}
              onChange={(e) => setEyefinityAuth({ ...eyefinityAuth, oauth_host: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="api-sandbox.eyefinity.com"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              API Base URL *
            </label>
            <input
              type="text"
              value={eyefinityAuth.api_url}
              onChange={(e) => setEyefinityAuth({ ...eyefinityAuth, api_url: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="https://api-sandbox.eyefinity.com"
            />
          </div>
        </>
      ) : (
        <>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              API Base URL *
            </label>
            <input
              type="text"
              value={eyefinityAuth.api_url}
              onChange={(e) => setEyefinityAuth({ ...eyefinityAuth, api_url: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="https://pm-ci.eyefinity.com"
            />
            <p className="text-sm text-gray-500 mt-1">
              VPN/CI environment base URL (without path).
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              API Path *
            </label>
            <input
              type="text"
              value={eyefinityAuth.api_path}
              onChange={(e) => setEyefinityAuth({ ...eyefinityAuth, api_path: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="al-pe"
            />
            <p className="text-sm text-gray-500 mt-1">
              API path prefix (e.g., al-pe, api, v1). This varies by environment.
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Access Token *
            </label>
            <textarea
              value={eyefinityAuth.static_token}
              onChange={(e) => setEyefinityAuth({ ...eyefinityAuth, static_token: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
              rows={4}
              placeholder="eyJhbGciOiJIUzI1NiIsImtpZCI6IkFMRV9JTlQifQ..."
            />
            <p className="text-sm text-gray-500 mt-1">
              Paste your pre-generated Eyefinity access token. Note: Static tokens don't auto-refresh.
            </p>
          </div>
        </>
      )}
      
      <div className="flex justify-between gap-3 pt-4">
        <button
          onClick={() => setCurrentStep(1)}
          className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
        <button
          onClick={handleEyefinityAuth}
          disabled={
            loading || 
            (eyefinityAuth.auth_method === 'oauth' 
              ? (!eyefinityAuth.client_id || !eyefinityAuth.client_secret || !eyefinityAuth.company_key)
              : (!eyefinityAuth.static_token || !eyefinityAuth.api_url || !eyefinityAuth.api_path)
            )
          }
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2"
        >
          {loading ? 'Connecting...' : 'Authenticate'}
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );

  const renderSyncStep = () => (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-gray-900">Import Data</h2>
      <p className="text-gray-600">
        Import your offices, providers, and staff from Eyefinity.
      </p>
      
      {!syncResults ? (
        <div className="text-center py-8">
          <button
            onClick={handleImportData}
            disabled={loading}
            className="px-8 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 flex items-center gap-2 mx-auto"
          >
            {loading ? 'Importing Data...' : 'Start Import'}
            <Users className="w-5 h-5" />
          </button>
        </div>
      ) : (
        <div className="bg-green-50 border border-green-200 rounded-lg p-6">
          <div className="flex items-center gap-2 mb-4">
            <Check className="w-6 h-6 text-green-600" />
            <h3 className="text-lg font-semibold text-green-900">Import Complete!</h3>
          </div>
          
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-700">Offices Imported:</span>
              <span className="font-semibold">{syncResults.offices.imported}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-700">Providers Imported:</span>
              <span className="font-semibold">{syncResults.providers.imported}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-700">Staff Imported:</span>
              <span className="font-semibold">{syncResults.staff.imported}</span>
            </div>
          </div>
          
          {[...syncResults.offices.errors, ...syncResults.providers.errors, ...syncResults.staff.errors].length > 0 && (
            <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded">
              <p className="text-sm text-yellow-800 font-medium mb-1">Some items had errors:</p>
              <ul className="text-xs text-yellow-700 space-y-1">
                {[...syncResults.offices.errors, ...syncResults.providers.errors, ...syncResults.staff.errors]
                  .slice(0, 5)
                  .map((err, i) => (
                    <li key={i}>• {err}</li>
                  ))}
              </ul>
            </div>
          )}
          
          <p className="text-sm text-gray-600 mt-4">
            Redirecting to dashboard...
          </p>
        </div>
      )}
    </div>
  );

  return (
    <div className="max-w-3xl mx-auto p-8">
      <div className="bg-white rounded-xl shadow-lg p-8">
        {renderStepIndicator()}
        
        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        )}
        
        {currentStep === 0 && renderAccountStep()}
        {currentStep === 1 && renderCompanyStep()}
        {currentStep === 2 && renderEyefinityStep()}
        {currentStep === 3 && renderSyncStep()}
      </div>
    </div>
  );
}
