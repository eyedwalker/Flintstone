import React, { useState } from 'react';
import { AlertTriangle, Settings, X } from 'lucide-react';
import DemoModeService from '../../services/demoModeService';
import DemoModeAdmin from './DemoModeAdmin';

const DemoBanner = () => {
  const [showAdmin, setShowAdmin] = useState(false);
  const settings = DemoModeService.getSettings();

  if (!settings.enabled) return null;

  return (
    <>
      <div className="bg-amber-500 text-white px-4 py-2 flex items-center justify-between sticky top-0 z-[9998] shadow-md">
        <div className="flex items-center gap-3">
          <AlertTriangle size={20} className="animate-pulse" />
          <span className="font-bold text-lg tracking-wider">DEMO MODE</span>
          <span className="text-amber-100 text-sm hidden sm:inline">
            All messages redirect to: {settings.demoEmail} / {settings.demoPhone}
          </span>
        </div>
        <button
          onClick={() => setShowAdmin(true)}
          className="flex items-center gap-1 bg-amber-600 hover:bg-amber-700 px-3 py-1 rounded text-sm"
        >
          <Settings size={14} />
          <span className="hidden sm:inline">Settings</span>
        </button>
      </div>

      <DemoModeAdmin isOpen={showAdmin} onClose={() => setShowAdmin(false)} />
    </>
  );
};

export default DemoBanner;
