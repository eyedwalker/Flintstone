import React, { useState, useEffect } from 'react';
import { Mic, Volume2, Play, Check, X, Sliders, User, Sparkles } from 'lucide-react';

// Voice options with descriptions
const VOICE_OPTIONS = [
  { id: 'emily', name: 'Emily', style: 'Bright & Cheerful', description: 'Upbeat, enthusiastic, great for friendly service' },
  { id: 'amy', name: 'Amy', style: 'Very Expressive', description: 'Animated, warm, shows genuine interest' },
  { id: 'jessica', name: 'Jessica', style: 'Upbeat & Warm', description: 'Friendly, professional, approachable' },
  { id: 'sarah', name: 'Sarah', style: 'Friendly', description: 'Clear, professional, balanced energy' },
  { id: 'rachel', name: 'Rachel', style: 'Warm & Calm', description: 'Soothing, professional, reassuring' },
  { id: 'josh', name: 'Josh', style: 'Male - Warm', description: 'Friendly male voice, conversational' },
  { id: 'adam', name: 'Adam', style: 'Male - Professional', description: 'Deep, authoritative, clear' },
];

const VoiceSettings = ({ isOpen, onClose }) => {
  const [settings, setSettings] = useState({
    voiceName: 'emily',
    agentName: 'Emily',
    stability: 0.3,
    style: 0.55,
    voiceSpeed: 1.15,
    greeting: '',
  });
  const [isPlaying, setIsPlaying] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isOpen) {
      loadSettings();
    }
  }, [isOpen]);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/voice/settings');
      if (response.ok) {
        const data = await response.json();
        if (data.settings) {
          setSettings(data.settings);
        }
      }
    } catch (err) {
      console.error('Failed to load settings:', err);
    }
    setLoading(false);
  };

  const handleSave = async () => {
    setError('');
    setSaved(false);

    try {
      const response = await fetch('/api/voice/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });

      if (response.ok) {
        setSaved(true);
        setTimeout(() => {
          setSaved(false);
        }, 2000);
      } else {
        setError('Failed to save settings');
      }
    } catch (err) {
      setError('Failed to save settings: ' + err.message);
    }
  };

  const handleVoiceChange = (voiceId) => {
    const voice = VOICE_OPTIONS.find(v => v.id === voiceId);
    setSettings(prev => ({
      ...prev,
      voiceName: voiceId,
      agentName: voice?.name || voiceId,
    }));
  };

  const playPreview = async () => {
    setIsPlaying(true);
    try {
      const text = `Hi there! This is ${settings.agentName} from Vision Care Center. How can I help you today?`;
      const params = new URLSearchParams({
        voice: settings.voiceName,
        text,
        speed: settings.voiceSpeed.toString(),
        stability: settings.stability.toString(),
        style: settings.style.toString(),
      });
      const audio = new Audio(`/api/voice/generate-audio?${params.toString()}`);
      audio.onended = () => setIsPlaying(false);
      audio.onerror = () => setIsPlaying(false);
      await audio.play();
    } catch (err) {
      console.error('Preview failed:', err);
      setIsPlaying(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999]">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg mx-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-purple-50 to-blue-50 sticky top-0">
          <div className="flex items-center gap-2">
            <Mic className="text-purple-600" size={20} />
            <h2 className="font-bold text-lg">Voice AI Settings</h2>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={20} />
          </button>
        </div>

        {loading ? (
          <div className="p-8 text-center text-gray-500">Loading settings...</div>
        ) : (
          <div className="p-4 space-y-5">
            {/* Voice Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <User size={14} className="inline mr-1" />
                AI Assistant Voice
              </label>
              <div className="grid gap-2">
                {VOICE_OPTIONS.map(voice => (
                  <button
                    key={voice.id}
                    onClick={() => handleVoiceChange(voice.id)}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      settings.voiceName === voice.id
                        ? 'border-purple-500 bg-purple-50 ring-2 ring-purple-200'
                        : 'border-gray-200 hover:border-purple-300 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="font-medium">{voice.name}</span>
                        <span className="text-sm text-purple-600 ml-2">({voice.style})</span>
                      </div>
                      {settings.voiceName === voice.id && (
                        <Check size={18} className="text-purple-600" />
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{voice.description}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Preview Button */}
            <div className="flex justify-center">
              <button
                onClick={playPreview}
                disabled={isPlaying}
                className={`flex items-center gap-2 px-6 py-3 rounded-full font-medium transition-all ${
                  isPlaying
                    ? 'bg-purple-100 text-purple-400 cursor-wait'
                    : 'bg-purple-600 text-white hover:bg-purple-700 shadow-lg hover:shadow-xl'
                }`}
              >
                {isPlaying ? (
                  <>
                    <Volume2 size={18} className="animate-pulse" />
                    Playing...
                  </>
                ) : (
                  <>
                    <Play size={18} />
                    Preview Voice
                  </>
                )}
              </button>
            </div>

            {/* Voice Settings */}
            <div className="bg-gray-50 rounded-lg p-4 space-y-4">
              <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
                <Sliders size={14} />
                Voice Tuning
              </div>

              {/* Expressiveness (Stability inverse) */}
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Expressiveness</span>
                  <span className="text-purple-600">{Math.round((1 - settings.stability) * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={(1 - settings.stability) * 100}
                  onChange={(e) => setSettings(prev => ({ ...prev, stability: 1 - (e.target.value / 100) }))}
                  className="w-full accent-purple-600"
                />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>Steady</span>
                  <span>Dynamic</span>
                </div>
              </div>

              {/* Animation/Style */}
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Energy Level</span>
                  <span className="text-purple-600">{Math.round(settings.style * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={settings.style * 100}
                  onChange={(e) => setSettings(prev => ({ ...prev, style: e.target.value / 100 }))}
                  className="w-full accent-purple-600"
                />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>Calm</span>
                  <span>Energetic</span>
                </div>
              </div>

              {/* Voice Speed */}
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Voice Speed</span>
                  <span className="text-purple-600">{settings.voiceSpeed.toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min="0.8"
                  max="1.5"
                  step="0.05"
                  value={settings.voiceSpeed}
                  onChange={(e) => setSettings(prev => ({ ...prev, voiceSpeed: parseFloat(e.target.value) }))}
                  className="w-full accent-purple-600"
                />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>Slower (0.8x)</span>
                  <span>Normal (1.0x)</span>
                  <span>Faster (1.5x)</span>
                </div>
              </div>
            </div>

            {/* Agent Name Override */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Sparkles size={14} className="inline mr-1" />
                Agent Display Name
              </label>
              <input
                type="text"
                value={settings.agentName}
                onChange={(e) => setSettings(prev => ({ ...prev, agentName: e.target.value }))}
                placeholder="Emily"
                className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <p className="text-xs text-gray-500 mt-1">Name used in greeting: "This is [Name], your virtual assistant"</p>
            </div>

            {/* Error */}
            {error && (
              <div className="text-red-600 text-sm bg-red-50 p-2 rounded flex items-center gap-2">
                <X size={16} />
                {error}
              </div>
            )}

            {/* Success */}
            {saved && (
              <div className="text-green-600 text-sm bg-green-50 p-2 rounded flex items-center gap-2">
                <Check size={16} />
                Settings saved successfully!
              </div>
            )}
          </div>
        )}

        {/* Footer */}
        <div className="flex justify-end gap-2 p-4 border-t bg-gray-50 sticky bottom-0">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={loading}
            className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 flex items-center gap-2 disabled:opacity-50"
          >
            <Check size={16} />
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
};

export default VoiceSettings;
