import React, { useState, useEffect } from 'react';
import { AdminSettingsService, getAvailableEnvironments } from '../../services/adminSettingsService';
import { Globe, ChevronDown, Check, Wifi, WifiOff } from 'lucide-react';

const ENV_COLORS = {
  sandbox: 'bg-green-500',
  integration: 'bg-blue-500',
  staging: 'bg-yellow-500',
  production: 'bg-red-500',
};

function EnvironmentSwitcher({ compact = false }) {
  const [isOpen, setIsOpen] = useState(false);
  const [currentEnv, setCurrentEnv] = useState('sandbox');
  const [syncing, setSyncing] = useState(false);
  
  const environments = getAvailableEnvironments();

  useEffect(() => {
    // Load current environment from settings
    let settings = AdminSettingsService.getSettings();
    if (!settings) {
      settings = AdminSettingsService.initializeDefaults();
    }
    setCurrentEnv(settings?.company?.apiEnvironment || 'sandbox');
  }, []);

  const handleEnvChange = async (env) => {
    setSyncing(true);
    setCurrentEnv(env);
    
    // Update settings and sync to proxy
    AdminSettingsService.setApiEnvironment(env);
    
    // Small delay for visual feedback
    setTimeout(() => {
      setSyncing(false);
      setIsOpen(false);
    }, 500);
  };

  const currentConfig = environments[currentEnv];
  const needsVpn = currentEnv === 'integration';

  if (compact) {
    return (
      <div className="relative">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium text-white ${ENV_COLORS[currentEnv]} hover:opacity-90`}
        >
          <span className="w-2 h-2 rounded-full bg-white/50 animate-pulse" />
          {currentEnv.toUpperCase()}
          <ChevronDown size={12} />
        </button>
        
        {isOpen && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
            <div className="absolute right-0 top-full mt-1 w-56 bg-white rounded-lg shadow-xl border border-gray-200 z-50 overflow-hidden">
              <div className="p-2 bg-gray-50 border-b text-sm font-medium text-gray-700">
                Switch API Environment
              </div>
              {Object.entries(environments).map(([key, config]) => (
                <button
                  key={key}
                  onClick={() => handleEnvChange(key)}
                  disabled={syncing}
                  className={`w-full flex items-center justify-between px-3 py-2 text-base hover:bg-gray-50 disabled:opacity-100 disabled:text-gray-500 disabled:bg-gray-50 disabled:cursor-not-allowed ${
                    currentEnv === key ? 'bg-blue-50' : ''
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${ENV_COLORS[key]}`} />
                    <span>{config.label}</span>
                  </div>
                  {currentEnv === key && <Check size={14} className="text-blue-600" />}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    );
  }

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-3 px-4 py-2 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 shadow-sm"
      >
        <div className="flex items-center gap-2">
          <Globe size={16} className="text-gray-500" />
          <span className={`w-2 h-2 rounded-full ${ENV_COLORS[currentEnv]}`} />
          <span className="font-medium text-gray-900">{currentConfig?.label || currentEnv}</span>
        </div>
        {needsVpn ? (
          <WifiOff size={14} className="text-orange-500" title="VPN Required" />
        ) : (
          <Wifi size={14} className="text-green-500" title="No VPN Needed" />
        )}
        <ChevronDown size={16} className="text-gray-400" />
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
          <div className="absolute left-0 top-full mt-2 w-72 bg-white rounded-xl shadow-xl border border-gray-200 z-50 overflow-hidden">
            <div className="p-3 bg-gradient-to-r from-gray-50 to-gray-100 border-b">
              <h4 className="font-semibold text-gray-900">API Environment</h4>
              <p className="text-xs text-gray-500">Select which Eyefinity environment to use</p>
            </div>
            
            <div className="p-2">
              {Object.entries(environments).map(([key, config]) => {
                const isVpn = key === 'integration';
                const isSelected = currentEnv === key;
                
                return (
                  <button
                    key={key}
                    onClick={() => handleEnvChange(key)}
                    disabled={syncing || !config.clientSecret}
                    className={`w-full flex items-center justify-between p-3 rounded-lg text-left transition-colors ${
                      isSelected 
                        ? 'bg-blue-50 border border-blue-200' 
                        : 'hover:bg-gray-50 border border-transparent'
                    } ${!config.clientSecret ? 'cursor-not-allowed text-gray-500 bg-gray-50' : ''} disabled:opacity-100`}
                  >
                    <div className="flex items-center gap-3">
                      <span className={`w-3 h-3 rounded-full ${ENV_COLORS[key]}`} />
                      <div>
                        <div className="font-medium text-gray-900 text-base">{config.label}</div>
                        <div className="text-sm text-gray-600">{config.apiBaseUrl}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {isVpn ? (
                        <span className="text-xs px-2 py-0.5 bg-orange-100 text-orange-700 rounded">VPN</span>
                      ) : (
                        <span className="text-xs px-2 py-0.5 bg-green-100 text-green-700 rounded">Public</span>
                      )}
                      {isSelected && <Check size={16} className="text-blue-600" />}
                    </div>
                  </button>
                );
              })}
            </div>

            {syncing && (
              <div className="p-3 bg-blue-50 border-t text-center text-sm text-blue-700">
                Switching environment...
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}

export default EnvironmentSwitcher;
