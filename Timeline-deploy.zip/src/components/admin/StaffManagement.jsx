/**
 * Staff Management Component
 * Manage staff members, providers, and their office assignments
 */

import React, { useState, useEffect } from 'react';
import { Users, Plus, Edit, Trash2, Building2, RefreshCw, UserCheck } from 'lucide-react';
import { staffAccessor } from '../../lib/accessors/StaffAccessor';
import { officeAccessor } from '../../lib/accessors/OfficeAccessor';
import EyefinityIntegrationService from '../../lib/services/eyefinity-integration-service';

const ROLE_LABELS = {
  doctor: 'Doctor',
  technician: 'Technician',
  optician: 'Optician',
  front_desk: 'Front Desk',
  manager: 'Manager',
  other: 'Other',
};

const ROLE_COLORS = {
  doctor: 'bg-purple-100 text-purple-700',
  technician: 'bg-blue-100 text-blue-700',
  optician: 'bg-green-100 text-green-700',
  front_desk: 'bg-yellow-100 text-yellow-700',
  manager: 'bg-red-100 text-red-700',
  other: 'bg-gray-100 text-gray-700',
};

export default function StaffManagement({ companyId }) {
  const [staff, setStaff] = useState([]);
  const [offices, setOffices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [error, setError] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedStaff, setSelectedStaff] = useState(null);
  const [filterRole, setFilterRole] = useState('all');

  useEffect(() => {
    loadData();
  }, [companyId]);

  const loadData = async () => {
    try {
      const [staffResult, officesResult] = await Promise.all([
        staffAccessor.getByCompany(companyId),
        officeAccessor.getByCompany(companyId),
      ]);
      
      if (staffResult.success) setStaff(staffResult.data);
      if (officesResult.success) setOffices(officesResult.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSyncProviders = async () => {
    setSyncing(true);
    setError('');
    
    try {
      const result = await EyefinityIntegrationService.importProviders(companyId);
      
      if (result.imported > 0) {
        await loadData();
      }
      
      alert(`Imported ${result.imported} providers${result.errors.length > 0 ? ` with ${result.errors.length} errors` : ''}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setSyncing(false);
    }
  };

  const handleSyncStaff = async () => {
    setSyncing(true);
    setError('');
    
    try {
      const result = await EyefinityIntegrationService.importStaff(companyId);
      
      if (result.imported > 0) {
        await loadData();
      }
      
      alert(`Imported ${result.imported} staff${result.errors.length > 0 ? ` with ${result.errors.length} errors` : ''}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setSyncing(false);
    }
  };

  const handleDelete = async (staffId) => {
    if (!confirm('Are you sure you want to deactivate this staff member?')) return;
    
    try {
      await staffAccessor.delete(staffId);
      await loadData();
    } catch (err) {
      setError(err.message);
    }
  };

  const filteredStaff = filterRole === 'all' 
    ? staff 
    : staff.filter(s => s.role === filterRole);

  if (loading) {
    return <div className="text-center py-8">Loading staff...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-bold text-gray-900">Staff & Providers</h2>
          <select
            value={filterRole}
            onChange={(e) => setFilterRole(e.target.value)}
            className="px-3 py-1 border border-gray-300 rounded-lg text-sm"
          >
            <option value="all">All Roles</option>
            {Object.entries(ROLE_LABELS).map(([value, label]) => (
              <option key={value} value={value}>{label}</option>
            ))}
          </select>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleSyncProviders}
            disabled={syncing}
            className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 flex items-center gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
            Sync Providers
          </button>
          <button
            onClick={handleSyncStaff}
            disabled={syncing}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
            Sync Staff
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Add Staff
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredStaff.map((member) => (
          <StaffCard
            key={member.id}
            staff={member}
            offices={offices}
            onEdit={setSelectedStaff}
            onDelete={handleDelete}
            onReload={loadData}
          />
        ))}
      </div>

      {filteredStaff.length === 0 && (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <Users className="w-12 h-12 text-gray-400 mx-auto mb-3" />
          <p className="text-gray-600 mb-4">No staff members found</p>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Add Your First Staff Member
          </button>
        </div>
      )}

      {showAddModal && (
        <StaffModal
          staff={null}
          offices={offices}
          onClose={() => setShowAddModal(false)}
          onSave={() => {
            setShowAddModal(false);
            loadData();
          }}
        />
      )}

      {selectedStaff && (
        <StaffModal
          staff={selectedStaff}
          offices={offices}
          onClose={() => setSelectedStaff(null)}
          onSave={() => {
            setSelectedStaff(null);
            loadData();
          }}
        />
      )}
    </div>
  );
}

function StaffCard({ staff, offices, onEdit, onDelete, onReload }) {
  const [assignedOffices, setAssignedOffices] = useState([]);
  const [showAssignModal, setShowAssignModal] = useState(false);

  useEffect(() => {
    loadAssignedOffices();
  }, [staff.id]);

  const loadAssignedOffices = async () => {
    const result = await staffAccessor.getWithOffices(staff.id);
    if (result.success && result.data.offices) {
      setAssignedOffices(result.data.offices);
    }
  };

  return (
    <>
      <div className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-blue-600" />
            <div>
              <h3 className="font-semibold text-gray-900">{staff.name}</h3>
              <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${ROLE_COLORS[staff.role]}`}>
                {ROLE_LABELS[staff.role]}
              </span>
            </div>
          </div>
          <div className="flex gap-1">
            <button
              onClick={() => onEdit(staff)}
              className="p-1 text-gray-400 hover:text-blue-600"
            >
              <Edit className="w-4 h-4" />
            </button>
            <button
              onClick={() => onDelete(staff.id)}
              className="p-1 text-gray-400 hover:text-red-600"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="space-y-2 text-sm text-gray-600">
          {staff.email && <div>{staff.email}</div>}
          {staff.phone && <div>{staff.phone}</div>}
          {staff.specialty && (
            <div className="text-xs text-gray-500">Specialty: {staff.specialty}</div>
          )}
          
          <div className="pt-2 border-t">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1">
                <Building2 className="w-4 h-4" />
                <span>{assignedOffices.length} office{assignedOffices.length !== 1 ? 's' : ''}</span>
              </div>
              <button
                onClick={() => setShowAssignModal(true)}
                className="text-xs text-blue-600 hover:text-blue-700"
              >
                Manage
              </button>
            </div>
            {assignedOffices.length > 0 && (
              <div className="mt-1 text-xs text-gray-500">
                {assignedOffices.map(o => o.name).join(', ')}
              </div>
            )}
          </div>
        </div>
      </div>

      {showAssignModal && (
        <OfficeAssignmentModal
          staff={staff}
          offices={offices}
          assignedOffices={assignedOffices}
          onClose={() => {
            setShowAssignModal(false);
            loadAssignedOffices();
          }}
          onSave={() => {
            setShowAssignModal(false);
            loadAssignedOffices();
            onReload();
          }}
        />
      )}
    </>
  );
}

function StaffModal({ staff, offices, onClose, onSave }) {
  const [formData, setFormData] = useState({
    name: staff?.name || '',
    email: staff?.email || '',
    phone: staff?.phone || '',
    role: staff?.role || 'technician',
    specialty: staff?.specialty || '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');

    try {
      if (staff) {
        await staffAccessor.update(staff.id, formData);
      } else {
        await staffAccessor.create({
          ...formData,
          active: true,
          settings: {},
        });
      }
      onSave();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
        <h3 className="text-xl font-bold text-gray-900 mb-4">
          {staff ? 'Edit Staff Member' : 'Add New Staff Member'}
        </h3>

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded text-red-700 text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Name *
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Role *
            </label>
            <select
              value={formData.role}
              onChange={(e) => setFormData({ ...formData, role: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              required
            >
              {Object.entries(ROLE_LABELS).map(([value, label]) => (
                <option key={value} value={value}>{label}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Phone
            </label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Specialty
            </label>
            <input
              type="text"
              value={formData.specialty}
              onChange={(e) => setFormData({ ...formData, specialty: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="e.g., Optometry, Ophthalmology"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {saving ? 'Saving...' : staff ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function OfficeAssignmentModal({ staff, offices, assignedOffices, onClose, onSave }) {
  const [selectedOffices, setSelectedOffices] = useState(
    new Set(assignedOffices.map(o => o.id))
  );
  const [saving, setSaving] = useState(false);

  const handleToggle = (officeId) => {
    const newSet = new Set(selectedOffices);
    if (newSet.has(officeId)) {
      newSet.delete(officeId);
    } else {
      newSet.add(officeId);
    }
    setSelectedOffices(newSet);
  };

  const handleSave = async () => {
    setSaving(true);
    
    try {
      // Remove old assignments
      for (const office of assignedOffices) {
        if (!selectedOffices.has(office.id)) {
          await staffAccessor.removeFromOffice(staff.id, office.id);
        }
      }
      
      // Add new assignments
      for (const officeId of selectedOffices) {
        if (!assignedOffices.find(o => o.id === officeId)) {
          await staffAccessor.assignToOffice(staff.id, officeId);
        }
      }
      
      onSave();
    } catch (err) {
      alert(`Error: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
        <h3 className="text-xl font-bold text-gray-900 mb-4">
          Assign {staff.name} to Offices
        </h3>

        <div className="space-y-2 max-h-96 overflow-y-auto">
          {offices.map((office) => (
            <label
              key={office.id}
              className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer"
            >
              <input
                type="checkbox"
                checked={selectedOffices.has(office.id)}
                onChange={() => handleToggle(office.id)}
                className="w-4 h-4 text-blue-600"
              />
              <div className="flex-1">
                <div className="font-medium text-gray-900">{office.name}</div>
                {office.address?.city && (
                  <div className="text-sm text-gray-500">
                    {office.address.city}, {office.address.state}
                  </div>
                )}
              </div>
            </label>
          ))}
        </div>

        <div className="flex justify-end gap-3 pt-4 mt-4 border-t">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            {saving ? 'Saving...' : 'Save Assignments'}
          </button>
        </div>
      </div>
    </div>
  );
}
