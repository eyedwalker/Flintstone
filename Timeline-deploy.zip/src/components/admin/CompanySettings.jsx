/**
 * Company Settings
 * Edit company information and Eyefinity integration
 */

import React, { useState, useEffect } from 'react';
import { Save, Key, AlertCircle, CheckCircle, RefreshCw } from 'lucide-react';
import { companyAccessor } from '../../lib/accessors/CompanyAccessor';
import EyefinityIntegrationService from '../../lib/services/eyefinity-integration-service';

export default function CompanySettings({ company, onUpdate }) {
  const [formData, setFormData] = useState({
    name: '',
    eyefinity_company_id: '',
    eyefinity_base_url: '',
    auth_method: 'oauth',
    client_id: '',
    client_secret: '',
    tenant_uid: '',
    oauth_host: '',
    api_base_url: '',
    static_token: '',
  });
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [testing, setTesting] = useState(false);

  useEffect(() => {
    // Only load form data once when company ID changes
    if (company && company.id) {
      // Detect auth method: OAuth if has credentials OR refresh token, Static if has token without OAuth creds
      const hasOAuthCreds = company.eyefinity_api_key && company.eyefinity_api_secret && company.tenant_uid;
      const hasRefreshToken = company.oauth_refresh_token;
      const hasStaticToken = company.oauth_token && !hasRefreshToken && !hasOAuthCreds;
      
      setFormData({
        name: company.name || '',
        eyefinity_company_id: company.eyefinity_company_id || '',
        eyefinity_base_url: company.eyefinity_base_url || '',
        auth_method: (hasOAuthCreds || hasRefreshToken) ? 'oauth' : (hasStaticToken ? 'static' : 'oauth'),
        client_id: company.eyefinity_api_key || '',
        client_secret: company.eyefinity_api_secret || '',
        tenant_uid: company.tenant_uid || '',
        oauth_host: company.oauth_host || 'pm-ci.eyefinity.com',
        api_base_url: company.api_base_url || 'https://pm-ci.eyefinity.com',
        api_path: company.api_path || 'al-pe',
        static_token: hasStaticToken ? company.oauth_token : '',
      });
    }
  }, [company?.id]); // Only re-run when switching companies, not on every update

  const handleSaveBasicInfo = async () => {
    setLoading(true);
    setError('');
    setSuccess('');
    
    try {
      await companyAccessor.update(company.id, {
        name: formData.name,
        eyefinity_company_id: formData.eyefinity_company_id,
        eyefinity_base_url: formData.eyefinity_base_url,
      });
      
      setSuccess('Company information updated successfully');
      if (onUpdate) onUpdate();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveOAuthSettings = async () => {
    setLoading(true);
    setError('');
    setSuccess('');
    
    try {
      console.log('Saving auth settings...');
      
      let updateData;
      
      if (formData.auth_method === 'static') {
        // Static token: Save token and clear OAuth credentials
        updateData = {
          oauth_token: formData.static_token,
          api_base_url: formData.api_base_url,
          api_path: formData.api_path || 'al-pe',
          oauth_host: formData.oauth_host,
          eyefinity_api_key: null,
          eyefinity_api_secret: null,
          tenant_uid: null,
          oauth_refresh_token: null,
          oauth_token_expires_at: null,
        };
      } else {
        // OAuth: Save credentials without token (will be generated on connect)
        updateData = {
          eyefinity_api_key: formData.client_id,
          eyefinity_api_secret: formData.client_secret,
          tenant_uid: formData.tenant_uid,
          oauth_host: formData.oauth_host,
          api_base_url: formData.api_base_url,
          api_path: formData.api_path || 'al-pe',
        };
      }
      
      const result = await companyAccessor.update(company.id, updateData);
      
      if (!result.success) {
        throw new Error(result.error || 'Failed to save settings');
      }
      
      setSuccess(
        formData.auth_method === 'static' 
          ? 'Static token saved successfully!' 
          : 'OAuth settings saved successfully! Click "Connect to Eyefinity" to authenticate.'
      );
      if (onUpdate) await onUpdate();
    } catch (err) {
      console.error('Save settings error:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleConnectEyefinity = async () => {
    setLoading(true);
    setError('');
    setSuccess('');
    
    try {
      // Settings must be saved first (either via Save Settings button or here)
      // Just save the credentials to the database - the existing proxy handles OAuth
      const updateData = {
        eyefinity_api_key: formData.client_id,
        eyefinity_api_secret: formData.client_secret,
        tenant_uid: formData.tenant_uid,
        oauth_host: formData.oauth_host,
        api_base_url: formData.api_base_url,
      };
      
      const result = await companyAccessor.update(company.id, updateData);
      
      if (!result.success) {
        throw new Error(result.error || 'Failed to save credentials');
      }
      
      setSuccess('Eyefinity credentials saved! Use "Test Connection" to verify.');
      
      // Only reload if successful
      if (onUpdate) await onUpdate();
    } catch (err) {
      console.error('Eyefinity save error:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    // Manually reload from database
    if (company) {
      setFormData({
        name: company.name || '',
        eyefinity_company_id: company.eyefinity_company_id || '',
        eyefinity_base_url: company.eyefinity_base_url || '',
        auth_method: company.oauth_refresh_token ? 'oauth' : 'static',
        client_id: company.eyefinity_api_key || '',
        client_secret: company.eyefinity_api_secret || '',
        tenant_uid: company.tenant_uid || '',
        oauth_host: company.oauth_host || 'api-sandbox.eyefinity.com',
        api_base_url: company.api_base_url || 'https://api-sandbox.eyefinity.com',
        static_token: company.oauth_token && !company.oauth_refresh_token ? company.oauth_token : '',
      });
      setError('');
      setSuccess('Form reset to saved values');
    }
  };

  const handleTestConnection = async () => {
    setTesting(true);
    setError('');
    setSuccess('');
    
    try {
      // Test by fetching providers
      const result = await EyefinityIntegrationService.importProviders(company.id);
      setSuccess(`Connection successful! Found ${result.imported} providers.`);
    } catch (err) {
      setError(`Connection test failed: ${err.message}`);
    } finally {
      setTesting(false);
    }
  };

  const hasOAuthConfig = company?.oauth_refresh_token;
  const hasStaticToken = company?.oauth_token && !company?.oauth_refresh_token;
  const isConnected = company?.oauth_token;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-1">Company Settings</h2>
        <p className="text-gray-600">Manage company information and API integrations</p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-start gap-2">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg flex items-start gap-2">
          <CheckCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <span>{success}</span>
        </div>
      )}

      {/* Basic Information */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Basic Information</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Company Name *
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Eyefinity Company ID
            </label>
            <input
              type="text"
              value={formData.eyefinity_company_id}
              onChange={(e) => setFormData({ ...formData, eyefinity_company_id: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Eyefinity Base URL
            </label>
            <input
              type="text"
              value={formData.eyefinity_base_url}
              onChange={(e) => setFormData({ ...formData, eyefinity_base_url: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <button
            onClick={handleSaveBasicInfo}
            disabled={loading || !formData.name}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            {loading ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>

      {/* Eyefinity Integration */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Eyefinity Integration</h3>
            <p className="text-sm text-gray-600 mt-1">
              OAuth Status: {isConnected ? (
                <span className="text-green-600 font-medium">
                  {hasOAuthConfig ? '✓ Connected (Auto-refresh)' : '✓ Connected (Static Token)'}
                </span>
              ) : (
                <span className="text-red-600 font-medium">✗ Not connected</span>
              )}
            </p>
          </div>
          {isConnected && (
            <button
              onClick={handleTestConnection}
              disabled={testing}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 flex items-center gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${testing ? 'animate-spin' : ''}`} />
              {testing ? 'Testing...' : 'Test Connection'}
            </button>
          )}
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Authentication Method
            </label>
            <div className="flex gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  value="oauth"
                  checked={formData.auth_method === 'oauth'}
                  onChange={(e) => setFormData({ ...formData, auth_method: e.target.value })}
                  className="w-4 h-4 text-blue-600"
                />
                <span>OAuth Flow (Auto-refresh)</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  value="static"
                  checked={formData.auth_method === 'static'}
                  onChange={(e) => setFormData({ ...formData, auth_method: e.target.value })}
                  className="w-4 h-4 text-blue-600"
                />
                <span>Static Token</span>
              </label>
            </div>
          </div>

          {formData.auth_method === 'oauth' ? (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  EPM Client ID *
                </label>
                <input
                  type="text"
                  value={formData.client_id}
                  onChange={(e) => setFormData({ ...formData, client_id: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="ef-productmgmt-test-client"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  EPM Client Secret *
                </label>
                <input
                  type="password"
                  value={formData.client_secret}
                  onChange={(e) => setFormData({ ...formData, client_secret: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tenant UID *
                </label>
                <input
                  type="text"
                  value={formData.tenant_uid}
                  onChange={(e) => setFormData({ ...formData, tenant_uid: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="12345678-1234-1234-1234-123456789012"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  OAuth Host
                </label>
                <input
                  type="text"
                  value={formData.oauth_host}
                  onChange={(e) => setFormData({ ...formData, oauth_host: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="api-sandbox.eyefinity.com"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  API Base URL
                </label>
                <input
                  type="text"
                  value={formData.api_base_url}
                  onChange={(e) => setFormData({ ...formData, api_base_url: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="https://api-sandbox.eyefinity.com"
                />
              </div>
            </>
          ) : (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  API Base URL *
                </label>
                <input
                  type="text"
                  value={formData.api_base_url}
                  onChange={(e) => setFormData({ ...formData, api_base_url: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="https://pm-ci.eyefinity.com"
                />
                <p className="text-sm text-gray-500 mt-1">
                  VPN/CI environment base URL (without path).
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  API Path *
                </label>
                <input
                  type="text"
                  value={formData.api_path}
                  onChange={(e) => setFormData({ ...formData, api_path: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="al-pe"
                />
                <p className="text-sm text-gray-500 mt-1">
                  API path prefix (e.g., al-pe, api, v1). This varies by environment.
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Access Token *
                </label>
                <textarea
                  value={formData.static_token}
                  onChange={(e) => setFormData({ ...formData, static_token: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
                  rows={4}
                  placeholder="eyJhbGciOiJIUzI1NiIsImtpZCI6IkFMRV9JTlQifQ..."
                />
                <p className="text-sm text-gray-500 mt-1">
                  Paste your pre-generated Eyefinity access token. Note: Static tokens don't auto-refresh.
                </p>
              </div>
            </>
          )}
          
          <div className="flex gap-3">
            <button
              onClick={handleSaveOAuthSettings}
              disabled={
                loading || 
                (formData.auth_method === 'oauth' 
                  ? (!formData.client_id || !formData.client_secret || !formData.tenant_uid)
                  : (!formData.static_token || !formData.api_base_url || !formData.api_path)
                )
              }
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              {loading ? 'Saving...' : 'Save Settings'}
            </button>
            
            <button
              onClick={handleConnectEyefinity}
              disabled={
                loading || 
                (formData.auth_method === 'oauth' && (!formData.client_id || !formData.client_secret || !formData.tenant_uid)) || 
                (formData.auth_method === 'static' && (!formData.static_token || !formData.api_base_url || !formData.api_path))
              }
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 flex items-center gap-2"
            >
              <Key className="w-4 h-4" />
              {loading ? 'Connecting...' : isConnected ? 'Update Connection' : 'Connect to Eyefinity'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
