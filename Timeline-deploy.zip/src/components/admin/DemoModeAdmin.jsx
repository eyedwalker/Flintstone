import React, { useState, useEffect } from 'react';
import { Settings, AlertTriangle, Check, X, Phone, Mail, Shield } from 'lucide-react';
import DemoModeService from '../../services/demoModeService';

const DemoModeAdmin = ({ isOpen, onClose }) => {
  const [enabled, setEnabled] = useState(false);
  const [demoEmail, setDemoEmail] = useState('');
  const [demoPhone, setDemoPhone] = useState('');
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const settings = DemoModeService.getSettings();
      setEnabled(settings.enabled);
      setDemoEmail(settings.demoEmail);
      setDemoPhone(settings.demoPhone);
      setError('');
      setSaved(false);
    }
  }, [isOpen]);

  const handleSave = () => {
    setError('');
    setSaved(false);

    if (enabled) {
      if (!demoEmail.trim()) {
        setError('Demo email is required when demo mode is enabled');
        return;
      }
      if (!demoPhone.trim()) {
        setError('Demo phone is required when demo mode is enabled');
        return;
      }
      if (!demoEmail.includes('@')) {
        setError('Please enter a valid email address');
        return;
      }
      DemoModeService.enable(demoEmail.trim(), demoPhone.trim());
    } else {
      DemoModeService.disable();
    }

    setSaved(true);
    setTimeout(() => {
      onClose();
      window.location.reload();
    }, 1000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999]">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-4">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b bg-amber-50">
          <div className="flex items-center gap-2">
            <Shield className="text-amber-600" size={20} />
            <h2 className="font-bold text-lg">Demo Mode Settings</h2>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Warning */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex gap-2">
            <AlertTriangle className="text-amber-600 flex-shrink-0 mt-0.5" size={18} />
            <div className="text-sm text-amber-800">
              <strong>Important:</strong> When demo mode is enabled, ALL emails and SMS messages 
              will be redirected to the configured demo addresses. No messages will reach actual patients.
            </div>
          </div>

          {/* Enable Toggle */}
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div>
              <div className="font-medium">Demo Mode</div>
              <div className="text-sm text-gray-500">Redirect all communications</div>
            </div>
            <button
              onClick={() => setEnabled(!enabled)}
              className={`relative w-14 h-7 rounded-full transition-colors ${
                enabled ? 'bg-amber-500' : 'bg-gray-300'
              }`}
            >
              <div
                className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                  enabled ? 'translate-x-8' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Demo Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Mail size={14} className="inline mr-1" />
              Demo Email Address
            </label>
            <input
              type="email"
              value={demoEmail}
              onChange={(e) => setDemoEmail(e.target.value)}
              placeholder="demo@example.com"
              disabled={!enabled}
              className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                !enabled ? 'bg-gray-100 text-gray-400' : ''
              }`}
            />
            <p className="text-xs text-gray-500 mt-1">All emails will be sent to this address</p>
          </div>

          {/* Demo Phone */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Phone size={14} className="inline mr-1" />
              Demo Phone Number
            </label>
            <input
              type="tel"
              value={demoPhone}
              onChange={(e) => setDemoPhone(e.target.value)}
              placeholder="+1234567890"
              disabled={!enabled}
              className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                !enabled ? 'bg-gray-100 text-gray-400' : ''
              }`}
            />
            <p className="text-xs text-gray-500 mt-1">All SMS messages will be sent to this number</p>
          </div>

          {/* Error */}
          {error && (
            <div className="text-red-600 text-sm bg-red-50 p-2 rounded flex items-center gap-2">
              <X size={16} />
              {error}
            </div>
          )}

          {/* Success */}
          {saved && (
            <div className="text-green-600 text-sm bg-green-50 p-2 rounded flex items-center gap-2">
              <Check size={16} />
              Settings saved! Refreshing...
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-2 p-4 border-t bg-gray-50">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 flex items-center gap-2"
          >
            <Check size={16} />
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
};

export default DemoModeAdmin;
