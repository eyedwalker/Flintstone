/**
 * Admin Dashboard
 * Main hub for account, company, office, and staff management
 */

import React, { useState, useEffect } from 'react';
import { Building2, MapPin, Users, Settings, Database, TrendingUp, ChevronLeft, Home } from 'lucide-react';
import { Link } from 'react-router-dom';
import AccountSetupWizard from './AccountSetupWizard';
import OfficeManagement from './OfficeManagement';
import StaffManagement from './StaffManagement';
import CompanySettings from './CompanySettings';
import { accountAccessor } from '../../lib/accessors/AccountAccessor';
import { companyAccessor } from '../../lib/accessors/CompanyAccessor';

const TABS = {
  overview: 'Overview',
  offices: 'Offices',
  staff: 'Staff & Providers',
  settings: 'Settings',
};

export default function AdminDashboard() {
  const [currentAccount, setCurrentAccount] = useState(null);
  const [currentCompany, setCurrentCompany] = useState(null);
  const [accounts, setAccounts] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [activeTab, setActiveTab] = useState('overview');
  const [showSetupWizard, setShowSetupWizard] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      // Load accounts
      const accountsResult = await accountAccessor.getAll();
      if (accountsResult.success && accountsResult.data.length > 0) {
        setAccounts(accountsResult.data);
        
        // Set first account as current if none selected
        if (!currentAccount) {
          const firstAccount = accountsResult.data[0];
          setCurrentAccount(firstAccount);
          
          // Load companies for this account
          const companiesResult = await companyAccessor.getByAccount(firstAccount.id);
          if (companiesResult.success && companiesResult.data.length > 0) {
            setCompanies(companiesResult.data);
            setCurrentCompany(companiesResult.data[0]);
          }
        }
      } else {
        // No accounts - show setup wizard
        setShowSetupWizard(true);
      }
    } catch (err) {
      console.error('Failed to load data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAccountChange = async (accountId) => {
    const account = accounts.find(a => a.id === accountId);
    setCurrentAccount(account);
    
    // Load companies for this account
    const companiesResult = await companyAccessor.getByAccount(accountId);
    if (companiesResult.success) {
      setCompanies(companiesResult.data);
      setCurrentCompany(companiesResult.data[0] || null);
    }
  };

  const handleSetupComplete = async (data) => {
    setShowSetupWizard(false);
    await loadData();
    setActiveTab('offices');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (showSetupWizard) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 py-12">
        <AccountSetupWizard onComplete={handleSetupComplete} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link
                to="/"
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                title="Back to Patient Readiness Center"
              >
                <Home className="w-6 h-6 text-gray-600 hover:text-blue-600" />
              </Link>
              <Building2 className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
                <p className="text-sm text-gray-500">Manage your organization</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {/* Account Selector */}
              {accounts.length > 1 && (
                <select
                  value={currentAccount?.id || ''}
                  onChange={(e) => handleAccountChange(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg text-sm"
                >
                  {accounts.map((account) => (
                    <option key={account.id} value={account.id}>
                      {account.name}
                    </option>
                  ))}
                </select>
              )}

              {/* Company Selector */}
              {companies.length > 0 && (
                <select
                  value={currentCompany?.id || ''}
                  onChange={(e) => setCurrentCompany(companies.find(c => c.id === e.target.value))}
                  className="px-3 py-2 border border-gray-300 rounded-lg text-sm"
                >
                  {companies.map((company) => (
                    <option key={company.id} value={company.id}>
                      {company.name}
                    </option>
                  ))}
                </select>
              )}

              <button
                onClick={() => setShowSetupWizard(true)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm"
              >
                Add Company
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-6 mt-6 border-b border-gray-200">
            {Object.entries(TABS).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                className={`pb-3 px-2 text-sm font-medium transition-colors relative ${
                  activeTab === key
                    ? 'text-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {label}
                {activeTab === key && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600" />
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!currentCompany ? (
          <div className="text-center py-12 bg-white rounded-lg shadow">
            <Database className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              No Company Selected
            </h3>
            <p className="text-gray-600 mb-4">
              Create your first company to get started
            </p>
            <button
              onClick={() => setShowSetupWizard(true)}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Setup Company
            </button>
          </div>
        ) : (
          <>
            {activeTab === 'overview' && <OverviewTab company={currentCompany} />}
            {activeTab === 'offices' && <OfficeManagement companyId={currentCompany.id} />}
            {activeTab === 'staff' && <StaffManagement companyId={currentCompany.id} />}
            {activeTab === 'settings' && <CompanySettings company={currentCompany} onUpdate={loadData} />}
          </>
        )}
      </div>
    </div>
  );
}

function OverviewTab({ company }) {
  const [stats, setStats] = useState({
    offices: 0,
    staff: 0,
    doctors: 0,
  });

  useEffect(() => {
    loadStats();
  }, [company.id]);

  const loadStats = async () => {
    // Load statistics
    const officeAccessor = (await import('../../lib/accessors/OfficeAccessor')).officeAccessor;
    const staffAccessor = (await import('../../lib/accessors/StaffAccessor')).staffAccessor;

    const [officesResult, staffResult] = await Promise.all([
      officeAccessor.getByCompany(company.id),
      staffAccessor.getActive(),
    ]);

    setStats({
      offices: officesResult.success ? officesResult.data.length : 0,
      staff: staffResult.success ? staffResult.data.length : 0,
      doctors: staffResult.success ? staffResult.data.filter(s => s.role === 'doctor').length : 0,
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard
          icon={MapPin}
          label="Office Locations"
          value={stats.offices}
          color="blue"
        />
        <StatCard
          icon={Users}
          label="Staff Members"
          value={stats.staff}
          color="green"
        />
        <StatCard
          icon={TrendingUp}
          label="Doctors/Providers"
          value={stats.doctors}
          color="purple"
        />
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Company Information</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-gray-500">Company Name:</span>
            <p className="font-medium text-gray-900">{company.name}</p>
          </div>
          <div>
            <span className="text-gray-500">Eyefinity Company ID:</span>
            <p className="font-medium text-gray-900">{company.eyefinity_company_id || 'Not set'}</p>
          </div>
          <div>
            <span className="text-gray-500">API Base URL:</span>
            <p className="font-medium text-gray-900">{company.eyefinity_base_url || 'Not set'}</p>
          </div>
          <div>
            <span className="text-gray-500">OAuth Status:</span>
            <p className={`font-medium ${company.oauth_token ? 'text-green-600' : 'text-red-600'}`}>
              {company.oauth_token ? '✓ Connected' : '✗ Not connected'}
            </p>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <QuickActionButton
            icon={MapPin}
            label="Manage Offices"
            description="Add and configure office locations"
          />
          <QuickActionButton
            icon={Users}
            label="Manage Staff"
            description="Add staff and assign to offices"
          />
          <QuickActionButton
            icon={Settings}
            label="Company Settings"
            description="Configure Eyefinity integration"
          />
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }) {
  const colors = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-green-50 text-green-600',
    purple: 'bg-purple-50 text-purple-600',
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center gap-4">
        <div className={`w-12 h-12 rounded-lg ${colors[color]} flex items-center justify-center`}>
          <Icon className="w-6 h-6" />
        </div>
        <div>
          <p className="text-sm text-gray-500">{label}</p>
          <p className="text-2xl font-bold text-gray-900">{value}</p>
        </div>
      </div>
    </div>
  );
}

function QuickActionButton({ icon: Icon, label, description }) {
  return (
    <button className="text-left p-4 bg-white rounded-lg border border-gray-200 hover:border-blue-300 hover:shadow-md transition-all">
      <Icon className="w-5 h-5 text-blue-600 mb-2" />
      <h4 className="font-medium text-gray-900">{label}</h4>
      <p className="text-xs text-gray-500 mt-1">{description}</p>
    </button>
  );
}

