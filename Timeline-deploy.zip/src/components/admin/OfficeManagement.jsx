/**
 * Office Management Component
 * Manage office locations and their settings
 */

import React, { useState, useEffect } from 'react';
import { MapPin, Plus, Edit, Trash2, Users, RefreshCw } from 'lucide-react';
import { officeAccessor } from '../../lib/accessors/OfficeAccessor';
import { staffAccessor } from '../../lib/accessors/StaffAccessor';
import EyefinityIntegrationService from '../../lib/services/eyefinity-integration-service';

export default function OfficeManagement({ companyId }) {
  const [offices, setOffices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [error, setError] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedOffice, setSelectedOffice] = useState(null);

  useEffect(() => {
    loadOffices();
  }, [companyId]);

  const loadOffices = async () => {
    try {
      const result = await officeAccessor.getByCompany(companyId);
      if (result.success) {
        setOffices(result.data);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSyncFromEyefinity = async () => {
    setSyncing(true);
    setError('');
    
    try {
      const result = await EyefinityIntegrationService.importOffices(companyId);
      
      if (result.imported > 0) {
        await loadOffices();
      }
      
      alert(`Imported ${result.imported} offices${result.errors.length > 0 ? ` with ${result.errors.length} errors` : ''}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setSyncing(false);
    }
  };

  const handleDelete = async (officeId) => {
    if (!confirm('Are you sure you want to delete this office?')) return;
    
    try {
      await officeAccessor.delete(officeId);
      await loadOffices();
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading offices...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Office Locations</h2>
        <div className="flex gap-2">
          <button
            onClick={handleSyncFromEyefinity}
            disabled={syncing}
            className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 flex items-center gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
            {syncing ? 'Syncing...' : 'Sync from Eyefinity'}
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Add Office
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {offices.map((office) => (
          <OfficeCard
            key={office.id}
            office={office}
            onEdit={setSelectedOffice}
            onDelete={handleDelete}
          />
        ))}
      </div>

      {offices.length === 0 && (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-3" />
          <p className="text-gray-600 mb-4">No offices found</p>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Add Your First Office
          </button>
        </div>
      )}

      {showAddModal && (
        <OfficeModal
          companyId={companyId}
          office={null}
          onClose={() => setShowAddModal(false)}
          onSave={() => {
            setShowAddModal(false);
            loadOffices();
          }}
        />
      )}

      {selectedOffice && (
        <OfficeModal
          companyId={companyId}
          office={selectedOffice}
          onClose={() => setSelectedOffice(null)}
          onSave={() => {
            setSelectedOffice(null);
            loadOffices();
          }}
        />
      )}
    </div>
  );
}

function OfficeCard({ office, onEdit, onDelete }) {
  const [staffCount, setStaffCount] = useState(0);

  useEffect(() => {
    loadStaffCount();
  }, [office.id]);

  const loadStaffCount = async () => {
    const result = await staffAccessor.getByOffice(office.id);
    if (result.success) {
      setStaffCount(result.data.length);
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <MapPin className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-gray-900">{office.name}</h3>
        </div>
        <div className="flex gap-1">
          <button
            onClick={() => onEdit(office)}
            className="p-1 text-gray-400 hover:text-blue-600"
          >
            <Edit className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDelete(office.id)}
            className="p-1 text-gray-400 hover:text-red-600"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="space-y-2 text-sm text-gray-600">
        {office.address?.city && (
          <div>{office.address.city}, {office.address.state}</div>
        )}
        {office.phone && <div>{office.phone}</div>}
        {office.timezone && <div className="text-xs text-gray-500">{office.timezone}</div>}
        
        <div className="flex items-center gap-1 pt-2 border-t">
          <Users className="w-4 h-4" />
          <span>{staffCount} staff members</span>
        </div>
      </div>
    </div>
  );
}

function OfficeModal({ companyId, office, onClose, onSave }) {
  const [formData, setFormData] = useState({
    name: office?.name || '',
    phone: office?.phone || '',
    email: office?.email || '',
    timezone: office?.timezone || 'America/Chicago',
    address: {
      street: office?.address?.street || '',
      city: office?.address?.city || '',
      state: office?.address?.state || '',
      zip: office?.address?.zip || '',
    },
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');

    try {
      if (office) {
        await officeAccessor.update(office.id, formData);
      } else {
        await officeAccessor.create({
          company_id: companyId,
          ...formData,
          settings: {},
        });
      }
      onSave();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <h3 className="text-xl font-bold text-gray-900 mb-4">
          {office ? 'Edit Office' : 'Add New Office'}
        </h3>

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded text-red-700 text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Office Name *
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Phone
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Street Address
            </label>
            <input
              type="text"
              value={formData.address.street}
              onChange={(e) => setFormData({
                ...formData,
                address: { ...formData.address, street: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                City
              </label>
              <input
                type="text"
                value={formData.address.city}
                onChange={(e) => setFormData({
                  ...formData,
                  address: { ...formData.address, city: e.target.value }
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                State
              </label>
              <input
                type="text"
                value={formData.address.state}
                onChange={(e) => setFormData({
                  ...formData,
                  address: { ...formData.address, state: e.target.value }
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                maxLength={2}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                ZIP Code
              </label>
              <input
                type="text"
                value={formData.address.zip}
                onChange={(e) => setFormData({
                  ...formData,
                  address: { ...formData.address, zip: e.target.value }
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Timezone
              </label>
              <select
                value={formData.timezone}
                onChange={(e) => setFormData({ ...formData, timezone: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="America/New_York">Eastern</option>
                <option value="America/Chicago">Central</option>
                <option value="America/Denver">Mountain</option>
                <option value="America/Los_Angeles">Pacific</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {saving ? 'Saving...' : office ? 'Update Office' : 'Create Office'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
