/**
 * Driver's License PDF417 Barcode Scanner
 * Full-screen camera modal that scans the PDF417 barcode on the back of US driver's licenses
 * and returns parsed AAMVA data for auto-filling patient intake forms.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { X, Camera, AlertCircle, CheckCircle, Loader } from 'lucide-react';
import { parseAAMVABarcode } from '../../lib/utils/aamva-parser';

const SCAN_INTERVAL_MS = 250;
const HINT_TIMEOUT_MS = 12000;

export default function DriversLicenseScanner({ isOpen, onClose, onScanComplete }) {
  const [status, setStatus] = useState('initializing'); // initializing | scanning | success | error
  const [errorMessage, setErrorMessage] = useState('');
  const [showHint, setShowHint] = useState(false);
  const [debugInfo, setDebugInfo] = useState('');

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const scanIntervalRef = useRef(null);
  const hintTimeoutRef = useRef(null);
  const readBarcodesRef = useRef(null);
  const scanCountRef = useRef(0);

  const cleanup = useCallback(() => {
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current);
      scanIntervalRef.current = null;
    }
    if (hintTimeoutRef.current) {
      clearTimeout(hintTimeoutRef.current);
      hintTimeoutRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  }, []);

  const handleClose = useCallback(() => {
    cleanup();
    onClose();
  }, [cleanup, onClose]);

  // Initialize camera and WASM on open
  useEffect(() => {
    if (!isOpen) return;

    let cancelled = false;

    async function init() {
      // Load zxing-wasm and prepare the WASM module
      try {
        setDebugInfo('Loading scanner engine...');
        const zxing = await import('zxing-wasm/reader');

        if (cancelled) return;

        // Pre-load the WASM module — this is critical for production
        setDebugInfo('Initializing WASM...');
        await zxing.prepareZXingModule({ fireImmediately: true });

        if (cancelled) return;

        readBarcodesRef.current = zxing.readBarcodes;
        console.log('[DLScanner] zxing-wasm loaded and WASM ready');
      } catch (err) {
        console.error('[DLScanner] Failed to load zxing-wasm:', err);
        if (!cancelled) {
          setStatus('error');
          setErrorMessage('Scanner could not load. Please fill in the fields manually.');
        }
        return;
      }

      // Start camera with fallback chain: environment → user → any
      // Request high resolution for better barcode detection
      setDebugInfo('Starting camera...');
      let stream = null;
      const facingModes = ['environment', 'user', undefined];

      for (const facingMode of facingModes) {
        try {
          const constraints = {
            video: {
              width: { ideal: 1920 },
              height: { ideal: 1080 },
              ...(facingMode ? { facingMode } : {}),
            },
          };
          stream = await navigator.mediaDevices.getUserMedia(constraints);
          console.log(`[DLScanner] Camera started with facingMode: ${facingMode || 'any'}`);
          break;
        } catch (err) {
          console.log(`[DLScanner] Camera ${facingMode || 'any'} failed:`, err.message);
        }
      }

      if (cancelled) {
        if (stream) stream.getTracks().forEach(t => t.stop());
        return;
      }

      if (!stream) {
        setStatus('error');
        setErrorMessage('Camera access is required to scan your license. Please allow camera access in your browser settings, or fill in the fields manually.');
        return;
      }

      streamRef.current = stream;

      // Log actual video resolution
      const track = stream.getVideoTracks()[0];
      const settings = track.getSettings();
      console.log(`[DLScanner] Camera resolution: ${settings.width}x${settings.height}`);

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        try {
          await videoRef.current.play();
        } catch (playErr) {
          console.log('[DLScanner] Video play() error:', playErr.message);
        }
      }

      setDebugInfo('');
      setStatus('scanning');
      scanCountRef.current = 0;

      // Start hint timer
      hintTimeoutRef.current = setTimeout(() => {
        if (!cancelled) setShowHint(true);
      }, HINT_TIMEOUT_MS);
    }

    init();

    return () => {
      cancelled = true;
      cleanup();
    };
  }, [isOpen, cleanup]);

  // Scanning loop — runs when status is 'scanning'
  useEffect(() => {
    if (status !== 'scanning' || !readBarcodesRef.current) return;

    const readBarcodes = readBarcodesRef.current;
    let scanning = false; // prevent overlapping scans

    scanIntervalRef.current = setInterval(async () => {
      if (scanning) return; // skip if previous scan still running
      scanning = true;

      const video = videoRef.current;
      const canvas = canvasRef.current;
      if (!video || !canvas || video.readyState < 2) {
        scanning = false;
        return;
      }

      const vw = video.videoWidth;
      const vh = video.videoHeight;
      if (vw === 0 || vh === 0) {
        scanning = false;
        return;
      }

      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      canvas.width = vw;
      canvas.height = vh;
      ctx.drawImage(video, 0, 0, vw, vh);

      const imageData = ctx.getImageData(0, 0, vw, vh);

      try {
        const results = await readBarcodes(imageData, {
          formats: ['PDF417'],
          tryHarder: true,
          tryRotate: true,
          tryInvert: true,
          tryDownscale: true,
          maxNumberOfSymbols: 1,
          textMode: 'Plain',
        });

        scanCountRef.current++;

        if (results.length > 0 && results[0].isValid && results[0].text) {
          const rawText = results[0].text;
          console.log('[DLScanner] Barcode detected! Raw length:', rawText.length);
          console.log('[DLScanner] Raw text preview:', rawText.substring(0, 100));

          const parsed = parseAAMVABarcode(rawText);
          console.log('[DLScanner] Parsed data:', parsed);

          // Check we got at least some useful data
          if (parsed.firstName || parsed.lastName) {
            setStatus('success');
            cleanup();

            // Brief success flash before closing
            setTimeout(() => {
              onScanComplete(parsed);
            }, 600);
            return;
          } else {
            console.log('[DLScanner] Barcode found but no name parsed — may not be AAMVA');
          }
        }
      } catch (err) {
        console.error('[DLScanner] Scan error:', err.message);
      } finally {
        scanning = false;
      }
    }, SCAN_INTERVAL_MS);

    return () => {
      if (scanIntervalRef.current) {
        clearInterval(scanIntervalRef.current);
        scanIntervalRef.current = null;
      }
    };
  }, [status, cleanup, onScanComplete]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between px-4 py-3 bg-gradient-to-b from-black/70 to-transparent">
        <div className="text-white">
          <h2 className="text-base font-semibold">Scan Driver's License</h2>
          <p className="text-xs text-white/70">Point at the barcode on the back</p>
        </div>
        <button
          onClick={handleClose}
          className="w-10 h-10 flex items-center justify-center rounded-full bg-white/20 text-white"
        >
          <X size={20} />
        </button>
      </div>

      {/* Video feed */}
      <video
        ref={videoRef}
        className="w-full h-full object-cover"
        autoPlay
        playsInline
        muted
      />

      {/* Hidden canvas for frame capture */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Scanning overlay */}
      {status === 'scanning' && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          {/* Dimmed borders around targeting rectangle */}
          <div className="absolute inset-0 bg-black/40" />
          <div
            className="relative w-80 h-48 border-2 border-white rounded-lg bg-transparent z-10"
            style={{ boxShadow: '0 0 0 9999px rgba(0,0,0,0.4)' }}
          >
            {/* Corner accents */}
            <div className="absolute -top-0.5 -left-0.5 w-6 h-6 border-t-4 border-l-4 border-blue-400 rounded-tl-lg" />
            <div className="absolute -top-0.5 -right-0.5 w-6 h-6 border-t-4 border-r-4 border-blue-400 rounded-tr-lg" />
            <div className="absolute -bottom-0.5 -left-0.5 w-6 h-6 border-b-4 border-l-4 border-blue-400 rounded-bl-lg" />
            <div className="absolute -bottom-0.5 -right-0.5 w-6 h-6 border-b-4 border-r-4 border-blue-400 rounded-br-lg" />

            {/* Scanning line animation */}
            <div className="absolute inset-x-2 h-0.5 bg-blue-400/80"
              style={{ top: '50%', animation: 'scanLine 2s ease-in-out infinite' }}
            />
          </div>
        </div>
      )}

      {/* Status bar */}
      <div className="absolute bottom-0 left-0 right-0 pb-safe">
        <div className="px-6 pb-8 pt-4 bg-gradient-to-t from-black/80 to-transparent">
          {status === 'initializing' && (
            <div className="flex flex-col items-center gap-2 text-white">
              <div className="flex items-center gap-2">
                <Loader size={18} className="animate-spin" />
                <span className="text-sm">Starting camera...</span>
              </div>
              {debugInfo && <span className="text-xs text-white/60">{debugInfo}</span>}
            </div>
          )}

          {status === 'scanning' && (
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-white mb-2">
                <Camera size={18} className="animate-pulse" />
                <span className="text-sm">Scanning for barcode...</span>
              </div>
              {showHint && (
                <p className="text-xs text-yellow-300">
                  Having trouble? Hold the license flat, ensure good lighting, and fill the rectangle with the barcode.
                </p>
              )}
            </div>
          )}

          {status === 'success' && (
            <div className="flex items-center justify-center gap-2 text-green-400">
              <CheckCircle size={20} />
              <span className="text-base font-medium">License scanned successfully!</span>
            </div>
          )}

          {status === 'error' && (
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-red-400 mb-3">
                <AlertCircle size={20} />
                <span className="text-sm">{errorMessage}</span>
              </div>
              <button
                onClick={handleClose}
                className="px-6 py-2 bg-white text-gray-900 rounded-lg text-sm font-medium"
              >
                Close
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Inline keyframe for scan line animation */}
      <style>{`
        @keyframes scanLine {
          0%, 100% { transform: translateY(-40px); opacity: 0.6; }
          50% { transform: translateY(40px); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
