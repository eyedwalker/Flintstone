/**
 * Patient Verification Component
 * Handles identity verification before form access
 * Supports: DOB, Phone, Email, Zip+LastName verification methods
 */

import React, { useState } from 'react';
import { FormSubmissionService } from '../../lib/services/form-submission-service';
import { 
  Shield, 
  Calendar, 
  Phone, 
  Mail, 
  MapPin, 
  AlertCircle,
  Lock,
  CheckCircle
} from 'lucide-react';

export default function PatientVerification({ submissionId, token, onSuccess, verificationMethod = 'dob' }) {
  const [method] = useState(verificationMethod);
  const [formData, setFormData] = useState({
    dob: '',
    phone: '',
    email: '',
    zip: '',
    lastName: '',
  });
  const [error, setError] = useState('');
  const [isLocked, setIsLocked] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsVerifying(true);

    try {
      // Try API verification first (for server-stored forms)
      if (token) {
        const response = await fetch('/api/forms/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            token,
            verificationData: formData,
          }),
        });
        
        const result = await response.json();
        
        if (result.success && result.verified) {
          onSuccess?.();
          return;
        } else if (result.locked) {
          setIsLocked(true);
          return;
        } else if (response.ok) {
          setError(result.error || 'Verification failed. Please check your information.');
          return;
        }
        // If API fails (404), fall through to localStorage
      }
      
      // Fallback to localStorage verification
      const result = FormSubmissionService.verifyPatient(submissionId, formData);
      
      if (result.success) {
        onSuccess?.();
      } else {
        setError(result.error || 'Verification failed');
        setIsLocked(result.locked || false);
      }
    } catch (err) {
      console.error('[Verification] Error:', err);
      setError('An error occurred. Please try again.');
    } finally {
      setIsVerifying(false);
    }
  };

  const renderVerificationForm = () => {
    switch (method) {
      case 'dob':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
              <Calendar className="w-6 h-6 text-blue-600" />
              <div>
                <p className="font-medium text-blue-900">Date of Birth Verification</p>
                <p className="text-sm text-blue-700">Enter your date of birth to verify your identity</p>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Date of Birth
              </label>
              <input
                type="date"
                value={formData.dob}
                onChange={(e) => handleInputChange('dob', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                required
              />
            </div>
          </div>
        );

      case 'phone':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
              <Phone className="w-6 h-6 text-blue-600" />
              <div>
                <p className="font-medium text-blue-900">Phone Verification</p>
                <p className="text-sm text-blue-700">Enter the phone number on file</p>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Phone Number
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                placeholder="(555) 123-4567"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                required
              />
            </div>
          </div>
        );

      case 'email':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
              <Mail className="w-6 h-6 text-blue-600" />
              <div>
                <p className="font-medium text-blue-900">Email Verification</p>
                <p className="text-sm text-blue-700">Enter the email address on file</p>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                placeholder="your.email@example.com"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                required
              />
            </div>
          </div>
        );

      case 'zipLastName':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
              <MapPin className="w-6 h-6 text-blue-600" />
              <div>
                <p className="font-medium text-blue-900">ZIP Code & Last Name Verification</p>
                <p className="text-sm text-blue-700">Enter your ZIP code and last name</p>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Last Name
              </label>
              <input
                type="text"
                value={formData.lastName}
                onChange={(e) => handleInputChange('lastName', e.target.value)}
                placeholder="Enter your last name"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                ZIP Code
              </label>
              <input
                type="text"
                value={formData.zip}
                onChange={(e) => handleInputChange('zip', e.target.value)}
                placeholder="12345"
                maxLength={10}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                required
              />
            </div>
          </div>
        );

      default:
        return (
          <div className="text-center py-4">
            <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-2" />
            <p className="text-gray-600">No verification required</p>
          </div>
        );
    }
  };

  if (isLocked) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-8 text-center">
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Lock className="w-8 h-8 text-red-600" />
        </div>
        <h2 className="text-xl font-bold text-gray-900 mb-2">Account Temporarily Locked</h2>
        <p className="text-gray-600 mb-4">
          Too many failed verification attempts. Please try again in 15 minutes or contact your healthcare provider.
        </p>
        <div className="p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-500">
            For assistance, please contact your healthcare provider directly.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 md:p-8">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Shield className="w-8 h-8 text-purple-600" />
        </div>
        <h2 className="text-xl font-bold text-gray-900">Verify Your Identity</h2>
        <p className="text-gray-600 mt-1">
          For your security, please verify your identity to access this form.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {renderVerificationForm()}

        {error && (
          <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        <button
          type="submit"
          disabled={isVerifying}
          className="w-full py-3 px-4 bg-purple-600 text-white font-medium rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {isVerifying ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Verifying...
            </>
          ) : (
            <>
              <Shield className="w-5 h-5" />
              Verify & Continue
            </>
          )}
        </button>
      </form>

      <p className="mt-6 text-xs text-center text-gray-500">
        Your information is encrypted and secure. We use this verification to protect your health information.
      </p>
    </div>
  );
}
