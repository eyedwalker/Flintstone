import React, { useState, useEffect } from 'react';
import { Phone, MessageSquare, Mail, FileText, ChevronDown, ChevronRight, Search, Plus, Edit, Copy, Trash2, Tag, Settings, Eye, Play, X, Send } from 'lucide-react';
import VoiceTemplateService, { TEMPLATE_CATEGORIES, MERGE_FIELD_DEFINITIONS } from '../../services/voiceTemplateService';

const CHANNEL_CONFIG = {
  voice: { label: 'Voice', icon: Phone, color: 'green', actionLabel: 'Call' },
  sms: { label: 'SMS', icon: MessageSquare, color: 'blue', actionLabel: 'Send SMS' },
  email: { label: 'Email', icon: Mail, color: 'purple', actionLabel: 'Send Email' },
};

export function CommunicationTemplateSelector({ 
  channel = 'voice',  // 'voice' | 'sms' | 'email' | 'all'
  onSelectTemplate, 
  selectedTemplateId,
  patientData = {},
  appointmentData = {},
  officeData = {},
  providerData = {},
  insuranceData = {},
  orderData = {},
  onAction,  // Called when user clicks action button (Call/Send)
  onCall,    // Alias for onAction (backward compat)
  showChannelFilter = false,  // Show channel tabs
}) {
  const [templates, setTemplates] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedChannel, setSelectedChannel] = useState(channel);
  const [searchQuery, setSearchQuery] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  const [previewTemplate, setPreviewTemplate] = useState(null);
  const [expandedCategories, setExpandedCategories] = useState(() => {
    // All collapsed by default
    const collapsed = {};
    Object.keys(TEMPLATE_CATEGORIES).forEach(cat => {
      collapsed[cat] = false;
    });
    return collapsed;
  });
  const [viewMode, setViewMode] = useState('list'); // 'list' or 'dropdown'

  useEffect(() => {
    loadTemplates();
  }, [selectedChannel]);

  useEffect(() => {
    setSelectedChannel(channel);
  }, [channel]);

  const loadTemplates = () => {
    let loaded = VoiceTemplateService.getTemplates().filter(t => t.isActive);
    if (selectedChannel !== 'all') {
      loaded = loaded.filter(t => t.channel === selectedChannel);
    }
    setTemplates(loaded);
  };

  const filteredTemplates = templates.filter(t => {
    const matchesCategory = selectedCategory === 'all' || t.category === selectedCategory;
    const matchesSearch = !searchQuery || 
      t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Group templates by category
  const groupedTemplates = filteredTemplates.reduce((acc, template) => {
    if (!acc[template.category]) {
      acc[template.category] = [];
    }
    acc[template.category].push(template);
    return acc;
  }, {});

  const toggleCategory = (category) => {
    setExpandedCategories(prev => ({
      ...prev,
      [category]: !prev[category]
    }));
  };

  const getMergeData = () => ({
    patient: patientData,
    appointment: appointmentData,
    office: officeData,
    provider: providerData,
    insurance: insuranceData,
    order: orderData,
    custom: {},
  });

  const handlePreview = (template) => {
    setPreviewTemplate(template);
    setShowPreview(true);
  };

  const handleSelectAndAction = (template) => {
    if (onSelectTemplate) {
      onSelectTemplate(template);
    }
    const actionHandler = onAction || onCall;
    if (actionHandler) {
      const script = VoiceTemplateService.generateScript(template.id, getMergeData());
      actionHandler(template, script);
    }
  };

  const renderPreviewContent = (content) => {
    const data = getMergeData();
    return VoiceTemplateService.applyMergeFields(content, data);
  };

  const getChannelConfig = (ch) => CHANNEL_CONFIG[ch] || CHANNEL_CONFIG.voice;
  const currentChannelConfig = getChannelConfig(selectedChannel === 'all' ? 'voice' : selectedChannel);

  return (
    <div className="communication-template-selector">
      {/* Channel Tabs (if enabled) */}
      {showChannelFilter && (
        <div className="flex gap-1 mb-2 border-b pb-2">
          <button
            onClick={() => setSelectedChannel('all')}
            className={`flex items-center gap-1 px-2 py-1 text-[10px] rounded ${
              selectedChannel === 'all' ? 'bg-gray-700 text-white' : 'bg-gray-100 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          {Object.entries(CHANNEL_CONFIG).map(([ch, config]) => {
            const Icon = config.icon;
            return (
              <button
                key={ch}
                onClick={() => setSelectedChannel(ch)}
                className={`flex items-center gap-1 px-2 py-1 text-[10px] rounded ${
                  selectedChannel === ch 
                    ? `bg-${config.color}-600 text-white` 
                    : 'bg-gray-100 hover:bg-gray-200'
                }`}
                style={selectedChannel === ch ? { 
                  backgroundColor: config.color === 'green' ? '#16a34a' : config.color === 'blue' ? '#2563eb' : '#9333ea' 
                } : {}}
              >
                <Icon size={10} />
                {config.label}
              </button>
            );
          })}
        </div>
      )}

      {/* Header with search, filter, and view toggle */}
      <div className="flex items-center gap-2 mb-2">
        <div className="relative flex-1">
          <Search size={14} className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-7 pr-3 py-1.5 text-xs border rounded"
          />
        </div>
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="text-xs border rounded px-2 py-1.5"
        >
          <option value="all">All Categories</option>
          {Object.entries(TEMPLATE_CATEGORIES).map(([key, { label, icon }]) => (
            <option key={key} value={key}>{icon} {label}</option>
          ))}
        </select>
        <div className="flex border rounded overflow-hidden">
          <button
            onClick={() => setViewMode('dropdown')}
            className={`px-2 py-1 text-[10px] ${viewMode === 'dropdown' ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}
            title="Dropdown View"
          >
            DDL
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`px-2 py-1 text-[10px] ${viewMode === 'list' ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}
            title="List View"
          >
            List
          </button>
        </div>
      </div>

      {/* Dropdown View Mode */}
      {viewMode === 'dropdown' && (
        <div className="mb-3">
          <select
            value=""
            onChange={(e) => {
              const template = templates.find(t => t.id === e.target.value);
              if (template) {
                handleSelectAndAction(template);
              }
            }}
            className="w-full text-xs border rounded px-2 py-2"
          >
            <option value="">-- Select a Template to Use --</option>
            {Object.entries(TEMPLATE_CATEGORIES).map(([category, { label, icon }]) => {
              const categoryTemplates = filteredTemplates.filter(t => t.category === category);
              if (categoryTemplates.length === 0) return null;
              return (
                <optgroup key={category} label={`${icon} ${label}`}>
                  {categoryTemplates.map(t => {
                    const chLabel = CHANNEL_CONFIG[t.channel]?.label || t.channel;
                    return (
                      <option key={t.id} value={t.id}>
                        [{chLabel}] {t.name}
                      </option>
                    );
                  })}
                </optgroup>
              );
            })}
          </select>
        </div>
      )}

      {/* Template List (only show in list mode) */}
      {viewMode === 'list' && (
      <div className="max-h-64 overflow-y-auto border rounded">
        {Object.entries(groupedTemplates).length === 0 ? (
          <div className="p-4 text-center text-gray-500 text-xs">
            No templates found
          </div>
        ) : (
          Object.entries(groupedTemplates).map(([category, categoryTemplates]) => {
            const categoryInfo = TEMPLATE_CATEGORIES[category] || { label: category, icon: '📄' };
            const isExpanded = expandedCategories[category] === true;
            
            return (
              <div key={category} className="border-b last:border-b-0">
                <button
                  onClick={() => toggleCategory(category)}
                  className="w-full flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 text-left"
                >
                  {isExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                  <span className="text-sm">{categoryInfo.icon}</span>
                  <span className="text-xs font-medium flex-1">{categoryInfo.label}</span>
                  <span className="text-[10px] text-gray-500 bg-gray-200 px-1.5 rounded">
                    {categoryTemplates.length}
                  </span>
                </button>
                
                {isExpanded && (
                  <div className="divide-y">
                    {categoryTemplates.map(template => {
                      const templateChannel = getChannelConfig(template.channel);
                      const ChannelIcon = templateChannel.icon;
                      const buttonColors = {
                        voice: 'bg-green-600 hover:bg-green-700',
                        sms: 'bg-blue-600 hover:bg-blue-700',
                        email: 'bg-purple-600 hover:bg-purple-700',
                      };
                      
                      return (
                        <div 
                          key={template.id}
                          className={`px-3 py-2 hover:bg-blue-50 cursor-pointer ${
                            selectedTemplateId === template.id ? 'bg-blue-100' : ''
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1.5">
                                <ChannelIcon size={10} className="text-gray-400 flex-shrink-0" />
                                <span className="text-xs font-medium truncate">{template.name}</span>
                              </div>
                              <div className="text-[10px] text-gray-500 truncate ml-4">{template.description}</div>
                            </div>
                            <div className="flex items-center gap-1 flex-shrink-0">
                              <button
                                onClick={(e) => { e.stopPropagation(); handlePreview(template); }}
                                className="p-1 hover:bg-gray-200 rounded"
                                title="Preview"
                              >
                                <Eye size={12} className="text-gray-500" />
                              </button>
                              <button
                                onClick={(e) => { e.stopPropagation(); handleSelectAndAction(template); }}
                                className={`flex items-center gap-1 px-2 py-1 text-white rounded text-[10px] ${buttonColors[template.channel]}`}
                              >
                                <ChannelIcon size={10} />
                                {templateChannel.actionLabel}
                              </button>
                            </div>
                          </div>
                          <div className="flex gap-2 mt-1 ml-4">
                            <span className={`text-[9px] px-1.5 py-0.5 rounded ${
                              template.channel === 'voice' ? 'bg-green-100 text-green-700' :
                              template.channel === 'sms' ? 'bg-blue-100 text-blue-700' :
                              'bg-purple-100 text-purple-700'
                            }`}>
                              {templateChannel.label}
                            </span>
                            {template.voiceSettings?.tone && (
                              <span className="text-[9px] px-1.5 py-0.5 bg-gray-100 text-gray-600 rounded">
                                {template.voiceSettings.tone}
                              </span>
                            )}
                            {template.isDefault && (
                              <span className="text-[9px] px-1.5 py-0.5 bg-amber-100 text-amber-700 rounded">
                                Default
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
      )}

      {/* Preview Modal */}
      {showPreview && previewTemplate && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[80vh] overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b bg-gray-50">
              <div>
                <h3 className="font-medium">{previewTemplate.name}</h3>
                <p className="text-xs text-gray-500">{previewTemplate.description}</p>
              </div>
              <button onClick={() => setShowPreview(false)} className="p-1 hover:bg-gray-200 rounded">
                <X size={18} />
              </button>
            </div>
            
            <div className="p-4 overflow-y-auto max-h-[60vh]">
              {/* Script Preview */}
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-gray-700 block mb-1">Greeting</label>
                  <div className="bg-green-50 border border-green-200 rounded p-3 text-sm">
                    {renderPreviewContent(previewTemplate.greeting)}
                  </div>
                </div>
                
                <div>
                  <label className="text-xs font-medium text-gray-700 block mb-1">Main Script</label>
                  <div className="bg-blue-50 border border-blue-200 rounded p-3 text-sm">
                    {renderPreviewContent(previewTemplate.mainScript)}
                  </div>
                </div>
                
                <div>
                  <label className="text-xs font-medium text-gray-700 block mb-1">Closing</label>
                  <div className="bg-purple-50 border border-purple-200 rounded p-3 text-sm">
                    {renderPreviewContent(previewTemplate.closingScript)}
                  </div>
                </div>

                {previewTemplate.conditionalScripts && (
                  <div>
                    <label className="text-xs font-medium text-gray-700 block mb-1">Conditional Responses</label>
                    <div className="space-y-2">
                      {Object.entries(previewTemplate.conditionalScripts).map(([key, script]) => script && (
                        <div key={key} className="bg-gray-50 border rounded p-2">
                          <span className="text-[10px] font-medium text-gray-500 uppercase">{key.replace('on', '')}</span>
                          <p className="text-xs mt-1">{renderPreviewContent(script)}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Merge Fields Used */}
                <div>
                  <label className="text-xs font-medium text-gray-700 block mb-1">Merge Fields Used</label>
                  <div className="flex flex-wrap gap-1">
                    {previewTemplate.mergeFields.map(field => (
                      <span key={field} className="text-[10px] px-2 py-0.5 bg-amber-100 text-amber-700 rounded">
                        {`{${field}}`}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="px-4 py-3 border-t bg-gray-50 flex justify-end gap-2">
              <button
                onClick={() => setShowPreview(false)}
                className="px-3 py-1.5 text-sm border rounded hover:bg-gray-100"
              >
                Close
              </button>
              {(() => {
                const previewChannel = getChannelConfig(previewTemplate.channel);
                const PreviewIcon = previewChannel.icon;
                const buttonBg = {
                  voice: 'bg-green-600 hover:bg-green-700',
                  sms: 'bg-blue-600 hover:bg-blue-700',
                  email: 'bg-purple-600 hover:bg-purple-700',
                }[previewTemplate.channel];
                return (
                  <button
                    onClick={() => { setShowPreview(false); handleSelectAndAction(previewTemplate); }}
                    className={`flex items-center gap-2 px-4 py-1.5 text-white rounded text-sm ${buttonBg}`}
                  >
                    <PreviewIcon size={14} />
                    Use Template & {previewChannel.actionLabel}
                  </button>
                );
              })()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Quick template picker for inline use
export function QuickTemplateSelect({ onSelect, selectedId, channel = 'all' }) {
  const [templates, setTemplates] = useState([]);
  
  useEffect(() => {
    let loaded = VoiceTemplateService.getTemplates().filter(t => t.isActive);
    if (channel !== 'all') {
      loaded = loaded.filter(t => t.channel === channel);
    }
    setTemplates(loaded);
  }, [channel]);

  const channelLabel = (ch) => CHANNEL_CONFIG[ch]?.label || ch;

  return (
    <select 
      value={selectedId || ''} 
      onChange={(e) => {
        const template = templates.find(t => t.id === e.target.value);
        if (template && onSelect) onSelect(template);
      }}
      className="text-xs border rounded px-2 py-1"
    >
      <option value="">Select Template...</option>
      {Object.entries(TEMPLATE_CATEGORIES).map(([category, { label, icon }]) => {
        const categoryTemplates = templates.filter(t => t.category === category);
        if (categoryTemplates.length === 0) return null;
        return (
          <optgroup key={category} label={`${icon} ${label}`}>
            {categoryTemplates.map(t => (
              <option key={t.id} value={t.id}>
                {channel === 'all' ? `[${channelLabel(t.channel)}] ` : ''}{t.name}
              </option>
            ))}
          </optgroup>
        );
      })}
    </select>
  );
}

// Backward compatibility alias
export const VoiceTemplateSelector = CommunicationTemplateSelector;

export default CommunicationTemplateSelector;
