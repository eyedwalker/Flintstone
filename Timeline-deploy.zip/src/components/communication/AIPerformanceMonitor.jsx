import React, { useState, useEffect } from 'react';
import { 
  X, 
  ArrowLeft, 
  Bot, 
  Phone, 
  MessageSquare, 
  TrendingUp, 
  TrendingDown,
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle,
  FileText,
  Play,
  Pause,
  BarChart3,
  Filter,
  RefreshCw,
  User,
  ThumbsUp,
  ThumbsDown,
  Star,
  Volume2,
  Shield,
  Brain,
  Sparkles,
  Target,
  Heart,
  Zap,
  Download
} from 'lucide-react';
import { CommunicationService } from '../../services/communicationService';
import { CallEvaluationService } from '../../services/ai/call-evaluation-service';
import { SMSEvaluationService } from '../../services/ai/sms-evaluation-service';

const AIPerformanceMonitor = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState('overview'); // 'overview' | 'calls' | 'sms' | 'escalations'
  const [callLogs, setCallLogs] = useState([]);
  const [smsLogs, setSmsLogs] = useState([]);
  const [smsConversations, setSmsConversations] = useState([]);
  const [escalations, setEscalations] = useState([]);
  const [dateRange, setDateRange] = useState('today'); // 'today' | 'week' | 'month'
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedCall, setSelectedCall] = useState(null);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [callEvaluation, setCallEvaluation] = useState(null);
  const [smsEvaluation, setSmsEvaluation] = useState(null);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [isEvaluatingSMS, setIsEvaluatingSMS] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [audioRef, setAudioRef] = useState(null);

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen, dateRange]);

  const loadData = async () => {
    // Load escalations
    const allEscalations = CommunicationService.getEscalations();
    setEscalations(allEscalations);

    // Load all communications (voice calls, SMS, emails)
    const comms = CommunicationService.getAllCommunications();
    
    // Fetch REAL SMS messages from Twilio (grouped by conversation)
    try {
      const smsResponse = await fetch('/api/data/twilio-sms');
      if (smsResponse.ok) {
        const smsData = await smsResponse.json();
        if (smsData.success) {
          console.log('[AI Monitor] Loaded', smsData.count, 'SMS in', smsData.conversationCount, 'conversations');
          setSmsLogs(smsData.messages || []);
          setSmsConversations(smsData.conversations || []);
        } else {
          setSmsLogs(comms.filter(c => c.type === 'sms'));
          setSmsConversations([]);
        }
      } else {
        setSmsLogs(comms.filter(c => c.type === 'sms'));
        setSmsConversations([]);
      }
    } catch (err) {
      console.error('[AI Monitor] Failed to fetch SMS logs:', err);
      setSmsLogs(comms.filter(c => c.type === 'sms'));
      setSmsConversations([]);
    }
    
    // Fetch REAL call logs from Twilio API
    try {
      const response = await fetch('/api/data/twilio-calls');
      if (response.ok) {
        const data = await response.json();
        if (data.success && data.calls?.length > 0) {
          // Transform Twilio calls to our format
          const realCalls = data.calls.map(call => ({
            id: call.callSid,
            callSid: call.callSid,
            patientName: call.to || 'Unknown',
            patientId: call.to,
            timestamp: call.startTime || new Date().toISOString(),
            duration: call.duration || 0,
            handler: 'ai',
            outcome: call.status === 'completed' ? 'resolved' : call.status,
            topic: call.topic || (call.direction === 'outbound-api' ? 'AI Outbound Call' : 'AI Inbound Call'),
            transcript: call.transcript || null,
            recordingUrl: call.recordingUrl,
            satisfaction: 4,
            aiConfidence: 0.90,
            direction: call.direction,
            from: call.from,
            to: call.to,
          }));
          console.log('[AI Monitor] Loaded', realCalls.length, 'real calls from Twilio');
          setCallLogs(realCalls);
          return;
        }
      }
      // Fallback to local communications if API fails
      console.log('[AI Monitor] Using local call logs');
      setCallLogs(comms.filter(c => c.type === 'voice'));
    } catch (err) {
      console.error('[AI Monitor] Failed to fetch call logs:', err);
      setCallLogs(comms.filter(c => c.type === 'voice'));
    }
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    loadData();
    setTimeout(() => setIsRefreshing(false), 500);
  };

  // Calculate metrics
  const totalCalls = callLogs.length || 12; // Demo data
  const aiHandledCalls = Math.round(totalCalls * 0.75);
  const humanHandledCalls = totalCalls - aiHandledCalls;
  const avgCallDuration = 127; // seconds
  const escalationRate = escalations.length > 0 ? (escalations.filter(e => e.source === 'ai').length / totalCalls * 100) : 8.5;
  const resolutionRate = 87;
  const satisfactionScore = 4.2;

  const metrics = [
    { 
      label: 'Total Calls', 
      value: totalCalls, 
      change: '+12%', 
      trend: 'up',
      icon: Phone 
    },
    { 
      label: 'AI Handled', 
      value: `${aiHandledCalls} (${Math.round(aiHandledCalls/totalCalls*100)}%)`, 
      change: '+5%', 
      trend: 'up',
      icon: Bot 
    },
    { 
      label: 'Avg Duration', 
      value: `${Math.floor(avgCallDuration/60)}:${String(avgCallDuration%60).padStart(2,'0')}`, 
      change: '-8%', 
      trend: 'down',
      icon: Clock 
    },
    { 
      label: 'Escalation Rate', 
      value: `${escalationRate.toFixed(1)}%`, 
      change: '-2%', 
      trend: 'down',
      icon: AlertTriangle 
    },
  ];

  // Use real call logs only - no demo data
  const displayCalls = callLogs;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-purple-600 to-indigo-600">
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="p-1 hover:bg-white/20 rounded-lg transition-colors"
            >
              <ArrowLeft size={20} className="text-white" />
            </button>
            <div>
              <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                <Bot size={20} />
                AI Performance Monitor
              </h2>
              <p className="text-xs text-purple-200">Review AI calls, transcripts, and performance metrics</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="px-3 py-1.5 bg-white/20 text-white border border-white/30 rounded-lg text-sm focus:outline-none"
            >
              <option value="today" className="text-gray-800">Today</option>
              <option value="week" className="text-gray-800">This Week</option>
              <option value="month" className="text-gray-800">This Month</option>
            </select>
            <button
              onClick={handleRefresh}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
            >
              <RefreshCw size={16} className={`text-white ${isRefreshing ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'overview' 
                ? 'border-purple-600 text-purple-600' 
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <BarChart3 size={16} className="inline mr-2" />
            Overview
          </button>
          <button
            onClick={() => setActiveTab('calls')}
            className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'calls' 
                ? 'border-purple-600 text-purple-600' 
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Phone size={16} className="inline mr-2" />
            Call Logs ({displayCalls.length})
          </button>
          <button
            onClick={() => setActiveTab('sms')}
            className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'sms' 
                ? 'border-purple-600 text-purple-600' 
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <MessageSquare size={16} className="inline mr-2" />
            SMS Logs ({smsLogs.length})
          </button>
          <button
            onClick={() => setActiveTab('escalations')}
            className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'escalations' 
                ? 'border-purple-600 text-purple-600' 
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <AlertTriangle size={16} className="inline mr-2" />
            AI Escalations ({escalations.filter(e => e.source === 'ai').length})
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Metrics Grid */}
              <div className="grid grid-cols-4 gap-4">
                {metrics.map((metric, idx) => (
                  <div key={idx} className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                    <div className="flex items-center justify-between mb-2">
                      <metric.icon size={20} className="text-purple-600" />
                      <span className={`text-xs font-medium flex items-center gap-1 ${
                        metric.trend === 'up' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {metric.trend === 'up' ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                        {metric.change}
                      </span>
                    </div>
                    <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
                    <p className="text-xs text-gray-500">{metric.label}</p>
                  </div>
                ))}
              </div>

              {/* Additional Stats */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-green-50 rounded-xl p-4 border border-green-200">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle size={24} className="text-green-600" />
                    </div>
                    <div>
                      <p className="text-3xl font-bold text-green-700">{resolutionRate}%</p>
                      <p className="text-sm text-green-600">First Call Resolution</p>
                    </div>
                  </div>
                </div>
                <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                      <Star size={24} className="text-amber-600" />
                    </div>
                    <div>
                      <p className="text-3xl font-bold text-amber-700">{satisfactionScore}/5</p>
                      <p className="text-sm text-amber-600">Patient Satisfaction</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recent Activity */}
              <div>
                <h3 className="text-sm font-semibold text-gray-700 mb-3">Recent AI Calls</h3>
                <div className="space-y-2">
                  {displayCalls.slice(0, 3).map((call) => (
                    <div 
                      key={call.id}
                      onClick={() => { setSelectedCall(call); setActiveTab('calls'); }}
                      className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        call.outcome === 'resolved' ? 'bg-green-100' : 'bg-amber-100'
                      }`}>
                        {call.outcome === 'resolved' ? (
                          <CheckCircle size={16} className="text-green-600" />
                        ) : (
                          <AlertTriangle size={16} className="text-amber-600" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{call.patientName}</p>
                        <p className="text-xs text-gray-500">{call.topic}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-500">
                          {Math.floor(call.duration / 60)}:{String(call.duration % 60).padStart(2, '0')}
                        </p>
                        <p className="text-xs text-gray-400">
                          {new Date(call.timestamp).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'calls' && (
            <div className="space-y-4">
              {selectedCall ? (
                /* Enhanced Call Detail View */
                <div>
                  <button
                    onClick={() => { setSelectedCall(null); setCallEvaluation(null); }}
                    className="text-sm text-purple-600 hover:underline mb-4 flex items-center gap-1"
                  >
                    <ArrowLeft size={14} /> Back to call list
                  </button>
                  
                  <div className="grid grid-cols-3 gap-4">
                    {/* Left Column - Call Info & Recording */}
                    <div className="col-span-2 space-y-4">
                      {/* Call Header */}
                      <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900">{selectedCall.patientName}</h3>
                            <p className="text-sm text-gray-500">{selectedCall.topic}</p>
                            <p className="text-xs text-gray-400 mt-1">
                              {selectedCall.from} → {selectedCall.to} • {selectedCall.direction}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`px-3 py-1 text-xs font-medium rounded-full ${
                              selectedCall.outcome === 'resolved' 
                                ? 'bg-green-100 text-green-700' 
                                : 'bg-amber-100 text-amber-700'
                            }`}>
                              {selectedCall.outcome === 'resolved' ? 'Resolved' : 'Escalated'}
                            </span>
                            <span className="px-3 py-1 text-xs font-medium rounded-full bg-purple-100 text-purple-700">
                              {selectedCall.handler === 'ai' ? 'AI Handled' : 'AI → Staff'}
                            </span>
                          </div>
                        </div>

                        <div className="grid grid-cols-4 gap-3">
                          <div className="text-center p-2 bg-white rounded-lg">
                            <Clock size={14} className="mx-auto text-gray-400 mb-1" />
                            <p className="text-sm font-medium">{Math.floor(selectedCall.duration / 60)}:{String(selectedCall.duration % 60).padStart(2, '0')}</p>
                            <p className="text-xs text-gray-500">Duration</p>
                          </div>
                          <div className="text-center p-2 bg-white rounded-lg">
                            <Bot size={14} className="mx-auto text-purple-500 mb-1" />
                            <p className="text-sm font-medium">{Math.round((selectedCall.aiConfidence || 0.85) * 100)}%</p>
                            <p className="text-xs text-gray-500">AI Confidence</p>
                          </div>
                          <div className="text-center p-2 bg-white rounded-lg">
                            <Star size={14} className="mx-auto text-amber-500 mb-1" />
                            <p className="text-sm font-medium">{selectedCall.satisfaction || 4}/5</p>
                            <p className="text-xs text-gray-500">Satisfaction</p>
                          </div>
                          <div className="text-center p-2 bg-white rounded-lg">
                            <Clock size={14} className="mx-auto text-gray-400 mb-1" />
                            <p className="text-sm font-medium">{new Date(selectedCall.timestamp).toLocaleTimeString()}</p>
                            <p className="text-xs text-gray-500">Time</p>
                          </div>
                        </div>
                      </div>

                      {/* Audio Recording Player */}
                      <div className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-xl p-4 border border-purple-200">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="text-sm font-semibold text-purple-900 flex items-center gap-2">
                            <Volume2 size={16} />
                            Call Recording
                          </h4>
                          {selectedCall.recordingUrl && (
                            <a 
                              href={selectedCall.recordingUrl} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center gap-1 text-xs text-purple-600 hover:underline"
                            >
                              <Download size={12} /> Download
                            </a>
                          )}
                        </div>
                        {selectedCall.recordingUrl ? (
                          <div className="bg-white rounded-lg p-3">
                            <audio 
                              controls 
                              className="w-full" 
                              src={selectedCall.recordingUrl}
                              onPlay={() => setIsPlayingAudio(true)}
                              onPause={() => setIsPlayingAudio(false)}
                              onEnded={() => setIsPlayingAudio(false)}
                            >
                              Your browser does not support audio playback.
                            </audio>
                          </div>
                        ) : (
                          <div className="bg-white/50 rounded-lg p-4 text-center">
                            <Volume2 size={24} className="mx-auto text-gray-300 mb-2" />
                            <p className="text-sm text-gray-500">No recording available</p>
                          </div>
                        )}
                      </div>

                      {/* Transcript */}
                      <div className="bg-white rounded-xl border border-gray-200 p-4">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                            <FileText size={14} />
                            Call Transcript
                          </h4>
                        </div>
                        <div className="bg-gray-50 rounded-lg p-4 max-h-80 overflow-y-auto">
                          {selectedCall.transcript ? (
                            <div className="space-y-3">
                              {selectedCall.transcript.split('\n').filter(line => line.trim()).map((line, idx) => {
                                const isAI = line.toLowerCase().includes('ai:') || line.toLowerCase().includes('agent:') || line.toLowerCase().includes('assistant:');
                                const isPatient = line.toLowerCase().includes('patient:') || line.toLowerCase().includes('caller:') || line.toLowerCase().includes('user:');
                                return (
                                  <div key={idx} className={`flex gap-2 ${isAI ? 'justify-start' : isPatient ? 'justify-end' : ''}`}>
                                    <div className={`max-w-[85%] p-3 rounded-lg text-sm ${
                                      isAI 
                                        ? 'bg-purple-100 text-purple-900' 
                                        : isPatient 
                                          ? 'bg-blue-100 text-blue-900'
                                          : 'bg-gray-100 text-gray-700'
                                    }`}>
                                      {line}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          ) : (
                            <p className="text-gray-400 text-center py-8">No transcript available</p>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Right Column - AI Assessment */}
                    <div className="space-y-4">
                      {/* Run Assessment Button */}
                      <button
                        onClick={async () => {
                          setIsEvaluating(true);
                          try {
                            const evaluation = await CallEvaluationService.evaluateCall({
                              callId: selectedCall.callSid || selectedCall.id,
                              transcript: selectedCall.transcript || '',
                              duration: selectedCall.duration || 0,
                              patientId: selectedCall.patientId || selectedCall.to,
                              patientName: selectedCall.patientName,
                              callType: selectedCall.direction?.includes('inbound') ? 'inbound' : 'outbound',
                              wasEscalated: selectedCall.outcome !== 'resolved',
                              wasTransferred: false,
                              recordingUrl: selectedCall.recordingUrl,
                            });
                            setCallEvaluation(evaluation);
                          } catch (err) {
                            console.error('Evaluation error:', err);
                          }
                          setIsEvaluating(false);
                        }}
                        disabled={isEvaluating}
                        className="w-full py-3 px-4 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-medium rounded-xl hover:from-purple-700 hover:to-indigo-700 disabled:opacity-50 flex items-center justify-center gap-2"
                      >
                        {isEvaluating ? (
                          <>
                            <RefreshCw size={16} className="animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          <>
                            <Brain size={16} />
                            Run AI Assessment
                          </>
                        )}
                      </button>

                      {/* AI Assessment Results */}
                      {callEvaluation && (
                        <>
                          {/* Overall Score */}
                          <div className="bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl p-4 text-white">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm font-medium opacity-90">Overall Score</span>
                              <Sparkles size={16} />
                            </div>
                            <p className="text-4xl font-bold">{callEvaluation.overallScore}</p>
                            <p className="text-xs opacity-75">out of 100</p>
                          </div>

                          {/* Score Breakdown */}
                          <div className="bg-white rounded-xl border border-gray-200 p-4">
                            <h5 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                              <Target size={14} />
                              Score Breakdown
                            </h5>
                            <div className="space-y-2">
                              {Object.entries(callEvaluation.scores).map(([key, value]) => (
                                <div key={key} className="flex items-center gap-2">
                                  <span className="text-xs text-gray-600 capitalize w-24">{key}</span>
                                  <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                                    <div 
                                      className={`h-full rounded-full ${
                                        value >= 80 ? 'bg-green-500' : value >= 60 ? 'bg-amber-500' : 'bg-red-500'
                                      }`}
                                      style={{ width: `${value}%` }}
                                    />
                                  </div>
                                  <span className="text-xs font-medium w-8">{value}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Sentiment */}
                          <div className="bg-white rounded-xl border border-gray-200 p-4">
                            <h5 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                              <Heart size={14} />
                              Sentiment Analysis
                            </h5>
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="text-gray-600">Overall</span>
                                <span className={`font-medium ${
                                  callEvaluation.sentiment.overall === 'positive' ? 'text-green-600' :
                                  callEvaluation.sentiment.overall === 'negative' ? 'text-red-600' : 'text-gray-600'
                                }`}>{callEvaluation.sentiment.overall}</span>
                              </div>
                              <div className="flex justify-between text-sm">
                                <span className="text-gray-600">Patient Mood</span>
                                <span className="font-medium">{callEvaluation.sentiment.patientMood}</span>
                              </div>
                              <div className="flex justify-between text-sm">
                                <span className="text-gray-600">Agent Tone</span>
                                <span className="font-medium">{callEvaluation.sentiment.agentTone}</span>
                              </div>
                            </div>
                          </div>

                          {/* Compliance */}
                          <div className="bg-white rounded-xl border border-gray-200 p-4">
                            <h5 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                              <Shield size={14} />
                              Compliance
                            </h5>
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">HIPAA Compliant</span>
                                {callEvaluation.compliance.hipaaCompliant ? (
                                  <CheckCircle size={16} className="text-green-500" />
                                ) : (
                                  <XCircle size={16} className="text-red-500" />
                                )}
                              </div>
                              {callEvaluation.compliance.hipaaViolations.length > 0 && (
                                <div className="bg-red-50 rounded p-2 text-xs text-red-700">
                                  {callEvaluation.compliance.hipaaViolations.join(', ')}
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Summary */}
                          <div className="bg-blue-50 rounded-xl border border-blue-200 p-4">
                            <h5 className="text-sm font-semibold text-blue-900 mb-2 flex items-center gap-2">
                              <Zap size={14} />
                              AI Summary
                            </h5>
                            <p className="text-sm text-blue-800">{callEvaluation.summary}</p>
                          </div>

                          {/* Recommendations */}
                          {callEvaluation.recommendations.forAgent.length > 0 && (
                            <div className="bg-amber-50 rounded-xl border border-amber-200 p-4">
                              <h5 className="text-sm font-semibold text-amber-900 mb-2">Recommendations</h5>
                              <ul className="text-sm text-amber-800 space-y-1">
                                {callEvaluation.recommendations.forAgent.map((rec, i) => (
                                  <li key={i} className="flex items-start gap-2">
                                    <span>•</span>
                                    <span>{rec}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </>
                      )}

                      {/* Rating Actions */}
                      <div className="bg-gray-50 rounded-xl border border-gray-200 p-4">
                        <p className="text-sm text-gray-600 mb-3">Rate AI Performance:</p>
                        <div className="flex items-center gap-2">
                          <button className="flex-1 py-2 px-3 rounded-lg border border-gray-300 hover:bg-green-50 hover:border-green-300 transition-colors flex items-center justify-center gap-2">
                            <ThumbsUp size={16} className="text-green-600" />
                            <span className="text-sm">Good</span>
                          </button>
                          <button className="flex-1 py-2 px-3 rounded-lg border border-gray-300 hover:bg-red-50 hover:border-red-300 transition-colors flex items-center justify-center gap-2">
                            <ThumbsDown size={16} className="text-red-600" />
                            <span className="text-sm">Needs Work</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                /* Call List */
                <div className="space-y-2">
                  {displayCalls.map((call) => (
                    <div
                      key={call.id}
                      onClick={() => setSelectedCall(call)}
                      className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl border border-gray-200 hover:border-purple-300 cursor-pointer transition-colors"
                    >
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        call.handler === 'ai' ? 'bg-purple-100' : 'bg-amber-100'
                      }`}>
                        {call.handler === 'ai' ? (
                          <Bot size={20} className="text-purple-600" />
                        ) : (
                          <User size={20} className="text-amber-600" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-gray-900">{call.patientName}</span>
                          <span className={`px-2 py-0.5 text-xs rounded-full ${
                            call.outcome === 'resolved' 
                              ? 'bg-green-100 text-green-700' 
                              : 'bg-amber-100 text-amber-700'
                          }`}>
                            {call.outcome}
                          </span>
                        </div>
                        <p className="text-sm text-gray-500">{call.topic}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-gray-700">
                          {Math.floor(call.duration / 60)}:{String(call.duration % 60).padStart(2, '0')}
                        </p>
                        <p className="text-xs text-gray-400">
                          {new Date(call.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        {call.recordingUrl && <Volume2 size={14} className="text-purple-500" title="Has recording" />}
                        {call.transcript && <FileText size={14} className="text-blue-500" title="Has transcript" />}
                        <div className="flex">
                          {[1,2,3,4,5].map(i => (
                            <Star 
                              key={i} 
                              size={12} 
                              className={i <= call.satisfaction ? 'text-amber-400 fill-amber-400' : 'text-gray-300'} 
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'sms' && (
            <div className="space-y-2">
              {selectedConversation ? (
                /* Enhanced Conversation Thread View with AI Assessment */
                <div>
                  <button 
                    onClick={() => { setSelectedConversation(null); setSmsEvaluation(null); }}
                    className="flex items-center gap-2 text-purple-600 hover:underline mb-4"
                  >
                    <ArrowLeft size={14} /> Back to conversations
                  </button>
                  
                  <div className="grid grid-cols-3 gap-4">
                    {/* Left Column - Conversation */}
                    <div className="col-span-2 space-y-4">
                      {/* Conversation Header */}
                      <div className="bg-gray-50 rounded-xl border border-gray-200 p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold text-gray-900">{selectedConversation.phone}</h3>
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-700">
                              {selectedConversation.messageCount} messages
                            </span>
                            <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-700">
                              {selectedConversation.inboundCount || 0} patient
                            </span>
                          </div>
                        </div>
                        <p className="text-sm text-gray-500">
                          {new Date(selectedConversation.messages[0]?.timestamp).toLocaleDateString()} - {new Date(selectedConversation.lastTimestamp).toLocaleDateString()}
                        </p>
                      </div>

                      {/* Message Thread */}
                      <div className="bg-white rounded-xl border border-gray-200 p-4">
                        <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                          <MessageSquare size={14} />
                          Conversation
                        </h4>
                        <div className="space-y-3 max-h-96 overflow-y-auto bg-gray-50 rounded-lg p-4">
                          {selectedConversation.messages.map((msg) => (
                            <div 
                              key={msg.id}
                              className={`flex ${msg.direction === 'outbound' ? 'justify-end' : 'justify-start'}`}
                            >
                              <div className={`max-w-[80%] p-3 rounded-lg ${
                                msg.direction === 'outbound' 
                                  ? 'bg-green-100 text-green-900' 
                                  : 'bg-blue-100 text-blue-900'
                              }`}>
                                <p className="text-sm">{msg.content}</p>
                                <p className="text-xs mt-1 opacity-70">
                                  {msg.direction === 'inbound' ? 'Patient' : 'AI'} • {new Date(msg.timestamp).toLocaleTimeString()}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Right Column - AI Assessment */}
                    <div className="space-y-4">
                      {/* Run Assessment Button */}
                      <button
                        onClick={async () => {
                          setIsEvaluatingSMS(true);
                          try {
                            const evaluation = await SMSEvaluationService.evaluateConversation({
                              conversationId: selectedConversation.id,
                              messages: selectedConversation.messages.map(m => ({
                                from: m.direction === 'inbound' ? selectedConversation.phone : 'office',
                                to: m.direction === 'outbound' ? selectedConversation.phone : 'office',
                                body: m.content,
                                timestamp: m.timestamp,
                                direction: m.direction,
                              })),
                              patientPhone: selectedConversation.phone,
                              officePhone: 'office',
                            });
                            setSmsEvaluation(evaluation);
                          } catch (err) {
                            console.error('SMS Evaluation error:', err);
                          }
                          setIsEvaluatingSMS(false);
                        }}
                        disabled={isEvaluatingSMS}
                        className="w-full py-3 px-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-medium rounded-xl hover:from-blue-700 hover:to-indigo-700 disabled:opacity-50 flex items-center justify-center gap-2"
                      >
                        {isEvaluatingSMS ? (
                          <>
                            <RefreshCw size={16} className="animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          <>
                            <Brain size={16} />
                            Run AI Assessment
                          </>
                        )}
                      </button>

                      {/* SMS Assessment Results */}
                      {smsEvaluation && (
                        <>
                          {/* Overall Score */}
                          <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl p-4 text-white">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm font-medium opacity-90">Overall Score</span>
                              <Sparkles size={16} />
                            </div>
                            <p className="text-4xl font-bold">{smsEvaluation.overallScore}</p>
                            <p className="text-xs opacity-75">out of 100</p>
                          </div>

                          {/* Score Breakdown */}
                          <div className="bg-white rounded-xl border border-gray-200 p-4">
                            <h5 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                              <Target size={14} />
                              Score Breakdown
                            </h5>
                            <div className="space-y-2">
                              {Object.entries(smsEvaluation.scores).map(([key, value]) => (
                                <div key={key} className="flex items-center gap-2">
                                  <span className="text-xs text-gray-600 capitalize w-28">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                                  <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                                    <div 
                                      className={`h-full rounded-full ${
                                        value >= 80 ? 'bg-green-500' : value >= 60 ? 'bg-amber-500' : 'bg-red-500'
                                      }`}
                                      style={{ width: `${value}%` }}
                                    />
                                  </div>
                                  <span className="text-xs font-medium w-8">{value}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Sentiment */}
                          <div className="bg-white rounded-xl border border-gray-200 p-4">
                            <h5 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                              <Heart size={14} />
                              Sentiment Analysis
                            </h5>
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="text-gray-600">Overall</span>
                                <span className={`font-medium ${
                                  smsEvaluation.sentiment.overall === 'positive' ? 'text-green-600' :
                                  smsEvaluation.sentiment.overall === 'negative' ? 'text-red-600' : 'text-gray-600'
                                }`}>{smsEvaluation.sentiment.overall}</span>
                              </div>
                              <div className="flex justify-between text-sm">
                                <span className="text-gray-600">Patient Mood</span>
                                <span className="font-medium">{smsEvaluation.sentiment.patientMood}</span>
                              </div>
                              <div className="flex justify-between text-sm">
                                <span className="text-gray-600">AI Tone</span>
                                <span className="font-medium">{smsEvaluation.sentiment.aiTone}</span>
                              </div>
                              <div className="flex justify-between text-sm">
                                <span className="text-gray-600">Mood Trend</span>
                                <span className={`font-medium ${
                                  smsEvaluation.sentiment.moodProgression === 'improved' ? 'text-green-600' :
                                  smsEvaluation.sentiment.moodProgression === 'declined' ? 'text-red-600' : 'text-gray-600'
                                }`}>{smsEvaluation.sentiment.moodProgression}</span>
                              </div>
                            </div>
                          </div>

                          {/* Compliance */}
                          <div className="bg-white rounded-xl border border-gray-200 p-4">
                            <h5 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                              <Shield size={14} />
                              Compliance
                            </h5>
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">HIPAA Compliant</span>
                                {smsEvaluation.compliance.hipaaCompliant ? (
                                  <CheckCircle size={16} className="text-green-500" />
                                ) : (
                                  <XCircle size={16} className="text-red-500" />
                                )}
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">Appropriate Content</span>
                                {smsEvaluation.compliance.appropriateContent ? (
                                  <CheckCircle size={16} className="text-green-500" />
                                ) : (
                                  <XCircle size={16} className="text-red-500" />
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Summary */}
                          <div className="bg-blue-50 rounded-xl border border-blue-200 p-4">
                            <h5 className="text-sm font-semibold text-blue-900 mb-2 flex items-center gap-2">
                              <Zap size={14} />
                              AI Summary
                            </h5>
                            <p className="text-sm text-blue-800">{smsEvaluation.summary}</p>
                            <div className="mt-2 text-xs text-blue-600">
                              {smsEvaluation.messageCount} messages • {smsEvaluation.conversationDuration}
                            </div>
                          </div>

                          {/* Recommendations */}
                          {smsEvaluation.recommendations.forAI.length > 0 && (
                            <div className="bg-amber-50 rounded-xl border border-amber-200 p-4">
                              <h5 className="text-sm font-semibold text-amber-900 mb-2">AI Recommendations</h5>
                              <ul className="text-sm text-amber-800 space-y-1">
                                {smsEvaluation.recommendations.forAI.map((rec, i) => (
                                  <li key={i} className="flex items-start gap-2">
                                    <span>•</span>
                                    <span>{rec}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {/* Follow-up */}
                          {smsEvaluation.followUpRequired && (
                            <div className="bg-red-50 rounded-xl border border-red-200 p-4">
                              <h5 className="text-sm font-semibold text-red-900 mb-2 flex items-center gap-2">
                                <AlertTriangle size={14} />
                                Follow-up Required
                              </h5>
                              <p className="text-sm text-red-800">{smsEvaluation.followUpReason}</p>
                              {smsEvaluation.suggestedAction && (
                                <p className="text-sm text-red-700 mt-1 font-medium">
                                  Action: {smsEvaluation.suggestedAction}
                                </p>
                              )}
                            </div>
                          )}
                        </>
                      )}

                      {/* Rating Actions */}
                      <div className="bg-gray-50 rounded-xl border border-gray-200 p-4">
                        <p className="text-sm text-gray-600 mb-3">Rate AI Performance:</p>
                        <div className="flex items-center gap-2">
                          <button className="flex-1 py-2 px-3 rounded-lg border border-gray-300 hover:bg-green-50 hover:border-green-300 transition-colors flex items-center justify-center gap-2">
                            <ThumbsUp size={16} className="text-green-600" />
                            <span className="text-sm">Good</span>
                          </button>
                          <button className="flex-1 py-2 px-3 rounded-lg border border-gray-300 hover:bg-red-50 hover:border-red-300 transition-colors flex items-center justify-center gap-2">
                            <ThumbsDown size={16} className="text-red-600" />
                            <span className="text-sm">Needs Work</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : smsConversations.length === 0 ? (
                <div className="text-center py-12">
                  <MessageSquare size={48} className="mx-auto text-gray-300 mb-4" />
                  <h3 className="text-lg font-semibold text-gray-700">No SMS Conversations</h3>
                  <p className="text-sm text-gray-500">SMS conversations will appear here.</p>
                </div>
              ) : (
                /* Conversation List */
                smsConversations.map((conv) => (
                  <div 
                    key={conv.id} 
                    className="p-4 bg-gray-50 rounded-xl border border-gray-200 hover:border-blue-300 cursor-pointer transition-colors"
                    onClick={() => setSelectedConversation(conv)}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                        <MessageSquare size={20} className="text-blue-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-gray-900">{conv.phone}</span>
                          <span className="px-2 py-0.5 text-xs rounded-full bg-gray-200 text-gray-700">
                            {conv.messageCount} msgs
                          </span>
                          {conv.inboundCount > 0 && (
                            <span className="px-2 py-0.5 text-xs rounded-full bg-blue-100 text-blue-700">
                              {conv.inboundCount} patient
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 truncate">{conv.lastMessage}</p>
                        <p className="text-xs text-gray-400 mt-1">
                          {new Date(conv.lastTimestamp).toLocaleString()}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button 
                          className="p-2 rounded-lg border border-gray-300 hover:bg-green-50 hover:border-green-300 transition-colors"
                          title="AI handled well"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <ThumbsUp size={14} className="text-green-600" />
                        </button>
                        <button 
                          className="p-2 rounded-lg border border-gray-300 hover:bg-red-50 hover:border-red-300 transition-colors"
                          title="AI needs correction"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <ThumbsDown size={14} className="text-red-600" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'escalations' && (
            <div className="space-y-2">
              {escalations.filter(e => e.source === 'ai').length === 0 ? (
                <div className="text-center py-12">
                  <CheckCircle size={48} className="mx-auto text-green-400 mb-4" />
                  <h3 className="text-lg font-semibold text-gray-700">No AI Escalations</h3>
                  <p className="text-sm text-gray-500">AI has handled all calls without escalation.</p>
                </div>
              ) : (
                escalations.filter(e => e.source === 'ai').map((esc) => (
                  <div key={esc.id} className="p-4 bg-gray-50 rounded-xl border border-gray-200">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                        <Bot size={20} className="text-purple-600" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-gray-900">{esc.patientName}</span>
                          <span className={`px-2 py-0.5 text-xs rounded-full ${
                            esc.priority === 'high' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                          }`}>
                            {esc.priority}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{esc.reason}</p>
                        {esc.aiSuggestedAction && (
                          <div className="bg-purple-50 rounded p-2 text-sm text-purple-700">
                            <strong>AI Suggestion:</strong> {esc.aiSuggestedAction}
                          </div>
                        )}
                        <p className="text-xs text-gray-400 mt-2">
                          {new Date(esc.createdAt).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200 bg-gray-50">
          <div className="flex items-center justify-between">
            <p className="text-xs text-gray-500">
              Data refreshed {new Date().toLocaleTimeString()}
            </p>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIPerformanceMonitor;
