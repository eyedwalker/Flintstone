export { default as EscalationQueuePopup } from './EscalationQueuePopup';
export { default as EscalationTrigger } from './EscalationTrigger';
export { default as AIPerformanceMonitor } from './AIPerformanceMonitor';
export { default as UnifiedCommunicationsPanel } from './UnifiedCommunicationsPanel';
export { 
  CommunicationTemplateSelector, 
  VoiceTemplateSelector,  // Backward compat alias
  QuickTemplateSelect 
} from './VoiceTemplateSelector';
