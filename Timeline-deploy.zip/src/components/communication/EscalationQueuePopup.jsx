import React, { useState, useEffect } from 'react';
import { 
  X, 
  ArrowLeft, 
  AlertTriangle, 
  Filter, 
  RefreshCw, 
  CheckCircle, 
  Clock, 
  User, 
  MessageSquare,
  Phone,
  Mail,
  ChevronRight,
  ChevronDown,
  Bell,
  FileText,
  Bot,
  Headphones,
  Play,
  ExternalLink
} from 'lucide-react';
import { CommunicationService } from '../../services/communicationService';

const EscalationQueuePopup = ({ isOpen, onClose, onSelectEscalation }) => {
  const [escalations, setEscalations] = useState([]);
  const [filters, setFilters] = useState({
    myEscalationsOnly: false,
    unassigned: true,
    assigned: true,
    acknowledged: true,
    inProgress: true,
  });
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [expandedEscalation, setExpandedEscalation] = useState(null);

  useEffect(() => {
    if (isOpen) {
      loadEscalations();
    }
  }, [isOpen]);

  const loadEscalations = async () => {
    // Start with localStorage escalations
    const localEscalations = CommunicationService.getEscalations();

    // Also fetch voice + SMS escalations from Supabase
    try {
      const res = await fetch('/api/data/escalations');
      if (res.ok) {
        const data = await res.json();
        const dbEscalations = (data.escalations || [])
          .filter(esc => !localEscalations.some(e => e.id === esc.id))
          .map(esc => ({
            id: esc.id,
            patientId: esc.phone || 'unknown',
            patientName: esc.phone || (esc.type === 'sms' ? 'SMS Patient' : 'Voice Caller'),
            appointmentId: '',
            reason: esc.reason,
            priority: 'high',
            status: 'active',
            source: esc.type === 'sms' ? 'sms' : 'ai',
            createdAt: esc.createdAt || new Date().toISOString(),
            transcript: esc.transcript || null,
          }));
        setEscalations([...localEscalations, ...dbEscalations]);
        return;
      }
    } catch (err) {
      console.log('[EscalationQueue] Could not fetch DB escalations:', err.message);
    }

    setEscalations(localEscalations);
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    loadEscalations();
    setTimeout(() => setIsRefreshing(false), 500);
  };

  const filteredEscalations = escalations.filter(esc => {
    // Filter by status
    if (esc.status === 'active' && !filters.unassigned) return false;
    if (esc.status === 'assigned' && !filters.assigned) return false;
    if (esc.status === 'acknowledged' && !filters.acknowledged) return false;
    if (esc.status === 'in_progress' && !filters.inProgress) return false;
    if (esc.status === 'resolved') return false; // Don't show resolved
    return true;
  });

  const activeCount = escalations.filter(e => e.status !== 'resolved').length;

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      case 'medium': return 'text-amber-600 bg-amber-50 border-amber-200';
      case 'low': return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'active':
        return <span className="px-2 py-0.5 text-xs rounded-full bg-red-100 text-red-700">Unassigned</span>;
      case 'assigned':
        return <span className="px-2 py-0.5 text-xs rounded-full bg-blue-100 text-blue-700">Assigned</span>;
      case 'acknowledged':
        return <span className="px-2 py-0.5 text-xs rounded-full bg-amber-100 text-amber-700">Acknowledged</span>;
      case 'in_progress':
        return <span className="px-2 py-0.5 text-xs rounded-full bg-purple-100 text-purple-700">In Progress</span>;
      default:
        return null;
    }
  };

  const getSourceIcon = (source) => {
    switch (source) {
      case 'ai':
        return <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center"><Bell size={16} className="text-purple-600" /></div>;
      case 'patient':
        return <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center"><User size={16} className="text-green-600" /></div>;
      case 'sms':
        return <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center"><MessageSquare size={16} className="text-blue-600" /></div>;
      default:
        return <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center"><AlertTriangle size={16} className="text-gray-600" /></div>;
    }
  };

  const handleAcknowledge = (escalationId, e) => {
    e.stopPropagation();
    CommunicationService.acknowledgeEscalation(escalationId);
    loadEscalations();
  };

  const handleResolve = (escalationId, e) => {
    e.stopPropagation();
    CommunicationService.resolveEscalation(escalationId);
    loadEscalations();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center gap-3 p-4 border-b border-gray-200">
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft size={20} className="text-gray-600" />
          </button>
          <h2 className="text-lg font-semibold text-gray-900">AI Communication Center</h2>
        </div>

        {/* Escalation Queue Header */}
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <AlertTriangle size={20} className="text-amber-500" />
              <span className="font-semibold text-gray-900">Escalation Queue</span>
              <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                activeCount > 0 ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600'
              }`}>
                {activeCount}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                <Filter size={16} className="text-gray-600" />
              </button>
              <button 
                onClick={handleRefresh}
                className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <RefreshCw size={16} className={`text-gray-600 ${isRefreshing ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          {/* Filters */}
          <div className="flex items-center gap-4 text-sm">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.myEscalationsOnly}
                onChange={(e) => setFilters(prev => ({ ...prev, myEscalationsOnly: e.target.checked }))}
                className="w-4 h-4 rounded border-gray-300 text-[#006FB4] focus:ring-[#006FB4]"
              />
              <span className="text-gray-700">My escalations only</span>
            </label>
            <span className="text-gray-400">Status:</span>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.unassigned}
                onChange={(e) => setFilters(prev => ({ ...prev, unassigned: e.target.checked }))}
                className="w-4 h-4 rounded border-gray-300 text-[#006FB4] focus:ring-[#006FB4]"
              />
              <span className="text-gray-600">Unassigned</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.assigned}
                onChange={(e) => setFilters(prev => ({ ...prev, assigned: e.target.checked }))}
                className="w-4 h-4 rounded border-gray-300 text-[#006FB4] focus:ring-[#006FB4]"
              />
              <span className="text-gray-600">Assigned</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.acknowledged}
                onChange={(e) => setFilters(prev => ({ ...prev, acknowledged: e.target.checked }))}
                className="w-4 h-4 rounded border-gray-300 text-[#006FB4] focus:ring-[#006FB4]"
              />
              <span className="text-gray-600">Acknowledged</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.inProgress}
                onChange={(e) => setFilters(prev => ({ ...prev, inProgress: e.target.checked }))}
                className="w-4 h-4 rounded border-gray-300 text-[#006FB4] focus:ring-[#006FB4]"
              />
              <span className="text-gray-600">In Progress</span>
            </label>
          </div>
        </div>

        {/* Escalation List */}
        <div className="flex-1 overflow-y-auto">
          {filteredEscalations.length === 0 ? (
            /* Empty State */
            <div className="flex flex-col items-center justify-center py-16 px-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                <CheckCircle size={32} className="text-green-500" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-1">All caught up!</h3>
              <p className="text-gray-500 text-center">No escalations require attention right now.</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {filteredEscalations.map((escalation) => (
                <div key={escalation.id} className="border-b border-gray-100">
                  {/* Main Row */}
                  <div
                    onClick={() => setExpandedEscalation(expandedEscalation === escalation.id ? null : escalation.id)}
                    className="p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                  >
                    <div className="flex items-start gap-3">
                      {getSourceIcon(escalation.source || 'system')}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-gray-900">{escalation.patientName}</span>
                          {getStatusBadge(escalation.status)}
                          <span className={`px-2 py-0.5 text-xs rounded-full border ${getPriorityColor(escalation.priority)}`}>
                            {escalation.priority}
                          </span>
                          {escalation.source === 'ai' && (
                            <span className="px-2 py-0.5 text-xs rounded-full bg-purple-100 text-purple-700 flex items-center gap-1">
                              <Bot size={10} /> AI
                            </span>
                          )}
                          {escalation.transcript && (
                            <span className="px-2 py-0.5 text-xs rounded-full bg-blue-100 text-blue-700 flex items-center gap-1">
                              <FileText size={10} /> Transcript
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{escalation.reason}</p>
                        <div className="flex items-center gap-4 text-xs text-gray-400">
                          <span className="flex items-center gap-1">
                            <Clock size={12} />
                            {new Date(escalation.createdAt).toLocaleString()}
                          </span>
                          {escalation.callDuration && (
                            <span className="flex items-center gap-1">
                              <Phone size={12} />
                              {Math.floor(escalation.callDuration / 60)}:{String(escalation.callDuration % 60).padStart(2, '0')}
                            </span>
                          )}
                          {escalation.aiConfidenceScore && (
                            <span className="flex items-center gap-1">
                              AI Confidence: {Math.round(escalation.aiConfidenceScore * 100)}%
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {escalation.status === 'active' && (
                          <button
                            onClick={(e) => handleAcknowledge(escalation.id, e)}
                            className="px-3 py-1.5 text-xs font-medium bg-[#006FB4] text-white rounded-lg hover:bg-[#005a94] transition-colors"
                          >
                            Acknowledge
                          </button>
                        )}
                        {(escalation.status === 'acknowledged' || escalation.status === 'in_progress') && (
                          <button
                            onClick={(e) => handleResolve(escalation.id, e)}
                            className="px-3 py-1.5 text-xs font-medium bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                          >
                            Resolve
                          </button>
                        )}
                        {expandedEscalation === escalation.id ? (
                          <ChevronDown size={16} className="text-gray-400" />
                        ) : (
                          <ChevronRight size={16} className="text-gray-400" />
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Expanded Detail Section */}
                  {expandedEscalation === escalation.id && (
                    <div className="px-4 pb-4 bg-gray-50 border-t border-gray-100">
                      <div className="ml-11 space-y-4">
                        {/* AI Suggested Action */}
                        {escalation.aiSuggestedAction && (
                          <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                            <div className="flex items-center gap-2 text-sm font-medium text-purple-700 mb-1">
                              <Bot size={14} />
                              AI Suggested Action
                            </div>
                            <p className="text-sm text-purple-800">{escalation.aiSuggestedAction}</p>
                          </div>
                        )}

                        {/* Transcript Section */}
                        {escalation.transcript && (
                          <div className="bg-white border border-gray-200 rounded-lg p-3">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
                                <FileText size={14} />
                                Call Transcript
                                {escalation.callDuration && (
                                  <span className="text-xs text-gray-500">
                                    ({Math.floor(escalation.callDuration / 60)}:{String(escalation.callDuration % 60).padStart(2, '0')})
                                  </span>
                                )}
                              </div>
                              {escalation.callRecordingUrl && (
                                <button className="flex items-center gap-1 text-xs text-[#006FB4] hover:underline">
                                  <Play size={12} />
                                  Play Recording
                                </button>
                              )}
                            </div>
                            <div className="bg-gray-50 rounded p-3 text-sm text-gray-700 max-h-48 overflow-y-auto font-mono whitespace-pre-wrap">
                              {escalation.transcript}
                            </div>
                          </div>
                        )}

                        {/* No transcript message */}
                        {!escalation.transcript && (
                          <div className="bg-gray-100 rounded-lg p-3 text-sm text-gray-500 italic">
                            No transcript available for this escalation.
                          </div>
                        )}

                        {/* Action Buttons */}
                        <div className="flex items-center gap-2 pt-2">
                          <button
                            onClick={() => onSelectEscalation?.(escalation)}
                            className="px-3 py-1.5 text-xs font-medium border border-gray-300 rounded-lg hover:bg-gray-100 transition-colors flex items-center gap-1"
                          >
                            <ExternalLink size={12} />
                            View Patient
                          </button>
                          {escalation.communicationId && (
                            <button className="px-3 py-1.5 text-xs font-medium border border-gray-300 rounded-lg hover:bg-gray-100 transition-colors flex items-center gap-1">
                              <MessageSquare size={12} />
                              View Full Conversation
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200 bg-gray-50">
          <div className="flex items-center justify-between text-sm text-gray-500">
            <span>Showing {filteredEscalations.length} of {escalations.length} escalations</span>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EscalationQueuePopup;
