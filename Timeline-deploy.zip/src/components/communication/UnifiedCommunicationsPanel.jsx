import React, { useState, useMemo } from 'react';
import { 
  Phone, MessageSquare, Mail, Send, Settings, AlertTriangle, 
  ChevronDown, Clock, CheckCircle, Circle, PhoneCall,
  PhoneOff, Mic, MicOff, Pause, Play, FileText
} from 'lucide-react';
import { QuickTemplateSelect } from './VoiceTemplateSelector';
import { VoiceTemplateService } from '../../services/voiceTemplateService';

const CHANNEL_CONFIG = {
  voice: { icon: Phone, color: 'green', bgColor: 'bg-green-50', borderColor: 'border-green-200', label: 'Call' },
  sms: { icon: MessageSquare, color: 'blue', bgColor: 'bg-blue-50', borderColor: 'border-blue-200', label: 'SMS' },
  email: { icon: Mail, color: 'purple', bgColor: 'bg-purple-50', borderColor: 'border-purple-200', label: 'Email' },
};

const UnifiedCommunicationsPanel = ({
  communications = [],
  onSendSMS,
  onSendEmail,
  onStartCall,
  onEscalate,
  onSettingsClick,
  patientPhone,
  patientEmail,
  patientName,
  patientData = {},
  appointmentData = {},
  officeData = {},
  providerData = {},
  insuranceData = {},
  activeCall,
  onEndCall,
  onToggleMute,
  onToggleHold,
  callDuration,
}) => {
  const [newMessage, setNewMessage] = useState('');
  const [selectedChannel, setSelectedChannel] = useState('sms');
  const [filterChannel, setFilterChannel] = useState('all');
  const [sending, setSending] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  // Combine and sort all communications by timestamp (newest first)
  const unifiedMessages = useMemo(() => {
    const sorted = [...communications].sort((a, b) => 
      new Date(b.timestamp) - new Date(a.timestamp)
    );
    
    if (filterChannel === 'all') return sorted;
    return sorted.filter(m => m.type === filterChannel);
  }, [communications, filterChannel]);

  // Count unread messages
  const unreadCount = useMemo(() => 
    communications.filter(m => m.direction === 'inbound' && !m.read).length,
    [communications]
  );

  // Count by channel
  const channelCounts = useMemo(() => ({
    voice: communications.filter(m => m.type === 'voice').length,
    sms: communications.filter(m => m.type === 'sms').length,
    email: communications.filter(m => m.type === 'email').length,
  }), [communications]);

  const handleSend = async () => {
    if (!newMessage.trim() && selectedChannel !== 'voice') return;
    setSending(true);
    try {
      if (selectedChannel === 'voice') {
        // Start call with template script
        await onStartCall?.(newMessage, selectedTemplate?.id);
        setNewMessage('');
        setSelectedTemplate(null);
      } else if (selectedChannel === 'sms') {
        await onSendSMS?.(newMessage);
        setNewMessage('');
      } else if (selectedChannel === 'email') {
        await onSendEmail?.('Message from your eye care provider', newMessage);
        setNewMessage('');
      }
    } finally {
      setSending(false);
    }
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const formatCallDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Handle template selection
  const handleTemplateSelect = (template) => {
    if (!template) return;
    setSelectedTemplate(template);
    
    // Generate script with variable substitution
    const script = VoiceTemplateService.generateScript(template.id, {
      patient: patientData,
      appointment: appointmentData,
      office: officeData,
      provider: providerData,
      insurance: insuranceData,
    });
    
    if (script) {
      // Combine all script parts into a single message
      const fullScript = [
        script.greeting,
        script.mainScript,
        script.closingScript
      ].filter(Boolean).join(' ');
      
      setNewMessage(fullScript);
    } else if (template.scriptTemplate) {
      // Fallback to raw template
      setNewMessage(template.scriptTemplate);
    }
  };

  return (
    <div className="flex flex-col border-t border-gray-200">
      {/* Header with Title and Settings */}
      <div className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b border-gray-200">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-sm text-gray-800">Communications</span>
          {unreadCount > 0 && (
            <span className="px-1.5 py-0.5 bg-red-500 text-white text-[10px] font-bold rounded-full animate-pulse">
              {unreadCount} new
            </span>
          )}
        </div>
        <button
          onClick={onSettingsClick}
          className="p-1 text-gray-500 hover:text-gray-700 hover:bg-gray-200 rounded"
        >
          <Settings size={14} />
        </button>
      </div>

      {/* AI Call Initiated Banner - shows briefly then hides */}
      {activeCall && (
        <div className="bg-green-500 text-white px-3 py-2 flex items-center gap-2">
          <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
          <span className="text-sm font-medium">AI call initiated</span>
          <span className="text-xs opacity-80">Check AI Monitor for transcript</span>
        </div>
      )}

      {/* Channel Buttons - TOP */}
      <div className="px-2 py-2 bg-white border-b border-gray-100">
        <div className="flex gap-1">
          <button
            onClick={() => setSelectedChannel('voice')}
            className={`flex-1 py-2 rounded text-xs font-medium flex items-center justify-center gap-1 ${
              selectedChannel === 'voice' ? 'bg-green-500 text-white' : 'bg-green-100 text-green-700 hover:bg-green-200'
            }`}
          >
            <Phone size={12} /> Call
          </button>
          <button
            onClick={() => setSelectedChannel('sms')}
            className={`flex-1 py-2 rounded text-xs font-medium flex items-center justify-center gap-1 ${
              selectedChannel === 'sms' ? 'bg-blue-500 text-white' : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
            }`}
          >
            <MessageSquare size={12} /> SMS
          </button>
          <button
            onClick={() => setSelectedChannel('email')}
            className={`flex-1 py-2 rounded text-xs font-medium flex items-center justify-center gap-1 ${
              selectedChannel === 'email' ? 'bg-purple-500 text-white' : 'bg-purple-100 text-purple-700 hover:bg-purple-200'
            }`}
          >
            <Mail size={12} /> Email
          </button>
        </div>
      </div>

      {/* Template Selector */}
      <div className="px-2 py-2 bg-white border-b border-gray-100">
        <QuickTemplateSelect
          channel={selectedChannel === 'voice' ? 'voice' : selectedChannel}
          selectedId={selectedTemplate?.id}
          onSelect={handleTemplateSelect}
        />
      </div>

      {/* Message Input */}
      <div className="px-2 py-2 bg-white border-b border-gray-100">
        <div className="flex gap-1.5">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder={selectedChannel === 'voice' ? 'Select template or type script...' : `Type ${selectedChannel === 'email' ? 'email' : 'message'}...`}
            className="flex-1 text-xs border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-300 focus:border-blue-400"
          />
          <button
            onClick={handleSend}
            disabled={sending || (!newMessage.trim() && selectedChannel !== 'voice') || activeCall}
            className={`px-4 py-2 text-white rounded-lg text-xs font-medium disabled:opacity-50 flex items-center gap-1 ${
              selectedChannel === 'voice' 
                ? 'bg-green-500 hover:bg-green-600' 
                : selectedChannel === 'email' 
                  ? 'bg-purple-500 hover:bg-purple-600' 
                  : 'bg-blue-500 hover:bg-blue-600'
            }`}
          >
            {selectedChannel === 'voice' ? <PhoneCall size={12} /> : <Send size={12} />}
            {selectedChannel === 'voice' && <span>Call</span>}
          </button>
        </div>
        {/* Contact Info & Escalate */}
        <div className="flex items-center justify-between mt-1.5 text-[10px] text-gray-500">
          <div className="flex items-center gap-3">
            {patientPhone && (
              <span className="flex items-center gap-1">
                <Phone size={10} /> {patientPhone}
              </span>
            )}
            {patientEmail && (
              <span className="flex items-center gap-1 truncate max-w-[150px]">
                <Mail size={10} /> {patientEmail}
              </span>
            )}
          </div>
          <button
            onClick={() => onEscalate?.('Needs follow-up')}
            className="flex items-center gap-1 text-red-600 hover:text-red-700 font-medium"
          >
            <AlertTriangle size={10} /> Escalate
          </button>
        </div>
      </div>

      {/* Message History - Filter Pills */}
      <div className="px-2 py-1.5 bg-gray-50 border-b border-gray-100 flex items-center gap-2">
        <span className="text-[10px] text-gray-500 font-medium">History:</span>
        <div className="flex gap-0.5 bg-gray-200 rounded p-0.5">
          <button
            onClick={() => setFilterChannel('all')}
            className={`px-2 py-0.5 text-[10px] font-medium rounded ${
              filterChannel === 'all' ? 'bg-white shadow-sm text-gray-800' : 'text-gray-600 hover:text-gray-800'
            }`}
          >
            All
          </button>
          {Object.entries(CHANNEL_CONFIG).map(([key, config]) => {
            const Icon = config.icon;
            const count = channelCounts[key];
            return (
              <button
                key={key}
                onClick={() => setFilterChannel(key)}
                className={`px-1.5 py-0.5 text-[10px] font-medium rounded flex items-center gap-0.5 ${
                  filterChannel === key ? 'bg-white shadow-sm text-gray-800' : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                <Icon size={10} />
                {count > 0 && <span>{count}</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* Unified Message Timeline - BELOW */}
      <div className="flex-1 overflow-y-auto px-2 py-2 space-y-1.5 max-h-[200px] bg-white">
        {unifiedMessages.length > 0 ? (
          unifiedMessages.map((msg) => {
            const config = CHANNEL_CONFIG[msg.type] || CHANNEL_CONFIG.sms;
            const Icon = config.icon;
            const isOutbound = msg.direction === 'outbound';
            const isUnread = msg.direction === 'inbound' && !msg.read;

            return (
              <div
                key={msg.id}
                className={`flex gap-2 ${isOutbound ? 'flex-row-reverse' : ''}`}
              >
                {/* Channel Icon */}
                <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${config.bgColor} ${config.borderColor} border`}>
                  <Icon size={10} className={`text-${config.color}-600`} />
                </div>
                
                {/* Message Bubble */}
                <div className={`flex-1 max-w-[85%] ${isOutbound ? 'text-right' : ''}`}>
                  <div
                    className={`inline-block px-2 py-1 rounded-lg text-xs ${
                      isOutbound 
                        ? `${config.bgColor} ${config.borderColor} border` 
                        : 'bg-gray-100 border border-gray-200'
                    } ${isUnread ? 'ring-2 ring-red-300' : ''}`}
                  >
                    {/* Message Header */}
                    <div className="flex items-center gap-1.5 mb-0.5 text-[9px] text-gray-500">
                      <span className="font-medium">
                        {isOutbound ? msg.sentBy || 'Staff' : patientName || 'Patient'}
                      </span>
                      <span>•</span>
                      <span>{formatTime(msg.timestamp)}</span>
                      {isUnread && <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />}
                    </div>
                    
                    {/* Message Content */}
                    <div className="text-gray-800 text-[11px]">
                      {msg.type === 'voice' ? (
                        <span className="italic text-gray-600">
                          {msg.content || `${msg.direction === 'outbound' ? 'Outgoing' : 'Incoming'} call`}
                        </span>
                      ) : (
                        msg.content?.length > 100 ? msg.content.substring(0, 100) + '...' : msg.content
                      )}
                    </div>

                    {/* Status */}
                    {isOutbound && msg.status && (
                      <div className="flex items-center gap-1 mt-0.5 text-[9px] text-gray-400">
                        {msg.status === 'delivered' ? (
                          <><CheckCircle size={8} className="text-green-500" /> Delivered</>
                        ) : msg.status === 'sent' ? (
                          <><Circle size={8} /> Sent</>
                        ) : (
                          <><Clock size={8} /> {msg.status}</>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="flex flex-col items-center justify-center text-gray-400 py-4">
            <MessageSquare size={20} className="mb-1 opacity-50" />
            <span className="text-[10px]">No communications yet</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default UnifiedCommunicationsPanel;
