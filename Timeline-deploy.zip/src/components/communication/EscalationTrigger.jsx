import React, { useState, useEffect } from 'react';
import { Bell, AlertTriangle } from 'lucide-react';
import { CommunicationService } from '../../services/communicationService';
import EscalationQueuePopup from './EscalationQueuePopup';

const EscalationTrigger = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeCount, setActiveCount] = useState(0);

  useEffect(() => {
    // Check escalation count periodically
    const checkEscalations = () => {
      const escalations = CommunicationService.getEscalations();
      const active = escalations.filter(e => e.status !== 'resolved').length;
      setActiveCount(active);
    };

    checkEscalations();
    const interval = setInterval(checkEscalations, 5000); // Check every 5 seconds

    return () => clearInterval(interval);
  }, []);

  const handleSelectEscalation = (escalation) => {
    console.log('[Escalation] Selected:', escalation);
    // Could navigate to patient or open detail view
  };

  return (
    <>
      {/* Floating Trigger Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-40 flex items-center gap-2 px-4 py-3 bg-[#003366] text-white rounded-full shadow-lg hover:bg-[#004488] transition-all hover:scale-105"
      >
        <div className="relative">
          <Bell size={20} />
          {activeCount > 0 && (
            <span className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center animate-pulse">
              {activeCount > 9 ? '9+' : activeCount}
            </span>
          )}
        </div>
        <span className="font-medium">Escalations</span>
      </button>

      {/* Popup */}
      <EscalationQueuePopup
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onSelectEscalation={handleSelectEscalation}
      />
    </>
  );
};

export default EscalationTrigger;
