import React from 'react';
import { Plus, Trash2 } from 'lucide-react';

function DataTable({ items, categories, lanes, onUpdateItem, onDeleteItem, onAddItem }) {
  return (
    <div className="bg-white rounded-xl shadow-sm border p-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Timeline Items</h2>
        <button
          onClick={onAddItem}
          className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus size={16} /> Add Item
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b">
              <th className="text-left py-3 px-2 font-medium text-gray-600">Name</th>
              <th className="text-left py-3 px-2 font-medium text-gray-600">Lane</th>
              <th className="text-left py-3 px-2 font-medium text-gray-600">Start Date</th>
              <th className="text-left py-3 px-2 font-medium text-gray-600">End Date</th>
              <th className="text-left py-3 px-2 font-medium text-gray-600">Category</th>
              <th className="text-left py-3 px-2 font-medium text-gray-600">Row</th>
              <th className="py-3 px-2"></th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => {
              const category = categories.find(c => c.id === item.categoryId);
              const lane = lanes.find(l => l.id === item.laneId);
              return (
                <tr key={item.id} className="border-b hover:bg-gray-50">
                  <td className="py-2 px-2">
                    <input
                      type="text"
                      value={item.name}
                      onChange={(e) => onUpdateItem(item.id, 'name', e.target.value)}
                      className="w-full px-2 py-1.5 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </td>
                  <td className="py-2 px-2">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: lane?.color || '#6B7280' }}
                      />
                      <select
                        value={item.laneId || lanes[0]?.id}
                        onChange={(e) => onUpdateItem(item.id, 'laneId', e.target.value)}
                        className="px-2 py-1.5 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      >
                        {lanes.map((ln) => (
                          <option key={ln.id} value={ln.id}>
                            {ln.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </td>
                  <td className="py-2 px-2">
                    <input
                      type="date"
                      value={item.startDate}
                      onChange={(e) => onUpdateItem(item.id, 'startDate', e.target.value)}
                      className="px-2 py-1.5 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </td>
                  <td className="py-2 px-2">
                    <input
                      type="date"
                      value={item.endDate}
                      onChange={(e) => onUpdateItem(item.id, 'endDate', e.target.value)}
                      className="px-2 py-1.5 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Optional"
                    />
                  </td>
                  <td className="py-2 px-2">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-4 h-4 rounded"
                        style={{ backgroundColor: category?.color || '#ccc' }}
                      />
                      <select
                        value={item.categoryId}
                        onChange={(e) => onUpdateItem(item.id, 'categoryId', e.target.value)}
                        className="px-2 py-1.5 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      >
                        {categories.map((cat) => (
                          <option key={cat.id} value={cat.id}>
                            {cat.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </td>
                  <td className="py-2 px-2">
                    <input
                      type="number"
                      value={item.row}
                      onChange={(e) => onUpdateItem(item.id, 'row', parseInt(e.target.value) || 0)}
                      className="w-16 px-2 py-1.5 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      min="0"
                    />
                  </td>
                  <td className="py-2 px-2">
                    <button
                      onClick={() => onDeleteItem(item.id)}
                      className="p-1.5 text-red-500 hover:bg-red-50 rounded transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {items.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No items yet. Click "Add Item" to get started.
        </div>
      )}

      <div className="mt-4 p-4 bg-blue-50 rounded-lg text-sm text-blue-800">
        <strong>Tips:</strong>
        <ul className="mt-1 list-disc list-inside space-y-1">
          <li><strong>Lane:</strong> Assign items to specific timeline lanes (e.g., Product Team, Engineering)</li>
          <li><strong>End Date:</strong> Leave empty for milestone markers, fill for duration bars</li>
          <li><strong>Row:</strong> Position within the lane (0 = closest to axis, negative = above, positive = below)</li>
        </ul>
      </div>
    </div>
  );
}

export default DataTable;
