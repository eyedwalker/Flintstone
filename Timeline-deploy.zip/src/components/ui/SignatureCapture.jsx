import React, { useState, useRef, useEffect } from 'react';
import { Pencil, Type, RotateCcw, Check, X } from 'lucide-react';

/**
 * Multi-option Signature Capture Component
 * Supports: Drawn signature (canvas), Typed signature, or Both
 * Legally compliant under ESIGN Act and UETA
 */
const SignatureCapture = ({
  onSignatureComplete,
  onClear,
  signerName = '',
  requireBothMethods = false, // Require both drawn AND typed
  allowedMethods = ['draw', 'type'], // Which methods to show
  height = 150,
  label = 'Signature',
  required = true,
}) => {
  const canvasRef = useRef(null);
  const [activeMethod, setActiveMethod] = useState(allowedMethods[0]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawnSignature, setHasDrawnSignature] = useState(false);
  const [typedSignature, setTypedSignature] = useState('');
  const [drawnSignatureData, setDrawnSignatureData] = useState(null);
  const [lastPosition, setLastPosition] = useState({ x: 0, y: 0 });

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    
    // Set canvas resolution for crisp lines
    canvas.width = rect.width * 2;
    canvas.height = rect.height * 2;
    ctx.scale(2, 2);
    
    // Style for signature
    ctx.strokeStyle = '#1a1a2e';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    // Draw signature line
    ctx.beginPath();
    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 1;
    ctx.moveTo(20, rect.height - 30);
    ctx.lineTo(rect.width - 20, rect.height - 30);
    ctx.stroke();
    
    // Reset stroke style
    ctx.strokeStyle = '#1a1a2e';
    ctx.lineWidth = 2;
  }, [activeMethod]);

  // Get position from mouse or touch event
  const getPosition = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    
    if (e.touches) {
      return {
        x: e.touches[0].clientX - rect.left,
        y: e.touches[0].clientY - rect.top,
      };
    }
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  };

  // Start drawing
  const startDrawing = (e) => {
    e.preventDefault();
    const pos = getPosition(e);
    setLastPosition(pos);
    setIsDrawing(true);
  };

  // Draw
  const draw = (e) => {
    if (!isDrawing) return;
    e.preventDefault();
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const pos = getPosition(e);
    
    ctx.beginPath();
    ctx.strokeStyle = '#1a1a2e';
    ctx.lineWidth = 2;
    ctx.moveTo(lastPosition.x, lastPosition.y);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
    
    setLastPosition(pos);
    setHasDrawnSignature(true);
  };

  // Stop drawing
  const stopDrawing = () => {
    if (isDrawing && hasDrawnSignature) {
      const canvas = canvasRef.current;
      setDrawnSignatureData(canvas.toDataURL('image/png'));
    }
    setIsDrawing(false);
  };

  // Clear canvas
  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Redraw signature line
    ctx.beginPath();
    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 1;
    ctx.moveTo(20, rect.height - 30);
    ctx.lineTo(rect.width - 20, rect.height - 30);
    ctx.stroke();
    
    setHasDrawnSignature(false);
    setDrawnSignatureData(null);
    onClear?.();
  };

  // Clear typed signature
  const clearTyped = () => {
    setTypedSignature('');
    onClear?.();
  };

  // Check if signature is valid
  const isValid = () => {
    if (requireBothMethods) {
      return hasDrawnSignature && typedSignature.trim().length > 0;
    }
    if (activeMethod === 'draw') {
      return hasDrawnSignature;
    }
    return typedSignature.trim().length > 0;
  };

  // Get signature data
  const getSignatureData = () => {
    return {
      method: requireBothMethods ? 'both' : activeMethod,
      drawnSignature: drawnSignatureData,
      typedSignature: typedSignature.trim(),
      timestamp: new Date().toISOString(),
      isValid: isValid(),
    };
  };

  // Notify parent when signature changes
  useEffect(() => {
    if (isValid()) {
      onSignatureComplete?.(getSignatureData());
    }
  }, [hasDrawnSignature, typedSignature, drawnSignatureData]);

  const showTabs = allowedMethods.length > 1 && !requireBothMethods;

  return (
    <div className="space-y-3">
      <label className="block text-sm font-semibold text-gray-700">
        {label} {required && <span className="text-red-500">*</span>}
      </label>

      {/* Method Tabs */}
      {showTabs && (
        <div className="flex border-b border-gray-200">
          {allowedMethods.includes('draw') && (
            <button
              type="button"
              onClick={() => setActiveMethod('draw')}
              className={`flex items-center gap-2 px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                activeMethod === 'draw'
                  ? 'border-[#006FB4] text-[#006FB4]'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Pencil size={14} />
              Draw
            </button>
          )}
          {allowedMethods.includes('type') && (
            <button
              type="button"
              onClick={() => setActiveMethod('type')}
              className={`flex items-center gap-2 px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                activeMethod === 'type'
                  ? 'border-[#006FB4] text-[#006FB4]'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Type size={14} />
              Type
            </button>
          )}
        </div>
      )}

      {/* Draw Signature */}
      {(activeMethod === 'draw' || requireBothMethods) && allowedMethods.includes('draw') && (
        <div className="space-y-2">
          {requireBothMethods && (
            <p className="text-xs text-gray-500 flex items-center gap-1">
              <Pencil size={12} /> Draw your signature below
            </p>
          )}
          <div className="relative border-2 border-gray-300 rounded-lg bg-white overflow-hidden">
            <canvas
              ref={canvasRef}
              className="w-full cursor-crosshair touch-none"
              style={{ height: `${height}px` }}
              onMouseDown={startDrawing}
              onMouseMove={draw}
              onMouseUp={stopDrawing}
              onMouseLeave={stopDrawing}
              onTouchStart={startDrawing}
              onTouchMove={draw}
              onTouchEnd={stopDrawing}
            />
            
            {/* Clear button */}
            {hasDrawnSignature && (
              <button
                type="button"
                onClick={clearCanvas}
                className="absolute top-2 right-2 p-1.5 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"
                title="Clear signature"
              >
                <RotateCcw size={14} className="text-gray-600" />
              </button>
            )}
            
            {/* Placeholder text */}
            {!hasDrawnSignature && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <span className="text-gray-400 text-sm">Sign here</span>
              </div>
            )}
          </div>
          
          {/* Validation indicator */}
          {hasDrawnSignature && (
            <div className="flex items-center gap-1 text-xs text-green-600">
              <Check size={12} />
              Signature captured
            </div>
          )}
        </div>
      )}

      {/* Type Signature */}
      {(activeMethod === 'type' || requireBothMethods) && allowedMethods.includes('type') && (
        <div className="space-y-2">
          {requireBothMethods && (
            <p className="text-xs text-gray-500 flex items-center gap-1">
              <Type size={12} /> Type your full legal name
            </p>
          )}
          <div className="relative">
            <input
              type="text"
              value={typedSignature}
              onChange={(e) => setTypedSignature(e.target.value)}
              placeholder={signerName || "Type your full legal name"}
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg text-xl focus:outline-none focus:ring-2 focus:ring-[#006FB4] focus:border-[#006FB4]"
              style={{ fontFamily: "'Brush Script MT', 'Segoe Script', cursive" }}
            />
            {typedSignature && (
              <button
                type="button"
                onClick={clearTyped}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-gray-100 rounded"
              >
                <X size={16} className="text-gray-400" />
              </button>
            )}
          </div>
          
          {/* Preview of typed signature */}
          {typedSignature && (
            <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
              <p className="text-xs text-gray-500 mb-1">Preview:</p>
              <p 
                className="text-2xl text-gray-800"
                style={{ fontFamily: "'Brush Script MT', 'Segoe Script', cursive" }}
              >
                {typedSignature}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Both methods required indicator */}
      {requireBothMethods && (
        <div className="p-3 bg-blue-50 rounded-lg border border-blue-100">
          <p className="text-sm text-blue-800">
            <strong>Both signatures required:</strong>
          </p>
          <div className="flex gap-4 mt-2 text-sm">
            <span className={hasDrawnSignature ? 'text-green-600' : 'text-gray-500'}>
              {hasDrawnSignature ? '✓' : '○'} Drawn signature
            </span>
            <span className={typedSignature.trim() ? 'text-green-600' : 'text-gray-500'}>
              {typedSignature.trim() ? '✓' : '○'} Typed name
            </span>
          </div>
        </div>
      )}

      {/* Legal disclaimer */}
      <p className="text-xs text-gray-400">
        By signing above, you agree that this electronic signature is legally binding 
        and has the same legal effect as a handwritten signature.
      </p>
    </div>
  );
};

export default SignatureCapture;
