import React, { useState, useEffect } from 'react';
import { 
  X, 
  Plus, 
  Calendar, 
  Clock, 
  AlertCircle, 
  CheckCircle2,
  User,
  FileText,
  Phone,
  CreditCard,
  Stethoscope,
  Bot,
  Zap
} from 'lucide-react';
import { 
  TaskType, 
  TaskCategory, 
  TaskPriority,
  TASK_CATEGORY_CONFIG,
  TASK_PRIORITY_CONFIG 
} from '../../lib/services/task-management-service';
import { TaskService } from '../../services/taskService';

const CheckoutTaskModal = ({ 
  isOpen, 
  onClose, 
  patient, 
  journey, 
  onTasksCreated 
}) => {
  const [selectedTasks, setSelectedTasks] = useState([]);
  const [customTask, setCustomTask] = useState({
    title: '',
    description: '',
    category: TaskCategory.MEDICAL,
    priority: TaskPriority.MEDIUM,
    dueDate: ''
  });
  const [showCustomTask, setShowCustomTask] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Get task templates from constants (no longer using localStorage)
  const DEFAULT_TEMPLATES = [
    {
      id: 'followup-1week',
      category: TaskCategory.MEDICAL,
      title: '1-Week Follow-up',
      description: 'Schedule follow-up appointment in 1 week',
      defaultPriority: TaskPriority.MEDIUM,
      defaultDueDays: 7
    },
    {
      id: 'followup-1month',
      category: TaskCategory.MEDICAL,
      title: '1-Month Follow-up',
      description: 'Schedule follow-up appointment in 1 month',
      defaultPriority: TaskPriority.MEDIUM,
      defaultDueDays: 30
    },
    {
      id: 'frame-adjustment',
      category: TaskCategory.PRODUCT,
      title: 'Frame Adjustment',
      description: 'Schedule frame adjustment appointment',
      defaultPriority: TaskPriority.LOW,
      defaultDueDays: 14
    },
    {
      id: 'insurance-claim',
      category: TaskCategory.INSURANCE,
      title: 'Insurance Claim',
      description: 'Submit insurance claim',
      defaultPriority: TaskPriority.HIGH,
      defaultDueDays: 2
    },
    {
      id: 'satisfaction-survey',
      category: TaskCategory.COMMUNICATION,
      title: 'Satisfaction Survey',
      description: 'Send patient satisfaction survey',
      defaultPriority: TaskPriority.LOW,
      defaultDueDays: 3
    }
  ];
  
  const templatesByCategory = DEFAULT_TEMPLATES.reduce((acc, template) => {
    if (!acc[template.category]) {
      acc[template.category] = [];
    }
    acc[template.category].push(template);
    return acc;
  }, {});

  useEffect(() => {
    if (isOpen) {
      // Reset state when modal opens
      setSelectedTasks([]);
      setCustomTask({
        title: '',
        description: '',
        category: TaskCategory.MEDICAL,
        priority: TaskPriority.MEDIUM,
        dueDate: ''
      });
      setShowCustomTask(false);
      setIsSubmitting(false);
    }
  }, [isOpen]);

  const handleTemplateToggle = (templateId) => {
    setSelectedTasks(prev => 
      prev.includes(templateId)
        ? prev.filter(id => id !== templateId)
        : [...prev, templateId]
    );
  };

  const handleAddCustomTask = () => {
    if (!customTask.title.trim()) return;
    
    const customTaskData = {
      id: `custom-${Date.now()}`,
      type: TaskType.CUSTOM,
      category: customTask.category,
      title: customTask.title,
      description: customTask.description,
      defaultPriority: customTask.priority,
      defaultDueDays: customTask.dueDate ? 
        Math.ceil((new Date(customTask.dueDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : 
        undefined,
      isActive: true,
      isCustom: true
    };

    setSelectedTasks(prev => [...prev, customTaskData.id]);
    
    // Add to templates temporarily for this session
    if (!templatesByCategory[customTask.category]) {
      templatesByCategory[customTask.category] = [];
    }
    templatesByCategory[customTask.category].push(customTaskData);
    
    // Reset custom task form
    setCustomTask({
      title: '',
      description: '',
      category: TaskCategory.MEDICAL,
      priority: TaskPriority.MEDIUM,
      dueDate: ''
    });
    setShowCustomTask(false);
  };

  const handleSubmit = async () => {
    if (selectedTasks.length === 0) {
      onClose();
      return;
    }

    setIsSubmitting(true);
    
    try {
      const createdTasks = [];
      
      for (const taskId of selectedTasks) {
        // Find template (custom or default)
        const template = Object.values(templatesByCategory)
          .flat()
          .find(t => t.id === taskId);
        
        if (template) {
          // Map to API format
          const dueAt = template.defaultDueDays
            ? new Date(Date.now() + template.defaultDueDays * 24 * 60 * 60 * 1000).toISOString()
            : undefined;
          
          const taskPayload = {
            title: template.title,
            description: template.description,
            priority: template.defaultPriority === TaskPriority.HIGH ? 'high' : 
                     template.defaultPriority === TaskPriority.LOW ? 'low' : 'normal',
            status: 'pending',
            category: template.category || 'general',
            channel: 'internal',
            dueAt,
            metadata: {
              patientId: patient.id,
              patientName: patient.patientName || patient.name,
              journeyId: journey.id,
              templateId: template.id,
              createdFrom: 'checkout'
            },
            source: {
              type: 'checkout',
              journeyId: journey.id,
              patientId: patient.id
            }
          };
          
          // Create via API
          const response = await TaskService.createTask(taskPayload);
          if (response.task) {
            createdTasks.push(response.task);
          }
        }
      }

      // Callback with created tasks
      if (onTasksCreated) {
        onTasksCreated(createdTasks);
      }

      onClose();
    } catch (error) {
      console.error('Error creating tasks:', error);
      alert(`Failed to create tasks: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getCategoryIcon = (category) => {
    const icons = {
      [TaskCategory.MEDICAL]: <Stethoscope className="w-4 h-4" />,
      [TaskCategory.INSURANCE]: <CreditCard className="w-4 h-4" />,
      [TaskCategory.PRODUCT]: <User className="w-4 h-4" />,
      [TaskCategory.COMMUNICATION]: <Phone className="w-4 h-4" />,
      [TaskCategory.ADMINISTRATIVE]: <FileText className="w-4 h-4" />
    };
    return icons[category] || <FileText className="w-4 h-4" />;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Post-Visit Follow-ups</h2>
            <p className="text-sm text-gray-500 mt-1">
              Select any follow-up tasks needed for {patient?.patientName || patient?.name}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          {/* Task Categories */}
          <div className="space-y-6">
            {Object.entries(templatesByCategory).map(([category, templates]) => {
              const categoryConfig = TASK_CATEGORY_CONFIG[category];
              
              return (
                <div key={category} className="space-y-3">
                  <div className="flex items-center gap-2">
                    {getCategoryIcon(category)}
                    <h3 className={`font-medium ${categoryConfig.color}`}>
                      {categoryConfig.label}
                    </h3>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {templates.map(template => (
                      <div
                        key={template.id}
                        onClick={() => handleTemplateToggle(template.id)}
                        className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                          selectedTasks.includes(template.id)
                            ? `${categoryConfig.borderColor} ${categoryConfig.bgColor}`
                            : 'border-gray-200 hover:border-gray-300 bg-white'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium text-gray-900">{template.title}</h4>
                              {template.aiCompletable && (
                                <div className="flex items-center gap-1 px-2 py-0.5 bg-purple-100 text-purple-700 rounded text-xs">
                                  <Bot className="w-3 h-3" />
                                  <span>AI</span>
                                </div>
                              )}
                              {selectedTasks.includes(template.id) && (
                                <CheckCircle2 className="w-4 h-4 text-green-600" />
                              )}
                            </div>
                            {template.description && (
                              <p className="text-sm text-gray-600 mt-1">{template.description}</p>
                            )}
                            <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                              <span className={`px-2 py-0.5 rounded ${TASK_PRIORITY_CONFIG[template.defaultPriority].bgColor} ${TASK_PRIORITY_CONFIG[template.defaultPriority].color}`}>
                                {TASK_PRIORITY_CONFIG[template.defaultPriority].label}
                              </span>
                              {template.defaultDueDays && (
                                <div className="flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  <span>Due in {template.defaultDueDays} days</span>
                                </div>
                              )}
                              {template.aiCompletable && (
                                <div className="flex items-center gap-1 text-purple-600">
                                  <Zap className="w-3 h-3" />
                                  <span>Auto-completable</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Add Custom Task */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            {!showCustomTask ? (
              <button
                onClick={() => setShowCustomTask(true)}
                className="flex items-center gap-2 px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Custom Task
              </button>
            ) : (
              <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                <h4 className="font-medium text-gray-900">Custom Task</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Task Title</label>
                    <input
                      type="text"
                      value={customTask.title}
                      onChange={(e) => setCustomTask(prev => ({ ...prev, title: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                      placeholder="Enter task title..."
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select
                      value={customTask.category}
                      onChange={(e) => setCustomTask(prev => ({ ...prev, category: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                    >
                      {Object.entries(TASK_CATEGORY_CONFIG).map(([key, config]) => (
                        <option key={key} value={key}>{config.label}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
                    <select
                      value={customTask.priority}
                      onChange={(e) => setCustomTask(prev => ({ ...prev, priority: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                    >
                      {Object.entries(TASK_PRIORITY_CONFIG).map(([key, config]) => (
                        <option key={key} value={key}>{config.label}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Due Date (Optional)</label>
                    <input
                      type="date"
                      value={customTask.dueDate}
                      onChange={(e) => setCustomTask(prev => ({ ...prev, dueDate: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description (Optional)</label>
                  <textarea
                    value={customTask.description}
                    onChange={(e) => setCustomTask(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                    rows={2}
                    placeholder="Enter task description..."
                  />
                </div>
                
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleAddCustomTask}
                    disabled={!customTask.title.trim()}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Add Task
                  </button>
                  <button
                    onClick={() => setShowCustomTask(false)}
                    className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-md text-sm"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Selected Tasks Summary */}
          {selectedTasks.length > 0 && (
            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">
                Selected Tasks ({selectedTasks.length})
              </h4>
              <div className="text-sm text-blue-700">
                {selectedTasks.length} follow-up task{selectedTasks.length !== 1 ? 's' : ''} will be created for this patient.
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-gray-200 bg-gray-50">
          <div className="text-sm text-gray-500">
            {selectedTasks.length > 0 ? (
              <span className="flex items-center gap-1">
                <AlertCircle className="w-4 h-4" />
                {selectedTasks.length} task{selectedTasks.length !== 1 ? 's' : ''} selected
              </span>
            ) : (
              'No follow-up tasks selected'
            )}
          </div>
          
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-md"
            >
              Skip Follow-ups
            </button>
            <button
              onClick={handleSubmit}
              disabled={isSubmitting}
              className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
                selectedTasks.length > 0
                  ? 'bg-blue-600 text-white hover:bg-blue-700'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              {isSubmitting ? 'Creating Tasks...' : 
               selectedTasks.length > 0 ? 'Complete Checkout' : 'No Follow-ups Needed'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutTaskModal;
