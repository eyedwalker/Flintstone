/**
 * Room Configuration Component
 * Admin interface to configure office rooms
 */

import React, { useState, useEffect } from 'react';
import { OfficeRoomsService } from '../../lib/services/office-rooms-service';
import { ROOM_TYPE_CONFIG, DEFAULT_ROOM_CONFIGS } from '../../lib/types/office-rooms';
import {
  Plus,
  Trash2,
  Edit,
  Save,
  X,
  Settings,
  Users,
  Activity,
  Eye,
  Clock,
  CreditCard,
  Circle,
  MoreHorizontal,
  GripVertical,
  Glasses,
} from 'lucide-react';

const ICON_MAP = {
  Users,
  Activity,
  Eye,
  Clock,
  CreditCard,
  Circle,
  MoreHorizontal,
  Glasses,
  User: Users,
};

const ROOM_TYPE_OPTIONS = [
  { value: 'waiting', label: 'Waiting Area' },
  { value: 'pre-testing', label: 'Pre-Testing' },
  { value: 'exam-room', label: 'Exam Room' },
  { value: 'dilation', label: 'Dilation' },
  { value: 'optical', label: 'Optical' },
  { value: 'contact-lens', label: 'Contact Lens' },
  { value: 'doctor-office', label: 'Doctor Office' },
  { value: 'dispensary', label: 'Dispensary Table' },
  { value: 'checkout', label: 'Checkout' },
  { value: 'other', label: 'Other' },
];

export default function RoomConfiguration({ officeId, officeName, onSave }) {
  const [config, setConfig] = useState(null);
  const [editingRoom, setEditingRoom] = useState(null);
  const [isAddingRoom, setIsAddingRoom] = useState(false);
  const [newRoom, setNewRoom] = useState({
    name: '',
    shortName: '',
    type: 'exam-room',
    capacity: 1,
    defaultDurationMinutes: 20,
    isActive: true,
    color: '#D1FAE5',
  });

  useEffect(() => {
    loadConfig();
  }, [officeId]);

  const loadConfig = () => {
    let existingConfig = OfficeRoomsService.getOfficeConfig(officeId);
    if (!existingConfig) {
      existingConfig = OfficeRoomsService.initializeOffice(officeId, officeName, 'medium');
    }
    setConfig(existingConfig);
  };

  const handleSaveRoom = () => {
    if (!newRoom.name) return;

    const room = OfficeRoomsService.addRoom(officeId, {
      ...newRoom,
      displayOrder: (config?.rooms?.length || 0) + 1,
      status: 'available',
    });

    setIsAddingRoom(false);
    setNewRoom({
      name: '',
      shortName: '',
      type: 'exam-room',
      capacity: 1,
      defaultDurationMinutes: 20,
      isActive: true,
      color: '#D1FAE5',
    });
    loadConfig();
  };

  const handleUpdateRoom = (roomId, updates) => {
    OfficeRoomsService.updateRoom(officeId, roomId, updates);
    setEditingRoom(null);
    loadConfig();
  };

  const handleDeleteRoom = (roomId) => {
    if (window.confirm('Are you sure you want to delete this room?')) {
      OfficeRoomsService.deleteRoom(officeId, roomId);
      loadConfig();
    }
  };

  const handleInitializeFromTemplate = (size) => {
    if (window.confirm(`This will replace all current rooms with the ${size} office template. Continue?`)) {
      const newConfig = OfficeRoomsService.initializeOffice(officeId, officeName, size);
      setConfig(newConfig);
    }
  };

  const handleSaveSettings = () => {
    OfficeRoomsService.saveOfficeConfig(config);
    onSave?.(config);
  };

  if (!config) {
    return <div className="p-4 text-gray-500">Loading room configuration...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Room Configuration</h3>
          <p className="text-sm text-gray-500">{officeName} - {config.rooms.length} rooms configured</p>
        </div>
        <div className="flex items-center gap-2">
          <select
            onChange={(e) => e.target.value && handleInitializeFromTemplate(e.target.value)}
            className="text-sm border border-gray-300 rounded-lg px-3 py-1.5"
            defaultValue=""
          >
            <option value="">Load Template...</option>
            <option value="small">Small Office (7 rooms)</option>
            <option value="medium">Medium Office (10 rooms)</option>
            <option value="large">Large Office (16 rooms)</option>
          </select>
          <button
            onClick={() => setIsAddingRoom(true)}
            className="flex items-center gap-2 px-3 py-1.5 bg-purple-600 text-white text-sm rounded-lg hover:bg-purple-700"
          >
            <Plus className="w-4 h-4" />
            Add Room
          </button>
        </div>
      </div>

      {/* Settings */}
      <div className="bg-gray-50 rounded-lg p-4 grid grid-cols-2 md:grid-cols-4 gap-4">
        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Alert Threshold (min)</label>
          <input
            type="number"
            value={config.alertThresholdMinutes}
            onChange={(e) => setConfig({ ...config, alertThresholdMinutes: parseInt(e.target.value) })}
            className="w-full px-3 py-1.5 border border-gray-300 rounded text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Default Exam Duration</label>
          <input
            type="number"
            value={config.defaultExamDuration}
            onChange={(e) => setConfig({ ...config, defaultExamDuration: parseInt(e.target.value) })}
            className="w-full px-3 py-1.5 border border-gray-300 rounded text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Default Pre-Test Duration</label>
          <input
            type="number"
            value={config.defaultPreTestDuration}
            onChange={(e) => setConfig({ ...config, defaultPreTestDuration: parseInt(e.target.value) })}
            className="w-full px-3 py-1.5 border border-gray-300 rounded text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Dilation Wait Time</label>
          <input
            type="number"
            value={config.defaultDilationWaitTime}
            onChange={(e) => setConfig({ ...config, defaultDilationWaitTime: parseInt(e.target.value) })}
            className="w-full px-3 py-1.5 border border-gray-300 rounded text-sm"
          />
        </div>
      </div>

      {/* Rooms List */}
      <div className="space-y-2">
        {config.rooms.sort((a, b) => a.displayOrder - b.displayOrder).map((room) => {
          const typeConfig = ROOM_TYPE_CONFIG[room.type] || ROOM_TYPE_CONFIG.other;
          const IconComponent = ICON_MAP[typeConfig.icon] || Circle;
          const isEditing = editingRoom?.id === room.id;

          return (
            <div
              key={room.id}
              className={`flex items-center gap-4 p-3 rounded-lg border ${
                room.isActive ? 'bg-white border-gray-200' : 'bg-gray-50 border-gray-100'
              }`}
            >
              <GripVertical className="w-4 h-4 text-gray-400 cursor-grab" />
              
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: room.color || typeConfig.color }}
              >
                <IconComponent className="w-5 h-5 text-white" style={{ filter: 'brightness(0.8)' }} />
              </div>

              {isEditing ? (
                <div className="flex-1 grid grid-cols-6 gap-2">
                  <input
                    type="text"
                    value={editingRoom.name}
                    onChange={(e) => setEditingRoom({ ...editingRoom, name: e.target.value })}
                    className="col-span-2 px-2 py-1 border border-gray-300 rounded text-sm"
                    placeholder="Room Name"
                  />
                  <input
                    type="text"
                    value={editingRoom.shortName || ''}
                    onChange={(e) => setEditingRoom({ ...editingRoom, shortName: e.target.value })}
                    className="px-2 py-1 border border-gray-300 rounded text-sm"
                    placeholder="Short"
                  />
                  <select
                    value={editingRoom.type}
                    onChange={(e) => setEditingRoom({ ...editingRoom, type: e.target.value })}
                    className="px-2 py-1 border border-gray-300 rounded text-sm"
                  >
                    {ROOM_TYPE_OPTIONS.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    value={editingRoom.defaultDurationMinutes || ''}
                    onChange={(e) => setEditingRoom({ ...editingRoom, defaultDurationMinutes: parseInt(e.target.value) })}
                    className="px-2 py-1 border border-gray-300 rounded text-sm"
                    placeholder="Duration"
                  />
                  <div className="flex gap-1">
                    <button
                      onClick={() => handleUpdateRoom(room.id, editingRoom)}
                      className="p-1.5 bg-green-100 text-green-700 rounded hover:bg-green-200"
                    >
                      <Save className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setEditingRoom(null)}
                      className="p-1.5 bg-gray-100 text-gray-600 rounded hover:bg-gray-200"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-gray-900">{room.name}</span>
                      {room.shortName && (
                        <span className="px-1.5 py-0.5 bg-gray-100 text-gray-600 text-xs rounded">{room.shortName}</span>
                      )}
                      {!room.isActive && (
                        <span className="px-1.5 py-0.5 bg-red-100 text-red-600 text-xs rounded">Inactive</span>
                      )}
                    </div>
                    <div className="text-xs text-gray-500">
                      {typeConfig.label} · Capacity: {room.capacity}
                      {room.defaultDurationMinutes && ` · ${room.defaultDurationMinutes} min`}
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleUpdateRoom(room.id, { isActive: !room.isActive })}
                      className={`px-2 py-1 text-xs rounded ${
                        room.isActive 
                          ? 'bg-green-100 text-green-700 hover:bg-green-200' 
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {room.isActive ? 'Active' : 'Inactive'}
                    </button>
                    <button
                      onClick={() => setEditingRoom(room)}
                      className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteRoom(room.id)}
                      className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </>
              )}
            </div>
          );
        })}
      </div>

      {/* Add Room Form */}
      {isAddingRoom && (
        <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
          <h4 className="font-medium text-purple-900 mb-3">Add New Room</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs text-gray-600 mb-1">Room Name</label>
              <input
                type="text"
                value={newRoom.name}
                onChange={(e) => setNewRoom({ ...newRoom, name: e.target.value })}
                className="w-full px-3 py-1.5 border border-gray-300 rounded text-sm"
                placeholder="e.g., Exam Room 1"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">Short Name</label>
              <input
                type="text"
                value={newRoom.shortName}
                onChange={(e) => setNewRoom({ ...newRoom, shortName: e.target.value })}
                className="w-full px-3 py-1.5 border border-gray-300 rounded text-sm"
                placeholder="e.g., E1"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">Type</label>
              <select
                value={newRoom.type}
                onChange={(e) => setNewRoom({ ...newRoom, type: e.target.value })}
                className="w-full px-3 py-1.5 border border-gray-300 rounded text-sm"
              >
                {ROOM_TYPE_OPTIONS.map(opt => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">Duration (min)</label>
              <input
                type="number"
                value={newRoom.defaultDurationMinutes}
                onChange={(e) => setNewRoom({ ...newRoom, defaultDurationMinutes: parseInt(e.target.value) })}
                className="w-full px-3 py-1.5 border border-gray-300 rounded text-sm"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-4">
            <button
              onClick={() => setIsAddingRoom(false)}
              className="px-4 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveRoom}
              disabled={!newRoom.name}
              className="px-4 py-1.5 text-sm bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
            >
              Add Room
            </button>
          </div>
        </div>
      )}

      {/* Save Button */}
      <div className="flex justify-end">
        <button
          onClick={handleSaveSettings}
          className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
        >
          Save Configuration
        </button>
      </div>
    </div>
  );
}
