import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  AlertTriangle, Settings, Route, FileText, Brain, Bot, User, LogOut,
  ChevronDown, Building2, Users, Phone, MessageSquare, Mic, Sparkles, BookOpen, Shield, BarChart3
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useCompany } from '../../contexts/CompanyContext';
import DemoModeService from '../../services/demoModeService';
import DemoModeAdmin from '../admin/DemoModeAdmin';
import VoiceSettings from '../admin/VoiceSettings';
import { EnvironmentSwitcher } from '../admin';

// Office phone number for testing SMS and voice calls
const OFFICE_PHONE = '+1 (580) 633-6397';

const AppHeader = ({ 
  escalations = [], 
  onAIMonitor, 
  onManageQueue,
  onAcknowledgeEscalation,
  onResolveEscalation 
}) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { currentUser, logout, isAdmin } = useAuth();
  const { activeCompany, companies, switchCompany } = useCompany();
  const [showDemoAdmin, setShowDemoAdmin] = useState(false);
  const [showVoiceSettings, setShowVoiceSettings] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  
  const demoSettings = DemoModeService.getSettings();
  const isDemoMode = demoSettings.enabled;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const isActive = (path) => location.pathname === path;

  const navItems = [
    { path: '/journey', label: 'Journey Board', icon: Route, adminOnly: false },
    { path: '/admin', label: 'Admin', icon: Settings, adminOnly: true },
    { path: '/recommendations-admin', label: 'Recommendations', icon: Sparkles, adminOnly: true },
    { path: '/forms-admin', label: 'Forms', icon: FileText, adminOnly: true },
    { path: '/journey-admin', label: 'Journey Settings', icon: null, adminOnly: true },
    { path: '/insurance-settings', label: 'Insurance', icon: Shield, adminOnly: true },
    { path: '/analytics', label: 'Analytics', icon: BarChart3, adminOnly: true },
    { path: '/ai-knowledge-base', label: 'AI Knowledge', icon: Brain, adminOnly: true },
    { path: '/ai-test', label: 'AI Test', icon: Bot, adminOnly: true },
    { path: '/help', label: 'Help & Docs', icon: BookOpen, adminOnly: false },
    { path: '/timeline', label: 'Timeline Creator', icon: null, adminOnly: false },
  ];

  return (
    <>
      {/* Single Consolidated Header Bar */}
      <div className="bg-[#1a1a2e] text-white px-4 py-2 flex items-center justify-between sticky top-0 z-[9998] shadow-lg">
        {/* Left: Logo + Demo Mode Indicator */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-white">eyefinity</span>
            <span className="text-[10px] text-gray-400 hidden sm:inline">PRC</span>
          </div>
          
          {isDemoMode && (
            <button
              onClick={() => setShowDemoAdmin(true)}
              className="flex items-center gap-2 bg-amber-500 hover:bg-amber-600 px-3 py-1 rounded text-xs font-semibold transition-colors"
            >
              <AlertTriangle size={14} className="animate-pulse" />
              <span>DEMO</span>
              <span className="hidden md:inline text-amber-100">→ {demoSettings.demoEmail}</span>
            </button>
          )}
        </div>

        {/* Center: Navigation */}
        <nav className="flex items-center gap-1">
          {navItems.map(item => {
            if (item.adminOnly && !isAdmin) return null;
            const Icon = item.icon;
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`px-3 py-1.5 rounded text-sm flex items-center gap-1.5 transition-colors ${
                  isActive(item.path)
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
              >
                {Icon && <Icon size={14} />}
                <span className="hidden lg:inline">{item.label}</span>
                <span className="lg:hidden">{item.label.split(' ')[0]}</span>
              </button>
            );
          })}
        </nav>

        {/* Right: Company Switcher + Environment + User */}
        <div className="flex items-center gap-3">
          {/* Company Switcher */}
          {isAdmin && companies.length > 1 && (
            <select
              value={activeCompany?.id || ''}
              onChange={(e) => switchCompany(e.target.value)}
              className="px-2 py-1 bg-gray-700 text-white text-xs rounded border border-gray-600 hover:bg-gray-600 transition-colors"
            >
              {companies.map(company => (
                <option key={company.id} value={company.id}>
                  {company.name}
                </option>
              ))}
            </select>
          )}
          
          {isAdmin && <EnvironmentSwitcher compact />}
          
          <div className="relative">
            <button 
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 text-sm text-gray-300 hover:text-white transition-colors"
            >
              <User size={16} />
              <span className="hidden sm:inline">{currentUser?.name}</span>
              <ChevronDown size={14} />
            </button>
            
            {showUserMenu && (
              <div className="absolute right-0 top-full mt-1 bg-white rounded-lg shadow-lg py-1 min-w-[150px] z-50">
                <button
                  onClick={() => { navigate('/admin'); setShowUserMenu(false); }}
                  className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
                >
                  <Building2 size={14} />
                  Admin Dashboard
                </button>
                {isAdmin && (
                  <>
                    <button
                      onClick={() => { navigate('/user-management'); setShowUserMenu(false); }}
                      className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
                    >
                      <Users size={14} />
                      User Management
                    </button>
                    <button
                      onClick={() => { setShowVoiceSettings(true); setShowUserMenu(false); }}
                      className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
                    >
                      <Mic size={14} />
                      Voice AI Settings
                    </button>
                  </>
                )}
                <hr className="my-1" />
                <button
                  onClick={handleLogout}
                  className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
                >
                  <LogOut size={14} />
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Secondary Bar: Page Title + Escalations + Actions */}
      <div className="bg-gray-50 border-b border-gray-200 px-4 py-2">
        <div className="flex items-center justify-between">
          {/* Left: Page Title + Office Phone */}
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold text-gray-800">Patient Readiness Center</h1>
            <div className="flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-lg px-3 py-1">
              <Phone size={14} className="text-blue-600" />
              <span className="text-sm font-medium text-blue-700">{OFFICE_PHONE}</span>
              <span className="text-xs text-blue-500">Test SMS/Call</span>
            </div>
          </div>
          
          {/* Center: Escalations Summary */}
          <div className="flex items-center gap-3">
            {escalations.length > 0 ? (
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 text-red-600">
                  <AlertTriangle size={16} />
                  <span className="font-semibold text-sm">{escalations.length} Escalations</span>
                </div>
                <div className="flex gap-1 max-w-[400px] overflow-hidden">
                  {escalations.slice(0, 3).map(esc => (
                    <div 
                      key={esc.id} 
                      className="bg-red-100 border border-red-200 rounded px-2 py-0.5 flex items-center gap-1 text-xs"
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        esc.priority === 'urgent' ? 'bg-red-600 animate-pulse' : 
                        esc.priority === 'high' ? 'bg-red-500' : 'bg-orange-500'
                      }`} />
                      <span className="font-medium truncate max-w-[80px]">{esc.patientName}</span>
                      <button
                        onClick={() => onResolveEscalation?.(esc.id)}
                        className="text-green-600 hover:text-green-800 ml-1"
                        title="Resolve"
                      >
                        ✓
                      </button>
                    </div>
                  ))}
                  {escalations.length > 3 && (
                    <button
                      onClick={onManageQueue}
                      className="text-blue-600 hover:underline text-xs"
                    >
                      +{escalations.length - 3} more
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <span className="text-gray-400 text-sm">No active escalations</span>
            )}
          </div>

          {/* Right: Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={onAIMonitor}
              className="px-3 py-1.5 bg-purple-600 text-white text-xs font-medium rounded hover:bg-purple-700 transition-colors flex items-center gap-1"
            >
              <Bot size={14} />
              <span className="hidden sm:inline">AI Monitor</span>
            </button>
            <button
              onClick={onManageQueue}
              className="px-3 py-1.5 bg-[#003366] text-white text-xs font-medium rounded hover:bg-[#004488] transition-colors flex items-center gap-1"
            >
              <Settings size={14} />
              <span className="hidden sm:inline">Queue</span>
            </button>
          </div>
        </div>
      </div>

      {/* Demo Mode Admin Modal */}
      <DemoModeAdmin isOpen={showDemoAdmin} onClose={() => setShowDemoAdmin(false)} />
      
      {/* Voice Settings Modal */}
      <VoiceSettings isOpen={showVoiceSettings} onClose={() => setShowVoiceSettings(false)} />
      
      {/* Click outside to close user menu */}
      {showUserMenu && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowUserMenu(false)}
        />
      )}
    </>
  );
};

export default AppHeader;
