import React, { forwardRef, useMemo } from 'react';

const TimelineView = forwardRef(({ items, categories, lanes }, ref) => {
  const config = useMemo(() => {
    if (items.length === 0) {
      return {
        minDate: new Date(),
        maxDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
        totalDays: 90,
        laneMetrics: {}
      };
    }

    const dates = items.flatMap(item => {
      const d = [new Date(item.startDate)];
      if (item.endDate) d.push(new Date(item.endDate));
      return d;
    });

    const minDate = new Date(Math.min(...dates));
    const maxDate = new Date(Math.max(...dates));
    
    minDate.setDate(minDate.getDate() - 7);
    maxDate.setDate(maxDate.getDate() + 14);

    const totalDays = Math.ceil((maxDate - minDate) / (1000 * 60 * 60 * 24));
    
    const laneMetrics = {};
    lanes.forEach(lane => {
      const laneItems = items.filter(item => item.laneId === lane.id);
      const maxAboveRow = Math.max(0, ...laneItems.filter(i => i.row < 0).map(i => Math.abs(i.row)));
      const maxBelowRow = Math.max(0, ...laneItems.filter(i => i.row >= 0).map(i => i.row));
      laneMetrics[lane.id] = { maxAboveRow, maxBelowRow };
    });

    return { minDate, maxDate, totalDays, laneMetrics };
  }, [items, lanes]);

  const { minDate, maxDate, totalDays, laneMetrics } = config;

  const padding = { top: 80, bottom: 60, left: 180, right: 40 };
  const timelineWidth = Math.max(1000, totalDays * 10);
  const rowHeight = 50;
  const laneSpacing = 150;
  
  const sortedLanes = [...lanes].sort((a, b) => a.order - b.order);
  const lanePositions = {};
  let currentY = padding.top;
  
  sortedLanes.forEach(lane => {
    const metrics = laneMetrics[lane.id] || { maxAboveRow: 0, maxBelowRow: 0 };
    const aboveSpace = metrics.maxAboveRow * rowHeight + 40;
    const belowSpace = metrics.maxBelowRow * rowHeight + 40;
    
    lanePositions[lane.id] = {
      axisY: currentY + aboveSpace,
      topY: currentY,
      bottomY: currentY + aboveSpace + belowSpace,
      height: aboveSpace + belowSpace
    };
    
    currentY += aboveSpace + belowSpace + laneSpacing;
  });
  
  const svgHeight = currentY + padding.bottom - laneSpacing;
  const svgWidth = timelineWidth + padding.left + padding.right;

  const getXPosition = (dateStr) => {
    const date = new Date(dateStr);
    const daysDiff = (date - minDate) / (1000 * 60 * 60 * 24);
    return padding.left + (daysDiff / totalDays) * timelineWidth;
  };

  const getMonthMarkers = () => {
    const markers = [];
    const current = new Date(minDate);
    current.setDate(1);
    
    while (current <= maxDate) {
      const x = getXPosition(current.toISOString().split('T')[0]);
      if (x >= padding.left && x <= padding.left + timelineWidth) {
        markers.push({
          x,
          label: current.toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
        });
      }
      current.setMonth(current.getMonth() + 1);
    }
    return markers;
  };

  const getWeekMarkers = () => {
    const markers = [];
    const current = new Date(minDate);
    const dayOfWeek = current.getDay();
    current.setDate(current.getDate() - dayOfWeek);
    
    while (current <= maxDate) {
      const x = getXPosition(current.toISOString().split('T')[0]);
      if (x >= padding.left && x <= padding.left + timelineWidth) {
        markers.push({
          x,
          label: current.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
        });
      }
      current.setDate(current.getDate() + 7);
    }
    return markers;
  };

  const monthMarkers = getMonthMarkers();
  const weekMarkers = getWeekMarkers();
  
  const getLanePosition = (laneId, row) => {
    const lanePos = lanePositions[laneId];
    if (!lanePos) return padding.top;
    
    if (row < 0) {
      return lanePos.axisY + (row * rowHeight);
    } else {
      return lanePos.axisY + (row * rowHeight);
    }
  };

  const getCategoryColor = (categoryId) => {
    const cat = categories.find(c => c.id === categoryId);
    return cat?.color || '#9CA3AF';
  };

  const darkenColor = (hex, percent) => {
    const num = parseInt(hex.replace('#', ''), 16);
    const amt = Math.round(2.55 * percent);
    const R = Math.max(0, (num >> 16) - amt);
    const G = Math.max(0, ((num >> 8) & 0x00FF) - amt);
    const B = Math.max(0, (num & 0x0000FF) - amt);
    return `#${(1 << 24 | R << 16 | G << 8 | B).toString(16).slice(1)}`;
  };

  return (
    <div ref={ref} style={{ backgroundColor: '#ffffff', padding: '20px' }}>
      <svg width={svgWidth} height={svgHeight} style={{ display: 'block' }}>
        <defs>
          <marker
            id="arrowhead"
            markerWidth="10"
            markerHeight="7"
            refX="9"
            refY="3.5"
            orient="auto"
          >
            <polygon points="0 0, 10 3.5, 0 7" fill="#374151" />
          </marker>
          <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="1" dy="1" stdDeviation="2" floodOpacity="0.15" />
          </filter>
        </defs>

        {/* Legend */}
        <g transform={`translate(${svgWidth - 210}, 10)`}>
          {/* Legend background and border */}
          <rect
            x="-10"
            y="-10"
            width="200"
            height={30 + categories.length * 22}
            rx="8"
            fill="#FFFFFF"
            stroke="#E5E7EB"
            strokeWidth="2"
            filter="url(#shadow)"
          />
          <text x="0" y="0" fontSize="12" fontWeight="600" fill="#374151">Legend</text>
          {categories.map((cat, idx) => (
            <g key={cat.id} transform={`translate(0, ${20 + idx * 22})`}>
              <rect x="0" y="-10" width="16" height="16" rx="3" fill={cat.color} />
              <text x="22" y="2" fontSize="11" fill="#4B5563">{cat.name}</text>
            </g>
          ))}
        </g>

        {/* Lane axes and labels */}
        {sortedLanes.map((lane, laneIndex) => {
          const lanePos = lanePositions[lane.id];
          if (!lanePos) return null;
          
          return (
            <g key={lane.id}>
              {/* Lane background */}
              <rect
                x="0"
                y={lanePos.topY}
                width={svgWidth}
                height={lanePos.height}
                fill={laneIndex % 2 === 0 ? '#F9FAFB' : '#FFFFFF'}
              />
              
              {/* Lane label */}
              <rect
                x="10"
                y={lanePos.axisY - 20}
                width="150"
                height="40"
                rx="6"
                fill={lane.color}
                opacity="0.9"
              />
              <text
                x="85"
                y={lanePos.axisY + 5}
                fontSize="13"
                fontWeight="600"
                fill="#FFFFFF"
                textAnchor="middle"
              >
                {lane.name}
              </text>
              
              {/* Timeline axis for this lane */}
              <line
                x1={padding.left}
                y1={lanePos.axisY}
                x2={padding.left + timelineWidth}
                y2={lanePos.axisY}
                stroke="#374151"
                strokeWidth="2"
                markerEnd="url(#arrowhead)"
              />
              
              {/* Month markers on this lane's axis */}
              {monthMarkers.map((marker, idx) => (
                <g key={`${lane.id}-month-${idx}`}>
                  <line
                    x1={marker.x}
                    y1={lanePos.axisY - 8}
                    x2={marker.x}
                    y2={lanePos.axisY + 8}
                    stroke="#6B7280"
                    strokeWidth="1"
                  />
                  {laneIndex === 0 && (
                    <text
                      x={marker.x}
                      y={lanePos.topY - 10}
                      textAnchor="middle"
                      fontSize="11"
                      fill="#4B5563"
                      fontWeight="500"
                    >
                      {marker.label}
                    </text>
                  )}
                </g>
              ))}
              
              {/* Week markers */}
              {weekMarkers.map((marker, idx) => (
                <line
                  key={`${lane.id}-week-${idx}`}
                  x1={marker.x}
                  y1={lanePos.axisY - 4}
                  x2={marker.x}
                  y2={lanePos.axisY + 4}
                  stroke="#9CA3AF"
                  strokeWidth="1"
                />
              ))}
            </g>
          );
        })}
        
        {/* Timeline items */}
        {items.map((item) => {
          const startX = getXPosition(item.startDate);
          const color = getCategoryColor(item.categoryId);
          const borderColor = darkenColor(color, 30);
          const lanePos = lanePositions[item.laneId];
          if (!lanePos) return null;
          
          const baseY = getLanePosition(item.laneId, item.row);

          if (item.endDate) {
            const endX = getXPosition(item.endDate);
            const barWidth = Math.max(endX - startX, 80);
            const barHeight = 36;
            const clipId = `clip-${item.id}`;
            const rectY = baseY - barHeight / 2;

            return (
              <g key={item.id}>
                <defs>
                  <clipPath id={clipId}>
                    <rect
                      x={startX + 2}
                      y={rectY + 2}
                      width={barWidth - 4}
                      height={barHeight - 4}
                      rx="4"
                    />
                  </clipPath>
                </defs>
                {/* Connector line */}
                <line
                  x1={startX}
                  y1={lanePos.axisY}
                  x2={startX}
                  y2={rectY + barHeight / 2}
                  stroke="#9CA3AF"
                  strokeWidth="1"
                  strokeDasharray="3,3"
                />
                {/* Duration bar */}
                <rect
                  x={startX}
                  y={rectY}
                  width={barWidth}
                  height={barHeight}
                  rx="4"
                  fill={color}
                  stroke={borderColor}
                  strokeWidth="1.5"
                  filter="url(#shadow)"
                />
                {/* Label */}
                <text
                  x={startX + barWidth / 2}
                  y={baseY + 5}
                  fontSize="12"
                  fill="#1F2937"
                  fontWeight="500"
                  textAnchor="middle"
                  dominantBaseline="middle"
                  clipPath={`url(#${clipId})`}
                >
                  {item.name}
                </text>
                {/* Arrow connector at end */}
                <circle
                  cx={endX}
                  cy={baseY}
                  r="4"
                  fill={borderColor}
                />
              </g>
            );
          } else {
            const labelText = `${item.startDate.replace(/-/g, '/')} ${item.name}`;
            const labelWidth = Math.max(labelText.length * 8 + 30, 140);
            const labelHeight = 32;
            const labelY = baseY - labelHeight / 2;
            const clipId = `clip-${item.id}`;

            return (
              <g key={item.id}>
                <defs>
                  <clipPath id={clipId}>
                    <rect
                      x={startX - 5}
                      y={labelY + 2}
                      width={labelWidth - 4}
                      height={labelHeight - 4}
                      rx="4"
                    />
                  </clipPath>
                </defs>
                {/* Connector line to timeline */}
                <line
                  x1={startX}
                  y1={lanePos.axisY}
                  x2={startX}
                  y2={labelY + labelHeight / 2}
                  stroke="#9CA3AF"
                  strokeWidth="1"
                  strokeDasharray="3,3"
                />
                {/* Milestone marker on timeline */}
                <circle
                  cx={startX}
                  cy={lanePos.axisY}
                  r="5"
                  fill={color}
                  stroke={borderColor}
                  strokeWidth="2"
                />
                {/* Label box */}
                <rect
                  x={startX - 5}
                  y={labelY}
                  width={labelWidth}
                  height={labelHeight}
                  rx="4"
                  fill={color}
                  stroke={borderColor}
                  strokeWidth="1.5"
                  filter="url(#shadow)"
                />
                {/* Label text */}
                <text
                  x={startX + labelWidth / 2 - 5}
                  y={labelY + labelHeight / 2 + 1}
                  fontSize="11"
                  fill="#1F2937"
                  fontWeight="500"
                  textAnchor="middle"
                  dominantBaseline="middle"
                  clipPath={`url(#${clipId})`}
                >
                  {labelText}
                </text>
              </g>
            );
          }
        })}
      </svg>
    </div>
  );
});

TimelineView.displayName = 'TimelineView';

export default TimelineView;
