/**
 * ID Document Upload Field Component
 * Allows patients to upload insurance cards, driver's licenses, etc.
 * Supports camera capture and file upload with OCR simulation
 */

import React, { useState, useRef } from 'react';
import { 
  Camera, 
  Upload, 
  X, 
  CheckCircle, 
  AlertCircle,
  RotateCcw,
  FileText,
  CreditCard,
  IdCard
} from 'lucide-react';

// Document type icons
const DOCUMENT_ICONS = {
  insuranceCard: CreditCard,
  driversLicense: IdCard,
  other: FileText,
};

// Compress image
async function compressImage(file, maxWidth = 1200, quality = 0.8) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target.result;
      
      img.onload = () => {
        let width = img.width;
        let height = img.height;
        
        if (width > maxWidth) {
          height = Math.round(height * (maxWidth / width));
          width = maxWidth;
        }
        
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
        
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      
      img.onerror = reject;
    };
    
    reader.onerror = reject;
  });
}

// Simulated OCR extraction
async function extractMetadata(imageDataUrl, documentType) {
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  if (documentType === 'insuranceCard') {
    const providers = ['VSP Vision', 'EyeMed', 'Blue Cross Blue Shield', 'Aetna', 'UnitedHealthcare'];
    return {
      insuranceProvider: providers[Math.floor(Math.random() * providers.length)],
      insuranceMemberId: `MEM${Math.random().toString().slice(2, 11)}`,
      insuranceGroupId: `GRP${Math.random().toString().slice(2, 8)}`,
    };
  } else if (documentType === 'driversLicense') {
    const states = ['CA', 'TX', 'NY', 'FL', 'IL'];
    return {
      licenseNumber: `DL${Math.random().toString().slice(2, 10)}`,
      expirationDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000 * 3).toISOString().split('T')[0],
      stateIssued: states[Math.floor(Math.random() * states.length)],
    };
  }
  
  return {};
}

export default function IDDocumentUploadField({
  documentType = 'insuranceCard',
  patientId,
  onUpload,
  onError,
  showMetadataFields = true,
  requireBack = false,
  label,
  description,
}) {
  const [frontImage, setFrontImage] = useState(null);
  const [backImage, setBackImage] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedData, setExtractedData] = useState({});
  const [error, setError] = useState('');
  const [uploadComplete, setUploadComplete] = useState(false);
  
  const frontInputRef = useRef(null);
  const backInputRef = useRef(null);

  const DocumentIcon = DOCUMENT_ICONS[documentType] || FileText;

  const handleFileSelect = async (e, side) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setError('Please select an image file');
      return;
    }

    // Validate file size (10MB max)
    if (file.size > 10 * 1024 * 1024) {
      setError('File size must be less than 10MB');
      return;
    }

    setError('');
    setIsProcessing(true);

    try {
      const compressedImage = await compressImage(file);
      
      if (side === 'front') {
        setFrontImage(compressedImage);
        
        // Run OCR on front image
        const metadata = await extractMetadata(compressedImage, documentType);
        setExtractedData(prev => ({ ...prev, ...metadata }));
      } else {
        setBackImage(compressedImage);
      }
    } catch (err) {
      console.error('Error processing image:', err);
      setError('Failed to process image');
      onError?.(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleMetadataChange = (field, value) => {
    setExtractedData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    if (!frontImage) {
      setError('Please upload the front of the document');
      return;
    }

    if (requireBack && !backImage) {
      setError('Please upload the back of the document');
      return;
    }

    const document = {
      id: `doc_${Date.now()}`,
      patientId,
      documentType,
      frontImage,
      backImage,
      uploadedAt: new Date(),
      ...extractedData,
    };

    setUploadComplete(true);
    onUpload?.(document);
  };

  const handleReset = () => {
    setFrontImage(null);
    setBackImage(null);
    setExtractedData({});
    setUploadComplete(false);
    setError('');
    if (frontInputRef.current) frontInputRef.current.value = '';
    if (backInputRef.current) backInputRef.current.value = '';
  };

  // Upload complete state
  if (uploadComplete) {
    return (
      <div className="border-2 border-green-200 bg-green-50 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
            <CheckCircle className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-green-900">Document Uploaded</h3>
            <p className="text-sm text-green-700">Your document has been successfully uploaded</p>
          </div>
        </div>
        
        <div className="flex gap-3">
          {frontImage && (
            <img src={frontImage} alt="Front" className="w-24 h-16 object-cover rounded border" />
          )}
          {backImage && (
            <img src={backImage} alt="Back" className="w-24 h-16 object-cover rounded border" />
          )}
        </div>
        
        <button
          onClick={handleReset}
          className="mt-4 flex items-center gap-2 text-sm text-green-700 hover:text-green-800"
        >
          <RotateCcw className="w-4 h-4" />
          Upload different document
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
          <DocumentIcon className="w-5 h-5 text-purple-600" />
        </div>
        <div>
          <h3 className="font-medium text-gray-900">
            {label || (documentType === 'insuranceCard' ? 'Insurance Card' : "Driver's License")}
          </h3>
          {description && <p className="text-sm text-gray-500">{description}</p>}
        </div>
      </div>

      {/* Front Image Upload */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Front of Document <span className="text-red-500">*</span>
        </label>
        <input
          ref={frontInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={(e) => handleFileSelect(e, 'front')}
          className="hidden"
          id={`front-${documentType}`}
        />
        
        {frontImage ? (
          <div className="relative">
            <img 
              src={frontImage} 
              alt="Front of document" 
              className="w-full max-h-48 object-contain rounded-lg border border-gray-200"
            />
            <button
              onClick={() => {
                setFrontImage(null);
                if (frontInputRef.current) frontInputRef.current.value = '';
              }}
              className="absolute top-2 right-2 p-1 bg-red-100 text-red-600 rounded-full hover:bg-red-200"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <label
            htmlFor={`front-${documentType}`}
            className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-purple-400 hover:bg-purple-50 transition-colors"
          >
            <div className="flex gap-4 mb-2">
              <Camera className="w-8 h-8 text-gray-400" />
              <Upload className="w-8 h-8 text-gray-400" />
            </div>
            <span className="text-sm text-gray-600">Take photo or upload file</span>
            <span className="text-xs text-gray-400 mt-1">JPG, PNG up to 10MB</span>
          </label>
        )}
      </div>

      {/* Back Image Upload (Optional) */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Back of Document {requireBack && <span className="text-red-500">*</span>}
          {!requireBack && <span className="text-gray-400 text-xs ml-1">(Optional)</span>}
        </label>
        <input
          ref={backInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={(e) => handleFileSelect(e, 'back')}
          className="hidden"
          id={`back-${documentType}`}
        />
        
        {backImage ? (
          <div className="relative">
            <img 
              src={backImage} 
              alt="Back of document" 
              className="w-full max-h-48 object-contain rounded-lg border border-gray-200"
            />
            <button
              onClick={() => {
                setBackImage(null);
                if (backInputRef.current) backInputRef.current.value = '';
              }}
              className="absolute top-2 right-2 p-1 bg-red-100 text-red-600 rounded-full hover:bg-red-200"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <label
            htmlFor={`back-${documentType}`}
            className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-purple-400 hover:bg-purple-50 transition-colors"
          >
            <div className="flex gap-3 mb-1">
              <Camera className="w-6 h-6 text-gray-400" />
              <Upload className="w-6 h-6 text-gray-400" />
            </div>
            <span className="text-sm text-gray-600">Upload back of document</span>
          </label>
        )}
      </div>

      {/* Extracted Metadata Fields */}
      {showMetadataFields && frontImage && Object.keys(extractedData).length > 0 && (
        <div className="p-4 bg-gray-50 rounded-lg space-y-3">
          <h4 className="text-sm font-medium text-gray-700">Extracted Information</h4>
          <p className="text-xs text-gray-500 mb-3">Please verify the information below</p>
          
          {documentType === 'insuranceCard' && (
            <>
              <div>
                <label className="block text-xs text-gray-500 mb-1">Insurance Provider</label>
                <input
                  type="text"
                  value={extractedData.insuranceProvider || ''}
                  onChange={(e) => handleMetadataChange('insuranceProvider', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Member ID</label>
                  <input
                    type="text"
                    value={extractedData.insuranceMemberId || ''}
                    onChange={(e) => handleMetadataChange('insuranceMemberId', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Group Number</label>
                  <input
                    type="text"
                    value={extractedData.insuranceGroupId || ''}
                    onChange={(e) => handleMetadataChange('insuranceGroupId', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  />
                </div>
              </div>
            </>
          )}
          
          {documentType === 'driversLicense' && (
            <>
              <div>
                <label className="block text-xs text-gray-500 mb-1">License Number</label>
                <input
                  type="text"
                  value={extractedData.licenseNumber || ''}
                  onChange={(e) => handleMetadataChange('licenseNumber', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-gray-500 mb-1">State Issued</label>
                  <input
                    type="text"
                    value={extractedData.stateIssued || ''}
                    onChange={(e) => handleMetadataChange('stateIssued', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Expiration Date</label>
                  <input
                    type="date"
                    value={extractedData.expirationDate || ''}
                    onChange={(e) => handleMetadataChange('expirationDate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  />
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* Processing indicator */}
      {isProcessing && (
        <div className="flex items-center gap-2 text-purple-600">
          <div className="w-5 h-5 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
          <span className="text-sm">Processing image...</span>
        </div>
      )}

      {/* Error display */}
      {error && (
        <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
          <AlertCircle className="w-5 h-5 text-red-600" />
          <span className="text-sm text-red-700">{error}</span>
        </div>
      )}

      {/* Submit Button */}
      {frontImage && (
        <button
          onClick={handleSubmit}
          disabled={isProcessing}
          className="w-full py-3 px-4 bg-purple-600 text-white font-medium rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <CheckCircle className="w-5 h-5" />
          Confirm & Upload
        </button>
      )}
    </div>
  );
}
