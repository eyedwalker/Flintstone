import React, { useState, useRef, useEffect } from 'react';
import { X, Mail, MessageSquare, Globe, Check, AlertTriangle } from 'lucide-react';
import FtcComplianceService from '../../services/ftcComplianceService';
import SignatureCapture from '../ui/SignatureCapture';

const RxConsentForm = ({ 
  patient, 
  onComplete, 
  onCancel,
  storeNumber,
  storeId 
}) => {
  const [consentType, setConsentType] = useState(null); // 'electronic' | 'physical'
  const [deliveryMethod, setDeliveryMethod] = useState(null); // 'email' | 'text' | 'portal'
  const [deliveryDetails, setDeliveryDetails] = useState('');
  const [signatureData, setSignatureData] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [clientIp, setClientIp] = useState('');

  useEffect(() => {
    // Get client IP on mount
    FtcComplianceService.getClientIp().then(ip => setClientIp(ip));
    
    // Pre-fill delivery details from patient data
    if (patient?.email) {
      setDeliveryDetails(patient.email);
      setDeliveryMethod('email');
    } else if (patient?.phone || patient?.mobilePhone) {
      setDeliveryDetails(patient.mobilePhone || patient.phone);
      setDeliveryMethod('text');
    }
  }, [patient]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    // Validation
    if (!consentType) {
      setError('Please select how you would like to receive your prescription');
      return;
    }

    if (consentType === 'electronic') {
      if (!deliveryMethod) {
        setError('Please select a delivery method');
        return;
      }
      if ((deliveryMethod === 'email' || deliveryMethod === 'text') && !deliveryDetails) {
        setError(`Please provide your ${deliveryMethod === 'email' ? 'email address' : 'phone number'}`);
        return;
      }
    }

    if (!signatureData?.isValid) {
      setError('Please provide your signature');
      return;
    }

    setIsSubmitting(true);

    try {
      const consent = {
        patientId: patient.id || patient.patientId,
        patientUid: patient.uid || patient.patientUid,
        patientName: `${patient.firstName || patient.FirstName} ${patient.lastName || patient.LastName}`,
        consentType: consentType,
        deliveryMethod: consentType === 'electronic' ? deliveryMethod : undefined,
        deliveryDetails: consentType === 'electronic' && deliveryMethod !== 'portal' ? deliveryDetails : undefined,
        consentTimestamp: new Date().toISOString(),
        consentSignature: signatureData?.typedSignature || 'Drawn Signature',
        consentSignatureImage: signatureData?.drawnSignature,
        consentSignatureMethod: signatureData?.method,
        consentIpAddress: clientIp,
        storeNumber: storeNumber,
        storeId: storeId,
      };

      const record = FtcComplianceService.saveConsent(consent);
      
      // Generate and log the compliance payload (US6)
      const payload = FtcComplianceService.generateConsentPayload(patient.id || patient.patientId);
      console.log('[FTC Compliance] Consent payload (US6):', payload);

      onComplete?.(record);
    } catch (err) {
      console.error('[FTC Compliance] Error saving consent:', err);
      setError('Failed to save consent. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-[#003366]">
          <h2 className="text-lg font-bold text-white">Prescription Delivery Consent</h2>
          <button
            onClick={onCancel}
            className="text-white hover:text-gray-200 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* FTC Notice */}
        <div className="p-4 bg-blue-50 border-b border-blue-100">
          <div className="flex gap-2">
            <AlertTriangle size={20} className="text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-blue-800">
              <p className="font-semibold">FTC Eyeglass Rule Notice</p>
              <p className="mt-1">
                Federal law requires us to provide you with a copy of your eyeglass prescription 
                immediately after your eye exam, at no additional cost.
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-6">
          {/* Patient Info */}
          <div className="bg-gray-50 rounded-lg p-3">
            <p className="text-sm text-gray-600">Patient</p>
            <p className="font-semibold text-gray-900">
              {patient?.firstName || patient?.FirstName} {patient?.lastName || patient?.LastName}
            </p>
          </div>

          {/* Consent Type Selection */}
          <div className="space-y-3">
            <label className="block text-sm font-semibold text-gray-700">
              How would you like to receive your prescription?
            </label>

            {/* Electronic Option */}
            <div
              onClick={() => setConsentType('electronic')}
              className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                consentType === 'electronic'
                  ? 'border-[#006FB4] bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  consentType === 'electronic' ? 'border-[#006FB4] bg-[#006FB4]' : 'border-gray-300'
                }`}>
                  {consentType === 'electronic' && <Check size={12} className="text-white" />}
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Electronic Delivery</p>
                  <p className="text-sm text-gray-600">Receive via email, text, or patient portal</p>
                </div>
              </div>

              {/* Delivery Method Options */}
              {consentType === 'electronic' && (
                <div className="mt-4 pl-8 space-y-3">
                  {/* Email */}
                  <div
                    onClick={(e) => { e.stopPropagation(); setDeliveryMethod('email'); }}
                    className={`p-3 border rounded-lg cursor-pointer ${
                      deliveryMethod === 'email' ? 'border-[#006FB4] bg-white' : 'border-gray-200'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Mail size={16} className="text-gray-500" />
                      <span className="text-sm font-medium">Email</span>
                    </div>
                    {deliveryMethod === 'email' && (
                      <input
                        type="email"
                        value={deliveryDetails}
                        onChange={(e) => setDeliveryDetails(e.target.value)}
                        onClick={(e) => e.stopPropagation()}
                        placeholder="Enter email address"
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#006FB4]"
                      />
                    )}
                  </div>

                  {/* Text */}
                  <div
                    onClick={(e) => { e.stopPropagation(); setDeliveryMethod('text'); }}
                    className={`p-3 border rounded-lg cursor-pointer ${
                      deliveryMethod === 'text' ? 'border-[#006FB4] bg-white' : 'border-gray-200'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <MessageSquare size={16} className="text-gray-500" />
                      <span className="text-sm font-medium">Text Message</span>
                    </div>
                    {deliveryMethod === 'text' && (
                      <input
                        type="tel"
                        value={deliveryDetails}
                        onChange={(e) => setDeliveryDetails(e.target.value)}
                        onClick={(e) => e.stopPropagation()}
                        placeholder="Enter phone number"
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#006FB4]"
                      />
                    )}
                  </div>

                  {/* Portal */}
                  <div
                    onClick={(e) => { e.stopPropagation(); setDeliveryMethod('portal'); }}
                    className={`p-3 border rounded-lg cursor-pointer ${
                      deliveryMethod === 'portal' ? 'border-[#006FB4] bg-white' : 'border-gray-200'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Globe size={16} className="text-gray-500" />
                      <span className="text-sm font-medium">Patient Portal</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Physical Option */}
            <div
              onClick={() => setConsentType('physical')}
              className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                consentType === 'physical'
                  ? 'border-[#006FB4] bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  consentType === 'physical' ? 'border-[#006FB4] bg-[#006FB4]' : 'border-gray-300'
                }`}>
                  {consentType === 'physical' && <Check size={12} className="text-white" />}
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Physical Copy</p>
                  <p className="text-sm text-gray-600">Receive a printed copy in-office</p>
                </div>
              </div>
            </div>
          </div>

          {/* Signature */}
          <SignatureCapture
            label="Electronic Signature"
            signerName={`${patient?.firstName || patient?.FirstName || ''} ${patient?.lastName || patient?.LastName || ''}`}
            allowedMethods={['draw', 'type']}
            requireBothMethods={false}
            height={120}
            onSignatureComplete={(data) => setSignatureData(data)}
            onClear={() => setSignatureData(null)}
          />

          {/* Error Message */}
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              {error}
            </div>
          )}

          {/* Submit */}
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 px-4 py-3 bg-[#006FB4] text-white rounded-lg font-medium hover:bg-[#005a94] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? 'Submitting...' : 'Submit Consent'}
            </button>
          </div>

          {/* Legal Text */}
          <p className="text-xs text-gray-400 text-center">
            This consent is retained for 3 years per FTC requirements.
            Date: {new Date().toLocaleDateString()} | IP: {clientIp || 'Detecting...'}
          </p>
        </form>
      </div>
    </div>
  );
};

export default RxConsentForm;
