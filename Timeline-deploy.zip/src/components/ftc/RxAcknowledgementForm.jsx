import React, { useState, useEffect, useRef } from 'react';
import { X, FileText, Check, AlertTriangle, Eye, Printer, Send, MessageSquare, Globe, Mail, CheckCircle, Upload, Smartphone, Monitor, ExternalLink } from 'lucide-react';
import FtcComplianceService from '../../services/ftcComplianceService';
import { EyefinityService } from '../../services/eyefinityService';
import FullResponseDisplay from '../FullResponseDisplay';
import SignatureCapture from '../ui/SignatureCapture';
import { CommunicationService } from '../../services/communicationService';
import DemoModeService from '../../services/demoModeService';
import { FormSubmissionService } from '../../lib/services/form-submission-service';

const RxAcknowledgementForm = ({ 
  patient, 
  examDate,
  onComplete, 
  onCancel,
  storeNumber,
  storeId,
  associateId,
  associateName
}) => {
  const [signatureData, setSignatureData] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [clientIp, setClientIp] = useState('');
  const [rxData, setRxData] = useState(null);
  const [fullRxResponse, setFullRxResponse] = useState(null);
  const [loadingRx, setLoadingRx] = useState(true);
  const [showRxPreview, setShowRxPreview] = useState(false);
  const [completedRecord, setCompletedRecord] = useState(null);
  const [sendingMethod, setSendingMethod] = useState(null);
  const [sendSuccess, setSendSuccess] = useState(null);
  const [captureMode, setCaptureMode] = useState(null); // 'device', 'remote', 'upload'
  const [uploadedFile, setUploadedFile] = useState(null);
  const [remoteFormSent, setRemoteFormSent] = useState(false);
  const [remoteFormLink, setRemoteFormLink] = useState(null);
  const printRef = useRef(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    // Get client IP on mount
    FtcComplianceService.getClientIp().then(ip => setClientIp(ip));
    
    // Fetch patient Rx data
    fetchRxData();
  }, [patient]);

  const fetchRxData = async () => {
    setLoadingRx(true);
    setRxError(null);
    try {
      const patientId = patient?.id || patient?.patientId || patient?.PatientId;
      if (patientId) {
        const response = await EyefinityService.getPatientRx(patientId);
        setFullRxResponse(response);
        setRxData(response);
      }
    } catch (err) {
      console.warn('[FTC] Could not fetch Rx data:', err);
      setRxError(err);
    } finally {
      setLoadingRx(false);
    }
  };

  const formatRxValue = (value) => {
    if (value === undefined || value === null) return '-';
    const num = parseFloat(value);
    if (isNaN(num)) return value;
    return num >= 0 ? `+${num.toFixed(2)}` : num.toFixed(2);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    if (!signatureData?.isValid) {
      setError('Please provide your signature to acknowledge receipt of your prescription');
      return;
    }

    setIsSubmitting(true);

    try {
      const acknowledgement = {
        patientId: patient.id || patient.patientId || patient.PatientId,
        patientUid: patient.uid || patient.patientUid || patient.PatientUid,
        patientName: `${patient.firstName || patient.FirstName} ${patient.lastName || patient.LastName}`,
        examDate: examDate || new Date().toISOString(),
        acknowledgementTimestamp: new Date().toISOString(),
        acknowledgementSignature: signatureData?.typedSignature || 'Drawn Signature',
        acknowledgementSignatureImage: signatureData?.drawnSignature,
        acknowledgementSignatureMethod: signatureData?.method,
        acknowledgementIpAddress: clientIp,
        storeNumber: storeNumber,
        storeId: storeId,
        associateId: associateId,
        associateName: associateName,
        rxData: rxData,
      };

      const record = FtcComplianceService.saveAcknowledgement(acknowledgement);
      
      // Generate and log the compliance payload (US8)
      const payload = FtcComplianceService.generateAcknowledgementPayload(patient.id || patient.patientId || patient.PatientId);
      console.log('[FTC Compliance] Acknowledgement payload (US8):', payload);

      // Show completion screen instead of closing immediately
      setCompletedRecord(record);
    } catch (err) {
      console.error('[FTC Compliance] Error saving acknowledgement:', err);
      setError('Failed to save acknowledgement. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePrint = () => {
    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Prescription Acknowledgement - ${patientName}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 40px; max-width: 600px; margin: 0 auto; }
          .header { text-align: center; border-bottom: 2px solid #003366; padding-bottom: 20px; margin-bottom: 20px; }
          .header h1 { color: #003366; margin: 0; font-size: 24px; }
          .section { margin-bottom: 20px; }
          .section-title { font-weight: bold; color: #333; margin-bottom: 8px; }
          .info-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }
          .signature-box { border: 1px solid #ccc; padding: 20px; margin-top: 10px; text-align: center; }
          .signature { font-family: 'Brush Script MT', cursive; font-size: 28px; }
          .signature-img { max-height: 80px; }
          .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #ccc; font-size: 12px; color: #666; }
          .legal { background: #f5f5f5; padding: 15px; border-radius: 5px; font-size: 12px; margin: 20px 0; }
          @media print { body { padding: 20px; } }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Prescription Acknowledgement</h1>
          <p>FTC Eyeglass Rule Compliance Document</p>
        </div>
        
        <div class="section">
          <div class="info-row"><span>Patient Name:</span><strong>${patientName}</strong></div>
          <div class="info-row"><span>Exam Date:</span><strong>${examDate ? new Date(examDate).toLocaleDateString() : new Date().toLocaleDateString()}</strong></div>
          <div class="info-row"><span>Acknowledgement Date:</span><strong>${new Date().toLocaleString()}</strong></div>
        </div>
        
        <div class="legal">
          <strong>Patient Acknowledgement:</strong><br/>
          I confirm that I have received a copy of my eyeglass prescription from this practice. 
          I understand that I am free to purchase eyewear from this practice or from another seller of my choice.
        </div>
        
        <div class="section">
          <div class="section-title">Patient Signature</div>
          <div class="signature-box">
            ${signatureData?.drawnSignature 
              ? `<img src="${signatureData.drawnSignature}" class="signature-img" alt="Patient Signature"/>`
              : `<span class="signature">${signatureData?.typedSignature || patientName}</span>`
            }
          </div>
        </div>
        
        <div class="footer">
          <p>This acknowledgement is retained for 3 years per FTC requirements.</p>
          <p>Document ID: ${completedRecord?.acknowledgement?.patientId}-${Date.now()}</p>
          <p>IP Address: ${clientIp} | Store: ${storeNumber || 'N/A'}</p>
        </div>
      </body>
      </html>
    `;
    
    const printWindow = window.open('', '_blank');
    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  };

  const handleSendText = async () => {
    setSendingMethod('text');
    try {
      // Use demo phone if demo mode is enabled, otherwise use patient's phone
      const demoSettings = DemoModeService.getSettings();
      let phone = patient?.mobilePhone || patient?.MobilePhone || patient?.phone || patient?.Phone;
      
      if (demoSettings.enabled) {
        phone = demoSettings.demoPhone;
        console.log('[DEMO MODE] Using demo phone for SMS:', phone);
      }
      
      if (!phone) {
        setError('No phone number available for this patient');
        setSendingMethod(null);
        return;
      }
      
      const message = `Your prescription acknowledgement has been recorded. You confirmed receipt of your eyeglass prescription on ${new Date().toLocaleDateString()}. This document is retained per FTC requirements. Thank you!`;
      
      await CommunicationService.sendSMS(phone, message);
      setSendSuccess('text');
      setTimeout(() => setSendSuccess(null), 3000);
    } catch (err) {
      console.error('[FTC] Error sending text:', err);
      setError('Failed to send text message');
    } finally {
      setSendingMethod(null);
    }
  };

  const handleSendEmail = async () => {
    setSendingMethod('email');
    try {
      // Use demo email if demo mode is enabled, otherwise use patient's email
      const demoSettings = DemoModeService.getSettings();
      let email = patient?.email || patient?.Email;
      
      if (demoSettings.enabled) {
        email = demoSettings.demoEmail;
        console.log('[DEMO MODE] Using demo email:', email);
      }
      
      if (!email) {
        setError('No email address available for this patient');
        setSendingMethod(null);
        return;
      }
      
      // Send via real email API
      const response = await fetch('/api/communications/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: email,
          subject: 'Prescription Acknowledgement Confirmation',
          body: `Your prescription acknowledgement has been recorded.\n\nYou confirmed receipt of your eyeglass prescription on ${new Date().toLocaleDateString()}.\n\nThis document is retained per FTC requirements.\n\nThank you!`,
        }),
      });
      
      const result = await response.json();
      if (result.success) {
        setSendSuccess('email');
        setTimeout(() => setSendSuccess(null), 3000);
      } else {
        setError('Failed to send email');
      }
    } catch (err) {
      console.error('[FTC] Error sending email:', err);
      setError('Failed to send email');
    } finally {
      setSendingMethod(null);
    }
  };

  const handleSendPortal = async () => {
    setSendingMethod('portal');
    try {
      // In production, this would post to patient portal
      console.log('[FTC] Would send to patient portal for:', patientName);
      setSendSuccess('portal');
      setTimeout(() => setSendSuccess(null), 3000);
    } catch (err) {
      console.error('[FTC] Error sending to portal:', err);
      setError('Failed to send to portal');
    } finally {
      setSendingMethod(null);
    }
  };

  const handleSendRemoteForm = async () => {
    setIsSubmitting(true);
    setError(null);
    try {
      const patientId = patient?.id || patient?.patientId || patient?.PatientId;
      const demoSettings = DemoModeService.getSettings();
      
      // Get contact info (use demo if enabled)
      let email = patient?.email || patient?.Email;
      let phone = patient?.mobilePhone || patient?.MobilePhone || patient?.phone || patient?.Phone;
      
      if (demoSettings.enabled) {
        email = demoSettings.demoEmail;
        phone = demoSettings.demoPhone;
        console.log('[DEMO MODE] Sending remote form to demo contacts:', email, phone);
      }

      // Create form submission
      const formService = new FormSubmissionService();
      const submission = formService.createSubmission({
        templateId: 'ftc-rx-acknowledgement',
        patientId: patientId,
        patientName: patientName,
        formType: 'compliance',
        prefilledResponses: {
          patientName: patientName,
          examDate: examDate || new Date().toISOString(),
        },
        verificationMethod: 'dob',
      });

      // Send to patient
      await formService.sendFormToPatient(submission.submissionId, email, phone);

      setRemoteFormLink(submission.accessLink);
      setRemoteFormSent(true);
      setCaptureMode('remote');
      
      console.log('[FTC] Remote form sent:', submission.accessLink);
    } catch (err) {
      console.error('[FTC] Error sending remote form:', err);
      setError('Failed to send form. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      setError(null);
    }
  };

  const handleUploadSubmit = async () => {
    if (!uploadedFile) return;
    
    setIsSubmitting(true);
    setError(null);

    try {
      // Convert file to base64 for storage
      const fileData = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(uploadedFile);
      });

      const acknowledgement = {
        patientId: patient.id || patient.patientId || patient.PatientId,
        patientUid: patient.uid || patient.patientUid || patient.PatientUid,
        patientName: patientName,
        examDate: examDate || new Date().toISOString(),
        acknowledgementTimestamp: new Date().toISOString(),
        acknowledgementSignature: 'Uploaded Document',
        acknowledgementSignatureImage: fileData,
        acknowledgementSignatureMethod: 'upload',
        acknowledgementIpAddress: clientIp,
        storeNumber: storeNumber,
        storeId: storeId,
        associateId: associateId,
        associateName: associateName,
        uploadedFileName: uploadedFile.name,
        uploadedFileType: uploadedFile.type,
      };

      const record = FtcComplianceService.saveAcknowledgement(acknowledgement);
      
      console.log('[FTC Compliance] Uploaded acknowledgement saved:', record);
      setCompletedRecord(record);
    } catch (err) {
      console.error('[FTC Compliance] Error saving uploaded acknowledgement:', err);
      setError('Failed to save acknowledgement. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDone = () => {
    onComplete?.(completedRecord);
  };

  const patientName = `${patient?.firstName || patient?.FirstName || ''} ${patient?.lastName || patient?.LastName || ''}`.trim();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-[#003366]">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            {completedRecord ? <CheckCircle size={20} /> : <FileText size={20} />}
            {completedRecord ? 'Acknowledgement Complete' : 'Prescription Acknowledgement'}
          </h2>
          <button
            onClick={completedRecord ? handleDone : onCancel}
            className="text-white hover:text-gray-200 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Completion Screen */}
        {completedRecord ? (
          <div className="p-6 space-y-6">
            {/* Success Message */}
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle size={32} className="text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Signature Recorded</h3>
              <p className="text-gray-600 mt-2">
                {patientName}'s prescription acknowledgement has been saved.
              </p>
            </div>

            {/* Summary */}
            <div className="bg-gray-50 rounded-lg p-4 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-gray-500">Patient</p>
                  <p className="font-semibold">{patientName}</p>
                </div>
                <div>
                  <p className="text-gray-500">Date Signed</p>
                  <p className="font-semibold">{new Date().toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-gray-500">Exam Date</p>
                  <p className="font-semibold">{examDate ? new Date(examDate).toLocaleDateString() : 'Today'}</p>
                </div>
                <div>
                  <p className="text-gray-500">Retention</p>
                  <p className="font-semibold">3 Years (FTC)</p>
                </div>
              </div>
            </div>

            {/* Print & Send Options */}
            <div className="space-y-3">
              <p className="text-sm font-semibold text-gray-700">Print or Send Copy to Patient:</p>
              
              {/* Print Button */}
              <button
                type="button"
                onClick={handlePrint}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 border-2 border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors"
              >
                <Printer size={18} />
                Print Acknowledgement
              </button>

              {/* Send Options */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={handleSendText}
                  disabled={sendingMethod === 'text'}
                  className={`flex flex-col items-center gap-1 px-3 py-3 border-2 rounded-lg font-medium transition-colors ${
                    sendSuccess === 'text' 
                      ? 'border-green-500 bg-green-50 text-green-700'
                      : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {sendSuccess === 'text' ? (
                    <CheckCircle size={18} className="text-green-600" />
                  ) : (
                    <MessageSquare size={18} />
                  )}
                  <span className="text-xs">{sendingMethod === 'text' ? 'Sending...' : sendSuccess === 'text' ? 'Sent!' : 'Text'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleSendEmail}
                  disabled={sendingMethod === 'email'}
                  className={`flex flex-col items-center gap-1 px-3 py-3 border-2 rounded-lg font-medium transition-colors ${
                    sendSuccess === 'email' 
                      ? 'border-green-500 bg-green-50 text-green-700'
                      : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {sendSuccess === 'email' ? (
                    <CheckCircle size={18} className="text-green-600" />
                  ) : (
                    <Mail size={18} />
                  )}
                  <span className="text-xs">{sendingMethod === 'email' ? 'Sending...' : sendSuccess === 'email' ? 'Sent!' : 'Email'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleSendPortal}
                  disabled={sendingMethod === 'portal'}
                  className={`flex flex-col items-center gap-1 px-3 py-3 border-2 rounded-lg font-medium transition-colors ${
                    sendSuccess === 'portal' 
                      ? 'border-green-500 bg-green-50 text-green-700'
                      : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {sendSuccess === 'portal' ? (
                    <CheckCircle size={18} className="text-green-600" />
                  ) : (
                    <Globe size={18} />
                  )}
                  <span className="text-xs">{sendingMethod === 'portal' ? 'Sending...' : sendSuccess === 'portal' ? 'Sent!' : 'Portal'}</span>
                </button>
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                {error}
              </div>
            )}

            {/* Done Button */}
            <button
              type="button"
              onClick={handleDone}
              className="w-full px-4 py-3 bg-[#22653B] text-white rounded-lg font-medium hover:bg-[#1a4f2e] transition-colors"
            >
              Done
            </button>
          </div>
        ) : captureMode === null ? (
          /* Capture Mode Selection */
          <div className="p-6 space-y-4">
            <div className="text-center mb-6">
              <h3 className="text-lg font-semibold text-gray-900">How would you like to capture the signature?</h3>
              <p className="text-sm text-gray-600 mt-1">Choose the method that works best for this patient</p>
            </div>

            {/* Option 1: Sign on Device */}
            <button
              type="button"
              onClick={() => setCaptureMode('device')}
              className="w-full p-4 border-2 border-gray-200 rounded-lg hover:border-[#006FB4] hover:bg-blue-50 transition-all text-left group"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200">
                  <Monitor size={24} className="text-[#006FB4]" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900">Sign on This Device</p>
                  <p className="text-sm text-gray-600 mt-1">Patient signs directly on iPad, tablet, or computer screen</p>
                  <p className="text-xs text-green-600 mt-2 font-medium">Best for in-office visits</p>
                </div>
              </div>
            </button>

            {/* Option 2: Send Form Remotely */}
            <button
              type="button"
              onClick={() => handleSendRemoteForm()}
              className="w-full p-4 border-2 border-gray-200 rounded-lg hover:border-[#006FB4] hover:bg-blue-50 transition-all text-left group"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center group-hover:bg-green-200">
                  <Send size={24} className="text-green-600" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900">Send Form to Patient</p>
                  <p className="text-sm text-gray-600 mt-1">Send via text or email - patient signs on their own device and returns</p>
                  <p className="text-xs text-blue-600 mt-2 font-medium">Best for remote or busy patients</p>
                </div>
              </div>
            </button>

            {/* Option 3: Print & Upload */}
            <button
              type="button"
              onClick={() => setCaptureMode('upload')}
              className="w-full p-4 border-2 border-gray-200 rounded-lg hover:border-[#006FB4] hover:bg-blue-50 transition-all text-left group"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center group-hover:bg-amber-200">
                  <Upload size={24} className="text-amber-600" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900">Print & Upload Signed Copy</p>
                  <p className="text-sm text-gray-600 mt-1">Print the form, have patient sign on paper, then scan/upload</p>
                  <p className="text-xs text-amber-600 mt-2 font-medium">Best when digital signature isn't available</p>
                </div>
              </div>
            </button>

            <button
              type="button"
              onClick={onCancel}
              className="w-full mt-4 px-4 py-2 text-gray-600 hover:text-gray-800 text-sm"
            >
              Cancel
            </button>
          </div>
        ) : captureMode === 'upload' ? (
          /* Upload Signed Copy Mode */
          <div className="p-6 space-y-4">
            <button
              type="button"
              onClick={() => setCaptureMode(null)}
              className="text-sm text-[#006FB4] hover:underline flex items-center gap-1"
            >
              ← Back to options
            </button>

            <div className="text-center mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Print & Upload Signed Copy</h3>
              <p className="text-sm text-gray-600 mt-1">Follow these steps to complete the acknowledgement</p>
            </div>

            {/* Step 1: Print */}
            <div className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 bg-[#006FB4] text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                <p className="font-semibold">Print the Form</p>
              </div>
              <button
                type="button"
                onClick={handlePrint}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 border-2 border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50"
              >
                <Printer size={18} />
                Print Acknowledgement Form
              </button>
            </div>

            {/* Step 2: Get Signature */}
            <div className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 bg-[#006FB4] text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                <p className="font-semibold">Have Patient Sign the Printed Form</p>
              </div>
              <p className="text-sm text-gray-600">Give the printed form to the patient to sign with pen</p>
            </div>

            {/* Step 3: Upload */}
            <div className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 bg-[#006FB4] text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                <p className="font-semibold">Upload the Signed Copy</p>
              </div>
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*,.pdf"
                onChange={handleFileUpload}
                className="hidden"
              />
              {uploadedFile ? (
                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                  <CheckCircle size={20} className="text-green-600" />
                  <span className="text-sm text-green-700 flex-1">{uploadedFile.name}</span>
                  <button
                    type="button"
                    onClick={() => setUploadedFile(null)}
                    className="text-red-500 hover:text-red-700 text-sm"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 hover:border-[#006FB4]"
                >
                  <Upload size={18} />
                  Upload Signed Document
                </button>
              )}
            </div>

            {/* Submit Upload */}
            <button
              type="button"
              onClick={handleUploadSubmit}
              disabled={!uploadedFile || isSubmitting}
              className="w-full px-4 py-3 bg-[#22653B] text-white rounded-lg font-medium hover:bg-[#1a4f2e] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? 'Submitting...' : 'Complete Acknowledgement'}
            </button>
          </div>
        ) : captureMode === 'remote' ? (
          /* Remote Form Sent Confirmation */
          <div className="p-6 space-y-4">
            <button
              type="button"
              onClick={() => { setCaptureMode(null); setRemoteFormSent(false); }}
              className="text-sm text-[#006FB4] hover:underline flex items-center gap-1"
            >
              ← Back to options
            </button>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Send size={32} className="text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Form Sent!</h3>
              <p className="text-gray-600 mt-2">
                The acknowledgement form has been sent to {patientName}.
              </p>
            </div>

            {remoteFormLink && (
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm font-semibold text-gray-700 mb-2">Form Link:</p>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={remoteFormLink}
                    readOnly
                    className="flex-1 px-3 py-2 bg-white border border-gray-300 rounded text-sm"
                  />
                  <button
                    type="button"
                    onClick={() => navigator.clipboard.writeText(remoteFormLink)}
                    className="px-3 py-2 bg-[#006FB4] text-white rounded text-sm hover:bg-[#005a94]"
                  >
                    Copy
                  </button>
                </div>
              </div>
            )}

            <div className="bg-blue-50 rounded-lg p-4 text-sm text-blue-800">
              <p className="font-semibold">What happens next?</p>
              <ul className="mt-2 space-y-1 list-disc list-inside">
                <li>Patient receives the form via text/email</li>
                <li>They review and sign on their device</li>
                <li>The signed acknowledgement is automatically recorded</li>
              </ul>
            </div>

            <button
              type="button"
              onClick={handleDone}
              className="w-full px-4 py-3 bg-[#22653B] text-white rounded-lg font-medium hover:bg-[#1a4f2e] transition-colors"
            >
              Done
            </button>
          </div>
        ) : (
          /* Device Signature Mode (Original Flow) */
          <>
            <button
              type="button"
              onClick={() => setCaptureMode(null)}
              className="mx-4 mt-4 text-sm text-[#006FB4] hover:underline flex items-center gap-1"
            >
              ← Back to options
            </button>
        {/* FTC Notice */}
        <div className="p-4 bg-amber-50 border-b border-amber-100">
          <div className="flex gap-2">
            <AlertTriangle size={20} className="text-amber-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-amber-800">
              <p className="font-semibold">FTC Eyeglass Rule Requirement</p>
              <p className="mt-1">
                Please confirm that you have received a copy of your eyeglass prescription. 
                This acknowledgement is required by federal law before completing your purchase.
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-5">
          {/* Patient Info */}
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-500">Patient</p>
                <p className="font-semibold text-gray-900">{patientName}</p>
              </div>
              <div>
                <p className="text-gray-500">Exam Date</p>
                <p className="font-semibold text-gray-900">
                  {examDate ? new Date(examDate).toLocaleDateString() : new Date().toLocaleDateString()}
                </p>
              </div>
            </div>
          </div>

          {/* Rx Preview (Optional) */}
          {rxData && (rxData.EyeGlass?.length > 0 || rxData.SoftCL?.length > 0) && (
            <div className="border border-gray-200 rounded-lg">
              <button
                type="button"
                onClick={() => setShowRxPreview(!showRxPreview)}
                className="w-full p-3 flex items-center justify-between text-left hover:bg-gray-50"
              >
                <span className="flex items-center gap-2 text-sm font-medium text-gray-700">
                  <Eye size={16} />
                  View Prescription Details
                </span>
                <span className="text-xs text-[#006FB4]">
                  {showRxPreview ? 'Hide' : 'Show'}
                </span>
              </button>
              
              {showRxPreview && rxData.EyeGlass?.[0] && (
                <div className="p-4 border-t border-gray-200 bg-gray-50">
                  <p className="text-xs font-semibold text-gray-500 mb-2">EYEGLASS PRESCRIPTION</p>
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-gray-500">
                        <th className="text-left py-1">Eye</th>
                        <th className="text-center py-1">Sphere</th>
                        <th className="text-center py-1">Cylinder</th>
                        <th className="text-center py-1">Axis</th>
                        <th className="text-center py-1">Add</th>
                      </tr>
                    </thead>
                    <tbody className="text-gray-900">
                      <tr>
                        <td className="py-1 font-medium">OD (Right)</td>
                        <td className="text-center">{formatRxValue(rxData.EyeGlass[0].OdSphere)}</td>
                        <td className="text-center">{formatRxValue(rxData.EyeGlass[0].OdCylinder)}</td>
                        <td className="text-center">{rxData.EyeGlass[0].OdAxis || '-'}</td>
                        <td className="text-center">{formatRxValue(rxData.EyeGlass[0].OdAdd)}</td>
                      </tr>
                      <tr>
                        <td className="py-1 font-medium">OS (Left)</td>
                        <td className="text-center">{formatRxValue(rxData.EyeGlass[0].OsSphere)}</td>
                        <td className="text-center">{formatRxValue(rxData.EyeGlass[0].OsCylinder)}</td>
                        <td className="text-center">{rxData.EyeGlass[0].OsAxis || '-'}</td>
                        <td className="text-center">{formatRxValue(rxData.EyeGlass[0].OsAdd)}</td>
                      </tr>
                    </tbody>
                  </table>
                  {rxData.EyeGlass[0].Pd && (
                    <p className="mt-2 text-xs text-gray-600">
                      PD: {rxData.EyeGlass[0].Pd}mm
                    </p>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Full API Response Display */}
          <div className="mt-4">
            <FullResponseDisplay 
              title="Complete Rx API Response" 
              data={fullRxResponse}
              isLoading={loadingRx}
              error={rxError}
              defaultExpanded={false}
            />
          </div>

          {/* Acknowledgement Statement */}
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
            <div className="flex items-start gap-3">
              <div className="w-5 h-5 rounded border-2 border-[#006FB4] bg-[#006FB4] flex items-center justify-center flex-shrink-0 mt-0.5">
                <Check size={12} className="text-white" />
              </div>
              <p className="text-sm text-gray-700">
                I confirm that I have received a copy of my eyeglass prescription from this practice. 
                I understand that I am free to purchase eyewear from this practice or from another seller of my choice.
              </p>
            </div>
          </div>

          {/* Signature */}
          <SignatureCapture
            label="Patient Signature"
            signerName={patientName}
            allowedMethods={['draw', 'type']}
            requireBothMethods={false}
            height={120}
            onSignatureComplete={(data) => setSignatureData(data)}
            onClear={() => setSignatureData(null)}
          />

          {/* Error Message */}
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              {error}
            </div>
          )}

          {/* Submit */}
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !signatureData?.isValid}
              className="flex-1 px-4 py-3 bg-[#22653B] text-white rounded-lg font-medium hover:bg-[#1a4f2e] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? 'Submitting...' : 'Confirm Receipt'}
            </button>
          </div>

          {/* Legal Text */}
          <p className="text-xs text-gray-400 text-center">
            This acknowledgement is retained for 3 years per FTC requirements.
            <br />
            Date: {new Date().toLocaleString()} | IP: {clientIp || 'Detecting...'}
          </p>
        </form>
          </>
        )}
      </div>
    </div>
  );
};

export default RxAcknowledgementForm;
