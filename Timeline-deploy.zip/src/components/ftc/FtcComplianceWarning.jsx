import React from 'react';
import { AlertTriangle, AlertCircle, CheckCircle, FileText } from 'lucide-react';
import FtcComplianceService from '../../services/ftcComplianceService';

const FtcComplianceWarning = ({ 
  patientId, 
  hasExam = true,
  onRequestConsent,
  onRequestAcknowledgement,
  compact = false 
}) => {
  if (!hasExam) return null;

  const requirements = FtcComplianceService.getComplianceRequirements(patientId);
  const checkResult = FtcComplianceService.canProceedToCheckout(patientId, hasExam);

  // If complete, show success
  if (requirements.isComplete) {
    if (compact) return null;
    return (
      <div className="flex items-center gap-2 px-3 py-2 bg-green-50 border border-green-200 rounded-lg">
        <CheckCircle size={16} className="text-green-600 flex-shrink-0" />
        <span className="text-sm text-green-700 font-medium">FTC Rx Compliance Complete</span>
      </div>
    );
  }

  // Blocking warning
  if (!checkResult.canProceed) {
    return (
      <div className={`${compact ? 'p-2' : 'p-3'} bg-red-50 border border-red-200 rounded-lg`}>
        <div className="flex items-start gap-2">
          <AlertCircle size={compact ? 16 : 20} className="text-red-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className={`font-semibold text-red-800 ${compact ? 'text-xs' : 'text-sm'}`}>
              {compact ? 'FTC Compliance Required' : 'FTC Eyeglass Rule - Action Required'}
            </p>
            {!compact && (
              <p className="text-sm text-red-700 mt-1">{checkResult.blockingReason}</p>
            )}
            <div className={`flex gap-2 ${compact ? 'mt-1' : 'mt-2'}`}>
              {requirements.needsConsent && (
                <button
                  onClick={onRequestConsent}
                  className={`flex items-center gap-1 px-3 py-1.5 bg-red-600 text-white rounded font-medium hover:bg-red-700 transition-colors ${compact ? 'text-xs' : 'text-sm'}`}
                >
                  <FileText size={14} />
                  Get Consent
                </button>
              )}
              {requirements.needsAcknowledgement && (
                <button
                  onClick={onRequestAcknowledgement}
                  className={`flex items-center gap-1 px-3 py-1.5 bg-red-600 text-white rounded font-medium hover:bg-red-700 transition-colors ${compact ? 'text-xs' : 'text-sm'}`}
                >
                  <FileText size={14} />
                  Get Acknowledgement
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Warning (non-blocking)
  if (checkResult.warningMessage) {
    return (
      <div className={`${compact ? 'p-2' : 'p-3'} bg-amber-50 border border-amber-200 rounded-lg`}>
        <div className="flex items-start gap-2">
          <AlertTriangle size={compact ? 16 : 20} className="text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className={`font-medium text-amber-800 ${compact ? 'text-xs' : 'text-sm'}`}>
              {checkResult.warningMessage}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return null;
};

export const FtcComplianceStatus = ({ patientId, hasExam = true }) => {
  if (!hasExam) {
    return (
      <span className="text-xs text-gray-400">N/A</span>
    );
  }

  const requirements = FtcComplianceService.getComplianceRequirements(patientId);
  const status = FtcComplianceService.getComplianceStatus(patientId);

  if (requirements.isComplete) {
    return (
      <div className="flex items-center gap-1">
        <CheckCircle size={12} className="text-green-600" />
        <span className="text-xs text-green-700 font-medium">Complete</span>
      </div>
    );
  }

  if (requirements.needsConsent) {
    return (
      <div className="flex items-center gap-1">
        <AlertCircle size={12} className="text-red-500" />
        <span className="text-xs text-red-600 font-medium">Consent Required</span>
      </div>
    );
  }

  if (requirements.needsAcknowledgement) {
    return (
      <div className="flex items-center gap-1">
        <AlertTriangle size={12} className="text-amber-500" />
        <span className="text-xs text-amber-600 font-medium">Ack. Required</span>
      </div>
    );
  }

  if (requirements.needsDelivery) {
    return (
      <div className="flex items-center gap-1">
        <AlertTriangle size={12} className="text-blue-500" />
        <span className="text-xs text-blue-600 font-medium">Pending Delivery</span>
      </div>
    );
  }

  return (
    <span className="text-xs text-gray-400">Not Started</span>
  );
};

export default FtcComplianceWarning;
