/**
 * Recommendation List Component
 * 
 * Displays a collection of recommendations with tracking
 */

import React, { useState, useEffect } from 'react';
import { Sparkles, ChevronRight } from 'lucide-react';
import RecommendationCard from './RecommendationCard';
import { RecommendationService } from '../../lib/services/recommendation-service';

const RecommendationList = ({ 
  patientId,
  journeyId,
  displayLocation,
  context,
  compact = false,
  maxDisplay = 3,
  title = 'Recommendations'
}) => {
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRecommendations();
  }, [patientId, displayLocation, context]);

  const loadRecommendations = () => {
    console.log('[RecommendationList] Loading recommendations', {
      patientId,
      displayLocation,
      hasContext: !!context,
      context
    });

    if (!patientId || !context) {
      console.log('[RecommendationList] Missing patientId or context - skipping');
      setRecommendations([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);

      // Generate recommendations for this patient
      const generated = RecommendationService.generateRecommendations(
        context,
        displayLocation
      );

      console.log('[RecommendationList] Generated recommendations:', generated.length, generated);

      // Limit to maxDisplay
      const limited = generated.slice(0, maxDisplay);

      console.log('[RecommendationList] Displaying:', limited.length, 'recommendations');

      setRecommendations(limited);

      // Track impressions
      limited.forEach(rec => {
        RecommendationService.trackEvent(
          rec.id,
          patientId,
          'impression',
          displayLocation,
          { journeyId }
        );
      });
    } catch (error) {
      console.error('[RecommendationList] Error loading recommendations:', error);
      setRecommendations([]);
    } finally {
      setLoading(false);
    }
  };

  const handleDismiss = (recommendation) => {
    RecommendationService.dismissRecommendation(
      recommendation.id,
      patientId,
      displayLocation
    );

    // Remove from display
    setRecommendations(prev => prev.filter(r => r.id !== recommendation.id));
  };

  const handleClick = (recommendation) => {
    RecommendationService.trackEvent(
      recommendation.id,
      patientId,
      'click',
      displayLocation,
      { journeyId }
    );
  };

  const handleCtaClick = (recommendation) => {
    RecommendationService.trackEvent(
      recommendation.id,
      patientId,
      'click',
      displayLocation,
      { 
        journeyId,
        ctaUrl: recommendation.ctaUrl 
      }
    );

    // Navigate if URL is provided
    if (recommendation.ctaUrl) {
      if (recommendation.ctaUrl.startsWith('http')) {
        // External URL
        window.open(recommendation.ctaUrl, '_blank');
      } else {
        // Internal URL
        window.location.href = recommendation.ctaUrl;
      }
    }
  };

  if (loading) {
    return (
      <div className="animate-pulse">
        <div className="h-6 bg-gray-200 rounded w-1/3 mb-3"></div>
        <div className="space-y-3">
          {[1, 2].map(i => (
            <div key={i} className="h-24 bg-gray-100 rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  if (recommendations.length === 0) {
    return null; // Don't show anything if no recommendations
  }

  return (
    <div className="recommendation-list">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-600" />
          <h3 className="text-sm font-semibold text-gray-900">{title}</h3>
          <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded-full font-medium">
            {recommendations.length}
          </span>
        </div>
      </div>

      {/* Recommendations */}
      <div className={compact ? 'space-y-2' : 'space-y-3'}>
        {recommendations.map(recommendation => (
          <RecommendationCard
            key={recommendation.id}
            recommendation={recommendation}
            onDismiss={handleDismiss}
            onClick={handleClick}
            onCtaClick={handleCtaClick}
            compact={compact}
          />
        ))}
      </div>

      {/* View All (if more recommendations available) */}
      {recommendations.length >= maxDisplay && (
        <button
          className="mt-3 w-full px-3 py-2 text-sm text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors flex items-center justify-center gap-1 font-medium"
        >
          View All Recommendations
          <ChevronRight className="w-4 h-4" />
        </button>
      )}
    </div>
  );
};

export default RecommendationList;
