/**
 * Recommendation Card Component
 * 
 * Displays a single recommendation with content, CTA, and tracking
 */

import React from 'react';
import { X, ExternalLink, ShoppingBag, Calendar, Info, Sparkles } from 'lucide-react';

const RecommendationCard = ({ 
  recommendation, 
  onDismiss, 
  onClick,
  onCtaClick,
  compact = false 
}) => {
  const handleCtaClick = (e) => {
    e.stopPropagation();
    if (onCtaClick) {
      onCtaClick(recommendation);
    }
  };

  const handleDismiss = (e) => {
    e.stopPropagation();
    if (onDismiss) {
      onDismiss(recommendation);
    }
  };

  const getTypeIcon = () => {
    switch (recommendation.ruleMetadata?.category || recommendation.metadata?.category) {
      case 'lifestyle-products':
        return <Sparkles className="w-4 h-4" />;
      case 'product-renewal':
        return <ShoppingBag className="w-4 h-4" />;
      case 'scheduling':
        return <Calendar className="w-4 h-4" />;
      default:
        return <Info className="w-4 h-4" />;
    }
  };

  const getTypeColor = () => {
    switch (recommendation.ruleMetadata?.category || recommendation.metadata?.category) {
      case 'lifestyle-products':
        return 'bg-purple-100 text-purple-600';
      case 'product-renewal':
        return 'bg-blue-100 text-blue-600';
      case 'scheduling':
        return 'bg-green-100 text-green-600';
      case 'insurance':
        return 'bg-orange-100 text-orange-600';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  if (compact) {
    return (
      <div 
        onClick={() => onClick?.(recommendation)}
        className="group relative bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-3 hover:shadow-md transition-all cursor-pointer"
      >
        <button
          onClick={handleDismiss}
          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 w-5 h-5 rounded-full bg-white shadow-sm flex items-center justify-center hover:bg-gray-100 transition-opacity"
          title="Dismiss"
        >
          <X className="w-3 h-3 text-gray-500" />
        </button>

        <div className="flex items-start gap-3">
          <div className={`w-8 h-8 rounded-full ${getTypeColor()} flex items-center justify-center flex-shrink-0`}>
            {getTypeIcon()}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="font-semibold text-gray-900 text-sm leading-tight mb-1">
              {recommendation.title}
            </div>
            <div className="text-xs text-gray-600 line-clamp-2">
              {recommendation.description}
            </div>
            
            {recommendation.ctaText && recommendation.ctaUrl && (
              <button
                onClick={handleCtaClick}
                className="mt-2 text-xs font-medium text-blue-600 hover:text-blue-700 flex items-center gap-1"
              >
                {recommendation.ctaText}
                <ExternalLink className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      onClick={() => onClick?.(recommendation)}
      className="group relative bg-white border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition-all cursor-pointer overflow-hidden"
    >
      {/* Dismiss button */}
      <button
        onClick={handleDismiss}
        className="absolute top-3 right-3 z-10 opacity-0 group-hover:opacity-100 w-7 h-7 rounded-full bg-white shadow-md flex items-center justify-center hover:bg-gray-100 transition-opacity"
        title="Dismiss"
      >
        <X className="w-4 h-4 text-gray-500" />
      </button>

      {/* Media */}
      {recommendation.mediaType === 'image' && recommendation.mediaUrl && (
        <div className="relative h-40 bg-gradient-to-br from-blue-100 to-purple-100">
          <img
            src={recommendation.mediaUrl}
            alt={recommendation.title}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.target.style.display = 'none';
            }}
          />
        </div>
      )}

      {/* Content */}
      <div className="p-4">
        <div className="flex items-start gap-3 mb-3">
          <div className={`w-10 h-10 rounded-full ${getTypeColor()} flex items-center justify-center flex-shrink-0`}>
            {getTypeIcon()}
          </div>
          
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-gray-900 text-base leading-tight mb-1">
              {recommendation.title}
            </h3>
            {recommendation.ruleMetadata?.category && (
              <span className="text-xs text-gray-500 capitalize">
                {recommendation.ruleMetadata.category.replace(/-/g, ' ')}
              </span>
            )}
          </div>
        </div>

        <p className="text-sm text-gray-600 leading-relaxed mb-4">
          {recommendation.description}
        </p>

        {/* Tags */}
        {recommendation.ruleMetadata?.tags && recommendation.ruleMetadata.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {recommendation.ruleMetadata.tags.slice(0, 3).map((tag, index) => (
              <span
                key={index}
                className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded-full"
              >
                {tag}
              </span>
            ))}
          </div>
        )}

        {/* CTA Button */}
        {recommendation.ctaText && recommendation.ctaUrl && (
          <button
            onClick={handleCtaClick}
            className="w-full px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 font-medium text-sm"
          >
            {recommendation.ctaText}
            <ExternalLink className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Priority indicator */}
      {recommendation.priority >= 80 && (
        <div className="absolute top-3 left-3 px-2 py-1 bg-yellow-400 text-yellow-900 text-xs font-semibold rounded-full shadow-sm">
          High Priority
        </div>
      )}
    </div>
  );
};

export default RecommendationCard;
