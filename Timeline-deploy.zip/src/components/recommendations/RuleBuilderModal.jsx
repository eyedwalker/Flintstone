/**
 * Visual Rule Builder Modal
 * 
 * Complete UI for creating and editing recommendation rules
 */

import React, { useState, useEffect } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  Save,
  Eye,
  Info,
  ChevronDown,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  FileText
} from 'lucide-react';
import { RecommendationService } from '../../lib/services/recommendation-service';
import { MailMergeService } from '../../lib/services/mail-merge-service';

// Available fields for conditions
const AVAILABLE_FIELDS = [
  { value: 'patient.age', label: 'Patient Age', type: 'number' },
  { value: 'patient.gender', label: 'Patient Gender', type: 'string' },
  { value: 'patient.lifestyle.hobbies', label: 'Lifestyle Hobbies', type: 'array' },
  { value: 'patient.lifestyle.screenTime', label: 'Screen Time (hours)', type: 'number' },
  { value: 'patient.lifestyle.outdoorActivities', label: 'Outdoor Activities', type: 'boolean' },
  { value: 'patient.lifestyle.dryEyeSymptoms', label: 'Dry Eye Symptoms', type: 'boolean' },
  { value: 'appointment.type', label: 'Appointment Type', type: 'string' },
  { value: 'appointment.status', label: 'Appointment Status', type: 'string' },
  { value: 'journey.journeyPhase', label: 'Journey Phase', type: 'string' },
  { value: 'journey.currentStep', label: 'Current Step', type: 'string' },
  { value: 'purchaseHistory[0].productType', label: 'Last Purchase Type', type: 'string' },
  { value: 'purchaseHistory[0].productName', label: 'Last Purchase Name', type: 'string' },
  { value: 'insuranceInfo.carrier', label: 'Insurance Carrier', type: 'string' },
];

// Operators by field type
const OPERATORS_BY_TYPE = {
  number: [
    { value: '==', label: 'equals' },
    { value: '!=', label: 'not equals' },
    { value: '>', label: 'greater than' },
    { value: '<', label: 'less than' },
    { value: '>=', label: 'greater than or equal' },
    { value: '<=', label: 'less than or equal' }
  ],
  string: [
    { value: '==', label: 'equals' },
    { value: '!=', label: 'not equals' },
    { value: 'contains', label: 'contains' },
    { value: 'not-contains', label: 'does not contain' },
    { value: 'in', label: 'is one of' }
  ],
  array: [
    { value: 'contains', label: 'contains' },
    { value: 'not-contains', label: 'does not contain' }
  ],
  boolean: [
    { value: '==', label: 'is' }
  ]
};

// Display locations
const DISPLAY_LOCATIONS = [
  { value: 'journey-step', label: 'Journey Step Cards' },
  { value: 'patient-details-sidebar', label: 'Patient Details Sidebar' },
  { value: 'patient-details-header', label: 'Patient Details Header' },
  { value: 'checkout-summary', label: 'Checkout Summary' },
  { value: 'post-visit-summary', label: 'Post-Visit Summary' },
  { value: 'appointment-confirmation', label: 'Appointment Confirmation' },
  { value: 'room-assignment', label: 'Room Assignment' },
];

// Mail merge tokens
const MAIL_MERGE_TOKENS = [
  { token: '{{patient.firstName}}', label: 'Patient First Name' },
  { token: '{{patient.lastName}}', label: 'Patient Last Name' },
  { token: '{{patient.age}}', label: 'Patient Age' },
  { token: '{{appointment.date|shortdate}}', label: 'Appointment Date' },
  { token: '{{appointment.provider.name}}', label: 'Provider Name' },
  { token: '{{journey.currentStep}}', label: 'Current Journey Step' },
  { token: '{{purchaseHistory[0].productName}}', label: 'Last Product Purchased' },
  { token: '{{purchaseHistory[0].purchaseDate|shortdate}}', label: 'Last Purchase Date' },
  { token: '{{patient.lifestyle.hobbies[0]}}', label: 'First Hobby' },
  { token: '{{insuranceInfo.carrier}}', label: 'Insurance Carrier' },
];

const RuleBuilderModal = ({ rule, onClose, onSave }) => {
  const [activeTab, setActiveTab] = useState('conditions');
  const [errors, setErrors] = useState({});
  
  const [formData, setFormData] = useState(() => ({
    name: rule?.name || '',
    description: rule?.description || '',
    enabled: rule?.enabled ?? true,
    priority: rule?.priority || 50,
    category: rule?.category || '',
    tags: rule?.tags || [],
    conditions: rule?.conditions || [],
    recommendation: {
      type: rule?.recommendation?.type || 'product',
      title: rule?.recommendation?.title || '',
      description: rule?.recommendation?.description || '',
      mediaType: rule?.recommendation?.mediaType || 'text',
      mediaContent: rule?.recommendation?.mediaContent || '',
      ctaText: rule?.recommendation?.ctaText || '',
      ctaUrl: rule?.recommendation?.ctaUrl || '',
      metadata: rule?.recommendation?.metadata || {}
    },
    displayConfig: {
      locations: rule?.displayConfig?.locations || [],
      journeySteps: rule?.displayConfig?.journeySteps || [],
      timing: rule?.displayConfig?.timing || 'immediate',
      maxDisplaysPerPatient: rule?.displayConfig?.maxDisplaysPerPatient || 3,
      cooldownPeriod: rule?.displayConfig?.cooldownPeriod || 0
    }
  }));

  const updateField = (path, value) => {
    setFormData(prev => {
      const newData = { ...prev };
      const keys = path.split('.');
      let current = newData;
      
      for (let i = 0; i < keys.length - 1; i++) {
        current = current[keys[i]];
      }
      
      current[keys[keys.length - 1]] = value;
      return newData;
    });
    
    // Clear error for this field
    if (errors[path]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[path];
        return newErrors;
      });
    }
  };

  const addCondition = () => {
    setFormData(prev => ({
      ...prev,
      conditions: [
        ...prev.conditions,
        { field: '', operator: '==', value: '', logicalOperator: 'AND' }
      ]
    }));
  };

  const updateCondition = (index, field, value) => {
    setFormData(prev => {
      const newConditions = [...prev.conditions];
      newConditions[index] = { ...newConditions[index], [field]: value };
      return { ...prev, conditions: newConditions };
    });
  };

  const removeCondition = (index) => {
    setFormData(prev => ({
      ...prev,
      conditions: prev.conditions.filter((_, i) => i !== index)
    }));
  };

  const toggleDisplayLocation = (location) => {
    setFormData(prev => {
      const locations = prev.displayConfig.locations.includes(location)
        ? prev.displayConfig.locations.filter(l => l !== location)
        : [...prev.displayConfig.locations, location];
      
      return {
        ...prev,
        displayConfig: { ...prev.displayConfig, locations }
      };
    });
  };

  const addTag = (tag) => {
    if (tag && !formData.tags.includes(tag)) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, tag]
      }));
    }
  };

  const removeTag = (tag) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(t => t !== tag)
    }));
  };

  const insertToken = (token, field) => {
    const currentValue = field === 'title' 
      ? formData.recommendation.title 
      : formData.recommendation.description;
    
    updateField(`recommendation.${field}`, currentValue + token);
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Rule name is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    if (formData.priority < 1 || formData.priority > 100) {
      newErrors.priority = 'Priority must be between 1 and 100';
    }

    if (formData.conditions.length === 0) {
      newErrors.conditions = 'At least one condition is required';
    } else {
      formData.conditions.forEach((cond, idx) => {
        if (!cond.field) {
          newErrors[`condition-${idx}-field`] = 'Field is required';
        }
        if (!cond.value && cond.value !== 0 && cond.value !== false) {
          newErrors[`condition-${idx}-value`] = 'Value is required';
        }
      });
    }

    if (!formData.recommendation.title.trim()) {
      newErrors['recommendation.title'] = 'Recommendation title is required';
    }

    if (!formData.recommendation.description.trim()) {
      newErrors['recommendation.description'] = 'Recommendation description is required';
    }

    if (formData.displayConfig.locations.length === 0) {
      newErrors.locations = 'At least one display location is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (!validate()) {
      alert('Please fix the errors before saving');
      return;
    }

    if (rule) {
      RecommendationService.updateRule(rule.id, formData);
    } else {
      RecommendationService.createRule(formData);
    }

    onSave();
  };

  const tabs = [
    { id: 'basics', label: 'Basics', icon: Info },
    { id: 'conditions', label: 'Conditions', icon: Sparkles },
    { id: 'content', label: 'Content', icon: FileText },
    { id: 'display', label: 'Display', icon: Eye },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-6xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 flex items-center justify-between bg-gradient-to-r from-purple-50 to-blue-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">
                {rule ? 'Edit Rule' : 'Create New Rule'}
              </h2>
              <p className="text-sm text-gray-500">Build intelligent recommendation rules</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200 bg-gray-50 px-6">
          <div className="flex gap-1">
            {tabs.map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-3 font-medium text-sm flex items-center gap-2 border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                  {errors[tab.id] && (
                    <AlertCircle className="w-4 h-4 text-red-500" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'basics' && (
            <BasicsTab 
              formData={formData} 
              errors={errors}
              updateField={updateField}
              addTag={addTag}
              removeTag={removeTag}
            />
          )}

          {activeTab === 'conditions' && (
            <ConditionsTab
              conditions={formData.conditions}
              errors={errors}
              addCondition={addCondition}
              updateCondition={updateCondition}
              removeCondition={removeCondition}
            />
          )}

          {activeTab === 'content' && (
            <ContentTab
              recommendation={formData.recommendation}
              errors={errors}
              updateField={updateField}
              insertToken={insertToken}
            />
          )}

          {activeTab === 'display' && (
            <DisplayTab
              displayConfig={formData.displayConfig}
              errors={errors}
              updateField={updateField}
              toggleDisplayLocation={toggleDisplayLocation}
            />
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-200 bg-gray-50 flex justify-between items-center">
          <div className="text-sm text-gray-500">
            {Object.keys(errors).length > 0 && (
              <span className="text-red-600 flex items-center gap-1">
                <AlertCircle className="w-4 h-4" />
                Please fix {Object.keys(errors).length} error{Object.keys(errors).length !== 1 ? 's' : ''}
              </span>
            )}
          </div>
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2 font-medium"
            >
              <Save className="w-4 h-4" />
              {rule ? 'Update Rule' : 'Create Rule'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Basics Tab Component
const BasicsTab = ({ formData, errors, updateField, addTag, removeTag }) => {
  const [tagInput, setTagInput] = useState('');

  const handleAddTag = () => {
    if (tagInput.trim()) {
      addTag(tagInput.trim());
      setTagInput('');
    }
  };

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Name */}
      <div>
        <label className="block text-sm font-medium text-gray-900 mb-2">
          Rule Name *
        </label>
        <input
          type="text"
          value={formData.name}
          onChange={(e) => updateField('name', e.target.value)}
          className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
            errors.name ? 'border-red-500' : 'border-gray-300'
          }`}
          placeholder="e.g., Outdoor Sports Lens Package"
        />
        {errors.name && (
          <p className="mt-1 text-sm text-red-600">{errors.name}</p>
        )}
      </div>

      {/* Description */}
      <div>
        <label className="block text-sm font-medium text-gray-900 mb-2">
          Description *
        </label>
        <textarea
          value={formData.description}
          onChange={(e) => updateField('description', e.target.value)}
          rows={3}
          className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
            errors.description ? 'border-red-500' : 'border-gray-300'
          }`}
          placeholder="Describe when and why this rule should trigger..."
        />
        {errors.description && (
          <p className="mt-1 text-sm text-red-600">{errors.description}</p>
        )}
      </div>

      {/* Priority & Enabled */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Priority (1-100) *
          </label>
          <input
            type="number"
            min="1"
            max="100"
            value={formData.priority}
            onChange={(e) => updateField('priority', parseInt(e.target.value))}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
              errors.priority ? 'border-red-500' : 'border-gray-300'
            }`}
          />
          <p className="mt-1 text-xs text-gray-500">Higher priority = shown first</p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Status
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.enabled}
              onChange={(e) => updateField('enabled', e.target.checked)}
              className="w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
            />
            <span className="text-sm text-gray-700">
              {formData.enabled ? 'Active' : 'Inactive'}
            </span>
          </label>
        </div>
      </div>

      {/* Category */}
      <div>
        <label className="block text-sm font-medium text-gray-900 mb-2">
          Category
        </label>
        <select
          value={formData.category}
          onChange={(e) => updateField('category', e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="">Select category...</option>
          <option value="lifestyle-products">Lifestyle Products</option>
          <option value="product-renewal">Product Renewal</option>
          <option value="age-based-products">Age-Based Products</option>
          <option value="medical-products">Medical Products</option>
          <option value="insurance">Insurance</option>
          <option value="scheduling">Scheduling</option>
        </select>
      </div>

      {/* Tags */}
      <div>
        <label className="block text-sm font-medium text-gray-900 mb-2">
          Tags
        </label>
        <div className="flex gap-2 mb-2">
          <input
            type="text"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
            placeholder="Add tag..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
          <button
            onClick={handleAddTag}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            Add
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {formData.tags.map(tag => (
            <span
              key={tag}
              className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm flex items-center gap-1"
            >
              {tag}
              <button
                onClick={() => removeTag(tag)}
                className="hover:text-blue-900"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

// Conditions Tab Component
const ConditionsTab = ({ conditions, errors, addCondition, updateCondition, removeCondition }) => {
  return (
    <div className="space-y-6">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-2">
          <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-blue-900">
            <p className="font-medium mb-1">How Conditions Work</p>
            <p>Define criteria that must be met for this recommendation to show. All conditions are evaluated together using AND/OR logic.</p>
          </div>
        </div>
      </div>

      {errors.conditions && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-700">
          {errors.conditions}
        </div>
      )}

      <div className="space-y-3">
        {conditions.map((condition, index) => (
          <ConditionRow
            key={index}
            condition={condition}
            index={index}
            errors={errors}
            updateCondition={updateCondition}
            removeCondition={removeCondition}
            showLogicalOperator={index < conditions.length - 1}
          />
        ))}
      </div>

      <button
        onClick={addCondition}
        className="w-full px-4 py-3 border-2 border-dashed border-gray-300 text-gray-600 rounded-lg hover:border-blue-500 hover:text-blue-600 hover:bg-blue-50 transition-colors flex items-center justify-center gap-2"
      >
        <Plus className="w-5 h-5" />
        Add Condition
      </button>
    </div>
  );
};

// Condition Row Component
const ConditionRow = ({ condition, index, errors, updateCondition, removeCondition, showLogicalOperator }) => {
  const selectedField = AVAILABLE_FIELDS.find(f => f.value === condition.field);
  const operators = selectedField ? OPERATORS_BY_TYPE[selectedField.type] : [];

  return (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
      <div className="flex items-start gap-3">
        <div className="flex-1 grid grid-cols-3 gap-3">
          {/* Field */}
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">Field</label>
            <select
              value={condition.field}
              onChange={(e) => updateCondition(index, 'field', e.target.value)}
              className={`w-full px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                errors[`condition-${index}-field`] ? 'border-red-500' : 'border-gray-300'
              }`}
            >
              <option value="">Select field...</option>
              {AVAILABLE_FIELDS.map(field => (
                <option key={field.value} value={field.value}>
                  {field.label}
                </option>
              ))}
            </select>
          </div>

          {/* Operator */}
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">Operator</label>
            <select
              value={condition.operator}
              onChange={(e) => updateCondition(index, 'operator', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              disabled={!selectedField}
            >
              {operators.map(op => (
                <option key={op.value} value={op.value}>
                  {op.label}
                </option>
              ))}
            </select>
          </div>

          {/* Value */}
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">Value</label>
            {selectedField?.type === 'boolean' ? (
              <select
                value={condition.value}
                onChange={(e) => updateCondition(index, 'value', e.target.value === 'true')}
                className={`w-full px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                  errors[`condition-${index}-value`] ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="true">True</option>
                <option value="false">False</option>
              </select>
            ) : (
              <input
                type={selectedField?.type === 'number' ? 'number' : 'text'}
                value={condition.value}
                onChange={(e) => updateCondition(index, 'value', selectedField?.type === 'number' ? parseFloat(e.target.value) : e.target.value)}
                placeholder="Enter value..."
                className={`w-full px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                  errors[`condition-${index}-value`] ? 'border-red-500' : 'border-gray-300'
                }`}
              />
            )}
          </div>
        </div>

        {/* Remove Button */}
        <button
          onClick={() => removeCondition(index)}
          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors mt-6"
          title="Remove condition"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Logical Operator */}
      {showLogicalOperator && (
        <div className="mt-3 flex items-center gap-2">
          <span className="text-xs text-gray-500">Then apply:</span>
          <select
            value={condition.logicalOperator || 'AND'}
            onChange={(e) => updateCondition(index, 'logicalOperator', e.target.value)}
            className="px-2 py-1 border border-gray-300 rounded text-xs font-semibold text-purple-700 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="AND">AND</option>
            <option value="OR">OR</option>
          </select>
        </div>
      )}
    </div>
  );
};

// Content Tab Component
const ContentTab = ({ recommendation, errors, updateField, insertToken }) => {
  const [showTokens, setShowTokens] = useState(false);

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
        <div className="flex items-start gap-2">
          <Sparkles className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-purple-900">
            <p className="font-medium mb-1">Mail Merge Tokens</p>
            <p>Use tokens like <code className="px-1 py-0.5 bg-purple-200 rounded text-xs">{'{{patient.firstName}}'}</code> to personalize content. Click tokens below to insert them.</p>
          </div>
        </div>
      </div>

      {/* Type */}
      <div>
        <label className="block text-sm font-medium text-gray-900 mb-2">
          Recommendation Type
        </label>
        <select
          value={recommendation.type}
          onChange={(e) => updateField('recommendation.type', e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="product">Product</option>
          <option value="service">Service</option>
          <option value="content">Content</option>
          <option value="action">Action</option>
        </select>
      </div>

      {/* Title */}
      <div>
        <label className="block text-sm font-medium text-gray-900 mb-2">
          Title *
        </label>
        <input
          type="text"
          value={recommendation.title}
          onChange={(e) => updateField('recommendation.title', e.target.value)}
          className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
            errors['recommendation.title'] ? 'border-red-500' : 'border-gray-300'
          }`}
          placeholder="e.g., Enhance Your Outdoor Experience"
        />
        {errors['recommendation.title'] && (
          <p className="mt-1 text-sm text-red-600">{errors['recommendation.title']}</p>
        )}
      </div>

      {/* Description */}
      <div>
        <label className="block text-sm font-medium text-gray-900 mb-2">
          Description *
        </label>
        <textarea
          value={recommendation.description}
          onChange={(e) => updateField('recommendation.description', e.target.value)}
          rows={4}
          className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
            errors['recommendation.description'] ? 'border-red-500' : 'border-gray-300'
          }`}
          placeholder="Describe the recommendation..."
        />
        {errors['recommendation.description'] && (
          <p className="mt-1 text-sm text-red-600">{errors['recommendation.description']}</p>
        )}
      </div>

      {/* Mail Merge Tokens */}
      <div>
        <button
          onClick={() => setShowTokens(!showTokens)}
          className="flex items-center gap-2 text-sm font-medium text-purple-600 hover:text-purple-700"
        >
          <ChevronDown className={`w-4 h-4 transition-transform ${showTokens ? 'rotate-180' : ''}`} />
          Insert Mail Merge Token
        </button>
        
        {showTokens && (
          <div className="mt-3 grid grid-cols-2 gap-2">
            {MAIL_MERGE_TOKENS.map(({ token, label }) => (
              <button
                key={token}
                onClick={() => insertToken(token, 'description')}
                className="px-3 py-2 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-lg text-left transition-colors"
              >
                <div className="font-mono text-xs text-purple-700">{token}</div>
                <div className="text-xs text-gray-600">{label}</div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Media */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Media Type
          </label>
          <select
            value={recommendation.mediaType}
            onChange={(e) => updateField('recommendation.mediaType', e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="text">Text Only</option>
            <option value="image">Image</option>
            <option value="video">Video</option>
            <option value="url">URL</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Media URL
          </label>
          <input
            type="text"
            value={recommendation.mediaContent || ''}
            onChange={(e) => updateField('recommendation.mediaContent', e.target.value)}
            placeholder="https://..."
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>

      {/* CTA */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            CTA Button Text
          </label>
          <input
            type="text"
            value={recommendation.ctaText || ''}
            onChange={(e) => updateField('recommendation.ctaText', e.target.value)}
            placeholder="e.g., Learn More"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            CTA URL
          </label>
          <input
            type="text"
            value={recommendation.ctaUrl || ''}
            onChange={(e) => updateField('recommendation.ctaUrl', e.target.value)}
            placeholder="/products/... or https://..."
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>
    </div>
  );
};

// Display Tab Component
const DisplayTab = ({ displayConfig, errors, updateField, toggleDisplayLocation }) => {
  return (
    <div className="space-y-6 max-w-4xl">
      {/* Display Locations */}
      <div>
        <label className="block text-sm font-medium text-gray-900 mb-3">
          Display Locations *
        </label>
        {errors.locations && (
          <p className="mb-2 text-sm text-red-600">{errors.locations}</p>
        )}
        <div className="grid grid-cols-2 gap-3">
          {DISPLAY_LOCATIONS.map(location => (
            <label
              key={location.value}
              className={`flex items-center gap-3 p-3 border-2 rounded-lg cursor-pointer transition-colors ${
                displayConfig.locations.includes(location.value)
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="checkbox"
                checked={displayConfig.locations.includes(location.value)}
                onChange={() => toggleDisplayLocation(location.value)}
                className="w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
              />
              <span className="text-sm font-medium text-gray-900">{location.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Timing */}
      <div>
        <label className="block text-sm font-medium text-gray-900 mb-2">
          Display Timing
        </label>
        <select
          value={displayConfig.timing}
          onChange={(e) => updateField('displayConfig.timing', e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="immediate">Immediate</option>
          <option value="after-step">After Step Completion</option>
          <option value="before-checkout">Before Checkout</option>
        </select>
      </div>

      {/* Max Displays & Cooldown */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Max Displays Per Patient
          </label>
          <input
            type="number"
            min="1"
            value={displayConfig.maxDisplaysPerPatient}
            onChange={(e) => updateField('displayConfig.maxDisplaysPerPatient', parseInt(e.target.value))}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
          <p className="mt-1 text-xs text-gray-500">How many times to show this</p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Cooldown Period (hours)
          </label>
          <input
            type="number"
            min="0"
            value={displayConfig.cooldownPeriod}
            onChange={(e) => updateField('displayConfig.cooldownPeriod', parseInt(e.target.value))}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
          <p className="mt-1 text-xs text-gray-500">Wait time between displays</p>
        </div>
      </div>
    </div>
  );
};

export default RuleBuilderModal;
