import React, { useState } from 'react';

const FullResponseDisplay = ({ 
  title = "API Response", 
  data, 
  isLoading = false, 
  error = null,
  defaultExpanded = false 
}) => {
  const [expanded, setExpanded] = useState(defaultExpanded);

  // Helper to format patient data like the card in the image
  const formatPatientCard = (patientData) => {
    const patient = Array.isArray(patientData) ? patientData[0] : patientData;
    if (!patient) return null;

    return (
      <div className="bg-white border border-gray-200 rounded-lg p-4">
        <div className="mb-4">
          <h2 className="text-lg font-semibold text-gray-900">
            {patient.firstName || patient.FirstName || 'Patient'} {patient.lastName || patient.LastName || 'Name'}
          </h2>
          <div className="text-sm text-gray-600 mt-1">
            <span className="font-medium">Age:</span> {patient.age || 'N/A'} {patient.dob && `(${patient.dob})`}
          </div>
          <div className="text-sm text-gray-600">
            <span className="font-medium">Gender:</span> {patient.gender || patient.Gender || 'N/A'}
          </div>
          <div className="text-sm text-gray-600">
            <span className="font-medium">Patient ID:</span> {patient.patientId || patient.PatientId || 'N/A'}
          </div>
          <div className="text-sm text-gray-600">
            <span className="font-medium">Language:</span> {patient.language || patient.Language || 'English'}
          </div>
        </div>

        <div className="grid grid-cols-4 gap-6">
          {/* Contact Column */}
          <div>
            <h3 className="font-semibold text-sm text-gray-900 mb-2">Contact</h3>
            <div className="space-y-1 text-xs">
              <div><span className="font-medium">Mobile:</span> {patient.mobilePhone || patient.MobilePhone || 'N/A'}</div>
              <div><span className="font-medium">Home:</span> {patient.homePhone || patient.HomePhone || 'N/A'}</div>
              <div><span className="font-medium">Email:</span> {patient.email || patient.Email || 'N/A'}</div>
              <div><span className="font-medium">Pref:</span> {patient.communicationPreference || 'N/A'}</div>
              {patient.address && (
                <div className="mt-2">
                  <div className="font-medium">Address:</div>
                  <div>{patient.address}</div>
                </div>
              )}
            </div>
          </div>

          {/* Appointment Column */}
          <div>
            <h3 className="font-semibold text-sm text-gray-900 mb-2">Appointment</h3>
            <div className="space-y-1 text-xs">
              <div><span className="font-medium">Date:</span> {patient.appointmentDate || 'N/A'}</div>
              <div><span className="font-medium">Time:</span> {patient.appointmentTime || 'N/A'}</div>
              <div><span className="font-medium">Provider:</span> {patient.providerName || patient.ProviderName || 'N/A'}</div>
              <div><span className="font-medium">Type:</span> {patient.appointmentType || 'N/A'}</div>
              <div><span className="font-medium">Status:</span> 
                <span className="ml-1 px-1.5 py-0.5 bg-green-100 text-green-700 rounded text-[10px]">
                  {patient.status || 'Confirmed'}
                </span>
              </div>
            </div>
          </div>

          {/* Insurance & History Column */}
          <div>
            <h3 className="font-semibold text-sm text-gray-900 mb-2">Insurance & History</h3>
            <div className="space-y-1 text-xs">
              <div><span className="font-medium">Plan:</span> {patient.insurancePlan || 'N/A'}</div>
              <div><span className="font-medium">ID:</span> {patient.insuranceId || patient.InsuranceId || 'N/A'}</div>
              <div><span className="font-medium">First Visit:</span> {patient.firstVisit || patient.FirstVisit || 'N/A'}</div>
              <div><span className="font-medium">Last Visit:</span> {patient.lastVisit || patient.LastVisit || 'N/A'}</div>
              <div><span className="font-medium">Last Exam:</span> {patient.lastExam || patient.LastExam || 'N/A'}</div>
            </div>
          </div>

          {/* Compliance & Notes Column */}
          <div>
            <h3 className="font-semibold text-sm text-gray-900 mb-2">Compliance & Notes</h3>
            <div className="space-y-1 text-xs">
              <div><span className="font-medium">HIPAA:</span> {patient.hipaaCompliance || 'N/A'}</div>
              <div><span className="font-medium">Recall:</span> {patient.recallDate || patient.RecallDate || 'None scheduled'}</div>
              {patient.notes && (
                <div className="mt-2">
                  <div className="font-medium">Notes:</div>
                  <div className="text-gray-600">{patient.notes}</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Helper to format orders/appointments data
  const formatOrdersCard = (ordersData) => {
    const orders = Array.isArray(ordersData?.items) ? ordersData.items : (Array.isArray(ordersData) ? ordersData : []);
    
    return (
      <div className="bg-white border border-gray-200 rounded-lg p-4">
        <div className="mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Patient Orders ({orders.length})</h2>
        </div>

        <div className="space-y-3">
          {orders.slice(0, 5).map((order, idx) => (
            <div key={order.OrderId || idx} className="border-b border-gray-100 pb-3 last:border-b-0">
              <div className="grid grid-cols-4 gap-4">
                <div>
                  <div className="font-medium text-sm">Order #{order.OrderNumber || order.OrderId || `ORD-${idx + 1}`}</div>
                  <div className="text-xs text-gray-600">Date: {order.OrderDate ? new Date(order.OrderDate).toLocaleDateString() : 'N/A'}</div>
                </div>
                <div>
                  <div className="text-sm">Status: <span className="font-medium">{order.Status || 'N/A'}</span></div>
                  <div className="text-xs text-gray-600">Type: {order.OrderType || 'N/A'}</div>
                </div>
                <div>
                  <div className="text-sm">Total: <span className="font-medium">${order.TotalAmount || '0.00'}</span></div>
                  <div className="text-xs text-gray-600">Patient: ${order.PatientAmount || '0.00'}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-600">Provider: {order.ProviderName || 'N/A'}</div>
                  <div className="text-xs text-gray-600">Office: {order.OfficeId || 'N/A'}</div>
                </div>
              </div>
            </div>
          ))}
          {orders.length > 5 && (
            <div className="text-center text-sm text-gray-500">+{orders.length - 5} more orders</div>
          )}
        </div>
      </div>
    );
  };

  // Helper to format RX data
  const formatRxCard = (rxData) => {
    const prescriptions = Array.isArray(rxData?.items) ? rxData.items : (Array.isArray(rxData) ? rxData : []);
    
    return (
      <div className="bg-white border border-gray-200 rounded-lg p-4">
        <div className="mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Patient Prescriptions ({prescriptions.length})</h2>
        </div>

        <div className="space-y-4">
          {prescriptions.slice(0, 3).map((rx, idx) => (
            <div key={rx.RxNumber || idx} className="border border-gray-100 rounded p-3">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <div className="font-medium">Prescription #{rx.RxNumber || `RX-${idx + 1}`}</div>
                  <div className="text-sm text-gray-600">
                    Date: {rx.DatePrescribed ? new Date(rx.DatePrescribed).toLocaleDateString() : 'N/A'}
                  </div>
                </div>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  rx.Status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                }`}>
                  {rx.Status || 'Active'}
                </span>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="font-medium text-gray-700">OD (Right Eye)</div>
                  <div className="text-xs">Sph: {rx.OdSphere || '-'} Cyl: {rx.OdCylinder || '-'} Axis: {rx.OdAxis || '-'}</div>
                </div>
                <div>
                  <div className="font-medium text-gray-700">OS (Left Eye)</div>
                  <div className="text-xs">Sph: {rx.OsSphere || '-'} Cyl: {rx.OsCylinder || '-'} Axis: {rx.OsAxis || '-'}</div>
                </div>
              </div>
              
              {(rx.AddPower || rx.PupillaryDistance) && (
                <div className="mt-2 pt-2 border-t border-gray-100 text-xs">
                  {rx.AddPower && <span className="mr-4">Add: {rx.AddPower}</span>}
                  {rx.PupillaryDistance && <span>PD: {rx.PupillaryDistance}mm</span>}
                </div>
              )}
            </div>
          ))}
          {prescriptions.length > 3 && (
            <div className="text-center text-sm text-gray-500">+{prescriptions.length - 3} more prescriptions</div>
          )}
        </div>
      </div>
    );
  };

  // Helper to check if a value is empty/missing
  const isEmpty = (value) => {
    if (value === null || value === undefined) return true;
    if (typeof value === 'string' && value.trim() === '') return true;
    if (Array.isArray(value) && value.length === 0) return true;
    if (typeof value === 'object' && Object.keys(value).length === 0) return true;
    return false;
  };

  // Helper to render a value with proper formatting
  const renderValue = (value, key) => {
    if (value === null || value === undefined) {
      return <span className="text-gray-400 italic">null</span>;
    }
    
    if (typeof value === 'boolean') {
      return <span className={value ? 'text-green-600' : 'text-red-600'}>{String(value)}</span>;
    }
    
    if (typeof value === 'string') {
      if (value.trim() === '') {
        return <span className="text-gray-400 italic">(empty)</span>;
      }
      // Check for dates
      if (key?.toLowerCase().includes('date') || key?.toLowerCase().includes('dob')) {
        try {
          const date = new Date(value);
          if (!isNaN(date.getTime())) {
            return (
              <span className="text-blue-600">
                {value} <span className="text-gray-500 text-sm">({date.toLocaleDateString()})</span>
              </span>
            );
          }
        } catch {}
      }
      // Check for emails
      if (key?.toLowerCase().includes('email') && value.includes('@')) {
        return <span className="text-purple-600">{value}</span>;
      }
      // Check for phone numbers
      if (key?.toLowerCase().includes('phone') || key?.toLowerCase().includes('number')) {
        return <span className="text-green-600">{value}</span>;
      }
      return value;
    }
    
    if (typeof value === 'number') {
      return <span className="text-blue-600">{value}</span>;
    }
    
    if (Array.isArray(value)) {
      if (value.length === 0) {
        return <span className="text-gray-400 italic">[] (empty array)</span>;
      }
      return (
        <div className="ml-4">
          <span className="text-gray-600">[{value.length} items]</span>
          {value.map((item, index) => (
            <div key={index} className="ml-4 border-l border-gray-200 pl-4 mt-2">
              <div className="text-sm font-medium text-gray-500">Item {index}</div>
              {renderObject(item, true)}
            </div>
          ))}
        </div>
      );
    }
    
    if (typeof value === 'object') {
      return renderObject(value, true);
    }
    
    return String(value);
  };

  // Helper to render an object
  const renderObject = (obj, isNested = false) => {
    if (isEmpty(obj)) {
      return <span className="text-gray-400 italic">{} (empty object)</span>;
    }

    const entries = Object.entries(obj);
    
    return (
      <div className={isNested ? "ml-4 border-l border-gray-100 pl-4" : ""}>
        {entries.map(([key, value]) => (
          <div key={key} className="py-1">
            <div className="flex flex-wrap items-start gap-2">
              <span className="font-medium text-gray-700 min-w-0 break-words">
                {key}:
              </span>
              <div className="flex-1 min-w-0">
                {isEmpty(value) ? (
                  <span className="text-gray-400 italic">
                    {value === null ? 'null' : 
                     value === undefined ? 'undefined' : 
                     Array.isArray(value) ? '[] (empty)' :
                     typeof value === 'object' ? '{} (empty)' : '(empty)'}
                  </span>
                ) : (
                  renderValue(value, key)
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
        <div className="flex items-center gap-2">
          <div className="animate-spin h-4 w-4 border-2 border-blue-500 border-t-transparent rounded-full"></div>
          <span className="text-gray-600">Loading {title}...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <div className="flex items-center gap-2 text-red-700">
          <span className="font-medium">Error loading {title}:</span>
          <span>{error.message || String(error)}</span>
        </div>
      </div>
    );
  }

  if (isEmpty(data)) {
    return (
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <div className="text-yellow-700">
          <span className="font-medium">{title}:</span> No data available
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 rounded p-2">
      <div 
        className="flex items-center justify-between cursor-pointer hover:bg-gray-100 p-1 rounded"
        onClick={() => setExpanded(!expanded)}
      >
        <h3 className="font-medium text-xs text-[#222222]">{title}</h3>
        <div className="flex items-center gap-2">
          {Array.isArray(data?.items) ? (
            <span className="text-[10px] text-gray-500">
              {data.items.length} item{data.items.length !== 1 ? 's' : ''}
            </span>
          ) : Array.isArray(data) ? (
            <span className="text-[10px] text-gray-500">
              {data.length} item{data.length !== 1 ? 's' : ''}
            </span>
          ) : null}
          <svg
            className={`w-3 h-3 text-gray-500 transform transition-transform ${
              expanded ? 'rotate-180' : ''
            }`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </div>
      
      {expanded && (
        <div className="mt-2 pt-2 border-t border-gray-200">
          <div className="max-h-96 overflow-auto">
            {/* Use formatted card layouts for different data types */}
            {title === 'Patient Details' && formatPatientCard(data)}
            {title === 'Patient Prescriptions (Rx)' && formatRxCard(data)}
            {title === 'Patient Orders' && formatOrdersCard(data)}
            {title === 'Patient Appointments' && formatOrdersCard(data)}
            
            {/* Fallback to raw data display for other types */}
            {!['Patient Details', 'Patient Prescriptions (Rx)', 'Patient Orders', 'Patient Appointments'].includes(title) && (
              <div className="text-xs bg-white p-2 rounded border">
                {Array.isArray(data) ? (
                  <div className="space-y-3">
                    {data.map((item, index) => (
                      <div key={index} className="pb-3 last:pb-0 border-b border-gray-100 last:border-b-0">
                        <div className="font-medium text-gray-700 mb-2 text-[11px]">
                          Item {index + 1}
                        </div>
                        <div className="space-y-1">
                          {renderObject(item)}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-1">
                    {renderObject(data)}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default FullResponseDisplay;
