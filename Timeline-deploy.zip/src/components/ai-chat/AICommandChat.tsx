/**
 * AI Command Chat Component
 * Natural language chat interface for interacting with the AI system
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Send, Bot, User, Loader2, AlertCircle, CheckCircle, XCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { processNaturalLanguage, executeConfirmedAction } from '../../services/ai/nlu-service';
import OfficeDataCacheService from '../../services/officeDataCacheService';
import type {
  ConversationMessage,
  ConversationContext,
  ToolContext,
  CurrentPatientContext,
  NLUResult,
} from '../../services/ai/types';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  toolName?: string;
  data?: any;
  requiresConfirmation?: boolean;
  pendingAction?: {
    toolName: string;
    parameters: Record<string, any>;
  };
  status?: 'pending' | 'confirmed' | 'cancelled';
}

interface AICommandChatProps {
  staffId: string;
  staffName: string;
  officeId: string;
  companyId?: string;
  currentTaskId?: string;
  currentPatientName?: string;
  currentPatient?: CurrentPatientContext;
  className?: string;
  onActionComplete?: (result: NLUResult) => void;
}

export function AICommandChat({
  staffId,
  staffName,
  officeId,
  companyId,
  currentTaskId,
  currentPatientName,
  currentPatient,
  className = '',
  onActionComplete,
}: AICommandChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [conversationContext, setConversationContext] = useState<ConversationContext>({});
  const [isExpanded, setIsExpanded] = useState(true);
  const [officeData, setOfficeData] = useState<ToolContext['officeData']>(undefined);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const toolContext: ToolContext = {
    staffId,
    staffName,
    officeId,
    companyId,
    currentPatientId: currentPatient?.id,
    currentPatient,
    officeData,
  };

  // Load cached office data (providers, appointment types, carriers) when office changes
  useEffect(() => {
    if (officeId) {
      OfficeDataCacheService.loadOfficeData(officeId, companyId)
        .then(cached => {
          setOfficeData({
            providers: cached.providers.map(p => ({
              staffId: p.staffId,
              fullName: p.fullName,
              providerType: p.providerType,
              guid: p.guid,
            })),
            appointmentTypes: cached.appointmentTypes.map(t => ({
              appointmentTypeId: t.appointmentTypeId,
              description: t.description,
              duration: t.duration,
            })),
            insuranceCarriers: cached.insuranceCarriers.map(c => ({
              carrierId: c.carrierId,
              carrierName: c.carrierName,
            })),
          });
        })
        .catch(err => console.warn('[AIChat] Failed to load office data cache:', err));
    }
  }, [officeId, companyId]);

  useEffect(() => {
    if (currentPatient) {
      setConversationContext(prev => ({
        ...prev,
        currentPatient,
      }));
    }
  }, [currentPatient]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const generateId = () => `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  const getConversationHistory = useCallback((): ConversationMessage[] => {
    return messages.slice(-10).map(msg => ({
      role: msg.role,
      content: msg.content,
    }));
  }, [messages]);

  const addMessage = (role: 'user' | 'assistant', content: string, extras?: Partial<Message>) => {
    const newMessage: Message = {
      id: generateId(),
      role,
      content,
      timestamp: new Date(),
      ...extras,
    };
    setMessages(prev => [...prev, newMessage]);
    return newMessage;
  };

  const updateMessage = (id: string, updates: Partial<Message>) => {
    setMessages(prev => prev.map(msg => 
      msg.id === id ? { ...msg, ...updates } : msg
    ));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    addMessage('user', userMessage);
    setIsLoading(true);

    try {
      const result = await processNaturalLanguage(
        userMessage,
        toolContext,
        getConversationHistory(),
        conversationContext
      );

      if (result.updatedContext) {
        setConversationContext(result.updatedContext);
      }

      if (result.requiresConfirmation && result.toolName) {
        addMessage('assistant', result.message, {
          toolName: result.toolName,
          data: result.data,
          requiresConfirmation: true,
          pendingAction: {
            toolName: result.toolName,
            parameters: result.parameters || {},
          },
          status: 'pending',
        });
      } else {
        addMessage('assistant', result.message, {
          toolName: result.toolName,
          data: result.data,
        });

        if (result.success && onActionComplete) {
          onActionComplete(result);
        }
      }
    } catch (error: any) {
      addMessage('assistant', `Sorry, I encountered an error: ${error.message}`);
    } finally {
      setIsLoading(false);
      inputRef.current?.focus();
    }
  };

  const handleConfirm = async (messageId: string) => {
    const message = messages.find(m => m.id === messageId);
    if (!message?.pendingAction) return;

    updateMessage(messageId, { status: 'confirmed' });
    setIsLoading(true);

    try {
      const result = await executeConfirmedAction(
        message.pendingAction.toolName,
        message.pendingAction.parameters,
        toolContext
      );

      addMessage('assistant', result.message, {
        toolName: result.toolName,
        data: result.data,
      });

      if (result.success && onActionComplete) {
        onActionComplete(result);
      }
    } catch (error: any) {
      addMessage('assistant', `Failed to execute action: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = (messageId: string) => {
    updateMessage(messageId, { status: 'cancelled' });
    addMessage('assistant', 'Action cancelled. Is there anything else I can help you with?');
  };

  const handleQuickAction = (action: string) => {
    setInput(action);
    inputRef.current?.focus();
  };

  const quickActions = [
    "What's today's schedule?",
    "Find available slots",
    "Send forms to patient",
    "Create a task",
    "Check escalations",
    "Call a patient",
  ];

  return (
    <div className={`flex flex-col bg-white rounded-lg shadow-lg border border-gray-200 ${className}`}>
      {/* Header */}
      <div 
        className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-2">
          <Bot className="w-5 h-5" />
          <span className="font-medium">AI Assistant</span>
          {currentPatientName && (
            <span className="text-sm text-blue-200">
              • {currentPatientName}
            </span>
          )}
        </div>
        <button className="p-1 hover:bg-blue-500 rounded">
          {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
        </button>
      </div>

      {isExpanded && (
        <>
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-[300px] max-h-[500px]">
            {messages.length === 0 ? (
              <div className="text-center text-gray-500 py-8">
                <Bot className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p className="mb-4">How can I help you today?</p>
                <div className="flex flex-wrap justify-center gap-2">
                  {quickActions.map((action, i) => (
                    <button
                      key={i}
                      onClick={() => handleQuickAction(action)}
                      className="px-3 py-1.5 text-sm bg-gray-100 hover:bg-gray-200 rounded-full text-gray-700 transition-colors"
                    >
                      {action}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {message.role === 'assistant' && (
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                      <Bot className="w-4 h-4 text-blue-600" />
                    </div>
                  )}
                  
                  <div
                    className={`max-w-[80%] rounded-lg px-4 py-2 ${
                      message.role === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{message.content}</p>
                    
                    {message.toolName && (
                      <div className="mt-2 text-xs opacity-70 flex items-center gap-1">
                        <span className="px-2 py-0.5 bg-black/10 rounded">
                          {message.toolName.replace(/_/g, ' ')}
                        </span>
                      </div>
                    )}

                    {message.requiresConfirmation && message.status === 'pending' && (
                      <div className="mt-3 flex gap-2">
                        <button
                          onClick={() => handleConfirm(message.id)}
                          className="flex items-center gap-1 px-3 py-1.5 bg-green-500 text-white rounded hover:bg-green-600 text-sm"
                        >
                          <CheckCircle className="w-4 h-4" />
                          Confirm
                        </button>
                        <button
                          onClick={() => handleCancel(message.id)}
                          className="flex items-center gap-1 px-3 py-1.5 bg-red-500 text-white rounded hover:bg-red-600 text-sm"
                        >
                          <XCircle className="w-4 h-4" />
                          Cancel
                        </button>
                      </div>
                    )}

                    {message.status === 'confirmed' && (
                      <div className="mt-2 flex items-center gap-1 text-green-600 text-sm">
                        <CheckCircle className="w-4 h-4" />
                        <span>Confirmed</span>
                      </div>
                    )}

                    {message.status === 'cancelled' && (
                      <div className="mt-2 flex items-center gap-1 text-red-500 text-sm">
                        <XCircle className="w-4 h-4" />
                        <span>Cancelled</span>
                      </div>
                    )}

                    {message.data?.slots && message.data.slots.length > 0 && (
                      <div className="mt-3 space-y-1">
                        {message.data.slots.slice(0, 5).map((slot: any, i: number) => (
                          <div
                            key={i}
                            className="text-sm p-2 bg-white rounded border cursor-pointer hover:bg-blue-50"
                            onClick={() => handleQuickAction(`Book slot ${i + 1}`)}
                          >
                            <span className="font-medium">{slot.date}</span> at {slot.startTime}
                            {slot.providerName && <span className="text-gray-500"> - {slot.providerName}</span>}
                          </div>
                        ))}
                      </div>
                    )}

                    {message.data?.patients && message.data.patients.length > 0 && (
                      <div className="mt-3 space-y-1">
                        {message.data.patients.slice(0, 5).map((patient: any, i: number) => (
                          <div
                            key={i}
                            className="text-sm p-2 bg-white rounded border cursor-pointer hover:bg-blue-50"
                            onClick={() => handleQuickAction(`Select patient ${i + 1}`)}
                          >
                            <span className="font-medium">{patient.fullName}</span>
                            {patient.dob && <span className="text-gray-500 ml-2">DOB: {patient.dob}</span>}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {message.role === 'user' && (
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                      <User className="w-4 h-4 text-gray-600" />
                    </div>
                  )}
                </div>
              ))
            )}
            
            {isLoading && (
              <div className="flex gap-3 justify-start">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                  <Bot className="w-4 h-4 text-blue-600" />
                </div>
                <div className="bg-gray-100 rounded-lg px-4 py-2 flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                  <span className="text-gray-500">Thinking...</span>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <form onSubmit={handleSubmit} className="p-4 border-t border-gray-200">
            <div className="flex gap-2">
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type a command or ask a question..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                title="Send message"
                aria-label="Send message"
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </form>
        </>
      )}
    </div>
  );
}

export default AICommandChat;
