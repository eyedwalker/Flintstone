export type TaskPriority = 'low' | 'normal' | 'high' | 'urgent';
export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'blocked';

export interface TimelineTask {
  id: string;
  title: string;
  description?: string;
  status: TaskStatus;
  priority: TaskPriority;
  category?: string;
  channel?: string;
  assignee?: string;
  assignedToOffice?: string;
  createdBy?: string;
  createdByName?: string;
  dueAt?: string | null;
  createdAt: string;
  updatedAt: string;
  metadata?: Record<string, any>;
}

interface TaskListResponse {
  tasks: TimelineTask[];
  queue?: {
    queueLength: number;
    scheduledLength: number;
    nextJob?: any;
    nextScheduled?: any;
  };
}

const API_BASE = '/api/tasks/db';

async function parseJson<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || `Task API error (${response.status})`);
  }
  return response.json();
}

export const TaskService = {
  async fetchTasks(status?: string): Promise<TaskListResponse> {
    const url = status && status !== 'all' ? `${API_BASE}?status=${encodeURIComponent(status)}` : API_BASE;
    const response = await fetch(url);
    return parseJson<TaskListResponse>(response);
  },

  async createTask(
    payload: Partial<TimelineTask> & { title: string },
    options?: { reminderInSeconds?: number }
  ) {
    const response = await fetch(API_BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...payload,
        reminderInSeconds: options?.reminderInSeconds,
      }),
    });
    return parseJson<{ task: TimelineTask }>(response);
  },

  async updateTask(id: string, updates: Partial<TimelineTask>) {
    const response = await fetch(`${API_BASE}/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    return parseJson<{ task: TimelineTask }>(response);
  },
};
