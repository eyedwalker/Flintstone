/**
 * HIPAA Compliance Service
 * Handles annual HIPAA agreement signature capture, tracking, and expiration
 */

const HIPAA_RECORDS_KEY = 'hipaa_signature_records';
const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1000; // 1 year in milliseconds

export interface HipaaSignatureRecord {
  patientId: string;
  patientUid?: string;
  patientName: string;
  
  // Signature data
  signatureTimestamp: string;
  signatureImage?: string; // Base64 PNG
  signatureTyped?: string;
  signatureMethod: 'draw' | 'type' | 'both';
  
  // Device/capture info
  deviceId: string;
  deviceType: 'ipad' | 'desktop' | 'mobile' | 'unknown';
  ipAddress: string;
  userAgent?: string;
  
  // Associate supervision
  associateId: string;
  associateName: string;
  associateSupervised: boolean;
  
  // Store info
  storeNumber?: string;
  storeId?: string;
  
  // Expiration tracking
  expiresAt: string;
  isExpired: boolean;
  
  // Metadata
  createdAt: string;
  updatedAt: string;
}

export interface HipaaComplianceStatus {
  hasSignature: boolean;
  isExpired: boolean;
  isValid: boolean;
  expiresAt?: string;
  daysUntilExpiration?: number;
  lastSignatureDate?: string;
  requiresRenewal: boolean;
}

class HipaaComplianceServiceClass {
  
  // ============================================
  // SIGNATURE RECORDS
  // ============================================

  /**
   * Get all HIPAA signature records
   */
  getAllRecords(): HipaaSignatureRecord[] {
    const stored = localStorage.getItem(HIPAA_RECORDS_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  /**
   * Get HIPAA signature record for a patient
   */
  getPatientRecord(patientId: string): HipaaSignatureRecord | null {
    const records = this.getAllRecords();
    return records.find(r => r.patientId === patientId) || null;
  }

  /**
   * Save or update a HIPAA signature record
   */
  saveRecord(record: HipaaSignatureRecord): void {
    const records = this.getAllRecords();
    const existingIndex = records.findIndex(r => r.patientId === record.patientId);
    
    record.updatedAt = new Date().toISOString();
    
    if (existingIndex >= 0) {
      records[existingIndex] = record;
    } else {
      record.createdAt = new Date().toISOString();
      records.push(record);
    }
    
    localStorage.setItem(HIPAA_RECORDS_KEY, JSON.stringify(records));
  }

  // ============================================
  // SIGNATURE CAPTURE
  // ============================================

  /**
   * Capture HIPAA signature for a patient
   */
  captureSignature(params: {
    patientId: string;
    patientUid?: string;
    patientName: string;
    signatureImage?: string;
    signatureTyped?: string;
    signatureMethod: 'draw' | 'type' | 'both';
    deviceId: string;
    deviceType: 'ipad' | 'desktop' | 'mobile' | 'unknown';
    ipAddress: string;
    userAgent?: string;
    associateId: string;
    associateName: string;
    associateSupervised: boolean;
    storeNumber?: string;
    storeId?: string;
  }): HipaaSignatureRecord {
    const now = new Date();
    const expiresAt = new Date(now.getTime() + ONE_YEAR_MS);
    
    const record: HipaaSignatureRecord = {
      patientId: params.patientId,
      patientUid: params.patientUid,
      patientName: params.patientName,
      signatureTimestamp: now.toISOString(),
      signatureImage: params.signatureImage,
      signatureTyped: params.signatureTyped,
      signatureMethod: params.signatureMethod,
      deviceId: params.deviceId,
      deviceType: params.deviceType,
      ipAddress: params.ipAddress,
      userAgent: params.userAgent,
      associateId: params.associateId,
      associateName: params.associateName,
      associateSupervised: params.associateSupervised,
      storeNumber: params.storeNumber,
      storeId: params.storeId,
      expiresAt: expiresAt.toISOString(),
      isExpired: false,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    };
    
    this.saveRecord(record);
    return record;
  }

  // ============================================
  // COMPLIANCE CHECKS
  // ============================================

  /**
   * Get compliance status for a patient
   */
  getComplianceStatus(patientId: string): HipaaComplianceStatus {
    const record = this.getPatientRecord(patientId);
    
    if (!record) {
      return {
        hasSignature: false,
        isExpired: false,
        isValid: false,
        requiresRenewal: true,
      };
    }
    
    const now = new Date();
    const expiresAt = new Date(record.expiresAt);
    const isExpired = now >= expiresAt;
    const daysUntilExpiration = Math.ceil((expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    // Update expiration status if needed
    if (isExpired && !record.isExpired) {
      record.isExpired = true;
      this.saveRecord(record);
    }
    
    return {
      hasSignature: true,
      isExpired: isExpired,
      isValid: !isExpired && record.associateSupervised,
      expiresAt: record.expiresAt,
      daysUntilExpiration: isExpired ? 0 : daysUntilExpiration,
      lastSignatureDate: record.signatureTimestamp,
      requiresRenewal: isExpired,
    };
  }

  /**
   * Check if patient has valid (non-expired) HIPAA signature
   */
  hasValidSignature(patientId: string): boolean {
    const status = this.getComplianceStatus(patientId);
    return status.isValid;
  }

  /**
   * Check if patient needs HIPAA signature (missing or expired)
   */
  needsSignature(patientId: string): boolean {
    const status = this.getComplianceStatus(patientId);
    return !status.hasSignature || status.isExpired;
  }

  /**
   * Check if patient can proceed to exam/Rx sales
   */
  canProceedToExam(patientId: string): {
    canProceed: boolean;
    blockingReason?: string;
    warningMessage?: string;
  } {
    const status = this.getComplianceStatus(patientId);
    
    if (status.isValid) {
      // Check if expiring soon (within 30 days)
      if (status.daysUntilExpiration && status.daysUntilExpiration <= 30) {
        return {
          canProceed: true,
          warningMessage: `HIPAA signature expires in ${status.daysUntilExpiration} days. Consider renewal.`,
        };
      }
      return { canProceed: true };
    }
    
    if (!status.hasSignature) {
      return {
        canProceed: false,
        blockingReason: 'HIPAA signature required',
        warningMessage: 'Patient must sign HIPAA agreement before exam or Rx materials can be provided.',
      };
    }
    
    if (status.isExpired) {
      return {
        canProceed: false,
        blockingReason: 'HIPAA signature expired',
        warningMessage: 'HIPAA signature has expired (over 1 year old). Patient must re-sign before proceeding.',
      };
    }
    
    return { canProceed: true };
  }

  // ============================================
  // DEVICE DETECTION
  // ============================================

  /**
   * Detect device type from user agent
   */
  detectDeviceType(): 'ipad' | 'desktop' | 'mobile' | 'unknown' {
    const ua = navigator.userAgent.toLowerCase();
    
    if (ua.includes('ipad')) return 'ipad';
    if (ua.includes('iphone') || ua.includes('android')) return 'mobile';
    if (ua.includes('macintosh') || ua.includes('windows') || ua.includes('linux')) return 'desktop';
    
    return 'unknown';
  }

  /**
   * Generate a device ID (fingerprint)
   */
  generateDeviceId(): string {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.textBaseline = 'top';
      ctx.font = '14px Arial';
      ctx.fillText('Device ID', 2, 2);
    }
    
    const components = [
      navigator.userAgent,
      navigator.language,
      screen.width + 'x' + screen.height,
      new Date().getTimezoneOffset(),
      canvas.toDataURL(),
    ];
    
    // Simple hash
    let hash = 0;
    const str = components.join('|');
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    
    return 'DEV-' + Math.abs(hash).toString(16).toUpperCase();
  }

  /**
   * Get client IP address
   */
  async getClientIp(): Promise<string> {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch {
      return 'unknown';
    }
  }

  // ============================================
  // REPORTING
  // ============================================

  /**
   * Get all patients needing HIPAA renewal
   */
  getPatientsNeedingRenewal(): HipaaSignatureRecord[] {
    const records = this.getAllRecords();
    const now = new Date();
    
    return records.filter(r => {
      const expiresAt = new Date(r.expiresAt);
      return now >= expiresAt;
    });
  }

  /**
   * Get patients with signatures expiring within N days
   */
  getPatientsExpiringSoon(days: number = 30): HipaaSignatureRecord[] {
    const records = this.getAllRecords();
    const now = new Date();
    const threshold = new Date(now.getTime() + (days * 24 * 60 * 60 * 1000));
    
    return records.filter(r => {
      const expiresAt = new Date(r.expiresAt);
      return expiresAt > now && expiresAt <= threshold;
    });
  }

  /**
   * Generate compliance report
   */
  generateComplianceReport(): {
    totalPatients: number;
    validSignatures: number;
    expiredSignatures: number;
    expiringSoon: number;
    noSignature: number;
  } {
    const records = this.getAllRecords();
    const now = new Date();
    const thirtyDaysFromNow = new Date(now.getTime() + (30 * 24 * 60 * 60 * 1000));
    
    let valid = 0;
    let expired = 0;
    let expiringSoon = 0;
    
    records.forEach(r => {
      const expiresAt = new Date(r.expiresAt);
      if (now >= expiresAt) {
        expired++;
      } else if (expiresAt <= thirtyDaysFromNow) {
        expiringSoon++;
        valid++;
      } else {
        valid++;
      }
    });
    
    return {
      totalPatients: records.length,
      validSignatures: valid,
      expiredSignatures: expired,
      expiringSoon: expiringSoon,
      noSignature: 0, // Would need patient list to calculate
    };
  }

  // ============================================
  // UTILITIES
  // ============================================

  /**
   * Clear all records (for testing)
   */
  clearAllRecords(): void {
    localStorage.removeItem(HIPAA_RECORDS_KEY);
  }

  /**
   * Export records for backup
   */
  exportRecords(): string {
    return JSON.stringify(this.getAllRecords(), null, 2);
  }
}

export const HipaaComplianceService = new HipaaComplianceServiceClass();
export default HipaaComplianceService;
