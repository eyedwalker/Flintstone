// Voice Template Service for AI Agent Calls
// Supports categorized templates with extensive mail merge fields

export type TemplateCategory = 
  | 'appointment_confirmation'
  | 'appointment_reminder'
  | 'appointment_reschedule'
  | 'insurance_verification'
  | 'insurance_benefits'
  | 'forms_completion'
  | 'prescription_ready'
  | 'recall_outreach'
  | 'balance_due'
  | 'order_status'
  | 'welcome_new_patient'
  | 'post_visit_followup'
  | 'emergency_closure'
  | 'general_announcement'
  | 'custom';

export type TemplateChannel = 'voice' | 'sms' | 'email';

export interface MergeFieldDefinition {
  field: string;
  label: string;
  category: 'patient' | 'appointment' | 'office' | 'provider' | 'insurance' | 'order' | 'custom';
  description: string;
  example: string;
}

export interface VoiceTemplate {
  id: string;
  name: string;
  description: string;
  category: TemplateCategory;
  channel: TemplateChannel;
  
  // Voice-specific settings
  voiceSettings?: {
    tone: 'friendly' | 'professional' | 'urgent' | 'empathetic';
    pace: 'slow' | 'normal' | 'fast';
    allowInterruption: boolean;
    maxRetries: number;
  };
  
  // Script content
  greeting: string;
  mainScript: string;
  closingScript: string;
  
  // Conditional scripts based on responses
  conditionalScripts?: {
    onConfirm?: string;
    onReschedule?: string;
    onCancel?: string;
    onQuestion?: string;
    onNoAnswer?: string;
    onVoicemail?: string;
  };
  
  // Mail merge fields used in this template
  mergeFields: string[];
  
  // Metadata
  isActive: boolean;
  isDefault: boolean;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
  version: number;
}

// All available merge fields
export const MERGE_FIELD_DEFINITIONS: MergeFieldDefinition[] = [
  // Patient Fields
  { field: 'patient.firstName', label: 'First Name', category: 'patient', description: 'Patient first name', example: 'John' },
  { field: 'patient.lastName', label: 'Last Name', category: 'patient', description: 'Patient last name', example: 'Smith' },
  { field: 'patient.fullName', label: 'Full Name', category: 'patient', description: 'Patient full name', example: 'John Smith' },
  { field: 'patient.preferredName', label: 'Preferred Name', category: 'patient', description: 'How patient prefers to be called', example: 'Johnny' },
  { field: 'patient.phone', label: 'Phone', category: 'patient', description: 'Primary phone number', example: '(555) 123-4567' },
  { field: 'patient.mobilePhone', label: 'Mobile Phone', category: 'patient', description: 'Mobile phone number', example: '(555) 987-6543' },
  { field: 'patient.email', label: 'Email', category: 'patient', description: 'Email address', example: 'john@email.com' },
  { field: 'patient.dob', label: 'Date of Birth', category: 'patient', description: 'Patient date of birth', example: '01/15/1985' },
  { field: 'patient.age', label: 'Age', category: 'patient', description: 'Patient age', example: '39' },
  { field: 'patient.lastExamDate', label: 'Last Exam Date', category: 'patient', description: 'Date of last exam', example: '06/15/2024' },
  { field: 'patient.nextRecallDate', label: 'Recall Date', category: 'patient', description: 'Next recall due date', example: '06/15/2025' },
  { field: 'patient.preferredLanguage', label: 'Preferred Language', category: 'patient', description: 'Patient preferred language', example: 'English' },
  
  // Appointment Fields
  { field: 'appointment.date', label: 'Appointment Date', category: 'appointment', description: 'Date of appointment', example: 'Monday, January 15th' },
  { field: 'appointment.dateShort', label: 'Date (Short)', category: 'appointment', description: 'Short date format', example: '01/15/2025' },
  { field: 'appointment.time', label: 'Appointment Time', category: 'appointment', description: 'Time of appointment', example: '2:30 PM' },
  { field: 'appointment.duration', label: 'Duration', category: 'appointment', description: 'Appointment duration', example: '30 minutes' },
  { field: 'appointment.type', label: 'Appointment Type', category: 'appointment', description: 'Type of appointment', example: 'Comprehensive Eye Exam' },
  { field: 'appointment.reason', label: 'Reason', category: 'appointment', description: 'Reason for visit', example: 'Annual checkup' },
  { field: 'appointment.status', label: 'Status', category: 'appointment', description: 'Appointment status', example: 'Confirmed' },
  { field: 'appointment.confirmationNumber', label: 'Confirmation #', category: 'appointment', description: 'Confirmation number', example: 'APT-2025-1234' },
  { field: 'appointment.arrivalTime', label: 'Arrival Time', category: 'appointment', description: 'Suggested arrival time', example: '2:15 PM' },
  { field: 'appointment.daysUntil', label: 'Days Until', category: 'appointment', description: 'Days until appointment', example: '3' },
  
  // Office Fields
  { field: 'office.name', label: 'Office Name', category: 'office', description: 'Name of the office', example: 'Vision Care Center' },
  { field: 'office.phone', label: 'Office Phone', category: 'office', description: 'Office phone number', example: '(555) 555-1234' },
  { field: 'office.address', label: 'Address', category: 'office', description: 'Full office address', example: '123 Main St, Suite 100' },
  { field: 'office.city', label: 'City', category: 'office', description: 'Office city', example: 'Dallas' },
  { field: 'office.state', label: 'State', category: 'office', description: 'Office state', example: 'TX' },
  { field: 'office.zip', label: 'ZIP Code', category: 'office', description: 'Office ZIP code', example: '75201' },
  { field: 'office.fullAddress', label: 'Full Address', category: 'office', description: 'Complete address', example: '123 Main St, Suite 100, Dallas, TX 75201' },
  { field: 'office.hours', label: 'Office Hours', category: 'office', description: 'Office hours', example: 'Mon-Fri 8am-5pm' },
  { field: 'office.website', label: 'Website', category: 'office', description: 'Office website', example: 'www.visioncare.com' },
  { field: 'office.email', label: 'Office Email', category: 'office', description: 'Office email', example: 'info@visioncare.com' },
  
  // Provider Fields
  { field: 'provider.name', label: 'Provider Name', category: 'provider', description: 'Provider full name', example: 'Dr. Sarah Johnson' },
  { field: 'provider.firstName', label: 'Provider First Name', category: 'provider', description: 'Provider first name', example: 'Sarah' },
  { field: 'provider.lastName', label: 'Provider Last Name', category: 'provider', description: 'Provider last name', example: 'Johnson' },
  { field: 'provider.title', label: 'Title', category: 'provider', description: 'Provider title', example: 'OD' },
  { field: 'provider.specialty', label: 'Specialty', category: 'provider', description: 'Provider specialty', example: 'Optometrist' },
  
  // Insurance Fields
  { field: 'insurance.name', label: 'Insurance Name', category: 'insurance', description: 'Insurance company name', example: 'VSP Vision Care' },
  { field: 'insurance.planName', label: 'Plan Name', category: 'insurance', description: 'Insurance plan name', example: 'VSP Choice' },
  { field: 'insurance.planType', label: 'Plan Type', category: 'insurance', description: 'Type of plan', example: 'Vision' },
  { field: 'insurance.memberId', label: 'Member ID', category: 'insurance', description: 'Insurance member ID', example: '123456789' },
  { field: 'insurance.groupNumber', label: 'Group Number', category: 'insurance', description: 'Insurance group number', example: 'GRP-5678' },
  { field: 'insurance.copay', label: 'Copay Amount', category: 'insurance', description: 'Expected copay', example: '$25' },
  { field: 'insurance.deductible', label: 'Deductible', category: 'insurance', description: 'Deductible amount', example: '$100' },
  { field: 'insurance.benefitsUsed', label: 'Benefits Used', category: 'insurance', description: 'Benefits used this year', example: '$150' },
  { field: 'insurance.benefitsRemaining', label: 'Benefits Remaining', category: 'insurance', description: 'Benefits remaining', example: '$350' },
  { field: 'insurance.expirationDate', label: 'Benefits Expiration', category: 'insurance', description: 'When benefits expire', example: '12/31/2025' },
  
  // Order Fields
  { field: 'order.number', label: 'Order Number', category: 'order', description: 'Order number', example: 'ORD-2025-5678' },
  { field: 'order.type', label: 'Order Type', category: 'order', description: 'Type of order', example: 'Eyeglasses' },
  { field: 'order.status', label: 'Order Status', category: 'order', description: 'Current order status', example: 'Ready for pickup' },
  { field: 'order.estimatedDate', label: 'Estimated Date', category: 'order', description: 'Estimated completion', example: 'January 20, 2025' },
  { field: 'order.totalAmount', label: 'Total Amount', category: 'order', description: 'Order total', example: '$450.00' },
  { field: 'order.balanceDue', label: 'Balance Due', category: 'order', description: 'Amount still owed', example: '$125.00' },
  
  // Custom/Dynamic Fields
  { field: 'custom.message', label: 'Custom Message', category: 'custom', description: 'Custom message content', example: 'Your custom message here' },
  { field: 'custom.date', label: 'Custom Date', category: 'custom', description: 'A custom date value', example: '01/20/2025' },
  { field: 'custom.amount', label: 'Custom Amount', category: 'custom', description: 'A custom amount', example: '$100.00' },
  { field: 'custom.link', label: 'Custom Link', category: 'custom', description: 'A custom URL', example: 'https://example.com' },
];

// Category metadata
export const TEMPLATE_CATEGORIES: Record<TemplateCategory, { label: string; description: string; icon: string }> = {
  appointment_confirmation: { label: 'Appointment Confirmation', description: 'Confirm upcoming appointments', icon: '✅' },
  appointment_reminder: { label: 'Appointment Reminder', description: 'Remind patients of appointments', icon: '🔔' },
  appointment_reschedule: { label: 'Reschedule Request', description: 'Handle reschedule requests', icon: '📅' },
  insurance_verification: { label: 'Insurance Verification', description: 'Verify insurance information', icon: '🏥' },
  insurance_benefits: { label: 'Benefits Information', description: 'Inform about insurance benefits', icon: '💳' },
  forms_completion: { label: 'Forms Completion', description: 'Request form completion', icon: '📝' },
  prescription_ready: { label: 'Prescription Ready', description: 'Notify prescription is ready', icon: '👓' },
  recall_outreach: { label: 'Recall Outreach', description: 'Schedule recall appointments', icon: '📞' },
  balance_due: { label: 'Balance Due', description: 'Notify of outstanding balance', icon: '💰' },
  order_status: { label: 'Order Status', description: 'Update on order status', icon: '📦' },
  welcome_new_patient: { label: 'Welcome New Patient', description: 'Welcome new patients', icon: '👋' },
  post_visit_followup: { label: 'Post-Visit Follow-up', description: 'Follow up after visits', icon: '💬' },
  emergency_closure: { label: 'Emergency Closure', description: 'Notify of closures', icon: '⚠️' },
  general_announcement: { label: 'General Announcement', description: 'General announcements', icon: '📢' },
  custom: { label: 'Custom', description: 'Custom template', icon: '✏️' },
};

// Default voice templates
const DEFAULT_VOICE_TEMPLATES: VoiceTemplate[] = [
  {
    id: 'voice_appt_confirm_1',
    name: 'Appointment Confirmation - Standard',
    description: 'Standard call to confirm an upcoming appointment',
    category: 'appointment_confirmation',
    channel: 'voice',
    voiceSettings: {
      tone: 'friendly',
      pace: 'normal',
      allowInterruption: true,
      maxRetries: 2,
    },
    greeting: "Hello, may I speak with {patient.firstName}? This is calling from {office.name}.",
    mainScript: "I'm calling to confirm your appointment scheduled for {appointment.date} at {appointment.time} with {provider.name}. Can you confirm you'll be able to make it?",
    closingScript: "Great! As a reminder, please arrive about 15 minutes early. If you have any questions, you can reach us at {office.phone}. Have a wonderful day!",
    conditionalScripts: {
      onConfirm: "Perfect! We have you confirmed for {appointment.date} at {appointment.time}. We look forward to seeing you!",
      onReschedule: "No problem, I understand schedules can change. Would you like me to transfer you to our scheduling team, or would you prefer to call us back at {office.phone}?",
      onCancel: "I understand. Would you like to reschedule for another time, or should I cancel this appointment for now?",
      onVoicemail: "Hello {patient.firstName}, this is {office.name} calling to confirm your appointment on {appointment.date} at {appointment.time} with {provider.name}. Please call us back at {office.phone} to confirm. Thank you!",
    },
    mergeFields: ['patient.firstName', 'office.name', 'appointment.date', 'appointment.time', 'provider.name', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'voice_appt_reminder_24hr',
    name: 'Appointment Reminder - 24 Hour',
    description: 'Reminder call 24 hours before appointment',
    category: 'appointment_reminder',
    channel: 'voice',
    voiceSettings: {
      tone: 'friendly',
      pace: 'normal',
      allowInterruption: true,
      maxRetries: 2,
    },
    greeting: "Hello, this is {office.name} with a friendly reminder for {patient.firstName}.",
    mainScript: "We're calling to remind you about your appointment tomorrow, {appointment.date}, at {appointment.time} with {provider.name}. Please remember to bring your insurance card and arrive about 15 minutes early.",
    closingScript: "If you need to make any changes, please call us at {office.phone}. We look forward to seeing you tomorrow!",
    conditionalScripts: {
      onConfirm: "Thank you for confirming! We'll see you tomorrow at {appointment.time}.",
      onReschedule: "I understand. Please call us at {office.phone} as soon as possible to reschedule.",
      onVoicemail: "Hello {patient.firstName}, this is a reminder from {office.name} about your appointment tomorrow at {appointment.time}. Please call us at {office.phone} if you need to make any changes. See you soon!",
    },
    mergeFields: ['patient.firstName', 'office.name', 'appointment.date', 'appointment.time', 'provider.name', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'voice_insurance_verify',
    name: 'Insurance Verification Request',
    description: 'Call to verify or update insurance information',
    category: 'insurance_verification',
    channel: 'voice',
    voiceSettings: {
      tone: 'professional',
      pace: 'normal',
      allowInterruption: true,
      maxRetries: 2,
    },
    greeting: "Hello, may I speak with {patient.firstName} {patient.lastName}? This is calling from {office.name}.",
    mainScript: "I'm calling regarding your upcoming appointment on {appointment.date}. We need to verify your insurance information to ensure everything is in order. Do you have a moment to confirm a few details?",
    closingScript: "Thank you for verifying that information. If there are any changes before your appointment, please let us know. You can reach us at {office.phone}. Have a great day!",
    conditionalScripts: {
      onConfirm: "Great! Can you please confirm your insurance is still with {insurance.name}? And your member ID is {insurance.memberId}?",
      onQuestion: "I'd be happy to help answer that. For detailed benefits questions, I can transfer you to our insurance specialist, or you can call us at {office.phone}.",
      onVoicemail: "Hello {patient.firstName}, this is {office.name}. We need to verify your insurance information before your appointment on {appointment.date}. Please call us back at {office.phone} at your earliest convenience. Thank you!",
    },
    mergeFields: ['patient.firstName', 'patient.lastName', 'office.name', 'appointment.date', 'insurance.name', 'insurance.memberId', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'voice_recall_standard',
    name: 'Recall Outreach - Standard',
    description: 'Call patients due for their annual exam',
    category: 'recall_outreach',
    channel: 'voice',
    voiceSettings: {
      tone: 'friendly',
      pace: 'normal',
      allowInterruption: true,
      maxRetries: 3,
    },
    greeting: "Hello, may I speak with {patient.firstName}? This is calling from {office.name}, {provider.name}'s office.",
    mainScript: "I'm reaching out because according to our records, you're due for your annual eye exam. Your last visit was on {patient.lastExamDate}. Regular eye exams are important for maintaining your eye health. Would you like to schedule an appointment?",
    closingScript: "Wonderful! We appreciate you taking care of your eye health. If you have any questions, don't hesitate to call us at {office.phone}. Take care!",
    conditionalScripts: {
      onConfirm: "Great! I can help you find a convenient time. Do you prefer mornings or afternoons? And is there a particular day of the week that works best for you?",
      onReschedule: "No problem. When would be a better time for us to call back?",
      onQuestion: "That's a great question. For detailed information, I can have someone from our office call you back, or you can reach us directly at {office.phone}.",
      onVoicemail: "Hello {patient.firstName}, this is {office.name} calling. We noticed you're due for your annual eye exam - your last visit was {patient.lastExamDate}. Please give us a call at {office.phone} to schedule your next appointment. Thank you!",
    },
    mergeFields: ['patient.firstName', 'office.name', 'provider.name', 'patient.lastExamDate', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'voice_rx_ready',
    name: 'Prescription Ready for Pickup',
    description: 'Notify patient their glasses/contacts are ready',
    category: 'prescription_ready',
    channel: 'voice',
    voiceSettings: {
      tone: 'friendly',
      pace: 'normal',
      allowInterruption: true,
      maxRetries: 2,
    },
    greeting: "Hello, this is {office.name} calling for {patient.firstName}.",
    mainScript: "Great news! Your {order.type} order is ready for pickup. You can come by anytime during our business hours, {office.hours}.",
    closingScript: "We're located at {office.address}. If you have any questions, call us at {office.phone}. We look forward to seeing you!",
    conditionalScripts: {
      onConfirm: "Perfect! Just bring your photo ID when you come in. Is there anything else I can help you with?",
      onQuestion: "I'd be happy to help. What would you like to know?",
      onVoicemail: "Hello {patient.firstName}, this is {office.name}. We're excited to let you know your {order.type} is ready for pickup! We're open {office.hours}. See you soon!",
    },
    mergeFields: ['patient.firstName', 'office.name', 'order.type', 'office.hours', 'office.address', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'voice_balance_due',
    name: 'Balance Due Reminder',
    description: 'Remind patient of outstanding balance',
    category: 'balance_due',
    channel: 'voice',
    voiceSettings: {
      tone: 'professional',
      pace: 'normal',
      allowInterruption: true,
      maxRetries: 2,
    },
    greeting: "Hello, may I speak with {patient.firstName} {patient.lastName}? This is calling from {office.name}'s billing department.",
    mainScript: "I'm calling regarding an outstanding balance of {order.balanceDue} on your account. This is related to your visit on {patient.lastExamDate}. Would you like to take care of this over the phone today?",
    closingScript: "Thank you for your time. If you have any questions about your statement, please call our billing department at {office.phone}. Have a good day.",
    conditionalScripts: {
      onConfirm: "Great! I can take a payment over the phone now, or I can transfer you to our billing specialist. Which would you prefer?",
      onQuestion: "I understand you may have questions. I can transfer you to our billing specialist who can review your account in detail.",
      onVoicemail: "Hello {patient.firstName}, this is {office.name}'s billing department. We're calling regarding an outstanding balance on your account. Please call us at {office.phone} at your earliest convenience. Thank you.",
    },
    mergeFields: ['patient.firstName', 'patient.lastName', 'office.name', 'order.balanceDue', 'patient.lastExamDate', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'voice_forms_request',
    name: 'Forms Completion Request',
    description: 'Request patient complete pre-visit forms',
    category: 'forms_completion',
    channel: 'voice',
    voiceSettings: {
      tone: 'friendly',
      pace: 'normal',
      allowInterruption: true,
      maxRetries: 2,
    },
    greeting: "Hello, this is {office.name} calling for {patient.firstName}.",
    mainScript: "I'm calling about your upcoming appointment on {appointment.date}. We have some forms that need to be completed before your visit. You can fill them out online, or arrive about 20 minutes early to complete them in office. Would you like me to send you the link to complete them online?",
    closingScript: "Perfect! If you have any trouble with the forms, just give us a call at {office.phone}. We look forward to seeing you on {appointment.date}!",
    conditionalScripts: {
      onConfirm: "Great! We'll send a link to your phone or email. The forms only take about 5-10 minutes to complete.",
      onReschedule: "No problem. Would you prefer to complete them when you arrive? Just plan to come about 20 minutes early.",
      onVoicemail: "Hello {patient.firstName}, this is {office.name}. We're calling about forms needed for your appointment on {appointment.date}. Please visit our website or call us at {office.phone} to complete them before your visit. Thank you!",
    },
    mergeFields: ['patient.firstName', 'office.name', 'appointment.date', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'voice_welcome_new',
    name: 'Welcome New Patient',
    description: 'Welcome call to new patients',
    category: 'welcome_new_patient',
    channel: 'voice',
    voiceSettings: {
      tone: 'friendly',
      pace: 'normal',
      allowInterruption: true,
      maxRetries: 2,
    },
    greeting: "Hello, is this {patient.firstName}? This is calling from {office.name}.",
    mainScript: "I'm calling to welcome you as a new patient and let you know we're excited to meet you at your upcoming appointment on {appointment.date} at {appointment.time}. Do you have any questions I can help answer before your visit?",
    closingScript: "Wonderful! We're located at {office.address}. Please arrive about 15 minutes early and bring your insurance card and photo ID. See you soon!",
    conditionalScripts: {
      onConfirm: "Great! Is there anything specific you'd like {provider.name} to focus on during your exam?",
      onQuestion: "I'd be happy to help with that. What would you like to know?",
      onVoicemail: "Hello {patient.firstName}, this is {office.name} calling to welcome you as a new patient! We look forward to meeting you at your appointment on {appointment.date} at {appointment.time}. If you have any questions, please call us at {office.phone}. See you soon!",
    },
    mergeFields: ['patient.firstName', 'office.name', 'appointment.date', 'appointment.time', 'provider.name', 'office.address', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'voice_benefits_expiring',
    name: 'Insurance Benefits Expiring',
    description: 'Remind patients their benefits are expiring',
    category: 'insurance_benefits',
    channel: 'voice',
    voiceSettings: {
      tone: 'friendly',
      pace: 'normal',
      allowInterruption: true,
      maxRetries: 3,
    },
    greeting: "Hello, may I speak with {patient.firstName}? This is calling from {office.name}.",
    mainScript: "I'm reaching out with some important information about your vision benefits. According to our records, your {insurance.name} benefits will expire on {insurance.expirationDate}, and you still have {insurance.benefitsRemaining} in unused benefits. Would you like to schedule an appointment to use those before they expire?",
    closingScript: "Great decision! Taking advantage of your benefits is a smart choice. Is there anything else I can help you with today?",
    conditionalScripts: {
      onConfirm: "Wonderful! Let me help you find a convenient time. Do you have any preference for morning or afternoon appointments?",
      onQuestion: "That's a good question. I can give you a general overview, or if you'd like detailed benefits information, I can transfer you to our insurance specialist.",
      onVoicemail: "Hello {patient.firstName}, this is {office.name} with an important reminder. Your {insurance.name} vision benefits of {insurance.benefitsRemaining} will expire on {insurance.expirationDate}. Don't let them go to waste! Call us at {office.phone} to schedule your appointment. Thank you!",
    },
    mergeFields: ['patient.firstName', 'office.name', 'insurance.name', 'insurance.expirationDate', 'insurance.benefitsRemaining', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'voice_post_visit',
    name: 'Post-Visit Follow-up',
    description: 'Follow up after patient visit',
    category: 'post_visit_followup',
    channel: 'voice',
    voiceSettings: {
      tone: 'empathetic',
      pace: 'normal',
      allowInterruption: true,
      maxRetries: 2,
    },
    greeting: "Hello, is this {patient.firstName}? This is calling from {office.name}.",
    mainScript: "I'm calling to follow up on your recent visit with {provider.name}. How are you feeling? Is everything going well with your new prescription or treatment?",
    closingScript: "Thank you for the feedback! If you have any concerns or questions, don't hesitate to call us at {office.phone}. Take care!",
    conditionalScripts: {
      onConfirm: "That's wonderful to hear! We're glad everything is working well for you.",
      onQuestion: "I'm sorry to hear you're having some concerns. Let me see how I can help, or I can have {provider.name}'s team call you back.",
      onVoicemail: "Hello {patient.firstName}, this is {office.name} calling to check in after your recent visit. We hope everything is going well! If you have any questions or concerns, please give us a call at {office.phone}. Have a great day!",
    },
    mergeFields: ['patient.firstName', 'office.name', 'provider.name', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  
  // ============================================
  // SMS TEMPLATES
  // ============================================
  {
    id: 'sms_appt_confirm_1',
    name: 'Appointment Confirmation',
    description: 'Confirm upcoming appointment via SMS',
    category: 'appointment_confirmation',
    channel: 'sms',
    greeting: '',
    mainScript: "Hi {patient.firstName}! This is {office.name}. Your appointment is scheduled for {appointment.date} at {appointment.time} with {provider.name}. Reply YES to confirm or CHANGE to reschedule.",
    closingScript: '',
    mergeFields: ['patient.firstName', 'office.name', 'appointment.date', 'appointment.time', 'provider.name'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'sms_appt_reminder_24hr',
    name: 'Appointment Reminder - 24 Hour',
    description: 'Reminder 24 hours before appointment',
    category: 'appointment_reminder',
    channel: 'sms',
    greeting: '',
    mainScript: "Reminder: {patient.firstName}, your appointment is TOMORROW {appointment.date} at {appointment.time} with {provider.name} at {office.name}. Please arrive 15 min early. Questions? Call {office.phone}",
    closingScript: '',
    mergeFields: ['patient.firstName', 'appointment.date', 'appointment.time', 'provider.name', 'office.name', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'sms_appt_reminder_48hr',
    name: 'Appointment Reminder - 48 Hour',
    description: 'Reminder 48 hours before appointment',
    category: 'appointment_reminder',
    channel: 'sms',
    greeting: '',
    mainScript: "Hi {patient.firstName}! Just a friendly reminder about your appointment in 2 days on {appointment.date} at {appointment.time}. See you at {office.name}! Reply CONFIRM or call {office.phone} to change.",
    closingScript: '',
    mergeFields: ['patient.firstName', 'appointment.date', 'appointment.time', 'office.name', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'sms_insurance_verify',
    name: 'Insurance Verification Request',
    description: 'Request insurance verification via SMS',
    category: 'insurance_verification',
    channel: 'sms',
    greeting: '',
    mainScript: "Hi {patient.firstName}, {office.name} here. We need to verify your insurance before your {appointment.date} appt. Please call us at {office.phone} or reply with your current insurance info. Thanks!",
    closingScript: '',
    mergeFields: ['patient.firstName', 'office.name', 'appointment.date', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'sms_forms_link',
    name: 'Pre-Visit Forms Link',
    description: 'Send link to complete pre-visit forms',
    category: 'forms_completion',
    channel: 'sms',
    greeting: '',
    mainScript: "Hi {patient.firstName}! Please complete your pre-visit forms before your {appointment.date} appointment. Click here: {custom.link} - Takes only 5 min! Questions? {office.phone}",
    closingScript: '',
    mergeFields: ['patient.firstName', 'appointment.date', 'custom.link', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'sms_rx_ready',
    name: 'Prescription Ready',
    description: 'Notify prescription/order is ready for pickup',
    category: 'prescription_ready',
    channel: 'sms',
    greeting: '',
    mainScript: "Great news {patient.firstName}! Your {order.type} is ready for pickup at {office.name}. We're open {office.hours}. See you soon!",
    closingScript: '',
    mergeFields: ['patient.firstName', 'order.type', 'office.name', 'office.hours'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'sms_recall_due',
    name: 'Recall - Due for Exam',
    description: 'Notify patient they are due for annual exam',
    category: 'recall_outreach',
    channel: 'sms',
    greeting: '',
    mainScript: "Hi {patient.firstName}! It's been a year since your last eye exam at {office.name}. Time for your annual checkup! Call {office.phone} or reply SCHEDULE to book. Your vision is important!",
    closingScript: '',
    mergeFields: ['patient.firstName', 'office.name', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'sms_benefits_expiring',
    name: 'Benefits Expiring Soon',
    description: 'Alert patient their benefits expire soon',
    category: 'insurance_benefits',
    channel: 'sms',
    greeting: '',
    mainScript: "Hi {patient.firstName}! Your {insurance.name} benefits ({insurance.benefitsRemaining} remaining) expire {insurance.expirationDate}. Don't lose them! Call {office.phone} to schedule before year end.",
    closingScript: '',
    mergeFields: ['patient.firstName', 'insurance.name', 'insurance.benefitsRemaining', 'insurance.expirationDate', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'sms_balance_due',
    name: 'Balance Due Reminder',
    description: 'Remind patient of outstanding balance',
    category: 'balance_due',
    channel: 'sms',
    greeting: '',
    mainScript: "Hi {patient.firstName}, this is {office.name}. You have an outstanding balance of {order.balanceDue}. Please call {office.phone} to make a payment or discuss options. Thank you!",
    closingScript: '',
    mergeFields: ['patient.firstName', 'office.name', 'order.balanceDue', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'sms_welcome_new',
    name: 'Welcome New Patient',
    description: 'Welcome message for new patients',
    category: 'welcome_new_patient',
    channel: 'sms',
    greeting: '',
    mainScript: "Welcome to {office.name}, {patient.firstName}! We're excited to see you on {appointment.date} at {appointment.time}. Please arrive 15 min early & bring your insurance card. See you soon!",
    closingScript: '',
    mergeFields: ['patient.firstName', 'office.name', 'appointment.date', 'appointment.time'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'sms_post_visit',
    name: 'Post-Visit Follow-up',
    description: 'Follow up after patient visit',
    category: 'post_visit_followup',
    channel: 'sms',
    greeting: '',
    mainScript: "Hi {patient.firstName}! Thank you for visiting {office.name}. How was your experience? Any questions about your visit? Reply or call {office.phone}. We appreciate you!",
    closingScript: '',
    mergeFields: ['patient.firstName', 'office.name', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'sms_order_status',
    name: 'Order Status Update',
    description: 'Update on order status',
    category: 'order_status',
    channel: 'sms',
    greeting: '',
    mainScript: "Hi {patient.firstName}! Update on your {order.type} order #{order.number}: {order.status}. Estimated ready: {order.estimatedDate}. Questions? Call {office.phone}",
    closingScript: '',
    mergeFields: ['patient.firstName', 'order.type', 'order.number', 'order.status', 'order.estimatedDate', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },

  // ============================================
  // EMAIL TEMPLATES
  // ============================================
  {
    id: 'email_appt_confirm',
    name: 'Appointment Confirmation',
    description: 'Confirm upcoming appointment via email',
    category: 'appointment_confirmation',
    channel: 'email',
    greeting: 'Dear {patient.firstName},',
    mainScript: `Thank you for scheduling your appointment at {office.name}!

**Appointment Details:**
- **Date:** {appointment.date}
- **Time:** {appointment.time}
- **Provider:** {provider.name}
- **Location:** {office.fullAddress}

Please arrive 15 minutes early to complete any necessary paperwork. Don't forget to bring:
- Your insurance card
- Photo ID
- Any current eyewear

If you need to reschedule, please call us at {office.phone} or reply to this email.`,
    closingScript: `We look forward to seeing you!

Best regards,
{office.name}
{office.phone}
{office.website}`,
    mergeFields: ['patient.firstName', 'office.name', 'appointment.date', 'appointment.time', 'provider.name', 'office.fullAddress', 'office.phone', 'office.website'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'email_appt_reminder',
    name: 'Appointment Reminder',
    description: 'Reminder email before appointment',
    category: 'appointment_reminder',
    channel: 'email',
    greeting: 'Dear {patient.firstName},',
    mainScript: `This is a friendly reminder about your upcoming appointment.

**Appointment Details:**
- **Date:** {appointment.date}
- **Time:** {appointment.time}
- **Provider:** {provider.name}
- **Location:** {office.name}

**What to Bring:**
- Insurance card
- Photo ID
- List of current medications
- Any changes to your health history

Please arrive 15 minutes before your scheduled time.`,
    closingScript: `If you need to reschedule, please contact us as soon as possible at {office.phone}.

See you soon!
{office.name}`,
    mergeFields: ['patient.firstName', 'appointment.date', 'appointment.time', 'provider.name', 'office.name', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'email_insurance_verify',
    name: 'Insurance Verification Request',
    description: 'Request to verify insurance information',
    category: 'insurance_verification',
    channel: 'email',
    greeting: 'Dear {patient.firstName},',
    mainScript: `We're reaching out regarding your upcoming appointment on {appointment.date} at {office.name}.

To ensure a smooth visit, we need to verify your insurance information. Our records show:
- **Insurance:** {insurance.name}
- **Plan:** {insurance.planName}
- **Member ID:** {insurance.memberId}

**Please confirm this information is current**, or provide updated details by:
- Replying to this email with your current insurance card (front and back)
- Calling us at {office.phone}
- Uploading through our patient portal

This helps us verify your benefits and provide accurate cost estimates before your visit.`,
    closingScript: `Thank you for your prompt attention to this matter.

Best regards,
{office.name} Insurance Team
{office.phone}`,
    mergeFields: ['patient.firstName', 'appointment.date', 'office.name', 'insurance.name', 'insurance.planName', 'insurance.memberId', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'email_forms_request',
    name: 'Pre-Visit Forms',
    description: 'Request to complete pre-visit forms online',
    category: 'forms_completion',
    channel: 'email',
    greeting: 'Dear {patient.firstName},',
    mainScript: `Your appointment at {office.name} is coming up on {appointment.date}!

To save time during your visit, please complete your pre-visit forms online. It only takes about 5-10 minutes.

**Complete Your Forms Here:** {custom.link}

These forms include:
- Patient health history
- Insurance information
- HIPAA acknowledgment
- Consent forms

Completing these ahead of time means less waiting and more time with your doctor.`,
    closingScript: `If you have any questions or need assistance, please call us at {office.phone}.

Thank you!
{office.name}`,
    mergeFields: ['patient.firstName', 'office.name', 'appointment.date', 'custom.link', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'email_rx_ready',
    name: 'Order Ready for Pickup',
    description: 'Notify that order is ready for pickup',
    category: 'prescription_ready',
    channel: 'email',
    greeting: 'Dear {patient.firstName},',
    mainScript: `Great news! Your {order.type} is ready for pickup at {office.name}.

**Order Details:**
- Order #: {order.number}
- Item: {order.type}
- Status: Ready for Pickup

**Pickup Location:**
{office.fullAddress}

**Office Hours:**
{office.hours}

Please bring a photo ID when you come to pick up your order.`,
    closingScript: `We look forward to seeing you!

{office.name}
{office.phone}`,
    mergeFields: ['patient.firstName', 'order.type', 'office.name', 'order.number', 'office.fullAddress', 'office.hours', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'email_recall_annual',
    name: 'Annual Exam Recall',
    description: 'Remind patient to schedule annual exam',
    category: 'recall_outreach',
    channel: 'email',
    greeting: 'Dear {patient.firstName},',
    mainScript: `It's time for your annual eye exam!

According to our records, your last comprehensive eye exam was on {patient.lastExamDate}. Regular eye exams are essential for:
- Maintaining clear, comfortable vision
- Early detection of eye diseases
- Updating your prescription if needed
- Overall eye health monitoring

**Schedule Your Appointment Today:**
- Call us: {office.phone}
- Visit: {office.website}
- Reply to this email

We have convenient appointment times available to fit your schedule.`,
    closingScript: `Your vision is important to us. We look forward to seeing you soon!

{provider.name} and the team at
{office.name}
{office.phone}`,
    mergeFields: ['patient.firstName', 'patient.lastExamDate', 'office.phone', 'office.website', 'provider.name', 'office.name'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'email_benefits_expiring',
    name: 'Benefits Expiring Alert',
    description: 'Alert about expiring insurance benefits',
    category: 'insurance_benefits',
    channel: 'email',
    greeting: 'Dear {patient.firstName},',
    mainScript: `**Important: Your Vision Benefits Are Expiring Soon!**

According to our records, your {insurance.name} vision benefits will expire on **{insurance.expirationDate}**.

**Your Current Benefits:**
- Remaining Balance: **{insurance.benefitsRemaining}**
- Plan: {insurance.planName}

Don't let your hard-earned benefits go to waste! These benefits do NOT roll over to next year.

**What you can use your benefits for:**
- Comprehensive eye exam
- New eyeglasses or prescription sunglasses
- Contact lenses
- Lens upgrades (progressives, transitions, etc.)

**Schedule now to use your benefits before they expire!**
Call: {office.phone}
Online: {office.website}`,
    closingScript: `Act now – appointments fill up quickly at year end!

{office.name}
{office.phone}`,
    mergeFields: ['patient.firstName', 'insurance.name', 'insurance.expirationDate', 'insurance.benefitsRemaining', 'insurance.planName', 'office.phone', 'office.website', 'office.name'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'email_balance_due',
    name: 'Balance Due Statement',
    description: 'Notify about outstanding balance',
    category: 'balance_due',
    channel: 'email',
    greeting: 'Dear {patient.firstName},',
    mainScript: `This is a friendly reminder that you have an outstanding balance on your account.

**Account Summary:**
- Balance Due: **{order.balanceDue}**
- Service Date: {patient.lastExamDate}

**Payment Options:**
- Pay online through our patient portal
- Call us at {office.phone} to pay by phone
- Mail a check to: {office.fullAddress}
- Pay in person at our office

If you have questions about your statement or need to set up a payment plan, please don't hesitate to contact us.`,
    closingScript: `Thank you for your prompt attention to this matter.

{office.name} Billing Department
{office.phone}`,
    mergeFields: ['patient.firstName', 'order.balanceDue', 'patient.lastExamDate', 'office.phone', 'office.fullAddress', 'office.name'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'email_welcome_new',
    name: 'Welcome New Patient',
    description: 'Welcome email for new patients',
    category: 'welcome_new_patient',
    channel: 'email',
    greeting: 'Dear {patient.firstName},',
    mainScript: `Welcome to {office.name}! We're delighted to have you as a new patient.

**Your First Appointment:**
- **Date:** {appointment.date}
- **Time:** {appointment.time}
- **Provider:** {provider.name}
- **Location:** {office.fullAddress}

**Before Your Visit:**
1. Complete your new patient forms online (link in separate email)
2. Gather your insurance card and photo ID
3. Make a list of any medications you take
4. Note any vision concerns or symptoms

**What to Expect:**
Your first visit will include a comprehensive eye exam where {provider.name} will assess your vision and overall eye health. Please plan for approximately 60-90 minutes.

**Directions & Parking:**
{office.fullAddress}
Free parking available on-site.`,
    closingScript: `We're looking forward to meeting you! If you have any questions before your visit, please call us at {office.phone}.

Warmly,
The Team at {office.name}`,
    mergeFields: ['patient.firstName', 'office.name', 'appointment.date', 'appointment.time', 'provider.name', 'office.fullAddress', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
  {
    id: 'email_post_visit',
    name: 'Post-Visit Thank You',
    description: 'Thank you email after visit',
    category: 'post_visit_followup',
    channel: 'email',
    greeting: 'Dear {patient.firstName},',
    mainScript: `Thank you for visiting {office.name}! We hope you had a great experience with {provider.name}.

**Your Visit Summary:**
We've attached your receipt and any relevant documents from your visit. If you ordered eyewear, we'll notify you when it's ready for pickup.

**Questions About Your Visit?**
If you have any questions about your exam, prescription, or treatment plan, please don't hesitate to reach out.

**Leave Us a Review:**
Your feedback helps us serve you better! We'd appreciate if you could share your experience:
- Google: {custom.link}

**Schedule Your Next Visit:**
Don't forget to schedule your next annual exam to maintain your eye health.`,
    closingScript: `Thank you for trusting us with your eye care!

Best regards,
{provider.name} and the team at
{office.name}
{office.phone}`,
    mergeFields: ['patient.firstName', 'office.name', 'provider.name', 'custom.link', 'office.phone'],
    isActive: true,
    isDefault: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
  },
];

class VoiceTemplateServiceClass {
  private storageKey = 'voiceTemplates';

  getTemplates(): VoiceTemplate[] {
    const stored = localStorage.getItem(this.storageKey);
    if (stored) {
      return JSON.parse(stored);
    }
    // Initialize with defaults
    this.saveTemplates(DEFAULT_VOICE_TEMPLATES);
    return DEFAULT_VOICE_TEMPLATES;
  }

  saveTemplates(templates: VoiceTemplate[]): void {
    localStorage.setItem(this.storageKey, JSON.stringify(templates));
  }

  getTemplateById(id: string): VoiceTemplate | undefined {
    return this.getTemplates().find(t => t.id === id);
  }

  getTemplatesByCategory(category: TemplateCategory): VoiceTemplate[] {
    return this.getTemplates().filter(t => t.category === category && t.isActive);
  }

  getTemplatesByChannel(channel: TemplateChannel): VoiceTemplate[] {
    return this.getTemplates().filter(t => t.channel === channel && t.isActive);
  }

  getActiveTemplates(): VoiceTemplate[] {
    return this.getTemplates().filter(t => t.isActive);
  }

  createTemplate(template: Omit<VoiceTemplate, 'id' | 'createdAt' | 'updatedAt' | 'version'>): VoiceTemplate {
    const newTemplate: VoiceTemplate = {
      ...template,
      id: `voice_custom_${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      version: 1,
    };
    const templates = this.getTemplates();
    templates.push(newTemplate);
    this.saveTemplates(templates);
    return newTemplate;
  }

  updateTemplate(id: string, updates: Partial<VoiceTemplate>): VoiceTemplate | null {
    const templates = this.getTemplates();
    const index = templates.findIndex(t => t.id === id);
    if (index === -1) return null;

    templates[index] = {
      ...templates[index],
      ...updates,
      updatedAt: new Date().toISOString(),
      version: templates[index].version + 1,
    };
    this.saveTemplates(templates);
    return templates[index];
  }

  deleteTemplate(id: string): boolean {
    const templates = this.getTemplates();
    const filtered = templates.filter(t => t.id !== id);
    if (filtered.length === templates.length) return false;
    this.saveTemplates(filtered);
    return true;
  }

  duplicateTemplate(id: string, newName?: string): VoiceTemplate | null {
    const original = this.getTemplateById(id);
    if (!original) return null;

    const duplicate: VoiceTemplate = {
      ...original,
      id: `voice_custom_${Date.now()}`,
      name: newName || `${original.name} (Copy)`,
      isDefault: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      version: 1,
    };
    const templates = this.getTemplates();
    templates.push(duplicate);
    this.saveTemplates(templates);
    return duplicate;
  }

  // Apply merge fields to template content
  applyMergeFields(content: string, data: Record<string, any>): string {
    let result = content;

    // Find all merge fields in the content and replace with values
    const fieldPattern = /\{([^}]+)\}/g;
    let match;

    while ((match = fieldPattern.exec(content)) !== null) {
      const field = match[1];
      const value = this.getNestedValue(data, field);
      if (value !== undefined && value !== null && String(value).trim() !== '') {
        result = result.replace(new RegExp(`\\{${field}\\}`, 'g'), String(value));
      }
    }

    // Remove any remaining unresolved merge fields so they aren't spoken aloud
    result = result.replace(/\{[^}]+\}/g, '');
    // Clean up double spaces and leading/trailing whitespace
    result = result.replace(/\s{2,}/g, ' ').trim();

    return result;
  }

  private getNestedValue(obj: Record<string, any>, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }

  // Get all merge fields used in a template
  extractMergeFields(template: VoiceTemplate): string[] {
    const allContent = [
      template.greeting,
      template.mainScript,
      template.closingScript,
      ...(template.conditionalScripts ? Object.values(template.conditionalScripts) : []),
    ].join(' ');

    const fieldPattern = /\{([^}]+)\}/g;
    const fields = new Set<string>();
    let match;
    
    while ((match = fieldPattern.exec(allContent)) !== null) {
      fields.add(match[1]);
    }
    
    return Array.from(fields);
  }

  // Generate full script from template with data
  generateScript(templateId: string, data: Record<string, any>): {
    greeting: string;
    mainScript: string;
    closingScript: string;
    conditionalScripts?: Record<string, string>;
  } | null {
    const template = this.getTemplateById(templateId);
    if (!template) return null;

    return {
      greeting: this.applyMergeFields(template.greeting, data),
      mainScript: this.applyMergeFields(template.mainScript, data),
      closingScript: this.applyMergeFields(template.closingScript, data),
      conditionalScripts: template.conditionalScripts ? 
        Object.fromEntries(
          Object.entries(template.conditionalScripts).map(([key, value]) => [
            key,
            this.applyMergeFields(value || '', data),
          ])
        ) : undefined,
    };
  }

  // Get merge field definitions by category
  getMergeFieldsByCategory(category: MergeFieldDefinition['category']): MergeFieldDefinition[] {
    return MERGE_FIELD_DEFINITIONS.filter(f => f.category === category);
  }

  // Get all merge field definitions
  getAllMergeFields(): MergeFieldDefinition[] {
    return MERGE_FIELD_DEFINITIONS;
  }

  // Reset to default templates
  resetToDefaults(): void {
    this.saveTemplates(DEFAULT_VOICE_TEMPLATES);
  }
}

export const VoiceTemplateService = new VoiceTemplateServiceClass();
export default VoiceTemplateService;
