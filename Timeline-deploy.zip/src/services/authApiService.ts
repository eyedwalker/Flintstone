/**
 * Auth API Service
 * Client-side service for interacting with the Vercel KV-backed auth API
 */

const API_BASE = '/api/auth';

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: 'admin' | 'manager' | 'associate';
  mfaEnabled: boolean;
  mustChangePassword?: boolean;
}

export interface Session {
  id: string;
  token: string;
  refreshToken: string;
  expiresAt: string;
}

export interface AuthResult {
  success: boolean;
  error?: string;
  requiresMfa?: boolean;
  mfaToken?: string;
  user?: User;
  session?: Session;
}

export interface Invite {
  id: string;
  token?: string;
  email: string;
  role: 'admin' | 'manager' | 'associate';
  status: 'pending' | 'used' | 'expired' | 'revoked';
  invitedBy?: string;
  invitedByName?: string;
  createdAt: string;
  expiresAt: string;
  usedAt?: string;
  inviteUrl?: string;
}

class AuthApiServiceClass {
  private getAuthHeader(): HeadersInit {
    const session = this.getStoredSession();
    if (session?.token) {
      return {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.token}`
      };
    }
    return { 'Content-Type': 'application/json' };
  }

  private getStoredSession(): Session | null {
    const stored = localStorage.getItem('auth_session');
    return stored ? JSON.parse(stored) : null;
  }

  private storeSession(session: Session): void {
    localStorage.setItem('auth_session', JSON.stringify(session));
  }

  private clearSession(): void {
    localStorage.removeItem('auth_session');
    localStorage.removeItem('currentUser');
  }

  // ============================================
  // INITIALIZATION
  // ============================================

  async checkInitialized(): Promise<{ initialized: boolean; userCount: number }> {
    try {
      const response = await fetch(`${API_BASE}/init`);
      return await response.json();
    } catch (error) {
      console.error('[AuthAPI] Init check error:', error);
      return { initialized: false, userCount: 0 };
    }
  }

  async initializeAdmin(): Promise<{ success: boolean; credentials?: { email: string; password: string }; error?: string }> {
    try {
      const response = await fetch(`${API_BASE}/init`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      return await response.json();
    } catch (error) {
      console.error('[AuthAPI] Init error:', error);
      return { success: false, error: 'Failed to initialize' };
    }
  }

  // ============================================
  // LOGIN / LOGOUT
  // ============================================

  async login(email: string, password: string): Promise<AuthResult> {
    try {
      const response = await fetch(`${API_BASE}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      const result = await response.json();

      if (result.success && result.session) {
        this.storeSession(result.session);
        localStorage.setItem('currentUser', JSON.stringify({
          ...result.user,
          name: `${result.user.firstName} ${result.user.lastName}`,
          username: result.user.email
        }));
      }

      return result;
    } catch (error) {
      console.error('[AuthAPI] Login error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  async verifyMfa(mfaToken: string, code: string): Promise<AuthResult> {
    try {
      const response = await fetch(`${API_BASE}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mfaToken, mfaCode: code })
      });

      const result = await response.json();

      if (result.success && result.session) {
        this.storeSession(result.session);
        localStorage.setItem('currentUser', JSON.stringify({
          ...result.user,
          name: `${result.user.firstName} ${result.user.lastName}`,
          username: result.user.email
        }));
      }

      return result;
    } catch (error) {
      console.error('[AuthAPI] MFA verify error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  async logout(): Promise<void> {
    try {
      await fetch(`${API_BASE}/session`, {
        method: 'DELETE',
        headers: this.getAuthHeader()
      });
    } catch (error) {
      console.error('[AuthAPI] Logout error:', error);
    } finally {
      this.clearSession();
    }
  }

  // ============================================
  // SESSION
  // ============================================

  async validateSession(): Promise<{ valid: boolean; user?: User; session?: { id: string; expiresAt: string } }> {
    const session = this.getStoredSession();
    if (!session?.token) {
      return { valid: false };
    }

    try {
      const response = await fetch(`${API_BASE}/session`, {
        headers: this.getAuthHeader()
      });

      const result = await response.json();
      
      if (!result.valid) {
        this.clearSession();
      }

      return result;
    } catch (error) {
      console.error('[AuthAPI] Session validation error:', error);
      return { valid: false };
    }
  }

  async refreshSession(): Promise<AuthResult> {
    const session = this.getStoredSession();
    if (!session?.refreshToken) {
      return { success: false, error: 'No refresh token' };
    }

    try {
      const response = await fetch(`${API_BASE}/session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken: session.refreshToken })
      });

      const result = await response.json();

      if (result.success && result.session) {
        this.storeSession(result.session);
        localStorage.setItem('currentUser', JSON.stringify({
          ...result.user,
          name: `${result.user.firstName} ${result.user.lastName}`,
          username: result.user.email
        }));
      } else {
        this.clearSession();
      }

      return result;
    } catch (error) {
      console.error('[AuthAPI] Session refresh error:', error);
      this.clearSession();
      return { success: false, error: 'Failed to refresh session' };
    }
  }

  // ============================================
  // REGISTRATION
  // ============================================

  async register(data: {
    inviteToken: string;
    email: string;
    firstName: string;
    lastName: string;
    password: string;
    confirmPassword: string;
  }): Promise<AuthResult> {
    try {
      const response = await fetch(`${API_BASE}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      return await response.json();
    } catch (error) {
      console.error('[AuthAPI] Register error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  // ============================================
  // INVITES
  // ============================================

  async validateInvite(token: string): Promise<{ valid: boolean; invite?: Invite; error?: string }> {
    try {
      const response = await fetch(`${API_BASE}/invite?token=${encodeURIComponent(token)}`);
      return await response.json();
    } catch (error) {
      console.error('[AuthAPI] Validate invite error:', error);
      return { valid: false, error: 'Network error' };
    }
  }

  async listInvites(): Promise<{ invites: Invite[] }> {
    try {
      const response = await fetch(`${API_BASE}/invite`, {
        headers: this.getAuthHeader()
      });
      return await response.json();
    } catch (error) {
      console.error('[AuthAPI] List invites error:', error);
      return { invites: [] };
    }
  }

  async createInvite(email: string, role: 'admin' | 'manager' | 'associate', expirationDays: number = 7): Promise<{ success: boolean; invite?: Invite; error?: string }> {
    try {
      const response = await fetch(`${API_BASE}/invite`, {
        method: 'POST',
        headers: this.getAuthHeader(),
        body: JSON.stringify({ email, role, expirationDays })
      });
      return await response.json();
    } catch (error) {
      console.error('[AuthAPI] Create invite error:', error);
      return { success: false, error: 'Network error' };
    }
  }

  async revokeInvite(token: string): Promise<{ success: boolean; error?: string }> {
    try {
      const response = await fetch(`${API_BASE}/invite?token=${encodeURIComponent(token)}`, {
        method: 'DELETE',
        headers: this.getAuthHeader()
      });
      return await response.json();
    } catch (error) {
      console.error('[AuthAPI] Revoke invite error:', error);
      return { success: false, error: 'Network error' };
    }
  }

  // ============================================
  // USERS (Admin)
  // ============================================

  async listUsers(): Promise<{ users: User[] }> {
    try {
      const response = await fetch(`${API_BASE}/users`, {
        headers: this.getAuthHeader()
      });
      return await response.json();
    } catch (error) {
      console.error('[AuthAPI] List users error:', error);
      return { users: [] };
    }
  }

  async updateUserRole(email: string, role: 'admin' | 'manager' | 'associate'): Promise<{ success: boolean; error?: string }> {
    try {
      const response = await fetch(`${API_BASE}/users?email=${encodeURIComponent(email)}`, {
        method: 'PUT',
        headers: this.getAuthHeader(),
        body: JSON.stringify({ role })
      });
      return await response.json();
    } catch (error) {
      console.error('[AuthAPI] Update user role error:', error);
      return { success: false, error: 'Network error' };
    }
  }

  async resetUserPassword(email: string): Promise<{ success: boolean; temporaryPassword?: string; error?: string }> {
    try {
      const response = await fetch(`${API_BASE}/users?email=${encodeURIComponent(email)}`, {
        method: 'PUT',
        headers: this.getAuthHeader(),
        body: JSON.stringify({ resetPassword: true })
      });
      return await response.json();
    } catch (error) {
      console.error('[AuthAPI] Reset password error:', error);
      return { success: false, error: 'Network error' };
    }
  }

  async deleteUser(email: string): Promise<{ success: boolean; error?: string }> {
    try {
      const response = await fetch(`${API_BASE}/users?email=${encodeURIComponent(email)}`, {
        method: 'DELETE',
        headers: this.getAuthHeader()
      });
      return await response.json();
    } catch (error) {
      console.error('[AuthAPI] Delete user error:', error);
      return { success: false, error: 'Network error' };
    }
  }

  // ============================================
  // PASSWORD VALIDATION (Client-side)
  // ============================================

  validatePassword(password: string): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    
    if (password.length < 12) {
      errors.push('Password must be at least 12 characters');
    }
    if (!/[a-z]/.test(password)) {
      errors.push('Password must contain at least one lowercase letter');
    }
    if (!/[A-Z]/.test(password)) {
      errors.push('Password must contain at least one uppercase letter');
    }
    if (!/\d/.test(password)) {
      errors.push('Password must contain at least one number');
    }
    if (!/[@$!%*?&]/.test(password)) {
      errors.push('Password must contain at least one special character (@$!%*?&)');
    }
    
    return { valid: errors.length === 0, errors };
  }
}

export const AuthApiService = new AuthApiServiceClass();
export default AuthApiService;
