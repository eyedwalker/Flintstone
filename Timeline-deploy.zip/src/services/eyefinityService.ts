/// <reference types="vite/client" />
/**
 * Eyefinity API Service - v2 Endpoints
 * Provides comprehensive integration with Eyefinity Practice Management API
 */

import DemoModeService from './demoModeService';

export interface EyefinityConfig {
  accessToken: string;
  baseUrl?: string;
  officeId?: string;
  tenantId?: string;
}

export interface Office {
  id: string;
  officeId: string;
  officeName: string;
  address?: string;
  phone?: string;
  guid?: string;
}

export interface Provider {
  id: string;
  staffId: string;
  firstName: string;
  lastName: string;
  fullName: string;
  providerType?: string;
  guid?: string;
  officeId?: string;
}

export interface PatientAddress {
  patientId: string;
  patientAddressId: number;
  address: string;
  address2?: string;
  city: string;
  state: string;
  zipCode: string;
  country?: string;
  isPrimary: boolean;
  addressType: string;
}

export interface PatientPhone {
  patientId: string;
  phoneId: number;
  number: string;
  isPrimary: boolean;
  type: string;
  whenToCall?: string;
  isBadPhone: boolean;
}

export interface PatientInsurance {
  patientId: string;
  insuranceId: number;
  patientInsuranceUid: string;
  companyName: string;
  planName: string;
  isPrimary: boolean;
  coverageType: string;
  planType: string;
  insuranceIdentificationNumber: string;
  isActive: boolean;
}

export interface Patient {
  id: string;
  patientId: string;
  PatientLegacyId?: number; // Legacy integer patient ID for popup URLs
  PatientId?: string; // Original GUID patient ID from API
  firstName: string;
  lastName: string;
  middleInitial?: string;
  fullName: string;
  preferredName?: string;
  title?: string;
  gender?: string;
  dob?: string;
  age?: number;
  phone?: string;
  mobilePhone?: string;
  homePhone?: string;
  email?: string;
  isBadEmail?: boolean;
  homeOffice?: number;
  examOffice?: number;
  primaryProviderId?: number;
  preferredLanguage?: string;
  communicationPreference?: string;
  occupation?: string;
  isInactive?: boolean;
  isDeceased?: boolean;
  emailDeclinedToShare?: boolean;
  emailRecall?: boolean;
  emailPromotion?: boolean;
  sendOrderNotificationsViaText?: boolean;
  sendOrderNotificationsViaEmail?: boolean;
  sendApptNotificationsViaText?: boolean;
  sendApptNotificationsViaEmail?: boolean;
  firstVisit?: string;
  lastVisit?: string;
  lastExamDate?: string;
  nextRecallDate?: string;
  nextRecallReason?: string;
  addresses?: PatientAddress[];
  phoneNumbers?: PatientPhone[];
  insurances?: PatientInsurance[];
  emrPatientNum?: string;
  patientUid?: string;
  hipaaSignatureDate?: string;
  hipaaSignatureIsOnFile?: boolean;
  medicalRecordNum?: string;
  officeId?: string;
  providerId?: string;
}

export interface AppointmentSlot {
  date: string;
  startTime: string;
  endTime: string;
  providerId: string;
  providerName: string;
  officeId: string;
  duration: number;
  available: boolean;
}

// Schedule Manager POST /offices/{officeId}/appointmentSlots request body
export interface BulkSlotSearchRequest {
  StartDate: string;             // yyyy-mm-dd or yyyy-mm-ddThh:mm:ss
  EndDate: string;               // yyyy-mm-dd or yyyy-mm-ddThh:mm:ss
  AppointmentDuration: number;   // 0 = use system default
  IncludeNiceTimes: boolean;     // round to 15-min increments
  RestrictServiceItemSlots: boolean;
  ResourceIds?: string[];        // provider/staff GUIDs
  ServiceCatalogItemId?: string; // appointment type UUID
  StartHour?: number;            // 0-23
  EndHour?: number;              // 0-23
  DaysOfWeek?: number[];         // 0=Sun..6=Sat
}

export interface BulkSlotResponse {
  slotId?: string;
  date: string;
  startTime: string;
  endTime: string;
  providerId: string;
  providerName: string;
  officeId: string;
  duration?: number;
  appointmentTypeId?: number;
}

export interface AppointmentNote {
  id: number;
  date: string;
  detail: string;
  noteType: number;
  isUrgent: boolean;
  isFollowUp: boolean;
  entityId: number;
}

export interface Appointment {
  id: string;
  appointmentId: string;
  appointmentTypeId?: number;
  appointmentTypeName?: string;
  appointmentTypeUid?: string;
  patientId: string;
  patientLegacyId?: number;
  patientName: string;
  patientFirstName?: string;
  patientLastName?: string;
  providerId: string;
  providerName: string;
  providerFirstName?: string;
  providerLastName?: string;
  officeId: string;
  date: string;
  startTime: string;
  endTime: string;
  appointmentType: string;
  status: string;
  showStatus?: string;
  confirmedIndicator?: string;
  reason?: string;
  notes?: AppointmentNote[];
  isUrgent?: boolean;
  isDeleted?: boolean;
  cancelIndicator?: boolean;
  isPreAppointment?: boolean;
  appointmentCreatedDate?: string;
  appointmentLastChangedDate?: string;
  statusLastChangedDate?: string;
  appointmentExternalId?: string;
  patientInsuranceUid?: string;
  patientMedicalInsuranceUid?: string;
}

export interface CreateAppointmentPayload {
  PatientId: string;
  OfficeId: string;
  StaffId: string;
  AppointmentDate: string;
  AppointmentStartTime: string;
  AppointmentEndTime: string;
  AppointmentTypeId: number;
  AppointmentReason?: string;
  CancelIndicator?: boolean;
  Notes?: string[];
}

export interface PaginatedResponse<T> {
  items: T[];
  page: number;
  pageSize: number;
  totalCount: number;
  totalPages: number;
}

export class EyefinityService {
  // Active company ID — set by CompanyContext so all API calls route to the right tenant
  private static _activeCompanyId: string | null = null;

  static setActiveCompanyId(id: string | null) {
    this._activeCompanyId = id;
  }

  // No longer needed - proxy handles all authentication
  // Keeping method for backward compatibility but it's not used
  private static getConfig(): EyefinityConfig {
    return {
      accessToken: '', // Not used - proxy handles auth
      baseUrl: '/api/eyefinity',
      officeId: import.meta.env.VITE_DEFAULT_OFFICE_ID || '936',
    };
  }

  private static getHeaders(companyId?: string): Record<string, string> {
    // Proxy handles OAuth authentication internally - no client-side token needed
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    // Add company ID for multi-tenant support (explicit param > static default)
    const resolvedCompanyId = companyId || this._activeCompanyId;
    if (resolvedCompanyId) {
      headers['X-Company-Id'] = resolvedCompanyId;
    }

    return headers;
  }

  // ============================================
  // OFFICES - v2 Endpoints (GUID-based)
  // ============================================

  static async getOffices(page = 1, pageSize = 100, companyId?: string): Promise<PaginatedResponse<Office>> {
    console.log('[EyefinityService] Fetching v2 offices');
    
    const params = new URLSearchParams({
      page: page.toString(),
      pageSize: pageSize.toString(),
    });

    const response = await fetch(`/api/eyefinity/v2offices?${params}`, {
      headers: this.getHeaders(companyId),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to fetch offices: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    console.log('[EyefinityService] Raw offices response:', data);
    
    // Handle both array response and paginated response with items property
    const rawItems = Array.isArray(data) ? data : (data.items || data.Items || []);
    
    // Map v2 API response fields to Office interface
    // PE API returns OfficeId as the GUID and OfficeNumber as the human-readable ID
    const mappedItems = rawItems.map((item: Record<string, unknown>) => ({
      id: item.OfficeGuid || item.OfficeId || item.OfficeNumber || item.Id || item.id,
      officeId: String(item.OfficeNumber || item.officeId || ''),
      officeName: item.OfficeName || item.Name || item.name || `Office ${item.OfficeNumber}`,
      address: item.Address1 || item.Address || item.address,
      phone: item.PhoneNumber || item.Phone || item.phone,
      guid: item.OfficeGuid || item.OfficeId || item.Guid || item.guid,
    }));
    
    console.log('[EyefinityService] Mapped offices:', mappedItems.length, mappedItems.slice(0, 2));
    
    return {
      items: mappedItems,
      page: data.page || data.Page || 1,
      pageSize: data.pageSize || data.PageSize || mappedItems.length,
      totalCount: data.totalCount || data.TotalCount || mappedItems.length,
      totalPages: data.totalPages || data.TotalPages || 1,
    };
  }

  static async getOfficeById(officeGuid: string): Promise<Office> {
    console.log('[EyefinityService] Fetching office by GUID:', officeGuid);

    const response = await fetch(`/api/eyefinity/v2offices/${officeGuid}`, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch office: ${response.status}`);
    }

    return response.json();
  }

  // ============================================
  // PROVIDERS/STAFF - v2 Endpoints (GUID-based)
  // ============================================

  static async getProviders(options: {
    officeId?: string;
    page?: number;
    pageSize?: number;
  } = {}): Promise<PaginatedResponse<Provider>> {
    const { officeId, page = 1, pageSize = 50 } = options;
    console.log('[EyefinityService] Fetching v2 providers');

    const params = new URLSearchParams({
      page: page.toString(),
      pageSize: pageSize.toString(),
    });

    if (officeId) {
      params.append('officeId', officeId);
    }

    const response = await fetch(`/api/eyefinity/v2staff?${params}`, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch providers: ${response.status}`);
    }

    const data = await response.json();

    // Handle both array response and paginated response with items property
    const rawItems = Array.isArray(data) ? data : (data.items || data.Items || []);

    // Map v2 API response fields to Provider interface
    const mappedItems = rawItems.map((item: Record<string, unknown>) => ({
      id: (item.StaffId || item.staffId || item.id || '') as string,
      staffId: (item.StaffId || item.staffId || '') as string,
      firstName: (item.FirstName || item.firstName || '') as string,
      lastName: (item.LastName || item.lastName || '') as string,
      fullName: item.FirstName && item.LastName
        ? `${item.FirstName} ${item.LastName}`
        : (item.fullName || item.FullName || `${item.FirstName || ''} ${item.LastName || ''}`.trim() || 'Unknown') as string,
      guid: (item.StaffId || item.Guid || item.guid || '') as string,
      officeId: (item.CompanyLegacyId || item.OfficeId || item.officeId || '') as string,
      providerType: (item.ProviderType || item.providerType || '') as string,
      isActive: item.IsActive ?? item.isActive ?? true,
      allowToBeScheduled: item.AllowToBeScheduled ?? item.allowToBeScheduled ?? true,
    }));

    console.log('[EyefinityService] Providers fetched:', mappedItems.length);

    return {
      items: mappedItems,
      page: data.page || data.Page || page,
      pageSize: data.pageSize || data.PageSize || mappedItems.length,
      totalCount: data.totalCount || data.TotalCount || mappedItems.length,
      totalPages: data.totalPages || data.TotalPages || 1,
    };
  }

  static async getProviderById(staffGuid: string): Promise<Provider> {
    const response = await fetch(`/api/eyefinity/v2staff/${staffGuid}`, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch provider: ${response.status}`);
    }

    return response.json();
  }

  // ============================================
  // PATIENTS
  // ============================================

  static async searchPatients(options: {
    lastName?: string;
    firstName?: string;
    dob?: string;
    phone?: string;
    page?: number;
    pageSize?: number;
  }): Promise<PaginatedResponse<Patient>> {
    const { lastName, firstName, dob, phone, page = 1, pageSize = 50 } = options;
    console.log('[EyefinityService] Searching patients:', { lastName, firstName });

    const params = new URLSearchParams();
    
    // Add required pagination parameters
    params.append('page', page.toString());
    params.append('pageSize', pageSize.toString());

    if (lastName) params.append('lastName', lastName);
    if (firstName) params.append('firstName', firstName);
    if (dob) params.append('dob', dob);
    if (phone) params.append('phone', phone);

    const response = await fetch(`/api/eyefinity/patients?${params}`, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error(`Failed to search patients: ${response.status}`);
    }

    const data = await response.json();

    // Handle both array response and paginated response with items property
    const rawItems = Array.isArray(data) ? data : (data.items || data.Items || []);

    // Map v2 API response fields to Patient interface
    const mappedItems = rawItems.map((item: Record<string, unknown>) => ({
      id: String(item.PatientId || item.patientId || item.id || ''),
      patientId: String(item.PatientId || item.patientId || ''),
      PatientLegacyId: item.PatientLegacyId as number | undefined,
      PatientId: item.PatientId as string | undefined,
      firstName: (item.FirstName || item.firstName || '') as string,
      lastName: (item.LastName || item.lastName || '') as string,
      fullName: item.FirstName && item.LastName
        ? `${item.FirstName} ${item.LastName}`
        : (item.fullName || item.FullName || '') as string,
      dob: (item.Dob || item.DateOfBirth || item.dob || '') as string,
      email: (item.Email || item.email || '') as string,
      phone: (item.Phone || item.phone || '') as string,
      gender: (item.Gender || item.gender || '') as string,
      isInactive: (item.InActive || item.isInactive || false) as boolean,
    }));

    console.log('[EyefinityService] Patients found:', mappedItems.length);

    return {
      items: mappedItems,
      page: data.page || data.Page || page,
      pageSize: data.pageSize || data.PageSize || mappedItems.length,
      totalCount: data.totalCount || data.TotalCount || mappedItems.length,
      totalPages: data.totalPages || data.TotalPages || 1,
    };
  }

  static async getPatientById(patientId: string, companyId?: string): Promise<Patient> {
    console.log('[EyefinityService] Fetching patient by ID:', patientId);
    
    // Determine if this is a GUID or integer ID
    const isGuid = patientId.includes('-');
    const endpoint = isGuid ? `/api/eyefinity/v2patients/${patientId}` : `/api/eyefinity/v1patients/${patientId}`;
    
    console.log(`[EyefinityService] Using ${isGuid ? 'v2patients (GUID)' : 'v1patients (ID)'} endpoint:`, endpoint);
    
    const response = await fetch(endpoint, {
      headers: this.getHeaders(companyId),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch patient: ${response.status}`);
    }

    const data = await response.json();
    console.log('[EyefinityService] Patient API response:', data);
    const raw = Array.isArray(data) ? data[0] : data;
    if (!raw) throw new Error('Patient not found');
    
    // Debug PatientLegacyId preservation
    console.log('[EyefinityService] Raw PatientLegacyId:', raw.PatientLegacyId);
    console.log('[EyefinityService] Raw PatientId:', raw.PatientId);
    
    // Calculate age from DOB
    const calculateAge = (dob: string): number => {
      if (!dob) return 0;
      const birthDate = new Date(dob);
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) age--;
      return age;
    };

    // Map all patient fields
    const mappedPatient: Patient = {
      id: String(raw.PatientId || raw.patientId),
      patientId: String(raw.PatientId || raw.patientId),
      PatientLegacyId: raw.PatientLegacyId, // Preserve legacy ID for popup URLs
      PatientId: raw.PatientId, // Preserve original PatientId (GUID)
      firstName: raw.FirstName || raw.firstName || '',
      lastName: raw.LastName || raw.lastName || '',
      middleInitial: raw.MiddleInitial || '',
      fullName: `${raw.FirstName || ''} ${raw.LastName || ''}`.trim(),
      preferredName: raw.PreferredName || '',
      title: raw.Title || '',
      gender: raw.Gender || '',
      dob: raw.Dob || raw.DateOfBirth || '',
      age: calculateAge(raw.Dob || raw.DateOfBirth),
      email: raw.Email || '',
      isBadEmail: raw.IsBadEmail || false,
      homeOffice: raw.HomeOffice,
      examOffice: raw.ExamOffice,
      primaryProviderId: raw.PrimaryProviderId,
      preferredLanguage: raw.PreferredLanguage || 'English',
      communicationPreference: raw.CommunicationPreference || 'PHONE',
      occupation: raw.Occupation,
      isInactive: raw.InActive || false,
      isDeceased: raw.IsDeceased || false,
      emailDeclinedToShare: raw.EmailDeclinedToShare || false,
      emailRecall: raw.EmailRecall || false,
      emailPromotion: raw.EmailPromotion || false,
      sendOrderNotificationsViaText: raw.SendOrderNotificationsViaText || false,
      sendOrderNotificationsViaEmail: raw.SendOrderNotificationsViaEmail || false,
      sendApptNotificationsViaText: raw.SendApptNotificationsViaText || false,
      sendApptNotificationsViaEmail: raw.SendApptNotificationsViaEmail || false,
      firstVisit: raw.FirstVisit || '',
      lastVisit: raw.LastVisit || '',
      lastExamDate: raw.LastExamDate || '',
      nextRecallDate: raw.NextRecallDate,
      nextRecallReason: raw.NextRecallReason,
      emrPatientNum: raw.EMRPatientNum || '',
      patientUid: raw.PatientUid || '',
      hipaaSignatureDate: raw.HipaaSignatureDate || '',
      hipaaSignatureIsOnFile: raw.HipaaSignatureIsOnFile || false,
      medicalRecordNum: raw.MedicalRecordNum,
      // Map addresses
      addresses: (raw.Addresses || []).map((addr: any) => ({
        patientId: String(addr.PatientId),
        patientAddressId: addr.PatientAddressId,
        address: addr.Address || '',
        address2: addr.Address2 || '',
        city: addr.City || '',
        state: addr.State || '',
        zipCode: addr.ZipCode || '',
        country: addr.Country || '',
        isPrimary: addr.IsPrimary || false,
        addressType: addr.AddressType || 'Home',
      })),
      // Map phone numbers
      phoneNumbers: (raw.PhoneNumbers || []).map((phone: any) => ({
        patientId: String(phone.PatientId),
        phoneId: phone.PhoneId,
        number: phone.Number || '',
        isPrimary: phone.IsPrimary || false,
        type: phone.Type || 'Home',
        whenToCall: phone.WhenToCall || 'Anytime',
        isBadPhone: phone.IsBadPhone || false,
      })),
      // Map insurances
      insurances: (raw.Insurances || []).map((ins: any) => ({
        patientId: String(ins.PatientId),
        insuranceId: ins.InsuranceId,
        patientInsuranceUid: ins.PatientInsuranceUid || '',
        companyName: ins.CompanyName || '',
        planName: ins.PlanName || '',
        isPrimary: ins.IsPrimary || false,
        coverageType: ins.CoverageType || '',
        planType: ins.PlanType || '',
        insuranceIdentificationNumber: ins.InsuranceIdentificationNumber || '',
        isActive: ins.IsActive || false,
      })),
    };

    // Set primary phone numbers
    const primaryPhone = mappedPatient.phoneNumbers?.find((p: any) => p.isPrimary);
    const mobilePhone = mappedPatient.phoneNumbers?.find((p: any) => p.type === 'Mobile');
    const homePhone = mappedPatient.phoneNumbers?.find((p: any) => p.type === 'Home');
    mappedPatient.phone = primaryPhone?.number || mobilePhone?.number || homePhone?.number || '';
    mappedPatient.mobilePhone = mobilePhone?.number;
    mappedPatient.homePhone = homePhone?.number;

    // DEMO MODE: Replace contact info with demo credentials
    const demoSettings = DemoModeService.getSettings();
    if (demoSettings.enabled) {
      console.log(`[DEMO MODE] Replacing patient contact info with demo credentials`);
      console.log(`[DEMO MODE] Original: ${mappedPatient.email} / ${mappedPatient.phone}`);
      mappedPatient.email = demoSettings.demoEmail;
      mappedPatient.phone = demoSettings.demoPhone;
      mappedPatient.mobilePhone = demoSettings.demoPhone;
      mappedPatient.homePhone = demoSettings.demoPhone;
      // Also update phone numbers array
      if (mappedPatient.phoneNumbers) {
        mappedPatient.phoneNumbers = mappedPatient.phoneNumbers.map((p: any) => ({
          ...p,
          number: demoSettings.demoPhone,
        }));
      }
      console.log(`[DEMO MODE] Replaced with: ${mappedPatient.email} / ${mappedPatient.phone}`);
    }

    console.log('[EyefinityService] Mapped patient:', mappedPatient.fullName, mappedPatient);
    return mappedPatient;
  }

  /**
   * Update patient contact info.
   * Note: The PE API does not support PATCH/PUT on /v2patients/{guid} directly.
   * The only supported mutation endpoints are /communicationmethods and creating
   * a new patient record. This method updates communication preferences.
   * For full patient updates, a new patient record must be created.
   */
  static async updatePatientContact(patientId: string, contactData: {
    email?: string;
    phone?: string;
  }): Promise<Patient> {
    console.log('[EyefinityService] Updating patient contact:', patientId, contactData);

    // Use v2patients communicationmethods endpoint (the only supported update path)
    const methods: Array<Record<string, any>> = [
      { CommunicationEventType: 1, Call: true, Email: !!contactData.email, Text: !!contactData.phone, Mail: true, Description: 'Recalls' },
      { CommunicationEventType: 2, Call: true, Email: !!contactData.email, Text: !!contactData.phone, Mail: true, Description: 'Appointment' },
      { CommunicationEventType: 3, Call: true, Email: !!contactData.email, Text: !!contactData.phone, Mail: true, Description: 'Product Pick Up' },
      { CommunicationEventType: 4, Call: true, Email: !!contactData.email, Text: !!contactData.phone, Mail: true, Description: 'Marketing Promo' },
    ];

    const response = await fetch(`/api/eyefinity/v2patients/${patientId}/communicationmethods`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(methods),
    });

    if (!response.ok) {
      console.warn(`[EyefinityService] Communication methods update failed: ${response.status}`);
    }

    // Return the current patient data
    const patientResponse = await fetch(`/api/eyefinity/v2patients/${patientId}`, {
      headers: this.getHeaders(),
    });

    if (!patientResponse.ok) {
      throw new Error(`Failed to fetch patient after update: ${patientResponse.status}`);
    }

    const patients = await patientResponse.json();
    return Array.isArray(patients) ? patients[0] : patients;
  }

  /**
   * Create a new patient in Eyefinity via POST /v2patients
   * Required: FirstName, LastName, Dob, HomeOfficeId, PhoneNumbers, PrimaryProviderId, Gender, Addresses
   * Gender must be 'M' or 'F' (not 'Male'/'Female')
   * Addresses array is required for the API to accept the request
   */
  static async createPatient(patientData: {
    firstName: string;
    lastName: string;
    dateOfBirth: string;  // YYYY-MM-DD format
    homeOfficeId: string; // Eyefinity office GUID
    phone: string;
    email?: string;
    gender?: string;      // 'M' or 'F'
    middleInitial?: string;
    primaryProviderId?: string; // Provider GUID (not staff GUID)
    address?: {
      address: string;
      city: string;
      state: string;
      zipCode: string;
    };
  }, companyId?: string): Promise<any> {
    console.log('[EyefinityService] Creating patient via Eyefinity API:', patientData);

    // Normalize gender to M/F format required by API
    let gender = patientData.gender || 'M';
    if (gender.toLowerCase() === 'male') gender = 'M';
    else if (gender.toLowerCase() === 'female') gender = 'F';

    // PE API requires office GUIDs, not numeric/string office IDs.
    // Auto-resolve if the homeOfficeId is not already a GUID.
    let officeGuid = patientData.homeOfficeId;
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(officeGuid)) {
      try {
        console.log(`[EyefinityService] Resolving office ID "${officeGuid}" to GUID...`);
        const offices = await this.getOffices(1, 100, companyId);
        const matched = offices.items.find(o =>
          o.officeId === officeGuid || o.id === officeGuid || o.name?.includes(officeGuid)
        );
        if (matched?.guid) {
          console.log(`[EyefinityService] Resolved office ${officeGuid} → GUID ${matched.guid}`);
          officeGuid = matched.guid;
        } else {
          console.warn(`[EyefinityService] Could not resolve office ID "${officeGuid}" to GUID. Available offices:`,
            offices.items.map(o => `${o.name} (${o.officeId}, guid: ${o.guid})`));
        }
      } catch (err) {
        console.warn(`[EyefinityService] Office lookup failed, using raw ID:`, err);
      }
    }

    // Also resolve PrimaryProviderId if needed — get first provider from the office
    let providerId = patientData.primaryProviderId;
    if (!providerId || !/^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(providerId)) {
      try {
        console.log(`[EyefinityService] Resolving provider for office ${officeGuid}...`);
        const providers = await this.getProviders({ officeId: officeGuid });
        if (providers.items.length > 0) {
          providerId = providers.items[0].id;
          console.log(`[EyefinityService] Using provider: ${providers.items[0].fullName} (${providerId})`);
        }
      } catch (err) {
        console.warn(`[EyefinityService] Provider lookup failed:`, err);
      }
    }

    const payload: Record<string, any> = {
      PatientId: 0, // Auto-generate next available ID
      FirstName: patientData.firstName,
      LastName: patientData.lastName,
      Dob: patientData.dateOfBirth,
      HomeOfficeId: officeGuid,
      ExamOfficeId: officeGuid,
      PrimaryProviderId: providerId || officeGuid,
      Gender: gender,
      PhoneNumbers: [
        {
          Number: patientData.phone,
          IsPrimary: true,
          Type: 'Mobile',
        },
      ],
      Addresses: [
        patientData.address
          ? {
              Address: patientData.address.address,
              City: patientData.address.city,
              State: patientData.address.state,
              ZipCode: patientData.address.zipCode,
              Country: 'United States',
              IsPrimary: true,
              AddressType: 'Home',
            }
          : {
              Address: 'Not provided',
              City: 'Not provided',
              State: 'CA',
              ZipCode: '00000',
              Country: 'United States',
              IsPrimary: true,
              AddressType: 'Home',
            },
      ],
    };

    if (patientData.email) payload.Email = patientData.email;
    if (patientData.middleInitial) payload.MiddleInitial = patientData.middleInitial;

    const response = await fetch('/api/eyefinity/v2patients', {
      method: 'POST',
      headers: this.getHeaders(companyId),
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to create patient: ${response.status} - ${errorText}`);
    }

    return response.json();
  }

  // ============================================
  // APPOINTMENTS - v2 Endpoints
  // ============================================

  static async getAppointments(options: {
    fromDate?: string;
    toDate?: string;
    officeId?: string;
    patientId?: string;
    providerId?: string;
    page?: number;
    pageSize?: number;
    companyId?: string;
  } = {}): Promise<PaginatedResponse<Appointment>> {
    const {
      fromDate = new Date().toISOString().split('T')[0],
      toDate = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 90 days for demo
      officeId,
      providerId,
      patientId,
      page = 1,
      pageSize = 500, // Increased for demo
    } = options;

    console.log('[EyefinityService] Fetching appointments:', { fromDate, toDate });

    const params = new URLSearchParams({
      fromDate,
      toDate,
      page: page.toString(),
      pageSize: pageSize.toString(),
    });

    if (officeId) params.append('officeId', officeId);
    if (providerId) params.append('providerId', providerId);
    if (patientId) params.append('patientId', patientId);

    const response = await fetch(`/api/eyefinity/v2appointments?${params}`, {
      headers: this.getHeaders(options.companyId),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch appointments: ${response.status}`);
    }

    const data = await response.json();
    console.log('[EyefinityService] Raw appointments response:', data);
    
    // Handle both array response and paginated response
    const rawItems = Array.isArray(data) ? data : (data.items || data.Items || []);
    
    // Map API response fields to Appointment interface with all available fields
    const mappedItems = rawItems.map((item: Record<string, unknown>) => ({
      id: String(item.AppointmentId || item.appointmentId || item.Id || item.id),
      appointmentId: String(item.AppointmentId || item.appointmentId || ''),
      appointmentTypeId: item.AppointmentTypeId as number | undefined,
      appointmentTypeName: item.AppointmentTypeName as string | undefined,
      appointmentTypeUid: item.AppointmentTypeUid as string | undefined,
      patientId: String(item.PatientId || item.patientId || ''),
      patientLegacyId: item.PatientLegacyId as number | undefined,
      patientName: item.PatientName || item.patientName ||
        `${item.PatientFirstName || ''} ${item.PatientLastName || ''}`.trim() || 'Unknown Patient',
      patientFirstName: item.PatientFirstName as string | undefined,
      patientLastName: item.PatientLastName as string | undefined,
      providerId: String(item.ProviderId || item.StaffId || item.providerId || ''),
      providerName: item.ProviderName || item.StaffName || item.providerName || 
        `${item.ProviderFirstName || item.StaffFirstName || ''} ${item.ProviderLastName || item.StaffLastName || ''}`.trim() || '',
      providerFirstName: (item.ProviderFirstName || item.StaffFirstName) as string | undefined,
      providerLastName: (item.ProviderLastName || item.StaffLastName) as string | undefined,
      officeId: String(item.OfficeId || item.OfficeNumber || item.officeId || ''),
      date: item.AppointmentDate || item.appointmentDate || item.Date || '',
      startTime: item.AppointmentStartTime || item.StartTime || item.startTime || '',
      endTime: item.AppointmentEndTime || item.EndTime || item.endTime || '',
      appointmentType: item.AppointmentTypeName || item.AppointmentType || item.appointmentType || item.AppointmentReason || `Type ${item.AppointmentTypeId || ''}`,
      status: item.Status || item.status || item.AppointmentStatus || 'Scheduled',
      showStatus: item.AppointmentShowStatus as string | undefined,
      confirmedIndicator: item.ConfirmedIndicator as string | undefined,
      reason: item.AppointmentReason || item.Reason || item.reason || '',
      notes: ((item.Notes || item.notes || []) as any[]).map((n: any) => ({
        id: n.Id || n.id,
        date: n.Date || n.date,
        detail: n.Detail || n.detail,
        noteType: n.NoteType || n.noteType,
        isUrgent: n.IsUrgent || n.isUrgent || false,
        isFollowUp: n.IsFollowUp || n.isFollowUp || false,
        entityId: n.EntityId || n.entityId,
      })),
      isUrgent: item.IsUrgent as boolean | undefined,
      isDeleted: item.IsDeleted as boolean | undefined,
      cancelIndicator: item.CancelIndicator as boolean | undefined,
      isPreAppointment: item.IsPreAppointment as boolean | undefined,
      appointmentCreatedDate: item.AppointmentCreatedDate as string | undefined,
      appointmentLastChangedDate: item.AppointmentLastChangedDate as string | undefined,
      statusLastChangedDate: item.StatusLastChangedDate as string | undefined,
      appointmentExternalId: item.AppointmentExternalId as string | undefined,
      patientInsuranceUid: item.PatientInsuranceUid as string | undefined,
      patientMedicalInsuranceUid: item.PatientMedicalInsuranceUid as string | undefined,
    }));
    
    console.log('[EyefinityService] Mapped appointments:', mappedItems.length, mappedItems.slice(0, 2));
    
    return {
      items: mappedItems,
      page: data.page || data.Page || 1,
      pageSize: data.pageSize || data.PageSize || mappedItems.length,
      totalCount: data.totalCount || data.TotalCount || mappedItems.length,
      totalPages: data.totalPages || data.TotalPages || 1,
    };
  }

  static async getAppointmentById(appointmentId: string): Promise<Appointment> {
    const response = await fetch(`/api/eyefinity/v2appointments/${appointmentId}`, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch appointment: ${response.status}`);
    }

    return response.json();
  }

  // ============================================
  // APPOINTMENT SLOTS - v2 (GUID-based)
  // ============================================

  static async getAppointmentSlots(staffGuid: string, options: {
    officeId: string;
    fromDate: string;
    toDate: string;
    itemDuration?: number;
    appointmentTypeId?: number;
    page?: number;
    pageSize?: number;
  }): Promise<PaginatedResponse<AppointmentSlot>> {
    const {
      officeId,
      fromDate,
      toDate,
      itemDuration = 30,
      appointmentTypeId,
      page = 1,
      pageSize = 50,
    } = options;

    console.log('[EyefinityService] Fetching v2 appointment slots:', { staffGuid, officeId, fromDate, toDate });

    const params = new URLSearchParams({
      officeId,
      fromDate,
      toDate,
      page: page.toString(),
      pageSize: pageSize.toString(),
    });

    if (appointmentTypeId) {
      params.append('appointmentTypeId', appointmentTypeId.toString());
    } else {
      params.append('itemDuration', itemDuration.toString());
    }

    const response = await fetch(`/api/eyefinity/v2staff/${staffGuid}/appointmentSlots?${params}`, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to fetch slots: ${response.status} - ${errorText}`);
    }

    const data = await response.json();

    // Handle both array response and paginated response with items property
    const rawItems = Array.isArray(data) ? data : (data.items || data.Items || []);

    // Map v2 API response fields to AppointmentSlot interface
    const mappedItems = rawItems.map((item: Record<string, unknown>) => ({
      date: (item.Date || item.date || '') as string,
      startTime: (item.StartTime || item.startTime || '') as string,
      endTime: (item.EndTime || item.endTime || '') as string,
      providerId: (item.StaffId || item.ProviderId || item.providerId || '') as string,
      providerName: (item.ProviderName || item.providerName || '') as string,
      officeId: (item.OfficeId || item.officeId || officeId || '') as string,
      duration: (item.Duration || item.duration || itemDuration) as number,
      available: (item.Available ?? item.available ?? true) as boolean,
    }));

    console.log('[EyefinityService] Slots fetched:', mappedItems.length);

    return {
      items: mappedItems,
      page: data.page || data.Page || page,
      pageSize: data.pageSize || data.PageSize || mappedItems.length,
      totalCount: data.totalCount || data.TotalCount || mappedItems.length,
      totalPages: data.totalPages || data.TotalPages || 1,
    };
  }

  /**
   * Bulk slot search via Schedule Manager API
   * Searches across all providers in a single API call
   */
  static async findSlotsBulk(
    officeId: string,
    options: {
      providerId?: string;
      appointmentTypeId?: number;
      startDate: string;
      endDate: string;
      startTime?: string;
      endTime?: string;
      companyId?: string;
      limit?: number;
      offset?: number;
    }
  ): Promise<BulkSlotResponse[]> {
    console.log('[EyefinityService] Bulk slot search via Schedule Manager:', { officeId, ...options });

    // Build request body per Schedule Manager Swagger spec
    const requestBody: BulkSlotSearchRequest = {
      StartDate: options.startDate,
      EndDate: options.endDate,
      AppointmentDuration: 0,       // 0 = use system default duration
      IncludeNiceTimes: true,        // round to 15-min increments
      RestrictServiceItemSlots: false,
    };

    // ResourceIds = provider/staff GUIDs (array)
    if (options.providerId) {
      requestBody.ResourceIds = [options.providerId];
    }

    // ServiceCatalogItemId = appointment type (must be UUID string, not integer)
    if (options.appointmentTypeId) {
      requestBody.ServiceCatalogItemId = String(options.appointmentTypeId);
    }

    // Map startTime/endTime to StartHour/EndHour (integer 0-23)
    if (options.startTime) {
      const hour = parseInt(options.startTime.split(':')[0], 10);
      if (!isNaN(hour)) requestBody.StartHour = hour;
    }
    if (options.endTime) {
      const hour = parseInt(options.endTime.split(':')[0], 10);
      if (!isNaN(hour)) requestBody.EndHour = hour;
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
    if (options.companyId) headers['X-Company-Id'] = options.companyId;

    // Schedule Manager API requires Limit and Offset as query params
    const limit = options.limit || 50;
    const offset = options.offset || 0;
    const url = `/api/schedule-manager/offices/${officeId}/appointmentSlots?Limit=${limit}&Offset=${offset}`;

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(requestBody),
    });

    if (!response.ok) {
      throw new Error(`Bulk slot search failed: ${response.status}`);
    }

    const data = await response.json();

    // Schedule Manager returns { openAppointmentSlots: [...], Offset, Limit, Size }
    const rawItems = data.openAppointmentSlots || [];

    // Map from Schedule Manager response DTO to our BulkSlotResponse
    return rawItems.map((item: any) => {
      // AppointmentDate is ISO datetime, extract date and time parts
      const apptDate = item.AppointmentDate || '';
      const datePart = apptDate.split('T')[0] || apptDate;
      const timePart = apptDate.includes('T') ? apptDate.split('T')[1]?.substring(0, 5) : '';
      const durationMin = item.DurationMinutes || 0;

      // Calculate end time from start + duration
      let endTime = '';
      if (timePart && durationMin) {
        const [h, m] = timePart.split(':').map(Number);
        const totalMin = h * 60 + m + durationMin;
        endTime = `${String(Math.floor(totalMin / 60)).padStart(2, '0')}:${String(totalMin % 60).padStart(2, '0')}`;
      }

      return {
        slotId: item.CorrelationId || undefined,
        date: datePart,
        startTime: timePart,
        endTime,
        providerId: String(item.ResourceId || ''),
        providerName: [item.ResourceFirstName, item.ResourceLastName].filter(Boolean).join(' '),
        officeId: String(item.OfficeId || officeId),
        duration: durationMin,
      };
    });
  }

  static async findNextAvailableSlot(officeId: string, options: {
    fromDate?: string;
    providerName?: string;
    duration?: number;
    daysToSearch?: number;
    appointmentTypeId?: number;
    companyId?: string;
  } = {}): Promise<{ slots: AppointmentSlot[]; provider?: Provider }> {
    const {
      fromDate = new Date().toISOString().split('T')[0],
      providerName,
      duration = 30,
      daysToSearch = 14,
    } = options;

    const toDate = new Date(new Date(fromDate).getTime() + daysToSearch * 24 * 60 * 60 * 1000)
      .toISOString()
      .split('T')[0];

    // ========== TRY BULK SEARCH FIRST (Schedule Manager API) ==========
    try {
      console.log('[EyefinityService] Attempting bulk slot search via Schedule Manager');

      // Schedule Manager requires office GUID, not numeric office number.
      // If officeId looks numeric, resolve it to GUID via the offices list.
      let scheduleManagerOfficeId = officeId;
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(officeId)) {
        try {
          const offices = await this.getOffices(1, 100, options.companyId);
          const matched = offices.items.find(o =>
            o.officeId === officeId || o.id === officeId
          );
          if (matched?.guid) {
            console.log(`[EyefinityService] Resolved office ${officeId} → GUID ${matched.guid}`);
            scheduleManagerOfficeId = matched.guid;
          }
        } catch {
          // If office lookup fails, try with original ID
        }
      }

      // If providerName is specified, resolve to ID from cache
      let providerId: string | undefined;
      if (providerName) {
        try {
          const { default: OfficeDataCacheService } = await import('./officeDataCacheService');
          const cachedProviders = await OfficeDataCacheService.getProviders(officeId, options.companyId);
          const lowerName = providerName.toLowerCase();
          const matched = cachedProviders.find(p =>
            p.fullName?.toLowerCase().includes(lowerName) ||
            p.lastName?.toLowerCase().includes(lowerName)
          );
          if (matched) providerId = matched.guid || matched.staffId;
        } catch {
          // Cache not available, continue without provider filter
        }
      }

      const bulkSlots = await this.findSlotsBulk(scheduleManagerOfficeId, {
        startDate: fromDate,
        endDate: toDate,
        providerId,
        appointmentTypeId: options.appointmentTypeId,
        companyId: options.companyId,
      });

      if (bulkSlots.length > 0) {
        const mappedSlots: AppointmentSlot[] = bulkSlots.map(s => ({
          date: s.date,
          startTime: s.startTime,
          endTime: s.endTime,
          providerId: s.providerId,
          providerName: s.providerName,
          officeId: s.officeId,
          duration: s.duration || duration,
          available: true,
        }));

        mappedSlots.sort((a, b) => {
          const dateCompare = a.date.localeCompare(b.date);
          if (dateCompare !== 0) return dateCompare;
          return a.startTime.localeCompare(b.startTime);
        });

        console.log(`[EyefinityService] Bulk search returned ${mappedSlots.length} slots`);
        return { slots: mappedSlots.slice(0, 20) };
      }
    } catch (bulkError) {
      console.warn('[EyefinityService] Bulk slot search failed, falling back to per-provider:', bulkError);
    }

    // ========== FALLBACK: PER-PROVIDER ITERATION ==========
    const providers = await this.getProviders({ officeId });

    let targetProviders = providers.items.filter((p: any) =>
      (p.allowToBeScheduled !== false) && (p.isActive !== false)
    );

    if (providerName) {
      const lowerName = providerName.toLowerCase();
      targetProviders = targetProviders.filter(p =>
        p.fullName?.toLowerCase().includes(lowerName) ||
        p.lastName?.toLowerCase().includes(lowerName)
      );
    }

    if (targetProviders.length === 0) {
      return { slots: [] };
    }

    const allSlots: AppointmentSlot[] = [];
    for (const provider of targetProviders.slice(0, 5)) {
      try {
        const slotsResponse = await this.getAppointmentSlots(provider.guid || provider.staffId, {
          officeId,
          fromDate,
          toDate,
          itemDuration: duration,
        });

        const enrichedSlots = slotsResponse.items.map(slot => ({
          ...slot,
          providerName: provider.fullName,
          providerId: provider.guid || provider.staffId,
        }));

        allSlots.push(...enrichedSlots);
      } catch (err) {
        console.warn(`[EyefinityService] Failed to get slots for provider ${provider.fullName}:`, err);
      }
    }

    allSlots.sort((a, b) => {
      const dateCompare = a.date.localeCompare(b.date);
      if (dateCompare !== 0) return dateCompare;
      return a.startTime.localeCompare(b.startTime);
    });

    return {
      slots: allSlots.slice(0, 20),
      provider: targetProviders[0],
    };
  }

  // ============================================
  // CREATE/UPDATE APPOINTMENTS - v2
  // ============================================

  static async createAppointment(staffGuid: string, payload: CreateAppointmentPayload): Promise<Appointment> {
    console.log('[EyefinityService] Creating v2 appointment:', payload);

    const response = await fetch(`/api/eyefinity/v2staff/${staffGuid}/appointments`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify({
        ...payload,
        CancelIndicator: payload.CancelIndicator ?? false,
        Notes: payload.Notes ?? [],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to create appointment: ${response.status} - ${errorText}`);
    }

    return response.json();
  }

  /**
   * Cancel an appointment by re-PUTting it with CancelIndicator=true.
   * The PE API has no separate cancel endpoint — all appointment mutations
   * go through PUT /v2staff/{staffGuid}/appointments.
   * Requires the full appointment context (fetched first, then re-sent with cancel flag).
   */
  static async cancelAppointment(appointmentId: string, reason?: string): Promise<void> {
    console.log('[EyefinityService] Canceling appointment:', appointmentId);

    // First, find the appointment to get its full data (staffId, patientId, officeId, etc.)
    const today = new Date().toISOString().split('T')[0];
    const farFuture = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const farPast = new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const apptResult = await this.getAppointments({ fromDate: farPast, toDate: farFuture, pageSize: 500 });
    const appointment = apptResult.items.find(a => a.appointmentId === appointmentId || a.id === appointmentId);

    if (!appointment) {
      throw new Error(`Appointment ${appointmentId} not found — cannot cancel`);
    }

    // The staffGuid / providerId from the appointment
    const staffGuid = appointment.providerId;

    const response = await fetch(`/api/eyefinity/v2staff/${staffGuid}/appointments`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify({
        AppointmentId: appointmentId,
        PatientId: appointment.patientId,
        OfficeId: appointment.officeId || '',
        StaffId: staffGuid,
        AppointmentDate: appointment.date,
        AppointmentStartTime: appointment.startTime,
        AppointmentEndTime: appointment.endTime,
        AppointmentTypeId: appointment.appointmentTypeId,
        CancelIndicator: true,
        Notes: [],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to cancel appointment: ${response.status} - ${errorText}`);
    }
  }

  /**
   * Reschedule an appointment by re-PUTting it with new date/time.
   * The PE API has no PATCH endpoint — all appointment mutations
   * go through PUT /v2staff/{staffGuid}/appointments with AppointmentId in payload.
   */
  static async rescheduleAppointment(appointmentId: string, newData: {
    date?: string;
    startTime?: string;
    endTime?: string;
    providerId?: string;
  }): Promise<Appointment> {
    console.log('[EyefinityService] Rescheduling appointment:', appointmentId);

    // First, find the appointment to get its full data
    const farFuture = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const farPast = new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const apptResult = await this.getAppointments({ fromDate: farPast, toDate: farFuture, pageSize: 500 });
    const appointment = apptResult.items.find(a => a.appointmentId === appointmentId || a.id === appointmentId);

    if (!appointment) {
      throw new Error(`Appointment ${appointmentId} not found — cannot reschedule`);
    }

    const staffGuid = newData.providerId || appointment.providerId;

    const response = await fetch(`/api/eyefinity/v2staff/${staffGuid}/appointments`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify({
        AppointmentId: appointmentId,
        PatientId: appointment.patientId,
        OfficeId: appointment.officeId || '',
        StaffId: staffGuid,
        AppointmentDate: newData.date || appointment.date,
        AppointmentStartTime: newData.startTime || appointment.startTime,
        AppointmentEndTime: newData.endTime || appointment.endTime,
        AppointmentTypeId: appointment.appointmentTypeId,
        CancelIndicator: false,
        Notes: [],
      }),
    });

    if (!response.ok) {
      throw new Error(`Failed to reschedule appointment: ${response.status}`);
    }

    return response.json();
  }

  // ============================================
  // TODAY'S SCHEDULE HELPER
  // ============================================

  static async getTodaysSchedule(options: {
    officeId?: string;
    providerId?: string;
  } = {}): Promise<Appointment[]> {
    const today = new Date().toISOString().split('T')[0];
    
    const result = await this.getAppointments({
      fromDate: today,
      toDate: today,
      officeId: options.officeId,
      providerId: options.providerId,
      pageSize: 200,
    });

    return result.items.sort((a, b) => a.startTime.localeCompare(b.startTime));
  }

  // ============================================
  // INSURANCE - v2 Endpoints
  // ============================================

  /**
   * Get insurance carriers for an office
   * Swagger: GET /v2offices/{officeId}/insuranceCarriers
   */
  static async getInsuranceCarriers(officeId: string, page = 1, pageSize = 500): Promise<PaginatedResponse<any>> {
    const params = new URLSearchParams({
      page: page.toString(),
      pageSize: pageSize.toString(),
    });

    const response = await fetch(`/api/eyefinity/v2offices/${officeId}/insuranceCarriers?${params}`, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch insurance carriers: ${response.status}`);
    }

    return response.json();
  }

  /**
   * Get insurance carriers for a company
   * Swagger: GET /v2companies/{companyId}/insuranceCarriers
   */
  static async getCompanyInsuranceCarriers(companyId: string, page = 1, pageSize = 500): Promise<PaginatedResponse<any>> {
    const params = new URLSearchParams({
      page: page.toString(),
      pageSize: pageSize.toString(),
    });

    const response = await fetch(`/api/eyefinity/v2companies/${companyId}/insuranceCarriers?${params}`, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch company insurance carriers: ${response.status}`);
    }

    return response.json();
  }

  // ============================================
  // ORDERS
  // ============================================

  static async getPatientOrders(patientId: string, options: {
    fromStatusChangedDate?: string;
    toStatusChangedDate?: string;
    page?: number;
    pageSize?: number;
    companyId?: string;
  } = {}): Promise<PaginatedResponse<any>> {
    console.log('[EyefinityService] Fetching patient orders for:', patientId);
    
    const {
      fromStatusChangedDate = '2020-01-01',
      toStatusChangedDate = new Date().toISOString().split('T')[0],
      page = 1,
      pageSize = 100,
    } = options;

    // Use v2orders endpoint with patientId as query parameter (correct API structure)
    const params = new URLSearchParams({
      patientId,
      fromStatusChangedDate,
      toStatusChangedDate,
      page: page.toString(),
      pageSize: pageSize.toString(),
    });
    
    const endpoint = `/api/eyefinity/v2orders`;
    
    const response = await fetch(`${endpoint}?${params}`, {
      headers: this.getHeaders(options.companyId),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch patient orders: ${response.status}`);
    }

    return response.json();
  }

  // ============================================
  // RX/PRESCRIPTIONS
  // ============================================

  static async getPatientRx(patientId: string, page = 1, pageSize = 100, companyId?: string): Promise<PaginatedResponse<any>> {
    console.log('[EyefinityService] Fetching patient Rx for:', patientId);
    
    // TODO: RX endpoints not available in current Eyefinity API version
    // Returning placeholder data until RX API access is resolved
    console.warn('[EyefinityService] Using placeholder RX data - API endpoints not available');
    
    // Generate realistic placeholder prescription data
    const placeholderRxData = [
      {
        RxNumber: 'RX-2024-001234',
        DatePrescribed: '2024-01-15T10:30:00Z',
        Product: 'Distance Glasses',
        Status: 'Active',
        ProviderName: 'Dr. Sarah Johnson',
        OdSphere: '-2.25',
        OdCylinder: '-0.75',
        OdAxis: '165',
        OsSphere: '-2.50',
        OsCylinder: '-1.00',
        OsAxis: '170',
        AddPower: null,
        PupillaryDistance: '64',
        ExpirationDate: '2026-01-15T00:00:00Z',
        Notes: 'Patient prefers anti-reflective coating'
      },
      {
        RxNumber: 'RX-2023-005678',
        DatePrescribed: '2023-06-20T14:15:00Z',
        Product: 'Progressive Lenses',
        Status: 'Expired',
        ProviderName: 'Dr. Michael Chen',
        OdSphere: '-2.00',
        OdCylinder: '-0.50',
        OdAxis: '160',
        OsSphere: '-2.25',
        OsCylinder: '-0.75',
        OsAxis: '175',
        AddPower: '+1.75',
        PupillaryDistance: '64',
        ExpirationDate: '2024-06-20T00:00:00Z',
        Notes: 'Previous prescription - updated due to vision change'
      }
    ];
    
    // Simulate API pagination response structure
    return {
      items: placeholderRxData,
      totalCount: placeholderRxData.length,
      page,
      pageSize,
      totalPages: Math.ceil(placeholderRxData.length / pageSize)
    };
  }

  // ============================================
  // COMMUNICATION METHODS
  // ============================================

  static async getPatientCommunicationMethods(patientId: string): Promise<any> {
    console.log('[EyefinityService] Fetching patient communication methods for:', patientId);
    
    const endpoint = `/api/eyefinity/v2patients/${patientId}/communicationmethods`;
    
    const response = await fetch(endpoint, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch patient communication methods: ${response.status}`);
    }

    return response.json();
  }

  // ============================================
  // APPOINTMENT TYPES
  // ============================================

  static async getAppointmentTypes(officeId: string): Promise<AppointmentType[]> {
    console.log('[EyefinityService] Fetching appointment types for office:', officeId);

    const response = await fetch(`/api/eyefinity/v2offices/${officeId}/appointmentTypes`, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch appointment types: ${response.status}`);
    }

    const data = await response.json();
    const rawItems = Array.isArray(data) ? data : (data.items || []);
    
    return rawItems.map((item: any) => ({
      appointmentTypeId: item.AppointmentTypeId || item.Id,
      appointmentTypeUid: item.AppointmentTypeUid || item.Uid,
      description: item.Description || item.Name,
      companyServiceName: item.CompanyServiceName,
      duration: item.Duration || 30,
      isActive: item.IsActive !== false,
    }));
  }

  // ============================================
  // APPOINTMENT CONFIRMATION - Write to Eyefinity
  // ============================================

  static async confirmAppointment(
    staffId: string,
    appointmentId: string,
    confirmed: boolean = true,
    note?: string
  ): Promise<AppointmentConfirmation> {
    console.log('[EyefinityService] Confirming appointment:', { staffId, appointmentId, confirmed });

    const payload: any = { Confirmed: confirmed };
    if (note) {
      payload.Note = { Detail: note };
    }

    const response = await fetch(
      `/api/eyefinity/staff/${staffId}/appointments/${appointmentId}/appointmentConfirmations`,
      {
        method: 'PUT',
        headers: this.getHeaders(),
        body: JSON.stringify(payload),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to confirm appointment: ${response.status} - ${errorText}`);
    }

    return response.json();
  }

  static async getAppointmentConfirmation(
    staffId: string,
    appointmentId: string
  ): Promise<AppointmentConfirmation> {
    const response = await fetch(
      `/api/eyefinity/staff/${staffId}/appointments/${appointmentId}/appointmentConfirmations`,
      { headers: this.getHeaders() }
    );

    if (!response.ok) {
      throw new Error(`Failed to get appointment confirmation: ${response.status}`);
    }

    return response.json();
  }


  static async updatePatientCommunicationMethods(
    patientId: string,
    methods: CommunicationMethod[]
  ): Promise<CommunicationMethod[]> {
    console.log('[EyefinityService] Updating communication methods for patient:', patientId);

    // Use v2 endpoint with patient GUID
    const response = await fetch(`/api/eyefinity/v2patients/${patientId}/communicationmethods`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(methods),
    });

    if (!response.ok) {
      throw new Error(`Failed to update communication methods: ${response.status}`);
    }

    return response.json();
  }

  // ============================================
  // PATIENT SEARCH (POST - more powerful)
  // ============================================

  static async searchPatientsAdvanced(options: {
    lastName?: string;
    dateOfBirth?: string;
    phoneNumber?: string;
    email?: string;
    zipCode?: string;
    gender?: string;
    page?: number;
    pageSize?: number;
  }): Promise<PaginatedResponse<Patient>> {
    const { page = 1, pageSize = 50, ...searchParams } = options;
    console.log('[EyefinityService] Advanced patient search:', searchParams);

    const params = new URLSearchParams({
      page: page.toString(),
      pageSize: pageSize.toString(),
    });

    const body: Record<string, any> = {};
    if (searchParams.lastName) body.LastName = searchParams.lastName;
    if (searchParams.dateOfBirth) body.DateOfBirth = searchParams.dateOfBirth;
    if (searchParams.phoneNumber) body.PhoneNumber = searchParams.phoneNumber;
    if (searchParams.email) body.Email = searchParams.email;
    if (searchParams.zipCode) body.ZipCode = searchParams.zipCode;
    if (searchParams.gender) body.Gender = searchParams.gender;

    const response = await fetch(`/api/eyefinity/v2patients/search?${params}`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      throw new Error(`Failed to search patients: ${response.status}`);
    }

    const data = await response.json();

    // API returns { Patients: [...] } not { items: [...] }
    const rawPatients = data.Patients || data.patients || data.items || data.Items || [];

    return {
      items: rawPatients,
      page,
      pageSize,
      totalCount: rawPatients.length,
    };
  }

  // ============================================
  // ORDER NOTIFICATIONS
  // ============================================

  static async notifyOrderPickup(
    patientId: string,
    orderId: string,
    timestamp?: string
  ): Promise<void> {
    console.log('[EyefinityService] Notifying order pickup:', { patientId, orderId });

    // Use v1 endpoint with integer patient ID
    const endpoint = `patients/${patientId}`;

    const response = await fetch(
      `/api/eyefinity/${endpoint}/orders/${orderId}/notifications`,
      {
        method: 'PUT',
        headers: this.getHeaders(),
        body: JSON.stringify({
          TimeStamp: timestamp || new Date().toISOString().split('T')[0],
          OrderStatus: 'Notified',
        }),
      }
    );

    if (!response.ok) {
      throw new Error(`Failed to notify order: ${response.status}`);
    }
  }

  // ============================================
  // LEGACY COMPATIBILITY METHODS
  // These wrap v2 methods for backward compatibility
  // ============================================

  static async fetchOffices(companyId?: string): Promise<PaginatedResponse<Office>> {
    return this.getOffices(1, 100, companyId);
  }

  static async fetchAppointments(options: {
    fromDate?: string;
    toDate?: string;
    officeId?: string;
  } = {}): Promise<PaginatedResponse<Appointment>> {
    return this.getAppointments(options);
  }
}

// ============================================
// NEW TYPES FROM SWAGGER DOCUMENTATION
// ============================================

export interface AppointmentType {
  appointmentTypeId: number;
  appointmentTypeUid?: string;
  description: string;
  companyServiceName?: string;
  duration: number;
  isActive: boolean;
}

export interface AppointmentConfirmation {
  appointmentId: number;
  confirmed: boolean;
  confirmedDate?: string;
  note?: {
    id?: number;
    detail: string;
    date?: string;
  };
}

export interface CommunicationMethod {
  communicationEventType: number; // 1=Recalls, 2=Appointment, 3=Product Pick Up, 4=Marketing, 5=Education
  communicationEventTypeName?: string;
  email?: boolean;
  phone?: boolean;
  text?: boolean;
  mail?: boolean;
}

export interface PaymentMethod {
  type: 'insurance' | 'private_pay' | 'other';
  insuranceId?: number;           // If using insurance from profile
  insuranceName?: string;         // Display name
  planName?: string;              // Plan name if insurance
  otherDescription?: string;      // If type is 'other'
}

export interface ReadinessStatus {
  appointment: 'complete' | 'incomplete';
  insurance: 'complete' | 'incomplete';
  demographics: 'complete' | 'incomplete';
  forms: 'complete' | 'incomplete';
  rxAcknowledgement: 'complete' | 'incomplete' | 'not_required';
  paymentMethod?: PaymentMethod;  // Selected payment method for this appointment
}

export function getAppointmentPaymentMethod(appointmentId: string): PaymentMethod | null {
  const readiness = getAppointmentReadiness(appointmentId);
  return readiness.paymentMethod || null;
}

export function setAppointmentPaymentMethod(appointmentId: string, paymentMethod: PaymentMethod): void {
  setAppointmentReadiness(appointmentId, { paymentMethod });
}

// ============================================
// FTC RX ACKNOWLEDGEMENT TYPES
// ============================================

export interface RxData {
  SoftCL?: SoftCLRxDetails[];
  HardCL?: HardCLRxDetails[];
  EyeGlass?: EyeGlassRxDetails[];
}

export interface SoftCLRxDetails {
  PatientExamUid?: string;
  RxType?: string;
  ExamDate?: string;
  ExpirationDate?: string;
  IsIncomplete?: boolean;
  IsRecheck?: boolean;
}

export interface HardCLRxDetails {
  PatientExamUid?: string;
  RxType?: string;
  ExamDate?: string;
  ExpirationDate?: string;
}

export interface EyeGlassRxDetails {
  PatientExamUid?: string;
  RxType?: string;
  ExamDate?: string;
  ExpirationDate?: string;
  OdSphere?: number;
  OdCylinder?: number;
  OdAxis?: number;
  OdAdd?: number;
  OsSphere?: number;
  OsCylinder?: number;
  OsAxis?: number;
  OsAdd?: number;
  Pd?: number;
}

export type RxConsentType = 'electronic' | 'physical' | 'declined';
export type RxDeliveryMethod = 'email' | 'text' | 'portal';

export interface RxConsent {
  patientId: string;
  patientUid?: string;
  patientName: string;
  consentType: RxConsentType;
  deliveryMethod?: RxDeliveryMethod;
  deliveryDetails?: string; // email or phone number
  consentTimestamp: string;
  consentSignature: string;
  consentIpAddress: string;
  storeNumber?: string;
  storeId?: string;
}

export interface RxDeliveryStatus {
  patientId: string;
  rxType: 'eyeglass' | 'contact_lens';
  deliveryMethod: RxDeliveryMethod;
  deliveryTimestamp?: string;
  wasDelivered: boolean;
  wasOpened?: boolean;
  openedTimestamp?: string;
}

export interface RxAcknowledgement {
  patientId: string;
  patientUid?: string;
  patientName: string;
  examDate: string;
  acknowledgementTimestamp: string;
  acknowledgementSignature: string;
  acknowledgementIpAddress: string;
  storeNumber?: string;
  storeId?: string;
  associateId?: string;
  associateName?: string;
  rxData?: RxData;
}

export interface FtcComplianceRecord {
  patientId: string;
  appointmentId?: string;
  consent?: RxConsent;
  delivery?: RxDeliveryStatus;
  acknowledgement?: RxAcknowledgement;
  isCompliant: boolean;
  complianceStatus: 'pending_consent' | 'pending_delivery' | 'pending_acknowledgement' | 'complete';
  createdAt: string;
  updatedAt: string;
}

export function getAppointmentReadiness(appointmentId: string): ReadinessStatus {
  const statuses = JSON.parse(localStorage.getItem('appointmentReadiness') || '{}');
  return statuses[appointmentId] || {
    appointment: 'incomplete',
    insurance: 'incomplete',
    demographics: 'incomplete',
    forms: 'incomplete',
    rxAcknowledgement: 'not_required',
  };
}

export function setAppointmentReadiness(appointmentId: string, readiness: Partial<ReadinessStatus>): void {
  const statuses = JSON.parse(localStorage.getItem('appointmentReadiness') || '{}');
  statuses[appointmentId] = {
    ...getAppointmentReadiness(appointmentId),
    ...readiness,
  };
  localStorage.setItem('appointmentReadiness', JSON.stringify(statuses));
}

export function isPatientReady(appointmentId: string): boolean {
  const readiness = getAppointmentReadiness(appointmentId);
  return readiness.appointment === 'complete' &&
         readiness.insurance === 'complete' &&
         readiness.demographics === 'complete' &&
         readiness.forms === 'complete';
}

export function getReadinessFilter(appointmentId: string): string {
  const readiness = getAppointmentReadiness(appointmentId);
  if (isPatientReady(appointmentId)) return 'Complete';
  if (readiness.insurance === 'incomplete') return 'Insurance: Incomplete';
  if (readiness.appointment === 'incomplete') return 'Appointment: Incomplete';
  if (readiness.forms === 'incomplete') return 'Forms: Incomplete';
  if (readiness.demographics === 'incomplete') return 'Demographics: Incomplete';
  return 'Incomplete';
}

// Legacy functions for backward compatibility
export function getAppointmentStatus(appointmentId: string): string {
  return isPatientReady(appointmentId) ? 'Ready' : 'Not Ready';
}

export function setAppointmentStatus(appointmentId: string, status: string): void {
  if (status === 'Ready') {
    setAppointmentReadiness(appointmentId, {
      appointment: 'complete',
      insurance: 'complete',
      demographics: 'complete',
      forms: 'complete',
    });
  }
}

export default EyefinityService;
