/**
 * Office Data Cache Service
 *
 * Caches providers, appointment types, and insurance carriers per office
 * in localStorage with a 30-minute TTL.
 *
 * Uses EyefinityService methods (which go through the proxy) to fetch data.
 * All three data sources are fetched in parallel on cache miss.
 */

import { EyefinityService, Provider, AppointmentType } from './eyefinityService';

// ============================================
// Interfaces
// ============================================

export interface CachedProvider {
  staffId: string;
  guid: string;
  firstName: string;
  lastName: string;
  fullName: string;
  providerType: string;
  isActive: boolean;
  allowToBeScheduled: boolean;
}

export interface CachedAppointmentType {
  appointmentTypeId: number;
  appointmentTypeUid?: string;
  description: string;
  companyServiceName?: string;
  duration: number;
  isActive: boolean;
}

export interface CachedInsuranceCarrier {
  carrierId: string;
  carrierName: string;
  planName?: string;
  isActive: boolean;
}

export interface CachedOfficeData {
  officeId: string;
  companyId: string;
  cachedAt: number; // Date.now() timestamp
  providers: CachedProvider[];
  appointmentTypes: CachedAppointmentType[];
  insuranceCarriers: CachedInsuranceCarrier[];
}

// ============================================
// Service
// ============================================

const CACHE_PREFIX = 'office_data_cache';
const TTL_MS = 30 * 60 * 1000; // 30 minutes

class OfficeDataCacheServiceClass {
  private inFlightLoads = new Map<string, Promise<CachedOfficeData>>();

  /**
   * Get the localStorage key for a specific office
   */
  private getCacheKey(companyId: string, officeId: string): string {
    return `${CACHE_PREFIX}:${companyId || 'default'}:${officeId}`;
  }

  /**
   * Check if cached data has expired
   */
  private isExpired(cachedData: CachedOfficeData): boolean {
    return Date.now() - cachedData.cachedAt > TTL_MS;
  }

  /**
   * Get cached office data from localStorage (no fetch)
   */
  getOfficeData(officeId: string, companyId: string = 'default'): CachedOfficeData | null {
    try {
      const key = this.getCacheKey(companyId, officeId);
      const stored = localStorage.getItem(key);
      if (!stored) return null;

      const data: CachedOfficeData = JSON.parse(stored);
      if (this.isExpired(data)) return null;

      return data;
    } catch {
      return null;
    }
  }

  /**
   * Load office data — returns cached if fresh, otherwise fetches all 3 in parallel.
   * Deduplicates concurrent requests for the same office.
   */
  async loadOfficeData(officeId: string, companyId: string = 'default'): Promise<CachedOfficeData> {
    // Check cache first
    const cached = this.getOfficeData(officeId, companyId);
    if (cached) return cached;

    // Deduplicate concurrent loads for the same office
    const loadKey = `${companyId}:${officeId}`;
    const existing = this.inFlightLoads.get(loadKey);
    if (existing) return existing;

    const loadPromise = this.fetchAndCache(officeId, companyId);
    this.inFlightLoads.set(loadKey, loadPromise);

    try {
      return await loadPromise;
    } finally {
      this.inFlightLoads.delete(loadKey);
    }
  }

  /**
   * Force refresh — bypasses cache and fetches fresh data
   */
  async refreshOfficeData(officeId: string, companyId: string = 'default'): Promise<CachedOfficeData> {
    return this.fetchAndCache(officeId, companyId);
  }

  /**
   * Get providers for an office (cached, fetch on miss)
   */
  async getProviders(officeId: string, companyId?: string): Promise<CachedProvider[]> {
    const data = await this.loadOfficeData(officeId, companyId);
    return data.providers;
  }

  /**
   * Get appointment types for an office (cached, fetch on miss)
   */
  async getAppointmentTypes(officeId: string, companyId?: string): Promise<CachedAppointmentType[]> {
    const data = await this.loadOfficeData(officeId, companyId);
    return data.appointmentTypes;
  }

  /**
   * Get insurance carriers for an office (cached, fetch on miss)
   */
  async getInsuranceCarriers(officeId: string, companyId?: string): Promise<CachedInsuranceCarrier[]> {
    const data = await this.loadOfficeData(officeId, companyId);
    return data.insuranceCarriers;
  }

  /**
   * Invalidate cache for a specific office
   */
  invalidateOffice(officeId: string, companyId: string = 'default'): void {
    const key = this.getCacheKey(companyId, officeId);
    localStorage.removeItem(key);
  }

  /**
   * Invalidate all cached office data
   */
  invalidateAll(): void {
    const keysToRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.startsWith(CACHE_PREFIX + ':')) {
        keysToRemove.push(key);
      }
    }
    keysToRemove.forEach(key => localStorage.removeItem(key));
  }

  // ============================================
  // Private
  // ============================================

  private async fetchAndCache(officeId: string, companyId: string): Promise<CachedOfficeData> {
    console.log(`[OfficeDataCache] Fetching data for office ${officeId} (company: ${companyId})`);

    // Fetch all three in parallel
    const [providersResult, appointmentTypesResult, carriersResult] = await Promise.allSettled([
      EyefinityService.getProviders({ officeId, pageSize: 100 }),
      EyefinityService.getAppointmentTypes(officeId),
      EyefinityService.getInsuranceCarriers(officeId),
    ]);

    // Map providers
    const providers: CachedProvider[] = providersResult.status === 'fulfilled'
      ? (providersResult.value.items || []).map((p: any) => ({
          staffId: p.staffId || p.id || '',
          guid: p.guid || p.staffId || '',
          firstName: p.firstName || '',
          lastName: p.lastName || '',
          fullName: p.fullName || `${p.firstName || ''} ${p.lastName || ''}`.trim(),
          providerType: p.providerType || '',
          isActive: p.isActive !== false,
          allowToBeScheduled: p.allowToBeScheduled !== false,
        }))
      : [];

    if (providersResult.status === 'rejected') {
      console.warn('[OfficeDataCache] Failed to fetch providers:', providersResult.reason);
    }

    // Map appointment types
    const appointmentTypes: CachedAppointmentType[] = appointmentTypesResult.status === 'fulfilled'
      ? (appointmentTypesResult.value || []).map((t: AppointmentType) => ({
          appointmentTypeId: t.appointmentTypeId,
          appointmentTypeUid: t.appointmentTypeUid,
          description: t.description,
          companyServiceName: t.companyServiceName,
          duration: t.duration,
          isActive: t.isActive,
        }))
      : [];

    if (appointmentTypesResult.status === 'rejected') {
      console.warn('[OfficeDataCache] Failed to fetch appointment types:', appointmentTypesResult.reason);
    }

    // Map insurance carriers
    const insuranceCarriers: CachedInsuranceCarrier[] = carriersResult.status === 'fulfilled'
      ? (carriersResult.value.items || carriersResult.value || []).map((c: any) => ({
          carrierId: String(c.InsuranceCarrierId || c.insuranceCarrierId || c.id || ''),
          carrierName: c.CompanyName || c.companyName || c.Name || c.name || '',
          planName: c.PlanName || c.planName || '',
          isActive: c.IsActive !== false && c.isActive !== false,
        }))
      : [];

    if (carriersResult.status === 'rejected') {
      console.warn('[OfficeDataCache] Failed to fetch insurance carriers:', carriersResult.reason);
    }

    const cacheEntry: CachedOfficeData = {
      officeId,
      companyId,
      cachedAt: Date.now(),
      providers,
      appointmentTypes,
      insuranceCarriers,
    };

    // Save to localStorage
    try {
      const key = this.getCacheKey(companyId, officeId);
      localStorage.setItem(key, JSON.stringify(cacheEntry));
      console.log(`[OfficeDataCache] Cached: ${providers.length} providers, ${appointmentTypes.length} apt types, ${insuranceCarriers.length} carriers`);
    } catch (e) {
      console.warn('[OfficeDataCache] Failed to save to localStorage:', e);
    }

    return cacheEntry;
  }
}

// Singleton export
const OfficeDataCacheService = new OfficeDataCacheServiceClass();
export default OfficeDataCacheService;
