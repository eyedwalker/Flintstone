/**
 * Escalation Alert Service
 * Sends real-time alerts via Twilio SMS/Voice when escalations are created
 * Integrates with the existing CommunicationService escalation queue
 */

import { sendSMS, makeVoiceCall, VoiceCallOptions } from '../lib/twilio';
import { CommunicationService, EscalationAlert } from './communicationService';

// ==================== TYPES ====================

export interface AlertRecipient {
  id: string;
  name: string;
  phone: string;
  email?: string;
  role: 'manager' | 'supervisor' | 'on-call' | 'all';
  notifyVia: ('sms' | 'voice' | 'email')[];
  priorityThreshold: 'low' | 'medium' | 'high' | 'urgent';
}

export interface AlertConfig {
  enabled: boolean;
  recipients: AlertRecipient[];
  escalationDelayMinutes: number;
  autoEscalateAfterMinutes: number;
  quietHours: {
    enabled: boolean;
    start: string; // HH:mm format
    end: string;
    emergencyOverride: boolean;
  };
  messageTemplates: {
    sms: string;
    voice: string;
  };
}

export interface AlertLog {
  id: string;
  escalationId: string;
  recipientId: string;
  recipientName: string;
  channel: 'sms' | 'voice' | 'email';
  status: 'pending' | 'sent' | 'delivered' | 'failed';
  sentAt: Date;
  error?: string;
}

// Storage keys
const CONFIG_KEY = 'escalation_alert_config';
const LOG_KEY = 'escalation_alert_log';

// Default configuration
const DEFAULT_CONFIG: AlertConfig = {
  enabled: true,
  recipients: [],
  escalationDelayMinutes: 0,
  autoEscalateAfterMinutes: 15,
  quietHours: {
    enabled: true,
    start: '22:00',
    end: '07:00',
    emergencyOverride: true,
  },
  messageTemplates: {
    sms: '🚨 ESCALATION: {patientName} - {reason}. Priority: {priority}. View in Timeline app.',
    voice: 'Attention. This is an escalation alert from the eye care office. Patient {patientName} requires immediate attention. Reason: {reason}. Priority level: {priority}. Please check the Timeline app for details.',
  },
};

// ==================== SERVICE ====================

class EscalationAlertServiceClass {
  private config: AlertConfig;
  private alertLog: AlertLog[] = [];

  constructor() {
    this.config = this.loadConfig();
    this.alertLog = this.loadAlertLog();
  }

  // ==================== CONFIGURATION ====================

  private loadConfig(): AlertConfig {
    const stored = localStorage.getItem(CONFIG_KEY);
    if (stored) {
      return { ...DEFAULT_CONFIG, ...JSON.parse(stored) };
    }
    return DEFAULT_CONFIG;
  }

  saveConfig(config: Partial<AlertConfig>): void {
    this.config = { ...this.config, ...config };
    localStorage.setItem(CONFIG_KEY, JSON.stringify(this.config));
  }

  getConfig(): AlertConfig {
    return { ...this.config };
  }

  // ==================== RECIPIENTS ====================

  addRecipient(recipient: Omit<AlertRecipient, 'id'>): AlertRecipient {
    const newRecipient: AlertRecipient = {
      ...recipient,
      id: `recipient_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    };
    this.config.recipients.push(newRecipient);
    this.saveConfig({ recipients: this.config.recipients });
    return newRecipient;
  }

  updateRecipient(id: string, updates: Partial<AlertRecipient>): void {
    const index = this.config.recipients.findIndex(r => r.id === id);
    if (index !== -1) {
      this.config.recipients[index] = { ...this.config.recipients[index], ...updates };
      this.saveConfig({ recipients: this.config.recipients });
    }
  }

  removeRecipient(id: string): void {
    this.config.recipients = this.config.recipients.filter(r => r.id !== id);
    this.saveConfig({ recipients: this.config.recipients });
  }

  getRecipients(): AlertRecipient[] {
    return [...this.config.recipients];
  }

  // ==================== ALERT SENDING ====================

  /**
   * Send alerts for a new escalation
   */
  async sendAlerts(escalation: EscalationAlert): Promise<AlertLog[]> {
    if (!this.config.enabled) {
      console.log('[EscalationAlert] Alerts disabled');
      return [];
    }

    // Check quiet hours
    if (this.isQuietHours() && !this.shouldOverrideQuietHours(escalation.priority)) {
      console.log('[EscalationAlert] In quiet hours, delaying non-urgent alert');
      // Could schedule for later - for now just log
      return [];
    }

    // Get eligible recipients based on priority
    const recipients = this.getEligibleRecipients(escalation.priority);
    if (recipients.length === 0) {
      console.log('[EscalationAlert] No eligible recipients for priority:', escalation.priority);
      return [];
    }

    const logs: AlertLog[] = [];

    for (const recipient of recipients) {
      for (const channel of recipient.notifyVia) {
        try {
          const log = await this.sendAlert(escalation, recipient, channel);
          logs.push(log);
        } catch (error: any) {
          console.error(`[EscalationAlert] Failed to send ${channel} to ${recipient.name}:`, error);
          logs.push(this.createAlertLog(escalation.id, recipient, channel, 'failed', error?.message));
        }
      }
    }

    return logs;
  }

  /**
   * Send a single alert
   */
  private async sendAlert(
    escalation: EscalationAlert,
    recipient: AlertRecipient,
    channel: 'sms' | 'voice' | 'email'
  ): Promise<AlertLog> {
    const message = this.formatMessage(escalation, channel);

    console.log(`[EscalationAlert] Sending ${channel} to ${recipient.name} (${recipient.phone})`);

    let status: AlertLog['status'] = 'pending';
    let error: string | undefined;

    switch (channel) {
      case 'sms':
        const smsResult = await sendSMS(recipient.phone, message);
        status = smsResult.success ? 'sent' : 'failed';
        error = smsResult.error;
        break;

      case 'voice':
        const voiceOptions: VoiceCallOptions = {
          voice: 'Polly.Joanna',
          record: false,
          timeout: 30,
        };
        const voiceResult = await makeVoiceCall(recipient.phone, message, voiceOptions);
        status = voiceResult.success ? 'sent' : 'failed';
        error = voiceResult.error;
        break;

      case 'email':
        // Email would use SES - for now just log
        console.log(`[EscalationAlert] Email alert to ${recipient.email}: ${message}`);
        status = 'sent';
        break;
    }

    const log = this.createAlertLog(escalation.id, recipient, channel, status, error);
    this.saveAlertLog(log);
    return log;
  }

  /**
   * Format alert message
   */
  private formatMessage(escalation: EscalationAlert, channel: 'sms' | 'voice' | 'email'): string {
    const template = channel === 'voice' 
      ? this.config.messageTemplates.voice 
      : this.config.messageTemplates.sms;

    return template
      .replace('{patientName}', escalation.patientName)
      .replace('{reason}', escalation.reason)
      .replace('{priority}', escalation.priority.toUpperCase())
      .replace('{source}', escalation.source)
      .replace('{id}', escalation.id);
  }

  /**
   * Get recipients eligible for this priority level
   */
  private getEligibleRecipients(priority: EscalationAlert['priority']): AlertRecipient[] {
    const priorityLevels = ['low', 'medium', 'high', 'urgent'];
    const priorityIndex = priorityLevels.indexOf(priority);

    return this.config.recipients.filter(r => {
      const thresholdIndex = priorityLevels.indexOf(r.priorityThreshold);
      return priorityIndex >= thresholdIndex;
    });
  }

  /**
   * Check if currently in quiet hours
   */
  private isQuietHours(): boolean {
    if (!this.config.quietHours.enabled) return false;

    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();

    const [startH, startM] = this.config.quietHours.start.split(':').map(Number);
    const [endH, endM] = this.config.quietHours.end.split(':').map(Number);
    const startMinutes = startH * 60 + startM;
    const endMinutes = endH * 60 + endM;

    // Handle overnight quiet hours (e.g., 22:00 - 07:00)
    if (startMinutes > endMinutes) {
      return currentTime >= startMinutes || currentTime < endMinutes;
    }
    return currentTime >= startMinutes && currentTime < endMinutes;
  }

  /**
   * Check if priority should override quiet hours
   */
  private shouldOverrideQuietHours(priority: EscalationAlert['priority']): boolean {
    return this.config.quietHours.emergencyOverride && 
           (priority === 'urgent' || priority === 'high');
  }

  // ==================== LOGGING ====================

  private createAlertLog(
    escalationId: string,
    recipient: AlertRecipient,
    channel: 'sms' | 'voice' | 'email',
    status: AlertLog['status'],
    error?: string
  ): AlertLog {
    return {
      id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      escalationId,
      recipientId: recipient.id,
      recipientName: recipient.name,
      channel,
      status,
      sentAt: new Date(),
      error,
    };
  }

  private loadAlertLog(): AlertLog[] {
    const stored = localStorage.getItem(LOG_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  private saveAlertLog(log: AlertLog): void {
    this.alertLog.push(log);
    // Keep last 500 logs
    if (this.alertLog.length > 500) {
      this.alertLog = this.alertLog.slice(-500);
    }
    localStorage.setItem(LOG_KEY, JSON.stringify(this.alertLog));
  }

  getAlertLog(escalationId?: string): AlertLog[] {
    if (escalationId) {
      return this.alertLog.filter(l => l.escalationId === escalationId);
    }
    return [...this.alertLog];
  }

  // ==================== INTEGRATION ====================

  /**
   * Create escalation and send alerts (combines CommunicationService + alerts)
   */
  async createEscalationWithAlerts(
    patientId: string,
    patientName: string,
    appointmentId: string,
    reason: string,
    priority: EscalationAlert['priority'] = 'medium',
    options?: {
      source?: EscalationAlert['source'];
      transcript?: string;
      callDuration?: number;
      callRecordingUrl?: string;
      communicationId?: string;
      aiConfidenceScore?: number;
      aiSuggestedAction?: string;
    }
  ): Promise<{ escalation: EscalationAlert; alerts: AlertLog[] }> {
    // Create escalation in CommunicationService
    const escalation = CommunicationService.createEscalation(
      patientId,
      patientName,
      appointmentId,
      reason,
      priority,
      options
    );

    // Send alerts
    const alerts = await this.sendAlerts(escalation);

    return { escalation, alerts };
  }

  /**
   * Auto-escalate old unacknowledged escalations
   */
  async checkAndAutoEscalate(): Promise<void> {
    const activeEscalations = CommunicationService.getActiveEscalations();
    const now = new Date();

    for (const escalation of activeEscalations) {
      const createdAt = new Date(escalation.createdAt);
      const minutesSinceCreation = (now.getTime() - createdAt.getTime()) / (1000 * 60);

      if (minutesSinceCreation >= this.config.autoEscalateAfterMinutes) {
        // Check if we've already sent follow-up alerts
        const existingAlerts = this.getAlertLog(escalation.id);
        const recentAlert = existingAlerts.find(a => {
          const alertAge = (now.getTime() - new Date(a.sentAt).getTime()) / (1000 * 60);
          return alertAge < this.config.autoEscalateAfterMinutes;
        });

        if (!recentAlert) {
          console.log(`[EscalationAlert] Auto-escalating: ${escalation.id}`);
          
          // Upgrade priority if not already urgent
          const upgradedPriority: EscalationAlert['priority'] = 
            escalation.priority === 'urgent' ? 'urgent' :
            escalation.priority === 'high' ? 'urgent' :
            escalation.priority === 'medium' ? 'high' : 'medium';

          // Send follow-up alerts with upgraded priority
          await this.sendAlerts({ ...escalation, priority: upgradedPriority });
        }
      }
    }
  }

  /**
   * Get escalation statistics
   */
  getStats(): {
    totalAlerts: number;
    successRate: number;
    byChannel: Record<string, { sent: number; failed: number }>;
    averageResponseTime?: number;
  } {
    const logs = this.getAlertLog();
    const byChannel: Record<string, { sent: number; failed: number }> = {
      sms: { sent: 0, failed: 0 },
      voice: { sent: 0, failed: 0 },
      email: { sent: 0, failed: 0 },
    };

    let successCount = 0;

    for (const log of logs) {
      if (log.status === 'sent' || log.status === 'delivered') {
        byChannel[log.channel].sent++;
        successCount++;
      } else if (log.status === 'failed') {
        byChannel[log.channel].failed++;
      }
    }

    return {
      totalAlerts: logs.length,
      successRate: logs.length > 0 ? successCount / logs.length : 0,
      byChannel,
    };
  }
}

export const EscalationAlertService = new EscalationAlertServiceClass();

// Start auto-escalation check every 5 minutes
if (typeof window !== 'undefined') {
  setInterval(() => {
    EscalationAlertService.checkAndAutoEscalate();
  }, 5 * 60 * 1000);
}
