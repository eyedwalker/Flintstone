// AI Knowledge Base Service
// Stores and manages information to educate the AI for better responses

export interface PracticeInfo {
  name: string;
  description?: string;
  tagline?: string;
  yearEstablished?: number;
  specialties?: string[];
  services?: string[];
  languages?: string[];
  acceptingNewPatients?: boolean;
}

export interface LocationInfo {
  id: string;
  name: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  phone: string;
  fax?: string;
  email?: string;
  hours: {
    monday?: string;
    tuesday?: string;
    wednesday?: string;
    thursday?: string;
    friday?: string;
    saturday?: string;
    sunday?: string;
  };
  directions?: string;
  parking?: string;
  accessibility?: string;
  isMainLocation?: boolean;
}

export interface ProviderInfo {
  id: string;
  name: string;
  title: string;
  credentials?: string[];
  specialty?: string;
  bio?: string;
  education?: string[];
  certifications?: string[];
  languages?: string[];
  acceptingNewPatients?: boolean;
  photo?: string;
}

export interface InsuranceInfo {
  id: string;
  name: string;
  planTypes?: string[];
  isAccepted: boolean;
  notes?: string;
  verificationPhone?: string;
  website?: string;
}

export interface PricingInfo {
  id: string;
  service: string;
  description?: string;
  priceRange?: string;
  insuranceCoverage?: string;
  notes?: string;
}

export interface FAQEntry {
  id: string;
  question: string;
  answer: string;
  category: 'appointments' | 'insurance' | 'services' | 'billing' | 'general' | 'emergency' | 'products' | 'custom';
  keywords?: string[];
  priority?: number;
}

export interface CustomKnowledge {
  id: string;
  title: string;
  content: string;
  category: string;
  keywords?: string[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AIKnowledgeBase {
  practice: PracticeInfo;
  locations: LocationInfo[];
  providers: ProviderInfo[];
  insurances: InsuranceInfo[];
  pricing: PricingInfo[];
  faqs: FAQEntry[];
  customKnowledge: CustomKnowledge[];
  lastUpdated: string;
}

// Default knowledge base structure
const DEFAULT_KNOWLEDGE_BASE: AIKnowledgeBase = {
  practice: {
    name: 'Vision Care Center',
    description: 'Comprehensive eye care for the whole family',
    tagline: 'Your vision is our focus',
    specialties: ['Comprehensive Eye Exams', 'Contact Lens Fitting', 'Pediatric Eye Care', 'Glaucoma Management'],
    services: ['Eye Exams', 'Contact Lenses', 'Glasses', 'LASIK Consultations', 'Dry Eye Treatment'],
    languages: ['English', 'Spanish'],
    acceptingNewPatients: true,
  },
  locations: [
    {
      id: 'loc_main',
      name: 'Main Office',
      address: '123 Vision Way, Suite 100',
      city: 'Dallas',
      state: 'TX',
      zip: '75201',
      phone: '(555) 555-1234',
      email: 'info@visioncare.com',
      hours: {
        monday: '8:00 AM - 5:00 PM',
        tuesday: '8:00 AM - 5:00 PM',
        wednesday: '8:00 AM - 5:00 PM',
        thursday: '8:00 AM - 5:00 PM',
        friday: '8:00 AM - 5:00 PM',
        saturday: '9:00 AM - 1:00 PM',
        sunday: 'Closed',
      },
      parking: 'Free parking available in the building lot',
      accessibility: 'Wheelchair accessible entrance and exam rooms',
      isMainLocation: true,
    },
  ],
  providers: [
    {
      id: 'prov_1',
      name: 'Dr. Sarah Johnson',
      title: 'OD',
      credentials: ['Doctor of Optometry'],
      specialty: 'Comprehensive Eye Care',
      bio: 'Dr. Johnson has been providing quality eye care for over 15 years.',
      education: ['University of Houston College of Optometry'],
      languages: ['English'],
      acceptingNewPatients: true,
    },
  ],
  insurances: [
    { id: 'ins_1', name: 'VSP', planTypes: ['VSP Choice', 'VSP Signature'], isAccepted: true },
    { id: 'ins_2', name: 'EyeMed', planTypes: ['Access', 'Insight'], isAccepted: true },
    { id: 'ins_3', name: 'Spectera', isAccepted: true },
    { id: 'ins_4', name: 'Medicare', isAccepted: true, notes: 'Accepted for medical eye conditions' },
    { id: 'ins_5', name: 'Davis Vision', isAccepted: true },
    { id: 'ins_6', name: 'Cigna Vision', isAccepted: true },
    { id: 'ins_7', name: 'Aetna Vision', isAccepted: true },
    { id: 'ins_8', name: 'Blue Cross Blue Shield', isAccepted: true, notes: 'Medical coverage only' },
  ],
  pricing: [
    {
      id: 'price_1',
      service: 'Comprehensive Eye Exam',
      description: 'Complete vision and eye health evaluation',
      priceRange: '$99 - $149',
      insuranceCoverage: 'Usually covered with vision insurance copay',
    },
    {
      id: 'price_2',
      service: 'Contact Lens Exam',
      description: 'Eye exam plus contact lens fitting',
      priceRange: '$149 - $199',
      insuranceCoverage: 'Fitting fee may apply with insurance',
    },
    {
      id: 'price_3',
      service: 'Glasses (frames + lenses)',
      description: 'Wide selection of frames with prescription lenses',
      priceRange: '$150 - $500+',
      insuranceCoverage: 'Insurance typically covers portion of frames and lenses',
    },
  ],
  faqs: [
    {
      id: 'faq_1',
      question: 'How often should I get an eye exam?',
      answer: 'We recommend annual comprehensive eye exams for most adults. Children, seniors, and those with certain conditions may need more frequent exams.',
      category: 'appointments',
      keywords: ['eye exam', 'frequency', 'how often', 'checkup'],
      priority: 1,
    },
    {
      id: 'faq_2',
      question: 'What insurance do you accept?',
      answer: 'We accept most major vision insurance plans including VSP, EyeMed, Spectera, Davis Vision, and more. We also accept Medicare for medical eye conditions. Please call to verify your specific plan.',
      category: 'insurance',
      keywords: ['insurance', 'accept', 'coverage', 'plans'],
      priority: 1,
    },
    {
      id: 'faq_3',
      question: 'Do I need an appointment?',
      answer: 'Yes, we recommend scheduling an appointment to ensure we can provide you with dedicated time and attention. Walk-ins may be accommodated based on availability.',
      category: 'appointments',
      keywords: ['appointment', 'walk-in', 'schedule', 'book'],
      priority: 1,
    },
    {
      id: 'faq_4',
      question: 'How long does an eye exam take?',
      answer: 'A comprehensive eye exam typically takes 30-45 minutes. Contact lens fittings may require additional time. Please plan to arrive 15 minutes early for paperwork.',
      category: 'appointments',
      keywords: ['how long', 'duration', 'time', 'exam length'],
      priority: 2,
    },
    {
      id: 'faq_5',
      question: 'Can I use my FSA/HSA?',
      answer: 'Yes! You can use your Flexible Spending Account (FSA) or Health Savings Account (HSA) for eye exams, glasses, contacts, and other qualified vision expenses.',
      category: 'billing',
      keywords: ['fsa', 'hsa', 'flexible spending', 'health savings'],
      priority: 2,
    },
    {
      id: 'faq_6',
      question: 'What should I bring to my appointment?',
      answer: 'Please bring your insurance card, photo ID, current glasses or contacts, a list of medications, and any previous eye records if available.',
      category: 'appointments',
      keywords: ['bring', 'what to bring', 'prepare', 'appointment'],
      priority: 1,
    },
    {
      id: 'faq_7',
      question: 'Do you see children?',
      answer: 'Yes, we provide comprehensive pediatric eye care. We recommend children have their first eye exam around age 1, again at age 3, and before starting school.',
      category: 'services',
      keywords: ['children', 'kids', 'pediatric', 'child eye exam'],
      priority: 2,
    },
    {
      id: 'faq_8',
      question: 'What if I have an eye emergency?',
      answer: 'For eye emergencies during business hours, call us immediately and we will do our best to see you right away. For after-hours emergencies, please go to your nearest emergency room.',
      category: 'emergency',
      keywords: ['emergency', 'urgent', 'injury', 'red eye', 'pain'],
      priority: 1,
    },
  ],
  customKnowledge: [],
  lastUpdated: new Date().toISOString(),
};

class AIKnowledgeBaseServiceClass {
  private storageKey = 'aiKnowledgeBase';

  getKnowledgeBase(): AIKnowledgeBase {
    const stored = localStorage.getItem(this.storageKey);
    if (stored) {
      return JSON.parse(stored);
    }
    this.saveKnowledgeBase(DEFAULT_KNOWLEDGE_BASE);
    return DEFAULT_KNOWLEDGE_BASE;
  }

  saveKnowledgeBase(kb: AIKnowledgeBase): void {
    kb.lastUpdated = new Date().toISOString();
    localStorage.setItem(this.storageKey, JSON.stringify(kb));
  }

  // Practice Info
  getPracticeInfo(): PracticeInfo {
    return this.getKnowledgeBase().practice;
  }

  updatePracticeInfo(info: Partial<PracticeInfo>): void {
    const kb = this.getKnowledgeBase();
    kb.practice = { ...kb.practice, ...info };
    this.saveKnowledgeBase(kb);
  }

  // Locations
  getLocations(): LocationInfo[] {
    return this.getKnowledgeBase().locations;
  }

  addLocation(location: Omit<LocationInfo, 'id'>): LocationInfo {
    const kb = this.getKnowledgeBase();
    const newLocation: LocationInfo = {
      ...location,
      id: `loc_${Date.now()}`,
    };
    kb.locations.push(newLocation);
    this.saveKnowledgeBase(kb);
    return newLocation;
  }

  updateLocation(id: string, updates: Partial<LocationInfo>): void {
    const kb = this.getKnowledgeBase();
    const index = kb.locations.findIndex(l => l.id === id);
    if (index !== -1) {
      kb.locations[index] = { ...kb.locations[index], ...updates };
      this.saveKnowledgeBase(kb);
    }
  }

  deleteLocation(id: string): void {
    const kb = this.getKnowledgeBase();
    kb.locations = kb.locations.filter(l => l.id !== id);
    this.saveKnowledgeBase(kb);
  }

  // Providers
  getProviders(): ProviderInfo[] {
    return this.getKnowledgeBase().providers;
  }

  addProvider(provider: Omit<ProviderInfo, 'id'>): ProviderInfo {
    const kb = this.getKnowledgeBase();
    const newProvider: ProviderInfo = {
      ...provider,
      id: `prov_${Date.now()}`,
    };
    kb.providers.push(newProvider);
    this.saveKnowledgeBase(kb);
    return newProvider;
  }

  updateProvider(id: string, updates: Partial<ProviderInfo>): void {
    const kb = this.getKnowledgeBase();
    const index = kb.providers.findIndex(p => p.id === id);
    if (index !== -1) {
      kb.providers[index] = { ...kb.providers[index], ...updates };
      this.saveKnowledgeBase(kb);
    }
  }

  deleteProvider(id: string): void {
    const kb = this.getKnowledgeBase();
    kb.providers = kb.providers.filter(p => p.id !== id);
    this.saveKnowledgeBase(kb);
  }

  // Insurance
  getInsurances(): InsuranceInfo[] {
    return this.getKnowledgeBase().insurances;
  }

  getAcceptedInsurances(): InsuranceInfo[] {
    return this.getInsurances().filter(i => i.isAccepted);
  }

  addInsurance(insurance: Omit<InsuranceInfo, 'id'>): InsuranceInfo {
    const kb = this.getKnowledgeBase();
    const newInsurance: InsuranceInfo = {
      ...insurance,
      id: `ins_${Date.now()}`,
    };
    kb.insurances.push(newInsurance);
    this.saveKnowledgeBase(kb);
    return newInsurance;
  }

  updateInsurance(id: string, updates: Partial<InsuranceInfo>): void {
    const kb = this.getKnowledgeBase();
    const index = kb.insurances.findIndex(i => i.id === id);
    if (index !== -1) {
      kb.insurances[index] = { ...kb.insurances[index], ...updates };
      this.saveKnowledgeBase(kb);
    }
  }

  deleteInsurance(id: string): void {
    const kb = this.getKnowledgeBase();
    kb.insurances = kb.insurances.filter(i => i.id !== id);
    this.saveKnowledgeBase(kb);
  }

  // Pricing
  getPricing(): PricingInfo[] {
    return this.getKnowledgeBase().pricing;
  }

  addPricing(pricing: Omit<PricingInfo, 'id'>): PricingInfo {
    const kb = this.getKnowledgeBase();
    const newPricing: PricingInfo = {
      ...pricing,
      id: `price_${Date.now()}`,
    };
    kb.pricing.push(newPricing);
    this.saveKnowledgeBase(kb);
    return newPricing;
  }

  updatePricing(id: string, updates: Partial<PricingInfo>): void {
    const kb = this.getKnowledgeBase();
    const index = kb.pricing.findIndex(p => p.id === id);
    if (index !== -1) {
      kb.pricing[index] = { ...kb.pricing[index], ...updates };
      this.saveKnowledgeBase(kb);
    }
  }

  deletePricing(id: string): void {
    const kb = this.getKnowledgeBase();
    kb.pricing = kb.pricing.filter(p => p.id !== id);
    this.saveKnowledgeBase(kb);
  }

  // FAQs
  getFAQs(): FAQEntry[] {
    return this.getKnowledgeBase().faqs;
  }

  getFAQsByCategory(category: FAQEntry['category']): FAQEntry[] {
    return this.getFAQs().filter(f => f.category === category);
  }

  searchFAQs(query: string): FAQEntry[] {
    const lowerQuery = query.toLowerCase();
    return this.getFAQs().filter(faq => 
      faq.question.toLowerCase().includes(lowerQuery) ||
      faq.answer.toLowerCase().includes(lowerQuery) ||
      faq.keywords?.some(k => k.toLowerCase().includes(lowerQuery))
    ).sort((a, b) => (b.priority || 0) - (a.priority || 0));
  }

  addFAQ(faq: Omit<FAQEntry, 'id'>): FAQEntry {
    const kb = this.getKnowledgeBase();
    const newFAQ: FAQEntry = {
      ...faq,
      id: `faq_${Date.now()}`,
    };
    kb.faqs.push(newFAQ);
    this.saveKnowledgeBase(kb);
    return newFAQ;
  }

  updateFAQ(id: string, updates: Partial<FAQEntry>): void {
    const kb = this.getKnowledgeBase();
    const index = kb.faqs.findIndex(f => f.id === id);
    if (index !== -1) {
      kb.faqs[index] = { ...kb.faqs[index], ...updates };
      this.saveKnowledgeBase(kb);
    }
  }

  deleteFAQ(id: string): void {
    const kb = this.getKnowledgeBase();
    kb.faqs = kb.faqs.filter(f => f.id !== id);
    this.saveKnowledgeBase(kb);
  }

  // Custom Knowledge
  getCustomKnowledge(): CustomKnowledge[] {
    return this.getKnowledgeBase().customKnowledge.filter(k => k.isActive);
  }

  addCustomKnowledge(knowledge: Omit<CustomKnowledge, 'id' | 'createdAt' | 'updatedAt'>): CustomKnowledge {
    const kb = this.getKnowledgeBase();
    const newKnowledge: CustomKnowledge = {
      ...knowledge,
      id: `custom_${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    kb.customKnowledge.push(newKnowledge);
    this.saveKnowledgeBase(kb);
    return newKnowledge;
  }

  updateCustomKnowledge(id: string, updates: Partial<CustomKnowledge>): void {
    const kb = this.getKnowledgeBase();
    const index = kb.customKnowledge.findIndex(k => k.id === id);
    if (index !== -1) {
      kb.customKnowledge[index] = {
        ...kb.customKnowledge[index],
        ...updates,
        updatedAt: new Date().toISOString(),
      };
      this.saveKnowledgeBase(kb);
    }
  }

  deleteCustomKnowledge(id: string): void {
    const kb = this.getKnowledgeBase();
    kb.customKnowledge = kb.customKnowledge.filter(k => k.id !== id);
    this.saveKnowledgeBase(kb);
  }

  // Generate AI Context from Knowledge Base
  generateAIContext(): string {
    const kb = this.getKnowledgeBase();
    
    let context = `## Practice Knowledge Base\n\n`;
    
    // Practice Info
    context += `### About the Practice\n`;
    context += `- Name: ${kb.practice.name}\n`;
    if (kb.practice.description) context += `- Description: ${kb.practice.description}\n`;
    if (kb.practice.specialties?.length) context += `- Specialties: ${kb.practice.specialties.join(', ')}\n`;
    if (kb.practice.services?.length) context += `- Services: ${kb.practice.services.join(', ')}\n`;
    if (kb.practice.languages?.length) context += `- Languages: ${kb.practice.languages.join(', ')}\n`;
    context += `- Accepting New Patients: ${kb.practice.acceptingNewPatients ? 'Yes' : 'No'}\n\n`;

    // Locations
    context += `### Locations\n`;
    kb.locations.forEach(loc => {
      context += `**${loc.name}**${loc.isMainLocation ? ' (Main Office)' : ''}\n`;
      context += `- Address: ${loc.address}, ${loc.city}, ${loc.state} ${loc.zip}\n`;
      context += `- Phone: ${loc.phone}\n`;
      if (loc.email) context += `- Email: ${loc.email}\n`;
      context += `- Hours:\n`;
      Object.entries(loc.hours).forEach(([day, hours]) => {
        if (hours) context += `  - ${day.charAt(0).toUpperCase() + day.slice(1)}: ${hours}\n`;
      });
      if (loc.parking) context += `- Parking: ${loc.parking}\n`;
      context += `\n`;
    });

    // Providers
    context += `### Providers\n`;
    kb.providers.forEach(prov => {
      context += `**${prov.name}, ${prov.title}**\n`;
      if (prov.specialty) context += `- Specialty: ${prov.specialty}\n`;
      if (prov.bio) context += `- Bio: ${prov.bio}\n`;
      if (prov.languages?.length) context += `- Languages: ${prov.languages.join(', ')}\n`;
      context += `- Accepting New Patients: ${prov.acceptingNewPatients ? 'Yes' : 'No'}\n\n`;
    });

    // Insurance
    context += `### Accepted Insurance\n`;
    const accepted = kb.insurances.filter(i => i.isAccepted);
    accepted.forEach(ins => {
      context += `- ${ins.name}`;
      if (ins.planTypes?.length) context += ` (Plans: ${ins.planTypes.join(', ')})`;
      if (ins.notes) context += ` - Note: ${ins.notes}`;
      context += `\n`;
    });
    context += `\n`;

    // Pricing
    if (kb.pricing.length > 0) {
      context += `### Pricing Information\n`;
      kb.pricing.forEach(price => {
        context += `**${price.service}**\n`;
        if (price.description) context += `- ${price.description}\n`;
        if (price.priceRange) context += `- Price Range: ${price.priceRange}\n`;
        if (price.insuranceCoverage) context += `- Insurance: ${price.insuranceCoverage}\n`;
        context += `\n`;
      });
    }

    // FAQs
    context += `### Frequently Asked Questions\n`;
    kb.faqs.forEach(faq => {
      context += `**Q: ${faq.question}**\n`;
      context += `A: ${faq.answer}\n\n`;
    });

    // Custom Knowledge
    if (kb.customKnowledge.filter(k => k.isActive).length > 0) {
      context += `### Additional Information\n`;
      kb.customKnowledge.filter(k => k.isActive).forEach(custom => {
        context += `**${custom.title}**\n`;
        context += `${custom.content}\n\n`;
      });
    }

    return context;
  }

  // Reset to defaults
  resetToDefaults(): void {
    this.saveKnowledgeBase(DEFAULT_KNOWLEDGE_BASE);
  }
}

export const AIKnowledgeBaseService = new AIKnowledgeBaseServiceClass();
export default AIKnowledgeBaseService;
