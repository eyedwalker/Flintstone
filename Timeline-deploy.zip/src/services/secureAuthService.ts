/**
 * Secure Authentication Service
 * Handles user authentication with password hashing, JWT tokens, and session management
 * 
 * IMPORTANT: In production, password hashing and JWT signing should happen server-side.
 * This implementation provides the structure for a secure auth flow.
 */

import { MFAService } from './mfaService';
import { InviteService } from './inviteService';

// Types
export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: 'admin' | 'manager' | 'associate';
  passwordHash: string;
  salt: string;
  mfaEnabled: boolean;
  mfaSecret?: string;
  createdAt: string;
  updatedAt: string;
  lastLogin?: string;
  failedLoginAttempts: number;
  lockedUntil?: string;
  mustChangePassword: boolean;
  passwordChangedAt?: string;
}

export interface Session {
  id: string;
  userId: string;
  token: string;
  refreshToken: string;
  expiresAt: string;
  createdAt: string;
  ipAddress?: string;
  userAgent?: string;
}

export interface AuthResult {
  success: boolean;
  error?: string;
  requiresMfa?: boolean;
  mfaToken?: string;
  user?: Omit<User, 'passwordHash' | 'salt' | 'mfaSecret'>;
  session?: Session;
}

export interface RegistrationData {
  inviteToken: string;
  email: string;
  firstName: string;
  lastName: string;
  password: string;
  confirmPassword: string;
}

// Constants
const USERS_KEY = 'secure_users';
const SESSIONS_KEY = 'secure_sessions';
const MFA_PENDING_KEY = 'mfa_pending';
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_DURATION_MINUTES = 15;
const SESSION_DURATION_HOURS = 8;
const REFRESH_TOKEN_DURATION_DAYS = 7;
const PASSWORD_MIN_LENGTH = 12;
const PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/;

class SecureAuthServiceClass {
  
  // ============================================
  // PASSWORD SECURITY
  // ============================================

  /**
   * Generate a random salt for password hashing
   * In production, use crypto.getRandomValues or server-side crypto
   */
  private generateSalt(): string {
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return Array.from(array, b => b.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Hash password with salt using SHA-256
   * In production, use bcrypt or Argon2 on the server
   */
  private async hashPassword(password: string, salt: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(password + salt);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Verify password against stored hash
   */
  private async verifyPassword(password: string, salt: string, hash: string): Promise<boolean> {
    const computedHash = await this.hashPassword(password, salt);
    return computedHash === hash;
  }

  /**
   * Validate password strength
   */
  validatePassword(password: string): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    
    if (password.length < PASSWORD_MIN_LENGTH) {
      errors.push(`Password must be at least ${PASSWORD_MIN_LENGTH} characters`);
    }
    if (!/[a-z]/.test(password)) {
      errors.push('Password must contain at least one lowercase letter');
    }
    if (!/[A-Z]/.test(password)) {
      errors.push('Password must contain at least one uppercase letter');
    }
    if (!/\d/.test(password)) {
      errors.push('Password must contain at least one number');
    }
    if (!/[@$!%*?&]/.test(password)) {
      errors.push('Password must contain at least one special character (@$!%*?&)');
    }
    
    return { valid: errors.length === 0, errors };
  }

  // ============================================
  // TOKEN GENERATION
  // ============================================

  /**
   * Generate a secure random token
   */
  private generateToken(length: number = 64): string {
    const array = new Uint8Array(length);
    crypto.getRandomValues(array);
    return Array.from(array, b => b.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Generate JWT-like token (simplified for demo - use real JWT in production)
   */
  private generateSessionToken(userId: string, expiresAt: Date): string {
    const payload = {
      sub: userId,
      exp: expiresAt.getTime(),
      iat: Date.now(),
      jti: this.generateToken(16),
    };
    // In production, sign this with a secret key
    return btoa(JSON.stringify(payload));
  }

  // ============================================
  // USER MANAGEMENT
  // ============================================

  /**
   * Get all users (internal use)
   */
  private getUsers(): User[] {
    const stored = localStorage.getItem(USERS_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  /**
   * Save users
   */
  private saveUsers(users: User[]): void {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }

  /**
   * Get user by email
   */
  getUserByEmail(email: string): User | null {
    const users = this.getUsers();
    return users.find(u => u.email.toLowerCase() === email.toLowerCase()) || null;
  }

  /**
   * Get user by ID
   */
  getUserById(id: string): User | null {
    const users = this.getUsers();
    return users.find(u => u.id === id) || null;
  }

  /**
   * Get user safe data (without sensitive fields)
   */
  getSafeUser(user: User): Omit<User, 'passwordHash' | 'salt' | 'mfaSecret'> {
    const { passwordHash, salt, mfaSecret, ...safeUser } = user;
    return safeUser;
  }

  // ============================================
  // REGISTRATION
  // ============================================

  /**
   * Register a new user with invite token
   */
  async register(data: RegistrationData): Promise<AuthResult> {
    // Validate invite token
    const invite = InviteService.validateInvite(data.inviteToken);
    if (!invite.valid || !invite.invite) {
      return { success: false, error: invite.error || 'Invalid invite token' };
    }

    // Check email matches invite
    if (invite.invite.email.toLowerCase() !== data.email.toLowerCase()) {
      return { success: false, error: 'Email does not match invitation' };
    }

    // Check if user already exists
    if (this.getUserByEmail(data.email)) {
      return { success: false, error: 'An account with this email already exists' };
    }

    // Validate password
    if (data.password !== data.confirmPassword) {
      return { success: false, error: 'Passwords do not match' };
    }

    const passwordValidation = this.validatePassword(data.password);
    if (!passwordValidation.valid) {
      return { success: false, error: passwordValidation.errors.join('. ') };
    }

    // Create user
    const salt = this.generateSalt();
    const passwordHash = await this.hashPassword(data.password, salt);

    const newUser: User = {
      id: this.generateToken(16),
      email: data.email.toLowerCase(),
      firstName: data.firstName,
      lastName: data.lastName,
      role: invite.invite.role,
      passwordHash,
      salt,
      mfaEnabled: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      failedLoginAttempts: 0,
      mustChangePassword: false,
    };

    const users = this.getUsers();
    users.push(newUser);
    this.saveUsers(users);

    // Mark invite as used
    InviteService.markInviteUsed(data.inviteToken);

    return {
      success: true,
      user: this.getSafeUser(newUser),
    };
  }

  // ============================================
  // LOGIN
  // ============================================

  /**
   * Login with email and password
   */
  async login(email: string, password: string, ipAddress?: string, userAgent?: string): Promise<AuthResult> {
    const user = this.getUserByEmail(email);

    if (!user) {
      // Don't reveal if user exists
      return { success: false, error: 'Invalid email or password' };
    }

    // Check if account is locked
    if (user.lockedUntil) {
      const lockExpiry = new Date(user.lockedUntil);
      if (lockExpiry > new Date()) {
        const minutesLeft = Math.ceil((lockExpiry.getTime() - Date.now()) / 60000);
        return { 
          success: false, 
          error: `Account is locked. Try again in ${minutesLeft} minute(s)` 
        };
      } else {
        // Lock expired, reset
        user.lockedUntil = undefined;
        user.failedLoginAttempts = 0;
      }
    }

    // Verify password
    const passwordValid = await this.verifyPassword(password, user.salt, user.passwordHash);

    if (!passwordValid) {
      // Increment failed attempts
      user.failedLoginAttempts++;
      
      if (user.failedLoginAttempts >= MAX_LOGIN_ATTEMPTS) {
        user.lockedUntil = new Date(Date.now() + LOCKOUT_DURATION_MINUTES * 60000).toISOString();
        this.updateUser(user);
        return { 
          success: false, 
          error: `Too many failed attempts. Account locked for ${LOCKOUT_DURATION_MINUTES} minutes` 
        };
      }

      this.updateUser(user);
      const attemptsLeft = MAX_LOGIN_ATTEMPTS - user.failedLoginAttempts;
      return { 
        success: false, 
        error: `Invalid email or password. ${attemptsLeft} attempt(s) remaining` 
      };
    }

    // Password correct - reset failed attempts
    user.failedLoginAttempts = 0;
    user.lockedUntil = undefined;

    // Check if MFA is enabled
    if (user.mfaEnabled && user.mfaSecret) {
      // Generate MFA pending token
      const mfaToken = this.generateToken(32);
      const pending = {
        userId: user.id,
        token: mfaToken,
        expiresAt: new Date(Date.now() + 5 * 60000).toISOString(), // 5 minutes
        ipAddress,
        userAgent,
      };
      
      const pendingList = this.getMfaPending();
      pendingList.push(pending);
      localStorage.setItem(MFA_PENDING_KEY, JSON.stringify(pendingList));

      return {
        success: true,
        requiresMfa: true,
        mfaToken,
      };
    }

    // No MFA - create session
    return this.createSession(user, ipAddress, userAgent);
  }

  /**
   * Verify MFA code and complete login
   */
  async verifyMfaAndLogin(mfaToken: string, code: string): Promise<AuthResult> {
    const pendingList = this.getMfaPending();
    const pendingIndex = pendingList.findIndex(p => p.token === mfaToken);

    if (pendingIndex === -1) {
      return { success: false, error: 'Invalid or expired MFA session' };
    }

    const pending = pendingList[pendingIndex];

    // Check expiry
    if (new Date(pending.expiresAt) < new Date()) {
      pendingList.splice(pendingIndex, 1);
      localStorage.setItem(MFA_PENDING_KEY, JSON.stringify(pendingList));
      return { success: false, error: 'MFA session expired. Please login again' };
    }

    const user = this.getUserById(pending.userId);
    if (!user || !user.mfaSecret) {
      return { success: false, error: 'User not found' };
    }

    // Verify TOTP code
    const isValid = MFAService.verifyTOTP(user.mfaSecret, code);
    if (!isValid) {
      return { success: false, error: 'Invalid verification code' };
    }

    // Remove pending MFA
    pendingList.splice(pendingIndex, 1);
    localStorage.setItem(MFA_PENDING_KEY, JSON.stringify(pendingList));

    // Create session
    return this.createSession(user, pending.ipAddress, pending.userAgent);
  }

  private getMfaPending(): any[] {
    const stored = localStorage.getItem(MFA_PENDING_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  // ============================================
  // SESSION MANAGEMENT
  // ============================================

  /**
   * Create a new session for user
   */
  private createSession(user: User, ipAddress?: string, userAgent?: string): AuthResult {
    const expiresAt = new Date(Date.now() + SESSION_DURATION_HOURS * 60 * 60 * 1000);
    const refreshExpiresAt = new Date(Date.now() + REFRESH_TOKEN_DURATION_DAYS * 24 * 60 * 60 * 1000);

    const session: Session = {
      id: this.generateToken(16),
      userId: user.id,
      token: this.generateSessionToken(user.id, expiresAt),
      refreshToken: this.generateToken(64),
      expiresAt: expiresAt.toISOString(),
      createdAt: new Date().toISOString(),
      ipAddress,
      userAgent,
    };

    // Save session
    const sessions = this.getSessions();
    sessions.push(session);
    this.saveSessions(sessions);

    // Update user last login
    user.lastLogin = new Date().toISOString();
    this.updateUser(user);

    return {
      success: true,
      user: this.getSafeUser(user),
      session,
    };
  }

  /**
   * Get all sessions
   */
  private getSessions(): Session[] {
    const stored = localStorage.getItem(SESSIONS_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  /**
   * Save sessions
   */
  private saveSessions(sessions: Session[]): void {
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
  }

  /**
   * Validate session token
   */
  validateSession(token: string): { valid: boolean; user?: Omit<User, 'passwordHash' | 'salt' | 'mfaSecret'>; session?: Session } {
    const sessions = this.getSessions();
    const session = sessions.find(s => s.token === token);

    if (!session) {
      return { valid: false };
    }

    // Check expiry
    if (new Date(session.expiresAt) < new Date()) {
      // Remove expired session
      this.revokeSession(session.id);
      return { valid: false };
    }

    const user = this.getUserById(session.userId);
    if (!user) {
      return { valid: false };
    }

    return {
      valid: true,
      user: this.getSafeUser(user),
      session,
    };
  }

  /**
   * Refresh session with refresh token
   */
  refreshSession(refreshToken: string): AuthResult {
    const sessions = this.getSessions();
    const sessionIndex = sessions.findIndex(s => s.refreshToken === refreshToken);

    if (sessionIndex === -1) {
      return { success: false, error: 'Invalid refresh token' };
    }

    const oldSession = sessions[sessionIndex];
    const user = this.getUserById(oldSession.userId);

    if (!user) {
      return { success: false, error: 'User not found' };
    }

    // Remove old session
    sessions.splice(sessionIndex, 1);
    this.saveSessions(sessions);

    // Create new session
    return this.createSession(user, oldSession.ipAddress, oldSession.userAgent);
  }

  /**
   * Revoke a specific session
   */
  revokeSession(sessionId: string): void {
    const sessions = this.getSessions();
    const filtered = sessions.filter(s => s.id !== sessionId);
    this.saveSessions(filtered);
  }

  /**
   * Revoke all sessions for a user
   */
  revokeAllUserSessions(userId: string): void {
    const sessions = this.getSessions();
    const filtered = sessions.filter(s => s.userId !== userId);
    this.saveSessions(filtered);
  }

  /**
   * Logout (revoke current session)
   */
  logout(sessionId: string): void {
    this.revokeSession(sessionId);
  }

  // ============================================
  // MFA MANAGEMENT
  // ============================================

  /**
   * Enable MFA for user
   */
  enableMfa(userId: string, secret: string, code: string): { success: boolean; error?: string } {
    const user = this.getUserById(userId);
    if (!user) {
      return { success: false, error: 'User not found' };
    }

    // Verify the code works with the secret
    const isValid = MFAService.verifyTOTP(secret, code);
    if (!isValid) {
      return { success: false, error: 'Invalid verification code' };
    }

    user.mfaEnabled = true;
    user.mfaSecret = secret;
    user.updatedAt = new Date().toISOString();
    this.updateUser(user);

    return { success: true };
  }

  /**
   * Disable MFA for user
   */
  disableMfa(userId: string, password: string): Promise<{ success: boolean; error?: string }> {
    return new Promise(async (resolve) => {
      const user = this.getUserById(userId);
      if (!user) {
        resolve({ success: false, error: 'User not found' });
        return;
      }

      // Verify password
      const passwordValid = await this.verifyPassword(password, user.salt, user.passwordHash);
      if (!passwordValid) {
        resolve({ success: false, error: 'Invalid password' });
        return;
      }

      user.mfaEnabled = false;
      user.mfaSecret = undefined;
      user.updatedAt = new Date().toISOString();
      this.updateUser(user);

      // Revoke all sessions for security
      this.revokeAllUserSessions(userId);

      resolve({ success: true });
    });
  }

  // ============================================
  // PASSWORD MANAGEMENT
  // ============================================

  /**
   * Change password
   */
  async changePassword(userId: string, currentPassword: string, newPassword: string): Promise<{ success: boolean; error?: string }> {
    const user = this.getUserById(userId);
    if (!user) {
      return { success: false, error: 'User not found' };
    }

    // Verify current password
    const passwordValid = await this.verifyPassword(currentPassword, user.salt, user.passwordHash);
    if (!passwordValid) {
      return { success: false, error: 'Current password is incorrect' };
    }

    // Validate new password
    const validation = this.validatePassword(newPassword);
    if (!validation.valid) {
      return { success: false, error: validation.errors.join('. ') };
    }

    // Hash new password
    const newSalt = this.generateSalt();
    const newHash = await this.hashPassword(newPassword, newSalt);

    user.passwordHash = newHash;
    user.salt = newSalt;
    user.passwordChangedAt = new Date().toISOString();
    user.mustChangePassword = false;
    user.updatedAt = new Date().toISOString();
    this.updateUser(user);

    // Revoke all other sessions
    this.revokeAllUserSessions(userId);

    return { success: true };
  }

  /**
   * Update user
   */
  private updateUser(user: User): void {
    const users = this.getUsers();
    const index = users.findIndex(u => u.id === user.id);
    if (index !== -1) {
      users[index] = user;
      this.saveUsers(users);
    }
  }

  // ============================================
  // ADMIN FUNCTIONS
  // ============================================

  /**
   * Get all users (admin only, returns safe data)
   */
  getAllUsers(): Omit<User, 'passwordHash' | 'salt' | 'mfaSecret'>[] {
    return this.getUsers().map(u => this.getSafeUser(u));
  }

  /**
   * Delete user (admin only)
   */
  deleteUser(userId: string): void {
    const users = this.getUsers().filter(u => u.id !== userId);
    this.saveUsers(users);
    this.revokeAllUserSessions(userId);
  }

  /**
   * Reset user password (admin only)
   */
  async adminResetPassword(userId: string, temporaryPassword: string): Promise<{ success: boolean; error?: string }> {
    const user = this.getUserById(userId);
    if (!user) {
      return { success: false, error: 'User not found' };
    }

    const newSalt = this.generateSalt();
    const newHash = await this.hashPassword(temporaryPassword, newSalt);

    user.passwordHash = newHash;
    user.salt = newSalt;
    user.mustChangePassword = true;
    user.updatedAt = new Date().toISOString();
    this.updateUser(user);

    // Revoke all sessions
    this.revokeAllUserSessions(userId);

    return { success: true };
  }

  /**
   * Update user role (admin only)
   */
  updateUserRole(userId: string, role: 'admin' | 'manager' | 'associate'): { success: boolean; error?: string } {
    const user = this.getUserById(userId);
    if (!user) {
      return { success: false, error: 'User not found' };
    }

    user.role = role;
    user.updatedAt = new Date().toISOString();
    this.updateUser(user);

    return { success: true };
  }

  // ============================================
  // INITIALIZATION
  // ============================================

  /**
   * Initialize with a default admin if no users exist
   */
  async initializeDefaultAdmin(): Promise<void> {
    const users = this.getUsers();
    if (users.length === 0) {
      // Create a default admin - in production, this would be done through a secure setup process
      const salt = this.generateSalt();
      const passwordHash = await this.hashPassword('Admin@123456', salt);

      const adminUser: User = {
        id: this.generateToken(16),
        email: 'admin@visioncare.local',
        firstName: 'System',
        lastName: 'Administrator',
        role: 'admin',
        passwordHash,
        salt,
        mfaEnabled: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        failedLoginAttempts: 0,
        mustChangePassword: true, // Force password change on first login
      };

      this.saveUsers([adminUser]);
      console.log('[SecureAuth] Default admin created: admin@visioncare.local / Admin@123456');
    }
  }
}

export const SecureAuthService = new SecureAuthServiceClass();
export default SecureAuthService;
