/**
 * FTC Rx Acknowledgement Compliance Service
 * Handles prescription consent, delivery tracking, and acknowledgement per FTC Eyeglass Rule
 */

import type {
  RxConsent,
  RxDeliveryStatus,
  RxAcknowledgement,
  FtcComplianceRecord,
  RxConsentType,
  RxDeliveryMethod,
  RxData,
} from './eyefinityService';

const FTC_COMPLIANCE_KEY = 'ftc_compliance_records';
const RX_CONSENT_KEY = 'rx_consent_records';
const RX_ACKNOWLEDGEMENT_KEY = 'rx_acknowledgement_records';

class FtcComplianceServiceClass {
  
  // ============================================
  // COMPLIANCE RECORDS
  // ============================================

  /**
   * Get all FTC compliance records
   */
  getAllRecords(): FtcComplianceRecord[] {
    const stored = localStorage.getItem(FTC_COMPLIANCE_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  /**
   * Get compliance record for a patient
   */
  getPatientRecord(patientId: string): FtcComplianceRecord | null {
    const records = this.getAllRecords();
    return records.find(r => r.patientId === patientId) || null;
  }

  /**
   * Get compliance record for an appointment
   */
  getAppointmentRecord(appointmentId: string): FtcComplianceRecord | null {
    const records = this.getAllRecords();
    return records.find(r => r.appointmentId === appointmentId) || null;
  }

  /**
   * Save or update a compliance record
   */
  saveRecord(record: FtcComplianceRecord): void {
    const records = this.getAllRecords();
    const existingIndex = records.findIndex(r => r.patientId === record.patientId);
    
    record.updatedAt = new Date().toISOString();
    
    if (existingIndex >= 0) {
      records[existingIndex] = record;
    } else {
      record.createdAt = new Date().toISOString();
      records.push(record);
    }
    
    localStorage.setItem(FTC_COMPLIANCE_KEY, JSON.stringify(records));
  }

  // ============================================
  // RX CONSENT
  // ============================================

  /**
   * Save patient's consent for Rx delivery
   */
  saveConsent(consent: RxConsent): FtcComplianceRecord {
    let record = this.getPatientRecord(consent.patientId);
    
    if (!record) {
      record = {
        patientId: consent.patientId,
        consent: consent,
        isCompliant: false,
        complianceStatus: consent.consentType === 'electronic' ? 'pending_delivery' : 'pending_acknowledgement',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    } else {
      record.consent = consent;
      record.complianceStatus = consent.consentType === 'electronic' ? 'pending_delivery' : 'pending_acknowledgement';
    }
    
    this.saveRecord(record);
    return record;
  }

  /**
   * Get patient's consent
   */
  getConsent(patientId: string): RxConsent | null {
    const record = this.getPatientRecord(patientId);
    return record?.consent || null;
  }

  /**
   * Check if patient has consented to electronic delivery
   */
  hasElectronicConsent(patientId: string): boolean {
    const consent = this.getConsent(patientId);
    return consent?.consentType === 'electronic';
  }

  /**
   * Check if patient declined electronic delivery (needs physical + acknowledgement)
   */
  needsPhysicalDelivery(patientId: string): boolean {
    const consent = this.getConsent(patientId);
    return consent?.consentType === 'physical' || consent?.consentType === 'declined';
  }

  // ============================================
  // RX DELIVERY TRACKING
  // ============================================

  /**
   * Record that Rx was delivered electronically
   */
  recordDelivery(delivery: RxDeliveryStatus): FtcComplianceRecord {
    let record = this.getPatientRecord(delivery.patientId);
    
    if (!record) {
      record = {
        patientId: delivery.patientId,
        delivery: delivery,
        isCompliant: delivery.wasOpened || false,
        complianceStatus: delivery.wasOpened ? 'complete' : 'pending_acknowledgement',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    } else {
      record.delivery = delivery;
      if (delivery.wasOpened) {
        record.isCompliant = true;
        record.complianceStatus = 'complete';
      }
    }
    
    this.saveRecord(record);
    return record;
  }

  /**
   * Track delivery (wrapper for recordDelivery for AI tool compatibility)
   */
  trackDelivery(patientId: string, delivery: Partial<RxDeliveryStatus>): FtcComplianceRecord {
    const fullDelivery: RxDeliveryStatus = {
      patientId,
      rxType: delivery.rxType || 'eyeglass',
      deliveryMethod: delivery.deliveryMethod || 'email',
      deliveryTimestamp: delivery.deliveryTimestamp || new Date().toISOString(),
      wasDelivered: true,
      wasOpened: delivery.wasOpened || false,
      openedTimestamp: delivery.openedTimestamp,
    };
    return this.recordDelivery(fullDelivery);
  }

  /**
   * Record that patient opened/viewed the electronically delivered Rx
   */
  recordRxOpened(patientId: string): FtcComplianceRecord | null {
    const record = this.getPatientRecord(patientId);
    if (!record || !record.delivery) return null;
    
    record.delivery.wasOpened = true;
    record.delivery.openedTimestamp = new Date().toISOString();
    record.isCompliant = true;
    record.complianceStatus = 'complete';
    
    this.saveRecord(record);
    return record;
  }

  // ============================================
  // RX ACKNOWLEDGEMENT (Physical delivery)
  // ============================================

  /**
   * Save patient's acknowledgement that they received physical Rx
   */
  saveAcknowledgement(acknowledgement: RxAcknowledgement): FtcComplianceRecord {
    let record = this.getPatientRecord(acknowledgement.patientId);
    
    if (!record) {
      record = {
        patientId: acknowledgement.patientId,
        acknowledgement: acknowledgement,
        isCompliant: true,
        complianceStatus: 'complete',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    } else {
      record.acknowledgement = acknowledgement;
      record.isCompliant = true;
      record.complianceStatus = 'complete';
    }
    
    this.saveRecord(record);
    return record;
  }

  /**
   * Get patient's acknowledgement
   */
  getAcknowledgement(patientId: string): RxAcknowledgement | null {
    const record = this.getPatientRecord(patientId);
    return record?.acknowledgement || null;
  }

  /**
   * Check if patient has acknowledged receiving Rx
   */
  hasAcknowledgement(patientId: string): boolean {
    return this.getAcknowledgement(patientId) !== null;
  }

  // ============================================
  // COMPLIANCE CHECKS
  // ============================================

  /**
   * Check if patient is FTC compliant
   */
  isCompliant(patientId: string): boolean {
    const record = this.getPatientRecord(patientId);
    return record?.isCompliant || false;
  }

  /**
   * Get compliance status for a patient
   */
  getComplianceStatus(patientId: string): FtcComplianceRecord['complianceStatus'] | 'no_record' {
    const record = this.getPatientRecord(patientId);
    return record?.complianceStatus || 'no_record';
  }

  /**
   * Check what's needed for compliance
   */
  getComplianceRequirements(patientId: string): {
    needsConsent: boolean;
    needsDelivery: boolean;
    needsAcknowledgement: boolean;
    isComplete: boolean;
  } {
    const record = this.getPatientRecord(patientId);
    
    if (!record) {
      return {
        needsConsent: true,
        needsDelivery: false,
        needsAcknowledgement: false,
        isComplete: false,
      };
    }
    
    const hasConsent = !!record.consent;
    const isElectronic = record.consent?.consentType === 'electronic';
    const hasDelivery = !!record.delivery?.wasDelivered;
    const hasOpened = !!record.delivery?.wasOpened;
    const hasAcknowledgement = !!record.acknowledgement;
    
    if (isElectronic) {
      return {
        needsConsent: !hasConsent,
        needsDelivery: hasConsent && !hasDelivery,
        needsAcknowledgement: hasDelivery && !hasOpened,
        isComplete: hasOpened,
      };
    } else {
      return {
        needsConsent: !hasConsent,
        needsDelivery: false,
        needsAcknowledgement: hasConsent && !hasAcknowledgement,
        isComplete: hasAcknowledgement,
      };
    }
  }

  /**
   * Check if patient can proceed to checkout (FTC blocking check)
   */
  canProceedToCheckout(patientId: string, hasExam: boolean = true): {
    canProceed: boolean;
    blockingReason?: string;
    warningMessage?: string;
  } {
    if (!hasExam) {
      return { canProceed: true };
    }
    
    const requirements = this.getComplianceRequirements(patientId);
    
    if (requirements.isComplete) {
      return { canProceed: true };
    }
    
    if (requirements.needsConsent) {
      return {
        canProceed: false,
        blockingReason: 'Rx consent required before proceeding',
        warningMessage: 'FTC Compliance: Patient must consent to Rx delivery method before eyeglass sale',
      };
    }
    
    if (requirements.needsAcknowledgement) {
      return {
        canProceed: false,
        blockingReason: 'Rx acknowledgement required before proceeding',
        warningMessage: 'FTC Compliance: Patient must acknowledge receipt of prescription before eyeglass sale',
      };
    }
    
    if (requirements.needsDelivery) {
      return {
        canProceed: true,
        warningMessage: 'Rx has not been delivered electronically yet. Ensure delivery before completing sale.',
      };
    }
    
    return { canProceed: true };
  }

  // ============================================
  // REPORTING (JSON Payloads per User Stories)
  // ============================================

  /**
   * Generate US6 payload - Consent data
   */
  generateConsentPayload(patientId: string): object | null {
    const consent = this.getConsent(patientId);
    if (!consent) return null;
    
    return {
      PatientIdentifiers: {
        Name: consent.patientName,
        SourcePatientId: patientId,
        PatientUid: consent.patientUid,
      },
      PatientConsentForDigitalDelivery: consent.consentType === 'electronic',
      PatientSignatureCapturedFlag: !!consent.consentSignature,
      PatientSignatureCaptureDateTime: consent.consentTimestamp,
      DeviceIpAddress: consent.consentIpAddress,
      StoreIdentifiers: {
        StoreNumber: consent.storeNumber,
        StoreId: consent.storeId,
      },
    };
  }

  /**
   * Generate US7 payload - Electronic delivery data
   */
  generateDeliveryPayload(patientId: string): object | null {
    const record = this.getPatientRecord(patientId);
    if (!record?.delivery || !record?.consent) return null;
    
    return {
      PatientIdentifiers: {
        Name: record.consent.patientName,
        SourcePatientId: patientId,
        PatientUid: record.consent.patientUid,
      },
      ElectronicDeliveryMethod: record.consent.deliveryMethod,
      ElectronicDeliveryDetails: record.consent.deliveryDetails,
      DeliveryDateTime: record.delivery.deliveryTimestamp,
      OpenRead: record.delivery.wasOpened,
      OpenReadDateTime: record.delivery.openedTimestamp,
      StoreIdentifiers: {
        StoreNumber: record.consent.storeNumber,
        StoreId: record.consent.storeId,
      },
    };
  }

  /**
   * Generate US8 payload - Acknowledgement data
   */
  generateAcknowledgementPayload(patientId: string): object | null {
    const acknowledgement = this.getAcknowledgement(patientId);
    if (!acknowledgement) return null;
    
    return {
      PatientIdentifiers: {
        Name: acknowledgement.patientName,
        SourcePatientId: patientId,
        PatientUid: acknowledgement.patientUid,
      },
      PatientSignatureCapturedFlag: !!acknowledgement.acknowledgementSignature,
      PatientSignatureCaptureDateTime: acknowledgement.acknowledgementTimestamp,
      DeviceIpAddress: acknowledgement.acknowledgementIpAddress,
      StoreIdentifiers: {
        StoreNumber: acknowledgement.storeNumber,
        StoreId: acknowledgement.storeId,
      },
      AssociateIdentifiers: {
        AssociateId: acknowledgement.associateId,
        AssociateName: acknowledgement.associateName,
      },
    };
  }

  // ============================================
  // UTILITIES
  // ============================================

  /**
   * Get client IP address (best effort)
   */
  async getClientIp(): Promise<string> {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch {
      return 'unknown';
    }
  }

  /**
   * Clear all compliance records (for testing)
   */
  clearAllRecords(): void {
    localStorage.removeItem(FTC_COMPLIANCE_KEY);
  }
}

export const FtcComplianceService = new FtcComplianceServiceClass();
export default FtcComplianceService;
