/// <reference types="vite/client" />
/**
 * Realistic Voice Service
 * Creates human-like AI voice interactions that are nearly indistinguishable from real humans
 * 
 * Features:
 * - ElevenLabs high-quality neural voices
 * - Ambient background audio (office sounds)
 * - Natural speech patterns (filler words, breathing, pauses)
 * - Conversation memory and context
 */

import { ElevenLabsService, AIPersonaVoice } from './elevenlabs-service';
import { DeepgramService, TranscriptionResult } from './deepgram-service';
import { AIPersona, getOrCreateDefaultPersona } from './ai-persona';
import { UnifiedAIResponseService, PatientContext, AIResponseResult } from './unified-ai-response-service';

// Ambient audio URLs (store in S3 or similar in production)
export const AMBIENT_SOUNDS = {
  'medical-office': {
    url: '/audio/ambient/medical-office.mp3',
    description: 'Subtle office sounds - keyboard typing, distant phones, HVAC',
    volume: 0.08
  },
  'busy-office': {
    url: '/audio/ambient/busy-office.mp3', 
    description: 'Active office - more voices in background, phones ringing',
    volume: 0.06
  },
  'quiet-office': {
    url: '/audio/ambient/quiet-office.mp3',
    description: 'Very subtle background - minimal noise',
    volume: 0.04
  },
  'reception': {
    url: '/audio/ambient/reception.mp3',
    description: 'Reception area - door sounds, footsteps, soft music',
    volume: 0.07
  }
};

// Natural speech enhancements
export const SPEECH_NATURALIZERS = {
  fillerWords: ['um', 'uh', 'so', 'well', 'let me see', 'okay so'],
  thinkingPhrases: [
    'Let me check on that for you...',
    'One moment while I look that up...',
    'Let me see here...',
    'Okay, looking at your information...',
  ],
  acknowledgments: [
    'I understand.',
    'Got it.',
    'Okay.',
    'Sure thing.',
    'Absolutely.',
    'Of course.',
  ],
  empathyPhrases: [
    'I completely understand.',
    'I hear you.',
    'That makes total sense.',
    'I can definitely help with that.',
  ]
};

export interface RealisticVoiceConfig {
  persona: AIPersona;
  ambientSound?: keyof typeof AMBIENT_SOUNDS;
  naturalizeSpeed: boolean;  // Add slight speed variations
  addFillers: boolean;       // Add occasional filler words
  addBreathing: boolean;     // Add subtle breathing sounds
  speakingRate: number;      // 0.8 - 1.2 (1.0 = normal)
}

export interface VoiceConversationState {
  callSid: string;
  patientContext: PatientContext;
  persona: AIPersona;
  messages: Array<{
    role: 'patient' | 'assistant';
    content: string;
    timestamp: Date;
    audioUrl?: string;
  }>;
  turnCount: number;
  startTime: Date;
  lastActivity: Date;
  recordingUrl?: string;
  escalationTriggered: boolean;
  transferRequested: boolean;
}

// In-memory conversation store (use Redis in production)
const conversations = new Map<string, VoiceConversationState>();

export class RealisticVoiceService {
  
  /**
   * Initialize a new voice conversation
   */
  static initConversation(
    callSid: string,
    callerPhone: string,
    officeId: string,
    patientInfo?: Partial<PatientContext>
  ): VoiceConversationState {
    const persona = getOrCreateDefaultPersona(officeId);
    
    const state: VoiceConversationState = {
      callSid,
      patientContext: {
        firstName: patientInfo?.firstName || 'there',
        lastName: patientInfo?.lastName || '',
        phone: callerPhone,
        officeName: patientInfo?.officeName,
        ...patientInfo
      },
      persona,
      messages: [],
      turnCount: 0,
      startTime: new Date(),
      lastActivity: new Date(),
      escalationTriggered: false,
      transferRequested: false
    };
    
    conversations.set(callSid, state);
    return state;
  }
  
  /**
   * Get conversation state
   */
  static getConversation(callSid: string): VoiceConversationState | undefined {
    return conversations.get(callSid);
  }
  
  /**
   * Generate the initial greeting with high-quality voice
   */
  static async generateGreeting(
    callSid: string,
    patientContext?: Partial<PatientContext>
  ): Promise<{
    text: string;
    audioBuffer: ArrayBuffer;
    ssmlText: string;
  }> {
    const state = conversations.get(callSid);
    if (!state) throw new Error('Conversation not found');
    
    const { persona } = state;
    const greeting = this.buildGreeting(persona, patientContext);
    
    // Add natural elements
    const naturalizedGreeting = this.naturalizeText(greeting, persona);
    
    // Generate high-quality audio
    const audioBuffer = await this.generateAudio(naturalizedGreeting, persona);
    
    // Store in conversation
    state.messages.push({
      role: 'assistant',
      content: greeting,
      timestamp: new Date()
    });
    state.lastActivity = new Date();
    
    return {
      text: greeting,
      audioBuffer,
      ssmlText: this.toSSML(naturalizedGreeting, persona)
    };
  }
  
  /**
   * Process patient speech and generate response
   */
  static async processPatientSpeech(
    callSid: string,
    speechText: string
  ): Promise<{
    response: AIResponseResult;
    audioBuffer?: ArrayBuffer;
    shouldTransfer: boolean;
    shouldEscalate: boolean;
    transferReason?: string;
  }> {
    const state = conversations.get(callSid);
    if (!state) throw new Error('Conversation not found');
    
    const { persona, patientContext } = state;
    
    // Store patient message
    state.messages.push({
      role: 'patient',
      content: speechText,
      timestamp: new Date()
    });
    state.turnCount++;
    state.lastActivity = new Date();
    
    // Update context with conversation history
    const contextWithHistory: PatientContext = {
      ...patientContext,
      previousMessages: state.messages.map(m => ({
        role: m.role,
        content: m.content,
        timestamp: m.timestamp.toISOString()
      }))
    };
    
    // Generate AI response using UnifiedAIResponseService
    const response = await UnifiedAIResponseService.generateResponse(
      speechText,
      contextWithHistory,
      persona.officeId,
      {
        channel: 'voice',
        generateAudio: false, // We'll generate our own higher quality
        includePersonaName: false
      }
    );
    
    // Check for escalation/transfer
    const shouldTransfer = response.escalationRequired || 
                          state.turnCount > (persona.behavior.escalateAfterAttempts || 5) ||
                          this.detectTransferRequest(speechText);
    
    const shouldEscalate = response.sentiment === 'urgent' || 
                          response.intent.primary === 'escalation_triggered';
    
    if (shouldEscalate) state.escalationTriggered = true;
    if (shouldTransfer) state.transferRequested = true;
    
    // Naturalize and generate audio
    const naturalizedResponse = this.naturalizeText(response.text, persona);
    let audioBuffer: ArrayBuffer | undefined;
    
    try {
      audioBuffer = await this.generateAudio(naturalizedResponse, persona);
    } catch (error) {
      console.error('Failed to generate ElevenLabs audio:', error);
    }
    
    // Store assistant response
    state.messages.push({
      role: 'assistant',
      content: response.text,
      timestamp: new Date()
    });
    
    return {
      response,
      audioBuffer,
      shouldTransfer,
      shouldEscalate,
      transferReason: shouldEscalate ? response.escalationReason : 
                      shouldTransfer ? 'Max turns reached or transfer requested' : undefined
    };
  }
  
  /**
   * Generate high-quality audio using ElevenLabs
   */
  static async generateAudio(
    text: string,
    persona: AIPersona,
    outputFormat: 'mp3_44100_128' | 'pcm_16000' | 'ulaw_8000' = 'mp3_44100_128'
  ): Promise<ArrayBuffer> {
    if (persona.voice.provider !== 'elevenlabs') {
      throw new Error('RealisticVoiceService requires ElevenLabs voice provider');
    }
    
    return ElevenLabsService.generateSpeechFromPersona(
      text,
      persona.voice,
      outputFormat
    );
  }
  
  /**
   * Build personalized greeting
   */
  private static buildGreeting(persona: AIPersona, patientContext?: Partial<PatientContext>): string {
    const hour = new Date().getHours();
    let timeGreeting = 'Hello';
    if (hour < 12) timeGreeting = 'Good morning';
    else if (hour < 17) timeGreeting = 'Good afternoon';
    else timeGreeting = 'Good evening';
    
    const patientName = patientContext?.firstName;
    const officeName = patientContext?.officeName || 'our office';
    
    // Use persona's configured greeting or build one
    if (persona.channels.voice.greeting) {
      return persona.channels.voice.greeting
        .replace('{timeGreeting}', timeGreeting)
        .replace('{patientName}', patientName || '')
        .replace('{officeName}', officeName);
    }
    
    if (patientName) {
      return `${timeGreeting}, ${patientName}! Thank you for calling ${officeName}. This is ${persona.name}. How can I help you today?`;
    }
    
    return `${timeGreeting}, and thank you for calling ${officeName}. This is ${persona.name}, how may I assist you today?`;
  }
  
  /**
   * Add natural speech elements to text
   */
  private static naturalizeText(text: string, persona: AIPersona): string {
    // Don't over-naturalize short responses
    if (text.length < 50) return text;
    
    let naturalized = text;
    
    // Add occasional thinking phrase for longer responses
    if (text.length > 100 && Math.random() > 0.6) {
      const thinkingPhrase = SPEECH_NATURALIZERS.thinkingPhrases[
        Math.floor(Math.random() * SPEECH_NATURALIZERS.thinkingPhrases.length)
      ];
      naturalized = thinkingPhrase + ' ' + naturalized;
    }
    
    // Add subtle pauses (represented as commas or ellipses for TTS)
    naturalized = naturalized
      .replace(/\. /g, '. ... ')  // Add pause after sentences
      .replace(/\? /g, '? ... '); // Add pause after questions
    
    return naturalized;
  }
  
  /**
   * Convert text to SSML for enhanced speech synthesis
   */
  private static toSSML(text: string, persona: AIPersona): string {
    const rate = persona.channels.voice.speakingRate || 1.0;
    
    return `
      <speak>
        <prosody rate="${rate * 100}%">
          ${text}
        </prosody>
      </speak>
    `.trim();
  }
  
  /**
   * Detect if patient is requesting transfer
   */
  private static detectTransferRequest(text: string): boolean {
    const transferPhrases = [
      'speak to someone',
      'talk to a person',
      'real person',
      'human',
      'operator',
      'representative',
      'transfer me',
      'connect me',
      'staff member',
      'someone else'
    ];
    
    const lower = text.toLowerCase();
    return transferPhrases.some(phrase => lower.includes(phrase));
  }
  
  /**
   * Generate transfer message
   */
  static async generateTransferMessage(
    callSid: string,
    reason: 'escalation' | 'request' | 'max_turns' = 'request'
  ): Promise<{
    text: string;
    audioBuffer: ArrayBuffer;
  }> {
    const state = conversations.get(callSid);
    if (!state) throw new Error('Conversation not found');
    
    const { persona } = state;
    
    const messages: Record<string, string> = {
      escalation: "I understand this is really important. Let me connect you with one of our team members right away who can better assist you. Please hold for just a moment.",
      request: "Of course, I'd be happy to connect you with a staff member. Please hold while I transfer your call.",
      max_turns: "I want to make sure you get the best help possible. Let me transfer you to one of our team members who can assist you further. One moment please."
    };
    
    const text = persona.channels.voice.transferMessage || messages[reason];
    const audioBuffer = await this.generateAudio(text, persona);
    
    return { text, audioBuffer };
  }
  
  /**
   * Generate hold message
   */
  static async generateHoldMessage(callSid: string): Promise<{
    text: string;
    audioBuffer: ArrayBuffer;
  }> {
    const state = conversations.get(callSid);
    if (!state) throw new Error('Conversation not found');
    
    const { persona } = state;
    const text = persona.channels.voice.holdMessage || 
      "Thank you for holding. I'm still here and working on that for you.";
    
    const audioBuffer = await this.generateAudio(text, persona);
    return { text, audioBuffer };
  }
  
  /**
   * Generate voicemail greeting
   */
  static async generateVoicemailGreeting(
    officeId: string,
    officeName: string
  ): Promise<{
    text: string;
    audioBuffer: ArrayBuffer;
  }> {
    const persona = getOrCreateDefaultPersona(officeId, officeName);
    
    const text = persona.channels.voice.voicemailGreeting ||
      `Hi, you've reached ${officeName}. We're sorry we missed your call. Please leave your name, number, and a brief message, and we'll get back to you as soon as possible. Thank you!`;
    
    const audioBuffer = await this.generateAudio(text, persona);
    return { text, audioBuffer };
  }
  
  /**
   * Mix audio with ambient background
   */
  static async mixWithAmbient(
    speechAudio: ArrayBuffer,
    ambientType: keyof typeof AMBIENT_SOUNDS = 'medical-office'
  ): Promise<ArrayBuffer> {
    // In production, use Web Audio API or server-side audio processing
    // For now, return the speech audio as-is
    // The ambient audio can be played separately in the browser
    console.log(`[RealisticVoice] Would mix with ${ambientType} ambient at volume ${AMBIENT_SOUNDS[ambientType].volume}`);
    return speechAudio;
  }
  
  /**
   * Get conversation transcript
   */
  static getTranscript(callSid: string): string {
    const state = conversations.get(callSid);
    if (!state) return '';
    
    return state.messages
      .map(m => `[${m.role.toUpperCase()}] ${m.content}`)
      .join('\n\n');
  }
  
  /**
   * End conversation and cleanup
   */
  static endConversation(callSid: string): VoiceConversationState | undefined {
    const state = conversations.get(callSid);
    if (state) {
      conversations.delete(callSid);
    }
    return state;
  }
  
  /**
   * Get all active conversations (for monitoring)
   */
  static getActiveConversations(): Map<string, VoiceConversationState> {
    return new Map(conversations);
  }
}

export default RealisticVoiceService;
