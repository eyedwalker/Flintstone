/// <reference types="vite/client" />
/**
 * Post-Call AI Evaluation Service
 * Analyzes call transcripts for quality, compliance, and insights
 */

import Anthropic from '@anthropic-ai/sdk';

const getAnthropicClient = () => {
  const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY;
  return apiKey ? new Anthropic({ apiKey, dangerouslyAllowBrowser: true }) : null;
};

// ==================== TYPES ====================

export interface CallEvaluationInput {
  callId: string;
  transcript: string;
  duration: number;
  patientId: string;
  patientName: string;
  callType: 'inbound' | 'outbound';
  wasEscalated: boolean;
  wasTransferred: boolean;
  recordingUrl?: string;
}

export interface CallEvaluationResult {
  callId: string;
  evaluatedAt: Date;
  
  // Quality Scores (0-100)
  overallScore: number;
  scores: {
    professionalism: number;
    empathy: number;
    accuracy: number;
    efficiency: number;
    resolution: number;
    compliance: number;
  };
  
  // Sentiment Analysis
  sentiment: {
    overall: 'positive' | 'neutral' | 'negative';
    patientMood: 'satisfied' | 'neutral' | 'frustrated' | 'angry';
    agentTone: 'warm' | 'professional' | 'cold' | 'robotic';
    tensionPoints: string[];
  };
  
  // Intent & Topics
  intents: {
    primary: string;
    secondary: string[];
    resolved: boolean;
  };
  topics: string[];
  
  // Compliance
  compliance: {
    hipaaCompliant: boolean;
    hipaaViolations: string[];
    piiExposed: boolean;
    piiTypes: string[];
    disclaimerGiven: boolean;
  };
  
  // Recommendations
  recommendations: {
    forAgent: string[];
    forTraining: string[];
    processImprovements: string[];
  };
  
  // Follow-up
  followUpRequired: boolean;
  followUpReason?: string;
  suggestedFollowUpAction?: string;
  
  // Summary
  summary: string;
  keyMoments: Array<{
    timestamp?: string;
    description: string;
    sentiment: 'positive' | 'neutral' | 'negative';
  }>;
}

export interface EvaluationMetrics {
  totalCalls: number;
  averageScore: number;
  sentimentDistribution: {
    positive: number;
    neutral: number;
    negative: number;
  };
  commonIssues: Array<{ issue: string; count: number }>;
  escalationRate: number;
  resolutionRate: number;
  averageCallDuration: number;
}

// Storage key
const EVALUATIONS_KEY = 'call_evaluations';
const METRICS_KEY = 'call_evaluation_metrics';

// ==================== EVALUATION SERVICE ====================

export class CallEvaluationService {
  
  /**
   * Evaluate a completed call
   */
  static async evaluateCall(input: CallEvaluationInput): Promise<CallEvaluationResult> {
    console.log(`[CallEvaluation] Evaluating call ${input.callId}`);
    
    const anthropic = getAnthropicClient();
    
    if (!anthropic) {
      console.warn('[CallEvaluation] No API key, using fallback evaluation');
      return this.generateFallbackEvaluation(input);
    }
    
    try {
      const response = await anthropic.messages.create({
        model: 'claude-3-haiku-20240307',
        max_tokens: 2000,
        system: this.getEvaluationSystemPrompt(),
        messages: [
          {
            role: 'user',
            content: this.formatEvaluationRequest(input),
          },
        ],
      });
      
      const responseText = response.content[0].type === 'text' ? response.content[0].text : '';
      const evaluation = this.parseEvaluationResponse(responseText, input);
      
      // Save evaluation
      this.saveEvaluation(evaluation);
      
      // Update metrics
      this.updateMetrics(evaluation);
      
      return evaluation;
    } catch (error) {
      console.error('[CallEvaluation] Error:', error);
      return this.generateFallbackEvaluation(input);
    }
  }
  
  /**
   * Get system prompt for evaluation
   */
  private static getEvaluationSystemPrompt(): string {
    return `You are a call quality analyst for a medical office. Evaluate call transcripts for:

1. QUALITY SCORES (0-100):
   - Professionalism: Proper greeting, language, tone
   - Empathy: Understanding patient concerns, showing care
   - Accuracy: Correct information provided
   - Efficiency: Time management, avoiding unnecessary delays
   - Resolution: Was the patient's issue resolved?
   - Compliance: HIPAA and office policy adherence

2. SENTIMENT ANALYSIS:
   - Patient mood throughout the call
   - Agent tone and warmth
   - Tension points or frustration moments

3. COMPLIANCE CHECK:
   - HIPAA violations (PHI discussed inappropriately)
   - PII exposure
   - Required disclaimers given

4. RECOMMENDATIONS:
   - How can the agent improve?
   - Training opportunities
   - Process improvements

Respond in JSON format with this structure:
{
  "overallScore": number,
  "scores": { professionalism, empathy, accuracy, efficiency, resolution, compliance },
  "sentiment": { overall, patientMood, agentTone, tensionPoints: [] },
  "intents": { primary, secondary: [], resolved },
  "topics": [],
  "compliance": { hipaaCompliant, hipaaViolations: [], piiExposed, piiTypes: [], disclaimerGiven },
  "recommendations": { forAgent: [], forTraining: [], processImprovements: [] },
  "followUpRequired": boolean,
  "followUpReason": string or null,
  "suggestedFollowUpAction": string or null,
  "summary": string,
  "keyMoments": [{ description, sentiment }]
}`;
  }
  
  /**
   * Format evaluation request
   */
  private static formatEvaluationRequest(input: CallEvaluationInput): string {
    return `Evaluate this ${input.callType} call:

CALL DETAILS:
- Patient: ${input.patientName}
- Duration: ${Math.round(input.duration / 60)} minutes ${input.duration % 60} seconds
- Was Escalated: ${input.wasEscalated ? 'Yes' : 'No'}
- Was Transferred: ${input.wasTransferred ? 'Yes' : 'No'}

TRANSCRIPT:
${input.transcript}

Provide your evaluation in JSON format.`;
  }
  
  /**
   * Parse evaluation response
   */
  private static parseEvaluationResponse(
    response: string,
    input: CallEvaluationInput
  ): CallEvaluationResult {
    try {
      // Extract JSON from response
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('No JSON found in response');
      }
      
      const parsed = JSON.parse(jsonMatch[0]);
      
      return {
        callId: input.callId,
        evaluatedAt: new Date(),
        overallScore: parsed.overallScore || 70,
        scores: {
          professionalism: parsed.scores?.professionalism || 70,
          empathy: parsed.scores?.empathy || 70,
          accuracy: parsed.scores?.accuracy || 70,
          efficiency: parsed.scores?.efficiency || 70,
          resolution: parsed.scores?.resolution || 70,
          compliance: parsed.scores?.compliance || 80,
        },
        sentiment: {
          overall: parsed.sentiment?.overall || 'neutral',
          patientMood: parsed.sentiment?.patientMood || 'neutral',
          agentTone: parsed.sentiment?.agentTone || 'professional',
          tensionPoints: parsed.sentiment?.tensionPoints || [],
        },
        intents: {
          primary: parsed.intents?.primary || 'general_inquiry',
          secondary: parsed.intents?.secondary || [],
          resolved: parsed.intents?.resolved ?? true,
        },
        topics: parsed.topics || [],
        compliance: {
          hipaaCompliant: parsed.compliance?.hipaaCompliant ?? true,
          hipaaViolations: parsed.compliance?.hipaaViolations || [],
          piiExposed: parsed.compliance?.piiExposed ?? false,
          piiTypes: parsed.compliance?.piiTypes || [],
          disclaimerGiven: parsed.compliance?.disclaimerGiven ?? true,
        },
        recommendations: {
          forAgent: parsed.recommendations?.forAgent || [],
          forTraining: parsed.recommendations?.forTraining || [],
          processImprovements: parsed.recommendations?.processImprovements || [],
        },
        followUpRequired: parsed.followUpRequired ?? false,
        followUpReason: parsed.followUpReason,
        suggestedFollowUpAction: parsed.suggestedFollowUpAction,
        summary: parsed.summary || 'Call evaluated successfully.',
        keyMoments: parsed.keyMoments || [],
      };
    } catch (error) {
      console.error('[CallEvaluation] Parse error:', error);
      return this.generateFallbackEvaluation(input);
    }
  }
  
  /**
   * Generate fallback evaluation when AI unavailable
   */
  private static generateFallbackEvaluation(input: CallEvaluationInput): CallEvaluationResult {
    const baseScore = input.wasEscalated ? 65 : 75;
    
    return {
      callId: input.callId,
      evaluatedAt: new Date(),
      overallScore: baseScore,
      scores: {
        professionalism: baseScore + 5,
        empathy: baseScore,
        accuracy: baseScore + 10,
        efficiency: input.duration < 300 ? 85 : 70,
        resolution: input.wasTransferred ? 60 : 80,
        compliance: 90,
      },
      sentiment: {
        overall: 'neutral',
        patientMood: input.wasEscalated ? 'frustrated' : 'neutral',
        agentTone: 'professional',
        tensionPoints: input.wasEscalated ? ['Patient requested escalation'] : [],
      },
      intents: {
        primary: 'general_inquiry',
        secondary: [],
        resolved: !input.wasTransferred,
      },
      topics: [],
      compliance: {
        hipaaCompliant: true,
        hipaaViolations: [],
        piiExposed: false,
        piiTypes: [],
        disclaimerGiven: true,
      },
      recommendations: {
        forAgent: ['Review call handling procedures'],
        forTraining: [],
        processImprovements: [],
      },
      followUpRequired: input.wasEscalated,
      followUpReason: input.wasEscalated ? 'Call was escalated' : undefined,
      summary: `${input.callType} call completed. Duration: ${Math.round(input.duration / 60)} minutes.`,
      keyMoments: [],
    };
  }
  
  // ==================== STORAGE ====================
  
  /**
   * Save evaluation
   */
  private static saveEvaluation(evaluation: CallEvaluationResult): void {
    const evaluations = this.getAllEvaluations();
    evaluations.push(evaluation);
    
    // Keep last 1000 evaluations
    if (evaluations.length > 1000) {
      evaluations.splice(0, evaluations.length - 1000);
    }
    
    localStorage.setItem(EVALUATIONS_KEY, JSON.stringify(evaluations));
  }
  
  /**
   * Get all evaluations
   */
  static getAllEvaluations(): CallEvaluationResult[] {
    const stored = localStorage.getItem(EVALUATIONS_KEY);
    return stored ? JSON.parse(stored) : [];
  }
  
  /**
   * Get evaluation by call ID
   */
  static getEvaluationByCallId(callId: string): CallEvaluationResult | null {
    const evaluations = this.getAllEvaluations();
    return evaluations.find(e => e.callId === callId) || null;
  }
  
  /**
   * Get recent evaluations
   */
  static getRecentEvaluations(limit: number = 50): CallEvaluationResult[] {
    const evaluations = this.getAllEvaluations();
    return evaluations
      .sort((a, b) => new Date(b.evaluatedAt).getTime() - new Date(a.evaluatedAt).getTime())
      .slice(0, limit);
  }
  
  /**
   * Get evaluations requiring follow-up
   */
  static getFollowUpRequired(): CallEvaluationResult[] {
    return this.getAllEvaluations().filter(e => e.followUpRequired);
  }
  
  /**
   * Get low-scoring evaluations
   */
  static getLowScoringEvaluations(threshold: number = 60): CallEvaluationResult[] {
    return this.getAllEvaluations().filter(e => e.overallScore < threshold);
  }
  
  // ==================== METRICS ====================
  
  /**
   * Update metrics
   */
  private static updateMetrics(evaluation: CallEvaluationResult): void {
    const metrics = this.getMetrics();
    
    metrics.totalCalls++;
    metrics.averageScore = (
      (metrics.averageScore * (metrics.totalCalls - 1) + evaluation.overallScore) / 
      metrics.totalCalls
    );
    
    // Update sentiment distribution
    metrics.sentimentDistribution[evaluation.sentiment.overall]++;
    
    // Track escalations
    if (evaluation.followUpRequired) {
      const currentRate = metrics.escalationRate * (metrics.totalCalls - 1);
      metrics.escalationRate = (currentRate + 1) / metrics.totalCalls;
    }
    
    // Track resolutions
    if (evaluation.intents.resolved) {
      const currentRate = metrics.resolutionRate * (metrics.totalCalls - 1);
      metrics.resolutionRate = (currentRate + 1) / metrics.totalCalls;
    }
    
    localStorage.setItem(METRICS_KEY, JSON.stringify(metrics));
  }
  
  /**
   * Get metrics
   */
  static getMetrics(): EvaluationMetrics {
    const stored = localStorage.getItem(METRICS_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
    
    return {
      totalCalls: 0,
      averageScore: 0,
      sentimentDistribution: { positive: 0, neutral: 0, negative: 0 },
      commonIssues: [],
      escalationRate: 0,
      resolutionRate: 0,
      averageCallDuration: 0,
    };
  }
  
  /**
   * Get metrics for date range
   */
  static getMetricsForDateRange(
    startDate: Date,
    endDate: Date
  ): EvaluationMetrics {
    const evaluations = this.getAllEvaluations().filter(e => {
      const evalDate = new Date(e.evaluatedAt);
      return evalDate >= startDate && evalDate <= endDate;
    });
    
    if (evaluations.length === 0) {
      return this.getMetrics();
    }
    
    const totalScore = evaluations.reduce((sum, e) => sum + e.overallScore, 0);
    const sentiments = { positive: 0, neutral: 0, negative: 0 };
    let escalations = 0;
    let resolutions = 0;
    
    for (const e of evaluations) {
      sentiments[e.sentiment.overall]++;
      if (e.followUpRequired) escalations++;
      if (e.intents.resolved) resolutions++;
    }
    
    return {
      totalCalls: evaluations.length,
      averageScore: totalScore / evaluations.length,
      sentimentDistribution: sentiments,
      commonIssues: [],
      escalationRate: escalations / evaluations.length,
      resolutionRate: resolutions / evaluations.length,
      averageCallDuration: 0,
    };
  }
  
  /**
   * Generate quality report
   */
  static generateQualityReport(days: number = 7): {
    metrics: EvaluationMetrics;
    topIssues: string[];
    improvements: string[];
    trendsVsPreviousPeriod: {
      scoreChange: number;
      escalationChange: number;
      resolutionChange: number;
    };
  } {
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - days * 24 * 60 * 60 * 1000);
    const prevStartDate = new Date(startDate.getTime() - days * 24 * 60 * 60 * 1000);
    
    const currentMetrics = this.getMetricsForDateRange(startDate, endDate);
    const previousMetrics = this.getMetricsForDateRange(prevStartDate, startDate);
    
    // Collect all recommendations from recent evaluations
    const recentEvals = this.getRecentEvaluations(100);
    const allIssues: string[] = [];
    const allImprovements: string[] = [];
    
    for (const e of recentEvals) {
      allIssues.push(...e.recommendations.forAgent);
      allImprovements.push(...e.recommendations.processImprovements);
    }
    
    // Count unique issues
    const issueCounts = new Map<string, number>();
    for (const issue of allIssues) {
      issueCounts.set(issue, (issueCounts.get(issue) || 0) + 1);
    }
    
    const topIssues = Array.from(issueCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([issue]) => issue);
    
    return {
      metrics: currentMetrics,
      topIssues,
      improvements: [...new Set(allImprovements)].slice(0, 5),
      trendsVsPreviousPeriod: {
        scoreChange: currentMetrics.averageScore - previousMetrics.averageScore,
        escalationChange: currentMetrics.escalationRate - previousMetrics.escalationRate,
        resolutionChange: currentMetrics.resolutionRate - previousMetrics.resolutionRate,
      },
    };
  }
}
