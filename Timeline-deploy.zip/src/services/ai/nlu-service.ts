/**
 * AI Natural Language Understanding Service
 * Main entry point for processing natural language commands using Claude
 */

import { getToolSchemas, getToolByName } from './tool-registry';
import { executeToolHandler } from './tool-handlers';
import AIKnowledgeBaseService from '../aiKnowledgeBaseService';
import { getDocumentationContext } from './documentation-knowledge';
import type {
  NLUResult,
  ToolContext,
  ConversationContext,
  ConversationMessage,
} from './types';

const ANTHROPIC_API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY;
const CLAUDE_MODEL = 'claude-sonnet-4-20250514';

function buildSystemPrompt(context: ToolContext, conversationContext?: ConversationContext): string {
  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  let systemPrompt = `You are an AI assistant for an eye care practice management system. You help staff manage the entire practice — scheduling, patient care, communications, tasks, compliance, and more.

Current Date: ${currentDate}
Staff Member: ${context.staffName || 'Staff'}
Office ID: ${context.officeId || 'Not specified'}

IMPORTANT INSTRUCTIONS:
1. When the user asks to do something, use the appropriate tool to accomplish the task.
2. Parse natural language dates (e.g., "tomorrow", "next Monday") and pass them to tools.
3. If you need more information to complete a task, ask clarifying questions.
4. Be concise but friendly in your responses.
5. When showing appointment slots or patient lists, format them clearly.
6. If a tool returns a pending selection (multiple options), present them clearly and ask the user to choose.
7. Always confirm before booking, canceling, rescheduling appointments, making calls, or sending messages.

AVAILABLE ACTIONS:
- Scheduling: Find available slots, book/cancel/reschedule appointments, view today's schedule
- Patients: Search patients, view details, check in patients, register new patients, verify insurance, view orders
- Communication: Send SMS messages, send emails, send links via SMS (forms, directions, portal)
- Voice Calls: Initiate outbound AI calls (appointment reminders, follow-ups, prescription ready, recall reminders, custom scripts)
- Tasks: Create staff tasks, list tasks by status, update tasks, mark tasks complete
- Escalations: Create escalation alerts, list active escalations, resolve escalations
- Forms: Check required forms, send forms to patients, send form reminders, check form completion status, list available templates
- Patient Journey: Start journeys, track progress, complete/skip steps, transition phases, list active journeys
- Compliance: FTC Rx status and delivery, HIPAA signature status, full compliance summary
- Insurance Verification: Verify benefits on payer portals (VSP, EyeMed, Davis Vision), check eligibility, get copays and allowances, check verification job status`;

  // Add cached office data context (providers, appointment types, carriers)
  if (context.officeData?.providers && context.officeData.providers.length > 0) {
    const providerList = context.officeData.providers
      .map(p => `- ${p.fullName} (${p.providerType || 'Provider'}, ID: ${p.guid || p.staffId})`)
      .join('\n');
    systemPrompt += `\n\nAVAILABLE PROVIDERS AT THIS OFFICE:\n${providerList}`;
  }

  if (context.officeData?.appointmentTypes && context.officeData.appointmentTypes.length > 0) {
    const typeList = context.officeData.appointmentTypes
      .map(t => `- ${t.description} (ID: ${t.appointmentTypeId}, Duration: ${t.duration} min)`)
      .join('\n');
    systemPrompt += `\n\nAPPOINTMENT TYPES:\n${typeList}\nWhen booking appointments, use the correct AppointmentTypeId from this list.`;
  }

  if (context.officeData?.insuranceCarriers && context.officeData.insuranceCarriers.length > 0) {
    const carrierList = context.officeData.insuranceCarriers
      .slice(0, 30)
      .map(c => `- ${c.carrierName}`)
      .join('\n');
    systemPrompt += `\n\nACCEPTED INSURANCE CARRIERS:\n${carrierList}`;
  }

  if (conversationContext?.currentPatient) {
    const patient = conversationContext.currentPatient;
    systemPrompt += `

CURRENT PATIENT CONTEXT:
- Name: ${patient.name}
- ID: ${patient.id || 'Unknown'}
- Office: ${patient.officeId || 'Not specified'}
- Provider: ${patient.providerId || 'Not specified'}`;
  }

  if (conversationContext?.pendingSelection) {
    const pending = conversationContext.pendingSelection;
    systemPrompt += `

PENDING SELECTION:
The user needs to choose from the following ${pending.type} options:
${pending.options.map((opt, i) => `${i + 1}. ${opt.label}`).join('\n')}

If the user provides a number or identifies one of these options, use that selection.`;
  }

  if (conversationContext?.lastAction) {
    systemPrompt += `

LAST ACTION: ${conversationContext.lastAction.tool} with params: ${JSON.stringify(conversationContext.lastAction.parameters)}`;
  }

  // Add Knowledge Base context
  try {
    const knowledgeContext = AIKnowledgeBaseService.generateAIContext();
    if (knowledgeContext) {
      systemPrompt += `

${knowledgeContext}`;
    }
  } catch (e) {
    console.warn('[NLU] Failed to load knowledge base context:', e);
  }

  // Add documentation knowledge for help & training questions
  try {
    const docContext = getDocumentationContext();
    if (docContext) {
      systemPrompt += `

${docContext}`;
    }
  } catch (e) {
    console.warn('[NLU] Failed to load documentation context:', e);
  }

  return systemPrompt;
}

function formatConversationHistory(history: ConversationMessage[]): Array<{ role: 'user' | 'assistant'; content: string }> {
  return history.slice(-10).map(msg => ({
    role: msg.role,
    content: msg.content,
  }));
}

export async function processNaturalLanguage(
  userMessage: string,
  toolContext: ToolContext,
  conversationHistory?: ConversationMessage[],
  conversationContext?: ConversationContext,
  conversationSummary?: string
): Promise<NLUResult> {
  try {
    if (conversationContext?.pendingSelection) {
      const selectionResult = handlePendingSelection(userMessage, conversationContext);
      if (selectionResult) {
        return selectionResult;
      }
    }

    const systemPrompt = buildSystemPrompt(toolContext, conversationContext);
    const tools = getToolSchemas();

    const messages: Array<{ role: 'user' | 'assistant'; content: string }> = [];

    if (conversationSummary) {
      messages.push({
        role: 'user',
        content: `[Previous conversation summary: ${conversationSummary}]`,
      });
      messages.push({
        role: 'assistant',
        content: 'I understand the context. How can I help you now?',
      });
    }

    if (conversationHistory && conversationHistory.length > 0) {
      messages.push(...formatConversationHistory(conversationHistory));
    }

    messages.push({ role: 'user', content: userMessage });

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({
        model: CLAUDE_MODEL,
        max_tokens: 4096,
        system: systemPrompt,
        tools,
        messages,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[NLU] Claude API error:', response.status, errorText);
      throw new Error(`Claude API error: ${response.status}`);
    }

    const data = await response.json();
    console.log('[NLU] Claude response:', data);

    return processClaudeResponse(data, toolContext, conversationContext);
  } catch (error: any) {
    console.error('[NLU] Error processing natural language:', error);
    return {
      success: false,
      message: `I encountered an error processing your request: ${error.message}`,
    };
  }
}

function handlePendingSelection(
  userMessage: string,
  conversationContext: ConversationContext
): NLUResult | null {
  const pending = conversationContext.pendingSelection;
  if (!pending) return null;

  const trimmed = userMessage.trim().toLowerCase();

  const numMatch = trimmed.match(/^(\d+)$/);
  if (numMatch) {
    const index = parseInt(numMatch[1], 10) - 1;
    if (index >= 0 && index < pending.options.length) {
      const selected = pending.options[index];
      return {
        success: true,
        message: `Selected: ${selected.label}`,
        data: { selection: selected },
        updatedContext: {
          ...conversationContext,
          pendingSelection: undefined,
          [`last${pending.type.charAt(0).toUpperCase() + pending.type.slice(1)}`]: {
            id: selected.id,
            name: selected.label,
          },
        },
      };
    }
  }

  for (const option of pending.options) {
    if (option.label.toLowerCase().includes(trimmed) || trimmed.includes(option.label.toLowerCase())) {
      return {
        success: true,
        message: `Selected: ${option.label}`,
        data: { selection: option },
        updatedContext: {
          ...conversationContext,
          pendingSelection: undefined,
        },
      };
    }
  }

  return null;
}

async function processClaudeResponse(
  data: any,
  toolContext: ToolContext,
  conversationContext?: ConversationContext
): Promise<NLUResult> {
  const content = data.content || [];
  
  let textResponse = '';
  let toolUse = null;

  for (const block of content) {
    if (block.type === 'text') {
      textResponse += block.text;
    } else if (block.type === 'tool_use') {
      toolUse = block;
    }
  }

  if (toolUse) {
    const toolName = toolUse.name;
    const toolParams = toolUse.input || {};
    
    console.log('[NLU] Executing tool:', toolName, toolParams);

    const toolDef = getToolByName(toolName);
    
    if (toolDef?.requiresConfirmation) {
      return {
        success: true,
        toolName,
        parameters: toolParams,
        message: textResponse || `I'm ready to ${toolName.replace(/_/g, ' ')}. Would you like me to proceed?`,
        requiresConfirmation: true,
        updatedContext: {
          ...conversationContext,
          lastAction: { tool: toolName, parameters: toolParams },
        },
      };
    }

    const toolResult = await executeToolHandler(toolName, toolParams, toolContext);

    return {
      success: toolResult.success,
      toolName,
      parameters: toolParams,
      message: toolResult.message,
      data: toolResult.data,
      suggestedFollowUp: toolResult.suggestedFollowUp,
      updatedContext: toolResult.pendingSelection
        ? {
            ...conversationContext,
            pendingSelection: toolResult.pendingSelection,
            lastAction: { tool: toolName, parameters: toolParams },
          }
        : {
            ...conversationContext,
            pendingSelection: undefined,
            lastAction: { tool: toolName, parameters: toolParams },
          },
    };
  }

  return {
    success: true,
    message: textResponse || "I'm not sure how to help with that. Could you rephrase your request?",
    updatedContext: conversationContext,
  };
}

export async function executeConfirmedAction(
  toolName: string,
  parameters: Record<string, any>,
  toolContext: ToolContext
): Promise<NLUResult> {
  try {
    const result = await executeToolHandler(toolName, parameters, toolContext);
    
    return {
      success: result.success,
      toolName,
      parameters,
      message: result.message,
      data: result.data,
      suggestedFollowUp: result.suggestedFollowUp,
    };
  } catch (error: any) {
    return {
      success: false,
      toolName,
      parameters,
      message: `Failed to execute ${toolName}: ${error.message}`,
    };
  }
}

export default {
  processNaturalLanguage,
  executeConfirmedAction,
};
