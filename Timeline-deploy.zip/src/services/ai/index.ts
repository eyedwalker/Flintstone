/**
 * AI Services Entry Point
 */

export { default as NLUService, processNaturalLanguage, executeConfirmedAction } from './nlu-service';
export { default as ToolRegistry } from './tool-registry';
export { default as ToolHandlers } from './tool-handlers';
export * from './types';

// AI Communication Services
export { ElevenLabsService, AMBIENT_AUDIO } from './elevenlabs-service';
export type { Voice, VoiceSettings, GenerateSpeechOptions, AIPersonaVoice } from './elevenlabs-service';

export { DeepgramService } from './deepgram-service';
export type { TranscriptionOptions, TranscriptionResult, StreamingTranscriptEvent } from './deepgram-service';

export { UnifiedAIResponseService } from './unified-ai-response-service';
export type { PatientContext, AIResponseOptions, AIResponseResult, CommunicationChannel } from './unified-ai-response-service';

export { CallEvaluationService } from './call-evaluation-service';
export type { CallEvaluationInput, CallEvaluationResult, EvaluationMetrics } from './call-evaluation-service';

export { RealisticVoiceService, AMBIENT_SOUNDS, SPEECH_NATURALIZERS } from './realistic-voice-service';
export type { RealisticVoiceConfig, VoiceConversationState } from './realistic-voice-service';

export * from './ai-persona';
