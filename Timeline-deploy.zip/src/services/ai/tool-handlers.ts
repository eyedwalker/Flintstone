/**
 * AI Tool Handlers
 * Actual implementations that connect tool schemas to backend services
 */

import { EyefinityService } from '../eyefinityService';
import { PatientJourneyService } from '../../lib/services/patient-journey-service';
import { FormSubmissionService } from '../../lib/services/form-submission-service';
import { FormEligibilityService } from '../../lib/services/form-eligibility-service';
import FtcComplianceService from '../ftcComplianceService';
import HipaaComplianceService from '../hipaaComplianceService';
import { CommunicationService } from '../communicationService';
import { TaskService } from '../taskService';
import type { ToolContext, ToolResult, PendingSelection } from './types';

// Form type shortcut → actual template ID mapping
const FORM_TYPE_TO_TEMPLATE_ID: Record<string, string> = {
  'patient-intake': 'patient-intake-form',
  'hipaa-privacy': 'hipaa-privacy-notice',
  'contact-lens-agreement': 'contact-lens-rx-release',
  'insurance-card-upload': 'insurance-card-upload',
  'drivers-license-upload': 'drivers-license-upload',
};

function parseNaturalDate(dateStr: string): string {
  if (!dateStr) return new Date().toISOString().split('T')[0];
  
  const lower = dateStr.toLowerCase().trim();
  const today = new Date();
  
  if (lower === 'today') {
    return today.toISOString().split('T')[0];
  }
  
  if (lower === 'tomorrow') {
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  }
  
  if (lower.startsWith('next ')) {
    const dayName = lower.replace('next ', '');
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const targetDay = days.indexOf(dayName);
    if (targetDay !== -1) {
      const currentDay = today.getDay();
      let daysUntil = targetDay - currentDay;
      if (daysUntil <= 0) daysUntil += 7;
      const nextDate = new Date(today);
      nextDate.setDate(nextDate.getDate() + daysUntil);
      return nextDate.toISOString().split('T')[0];
    }
  }
  
  if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    return dateStr;
  }
  
  const parsed = new Date(dateStr);
  if (!isNaN(parsed.getTime())) {
    return parsed.toISOString().split('T')[0];
  }
  
  return today.toISOString().split('T')[0];
}

function formatTime(time: string): string {
  if (!time) return '';
  if (/^\d{2}:\d{2}$/.test(time)) return time;
  
  const match = time.match(/(\d{1,2}):?(\d{2})?\s*(am|pm)?/i);
  if (match) {
    let hours = parseInt(match[1], 10);
    const minutes = match[2] || '00';
    const period = match[3]?.toLowerCase();
    
    if (period === 'pm' && hours < 12) hours += 12;
    if (period === 'am' && hours === 12) hours = 0;
    
    return `${hours.toString().padStart(2, '0')}:${minutes}`;
  }
  
  return time;
}

export const ToolHandlers: Record<string, (params: Record<string, any>, context: ToolContext) => Promise<ToolResult>> = {
  
  async find_available_slots(params, context): Promise<ToolResult> {
    try {
      const officeId = params.officeId ||
        context.currentPatient?.officeId ||
        context.officeId ||
        localStorage.getItem('defaultOfficeId');

      if (!officeId) {
        return {
          success: false,
          message: 'I need an office to search for availability. Could you specify which office, or would you like me to list the available offices first?',
          error: 'MISSING_OFFICE_ID',
          suggestedFollowUp: 'Would you like me to list available offices?',
        };
      }

      const fromDate = parseNaturalDate(params.date);
      const duration = parseInt(params.duration, 10) || 30;

      // Resolve appointment type to ID from cache if name provided
      let appointmentTypeId: number | undefined;
      if (params.appointmentType) {
        try {
          const { default: OfficeDataCacheService } = await import('../officeDataCacheService');
          const types = await OfficeDataCacheService.getAppointmentTypes(officeId, context.companyId);
          const lowerType = params.appointmentType.toLowerCase();
          const matched = types.find(t => t.description.toLowerCase().includes(lowerType));
          if (matched) appointmentTypeId = matched.appointmentTypeId;
        } catch { /* ignore, will search without type filter */ }
      }

      const result = await EyefinityService.findNextAvailableSlot(officeId, {
        fromDate,
        providerName: params.providerName,
        duration,
        daysToSearch: 14,
        appointmentTypeId,
        companyId: context.companyId,
      });

      const slots = result?.slots || [];

      if (slots.length === 0) {
        return {
          success: true,
          message: `No available slots found starting from ${fromDate}${params.providerName ? ` with ${params.providerName}` : ''}.`,
          data: { slots: [] },
          suggestedFollowUp: 'Would you like me to search a different date range or provider?',
        };
      }

      const slotSummary = slots.slice(0, 5).map(slot =>
        `${slot.date} at ${slot.startTime} with ${slot.providerName}`
      ).join('\n- ');

      return {
        success: true,
        message: `Found ${slots.length} available slots. Here are the first few:\n- ${slotSummary}`,
        data: {
          slots,
          provider: result.provider,
        },
        pendingSelection: {
          type: 'slot',
          options: slots.slice(0, 10).map((slot, i) => ({
            id: `${i}`,
            label: `${slot.date} at ${slot.startTime} with ${slot.providerName}`,
            data: slot,
          })),
          prompt: 'Which slot would you like to book?',
        },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to find available slots: ${error.message}`,
        error: error.message,
      };
    }
  },

  async book_appointment(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id || context.currentPatientId;
      
      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        
        if (searchResult.items.length === 0) {
          return {
            success: false,
            message: `Could not find patient "${params.patientName}". Please verify the name.`,
            error: 'PATIENT_NOT_FOUND',
          };
        }
        
        if (searchResult.items.length > 1) {
          return {
            success: false,
            message: `Found ${searchResult.items.length} patients matching "${params.patientName}". Please be more specific.`,
            pendingSelection: {
              type: 'patient',
              options: searchResult.items.slice(0, 5).map(p => ({
                id: p.patientId,
                label: `${p.fullName} (DOB: ${p.dob || 'N/A'})`,
                data: p,
              })),
              prompt: 'Which patient did you mean?',
            },
          };
        }
        
        patientId = searchResult.items[0].patientId;
      }

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified. Please provide a patient name or select a patient first.',
          error: 'MISSING_PATIENT',
        };
      }

      let providerId = params.providerId || context.currentPatient?.providerId;
      
      if (!providerId && params.providerName) {
        const officeId = params.officeId || context.officeId;
        const providers = await EyefinityService.getProviders({ officeId });
        const lowerName = params.providerName.toLowerCase();
        const matchedProvider = providers.items.find(p => 
          p.fullName?.toLowerCase().includes(lowerName) ||
          p.lastName?.toLowerCase().includes(lowerName)
        );
        
        if (matchedProvider) {
          providerId = matchedProvider.guid || matchedProvider.staffId;
        }
      }

      if (!providerId) {
        return {
          success: false,
          message: 'No provider specified. Please provide a provider name.',
          error: 'MISSING_PROVIDER',
        };
      }

      const officeId = params.officeId || context.currentPatient?.officeId || context.officeId;
      
      if (!officeId) {
        return {
          success: false,
          message: 'No office specified. Please provide an office ID.',
          error: 'MISSING_OFFICE',
        };
      }

      const appointmentDate = parseNaturalDate(params.date);
      const startTime = formatTime(params.time);
      const endTimeDate = new Date(`2000-01-01T${startTime}`);
      endTimeDate.setMinutes(endTimeDate.getMinutes() + 30);
      const endTime = endTimeDate.toTimeString().slice(0, 5);

      // Resolve appointment type ID dynamically
      let appointmentTypeId = parseInt(params.appointmentTypeId, 10) || 0;
      if (!appointmentTypeId && params.appointmentType) {
        try {
          const { default: OfficeDataCacheService } = await import('../officeDataCacheService');
          const types = await OfficeDataCacheService.getAppointmentTypes(officeId, context.companyId);
          const lowerType = params.appointmentType.toLowerCase();
          const matched = types.find(t =>
            t.description.toLowerCase().includes(lowerType) ||
            (t.companyServiceName && t.companyServiceName.toLowerCase().includes(lowerType))
          );
          if (matched) appointmentTypeId = matched.appointmentTypeId;
        } catch { /* fallback below */ }
      }
      if (!appointmentTypeId) appointmentTypeId = 1;

      const payload = {
        PatientId: patientId,
        OfficeId: officeId,
        StaffId: providerId,
        AppointmentDate: appointmentDate,
        AppointmentStartTime: startTime,
        AppointmentEndTime: endTime,
        AppointmentTypeId: appointmentTypeId,
        AppointmentReason: params.reason || params.appointmentType || 'General Exam',
      };

      const result = await EyefinityService.createAppointment(providerId, payload);

      return {
        success: true,
        message: `Appointment booked successfully for ${appointmentDate} at ${startTime}.`,
        data: result,
        requiresConfirmation: false,
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to book appointment: ${error.message}`,
        error: error.message,
      };
    }
  },

  async cancel_appointment(params, context): Promise<ToolResult> {
    try {
      let appointmentId = params.appointmentId;
      
      if (!appointmentId && (params.patientName || params.date)) {
        const fromDate = params.date ? parseNaturalDate(params.date) : new Date().toISOString().split('T')[0];
        
        const appointments = await EyefinityService.getAppointments({
          fromDate,
          toDate: fromDate,
        });
        
        if (params.patientName) {
          const lowerName = params.patientName.toLowerCase();
          const matched = appointments.items.filter(a => 
            a.patientName?.toLowerCase().includes(lowerName)
          );
          
          if (matched.length === 0) {
            return {
              success: false,
              message: `No appointments found for "${params.patientName}" on ${fromDate}.`,
            };
          }
          
          if (matched.length > 1) {
            return {
              success: false,
              message: `Found ${matched.length} appointments. Please specify which one.`,
              pendingSelection: {
                type: 'appointment',
                options: matched.map(a => ({
                  id: a.appointmentId,
                  label: `${a.patientName} at ${a.startTime} with ${a.providerName}`,
                  data: a,
                })),
                prompt: 'Which appointment would you like to cancel?',
              },
            };
          }
          
          appointmentId = matched[0].appointmentId;
        }
      }
      
      if (!appointmentId) {
        return {
          success: false,
          message: 'No appointment specified. Please provide appointment details.',
          error: 'MISSING_APPOINTMENT',
        };
      }

      await EyefinityService.cancelAppointment(appointmentId, params.reason);

      return {
        success: true,
        message: `Appointment ${appointmentId} has been cancelled.`,
        requiresConfirmation: false,
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to cancel appointment: ${error.message}`,
        error: error.message,
      };
    }
  },

  async reschedule_appointment(params, context): Promise<ToolResult> {
    try {
      let appointmentId = params.appointmentId;
      
      if (!appointmentId && params.currentDate) {
        return {
          success: false,
          message: 'Please provide the appointment ID or more details to identify the appointment.',
          error: 'MISSING_APPOINTMENT',
        };
      }

      if (!params.newDate || !params.newTime) {
        return {
          success: false,
          message: 'Please provide both a new date and time for the rescheduled appointment.',
          error: 'MISSING_NEW_DATETIME',
        };
      }

      const result = await EyefinityService.rescheduleAppointment(appointmentId, {
        date: parseNaturalDate(params.newDate),
        startTime: formatTime(params.newTime),
        providerId: params.newProviderId,
      });

      return {
        success: true,
        message: `Appointment rescheduled to ${params.newDate} at ${params.newTime}.`,
        data: result,
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to reschedule appointment: ${error.message}`,
        error: error.message,
      };
    }
  },

  async get_todays_schedule(params, context): Promise<ToolResult> {
    try {
      const officeId = params.officeId || context.officeId;
      
      const appointments = await EyefinityService.getTodaysSchedule({
        officeId,
        providerId: params.providerId,
      });

      if (appointments.length === 0) {
        return {
          success: true,
          message: 'No appointments scheduled for today.',
          data: { appointments: [] },
        };
      }

      const summary = appointments.slice(0, 10).map(a => 
        `${a.startTime} - ${a.patientName} (${a.appointmentType})`
      ).join('\n- ');

      return {
        success: true,
        message: `Today's schedule (${appointments.length} appointments):\n- ${summary}`,
        data: { appointments },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to get today's schedule: ${error.message}`,
        error: error.message,
      };
    }
  },

  async search_patient(params, context): Promise<ToolResult> {
    try {
      const result = await EyefinityService.searchPatients({
        lastName: params.lastName,
        firstName: params.firstName,
        phone: params.phone,
        dob: params.dob,
      });

      if (result.items.length === 0) {
        return {
          success: true,
          message: 'No patients found matching the search criteria.',
          data: { patients: [] },
        };
      }

      const patientList = result.items.slice(0, 5).map(p => 
        `${p.fullName} (DOB: ${p.dob || 'N/A'}, ID: ${p.patientId})`
      ).join('\n- ');

      return {
        success: true,
        message: `Found ${result.items.length} patient(s):\n- ${patientList}`,
        data: { patients: result.items },
        pendingSelection: result.items.length > 1 ? {
          type: 'patient',
          options: result.items.slice(0, 10).map(p => ({
            id: p.patientId,
            label: `${p.fullName} (DOB: ${p.dob || 'N/A'})`,
            data: p,
          })),
          prompt: 'Which patient would you like to work with?',
        } : undefined,
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to search patients: ${error.message}`,
        error: error.message,
      };
    }
  },

  async get_patient_details(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id || context.currentPatientId;

      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        
        if (searchResult.items.length === 0) {
          return {
            success: false,
            message: `No patient found with name "${params.patientName}".`,
          };
        }
        
        patientId = searchResult.items[0].patientId;
      }

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified. Please provide a patient name or ID.',
          error: 'MISSING_PATIENT',
        };
      }

      const patient = await EyefinityService.getPatientById(patientId);

      return {
        success: true,
        message: `Patient: ${patient.fullName}\nDOB: ${patient.dob || 'N/A'}\nPhone: ${patient.phone || 'N/A'}\nEmail: ${patient.email || 'N/A'}`,
        data: { patient },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to get patient details: ${error.message}`,
        error: error.message,
      };
    }
  },

  async checkin_patient(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id || context.currentPatientId;
      let patientName = params.patientName || context.currentPatient?.name;

      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        if (searchResult.items.length > 0) {
          patientId = searchResult.items[0].patientId;
          patientName = searchResult.items[0].fullName;
        }
      }

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified. Please provide a patient name or ID.',
          error: 'MISSING_PATIENT',
        };
      }

      // Check for existing journey and transition to in-office
      const existingJourney = PatientJourneyService.getJourneyByPatientId(patientId);

      if (existingJourney && existingJourney.journeyPhase === 'pre-visit') {
        // Transition to in-office phase
        const updatedJourney = PatientJourneyService.transitionPhase(existingJourney.id, 'in-office');
        return {
          success: true,
          message: `${patientName || 'Patient'} has been checked in. Journey transitioned to in-office phase.`,
          data: { checkedIn: true, journey: updatedJourney },
        };
      } else if (existingJourney && existingJourney.journeyPhase === 'in-office') {
        return {
          success: true,
          message: `${patientName || 'Patient'} is already checked in (in-office phase).`,
          data: { checkedIn: true, journey: existingJourney },
        };
      } else {
        // No journey exists — create one starting at in-office
        const journey = PatientJourneyService.createJourney({
          patientId,
          patientName: patientName || 'Unknown Patient',
          reasonForVisit: 'Check-in',
          startPhase: 'in-office',
          scheduledAppointmentDate: new Date(),
        });

        return {
          success: true,
          message: `${patientName || 'Patient'} has been checked in and an in-office journey has been started.`,
          data: { checkedIn: true, journey },
        };
      }
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to check in patient: ${error.message}`,
        error: error.message,
      };
    }
  },

  async create_patient(params, context): Promise<ToolResult> {
    try {
      if (!params.firstName || !params.lastName) {
        return {
          success: false,
          message: 'I need at least a first name and last name to register a new patient. Please provide both.',
          error: 'MISSING_REQUIRED_FIELDS',
        };
      }

      if (!params.phone) {
        return {
          success: false,
          message: 'A phone number is required to create a patient in Eyefinity. Please provide one.',
          error: 'MISSING_PHONE',
        };
      }

      if (!params.dateOfBirth) {
        return {
          success: false,
          message: 'A date of birth is required to create a patient in Eyefinity. Please provide one (e.g., 01/15/1990).',
          error: 'MISSING_DOB',
        };
      }

      const officeId = context.officeId;
      if (!officeId) {
        return {
          success: false,
          message: 'No office selected. Please select an office first.',
          error: 'MISSING_OFFICE',
        };
      }

      // Format DOB to YYYY-MM-DD if provided in other formats
      let dob = params.dateOfBirth;
      if (dob && dob.includes('/')) {
        const parts = dob.split('/');
        if (parts.length === 3) {
          const [month, day, year] = parts;
          dob = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
        }
      }

      const patient = await EyefinityService.createPatient({
        firstName: params.firstName,
        lastName: params.lastName,
        dateOfBirth: dob,
        homeOfficeId: officeId,
        phone: params.phone,
        email: params.email,
        gender: params.gender,
        primaryProviderId: params.providerId || context.currentPatient?.providerId,
      }, context.companyId);

      return {
        success: true,
        message: `New patient registered in Eyefinity: ${params.firstName} ${params.lastName} (Phone: ${params.phone})${params.email ? ` (Email: ${params.email})` : ''}`,
        data: { patient },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to create patient: ${error.message}`,
        error: error.message,
      };
    }
  },

  async send_sms(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id || context.currentPatientId;
      let patientName = params.patientName || context.currentPatient?.name;

      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        if (searchResult.items.length > 0) {
          patientId = searchResult.items[0].patientId;
          patientName = searchResult.items[0].fullName;
        }
      }

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified. Please provide a patient name or ID.',
          error: 'MISSING_PATIENT',
        };
      }

      if (!params.message) {
        return {
          success: false,
          message: 'No message content provided. What would you like the SMS to say?',
          error: 'MISSING_MESSAGE',
        };
      }

      const result = await CommunicationService.sendSMS(
        patientId,
        params.message,
        context.staffName || 'AI Assistant'
      );

      return {
        success: true,
        message: `SMS sent to ${patientName || 'patient'}: "${params.message.substring(0, 80)}${params.message.length > 80 ? '...' : ''}"`,
        data: { messageId: result.id, status: result.status },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to send SMS: ${error.message}`,
        error: error.message,
      };
    }
  },

  async send_email(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id || context.currentPatientId;
      let patientName = params.patientName || context.currentPatient?.name;

      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        if (searchResult.items.length > 0) {
          patientId = searchResult.items[0].patientId;
          patientName = searchResult.items[0].fullName;
        }
      }

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified. Please provide a patient name or ID.',
          error: 'MISSING_PATIENT',
        };
      }

      if (!params.subject || !params.body) {
        return {
          success: false,
          message: 'Please provide both a subject and body for the email.',
          error: 'MISSING_CONTENT',
        };
      }

      const result = await CommunicationService.sendEmail(
        patientId,
        params.subject,
        params.body,
        context.staffName || 'AI Assistant'
      );

      return {
        success: true,
        message: `Email sent to ${patientName || 'patient'}: "${params.subject}"`,
        data: { messageId: result.id, status: result.status },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to send email: ${error.message}`,
        error: error.message,
      };
    }
  },

  async list_providers(params, context): Promise<ToolResult> {
    try {
      const officeId = params.officeId || context.officeId;
      const result = await EyefinityService.getProviders({ officeId });

      if (result.items.length === 0) {
        return {
          success: true,
          message: 'No providers found.',
          data: { providers: [] },
        };
      }

      const providerList = result.items.map(p => 
        `${p.fullName} (${p.providerType || 'Provider'})`
      ).join('\n- ');

      return {
        success: true,
        message: `Available providers:\n- ${providerList}`,
        data: { providers: result.items },
        pendingSelection: {
          type: 'provider',
          options: result.items.map(p => ({
            id: p.guid || p.staffId,
            label: p.fullName,
            data: p,
          })),
          prompt: 'Would you like to select a provider?',
        },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to list providers: ${error.message}`,
        error: error.message,
      };
    }
  },

  async list_offices(params, context): Promise<ToolResult> {
    try {
      const result = await EyefinityService.getOffices();

      if (result.items.length === 0) {
        return {
          success: true,
          message: 'No offices found.',
          data: { offices: [] },
        };
      }

      const officeList = result.items.map(o => 
        `${o.officeName} (ID: ${o.guid || o.officeId})`
      ).join('\n- ');

      return {
        success: true,
        message: `Practice offices:\n- ${officeList}`,
        data: { offices: result.items },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to list offices: ${error.message}`,
        error: error.message,
      };
    }
  },

  async list_appointment_types(params, context): Promise<ToolResult> {
    try {
      const officeId = params.officeId || context.officeId || localStorage.getItem('defaultOfficeId');
      if (!officeId) {
        return { success: false, message: 'No office specified.', error: 'MISSING_OFFICE_ID' };
      }

      const { default: OfficeDataCacheService } = await import('../officeDataCacheService');
      const types = await OfficeDataCacheService.getAppointmentTypes(officeId, context.companyId);

      if (types.length === 0) {
        return { success: true, message: 'No appointment types found for this office.', data: { appointmentTypes: [] } };
      }

      const activeTypes = types.filter(t => t.isActive);
      const typeList = activeTypes
        .map(t => `${t.description} (ID: ${t.appointmentTypeId}, ${t.duration} min)`)
        .join('\n- ');

      return {
        success: true,
        message: `Available appointment types:\n- ${typeList}`,
        data: { appointmentTypes: activeTypes },
      };
    } catch (error: any) {
      return { success: false, message: `Failed to list appointment types: ${error.message}`, error: error.message };
    }
  },

  async list_insurance_carriers(params, context): Promise<ToolResult> {
    try {
      const officeId = params.officeId || context.officeId || localStorage.getItem('defaultOfficeId');
      if (!officeId) {
        return { success: false, message: 'No office specified.', error: 'MISSING_OFFICE_ID' };
      }

      const { default: OfficeDataCacheService } = await import('../officeDataCacheService');
      let carriers = await OfficeDataCacheService.getInsuranceCarriers(officeId, context.companyId);

      if (params.searchName) {
        const lowerSearch = params.searchName.toLowerCase();
        carriers = carriers.filter(c => c.carrierName.toLowerCase().includes(lowerSearch));
      }

      if (carriers.length === 0) {
        return {
          success: true,
          message: params.searchName
            ? `No insurance carriers matching "${params.searchName}" found.`
            : 'No insurance carriers found for this office.',
          data: { insuranceCarriers: [] },
        };
      }

      const carrierList = carriers.map(c => c.carrierName).join('\n- ');
      return {
        success: true,
        message: `Accepted insurance carriers (${carriers.length}):\n- ${carrierList}`,
        data: { insuranceCarriers: carriers },
      };
    } catch (error: any) {
      return { success: false, message: `Failed to list insurance carriers: ${error.message}`, error: error.message };
    }
  },

  async get_patient_orders(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id;

      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        
        if (searchResult.items.length > 0) {
          patientId = searchResult.items[0].patientId;
        }
      }

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified.',
          error: 'MISSING_PATIENT',
        };
      }

      const result = await EyefinityService.getPatientOrders(patientId);

      if (!result.items || result.items.length === 0) {
        return {
          success: true,
          message: 'No orders found for this patient.',
          data: { orders: [] },
        };
      }

      return {
        success: true,
        message: `Found ${result.items.length} order(s) for the patient.`,
        data: { orders: result.items },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to get patient orders: ${error.message}`,
        error: error.message,
      };
    }
  },

  async verify_insurance(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id;

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified for insurance verification.',
          error: 'MISSING_PATIENT',
        };
      }

      // Get patient data which includes insurance info
      const patient = await EyefinityService.getPatientById(patientId);
      const insurances = patient?.insurances || [];

      return {
        success: true,
        message: insurances.length > 0 
          ? `Found ${insurances.length} insurance record(s) for patient.`
          : 'No insurance records found for patient.',
        data: {
          patientId,
          patientName: `${patient?.firstName} ${patient?.lastName}`,
          insurances,
          hasInsurance: insurances.length > 0,
          primaryInsurance: insurances.find((i: any) => i.isPrimary) || null,
        },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to verify insurance: ${error.message}`,
        error: error.message,
      };
    }
  },

  // ==================== PATIENT JOURNEY TOOLS ====================

  async start_patient_journey(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id || context.currentPatientId;
      let patientName = params.patientName;

      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        
        if (searchResult.items.length > 0) {
          patientId = searchResult.items[0].patientId;
          patientName = searchResult.items[0].fullName;
        }
      }

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified. Please provide a patient name or select a patient first.',
          error: 'MISSING_PATIENT',
        };
      }

      // Check if journey already exists
      const existingJourney = PatientJourneyService.getJourneyByPatientId(patientId);
      if (existingJourney && existingJourney.journeyPhase !== 'completed') {
        return {
          success: false,
          message: `Patient ${patientName} already has an active journey in the "${existingJourney.journeyPhase}" phase.`,
          data: { journey: existingJourney },
          suggestedFollowUp: 'Would you like me to show the current journey status instead?',
        };
      }

      const journey = PatientJourneyService.createJourney({
        patientId,
        patientName: patientName || 'Unknown Patient',
        reasonForVisit: params.reasonForVisit || params.appointmentType || 'Eye Exam',
        providerName: params.providerName,
        priority: params.priority || 'normal',
        startPhase: params.startPhase || 'pre-visit',
        scheduledAppointmentDate: params.appointmentDate ? new Date(params.appointmentDate) : new Date(),
      });

      const currentStep = journey.steps.find((s: any) => s.id === journey.currentStepId);

      return {
        success: true,
        message: `Started patient journey for ${patientName}.\nPhase: ${journey.journeyPhase}\nCurrent Step: ${currentStep?.title || 'None'}\nTotal Steps: ${journey.steps.length}`,
        data: { journey },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to start patient journey: ${error.message}`,
        error: error.message,
      };
    }
  },

  async get_journey_status(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id || context.currentPatientId;

      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        
        if (searchResult.items.length > 0) {
          patientId = searchResult.items[0].patientId;
        }
      }

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified. Please provide a patient name or ID.',
          error: 'MISSING_PATIENT',
        };
      }

      const journey = PatientJourneyService.getJourneyByPatientId(patientId);

      if (!journey) {
        return {
          success: true,
          message: `No active journey found for this patient.`,
          data: { journey: null },
          suggestedFollowUp: 'Would you like me to start a new journey for this patient?',
        };
      }

      const currentStep = journey.steps.find(s => s.id === journey.currentStepId);
      const completedSteps = journey.steps.filter(s => s.status === 'completed').length;
      const pendingSteps = journey.steps.filter(s => s.status === 'pending');

      return {
        success: true,
        message: `Journey Status for ${journey.patientName}:\n` +
          `Phase: ${journey.journeyPhase}\n` +
          `Progress: ${journey.progressPercentage}%\n` +
          `Current Step: ${currentStep?.title || 'None'}\n` +
          `Completed: ${completedSteps}/${journey.steps.length} steps\n` +
          `Next Steps: ${pendingSteps.slice(0, 3).map(s => s.title).join(', ')}`,
        data: { journey },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to get journey status: ${error.message}`,
        error: error.message,
      };
    }
  },

  async complete_journey_step(params, context): Promise<ToolResult> {
    try {
      let journeyId = params.journeyId;
      
      if (!journeyId && (params.patientId || params.patientName || context.currentPatient?.id)) {
        const patientId = params.patientId || context.currentPatient?.id;
        const journey = PatientJourneyService.getJourneyByPatientId(patientId);
        if (journey) {
          journeyId = journey.id;
        }
      }

      if (!journeyId) {
        return {
          success: false,
          message: 'No journey specified. Please provide a journey ID or patient.',
          error: 'MISSING_JOURNEY',
        };
      }

      const journey = PatientJourneyService.getJourneyById(journeyId);
      if (!journey) {
        return {
          success: false,
          message: 'Journey not found.',
          error: 'JOURNEY_NOT_FOUND',
        };
      }

      // Find the step to complete
      let stepId = params.stepId;
      if (!stepId) {
        // Complete the current step
        stepId = journey.currentStepId;
      }

      if (!stepId) {
        return {
          success: false,
          message: 'No step to complete. The journey may already be completed.',
          error: 'NO_STEP',
        };
      }

      const updatedJourney = PatientJourneyService.completeStep(journeyId, stepId, params.notes);
      const completedStep = journey.steps.find(s => s.id === stepId);
      const nextStep = updatedJourney.steps.find(s => s.id === updatedJourney.currentStepId);

      return {
        success: true,
        message: `Completed step: "${completedStep?.title}".\n` +
          `Next step: ${nextStep?.title || 'None - phase complete'}\n` +
          `Progress: ${updatedJourney.progressPercentage}%`,
        data: { journey: updatedJourney },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to complete step: ${error.message}`,
        error: error.message,
      };
    }
  },

  async start_journey_step(params, context): Promise<ToolResult> {
    try {
      let journeyId = params.journeyId;
      
      if (!journeyId && (params.patientId || context.currentPatient?.id)) {
        const patientId = params.patientId || context.currentPatient?.id;
        const journey = PatientJourneyService.getJourneyByPatientId(patientId);
        if (journey) {
          journeyId = journey.id;
        }
      }

      if (!journeyId) {
        return {
          success: false,
          message: 'No journey specified.',
          error: 'MISSING_JOURNEY',
        };
      }

      const journey = PatientJourneyService.getJourneyById(journeyId);
      if (!journey) {
        return {
          success: false,
          message: 'Journey not found.',
          error: 'JOURNEY_NOT_FOUND',
        };
      }

      let stepId = params.stepId || journey.currentStepId;
      if (!stepId) {
        return {
          success: false,
          message: 'No step to start.',
          error: 'NO_STEP',
        };
      }

      const updatedJourney = PatientJourneyService.startStep(journeyId, stepId);
      const step = updatedJourney.steps.find(s => s.id === stepId);

      return {
        success: true,
        message: `Started step: "${step?.title}".\nStatus: In Progress`,
        data: { journey: updatedJourney },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to start step: ${error.message}`,
        error: error.message,
      };
    }
  },

  async skip_journey_step(params, context): Promise<ToolResult> {
    try {
      let journeyId = params.journeyId;
      
      if (!journeyId && (params.patientId || context.currentPatient?.id)) {
        const patientId = params.patientId || context.currentPatient?.id;
        const journey = PatientJourneyService.getJourneyByPatientId(patientId);
        if (journey) {
          journeyId = journey.id;
        }
      }

      if (!journeyId) {
        return {
          success: false,
          message: 'No journey specified.',
          error: 'MISSING_JOURNEY',
        };
      }

      const journey = PatientJourneyService.getJourneyById(journeyId);
      if (!journey) {
        return {
          success: false,
          message: 'Journey not found.',
          error: 'JOURNEY_NOT_FOUND',
        };
      }

      let stepId = params.stepId || journey.currentStepId;
      if (!stepId) {
        return {
          success: false,
          message: 'No step to skip.',
          error: 'NO_STEP',
        };
      }

      const updatedJourney = PatientJourneyService.skipStep(journeyId, stepId, params.reason);
      const skippedStep = journey.steps.find(s => s.id === stepId);
      const nextStep = updatedJourney.steps.find(s => s.id === updatedJourney.currentStepId);

      return {
        success: true,
        message: `Skipped step: "${skippedStep?.title}".\n` +
          `Reason: ${params.reason || 'Not specified'}\n` +
          `Next step: ${nextStep?.title || 'None'}`,
        data: { journey: updatedJourney },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to skip step: ${error.message}`,
        error: error.message,
      };
    }
  },

  async transition_journey_phase(params, context): Promise<ToolResult> {
    try {
      let journeyId = params.journeyId;
      
      if (!journeyId && (params.patientId || context.currentPatient?.id)) {
        const patientId = params.patientId || context.currentPatient?.id;
        const journey = PatientJourneyService.getJourneyByPatientId(patientId);
        if (journey) {
          journeyId = journey.id;
        }
      }

      if (!journeyId) {
        return {
          success: false,
          message: 'No journey specified.',
          error: 'MISSING_JOURNEY',
        };
      }

      if (!params.newPhase) {
        return {
          success: false,
          message: 'Please specify the new phase (pre-visit, in-office, post-visit, or completed).',
          error: 'MISSING_PHASE',
        };
      }

      const updatedJourney = PatientJourneyService.transitionPhase(journeyId, params.newPhase);

      return {
        success: true,
        message: `Transitioned journey to "${params.newPhase}" phase.\n` +
          `Patient: ${updatedJourney.patientName}\n` +
          `Progress: ${updatedJourney.progressPercentage}%`,
        data: { journey: updatedJourney },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to transition phase: ${error.message}`,
        error: error.message,
      };
    }
  },

  async list_active_journeys(params, context): Promise<ToolResult> {
    try {
      const phase = params.phase;
      let journeys = PatientJourneyService.getActiveJourneys();

      if (phase) {
        journeys = journeys.filter(j => j.journeyPhase === phase);
      }

      if (journeys.length === 0) {
        return {
          success: true,
          message: phase ? `No active journeys in the "${phase}" phase.` : 'No active journeys.',
          data: { journeys: [] },
        };
      }

      const journeyList = journeys.slice(0, 10).map(j => {
        const currentStep = j.steps.find(s => s.id === j.currentStepId);
        return `${j.patientName} - ${j.journeyPhase} (${currentStep?.title || 'No step'})`;
      }).join('\n- ');

      return {
        success: true,
        message: `Active journeys (${journeys.length}):\n- ${journeyList}`,
        data: { journeys },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to list journeys: ${error.message}`,
        error: error.message,
      };
    }
  },

  async cancel_patient_journey(params, context): Promise<ToolResult> {
    try {
      let journeyId = params.journeyId;
      
      if (!journeyId && (params.patientId || params.patientName || context.currentPatient?.id)) {
        let patientId = params.patientId || context.currentPatient?.id;
        
        if (!patientId && params.patientName) {
          const names = params.patientName.split(' ');
          const searchResult = await EyefinityService.searchPatients({
            firstName: names[0],
            lastName: names[names.length - 1],
          });
          if (searchResult.items.length > 0) {
            patientId = searchResult.items[0].patientId;
          }
        }
        
        if (patientId) {
          const journey = PatientJourneyService.getJourneyByPatientId(patientId);
          if (journey) {
            journeyId = journey.id;
          }
        }
      }

      if (!journeyId) {
        return {
          success: false,
          message: 'No journey found to cancel.',
          error: 'MISSING_JOURNEY',
        };
      }

      const updatedJourney = PatientJourneyService.cancelJourney(journeyId, params.reason);

      if (!updatedJourney) {
        return {
          success: false,
          message: 'Failed to cancel journey - journey not found.',
          error: 'JOURNEY_NOT_FOUND',
        };
      }

      return {
        success: true,
        message: `Cancelled journey for ${updatedJourney.patientName}.\nReason: ${params.reason || 'Not specified'}`,
        data: { journey: updatedJourney },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to cancel journey: ${error.message}`,
        error: error.message,
      };
    }
  },

  // ==================== FORMS TOOLS ====================

  async check_required_forms(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id || context.currentPatientId;
      let patientName = params.patientName || context.currentPatient?.name;

      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        if (searchResult.items.length > 0) {
          patientId = searchResult.items[0].patientId;
          patientName = searchResult.items[0].fullName;
        }
      }

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified. Please provide a patient name or ID.',
          error: 'MISSING_PATIENT',
        };
      }

      const eligibilityContext = {
        patientId,
        patientName: patientName || 'Unknown',
        isNewPatient: false, // Would need to check patient history
        appointmentType: params.appointmentType,
        appointmentDate: params.appointmentDate ? new Date(params.appointmentDate) : undefined,
        hasInsurance: true, // Default assumption
      };

      const requirements = FormEligibilityService.getRequiredForms(
        eligibilityContext,
        params.trigger
      );

      if (requirements.length === 0) {
        return {
          success: true,
          message: `No forms required for ${patientName}${params.trigger ? ` at ${params.trigger}` : ''}.`,
          data: { requirements: [] },
        };
      }

      const requiredForms = requirements.filter(r => r.status === 'required');
      const recommendedForms = requirements.filter(r => r.status === 'recommended');
      const overdueForms = requirements.filter(r => r.isOverdue);

      let message = `Forms for ${patientName}:\n`;
      
      if (overdueForms.length > 0) {
        message += `\n⚠️ OVERDUE (${overdueForms.length}):\n`;
        message += overdueForms.map(f => `- ${f.templateTitle}`).join('\n');
      }
      
      if (requiredForms.length > 0) {
        message += `\n\n📋 Required (${requiredForms.length}):\n`;
        message += requiredForms.map(f => `- ${f.templateTitle}${f.lastCompleted ? ` (last: ${new Date(f.lastCompleted).toLocaleDateString()})` : ''}`).join('\n');
      }
      
      if (recommendedForms.length > 0) {
        message += `\n\n📝 Recommended (${recommendedForms.length}):\n`;
        message += recommendedForms.map(f => `- ${f.templateTitle}`).join('\n');
      }

      return {
        success: true,
        message,
        data: { requirements, overdue: overdueForms.length, required: requiredForms.length },
        suggestedFollowUp: overdueForms.length > 0 ? 'Would you like me to send reminders for the overdue forms?' : undefined,
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to check required forms: ${error.message}`,
        error: error.message,
      };
    }
  },

  async send_patient_forms(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id || context.currentPatientId;
      let patientName = params.patientName || context.currentPatient?.name;
      let patientEmail = context.currentPatient?.email;
      let patientPhone = context.currentPatient?.phone;

      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        if (searchResult.items.length > 0) {
          patientId = searchResult.items[0].patientId;
          patientName = searchResult.items[0].fullName;
          patientEmail = searchResult.items[0].email;
          patientPhone = searchResult.items[0].phone;
        }
      }

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified. Please provide a patient name or ID.',
          error: 'MISSING_PATIENT',
        };
      }

      let templateIds: string[] = params.formTemplateIds || [];
      
      // Handle form type shortcuts with proper ID mapping
      if (params.formType && !templateIds.length) {
        if (params.formType === 'all-required') {
          const requirements = FormEligibilityService.getRequiredForms({
            patientId,
            patientName: patientName || 'Unknown',
            isNewPatient: false,
            hasInsurance: true,
          });
          templateIds = requirements.filter(r => r.status === 'required').map(r => r.templateId);
        } else {
          // Map shortcut names to actual template IDs
          const mappedId = FORM_TYPE_TO_TEMPLATE_ID[params.formType] || params.formType;
          templateIds = [mappedId];
        }
      }

      if (templateIds.length === 0) {
        return {
          success: false,
          message: 'No forms specified to send. Please provide form template IDs or a form type.',
          error: 'MISSING_FORMS',
        };
      }

      const sentForms: string[] = [];
      
      for (const templateId of templateIds) {
        const submission = FormSubmissionService.createSubmission({
          patientId,
          patientName: patientName || 'Patient',
          patientEmail,
          patientPhone,
          templateId,
        });

        await FormSubmissionService.sendFormToPatient(
          submission.submissionId,
          params.sendMethod !== 'sms' ? patientEmail : undefined,
          params.sendMethod !== 'email' ? patientPhone : undefined
        );

        FormEligibilityService.recordFormSent(patientId, templateId, submission.submissionId);
        sentForms.push(submission.formTitle);
      }

      return {
        success: true,
        message: `Sent ${sentForms.length} form(s) to ${patientName}:\n- ${sentForms.join('\n- ')}\n\nDelivery: ${params.sendMethod || 'email and SMS'}`,
        data: { sentForms, count: sentForms.length },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to send forms: ${error.message}`,
        error: error.message,
      };
    }
  },

  async send_form_reminder(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id || context.currentPatientId;
      let patientName = params.patientName || context.currentPatient?.name;

      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        if (searchResult.items.length > 0) {
          patientId = searchResult.items[0].patientId;
          patientName = searchResult.items[0].fullName;
        }
      }

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified.',
          error: 'MISSING_PATIENT',
        };
      }

      // Get pending forms for this patient
      const pendingForms = FormSubmissionService.getSubmissionsByPatientId(patientId)
        .filter(s => s.status !== 'completed' && s.status !== 'expired');

      if (pendingForms.length === 0) {
        return {
          success: true,
          message: `${patientName} has no pending forms to remind about.`,
          data: { reminders: 0 },
        };
      }

      let remindedCount = 0;
      const remindedForms: string[] = [];

      for (const form of pendingForms) {
        if (params.submissionId && form.submissionId !== params.submissionId) continue;
        
        await FormSubmissionService.resendForm(form.submissionId);
        remindedCount++;
        remindedForms.push(form.formTitle);
      }

      return {
        success: true,
        message: `Sent ${remindedCount} reminder(s) to ${patientName}:\n- ${remindedForms.join('\n- ')}`,
        data: { reminders: remindedCount, forms: remindedForms },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to send reminders: ${error.message}`,
        error: error.message,
      };
    }
  },

  async get_patient_form_status(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id || context.currentPatientId;
      let patientName = params.patientName || context.currentPatient?.name;

      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        if (searchResult.items.length > 0) {
          patientId = searchResult.items[0].patientId;
          patientName = searchResult.items[0].fullName;
        }
      }

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified.',
          error: 'MISSING_PATIENT',
        };
      }

      const submissions = FormSubmissionService.getSubmissionsByPatientId(patientId);
      
      const completed = submissions.filter(s => s.status === 'completed');
      const pending = submissions.filter(s => ['sent', 'viewed', 'in_progress'].includes(s.status));
      const expired = submissions.filter(s => s.status === 'expired');

      let message = `Form Status for ${patientName}:\n`;
      
      if (completed.length > 0) {
        message += `\n✅ Completed (${completed.length}):\n`;
        message += completed.slice(0, 5).map(f => 
          `- ${f.formTitle} (${new Date(f.completedAt!).toLocaleDateString()})`
        ).join('\n');
      }
      
      if (pending.length > 0) {
        message += `\n\n⏳ Pending (${pending.length}):\n`;
        message += pending.map(f => {
          const status = f.status === 'in_progress' ? 'In Progress' : 
                        f.status === 'viewed' ? 'Viewed' : 'Sent';
          return `- ${f.formTitle} (${status})`;
        }).join('\n');
      }
      
      if (expired.length > 0) {
        message += `\n\n❌ Expired (${expired.length}):\n`;
        message += expired.slice(0, 3).map(f => `- ${f.formTitle}`).join('\n');
      }

      if (submissions.length === 0) {
        message = `No forms have been sent to ${patientName} yet.`;
      }

      return {
        success: true,
        message,
        data: { 
          completed: completed.length, 
          pending: pending.length, 
          expired: expired.length,
          submissions 
        },
        suggestedFollowUp: pending.length > 0 ? 'Would you like me to send reminders for the pending forms?' : undefined,
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to get form status: ${error.message}`,
        error: error.message,
      };
    }
  },

  async list_form_templates(params, context): Promise<ToolResult> {
    try {
      let templates = FormSubmissionService.getTemplates();
      
      // Filter by category if specified
      if (params.category) {
        templates = templates.filter(t => t.category === params.category);
      }
      
      // Only show published templates
      templates = templates.filter(t => t.isPublished && !t.isArchived);

      if (templates.length === 0) {
        return {
          success: true,
          message: params.category 
            ? `No form templates found in category "${params.category}".`
            : 'No form templates available.',
          data: { templates: [] },
        };
      }

      const templateList = templates.map(t => 
        `- ${t.title}${t.description ? ` - ${t.description}` : ''} (ID: ${t.id})`
      ).join('\n');

      return {
        success: true,
        message: `Available form templates (${templates.length}):\n${templateList}`,
        data: { templates },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to list templates: ${error.message}`,
        error: error.message,
      };
    }
  },

  // ============================================
  // FTC RX COMPLIANCE TOOLS
  // ============================================

  async get_ftc_rx_status(params, context): Promise<ToolResult> {
    try {
      const patientId = params.patientId || context.currentPatient?.id;
      if (!patientId) {
        return {
          success: false,
          message: 'No patient ID available. Please specify a patient.',
          error: 'MISSING_PATIENT_ID',
        };
      }

      const requirements = FtcComplianceService.getComplianceRequirements(patientId);
      const consent = FtcComplianceService.getConsent(patientId);
      const acknowledgement = FtcComplianceService.getAcknowledgement(patientId);

      let statusMessage = `FTC Rx Compliance Status for ${params.patientName || 'patient'}:\n`;
      statusMessage += `- Overall: ${requirements.isComplete ? '✅ Complete' : '❌ Incomplete'}\n`;
      statusMessage += `- Consent: ${consent ? '✅ Received' : '❌ Needed'}\n`;
      if (consent) {
        statusMessage += `  Method: ${consent.consentType} (${consent.deliveryMethod || 'physical'})\n`;
      }
      statusMessage += `- Acknowledgement: ${acknowledgement ? '✅ Signed' : '❌ Needed'}\n`;

      return {
        success: true,
        message: statusMessage,
        data: { requirements, consent, acknowledgement },
        suggestedFollowUp: !requirements.isComplete 
          ? (requirements.needsConsent ? 'Would you like me to open the consent form?' : 'Would you like me to open the acknowledgement form?')
          : undefined,
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to get FTC status: ${error.message}`,
        error: error.message,
      };
    }
  },

  async send_rx_to_patient(params, context): Promise<ToolResult> {
    try {
      const patientId = params.patientId || context.currentPatient?.id;
      const patientName = params.patientName || context.currentPatient?.name;

      if (!params.deliveryMethod) {
        return {
          success: false,
          message: 'Please specify a delivery method (text, email, or portal).',
          error: 'MISSING_DELIVERY_METHOD',
        };
      }

      let deliveryDetails = params.deliveryDetails;
      if (!deliveryDetails && context.currentPatient) {
        if (params.deliveryMethod === 'text') {
          deliveryDetails = context.currentPatient.phone || (context.currentPatient as any).mobilePhone;
        } else if (params.deliveryMethod === 'email') {
          deliveryDetails = context.currentPatient.email;
        }
      }

      // Send via appropriate method
      if (params.deliveryMethod === 'text' && deliveryDetails) {
        const message = `Your eyeglass prescription is now available. Per FTC regulations, you have the right to receive a copy of your prescription. Please contact us if you have any questions.`;
        await CommunicationService.sendSMS(deliveryDetails, message);
      }

      // Track delivery
      FtcComplianceService.trackDelivery(patientId, {
        deliveryMethod: params.deliveryMethod,
        deliveryTimestamp: new Date().toISOString(),
        wasOpened: false,
      });

      return {
        success: true,
        message: `Prescription sent to ${patientName || 'patient'} via ${params.deliveryMethod}${deliveryDetails ? ` (${deliveryDetails})` : ''}.`,
        data: { deliveryMethod: params.deliveryMethod, deliveryDetails },
        requiresAction: {
          type: 'rx_delivery_sent',
          patientId,
          deliveryMethod: params.deliveryMethod,
        },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to send Rx: ${error.message}`,
        error: error.message,
      };
    }
  },

  async resend_rx_different_method(params, context): Promise<ToolResult> {
    try {
      const patientId = params.patientId || context.currentPatient?.id;
      const patientName = params.patientName || context.currentPatient?.name;

      if (!params.newDeliveryMethod) {
        return {
          success: false,
          message: 'Please specify a new delivery method.',
          error: 'MISSING_DELIVERY_METHOD',
        };
      }

      if (params.newDeliveryMethod === 'print') {
        return {
          success: true,
          message: `Opening print dialog for ${patientName || 'patient'}'s prescription...`,
          requiresAction: {
            type: 'print_rx',
            patientId,
          },
        };
      }

      // Resend via new method
      let deliveryDetails = params.newDeliveryDetails;
      if (!deliveryDetails && context.currentPatient) {
        if (params.newDeliveryMethod === 'text') {
          deliveryDetails = context.currentPatient.phone || (context.currentPatient as any).mobilePhone;
        } else if (params.newDeliveryMethod === 'email') {
          deliveryDetails = context.currentPatient.email;
        }
      }

      if (params.newDeliveryMethod === 'text' && deliveryDetails) {
        const message = `Your eyeglass prescription is now available (resent). Per FTC regulations, you have the right to receive a copy of your prescription.`;
        await CommunicationService.sendSMS(deliveryDetails, message);
      }

      // Update delivery tracking
      FtcComplianceService.trackDelivery(patientId, {
        deliveryMethod: params.newDeliveryMethod,
        deliveryTimestamp: new Date().toISOString(),
        wasOpened: false,
      });

      return {
        success: true,
        message: `Prescription resent to ${patientName || 'patient'} via ${params.newDeliveryMethod}${params.reason ? ` (reason: ${params.reason})` : ''}.`,
        data: { newDeliveryMethod: params.newDeliveryMethod, deliveryDetails },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to resend Rx: ${error.message}`,
        error: error.message,
      };
    }
  },

  async print_rx_acknowledgement(params, context): Promise<ToolResult> {
    const patientId = params.patientId || context.currentPatient?.id;
    const patientName = params.patientName || context.currentPatient?.name;

    return {
      success: true,
      message: `Opening print dialog for ${patientName || 'patient'}'s Rx acknowledgement...`,
      requiresAction: {
        type: 'print_rx_acknowledgement',
        patientId,
        patientName,
      },
    };
  },

  async request_rx_consent(params, context): Promise<ToolResult> {
    const patientId = params.patientId || context.currentPatient?.id;
    const patientName = params.patientName || context.currentPatient?.name;

    return {
      success: true,
      message: `Opening Rx consent form for ${patientName || 'patient'}...`,
      requiresAction: {
        type: 'show_rx_consent_form',
        patientId,
        patientName,
      },
    };
  },

  async request_rx_acknowledgement(params, context): Promise<ToolResult> {
    const patientId = params.patientId || context.currentPatient?.id;
    const patientName = params.patientName || context.currentPatient?.name;

    return {
      success: true,
      message: `Opening Rx acknowledgement form for ${patientName || 'patient'}...`,
      requiresAction: {
        type: 'show_rx_acknowledgement_form',
        patientId,
        patientName,
      },
    };
  },

  // ============================================
  // HIPAA COMPLIANCE TOOLS
  // ============================================

  async get_hipaa_status(params, context): Promise<ToolResult> {
    try {
      const patientId = params.patientId || context.currentPatient?.id;
      if (!patientId) {
        return {
          success: false,
          message: 'No patient ID available. Please specify a patient.',
          error: 'MISSING_PATIENT_ID',
        };
      }

      const status = HipaaComplianceService.getComplianceStatus(patientId);
      const record = HipaaComplianceService.getPatientRecord(patientId);

      let statusMessage = `HIPAA Signature Status for ${params.patientName || 'patient'}:\n`;
      if (status.isValid) {
        statusMessage += `✅ Valid - Expires in ${status.daysUntilExpiration} days\n`;
        statusMessage += `Last signed: ${new Date(status.lastSignatureDate!).toLocaleDateString()}`;
      } else if (status.isExpired) {
        statusMessage += `❌ Expired - Renewal required\n`;
        statusMessage += `Last signed: ${new Date(status.lastSignatureDate!).toLocaleDateString()}`;
      } else {
        statusMessage += `❌ Missing - Signature required`;
      }

      return {
        success: true,
        message: statusMessage,
        data: { status, record },
        suggestedFollowUp: !status.isValid ? 'Would you like me to open the HIPAA signature form?' : undefined,
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to get HIPAA status: ${error.message}`,
        error: error.message,
      };
    }
  },

  async request_hipaa_signature(params, context): Promise<ToolResult> {
    const patientId = params.patientId || context.currentPatient?.id;
    const patientName = params.patientName || context.currentPatient?.name;

    return {
      success: true,
      message: `Opening HIPAA signature form for ${patientName || 'patient'}...`,
      requiresAction: {
        type: 'show_hipaa_signature_form',
        patientId,
        patientName,
      },
    };
  },

  async get_compliance_summary(params, context): Promise<ToolResult> {
    try {
      const patientId = params.patientId || context.currentPatient?.id;
      const patientName = params.patientName || context.currentPatient?.name;

      if (!patientId) {
        return {
          success: false,
          message: 'No patient ID available. Please specify a patient.',
          error: 'MISSING_PATIENT_ID',
        };
      }

      const ftcReqs = FtcComplianceService.getComplianceRequirements(patientId);
      const hipaaStatus = HipaaComplianceService.getComplianceStatus(patientId);

      let summary = `Compliance Summary for ${patientName || 'patient'}:\n\n`;
      
      summary += `📋 FTC Rx Compliance:\n`;
      summary += `   ${ftcReqs.isComplete ? '✅ Complete' : '❌ Action Required'}\n`;
      if (!ftcReqs.isComplete) {
        if (ftcReqs.needsConsent) summary += `   - Needs: Rx Consent\n`;
        if (ftcReqs.needsDelivery) summary += `   - Needs: Rx Delivery\n`;
        if (ftcReqs.needsAcknowledgement) summary += `   - Needs: Rx Acknowledgement\n`;
      }

      summary += `\n🔒 HIPAA Signature:\n`;
      if (hipaaStatus.isValid) {
        summary += `   ✅ Valid (${hipaaStatus.daysUntilExpiration} days remaining)\n`;
      } else if (hipaaStatus.isExpired) {
        summary += `   ❌ Expired - Annual renewal required\n`;
      } else {
        summary += `   ❌ Missing - Signature required\n`;
      }

      const allComplete = ftcReqs.isComplete && hipaaStatus.isValid;
      summary += `\n${allComplete ? '✅ Patient is fully compliant!' : '⚠️ Action required before exam/checkout.'}`;

      return {
        success: true,
        message: summary,
        data: { ftcReqs, hipaaStatus, allComplete },
        suggestedFollowUp: !allComplete ? 'Would you like me to help complete the missing requirements?' : undefined,
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to get compliance summary: ${error.message}`,
        error: error.message,
      };
    }
  },

  // ==================== TASK MANAGEMENT TOOLS ====================

  async create_task(params, context): Promise<ToolResult> {
    try {
      if (!params.title) {
        return {
          success: false,
          message: 'Please provide a task title.',
          error: 'MISSING_TITLE',
        };
      }

      const dueAt = params.dueAt ? parseNaturalDate(params.dueAt) + 'T17:00:00Z' : undefined;

      const result = await TaskService.createTask({
        title: params.title,
        description: params.description,
        priority: params.priority || 'normal',
        assignee: params.assignee,
        category: params.category || 'general',
        status: 'pending',
        dueAt,
        createdBy: context.staffId,
        createdByName: context.staffName,
        assignedToOffice: context.officeId,
      });

      return {
        success: true,
        message: `Task created: "${params.title}"\nPriority: ${params.priority || 'normal'}${params.assignee ? `\nAssigned to: ${params.assignee}` : ''}${dueAt ? `\nDue: ${params.dueAt}` : ''}`,
        data: { task: result.task },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to create task: ${error.message}`,
        error: error.message,
      };
    }
  },

  async list_tasks(params, context): Promise<ToolResult> {
    try {
      const status = params.status || 'pending';
      const result = await TaskService.fetchTasks(status === 'all' ? undefined : status);
      const tasks = result.tasks || [];

      if (tasks.length === 0) {
        return {
          success: true,
          message: status === 'all' ? 'No tasks found.' : `No ${status} tasks found.`,
          data: { tasks: [] },
        };
      }

      const taskList = tasks.slice(0, 10).map(t => {
        const priority = t.priority === 'urgent' ? '🔴' : t.priority === 'high' ? '🟠' : t.priority === 'normal' ? '🟡' : '⚪';
        const statusIcon = t.status === 'completed' ? '✅' : t.status === 'in_progress' ? '🔄' : t.status === 'blocked' ? '🚫' : '⏳';
        return `${statusIcon} ${priority} ${t.title}${t.assignee ? ` (${t.assignee})` : ''} [${t.id.substring(0, 8)}]`;
      }).join('\n');

      return {
        success: true,
        message: `Tasks (${tasks.length}${status !== 'all' ? ` ${status}` : ''}):\n${taskList}`,
        data: { tasks },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to list tasks: ${error.message}`,
        error: error.message,
      };
    }
  },

  async update_task(params, context): Promise<ToolResult> {
    try {
      let taskId = params.taskId;

      // Find task by title if no ID provided
      if (!taskId && params.title) {
        const result = await TaskService.fetchTasks();
        const match = result.tasks.find(t =>
          t.title.toLowerCase().includes(params.title.toLowerCase())
        );
        if (match) {
          taskId = match.id;
        } else {
          return {
            success: false,
            message: `No task found matching "${params.title}".`,
            error: 'TASK_NOT_FOUND',
          };
        }
      }

      if (!taskId) {
        return {
          success: false,
          message: 'Please provide a task ID or title to update.',
          error: 'MISSING_TASK',
        };
      }

      const updates: Record<string, any> = {};
      if (params.status) updates.status = params.status;
      if (params.priority) updates.priority = params.priority;
      if (params.assignee) updates.assignee = params.assignee;

      const result = await TaskService.updateTask(taskId, updates);

      return {
        success: true,
        message: `Task updated: "${result.task.title}"\n${Object.entries(updates).map(([k, v]) => `${k}: ${v}`).join('\n')}`,
        data: { task: result.task },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to update task: ${error.message}`,
        error: error.message,
      };
    }
  },

  async complete_task(params, context): Promise<ToolResult> {
    try {
      let taskId = params.taskId;

      if (!taskId && params.title) {
        const result = await TaskService.fetchTasks();
        const match = result.tasks.find(t =>
          t.title.toLowerCase().includes(params.title.toLowerCase()) && t.status !== 'completed'
        );
        if (match) {
          taskId = match.id;
        } else {
          return {
            success: false,
            message: `No active task found matching "${params.title}".`,
            error: 'TASK_NOT_FOUND',
          };
        }
      }

      if (!taskId) {
        return {
          success: false,
          message: 'Please provide a task ID or title to complete.',
          error: 'MISSING_TASK',
        };
      }

      const result = await TaskService.updateTask(taskId, { status: 'completed' });

      return {
        success: true,
        message: `Task completed: "${result.task.title}" ✅`,
        data: { task: result.task },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to complete task: ${error.message}`,
        error: error.message,
      };
    }
  },

  // ==================== OUTBOUND VOICE CALL TOOLS ====================

  async make_outbound_call(params, context): Promise<ToolResult> {
    try {
      let phoneNumber = params.phoneNumber;
      let patientFirstName = '';
      let patientLastName = '';
      let patientId = params.patientId || context.currentPatient?.id || context.currentPatientId;

      // Look up patient phone if needed
      if (!phoneNumber && (patientId || params.patientName)) {
        if (!patientId && params.patientName) {
          const names = params.patientName.split(' ');
          const searchResult = await EyefinityService.searchPatients({
            firstName: names[0],
            lastName: names[names.length - 1],
          });
          if (searchResult.items.length > 0) {
            patientId = searchResult.items[0].patientId;
            patientFirstName = searchResult.items[0].firstName || names[0];
            patientLastName = searchResult.items[0].lastName || names[names.length - 1];
            phoneNumber = searchResult.items[0].phone || searchResult.items[0].mobilePhone;
          }
        } else if (patientId) {
          const patient = await EyefinityService.getPatientById(patientId);
          phoneNumber = patient.phone || patient.mobilePhone;
          patientFirstName = patient.firstName || '';
          patientLastName = patient.lastName || '';
        }
      }

      if (!phoneNumber) {
        return {
          success: false,
          message: 'No phone number available. Please provide a phone number or patient with a phone on file.',
          error: 'MISSING_PHONE',
        };
      }

      const response = await fetch('/api/voice/ai-outbound-call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: phoneNumber,
          patientId,
          patientFirstName,
          patientLastName,
          callType: params.callType || 'custom',
          script: params.script,
          appointmentDate: params.appointmentDate,
          appointmentTime: params.appointmentTime,
          useElevenLabs: true,
          recordCall: true,
        }),
      });

      const result = await response.json();

      if (!result.success) {
        return {
          success: false,
          message: `Failed to initiate call: ${result.error}`,
          error: result.error,
        };
      }

      return {
        success: true,
        message: `Outbound call initiated to ${params.patientName || phoneNumber}.\nCall type: ${params.callType || 'custom'}\nCall ID: ${result.callId}`,
        data: { callId: result.callId, status: result.status },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to make outbound call: ${error.message}`,
        error: error.message,
      };
    }
  },

  // ==================== ESCALATION TOOLS ====================

  async create_escalation(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id || context.currentPatientId;
      let patientName = params.patientName || context.currentPatient?.name || 'Unknown';

      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        if (searchResult.items.length > 0) {
          patientId = searchResult.items[0].patientId;
          patientName = searchResult.items[0].fullName;
        }
      }

      if (!params.reason) {
        return {
          success: false,
          message: 'Please provide a reason for the escalation.',
          error: 'MISSING_REASON',
        };
      }

      const escalation = CommunicationService.createEscalation(
        patientId || 'unknown',
        patientName,
        context.currentPatient?.appointmentId || '',
        params.reason,
        params.priority || 'medium',
        { source: 'ai', aiSuggestedAction: `Created by ${context.staffName || 'AI'} via chat` }
      );

      return {
        success: true,
        message: `Escalation created for ${patientName}:\nReason: ${params.reason}\nPriority: ${params.priority || 'medium'}\nID: ${escalation.id}`,
        data: { escalation },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to create escalation: ${error.message}`,
        error: error.message,
      };
    }
  },

  async list_escalations(params, context): Promise<ToolResult> {
    try {
      const showAll = params.showAll === 'true';
      const escalations = showAll
        ? CommunicationService.getEscalations()
        : CommunicationService.getActiveEscalations();

      if (escalations.length === 0) {
        return {
          success: true,
          message: showAll ? 'No escalations found.' : 'No active escalations.',
          data: { escalations: [] },
        };
      }

      const priorityIcon = (p: string) => p === 'urgent' ? '🔴' : p === 'high' ? '🟠' : p === 'medium' ? '🟡' : '⚪';
      const list = escalations.slice(0, 10).map(e =>
        `${priorityIcon(e.priority)} ${e.patientName} - ${e.reason} (${e.status}) [${e.id.substring(0, 12)}]`
      ).join('\n');

      return {
        success: true,
        message: `Escalations (${escalations.length}${!showAll ? ' active' : ''}):\n${list}`,
        data: { escalations },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to list escalations: ${error.message}`,
        error: error.message,
      };
    }
  },

  async resolve_escalation(params, context): Promise<ToolResult> {
    try {
      if (!params.escalationId) {
        return {
          success: false,
          message: 'Please provide the escalation ID to resolve.',
          error: 'MISSING_ID',
        };
      }

      CommunicationService.resolveEscalation(params.escalationId);

      return {
        success: true,
        message: `Escalation ${params.escalationId} has been resolved.${params.notes ? `\nNotes: ${params.notes}` : ''}`,
        data: { resolved: true },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to resolve escalation: ${error.message}`,
        error: error.message,
      };
    }
  },

  // ==================== SMS LINK TOOLS ====================

  async send_patient_link(params, context): Promise<ToolResult> {
    try {
      let phoneNumber = params.phoneNumber;
      let patientName = params.patientName || context.currentPatient?.name;

      // Look up patient phone if needed
      if (!phoneNumber && (params.patientId || params.patientName || context.currentPatient?.id)) {
        let patientId = params.patientId || context.currentPatient?.id;

        if (!patientId && params.patientName) {
          const names = params.patientName.split(' ');
          const searchResult = await EyefinityService.searchPatients({
            firstName: names[0],
            lastName: names[names.length - 1],
          });
          if (searchResult.items.length > 0) {
            patientId = searchResult.items[0].patientId;
            patientName = searchResult.items[0].fullName;
            phoneNumber = searchResult.items[0].phone || searchResult.items[0].mobilePhone;
          }
        } else if (patientId) {
          const patient = await EyefinityService.getPatientById(patientId);
          phoneNumber = patient.phone || patient.mobilePhone;
          patientName = patient.fullName || patientName;
        }
      }

      if (!phoneNumber) {
        return {
          success: false,
          message: 'No phone number available. Please provide a phone number or patient with a phone on file.',
          error: 'MISSING_PHONE',
        };
      }

      const response = await fetch('/api/voice/send-link', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: phoneNumber,
          linkType: params.linkType || 'portal',
          customUrl: params.customUrl,
          message: params.message,
        }),
      });

      const result = await response.json();

      if (!result.success) {
        return {
          success: false,
          message: `Failed to send link: ${result.error}`,
          error: result.error,
        };
      }

      return {
        success: true,
        message: `Link sent to ${patientName || phoneNumber} via SMS.\nType: ${params.linkType || 'portal'}`,
        data: { messageId: result.messageId },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to send link: ${error.message}`,
        error: error.message,
      };
    }
  },

  // ============================================
  // INSURANCE VERIFICATION TOOLS
  // ============================================

  async verify_insurance_benefits(params, context): Promise<ToolResult> {
    try {
      let patientId = params.patientId || context.currentPatient?.id;

      // Look up patient by name if needed
      if (!patientId && params.patientName) {
        const names = params.patientName.split(' ');
        const searchResult = await EyefinityService.searchPatients({
          firstName: names[0],
          lastName: names[names.length - 1],
        });
        if (searchResult.items.length > 0) {
          patientId = searchResult.items[0].patientId;
        }
      }

      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified. Please provide a patient ID or name.',
          error: 'MISSING_PATIENT',
        };
      }

      // Get patient insurance info
      const patient = await EyefinityService.getPatientById(patientId);
      const insurance = patient.insurances?.find((i: any) => i.isPrimary && i.isActive) || patient.insurances?.[0];

      if (!insurance) {
        return {
          success: false,
          message: `No active insurance found for ${patient.fullName || 'this patient'}.`,
          error: 'NO_INSURANCE',
        };
      }

      // Map carrier to payer type
      const carrierMap: Record<string, string> = {
        'vsp': 'vsp', 'vision service plan': 'vsp',
        'eyemed': 'eyemed', 'davis vision': 'davis-vision',
        'spectera': 'spectera', 'superior vision': 'superior-vision',
      };
      const carrierLower = (insurance.companyName || '').toLowerCase();
      const payerType = Object.entries(carrierMap).find(([key]) => carrierLower.includes(key))?.[1];

      if (!payerType) {
        return {
          success: false,
          message: `Automated verification not supported for "${insurance.companyName}". Supported payers: VSP, EyeMed, Davis Vision, Spectera, Superior Vision.`,
          error: 'UNSUPPORTED_PAYER',
        };
      }

      const response = await fetch('/api/insurance-verification/queue-job', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientId,
          appointmentId: params.appointmentId,
          payerType,
          memberId: insurance.insuranceIdentificationNumber || '',
          subscriberDob: patient.dateOfBirth,
          triggeredBy: 'ai_chat',
        }),
      });

      const data = await response.json();

      if (data.status === 'cached') {
        const r = data.result;
        return {
          success: true,
          message: `Benefit verification for ${patient.fullName || 'patient'} (${payerType.toUpperCase()}):\n` +
            `Status: ${r.is_eligible ? 'ELIGIBLE' : 'NOT ELIGIBLE'}\n` +
            `Plan: ${r.plan_name || 'N/A'}\n` +
            (r.exam_copay != null ? `Exam Copay: $${r.exam_copay}\n` : '') +
            (r.frames_allowance != null ? `Frames Allowance: $${r.frames_allowance}\n` : '') +
            (r.lenses_copay != null ? `Lenses Copay: $${r.lenses_copay}\n` : '') +
            (r.contacts_allowance != null ? `Contacts Allowance: $${r.contacts_allowance}\n` : '') +
            `(Cached result from ${new Date(r.created_at).toLocaleString()})`,
          data: r,
        };
      }

      if (data.jobId) {
        return {
          success: true,
          message: `Verification job queued for ${patient.fullName || 'patient'} (${payerType.toUpperCase()}). Job ID: ${data.jobId}. The verification worker will process this shortly. Use check_verification_status to monitor progress.`,
          data: { jobId: data.jobId, status: data.status },
        };
      }

      return {
        success: false,
        message: data.error || 'Failed to queue verification',
        error: data.error,
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Verification failed: ${error.message}`,
        error: error.message,
      };
    }
  },

  async get_insurance_benefits(params, context): Promise<ToolResult> {
    try {
      const patientId = params.patientId || context.currentPatient?.id;
      if (!patientId) {
        return {
          success: false,
          message: 'No patient specified.',
          error: 'MISSING_PATIENT',
        };
      }

      const response = await fetch(`/api/insurance-verification/results?patientId=${patientId}`);
      const data = await response.json();

      if (!data.results?.length) {
        return {
          success: true,
          message: 'No benefit verification results found for this patient. Use verify_insurance_benefits to run a verification.',
          data: { results: [] },
        };
      }

      const r = data.results[0];
      return {
        success: true,
        message: `Insurance benefits for patient (${(r.payerType || '').toUpperCase()}):\n` +
          `Eligibility: ${r.isEligible ? 'ELIGIBLE' : 'NOT ELIGIBLE'} (${r.eligibilityStatus || 'N/A'})\n` +
          `Plan: ${r.planName || 'N/A'} (${r.planType || 'N/A'})\n` +
          (r.benefits?.examCopay != null ? `Exam Copay: $${r.benefits.examCopay}\n` : '') +
          (r.benefits?.framesAllowance != null ? `Frames Allowance: $${r.benefits.framesAllowance}\n` : '') +
          (r.benefits?.framesCopay != null ? `Frames Copay: $${r.benefits.framesCopay}\n` : '') +
          (r.benefits?.lensesCopay != null ? `Lenses Copay: $${r.benefits.lensesCopay}\n` : '') +
          (r.benefits?.contactsAllowance != null ? `Contacts Allowance: $${r.benefits.contactsAllowance}\n` : '') +
          (r.eligibleDates?.exam ? `Next Exam Eligible: ${r.eligibleDates.exam}\n` : '') +
          (r.eligibleDates?.frames ? `Next Frames Eligible: ${r.eligibleDates.frames}\n` : '') +
          `Verified: ${new Date(r.createdAt).toLocaleString()}`,
        data: r,
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to get benefits: ${error.message}`,
        error: error.message,
      };
    }
  },

  async check_verification_status(params): Promise<ToolResult> {
    try {
      if (!params.jobId) {
        return {
          success: false,
          message: 'No job ID provided.',
          error: 'MISSING_JOB_ID',
        };
      }

      const response = await fetch(`/api/insurance-verification/job-status?jobId=${params.jobId}`);
      const data = await response.json();

      if (!data.job) {
        return {
          success: false,
          message: 'Verification job not found.',
          error: 'NOT_FOUND',
        };
      }

      const job = data.job;
      let message = `Verification job ${job.id}:\n` +
        `Status: ${job.status.toUpperCase()}\n` +
        `Payer: ${(job.payerType || '').toUpperCase()}\n` +
        `Attempts: ${job.attempts}/${job.maxAttempts}\n`;

      if (job.status === 'completed' && data.result) {
        message += `\nResult: ${data.result.is_eligible ? 'ELIGIBLE' : 'NOT ELIGIBLE'}\n` +
          `Plan: ${data.result.plan_name || 'N/A'}`;
      } else if (job.status === 'mfa_waiting') {
        message += `\nWaiting for MFA code. A staff member needs to enter the code from the payer portal.`;
      } else if (job.status === 'failed') {
        message += `\nError: ${job.lastError || 'Unknown error'}`;
      }

      return {
        success: true,
        message,
        data: { job: data.job, result: data.result },
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to check status: ${error.message}`,
        error: error.message,
      };
    }
  },
};

export async function executeToolHandler(
  toolName: string,
  params: Record<string, any>,
  context: ToolContext
): Promise<ToolResult> {
  const handler = ToolHandlers[toolName];
  
  if (!handler) {
    return {
      success: false,
      message: `Unknown tool: ${toolName}`,
      error: 'UNKNOWN_TOOL',
    };
  }

  try {
    return await handler(params, context);
  } catch (error: any) {
    console.error(`[ToolHandler] Error executing ${toolName}:`, error);
    return {
      success: false,
      message: `Error executing ${toolName}: ${error.message}`,
      error: error.message,
    };
  }
}

export default ToolHandlers;
