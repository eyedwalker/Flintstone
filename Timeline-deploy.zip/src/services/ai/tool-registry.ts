/**
 * AI Tool Registry
 * Defines all available tools with Claude-compatible schemas
 */

import type { ToolDefinition } from './types';

export const TOOL_DEFINITIONS: ToolDefinition[] = [
  // ============================================
  // SCHEDULING TOOLS
  // ============================================
  {
    name: 'find_available_slots',
    description: 'Find available appointment slots for a given date range and optionally a specific provider. Use this when the user asks about availability, open slots, or when to schedule.',
    category: 'scheduling',
    inputSchema: {
      type: 'object',
      properties: {
        date: {
          type: 'string',
          description: 'Target date or date range (e.g., "today", "tomorrow", "next Monday", "2026-01-25")',
        },
        providerName: {
          type: 'string',
          description: 'Optional provider/doctor name to filter slots',
        },
        officeId: {
          type: 'string',
          description: 'Optional office ID (GUID) to search in specific office',
        },
        duration: {
          type: 'string',
          description: 'Appointment duration in minutes (default: 30)',
        },
        appointmentType: {
          type: 'string',
          description: 'Type of appointment (e.g., "Comprehensive Exam", "Contact Lens Fitting"). Helps find slots with the correct duration.',
        },
      },
      required: ['date'],
    },
  },
  {
    name: 'book_appointment',
    description: 'Book an appointment for a patient. Requires patient ID, date, time, and provider.',
    category: 'scheduling',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID to book appointment for',
        },
        patientName: {
          type: 'string',
          description: 'Patient name (used to look up if ID not provided)',
        },
        date: {
          type: 'string',
          description: 'Appointment date',
        },
        time: {
          type: 'string',
          description: 'Appointment start time',
        },
        providerId: {
          type: 'string',
          description: 'Provider/staff ID (GUID)',
        },
        providerName: {
          type: 'string',
          description: 'Provider name (used to look up if ID not provided)',
        },
        appointmentType: {
          type: 'string',
          description: 'Type of appointment (e.g., "General Exam", "Follow-up")',
        },
        appointmentTypeId: {
          type: 'string',
          description: 'Appointment type ID (integer). Use list_appointment_types to find the correct ID.',
        },
        reason: {
          type: 'string',
          description: 'Reason for appointment',
        },
      },
      required: ['date', 'time'],
    },
    requiresConfirmation: true,
  },
  {
    name: 'cancel_appointment',
    description: 'Cancel an existing appointment',
    category: 'scheduling',
    inputSchema: {
      type: 'object',
      properties: {
        appointmentId: {
          type: 'string',
          description: 'ID of the appointment to cancel',
        },
        patientName: {
          type: 'string',
          description: 'Patient name (to find appointment if ID not provided)',
        },
        date: {
          type: 'string',
          description: 'Appointment date (to find appointment if ID not provided)',
        },
        reason: {
          type: 'string',
          description: 'Reason for cancellation',
        },
      },
    },
    requiresConfirmation: true,
  },
  {
    name: 'reschedule_appointment',
    description: 'Reschedule an existing appointment to a new date/time',
    category: 'scheduling',
    inputSchema: {
      type: 'object',
      properties: {
        appointmentId: {
          type: 'string',
          description: 'ID of the appointment to reschedule',
        },
        patientName: {
          type: 'string',
          description: 'Patient name (to find appointment if ID not provided)',
        },
        currentDate: {
          type: 'string',
          description: 'Current appointment date',
        },
        newDate: {
          type: 'string',
          description: 'New appointment date',
        },
        newTime: {
          type: 'string',
          description: 'New appointment time',
        },
        newProviderId: {
          type: 'string',
          description: 'Optional new provider ID',
        },
      },
      required: ['newDate', 'newTime'],
    },
    requiresConfirmation: true,
  },
  {
    name: 'get_todays_schedule',
    description: 'Get today\'s appointment schedule. Can filter by provider or office.',
    category: 'scheduling',
    inputSchema: {
      type: 'object',
      properties: {
        providerName: {
          type: 'string',
          description: 'Optional provider name to filter',
        },
        officeId: {
          type: 'string',
          description: 'Optional office ID to filter',
        },
      },
    },
  },

  // ============================================
  // PATIENT TOOLS
  // ============================================
  {
    name: 'search_patient',
    description: 'Search for patients by name, phone number, or date of birth',
    category: 'patient',
    inputSchema: {
      type: 'object',
      properties: {
        lastName: {
          type: 'string',
          description: 'Patient last name',
        },
        firstName: {
          type: 'string',
          description: 'Patient first name',
        },
        phone: {
          type: 'string',
          description: 'Patient phone number',
        },
        dob: {
          type: 'string',
          description: 'Patient date of birth (YYYY-MM-DD)',
        },
      },
    },
  },
  {
    name: 'get_patient_details',
    description: 'Get detailed information about a specific patient including contact info, insurance, and recent appointments',
    category: 'patient',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name (used if ID not provided)',
        },
      },
    },
  },
  {
    name: 'checkin_patient',
    description: 'Check in a patient for their appointment',
    category: 'patient',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
        appointmentId: {
          type: 'string',
          description: 'Appointment ID',
        },
      },
    },
  },
  {
    name: 'create_patient',
    description: 'Register a new patient in the system. Requires at least first name, last name, and a phone number or email.',
    category: 'patient',
    inputSchema: {
      type: 'object',
      properties: {
        firstName: {
          type: 'string',
          description: 'Patient first name',
        },
        lastName: {
          type: 'string',
          description: 'Patient last name',
        },
        phone: {
          type: 'string',
          description: 'Patient phone number',
        },
        email: {
          type: 'string',
          description: 'Patient email address',
        },
        dateOfBirth: {
          type: 'string',
          description: 'Date of birth (YYYY-MM-DD or natural language)',
        },
        gender: {
          type: 'string',
          description: 'Patient gender',
          enum: ['male', 'female', 'other', 'prefer_not_to_say'],
        },
      },
      required: ['firstName', 'lastName'],
    },
    requiresConfirmation: true,
  },

  // ============================================
  // COMMUNICATION TOOLS
  // ============================================
  {
    name: 'send_sms',
    description: 'Send an SMS text message to a patient',
    category: 'communication',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name (used if ID not provided)',
        },
        phoneNumber: {
          type: 'string',
          description: 'Phone number to send to (used if patient ID not available)',
        },
        message: {
          type: 'string',
          description: 'Message content to send',
        },
        template: {
          type: 'string',
          description: 'Optional template name (e.g., "appointment_reminder", "pickup_ready")',
          enum: ['appointment_reminder', 'pickup_ready', 'custom'],
        },
      },
      required: ['message'],
    },
    requiresConfirmation: true,
  },
  {
    name: 'send_email',
    description: 'Send an email to a patient',
    category: 'communication',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
        emailAddress: {
          type: 'string',
          description: 'Email address (used if patient ID not available)',
        },
        subject: {
          type: 'string',
          description: 'Email subject',
        },
        body: {
          type: 'string',
          description: 'Email body content',
        },
        template: {
          type: 'string',
          description: 'Optional template name',
        },
      },
      required: ['subject', 'body'],
    },
    requiresConfirmation: true,
  },

  // ============================================
  // EYEFINITY/ADMIN TOOLS
  // ============================================
  {
    name: 'list_providers',
    description: 'List available providers/doctors at an office',
    category: 'eyefinity',
    inputSchema: {
      type: 'object',
      properties: {
        officeId: {
          type: 'string',
          description: 'Optional office ID to filter providers',
        },
      },
    },
  },
  {
    name: 'list_offices',
    description: 'List all practice offices',
    category: 'eyefinity',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'list_appointment_types',
    description: 'List available appointment types for the current office. Shows type name, ID, and default duration. Use this when the user asks about appointment types or before booking to find the correct type.',
    category: 'eyefinity',
    inputSchema: {
      type: 'object',
      properties: {
        officeId: {
          type: 'string',
          description: 'Office ID (uses current office if not provided)',
        },
      },
    },
  },
  {
    name: 'list_insurance_carriers',
    description: 'List insurance carriers accepted at the current office. Use when patients ask about accepted insurance or to look up carrier information.',
    category: 'eyefinity',
    inputSchema: {
      type: 'object',
      properties: {
        officeId: {
          type: 'string',
          description: 'Office ID (uses current office if not provided)',
        },
        searchName: {
          type: 'string',
          description: 'Optional carrier name to search/filter by',
        },
      },
    },
  },
  {
    name: 'get_patient_orders',
    description: 'Get eyewear orders for a patient',
    category: 'orders',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name (used if ID not provided)',
        },
      },
    },
  },
  {
    name: 'verify_insurance',
    description: 'Verify a patient\'s insurance coverage',
    category: 'patient',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
      },
    },
  },

  // ============================================
  // PATIENT JOURNEY TOOLS
  // ============================================
  {
    name: 'start_patient_journey',
    description: 'Start a patient journey for pre-visit, in-office, or post-visit workflow. This creates a journey with steps that track the patient through their visit.',
    category: 'journey',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name (used to look up if ID not provided)',
        },
        reasonForVisit: {
          type: 'string',
          description: 'Reason for the visit (e.g., "Annual Eye Exam", "Contact Lens Fitting")',
        },
        providerName: {
          type: 'string',
          description: 'Provider/doctor name',
        },
        priority: {
          type: 'string',
          description: 'Priority level',
          enum: ['normal', 'urgent', 'vip'],
        },
        startPhase: {
          type: 'string',
          description: 'Which phase to start in',
          enum: ['pre-visit', 'in-office'],
        },
        appointmentDate: {
          type: 'string',
          description: 'Scheduled appointment date',
        },
      },
    },
  },
  {
    name: 'get_journey_status',
    description: 'Get the current status and progress of a patient\'s journey including current phase, step, and completion percentage.',
    category: 'journey',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name (used to look up if ID not provided)',
        },
      },
    },
  },
  {
    name: 'complete_journey_step',
    description: 'Mark the current or specified step in a patient journey as completed and move to the next step.',
    category: 'journey',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        journeyId: {
          type: 'string',
          description: 'Journey ID (optional if patient ID provided)',
        },
        stepId: {
          type: 'string',
          description: 'Specific step ID to complete (defaults to current step)',
        },
        notes: {
          type: 'string',
          description: 'Optional notes about the completed step',
        },
      },
    },
  },
  {
    name: 'start_journey_step',
    description: 'Start/begin working on a journey step, marking it as in-progress.',
    category: 'journey',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        journeyId: {
          type: 'string',
          description: 'Journey ID',
        },
        stepId: {
          type: 'string',
          description: 'Step ID to start (defaults to current step)',
        },
      },
    },
  },
  {
    name: 'skip_journey_step',
    description: 'Skip a journey step (e.g., if not applicable to this patient).',
    category: 'journey',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        journeyId: {
          type: 'string',
          description: 'Journey ID',
        },
        stepId: {
          type: 'string',
          description: 'Step ID to skip (defaults to current step)',
        },
        reason: {
          type: 'string',
          description: 'Reason for skipping the step',
        },
      },
    },
  },
  {
    name: 'transition_journey_phase',
    description: 'Move a patient journey to a new phase (pre-visit → in-office → post-visit → completed).',
    category: 'journey',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        journeyId: {
          type: 'string',
          description: 'Journey ID',
        },
        newPhase: {
          type: 'string',
          description: 'New phase to transition to',
          enum: ['pre-visit', 'in-office', 'post-visit', 'completed'],
        },
      },
      required: ['newPhase'],
    },
  },
  {
    name: 'list_active_journeys',
    description: 'List all active patient journeys, optionally filtered by phase.',
    category: 'journey',
    inputSchema: {
      type: 'object',
      properties: {
        phase: {
          type: 'string',
          description: 'Filter by journey phase',
          enum: ['pre-visit', 'in-office', 'post-visit'],
        },
      },
    },
  },
  {
    name: 'cancel_patient_journey',
    description: 'Cancel an active patient journey.',
    category: 'journey',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
        journeyId: {
          type: 'string',
          description: 'Journey ID',
        },
        reason: {
          type: 'string',
          description: 'Reason for cancellation',
        },
      },
    },
    requiresConfirmation: true,
  },

  // ============================================
  // FORMS TOOLS
  // ============================================
  {
    name: 'check_required_forms',
    description: 'Check which forms a patient needs to complete based on their appointment type, insurance, and form completion history. Use this to see what forms are missing or overdue.',
    category: 'forms',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name (used to look up if ID not provided)',
        },
        appointmentType: {
          type: 'string',
          description: 'Type of appointment (e.g., "comprehensive-exam", "contact-lens-exam")',
        },
        appointmentDate: {
          type: 'string',
          description: 'Appointment date',
        },
        trigger: {
          type: 'string',
          description: 'When to check for forms',
          enum: ['pre-visit', 'check-in', 'post-visit'],
        },
      },
    },
  },
  {
    name: 'send_patient_forms',
    description: 'Send one or more forms to a patient via email and/or SMS. The patient will receive a link to complete the forms online.',
    category: 'forms',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
        formTemplateIds: {
          type: 'array',
          items: { type: 'string' },
          description: 'Array of form template IDs to send',
        },
        formType: {
          type: 'string',
          description: 'Type of form to send (alternative to specific IDs)',
          enum: ['patient-intake', 'hipaa-privacy', 'contact-lens-agreement', 'insurance-card-upload', 'drivers-license-upload', 'all-required'],
        },
        sendMethod: {
          type: 'string',
          description: 'How to send the form link',
          enum: ['email', 'sms', 'both'],
        },
      },
    },
    requiresConfirmation: true,
  },
  {
    name: 'send_form_reminder',
    description: 'Send a reminder to a patient about incomplete forms they need to complete.',
    category: 'forms',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
        submissionId: {
          type: 'string',
          description: 'Specific form submission ID to remind about (optional - will remind about all pending if not specified)',
        },
        sendMethod: {
          type: 'string',
          description: 'How to send the reminder',
          enum: ['email', 'sms', 'both'],
        },
      },
    },
    requiresConfirmation: true,
  },
  {
    name: 'get_patient_form_status',
    description: 'Get the status of forms for a patient - which are completed, pending, or overdue.',
    category: 'forms',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
      },
    },
  },
  {
    name: 'list_form_templates',
    description: 'List available form templates that can be sent to patients.',
    category: 'forms',
    inputSchema: {
      type: 'object',
      properties: {
        category: {
          type: 'string',
          description: 'Filter by form category',
          enum: ['intake', 'consent', 'insurance', 'document-upload', 'survey'],
        },
      },
    },
  },

  // ============================================
  // FTC RX COMPLIANCE TOOLS
  // ============================================
  {
    name: 'get_ftc_rx_status',
    description: 'Get the FTC Eyeglass Rule compliance status for a patient. Shows if Rx consent, delivery, and acknowledgement are complete.',
    category: 'compliance',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name (used to look up if ID not provided)',
        },
      },
    },
  },
  {
    name: 'send_rx_to_patient',
    description: 'Send or resend the patient prescription via text, email, or patient portal. Use this when the patient needs their Rx delivered electronically.',
    category: 'compliance',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
        deliveryMethod: {
          type: 'string',
          description: 'How to deliver the prescription',
          enum: ['text', 'email', 'portal'],
        },
        deliveryDetails: {
          type: 'string',
          description: 'Phone number for text, email address for email (optional - uses patient record if not provided)',
        },
      },
      required: ['deliveryMethod'],
    },
    requiresConfirmation: true,
  },
  {
    name: 'resend_rx_different_method',
    description: 'Resend the prescription using a different delivery method when the original method did not work for the patient.',
    category: 'compliance',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
        newDeliveryMethod: {
          type: 'string',
          description: 'New delivery method to use',
          enum: ['text', 'email', 'portal', 'print'],
        },
        newDeliveryDetails: {
          type: 'string',
          description: 'New phone number or email address (optional)',
        },
        reason: {
          type: 'string',
          description: 'Reason for changing delivery method',
        },
      },
      required: ['newDeliveryMethod'],
    },
    requiresConfirmation: true,
  },
  {
    name: 'print_rx_acknowledgement',
    description: 'Print the Rx acknowledgement document for a patient. Use when patient needs a physical copy.',
    category: 'compliance',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
      },
    },
  },
  {
    name: 'request_rx_consent',
    description: 'Open the Rx consent form for a patient to choose their prescription delivery preference (electronic or physical).',
    category: 'compliance',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
      },
    },
  },
  {
    name: 'request_rx_acknowledgement',
    description: 'Open the Rx acknowledgement form for a patient to confirm receipt of their prescription.',
    category: 'compliance',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
      },
    },
  },

  // ============================================
  // HIPAA COMPLIANCE TOOLS
  // ============================================
  {
    name: 'get_hipaa_status',
    description: 'Get the HIPAA signature status for a patient. Shows if signature is valid, expired, or missing.',
    category: 'compliance',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
      },
    },
  },
  {
    name: 'request_hipaa_signature',
    description: 'Open the HIPAA authorization signature form for a patient. Required annually.',
    category: 'compliance',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
      },
    },
  },
  {
    name: 'get_compliance_summary',
    description: 'Get a summary of all compliance requirements (FTC Rx and HIPAA) for a patient. Use this to check what the patient needs before their appointment or checkout.',
    category: 'compliance',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
      },
    },
  },
  // ============================================
  // TASK MANAGEMENT TOOLS
  // ============================================
  {
    name: 'create_task',
    description: 'Create a new staff task (e.g., follow-up call, order check, patient callback). Tasks appear in the task management dashboard.',
    category: 'tasks',
    inputSchema: {
      type: 'object',
      properties: {
        title: {
          type: 'string',
          description: 'Task title/description',
        },
        description: {
          type: 'string',
          description: 'Detailed task description',
        },
        priority: {
          type: 'string',
          description: 'Task priority level',
          enum: ['low', 'normal', 'high', 'urgent'],
        },
        assignee: {
          type: 'string',
          description: 'Staff member to assign the task to',
        },
        category: {
          type: 'string',
          description: 'Task category',
          enum: ['callback', 'follow-up', 'order', 'billing', 'insurance', 'general'],
        },
        dueAt: {
          type: 'string',
          description: 'Due date/time (e.g., "today", "tomorrow 3pm", "2026-02-20")',
        },
      },
      required: ['title'],
    },
  },
  {
    name: 'list_tasks',
    description: 'List staff tasks, optionally filtered by status. Shows pending, in-progress, completed, or blocked tasks.',
    category: 'tasks',
    inputSchema: {
      type: 'object',
      properties: {
        status: {
          type: 'string',
          description: 'Filter by task status',
          enum: ['pending', 'in_progress', 'completed', 'blocked', 'all'],
        },
      },
    },
  },
  {
    name: 'update_task',
    description: 'Update an existing task (change status, priority, assignee, or description).',
    category: 'tasks',
    inputSchema: {
      type: 'object',
      properties: {
        taskId: {
          type: 'string',
          description: 'Task ID to update',
        },
        title: {
          type: 'string',
          description: 'Updated task title (to find by name if no ID)',
        },
        status: {
          type: 'string',
          description: 'New task status',
          enum: ['pending', 'in_progress', 'completed', 'blocked'],
        },
        priority: {
          type: 'string',
          description: 'New priority level',
          enum: ['low', 'normal', 'high', 'urgent'],
        },
        assignee: {
          type: 'string',
          description: 'New assignee',
        },
      },
    },
  },
  {
    name: 'complete_task',
    description: 'Mark a task as completed.',
    category: 'tasks',
    inputSchema: {
      type: 'object',
      properties: {
        taskId: {
          type: 'string',
          description: 'Task ID to complete',
        },
        title: {
          type: 'string',
          description: 'Task title (to find by name if no ID)',
        },
      },
    },
  },

  // ============================================
  // OUTBOUND VOICE CALL TOOLS
  // ============================================
  {
    name: 'make_outbound_call',
    description: 'Initiate an AI-powered outbound phone call to a patient. Supports appointment reminders, follow-ups, prescription ready notifications, recall reminders, and custom scripts.',
    category: 'voice',
    inputSchema: {
      type: 'object',
      properties: {
        phoneNumber: {
          type: 'string',
          description: 'Phone number to call (required if patient ID not provided)',
        },
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name (used to look up phone number)',
        },
        callType: {
          type: 'string',
          description: 'Type of call to make',
          enum: ['appointment_reminder', 'post_visit_followup', 'prescription_ready', 'recall_reminder', 'custom'],
        },
        script: {
          type: 'string',
          description: 'Custom script for the AI to speak (for custom call type)',
        },
        appointmentDate: {
          type: 'string',
          description: 'Appointment date (for reminder calls)',
        },
        appointmentTime: {
          type: 'string',
          description: 'Appointment time (for reminder calls)',
        },
      },
    },
    requiresConfirmation: true,
  },

  // ============================================
  // ESCALATION TOOLS
  // ============================================
  {
    name: 'create_escalation',
    description: 'Create an escalation alert for a patient issue that needs staff attention (complaint, urgent request, billing dispute, clinical concern).',
    category: 'escalation',
    inputSchema: {
      type: 'object',
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
        reason: {
          type: 'string',
          description: 'Reason for escalation',
        },
        priority: {
          type: 'string',
          description: 'Escalation priority',
          enum: ['low', 'medium', 'high', 'urgent'],
        },
      },
      required: ['reason'],
    },
  },
  {
    name: 'list_escalations',
    description: 'List escalation alerts. Shows active escalations by default.',
    category: 'escalation',
    inputSchema: {
      type: 'object',
      properties: {
        showAll: {
          type: 'string',
          description: 'Set to "true" to show all escalations including resolved ones',
        },
      },
    },
  },
  {
    name: 'resolve_escalation',
    description: 'Resolve an escalation alert with resolution notes.',
    category: 'escalation',
    inputSchema: {
      type: 'object',
      properties: {
        escalationId: {
          type: 'string',
          description: 'Escalation ID to resolve',
        },
        notes: {
          type: 'string',
          description: 'Resolution notes',
        },
      },
      required: ['escalationId'],
    },
  },

  // ============================================
  // SMS LINK TOOLS
  // ============================================
  {
    name: 'send_patient_link',
    description: 'Send a link to a patient via SMS (forms portal, directions, patient portal, or custom URL).',
    category: 'communication',
    inputSchema: {
      type: 'object',
      properties: {
        phoneNumber: {
          type: 'string',
          description: 'Phone number to send to',
        },
        patientId: {
          type: 'string',
          description: 'Patient ID (to look up phone number)',
        },
        patientName: {
          type: 'string',
          description: 'Patient name',
        },
        linkType: {
          type: 'string',
          description: 'Type of link to send',
          enum: ['forms', 'directions', 'portal', 'custom'],
        },
        customUrl: {
          type: 'string',
          description: 'Custom URL (when linkType is "custom")',
        },
        message: {
          type: 'string',
          description: 'Optional custom message to include with the link',
        },
      },
    },
    requiresConfirmation: true,
  },

  // ============================================
  // INSURANCE VERIFICATION TOOLS
  // ============================================

  {
    name: 'verify_insurance_benefits',
    description: 'Verify a patient\'s vision insurance benefits by checking their payer portal (VSP, EyeMed, Davis Vision). Queues an automated verification job that logs into the insurance portal and extracts benefit details. Returns cached results if available.',
    category: 'insurance' as ToolCategory,
    inputSchema: {
      type: 'object' as const,
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID to verify benefits for',
        },
        appointmentId: {
          type: 'string',
          description: 'Optional appointment ID to associate with verification',
        },
      },
      required: ['patientId'],
    },
    requiresConfirmation: false,
  },

  {
    name: 'get_insurance_benefits',
    description: 'Get the most recent insurance benefit verification results for a patient. Returns copays, allowances, eligibility dates, and plan details from a previous verification.',
    category: 'insurance' as ToolCategory,
    inputSchema: {
      type: 'object' as const,
      properties: {
        patientId: {
          type: 'string',
          description: 'Patient ID to get benefits for',
        },
      },
      required: ['patientId'],
    },
    requiresConfirmation: false,
  },

  {
    name: 'check_verification_status',
    description: 'Check the status of an insurance verification job. Returns whether it\'s queued, in progress, waiting for MFA, completed, or failed.',
    category: 'insurance' as ToolCategory,
    inputSchema: {
      type: 'object' as const,
      properties: {
        jobId: {
          type: 'string',
          description: 'Verification job ID to check status for',
        },
      },
      required: ['jobId'],
    },
    requiresConfirmation: false,
  },
];

export function getToolSchemas() {
  return TOOL_DEFINITIONS.map(tool => ({
    name: tool.name,
    description: tool.description,
    input_schema: tool.inputSchema,
  }));
}

export function getToolByName(name: string): ToolDefinition | undefined {
  return TOOL_DEFINITIONS.find(t => t.name === name);
}

export function getToolsByCategory(category: string): ToolDefinition[] {
  return TOOL_DEFINITIONS.filter(t => t.category === category);
}

export default TOOL_DEFINITIONS;
