/// <reference types="vite/client" />
/**
 * AI Persona Configuration
 * Defines the personality, voice, and behavior of AI assistants
 */

export interface AIPersona {
  id: string;
  name: string;
  role: string;
  officeId: string;
  isDefault: boolean;
  isActive: boolean;
  
  personality: {
    tone: 'professional' | 'friendly' | 'warm' | 'casual' | 'formal';
    traits: string[];
    greetingStyle: 'formal' | 'casual' | 'warm';
    signOffStyle: string;
  };
  
  voice: {
    provider: 'elevenlabs' | 'amazon-polly' | 'google' | 'azure';
    voiceId: string;
    voiceName?: string;
    stability: number;
    similarityBoost: number;
    style?: number;
    useSpeakerBoost?: boolean;
    model?: string;
    ambientAudio?: {
      enabled: boolean;
      type: 'office' | 'medical-office' | 'quiet' | 'custom';
      customUrl?: string;
      volume: number;
    };
  };
  
  channels: {
    sms: {
      enabled: boolean;
      maxLength: number;
      includePersonaName: boolean;
      signatureTemplate?: string;
    };
    voice: {
      enabled: boolean;
      greeting: string;
      holdMessage?: string;
      transferMessage?: string;
      voicemailGreeting?: string;
      interruptionSensitivity: 'low' | 'medium' | 'high';
      speakingRate: number;
    };
    email: {
      enabled: boolean;
      signature: string;
      replyPrefix?: string;
      includeDisclaimer: boolean;
    };
  };
  
  behavior: {
    canConfirmAppointments: boolean;
    canRescheduleAppointments: boolean;
    canCancelAppointments: boolean;
    canAnswerInsuranceQuestions: boolean;
    canProvideDirections: boolean;
    canTakeMessages: boolean;
    escalateKeywords: string[];
    escalateAfterAttempts: number;
    escalateOnSentiment: 'negative' | 'very-negative' | 'never';
    alwaysEscalateTopics: string[];
    maxResponseLength: number;
    requireApprovalFor: string[];
    prohibitedTopics: string[];
  };
  
  knowledge: {
    officeHours: string;
    officeAddress: string;
    officePhone: string;
    specialInstructions?: string;
    faqResponses?: Array<{
      question: string;
      answer: string;
    }>;
  };
  
  llmConfig: {
    provider: 'anthropic' | 'openai' | 'azure-openai';
    model: string;
    temperature: number;
    maxTokens: number;
    systemPromptOverride?: string;
  };
  
  stats?: {
    totalInteractions: number;
    successfulResolutions: number;
    escalations: number;
    averageSentiment: number;
    lastUsed?: string;
  };
  
  createdAt?: string;
  updatedAt?: string;
}

// LocalStorage key for personas
const PERSONAS_STORAGE_KEY = 'ai_personas';

/**
 * Get all personas from localStorage
 */
export function getPersonas(): AIPersona[] {
  try {
    const stored = localStorage.getItem(PERSONAS_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

/**
 * Save personas to localStorage
 */
export function savePersonas(personas: AIPersona[]): void {
  localStorage.setItem(PERSONAS_STORAGE_KEY, JSON.stringify(personas));
}

/**
 * Get default persona for an office
 */
export function getDefaultPersona(officeId: string): AIPersona | null {
  const personas = getPersonas();
  return personas.find(p => p.officeId === officeId && p.isDefault && p.isActive) || null;
}

/**
 * Get or create default persona for an office
 */
export function getOrCreateDefaultPersona(officeId: string, officeName?: string): AIPersona {
  const existing = getDefaultPersona(officeId);
  if (existing) return existing;
  
  const newPersona = createDefaultPersona(officeId, officeName);
  const personas = getPersonas();
  personas.push(newPersona);
  savePersonas(personas);
  return newPersona;
}

/**
 * Create a default persona
 */
export function createDefaultPersona(officeId: string, officeName?: string): AIPersona {
  return {
    id: `persona_${Date.now()}`,
    name: 'Sarah',
    role: 'Patient Care Coordinator',
    officeId,
    isDefault: true,
    isActive: true,
    personality: {
      tone: 'friendly',
      traits: ['empathetic', 'efficient', 'helpful', 'patient'],
      greetingStyle: 'warm',
      signOffStyle: 'Take care'
    },
    voice: {
      provider: 'elevenlabs',
      voiceId: 'EXAVITQu4vr4xnSDxMaL', // Sarah - warm, friendly female
      voiceName: 'Sarah',
      stability: 0.5,        // Lower = more expressive, Higher = more consistent
      similarityBoost: 0.75, // Higher = closer to original voice
      style: 0.3,            // Expressiveness (0-1)
      useSpeakerBoost: true, // Enhance clarity
      model: 'eleven_turbo_v2', // Fast, high-quality
      ambientAudio: {
        enabled: true,
        type: 'medical-office',
        volume: 0.08 // Subtle background noise
      }
    },
    channels: {
      sms: {
        enabled: true,
        maxLength: 160,
        includePersonaName: true
      },
      voice: {
        enabled: true,
        greeting: `Hello, thank you for calling ${officeName || 'our office'}. This is Sarah, how can I help you today?`,
        holdMessage: 'Please hold while I look that up for you.',
        transferMessage: 'Let me transfer you to someone who can help with that.',
        interruptionSensitivity: 'medium',
        speakingRate: 1.0
      },
      email: {
        enabled: true,
        signature: `\n\nBest regards,\nSarah\nPatient Care Coordinator\n${officeName || 'Our Office'}`,
        includeDisclaimer: true
      }
    },
    behavior: {
      canConfirmAppointments: true,
      canRescheduleAppointments: true,
      canCancelAppointments: false,
      canAnswerInsuranceQuestions: true,
      canProvideDirections: true,
      canTakeMessages: true,
      escalateKeywords: ['emergency', 'urgent', 'pain', 'bleeding', 'accident', 'manager', 'supervisor'],
      escalateAfterAttempts: 3,
      escalateOnSentiment: 'negative',
      alwaysEscalateTopics: ['billing dispute', 'complaint', 'refund', 'legal'],
      maxResponseLength: 500,
      requireApprovalFor: ['cancel_appointment'],
      prohibitedTopics: ['medical advice', 'diagnosis', 'prescriptions']
    },
    knowledge: {
      officeHours: 'Monday through Friday, 8 AM to 5 PM',
      officeAddress: '',
      officePhone: ''
    },
    llmConfig: {
      provider: 'anthropic',
      model: 'claude-3-haiku-20240307',
      temperature: 0.7,
      maxTokens: 500
    },
    stats: {
      totalInteractions: 0,
      successfulResolutions: 0,
      escalations: 0,
      averageSentiment: 0
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
}

/**
 * Update a persona
 */
export function updatePersona(personaId: string, updates: Partial<AIPersona>): AIPersona | null {
  const personas = getPersonas();
  const index = personas.findIndex(p => p.id === personaId);
  if (index === -1) return null;
  
  personas[index] = { ...personas[index], ...updates, updatedAt: new Date().toISOString() };
  
  // If setting as default, unset other defaults for same office
  if (updates.isDefault) {
    personas.forEach((p, i) => {
      if (i !== index && p.officeId === personas[index].officeId) {
        p.isDefault = false;
      }
    });
  }
  
  savePersonas(personas);
  return personas[index];
}

/**
 * Delete a persona
 */
export function deletePersona(personaId: string): boolean {
  const personas = getPersonas();
  const filtered = personas.filter(p => p.id !== personaId);
  if (filtered.length === personas.length) return false;
  savePersonas(filtered);
  return true;
}
