/// <reference types="vite/client" />
/**
 * ElevenLabs Voice Service
 * Handles text-to-speech generation with configurable voices and settings
 */

const ELEVENLABS_API_URL = 'https://api.elevenlabs.io/v1';

// Get API key from environment
const getApiKey = (): string | undefined => import.meta.env.VITE_ELEVENLABS_API_KEY;

export interface VoiceSettings {
  stability: number;           // 0-1
  similarity_boost: number;    // 0-1
  style?: number;              // 0-1 (only for v2 models)
  use_speaker_boost?: boolean;
}

export interface GenerateSpeechOptions {
  voiceId: string;
  text: string;
  modelId?: string;
  voiceSettings?: VoiceSettings;
  outputFormat?: 'mp3_44100_128' | 'mp3_22050_32' | 'pcm_16000' | 'pcm_22050' | 'pcm_24000' | 'ulaw_8000';
}

export interface StreamSpeechOptions extends GenerateSpeechOptions {
  optimizeStreamingLatency?: 0 | 1 | 2 | 3 | 4;
}

export interface Voice {
  voice_id: string;
  name: string;
  category: string;
  description?: string;
  preview_url?: string;
  labels?: Record<string, string>;
}

export interface AIPersonaVoice {
  provider: 'elevenlabs' | 'amazon-polly' | 'google' | 'azure';
  voiceId: string;
  voiceName?: string;
  stability: number;
  similarityBoost: number;
  style?: number;
  useSpeakerBoost?: boolean;
  model?: string;
}

export class ElevenLabsService {
  
  /**
   * Get available voices
   */
  static async getVoices(): Promise<Voice[]> {
    const apiKey = getApiKey();
    if (!apiKey) {
      throw new Error('VITE_ELEVENLABS_API_KEY not configured');
    }
    
    const response = await fetch(`${ELEVENLABS_API_URL}/voices`, {
      headers: {
        'xi-api-key': apiKey,
      },
    });
    
    if (!response.ok) {
      throw new Error(`Failed to get voices: ${response.status}`);
    }
    
    const data = await response.json();
    return data.voices;
  }
  
  /**
   * Generate speech from text (returns audio buffer)
   */
  static async generateSpeech(options: GenerateSpeechOptions): Promise<ArrayBuffer> {
    const apiKey = getApiKey();
    if (!apiKey) {
      throw new Error('VITE_ELEVENLABS_API_KEY not configured');
    }
    
    const {
      voiceId,
      text,
      modelId = 'eleven_turbo_v2_5',
      voiceSettings,
      outputFormat = 'mp3_44100_128'
    } = options;
    
    const response = await fetch(
      `${ELEVENLABS_API_URL}/text-to-speech/${voiceId}?output_format=${outputFormat}`,
      {
        method: 'POST',
        headers: {
          'xi-api-key': apiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text,
          model_id: modelId,
          voice_settings: voiceSettings || {
            stability: 0.3,
            similarity_boost: 0.75,
            style: 0.55,
            use_speaker_boost: true,
          },
        }),
      }
    );
    
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`ElevenLabs TTS failed: ${response.status} - ${error}`);
    }
    
    return response.arrayBuffer();
  }
  
  /**
   * Generate speech with streaming
   */
  static async streamSpeech(options: StreamSpeechOptions): Promise<ReadableStream<Uint8Array>> {
    const apiKey = getApiKey();
    if (!apiKey) {
      throw new Error('VITE_ELEVENLABS_API_KEY not configured');
    }
    
    const {
      voiceId,
      text,
      modelId = 'eleven_turbo_v2_5',
      voiceSettings,
      outputFormat = 'mp3_44100_128',
      optimizeStreamingLatency = 3
    } = options;
    
    const response = await fetch(
      `${ELEVENLABS_API_URL}/text-to-speech/${voiceId}/stream?output_format=${outputFormat}&optimize_streaming_latency=${optimizeStreamingLatency}`,
      {
        method: 'POST',
        headers: {
          'xi-api-key': apiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text,
          model_id: modelId,
          voice_settings: voiceSettings || {
            stability: 0.3,
            similarity_boost: 0.75,
            style: 0.55,
            use_speaker_boost: true,
          },
        }),
      }
    );
    
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`ElevenLabs stream failed: ${response.status} - ${error}`);
    }
    
    return response.body!;
  }
  
  /**
   * Generate speech using persona voice configuration
   */
  static async generateSpeechFromPersona(
    text: string, 
    voiceConfig: AIPersonaVoice,
    outputFormat: GenerateSpeechOptions['outputFormat'] = 'mp3_44100_128'
  ): Promise<ArrayBuffer> {
    if (voiceConfig.provider !== 'elevenlabs') {
      throw new Error(`Voice uses ${voiceConfig.provider}, not ElevenLabs`);
    }
    
    return this.generateSpeech({
      voiceId: voiceConfig.voiceId,
      text,
      modelId: voiceConfig.model || 'eleven_turbo_v2_5',
      voiceSettings: {
        stability: voiceConfig.stability,
        similarity_boost: voiceConfig.similarityBoost,
        style: voiceConfig.style,
        use_speaker_boost: voiceConfig.useSpeakerBoost,
      },
      outputFormat,
    });
  }
  
  /**
   * Get voice info
   */
  static async getVoice(voiceId: string): Promise<Voice> {
    const apiKey = getApiKey();
    if (!apiKey) {
      throw new Error('VITE_ELEVENLABS_API_KEY not configured');
    }
    
    const response = await fetch(`${ELEVENLABS_API_URL}/voices/${voiceId}`, {
      headers: {
        'xi-api-key': apiKey,
      },
    });
    
    if (!response.ok) {
      throw new Error(`Failed to get voice: ${response.status}`);
    }
    
    return response.json();
  }
  
  /**
   * Recommended voice presets for medical/office use
   */
  static readonly RECOMMENDED_VOICES = {
    'sarah-friendly': {
      voiceId: 'EXAVITQu4vr4xnSDxMaL',
      name: 'Sarah',
      description: 'Warm, friendly female voice - great for patient communication'
    },
    'rachel-professional': {
      voiceId: '21m00Tcm4TlvDq8ikWAM',
      name: 'Rachel',
      description: 'Clear, professional female voice'
    },
    'emily-warm': {
      voiceId: 'LcfcDJNUP1GQjkzn1xUU',
      name: 'Emily',
      description: 'Soft, empathetic female voice'
    },
    'josh-professional': {
      voiceId: 'TxGEqnHWrfWFTfGW9XjX',
      name: 'Josh',
      description: 'Friendly, professional male voice'
    },
    'adam-calm': {
      voiceId: 'pNInz6obpgDQGcFmaJgB',
      name: 'Adam',
      description: 'Deep, calm male voice'
    },
    'sam-conversational': {
      voiceId: 'yoZ06aMxZJJ28mfd3POQ',
      name: 'Sam',
      description: 'Natural, conversational male voice'
    }
  };
}

export const AMBIENT_AUDIO = {
  'medical-office': 'https://example-bucket.s3.amazonaws.com/ambient/medical-office.mp3',
  'office': 'https://example-bucket.s3.amazonaws.com/ambient/office-general.mp3',
  'quiet': 'https://example-bucket.s3.amazonaws.com/ambient/quiet-room.mp3',
};
