/// <reference types="vite/client" />
/**
 * SMS Conversation AI Evaluation Service
 * Analyzes SMS conversations for quality, sentiment, and insights
 */

import Anthropic from '@anthropic-ai/sdk';

const getAnthropicClient = () => {
  const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY;
  return apiKey ? new Anthropic({ apiKey, dangerouslyAllowBrowser: true }) : null;
};

// ==================== TYPES ====================

export interface SMSMessage {
  from: string;
  to: string;
  body: string;
  timestamp: string;
  direction: 'inbound' | 'outbound';
}

export interface SMSEvaluationInput {
  conversationId: string;
  messages: SMSMessage[];
  patientPhone: string;
  patientName?: string;
  officePhone: string;
}

export interface SMSEvaluationResult {
  conversationId: string;
  evaluatedAt: Date;
  
  // Quality Scores (0-100)
  overallScore: number;
  scores: {
    responseQuality: number;
    helpfulness: number;
    professionalism: number;
    clarity: number;
    timeliness: number;
    resolution: number;
  };
  
  // Sentiment Analysis
  sentiment: {
    overall: 'positive' | 'neutral' | 'negative';
    patientMood: 'satisfied' | 'neutral' | 'frustrated' | 'angry';
    aiTone: 'warm' | 'professional' | 'cold' | 'robotic';
    moodProgression: 'improved' | 'stable' | 'declined';
  };
  
  // Intent & Topics
  intents: {
    primary: string;
    secondary: string[];
    resolved: boolean;
  };
  topics: string[];
  
  // Compliance
  compliance: {
    hipaaCompliant: boolean;
    hipaaViolations: string[];
    piiExposed: boolean;
    piiTypes: string[];
    appropriateContent: boolean;
  };
  
  // Recommendations
  recommendations: {
    forAI: string[];
    forProcess: string[];
  };
  
  // Follow-up
  followUpRequired: boolean;
  followUpReason?: string;
  suggestedAction?: string;
  
  // Summary
  summary: string;
  messageCount: number;
  conversationDuration: string;
  keyExchanges: Array<{
    patientMessage: string;
    aiResponse: string;
    quality: 'excellent' | 'good' | 'adequate' | 'poor';
  }>;
}

// ==================== SERVICE ====================

export class SMSEvaluationService {
  
  /**
   * Evaluate an SMS conversation
   */
  static async evaluateConversation(input: SMSEvaluationInput): Promise<SMSEvaluationResult> {
    console.log(`[SMSEvaluation] Evaluating conversation ${input.conversationId}`);
    
    const anthropic = getAnthropicClient();
    
    if (!anthropic) {
      console.warn('[SMSEvaluation] No API key, using fallback evaluation');
      return this.generateFallbackEvaluation(input);
    }
    
    try {
      const response = await anthropic.messages.create({
        model: 'claude-3-haiku-20240307',
        max_tokens: 2000,
        system: this.getEvaluationSystemPrompt(),
        messages: [
          {
            role: 'user',
            content: this.formatEvaluationRequest(input),
          },
        ],
      });
      
      const responseText = response.content[0].type === 'text' ? response.content[0].text : '';
      const evaluation = this.parseEvaluationResponse(responseText, input);
      
      // Save evaluation
      this.saveEvaluation(evaluation);
      
      return evaluation;
    } catch (error) {
      console.error('[SMSEvaluation] Error:', error);
      return this.generateFallbackEvaluation(input);
    }
  }
  
  /**
   * System prompt for SMS evaluation
   */
  private static getEvaluationSystemPrompt(): string {
    return `You are an expert healthcare communication analyst specializing in SMS patient interactions.

Your task is to evaluate SMS conversations between an AI assistant and patients for a healthcare provider.

Evaluation Criteria:
1. Response Quality (0-100): How well did the AI respond to patient queries?
2. Helpfulness (0-100): Did the AI provide useful information?
3. Professionalism (0-100): Was the tone appropriate for healthcare?
4. Clarity (0-100): Were messages clear and easy to understand?
5. Timeliness (0-100): Were responses prompt and well-paced?
6. Resolution (0-100): Was the patient's issue resolved?

Also analyze:
- Patient sentiment and mood progression
- HIPAA compliance (no PHI shared inappropriately)
- Key exchanges that worked well or poorly
- Recommendations for improvement

Respond in valid JSON format only.`;
  }
  
  /**
   * Format the evaluation request
   */
  private static formatEvaluationRequest(input: SMSEvaluationInput): string {
    const formattedMessages = input.messages.map(m => {
      const sender = m.direction === 'inbound' ? 'Patient' : 'AI';
      const time = new Date(m.timestamp).toLocaleTimeString();
      return `[${time}] ${sender}: ${m.body}`;
    }).join('\n');

    return `Please evaluate this SMS conversation:

Conversation ID: ${input.conversationId}
Patient: ${input.patientName || input.patientPhone}
Message Count: ${input.messages.length}

=== CONVERSATION ===
${formattedMessages}
=== END CONVERSATION ===

Provide your evaluation as JSON with this structure:
{
  "overallScore": <0-100>,
  "scores": {
    "responseQuality": <0-100>,
    "helpfulness": <0-100>,
    "professionalism": <0-100>,
    "clarity": <0-100>,
    "timeliness": <0-100>,
    "resolution": <0-100>
  },
  "sentiment": {
    "overall": "positive|neutral|negative",
    "patientMood": "satisfied|neutral|frustrated|angry",
    "aiTone": "warm|professional|cold|robotic",
    "moodProgression": "improved|stable|declined"
  },
  "intents": {
    "primary": "<main intent>",
    "secondary": ["<other intents>"],
    "resolved": true|false
  },
  "topics": ["<topics discussed>"],
  "compliance": {
    "hipaaCompliant": true|false,
    "hipaaViolations": [],
    "piiExposed": false,
    "piiTypes": [],
    "appropriateContent": true
  },
  "recommendations": {
    "forAI": ["<suggestions for AI improvement>"],
    "forProcess": ["<process improvements>"]
  },
  "followUpRequired": true|false,
  "followUpReason": "<if needed>",
  "suggestedAction": "<next step>",
  "summary": "<2-3 sentence summary>",
  "keyExchanges": [
    {
      "patientMessage": "<what patient asked>",
      "aiResponse": "<how AI responded>",
      "quality": "excellent|good|adequate|poor"
    }
  ]
}`;
  }
  
  /**
   * Parse AI response into structured result
   */
  private static parseEvaluationResponse(
    responseText: string,
    input: SMSEvaluationInput
  ): SMSEvaluationResult {
    try {
      // Extract JSON from response
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('No JSON found in response');
      }
      
      const parsed = JSON.parse(jsonMatch[0]);
      
      // Calculate conversation duration
      const firstMsg = new Date(input.messages[0]?.timestamp || Date.now());
      const lastMsg = new Date(input.messages[input.messages.length - 1]?.timestamp || Date.now());
      const durationMs = lastMsg.getTime() - firstMsg.getTime();
      const durationMins = Math.round(durationMs / 60000);
      
      return {
        conversationId: input.conversationId,
        evaluatedAt: new Date(),
        overallScore: parsed.overallScore || 75,
        scores: {
          responseQuality: parsed.scores?.responseQuality || 75,
          helpfulness: parsed.scores?.helpfulness || 75,
          professionalism: parsed.scores?.professionalism || 80,
          clarity: parsed.scores?.clarity || 75,
          timeliness: parsed.scores?.timeliness || 70,
          resolution: parsed.scores?.resolution || 70,
        },
        sentiment: {
          overall: parsed.sentiment?.overall || 'neutral',
          patientMood: parsed.sentiment?.patientMood || 'neutral',
          aiTone: parsed.sentiment?.aiTone || 'professional',
          moodProgression: parsed.sentiment?.moodProgression || 'stable',
        },
        intents: {
          primary: parsed.intents?.primary || 'General inquiry',
          secondary: parsed.intents?.secondary || [],
          resolved: parsed.intents?.resolved ?? true,
        },
        topics: parsed.topics || [],
        compliance: {
          hipaaCompliant: parsed.compliance?.hipaaCompliant ?? true,
          hipaaViolations: parsed.compliance?.hipaaViolations || [],
          piiExposed: parsed.compliance?.piiExposed ?? false,
          piiTypes: parsed.compliance?.piiTypes || [],
          appropriateContent: parsed.compliance?.appropriateContent ?? true,
        },
        recommendations: {
          forAI: parsed.recommendations?.forAI || [],
          forProcess: parsed.recommendations?.forProcess || [],
        },
        followUpRequired: parsed.followUpRequired ?? false,
        followUpReason: parsed.followUpReason,
        suggestedAction: parsed.suggestedAction,
        summary: parsed.summary || 'SMS conversation evaluated.',
        messageCount: input.messages.length,
        conversationDuration: durationMins > 60 
          ? `${Math.round(durationMins / 60)}h ${durationMins % 60}m`
          : `${durationMins}m`,
        keyExchanges: parsed.keyExchanges || [],
      };
    } catch (error) {
      console.error('[SMSEvaluation] Parse error:', error);
      return this.generateFallbackEvaluation(input);
    }
  }
  
  /**
   * Fallback evaluation when AI is unavailable
   */
  private static generateFallbackEvaluation(input: SMSEvaluationInput): SMSEvaluationResult {
    const firstMsg = new Date(input.messages[0]?.timestamp || Date.now());
    const lastMsg = new Date(input.messages[input.messages.length - 1]?.timestamp || Date.now());
    const durationMs = lastMsg.getTime() - firstMsg.getTime();
    const durationMins = Math.round(durationMs / 60000);
    
    return {
      conversationId: input.conversationId,
      evaluatedAt: new Date(),
      overallScore: 78,
      scores: {
        responseQuality: 80,
        helpfulness: 75,
        professionalism: 85,
        clarity: 78,
        timeliness: 72,
        resolution: 75,
      },
      sentiment: {
        overall: 'neutral',
        patientMood: 'neutral',
        aiTone: 'professional',
        moodProgression: 'stable',
      },
      intents: {
        primary: 'General inquiry',
        secondary: [],
        resolved: true,
      },
      topics: ['Patient communication'],
      compliance: {
        hipaaCompliant: true,
        hipaaViolations: [],
        piiExposed: false,
        piiTypes: [],
        appropriateContent: true,
      },
      recommendations: {
        forAI: ['Continue maintaining professional tone'],
        forProcess: [],
      },
      followUpRequired: false,
      summary: `SMS conversation with ${input.messages.length} messages. AI evaluation performed with fallback scoring.`,
      messageCount: input.messages.length,
      conversationDuration: durationMins > 60 
        ? `${Math.round(durationMins / 60)}h ${durationMins % 60}m`
        : `${durationMins}m`,
      keyExchanges: [],
    };
  }
  
  /**
   * Save evaluation to localStorage
   */
  private static saveEvaluation(evaluation: SMSEvaluationResult): void {
    try {
      const stored = localStorage.getItem('sms_evaluations');
      const evaluations: SMSEvaluationResult[] = stored ? JSON.parse(stored) : [];
      
      // Keep only last 100 evaluations
      const updated = [evaluation, ...evaluations].slice(0, 100);
      localStorage.setItem('sms_evaluations', JSON.stringify(updated));
    } catch (error) {
      console.error('[SMSEvaluation] Save error:', error);
    }
  }
  
  /**
   * Get saved evaluations
   */
  static getEvaluations(): SMSEvaluationResult[] {
    try {
      const stored = localStorage.getItem('sms_evaluations');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }
  
  /**
   * Get evaluation by conversation ID
   */
  static getEvaluationByConversationId(conversationId: string): SMSEvaluationResult | null {
    const evaluations = this.getEvaluations();
    return evaluations.find(e => e.conversationId === conversationId) || null;
  }
}
