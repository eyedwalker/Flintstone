/// <reference types="vite/client" />
/**
 * Unified AI Response Service
 * Handles AI-powered responses across SMS, Voice, and Email channels
 */

import Anthropic from '@anthropic-ai/sdk';
import { AIPersona, getOrCreateDefaultPersona } from './ai-persona';
import { ElevenLabsService } from './elevenlabs-service';
import { DeepgramService, TranscriptionResult } from './deepgram-service';

const getAnthropicClient = () => {
  const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY;
  return apiKey ? new Anthropic({ apiKey, dangerouslyAllowBrowser: true }) : null;
};

export type CommunicationChannel = 'sms' | 'voice' | 'email';

export interface PatientContext {
  patientId?: string;
  firstName: string;
  lastName: string;
  phone?: string;
  email?: string;
  appointmentDateTime?: string;
  doctorName?: string;
  officeName?: string;
  reasonForVisit?: string;
  previousMessages?: Array<{
    role: 'patient' | 'assistant';
    content: string;
    timestamp?: string;
  }>;
  insuranceInfo?: {
    provider?: string;
    memberId?: string;
    verified?: boolean;
  };
}

export interface AIResponseOptions {
  channel: CommunicationChannel;
  includePersonaName?: boolean;
  maxLength?: number;
  generateAudio?: boolean;
  audioFormat?: 'mp3_44100_128' | 'pcm_16000' | 'ulaw_8000';
}

export interface AIResponseResult {
  text: string;
  audio?: ArrayBuffer;
  intent: {
    primary: string;
    confidence: number;
    requiresHumanFollowup: boolean;
    suggestedActions?: string[];
  };
  sentiment: 'positive' | 'neutral' | 'negative' | 'urgent';
  escalationRequired: boolean;
  escalationReason?: string;
  processingTimeMs: number;
  persona: {
    name: string;
    voiceId?: string;
  };
}

export class UnifiedAIResponseService {
  
  /**
   * Generate AI response for any channel
   */
  static async generateResponse(
    message: string,
    patientContext: PatientContext,
    officeId: string,
    options: AIResponseOptions
  ): Promise<AIResponseResult> {
    const startTime = Date.now();
    
    const persona = getOrCreateDefaultPersona(officeId, patientContext.officeName);
    
    if (!persona.channels[options.channel].enabled) {
      throw new Error(`Channel ${options.channel} is not enabled for this persona`);
    }
    
    // Check escalation triggers
    const escalationCheck = this.checkEscalationTriggers(message, persona);
    
    if (escalationCheck.required) {
      return {
        text: this.getEscalationResponse(persona, options.channel),
        intent: {
          primary: 'escalation_triggered',
          confidence: 1.0,
          requiresHumanFollowup: true,
          suggestedActions: ['transfer_to_human', 'create_escalation']
        },
        sentiment: 'urgent',
        escalationRequired: true,
        escalationReason: escalationCheck.reason,
        processingTimeMs: Date.now() - startTime,
        persona: { name: persona.name, voiceId: persona.voice.voiceId }
      };
    }
    
    // Generate AI response
    const systemPrompt = this.buildSystemPrompt(persona, patientContext, options.channel);
    const response = await this.callLLM(message, systemPrompt, persona, patientContext);
    
    let formattedResponse = this.formatForChannel(response.text, persona, options);
    
    // Generate audio if requested
    let audio: ArrayBuffer | undefined;
    if (options.generateAudio && persona.voice.provider === 'elevenlabs') {
      try {
        audio = await ElevenLabsService.generateSpeechFromPersona(
          formattedResponse,
          persona.voice,
          options.audioFormat || 'mp3_44100_128'
        );
      } catch (error) {
        console.error('Failed to generate audio:', error);
      }
    }
    
    return {
      text: formattedResponse,
      audio,
      intent: response.intent,
      sentiment: response.sentiment,
      escalationRequired: response.intent.requiresHumanFollowup,
      processingTimeMs: Date.now() - startTime,
      persona: { name: persona.name, voiceId: persona.voice.voiceId }
    };
  }
  
  /**
   * Build system prompt from persona config
   */
  private static buildSystemPrompt(
    persona: AIPersona,
    context: PatientContext,
    channel: CommunicationChannel
  ): string {
    if (persona.llmConfig.systemPromptOverride) {
      return this.replacePlaceholders(persona.llmConfig.systemPromptOverride, persona, context);
    }
    
    const behaviorRules = [];
    if (persona.behavior.canConfirmAppointments) behaviorRules.push('- You CAN confirm appointments');
    if (persona.behavior.canRescheduleAppointments) behaviorRules.push('- You CAN help reschedule appointments');
    if (!persona.behavior.canCancelAppointments) behaviorRules.push('- You CANNOT cancel appointments - transfer to staff');
    if (persona.behavior.canAnswerInsuranceQuestions) behaviorRules.push('- You CAN answer basic insurance questions');
    if (persona.behavior.canProvideDirections) behaviorRules.push('- You CAN provide office directions and hours');
    if (persona.behavior.canTakeMessages) behaviorRules.push('- You CAN take messages for staff');
    
    const prohibitions = persona.behavior.prohibitedTopics.length > 0
      ? `\n\nNEVER provide advice on: ${persona.behavior.prohibitedTopics.join(', ')}.`
      : '';
    
    const faqSection = persona.knowledge.faqResponses?.length 
      ? '\n\nFAQs:\n' + persona.knowledge.faqResponses.map(
          faq => `Q: ${faq.question}\nA: ${faq.answer}`
        ).join('\n\n')
      : '';
    
    const channelGuidelines: Record<CommunicationChannel, string> = {
      sms: `Keep responses under ${persona.channels.sms.maxLength || 160} characters. Be concise but warm.`,
      voice: `Speak naturally. Use short sentences. Don't use abbreviations or symbols.`,
      email: `Use professional formatting. Include greeting and signature.`
    };
    
    return `You are ${persona.name}, a ${persona.role} at ${context.officeName || 'the office'}.

PERSONALITY:
- Tone: ${persona.personality.tone}
- Traits: ${persona.personality.traits.join(', ')}

PATIENT:
- Name: ${context.firstName} ${context.lastName}
- Appointment: ${context.appointmentDateTime ? new Date(context.appointmentDateTime).toLocaleString() : 'Not scheduled'}
- Doctor: ${context.doctorName || 'Not assigned'}

OFFICE:
- Hours: ${persona.knowledge.officeHours || 'Monday-Friday 8am-5pm'}
- Address: ${persona.knowledge.officeAddress || 'Ask staff'}
- Phone: ${persona.knowledge.officePhone || 'Main line'}

CAPABILITIES:
${behaviorRules.join('\n')}
${prohibitions}

CHANNEL (${channel.toUpperCase()}):
${channelGuidelines[channel]}
${faqSection}

ESCALATION KEYWORDS: ${persona.behavior.escalateKeywords.join(', ')}

Be helpful, empathetic, and professional. Offer to transfer to staff when you cannot help.`;
  }
  
  /**
   * Call LLM
   */
  private static async callLLM(
    message: string,
    systemPrompt: string,
    persona: AIPersona,
    context: PatientContext
  ): Promise<{
    text: string;
    intent: AIResponseResult['intent'];
    sentiment: AIResponseResult['sentiment'];
  }> {
    const anthropic = getAnthropicClient();
    
    if (!anthropic) {
      return this.generateFallbackResponse(message, persona, context);
    }
    
    const messages: Array<{ role: 'user' | 'assistant'; content: string }> = [];
    
    if (context.previousMessages?.length) {
      for (const msg of context.previousMessages.slice(-5)) {
        messages.push({
          role: msg.role === 'patient' ? 'user' : 'assistant',
          content: msg.content
        });
      }
    }
    
    messages.push({ role: 'user', content: message });
    
    try {
      const response = await anthropic.messages.create({
        model: persona.llmConfig.model || 'claude-3-haiku-20240307',
        max_tokens: persona.llmConfig.maxTokens || 500,
        temperature: persona.llmConfig.temperature || 0.7,
        system: systemPrompt + `\n\nAfter your response, add:
[INTENT: <intent>]
[CONFIDENCE: <0.0-1.0>]
[SENTIMENT: <positive|neutral|negative|urgent>]
[NEEDS_HUMAN: <true|false>]`,
        messages,
      });
      
      const fullText = response.content[0].type === 'text' ? response.content[0].text : '';
      
      const analysisMatch = fullText.match(/\[INTENT: (.+?)\]\s*\[CONFIDENCE: (.+?)\]\s*\[SENTIMENT: (.+?)\]\s*\[NEEDS_HUMAN: (.+?)\]/);
      
      let text = fullText;
      let intent = 'general_inquiry';
      let confidence = 0.8;
      let sentiment: AIResponseResult['sentiment'] = 'neutral';
      let needsHuman = false;
      
      if (analysisMatch) {
        text = fullText.substring(0, fullText.indexOf('[INTENT:')).trim();
        intent = analysisMatch[1];
        confidence = parseFloat(analysisMatch[2]) || 0.8;
        sentiment = analysisMatch[3] as AIResponseResult['sentiment'];
        needsHuman = analysisMatch[4].toLowerCase() === 'true';
      }
      
      return {
        text,
        intent: { primary: intent, confidence, requiresHumanFollowup: needsHuman },
        sentiment
      };
    } catch (error) {
      console.error('LLM call failed:', error);
      return this.generateFallbackResponse(message, persona, context);
    }
  }
  
  /**
   * Fallback response when LLM unavailable
   */
  private static generateFallbackResponse(
    message: string,
    persona: AIPersona,
    context: PatientContext
  ): {
    text: string;
    intent: AIResponseResult['intent'];
    sentiment: AIResponseResult['sentiment'];
  } {
    const lower = message.toLowerCase();
    
    if (lower.includes('confirm') && lower.includes('appointment')) {
      return {
        text: `Hi ${context.firstName}, I'd be happy to help confirm your appointment for ${context.appointmentDateTime ? new Date(context.appointmentDateTime).toLocaleString() : 'the date on file'}. Is this correct?`,
        intent: { primary: 'confirm_appointment', confidence: 0.7, requiresHumanFollowup: false },
        sentiment: 'neutral'
      };
    }
    
    if (lower.includes('reschedule') || (lower.includes('change') && lower.includes('appointment'))) {
      return {
        text: `I understand you'd like to reschedule, ${context.firstName}. Let me connect you with our scheduling team.`,
        intent: { primary: 'reschedule_request', confidence: 0.7, requiresHumanFollowup: true },
        sentiment: 'neutral'
      };
    }
    
    if (lower.includes('cancel')) {
      return {
        text: `I understand you may need to cancel, ${context.firstName}. Let me transfer you to a staff member.`,
        intent: { primary: 'cancel_request', confidence: 0.7, requiresHumanFollowup: true },
        sentiment: 'neutral'
      };
    }
    
    if (lower.includes('hour') || lower.includes('open')) {
      return {
        text: `Our office hours are ${persona.knowledge.officeHours || 'Monday-Friday, 8am-5pm'}. Anything else I can help with?`,
        intent: { primary: 'hours_inquiry', confidence: 0.8, requiresHumanFollowup: false },
        sentiment: 'neutral'
      };
    }
    
    return {
      text: `Thank you for reaching out, ${context.firstName}. How can I help you today?`,
      intent: { primary: 'general_inquiry', confidence: 0.5, requiresHumanFollowup: false },
      sentiment: 'neutral'
    };
  }
  
  /**
   * Check escalation triggers
   */
  private static checkEscalationTriggers(
    message: string,
    persona: AIPersona
  ): { required: boolean; reason?: string } {
    const lower = message.toLowerCase();
    
    for (const keyword of persona.behavior.escalateKeywords) {
      if (lower.includes(keyword.toLowerCase())) {
        return { required: true, reason: `Keyword: ${keyword}` };
      }
    }
    
    for (const topic of persona.behavior.alwaysEscalateTopics) {
      if (lower.includes(topic.toLowerCase())) {
        return { required: true, reason: `Topic: ${topic}` };
      }
    }
    
    return { required: false };
  }
  
  /**
   * Get escalation response
   */
  private static getEscalationResponse(persona: AIPersona, channel: CommunicationChannel): string {
    const responses: Record<CommunicationChannel, string> = {
      sms: `I understand this is important. Let me connect you with a team member right away.`,
      voice: `I understand this is important. Let me transfer you to a staff member who can help. Please hold.`,
      email: `Thank you for reaching out. I'm forwarding this to a team member who will respond shortly.\n\nIf urgent, please call ${persona.knowledge.officePhone || 'our office'}.\n\nBest regards,\n${persona.name}`
    };
    return responses[channel];
  }
  
  /**
   * Format response for channel
   */
  private static formatForChannel(text: string, persona: AIPersona, options: AIResponseOptions): string {
    const { channel } = options;
    
    switch (channel) {
      case 'sms': {
        let smsText = text;
        if (persona.channels.sms.includePersonaName && options.includePersonaName !== false) {
          if (!smsText.toLowerCase().startsWith('hi') && !smsText.toLowerCase().startsWith('hello')) {
            smsText = `Hi, this is ${persona.name}. ${smsText}`;
          }
        }
        const maxLen = options.maxLength || persona.channels.sms.maxLength || 160;
        if (smsText.length > maxLen) {
          smsText = smsText.substring(0, maxLen - 3) + '...';
        }
        return smsText;
      }
      case 'voice':
        return text.replace(/&/g, ' and ').replace(/\//g, ' or ').replace(/[#*]/g, '').trim();
      case 'email': {
        let emailText = text;
        if (persona.channels.email.signature) {
          emailText += persona.channels.email.signature;
        }
        if (persona.channels.email.includeDisclaimer) {
          emailText += '\n\n---\nThis message was sent by an AI assistant.';
        }
        return emailText;
      }
      default:
        return text;
    }
  }
  
  /**
   * Replace placeholders
   */
  private static replacePlaceholders(template: string, persona: AIPersona, context: PatientContext): string {
    return template
      .replace(/\{\{persona\.name\}\}/g, persona.name)
      .replace(/\{\{persona\.role\}\}/g, persona.role)
      .replace(/\{\{patient\.firstName\}\}/g, context.firstName)
      .replace(/\{\{patient\.lastName\}\}/g, context.lastName)
      .replace(/\{\{office\.name\}\}/g, context.officeName || 'our office')
      .replace(/\{\{office\.hours\}\}/g, persona.knowledge.officeHours || '')
      .replace(/\{\{office\.phone\}\}/g, persona.knowledge.officePhone || '');
  }
  
  /**
   * Process voice input (transcribe + respond)
   */
  static async processVoiceInput(
    audioBuffer: ArrayBuffer,
    patientContext: PatientContext,
    officeId: string
  ): Promise<AIResponseResult & { transcription: TranscriptionResult }> {
    const transcription = await DeepgramService.transcribeAudio(audioBuffer, {
      model: 'nova-2',
      punctuate: true,
      smartFormat: true,
    });
    
    const response = await this.generateResponse(
      transcription.transcript,
      patientContext,
      officeId,
      { channel: 'voice', generateAudio: true, audioFormat: 'mp3_44100_128' }
    );
    
    return { ...response, transcription };
  }
}
