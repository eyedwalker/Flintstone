/// <reference types="vite/client" />
/**
 * Deepgram Speech-to-Text Service
 * Handles real-time and batch speech recognition
 */

const DEEPGRAM_API_URL = 'https://api.deepgram.com/v1';
const getApiKey = (): string | undefined => import.meta.env.VITE_DEEPGRAM_API_KEY;

export interface TranscriptionOptions {
  model?: 'nova-2' | 'nova' | 'enhanced' | 'base';
  language?: string;
  punctuate?: boolean;
  profanityFilter?: boolean;
  redact?: string[];
  diarize?: boolean;
  smartFormat?: boolean;
  utterances?: boolean;
  interimResults?: boolean;
  endpointing?: number;
}

export interface TranscriptionResult {
  transcript: string;
  confidence: number;
  words?: Array<{
    word: string;
    start: number;
    end: number;
    confidence: number;
    speaker?: number;
  }>;
  channels?: number;
  duration?: number;
}

export interface StreamingTranscriptEvent {
  type: 'transcript' | 'utterance_end' | 'speech_started';
  is_final: boolean;
  transcript: string;
  confidence: number;
  words?: Array<{
    word: string;
    start: number;
    end: number;
    confidence: number;
  }>;
}

export class DeepgramService {
  
  /**
   * Transcribe audio buffer (batch processing)
   */
  static async transcribeAudio(
    audioBuffer: ArrayBuffer,
    options: TranscriptionOptions = {}
  ): Promise<TranscriptionResult> {
    const apiKey = getApiKey();
    if (!apiKey) {
      throw new Error('VITE_DEEPGRAM_API_KEY not configured');
    }
    
    const {
      model = 'nova-2',
      language = 'en-US',
      punctuate = true,
      profanityFilter = false,
      smartFormat = true,
      utterances = true,
      diarize = false
    } = options;
    
    const params = new URLSearchParams({
      model,
      language,
      punctuate: String(punctuate),
      profanity_filter: String(profanityFilter),
      smart_format: String(smartFormat),
      utterances: String(utterances),
      diarize: String(diarize)
    });
    
    const response = await fetch(
      `${DEEPGRAM_API_URL}/listen?${params.toString()}`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Token ${apiKey}`,
          'Content-Type': 'audio/wav',
        },
        body: audioBuffer,
      }
    );
    
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Deepgram transcription failed: ${response.status} - ${error}`);
    }
    
    const data = await response.json();
    const result = data.results?.channels?.[0]?.alternatives?.[0];
    
    return {
      transcript: result?.transcript || '',
      confidence: result?.confidence || 0,
      words: result?.words,
      duration: data.metadata?.duration,
      channels: data.metadata?.channels,
    };
  }
  
  /**
   * Transcribe from URL
   */
  static async transcribeUrl(
    audioUrl: string,
    options: TranscriptionOptions = {}
  ): Promise<TranscriptionResult> {
    const apiKey = getApiKey();
    if (!apiKey) {
      throw new Error('VITE_DEEPGRAM_API_KEY not configured');
    }
    
    const {
      model = 'nova-2',
      language = 'en-US',
      punctuate = true,
      smartFormat = true,
    } = options;
    
    const params = new URLSearchParams({
      model,
      language,
      punctuate: String(punctuate),
      smart_format: String(smartFormat),
    });
    
    const response = await fetch(
      `${DEEPGRAM_API_URL}/listen?${params.toString()}`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Token ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url: audioUrl }),
      }
    );
    
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Deepgram transcription failed: ${response.status} - ${error}`);
    }
    
    const data = await response.json();
    const result = data.results?.channels?.[0]?.alternatives?.[0];
    
    return {
      transcript: result?.transcript || '',
      confidence: result?.confidence || 0,
      words: result?.words,
      duration: data.metadata?.duration,
    };
  }
  
  /**
   * Create WebSocket for real-time streaming transcription
   */
  static createStreamingConnection(
    options: TranscriptionOptions = {},
    callbacks: {
      onTranscript: (event: StreamingTranscriptEvent) => void;
      onError: (error: Error) => void;
      onClose: () => void;
    }
  ): WebSocket {
    const apiKey = getApiKey();
    if (!apiKey) {
      throw new Error('VITE_DEEPGRAM_API_KEY not configured');
    }
    
    const {
      model = 'nova-2',
      language = 'en-US',
      punctuate = true,
      interimResults = true,
      smartFormat = true,
      endpointing = 300,
    } = options;
    
    const params = new URLSearchParams({
      model,
      language,
      punctuate: String(punctuate),
      interim_results: String(interimResults),
      smart_format: String(smartFormat),
      endpointing: String(endpointing),
      encoding: 'mulaw',
      sample_rate: '8000',
      channels: '1',
    });
    
    const ws = new WebSocket(
      `wss://api.deepgram.com/v1/listen?${params.toString()}`,
      ['token', apiKey]
    );
    
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === 'Results') {
          const alternative = data.channel?.alternatives?.[0];
          if (alternative) {
            callbacks.onTranscript({
              type: 'transcript',
              is_final: data.is_final,
              transcript: alternative.transcript,
              confidence: alternative.confidence,
              words: alternative.words,
            });
          }
        } else if (data.type === 'UtteranceEnd') {
          callbacks.onTranscript({
            type: 'utterance_end',
            is_final: true,
            transcript: '',
            confidence: 1,
          });
        } else if (data.type === 'SpeechStarted') {
          callbacks.onTranscript({
            type: 'speech_started',
            is_final: false,
            transcript: '',
            confidence: 1,
          });
        }
      } catch (error) {
        callbacks.onError(error instanceof Error ? error : new Error(String(error)));
      }
    };
    
    ws.onerror = () => {
      callbacks.onError(new Error('WebSocket error'));
    };
    
    ws.onclose = () => {
      callbacks.onClose();
    };
    
    return ws;
  }
  
  /**
   * Send audio chunk to streaming connection
   */
  static sendAudioChunk(ws: WebSocket, audioData: ArrayBuffer | Uint8Array): void {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(audioData);
    }
  }
  
  /**
   * Close streaming connection
   */
  static closeStream(ws: WebSocket): void {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'CloseStream' }));
      ws.close();
    }
  }
}
