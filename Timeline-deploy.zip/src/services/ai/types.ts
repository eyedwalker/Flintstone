/**
 * AI System Type Definitions
 */

export interface ConversationMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface CurrentPatientContext {
  name: string;
  id?: string;
  officeId?: string;
  providerId?: string;
  phone?: string;
  email?: string;
  dob?: string;
  appointmentId?: string;
  appointmentDate?: string;
}

export interface PendingSelection {
  type: 'patient' | 'provider' | 'appointment' | 'slot';
  options: Array<{ id: string; label: string; data?: any }>;
  prompt: string;
}

export interface ConversationContext {
  currentPatient?: CurrentPatientContext;
  lastPatient?: { name: string; id?: string };
  lastProvider?: { name: string; id?: string };
  lastDate?: string;
  pendingSelection?: PendingSelection;
  lastAction?: { tool: string; parameters: Record<string, any> };
  currentWorkflow?: {
    type: string;
    step: string;
    collectedData: Record<string, any>;
  };
}

export interface ToolContext {
  staffId?: string;
  staffName?: string;
  officeId?: string;
  companyId?: string;
  currentPatientId?: string;
  currentPatient?: CurrentPatientContext;
  officeData?: {
    providers?: Array<{ staffId: string; fullName: string; providerType: string; guid: string }>;
    appointmentTypes?: Array<{ appointmentTypeId: number; description: string; duration: number }>;
    insuranceCarriers?: Array<{ carrierId: string; carrierName: string }>;
  };
}

export interface ToolResult {
  success: boolean;
  message: string;
  data?: any;
  error?: string;
  suggestedFollowUp?: string;
  requiresConfirmation?: boolean;
  pendingSelection?: PendingSelection;
  requiresAction?: {
    type: string;
    patientId?: string;
    patientName?: string;
    deliveryMethod?: string;
    [key: string]: any;
  };
}

export interface NLUResult {
  success: boolean;
  toolName?: string;
  parameters?: Record<string, any>;
  message: string;
  data?: any;
  requiresConfirmation?: boolean;
  confidence?: number;
  suggestedFollowUp?: string;
  updatedContext?: ConversationContext;
  source?: 'nlu' | 'legacy' | 'legacy-fallback';
}

export interface ProcessCommandRequest {
  command: string;
  context: ToolContext;
  conversationHistory?: ConversationMessage[];
  conversationContext?: ConversationContext;
  conversationSummary?: string;
}

export interface ProcessCommandResponse extends NLUResult {
  source: 'nlu' | 'legacy' | 'legacy-fallback';
}

export type ToolCategory = 'scheduling' | 'patient' | 'communication' | 'orders' | 'admin' | 'eyefinity' | 'journey' | 'forms' | 'compliance' | 'tasks' | 'voice' | 'escalation' | 'insurance';

export interface ToolDefinition {
  name: string;
  description: string;
  category: ToolCategory;
  inputSchema: {
    type: 'object';
    properties: Record<string, {
      type: string;
      description: string;
      enum?: string[];
      items?: { type: string };
    }>;
    required?: string[];
  };
  requiresConfirmation?: boolean;
}
