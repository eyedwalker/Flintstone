/**
 * Documentation Knowledge for AI Chat
 * Provides condensed documentation context so the AI assistant can answer
 * questions about system features, workflows, and troubleshooting.
 */

export function getDocumentationContext(): string {
  return `## System Documentation & Help Knowledge

### Application Overview
The Eyefinity Patient Readiness Center (PRC) is an eye care practice management system. It manages patient journeys from check-in through checkout, integrates with Eyefinity EHR, and provides AI-powered communication.

### Key Features & How They Work

**Patient Journey Board (/journey)**
- Main operational view showing all patients and their visit status
- Columns represent journey steps (e.g., Pre-Testing, Exam, Dilation, Optical, Checkout)
- Drag-and-drop patient cards between columns to update status
- Color-coded cards: Green = on time, Yellow = approaching wait threshold, Red = exceeded wait threshold
- Click a patient card to see details, send messages, or update status
- Wait times are calculated automatically and displayed on each card

**Patient Portal (/patient/*)**
- Patients access via magic link (SMS/email) or manual login with appointment ID + date of birth
- Sessions last 24 hours, no account creation needed
- Features: Dashboard with visit progress, Wait Time Tracker (auto-refreshes every 30 seconds), Prescription viewer with history, Billing & Payments (via Stripe), Personalized Recommendations
- Frame Scanner: Uses camera to scan frame barcodes, saves to favorites
- Measurements Tool: Uses camera for PD measurement, seg height, face geometry
  - Calibration methods: Credit card (±0.5mm accuracy) or auto-calibrate via iris diameter
  - Head movement step builds 3D face model
  - LiDAR support on iPhone Pro (±0.3mm accuracy)

**Admin Dashboard (/admin)**
- Company & office management (multi-tenant: one company can have multiple offices)
- Room configuration: Define physical rooms and assign to journey steps
- Environment settings (Production vs Sandbox for Eyefinity API)

**User Management (/user-management)**
- Invite-only registration system (admin sends email invites)
- Roles: admin (full access) and staff (limited access)
- Password requirements: 12+ characters, uppercase, lowercase, numbers, special characters
- MFA support via authenticator apps (TOTP)
- Sessions last 8 hours with automatic refresh

**Journey Configuration (/journey-admin)**
- Define journey steps (name, order, estimated duration, room assignment)
- Configure auto-advance rules and notifications
- Set wait time thresholds for escalation alerts

**Forms Administration (/forms-admin)**
- Create intake forms with drag-and-drop builder
- Field types: text, select, checkbox, date, signature, file upload
- Send forms to patients via SMS/email with secure token links
- Forms auto-save and submissions are linked to patient records

**Recommendations Engine (/recommendations-admin)**
- Rule-based product recommendations based on prescription data
- Conditions: prescription values, age, insurance type, etc.
- Priority levels: standard, high (shows "Highly Recommended" badge)
- Products, services, and promotional offers

**AI Knowledge Base (/ai-knowledge-base)**
- Configure what the AI knows about the practice
- Sections: Practice Info, Locations, Providers, Insurance, Pricing, FAQs, Custom Knowledge
- All data feeds into the AI system prompt for accurate responses
- Preview tab shows exactly what the AI sees

**AI Communication System**
- Automated SMS via Twilio with AI-powered responses
- Voice AI with ElevenLabs text-to-speech
- Sentiment analysis on patient messages
- Auto-escalation on negative sentiment or keywords (emergency, urgent, pain, manager)
- AI persona configuration: name, personality traits, behavior rules
- Prohibited topics: medical advice, diagnosis, prescriptions

**Frame Scanner (/patient/frame-scanner)**
- Camera-based barcode scanning using Quagga.js
- Manual UPC/SKU entry fallback
- Saves scanned frames to patient favorites
- Tips: Hold phone 4-6 inches from barcode, good lighting, phone vibrates on success

**Measurements Tool (/patient/measurements)**
- Step 1: Introduction and device capability check
- Step 2: Calibration (credit card method or auto-calibrate)
- Step 3: Head movement (left, right, up, down, tilt) for 3D face modeling
- Step 4: PD measurement with confidence score
- Step 5: Frame measurements (seg height, OC height)
- Step 6: Results with save/retake options
- No photos stored - only geometric data saved (HIPAA compliant)

**FTC Rx Acknowledgement**
- Federal requirement: patients must acknowledge receipt of prescription
- Methods: On-device signature, SMS/email link, or paper form
- Records: signature, date/time, prescription details, IP address
- Retained for 3 years per FTC requirements

**Billing & Payments**
- Invoice management with status tracking (Paid, Partial, Due, Overdue)
- Payment processing via Stripe (Apple Pay, Google Pay, Credit/Debit)
- Receipt download and email

**Demo Mode**
- Toggle via header button (amber "DEMO" badge)
- Simulates patient data for training without affecting real records
- Configurable demo email, phone, and patient data

### Common Troubleshooting

**Camera Not Working**
- Check browser permissions for camera access
- Use Chrome on Android, Safari on iPhone
- URL must be HTTPS
- Close other apps using the camera

**Barcode Not Scanning**
- Ensure good lighting, hold steady 4-6 inches away
- Clean dirty/damaged barcodes
- Use "Enter Manually" fallback option

**Measurements Seem Wrong**
- Use good lighting (natural light best)
- Remove glasses during PD measurement
- Face fully visible in camera frame
- Try credit card calibration for better accuracy
- Retake if confidence score below 85%

**Login Issues**
- Verify email and password are correct
- Check if account has been deactivated
- Sessions expire after 8 hours (staff) or 24 hours (patients)
- Clear browser cache if page not loading
- Contact admin for password reset

**Eyefinity EHR Connection Issues**
- Verify API credentials in Admin Dashboard
- Check if using correct environment (Production vs Sandbox)
- OAuth tokens auto-refresh; if persistent issues, re-authenticate
- Check network connectivity to Eyefinity API endpoints

**Payment Failed**
- Verify card details are correct
- Ensure sufficient funds
- Try a different payment method
- Contact office for assistance

### Navigation Quick Reference
- /journey - Patient Journey Board (main view)
- /admin - Admin Dashboard (admin only)
- /recommendations-admin - Recommendations Engine (admin only)
- /forms-admin - Forms Administration (admin only)
- /journey-admin - Journey Step Configuration (admin only)
- /ai-knowledge-base - AI Knowledge Base Editor (admin only)
- /ai-test - AI Communication Test Console (admin only)
- /help - Help & Documentation (all users)
- /patient/login - Patient Portal Login
- /patient/dashboard - Patient Dashboard
- /patient/frame-scanner - Frame Scanner
- /patient/measurements - Measurements Tool

### Security & Compliance
- HIPAA compliant data handling
- All connections over HTTPS
- JWT-based authentication with 8-hour expiry
- Multi-tenant data isolation (company-level)
- Measurements tool stores only geometric data, never photos
- FTC compliance for prescription acknowledgements (3-year retention)
- Stripe PCI-compliant payment processing
- Role-based access control (admin vs staff)`;
}
