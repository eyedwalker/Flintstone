/**
 * Admin Settings Service
 * 
 * Manages company, office, and user configuration.
 * Currently uses localStorage, designed for future API/database backing.
 * 
 * Hierarchy:
 * - Company: Top-level org settings, OAuth credentials, API config
 * - Offices: Enabled offices for this company
 * - Users: App users with role and office assignments
 */

export interface CompanySettings {
  id: string;
  name: string;
  partnerCode: string;
  
  // API Environment
  apiEnvironment: 'sandbox' | 'staging' | 'integration' | 'production';
  apiBaseUrl: string;
  
  // OAuth 2.0 Settings (for token refresh)
  oauth: {
    enabled: boolean;
    host: string;
    clientId: string;
    clientSecret: string;
    tenantUid: string;
    tokenEndpoint: string;
  };
  
  // Feature Flags
  features: {
    aiSmsReply: boolean;
    aiVoiceAnswer: boolean;
    aiEmailReply: boolean;
    patientJourneys: boolean;
    ftcCompliance: boolean;
    hipaaCompliance: boolean;
  };
  
  // Communication Settings
  communication: {
    twilioAccountSid?: string;
    twilioAuthToken?: string;
    twilioPhoneNumber?: string;
    smtpHost?: string;
    smtpPort?: number;
    smtpUsername?: string;
    smtpPassword?: string;
    smtpFromEmail?: string;
    smtpFromName?: string;
  };
  
  createdAt: string;
  updatedAt: string;
}

export interface OfficeSettings {
  id: string;
  officeId: string;  // Eyefinity office ID
  officeName: string;
  enabled: boolean;
  address?: string;
  phone?: string;
  timezone?: string;
  createdAt: string;
}

export interface UserSettings {
  id: string;
  username: string;
  passwordHash?: string;  // For local auth, will be removed when SSO enabled
  email?: string;
  name: string;
  role: 'super_admin' | 'admin' | 'associate';
  assignedOffices: string[];  // Array of office IDs user can access
  isActive: boolean;
  lastLogin?: string;
  ssoId?: string;  // For future Encompass SSO
  createdAt: string;
  updatedAt: string;
}

export interface AdminSettings {
  company: CompanySettings;
  offices: OfficeSettings[];
  users: UserSettings[];
  version: string;
}

const STORAGE_KEY = 'timeline_admin_settings';
const SETTINGS_VERSION = '1.0.0';

// Default API environments with OAuth credentials per environment
const API_ENVIRONMENTS = {
  sandbox: {
    label: 'Sandbox (No VPN)',
    apiBaseUrl: 'https://api-sandbox.eyefinity.com',
    oauthHost: 'api-sandbox.eyefinity.com',
    clientSecret: 'VD24uag29VepKKeG1zuSMXKuXg6Q9bXEvCM3csm9cb3sX84GCLh7P20UUdFucToB',
    uiBaseUrl: 'https://pm-sb.eyefinity.com',
  },
  integration: {
    label: 'Integration/PM-CI (VPN Required)',
    apiBaseUrl: 'https://api-integration.eyefinity.com',
    oauthHost: 'api-integration.eyefinity.com',
    clientSecret: 'p6cZ37pWOc39dObF5L8ttY9tZZRTNKs5zsJpoL3TN2GJ36tgzqm2kAT1DLt7DSTe',
    uiBaseUrl: 'https://pm-ci.eyefinity.com',
  },
  staging: {
    label: 'Staging/ACPT (No VPN)',
    apiBaseUrl: 'https://api-staging.eyefinity.com',
    oauthHost: 'api-staging.eyefinity.com',
    clientSecret: 'eWHwDWLwK1igPrN8Al03DNICT2smhBbILvy8VkujNnv1UfChCcD9qQAb8RfRIym5',
    uiBaseUrl: 'https://pm-acpt.eyefinity.com',
  },
  production: {
    label: 'Production',
    apiBaseUrl: 'https://api.eyefinity.com',
    oauthHost: 'api.eyefinity.com',
    clientSecret: '', // Requires SysAdmin access
    uiBaseUrl: 'https://pm.eyefinity.com',
  },
};

// Export for use in UI
export const getAvailableEnvironments = () => API_ENVIRONMENTS;

class AdminSettingsServiceClass {
  private settings: AdminSettings | null = null;

  constructor() {
    this.loadSettings();
  }

  private loadSettings(): void {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        this.settings = JSON.parse(stored);
        console.log('[AdminSettings] Loaded settings version:', this.settings?.version);
      }
    } catch (error) {
      console.error('[AdminSettings] Failed to load settings:', error);
    }
  }

  private saveSettings(): void {
    if (this.settings) {
      this.settings.company.updatedAt = new Date().toISOString();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.settings));
      console.log('[AdminSettings] Settings saved');
    }
  }

  // ============================================
  // INITIALIZATION
  // ============================================

  isInitialized(): boolean {
    return this.settings !== null && this.settings.company !== null;
  }

  getSettings(): AdminSettings | null {
    return this.settings;
  }

  initializeDefaults(companyName: string = 'My Company'): AdminSettings {
    const now = new Date().toISOString();
    
    this.settings = {
      version: SETTINGS_VERSION,
      company: {
        id: crypto.randomUUID(),
        name: companyName,
        partnerCode: '',
        apiEnvironment: 'sandbox',
        apiBaseUrl: API_ENVIRONMENTS.sandbox.apiBaseUrl,
        oauth: {
          enabled: false,
          host: API_ENVIRONMENTS.sandbox.oauthHost,
          clientId: '',
          clientSecret: '',
          tenantUid: '',
          tokenEndpoint: '/as/token.oauth2',
        },
        features: {
          aiSmsReply: true,
          aiVoiceAnswer: true,
          aiEmailReply: true,
          patientJourneys: true,
          ftcCompliance: true,
          hipaaCompliance: true,
        },
        communication: {},
        createdAt: now,
        updatedAt: now,
      },
      offices: [],
      users: [
        {
          id: crypto.randomUUID(),
          username: 'admin',
          passwordHash: 'admin123', // TODO: Hash passwords properly
          name: 'Admin User',
          role: 'super_admin',
          assignedOffices: ['*'], // * means all offices
          isActive: true,
          createdAt: now,
          updatedAt: now,
        },
      ],
    };

    this.saveSettings();
    return this.settings;
  }

  // ============================================
  // COMPANY SETTINGS
  // ============================================

  getCompany(): CompanySettings | null {
    return this.settings?.company || null;
  }

  updateCompany(updates: Partial<CompanySettings>): CompanySettings | null {
    if (!this.settings) return null;
    
    this.settings.company = {
      ...this.settings.company,
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    
    this.saveSettings();
    return this.settings.company;
  }

  setApiEnvironment(env: 'sandbox' | 'staging' | 'integration' | 'production'): void {
    if (!this.settings) return;
    
    const envConfig = API_ENVIRONMENTS[env];
    this.settings.company.apiEnvironment = env;
    this.settings.company.apiBaseUrl = envConfig.apiBaseUrl;
    this.settings.company.oauth.host = envConfig.oauthHost;
    
    // Auto-set the client secret for the environment
    if (envConfig.clientSecret) {
      this.settings.company.oauth.clientSecret = envConfig.clientSecret;
    }
    
    this.saveSettings();
    
    // Notify proxy server of config change
    this.syncToProxy();
  }

  // Sync settings to proxy server (local dev only)
  // On Vercel, proxy uses environment variables instead
  async syncToProxy(): Promise<boolean> {
    // Skip on Vercel - proxy config comes from env vars
    if (window.location.hostname.includes('vercel.app')) {
      console.log('[AdminSettings] Skipping proxy sync (Vercel uses env vars)');
      return true;
    }
    
    try {
      const oauthConfig = this.getOAuthConfig();
      if (!oauthConfig) return false;
      
      const response = await fetch('/proxy/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(oauthConfig),
      });
      
      return response.ok;
    } catch (e) {
      console.warn('[AdminSettings] Failed to sync to proxy:', e);
      return false;
    }
  }

  updateOAuthSettings(oauth: Partial<CompanySettings['oauth']>): void {
    if (!this.settings) return;
    
    this.settings.company.oauth = {
      ...this.settings.company.oauth,
      ...oauth,
    };
    
    this.saveSettings();
  }

  // ============================================
  // OFFICE SETTINGS
  // ============================================

  getOffices(): OfficeSettings[] {
    return this.settings?.offices || [];
  }

  getEnabledOffices(): OfficeSettings[] {
    return this.getOffices().filter(o => o.enabled);
  }

  addOffice(office: Omit<OfficeSettings, 'id' | 'createdAt'>): OfficeSettings {
    if (!this.settings) {
      this.initializeDefaults();
    }
    
    const newOffice: OfficeSettings = {
      ...office,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    
    this.settings!.offices.push(newOffice);
    this.saveSettings();
    return newOffice;
  }

  updateOffice(officeId: string, updates: Partial<OfficeSettings>): OfficeSettings | null {
    if (!this.settings) return null;
    
    const index = this.settings.offices.findIndex(o => o.id === officeId);
    if (index === -1) return null;
    
    this.settings.offices[index] = {
      ...this.settings.offices[index],
      ...updates,
    };
    
    this.saveSettings();
    return this.settings.offices[index];
  }

  removeOffice(officeId: string): boolean {
    if (!this.settings) return false;
    
    const index = this.settings.offices.findIndex(o => o.id === officeId);
    if (index === -1) return false;
    
    this.settings.offices.splice(index, 1);
    this.saveSettings();
    return true;
  }

  toggleOffice(officeId: string, enabled: boolean): void {
    this.updateOffice(officeId, { enabled });
  }

  // ============================================
  // USER SETTINGS
  // ============================================

  getUsers(): UserSettings[] {
    return this.settings?.users || [];
  }

  getUserById(userId: string): UserSettings | null {
    return this.settings?.users.find(u => u.id === userId) || null;
  }

  getUserByUsername(username: string): UserSettings | null {
    return this.settings?.users.find(u => u.username === username) || null;
  }

  addUser(user: Omit<UserSettings, 'id' | 'createdAt' | 'updatedAt'>): UserSettings {
    if (!this.settings) {
      this.initializeDefaults();
    }
    
    const now = new Date().toISOString();
    const newUser: UserSettings = {
      ...user,
      id: crypto.randomUUID(),
      createdAt: now,
      updatedAt: now,
    };
    
    this.settings!.users.push(newUser);
    this.saveSettings();
    return newUser;
  }

  updateUser(userId: string, updates: Partial<UserSettings>): UserSettings | null {
    if (!this.settings) return null;
    
    const index = this.settings.users.findIndex(u => u.id === userId);
    if (index === -1) return null;
    
    this.settings.users[index] = {
      ...this.settings.users[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    
    this.saveSettings();
    return this.settings.users[index];
  }

  removeUser(userId: string): boolean {
    if (!this.settings) return false;
    
    const index = this.settings.users.findIndex(u => u.id === userId);
    if (index === -1) return false;
    
    this.settings.users.splice(index, 1);
    this.saveSettings();
    return true;
  }

  // ============================================
  // AUTHENTICATION
  // ============================================

  authenticateUser(username: string, password: string): UserSettings | null {
    const user = this.getUserByUsername(username);
    if (!user || !user.isActive) return null;
    
    // TODO: Proper password hashing
    if (user.passwordHash === password) {
      this.updateUser(user.id, { lastLogin: new Date().toISOString() });
      return user;
    }
    
    return null;
  }

  canUserAccessOffice(userId: string, officeId: string): boolean {
    const user = this.getUserById(userId);
    if (!user) return false;
    
    // Super admins can access all
    if (user.role === 'super_admin') return true;
    
    // Check if wildcard or specific office
    if (user.assignedOffices.includes('*')) return true;
    return user.assignedOffices.includes(officeId);
  }

  getUserAccessibleOffices(userId: string): OfficeSettings[] {
    const user = this.getUserById(userId);
    if (!user) return [];
    
    const allOffices = this.getEnabledOffices();
    
    // Super admins or wildcard access
    if (user.role === 'super_admin' || user.assignedOffices.includes('*')) {
      return allOffices;
    }
    
    return allOffices.filter(o => user.assignedOffices.includes(o.officeId));
  }

  // ============================================
  // EXPORT FOR PROXY SERVER
  // ============================================

  getOAuthConfig(): {
    enabled: boolean;
    host: string;
    clientId: string;
    clientSecret: string;
    tenantUid: string;
    apiBaseUrl: string;
  } | null {
    const company = this.getCompany();
    if (!company) return null;
    
    return {
      enabled: company.oauth.enabled,
      host: company.oauth.host,
      clientId: company.oauth.clientId,
      clientSecret: company.oauth.clientSecret,
      tenantUid: company.oauth.tenantUid,
      apiBaseUrl: company.apiBaseUrl,
    };
  }

  // ============================================
  // IMPORT/EXPORT
  // ============================================

  exportSettings(): string {
    return JSON.stringify(this.settings, null, 2);
  }

  importSettings(jsonString: string): boolean {
    try {
      const imported = JSON.parse(jsonString) as AdminSettings;
      if (!imported.version || !imported.company) {
        throw new Error('Invalid settings format');
      }
      this.settings = imported;
      this.saveSettings();
      return true;
    } catch (error) {
      console.error('[AdminSettings] Import failed:', error);
      return false;
    }
  }

  resetSettings(): void {
    localStorage.removeItem(STORAGE_KEY);
    this.settings = null;
  }
}

// Singleton export
export const AdminSettingsService = new AdminSettingsServiceClass();

// Export types for use elsewhere
export type { AdminSettings as AdminSettingsType };
