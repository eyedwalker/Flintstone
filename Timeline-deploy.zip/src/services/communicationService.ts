// Communication Service for Patient Outreach
// Supports SMS, Email with templates and escalation

import DemoModeService from './demoModeService';

export interface CommunicationMessage {
  id: string;
  patientId: string;
  type: 'sms' | 'email' | 'voice';
  direction: 'outbound' | 'inbound';
  content: string;
  templateId?: string;
  status: 'pending' | 'sent' | 'delivered' | 'failed' | 'read';
  timestamp: string;
  sentBy?: string;
  escalated?: boolean;
  escalationReason?: string;
  // Voice-specific fields
  callDuration?: number;
  callStatus?: string;
  recordingUrl?: string;
  transcription?: string;
}

export interface CommunicationTemplate {
  id: string;
  name: string;
  type: 'sms' | 'email';
  subject?: string;
  content: string;
  category: 'appointment_reminder' | 'insurance_verification' | 'forms' | 'follow_up' | 'custom';
  variables: string[];
}

export interface EscalationAlert {
  id: string;
  patientId: string;
  patientName: string;
  appointmentId: string;
  reason: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'active' | 'acknowledged' | 'in_progress' | 'resolved';
  source: 'ai' | 'patient' | 'staff' | 'system';
  createdAt: string;
  acknowledgedAt?: string;
  resolvedAt?: string;
  assignedTo?: string;
  // Transcript and call data
  transcript?: string;
  callDuration?: number;
  callRecordingUrl?: string;
  communicationId?: string;
  // AI-specific fields
  aiConfidenceScore?: number;
  aiSuggestedAction?: string;
  // Resolution notes
  resolutionNotes?: string;
}

// Fallback demo contact info (used if demo mode not configured)
const FALLBACK_DEMO_PHONE = '+12142085261';
const FALLBACK_DEMO_EMAIL = 'daviwa2@vsp.com';

// Pre-defined templates
export const COMMUNICATION_TEMPLATES: CommunicationTemplate[] = [
  {
    id: 'appt_reminder_sms',
    name: 'Appointment Reminder (SMS)',
    type: 'sms',
    content: 'Hi {patientName}, this is a reminder about your appointment on {appointmentDate} at {appointmentTime} with {providerName}. Reply CONFIRM to confirm or RESCHEDULE to change.',
    category: 'appointment_reminder',
    variables: ['patientName', 'appointmentDate', 'appointmentTime', 'providerName'],
  },
  {
    id: 'appt_reminder_email',
    name: 'Appointment Reminder (Email)',
    type: 'email',
    subject: 'Appointment Reminder - {appointmentDate}',
    content: `Dear {patientName},

This is a friendly reminder about your upcoming appointment:

Date: {appointmentDate}
Time: {appointmentTime}
Provider: {providerName}
Location: {officeName}

Please arrive 15 minutes early to complete any necessary paperwork.

If you need to reschedule, please call us or reply to this email.

Thank you,
{officeName}`,
    category: 'appointment_reminder',
    variables: ['patientName', 'appointmentDate', 'appointmentTime', 'providerName', 'officeName'],
  },
  {
    id: 'insurance_verify_sms',
    name: 'Insurance Verification (SMS)',
    type: 'sms',
    content: 'Hi {patientName}, we need to verify your insurance before your appointment on {appointmentDate}. Please call us at {officePhone} or reply with your insurance info.',
    category: 'insurance_verification',
    variables: ['patientName', 'appointmentDate', 'officePhone'],
  },
  {
    id: 'forms_ready_sms',
    name: 'Forms Ready (SMS)',
    type: 'sms',
    content: 'Hi {patientName}, your pre-visit forms are ready! Please complete them before your appointment on {appointmentDate}. Link: {formsLink}',
    category: 'forms',
    variables: ['patientName', 'appointmentDate', 'formsLink'],
  },
  {
    id: 'follow_up_sms',
    name: 'Follow-up (SMS)',
    type: 'sms',
    content: 'Hi {patientName}, thank you for visiting us! How was your experience? Reply with any questions or concerns.',
    category: 'follow_up',
    variables: ['patientName'],
  },
  {
    id: 'custom_sms',
    name: 'Custom Message (SMS)',
    type: 'sms',
    content: '',
    category: 'custom',
    variables: [],
  },
  {
    id: 'custom_email',
    name: 'Custom Message (Email)',
    type: 'email',
    subject: '',
    content: '',
    category: 'custom',
    variables: [],
  },
];

class CommunicationServiceClass {
  private storageKey = 'patientCommunications';
  private escalationsKey = 'escalationAlerts';

  // Get demo contact info for any patient
  getDemoContact() {
    const demoSettings = DemoModeService.getSettings();
    return {
      phone: demoSettings.enabled && demoSettings.demoPhone ? demoSettings.demoPhone : FALLBACK_DEMO_PHONE,
      email: demoSettings.enabled && demoSettings.demoEmail ? demoSettings.demoEmail : FALLBACK_DEMO_EMAIL,
    };
  }

  // Get all communications for a patient
  getPatientCommunications(patientId: string): CommunicationMessage[] {
    const allComms = this.getAllCommunications();
    return allComms
      .filter(c => c.patientId === patientId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  // Get all communications
  getAllCommunications(): CommunicationMessage[] {
    const stored = localStorage.getItem(this.storageKey);
    return stored ? JSON.parse(stored) : [];
  }

  // Save communication
  saveCommunication(message: Omit<CommunicationMessage, 'id' | 'timestamp'>): CommunicationMessage {
    const comms = this.getAllCommunications();
    const newMessage: CommunicationMessage = {
      ...message,
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
    };
    comms.push(newMessage);
    localStorage.setItem(this.storageKey, JSON.stringify(comms));
    console.log('[CommunicationService] Saved message:', newMessage);
    return newMessage;
  }

  // Send SMS via Twilio API
  async sendSMS(patientId: string, content: string, sentBy: string = 'System'): Promise<CommunicationMessage> {
    const demoSettings = DemoModeService.getSettings();
    const targetPhone = demoSettings.enabled && demoSettings.demoPhone 
      ? demoSettings.demoPhone 
      : FALLBACK_DEMO_PHONE;
    
    if (demoSettings.enabled) {
      console.log(`[DEMO MODE] SMS redirected to ${targetPhone} (original patient: ${patientId})`);
    }
    console.log(`[CommunicationService] Sending SMS to ${targetPhone}:`, content);
    
    // Save message first
    const message = this.saveCommunication({
      patientId,
      type: 'sms',
      direction: 'outbound',
      content,
      status: 'pending',
      sentBy,
    });

    // Call actual Twilio API
    try {
      const response = await fetch('/api/communications/send-sms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: targetPhone,
          message: content,
        }),
      });

      const result = await response.json();
      if (result.success) {
        this.updateMessageStatus(message.id, 'delivered');
        console.log('[CommunicationService] SMS sent successfully:', result.messageId);
      } else {
        this.updateMessageStatus(message.id, 'failed');
        console.error('[CommunicationService] SMS failed:', result.error);
      }
    } catch (error) {
      console.error('[CommunicationService] SMS API error:', error);
      this.updateMessageStatus(message.id, 'failed');
    }

    return message;
  }

  // Send Email via AWS SES API
  async sendEmail(patientId: string, subject: string, content: string, sentBy: string = 'System'): Promise<CommunicationMessage> {
    const demoSettings = DemoModeService.getSettings();
    const targetEmail = demoSettings.enabled && demoSettings.demoEmail 
      ? demoSettings.demoEmail 
      : FALLBACK_DEMO_EMAIL;
    
    if (demoSettings.enabled) {
      console.log(`[DEMO MODE] Email redirected to ${targetEmail} (original patient: ${patientId})`);
    }
    console.log(`[CommunicationService] Sending Email to ${targetEmail}:`, { subject, content });
    
    // Save message first
    const message = this.saveCommunication({
      patientId,
      type: 'email',
      direction: 'outbound',
      content: `Subject: ${subject}\n\n${content}`,
      status: 'pending',
      sentBy,
    });

    // Call actual email API
    try {
      const response = await fetch('/api/communications/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: targetEmail,
          subject,
          body: content,
        }),
      });

      const result = await response.json();
      if (result.success) {
        this.updateMessageStatus(message.id, 'delivered');
        console.log('[CommunicationService] Email sent successfully:', result.messageId);
      } else {
        this.updateMessageStatus(message.id, 'failed');
        console.error('[CommunicationService] Email failed:', result.error);
      }
    } catch (error) {
      console.error('[CommunicationService] Email API error:', error);
      this.updateMessageStatus(message.id, 'failed');
    }

    return message;
  }

  // Process template with variables
  processTemplate(template: CommunicationTemplate, variables: Record<string, string>): { subject?: string; content: string } {
    let content = template.content;
    let subject = template.subject;

    Object.entries(variables).forEach(([key, value]) => {
      const regex = new RegExp(`\\{${key}\\}`, 'g');
      content = content.replace(regex, value || '');
      if (subject) {
        subject = subject.replace(regex, value || '');
      }
    });

    return { subject, content };
  }

  // Send using template
  async sendFromTemplate(
    patientId: string,
    templateId: string,
    variables: Record<string, string>,
    sentBy: string = 'System'
  ): Promise<CommunicationMessage | null> {
    const template = COMMUNICATION_TEMPLATES.find(t => t.id === templateId);
    if (!template) {
      console.error('[CommunicationService] Template not found:', templateId);
      return null;
    }

    const { subject, content } = this.processTemplate(template, variables);

    if (template.type === 'sms') {
      return this.sendSMS(patientId, content, sentBy);
    } else {
      return this.sendEmail(patientId, subject || 'Message from your eye care provider', content, sentBy);
    }
  }

  // Simulate incoming message (for demo)
  simulateIncomingMessage(patientId: string, content: string, type: 'sms' | 'email' = 'sms'): CommunicationMessage {
    console.log(`[CommunicationService] Simulating incoming ${type}:`, content);
    
    return this.saveCommunication({
      patientId,
      type,
      direction: 'inbound',
      content,
      status: 'read',
    });
  }

  // Update message status
  updateMessageStatus(messageId: string, status: CommunicationMessage['status']): void {
    const comms = this.getAllCommunications();
    const index = comms.findIndex(c => c.id === messageId);
    if (index !== -1) {
      comms[index].status = status;
      localStorage.setItem(this.storageKey, JSON.stringify(comms));
    }
  }

  // === ESCALATIONS ===

  // Get all escalations
  getEscalations(): EscalationAlert[] {
    const stored = localStorage.getItem(this.escalationsKey);
    return stored ? JSON.parse(stored) : [];
  }

  // Get active escalations
  getActiveEscalations(): EscalationAlert[] {
    return this.getEscalations().filter(e => e.status === 'active');
  }

  // Create escalation
  createEscalation(
    patientId: string,
    patientName: string,
    appointmentId: string,
    reason: string,
    priority: EscalationAlert['priority'] = 'medium',
    options?: {
      source?: EscalationAlert['source'];
      transcript?: string;
      callDuration?: number;
      callRecordingUrl?: string;
      communicationId?: string;
      aiConfidenceScore?: number;
      aiSuggestedAction?: string;
    }
  ): EscalationAlert {
    const escalations = this.getEscalations();
    const newEscalation: EscalationAlert = {
      id: `esc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      patientId,
      patientName,
      appointmentId,
      reason,
      priority,
      status: 'active',
      source: options?.source || 'system',
      createdAt: new Date().toISOString(),
      transcript: options?.transcript,
      callDuration: options?.callDuration,
      callRecordingUrl: options?.callRecordingUrl,
      communicationId: options?.communicationId,
      aiConfidenceScore: options?.aiConfidenceScore,
      aiSuggestedAction: options?.aiSuggestedAction,
    };
    escalations.push(newEscalation);
    localStorage.setItem(this.escalationsKey, JSON.stringify(escalations));
    console.log('[CommunicationService] Created escalation:', newEscalation);
    return newEscalation;
  }

  // Acknowledge escalation
  acknowledgeEscalation(escalationId: string): void {
    const escalations = this.getEscalations();
    const index = escalations.findIndex(e => e.id === escalationId);
    if (index !== -1) {
      escalations[index].status = 'acknowledged';
      escalations[index].acknowledgedAt = new Date().toISOString();
      localStorage.setItem(this.escalationsKey, JSON.stringify(escalations));
    }
  }

  // Resolve escalation
  resolveEscalation(escalationId: string): void {
    const escalations = this.getEscalations();
    const index = escalations.findIndex(e => e.id === escalationId);
    if (index !== -1) {
      escalations[index].status = 'resolved';
      escalations[index].resolvedAt = new Date().toISOString();
      localStorage.setItem(this.escalationsKey, JSON.stringify(escalations));
    }
  }

  // Clear all data (for testing)
  clearAll(): void {
    localStorage.removeItem(this.storageKey);
    localStorage.removeItem(this.escalationsKey);
  }
}

export const CommunicationService = new CommunicationServiceClass();
