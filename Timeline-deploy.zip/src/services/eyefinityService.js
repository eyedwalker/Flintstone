// Re-export from TypeScript implementation
// This file exists for backward compatibility
export * from './eyefinityService.ts';
