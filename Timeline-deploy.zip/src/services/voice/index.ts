/**
 * Voice Services Index
 * 
 * Exports all voice-related services for easy importing
 */

export { DeepgramService, getDeepgramService } from './deepgram-service';
export type { TranscriptionOptions, TranscriptionResult } from './deepgram-service';

export { ElevenLabsService, getElevenLabsService, RECOMMENDED_VOICES } from './elevenlabs-service';
export type { VoiceSettings, SpeechOptions, Voice } from './elevenlabs-service';

export { VoiceProvider, getVoiceProvider } from './voice-provider';
export type { VoiceProviderConfig, STTProvider, TTSProvider } from './voice-provider';
