/**
 * Deepgram Speech-to-Text Service
 * 
 * Provides high-quality transcription with:
 * - Medical vocabulary support
 * - Speaker diarization (identifies AI vs Patient)
 * - Real-time streaming capability
 * - Batch processing from recordings
 */

export interface TranscriptionOptions {
  model?: 'nova-2' | 'nova-2-medical' | 'enhanced' | 'base';
  language?: string;
  punctuate?: boolean;
  diarize?: boolean;
  smartFormat?: boolean;
  utterances?: boolean;
  keywords?: string[];
  detectLanguage?: boolean;
}

export interface TranscriptionResult {
  transcript: string;
  confidence: number;
  words: Array<{
    word: string;
    start: number;
    end: number;
    confidence: number;
    speaker?: number;
  }>;
  utterances?: Array<{
    speaker: number;
    text: string;
    start: number;
    end: number;
  }>;
  speakers?: number;
  duration: number;
  formattedTranscript?: string;
}

export interface DeepgramConfig {
  apiKey: string;
  model: string;
  language: string;
  features: {
    diarization: boolean;
    punctuation: boolean;
    smartFormat: boolean;
    utterances: boolean;
  };
  keywords: string[];
}

const DEFAULT_CONFIG: Partial<DeepgramConfig> = {
  model: 'nova-2-medical',
  language: 'en-US',
  features: {
    diarization: true,
    punctuation: true,
    smartFormat: true,
    utterances: true,
  },
  keywords: [
    'appointment', 'prescription', 'glasses', 'contacts', 'eye exam',
    'optometrist', 'ophthalmologist', 'vision', 'frames', 'lenses',
    'insurance', 'copay', 'deductible', 'VSP', 'EyeMed',
  ],
};

export class DeepgramService {
  private apiKey: string;
  private config: DeepgramConfig;

  constructor(apiKey?: string) {
    this.apiKey = apiKey || process.env.DEEPGRAM_API_KEY || '';
    this.config = {
      ...DEFAULT_CONFIG,
      apiKey: this.apiKey,
    } as DeepgramConfig;
  }

  /**
   * Check if Deepgram is configured
   */
  isConfigured(): boolean {
    return !!this.apiKey && this.apiKey !== 'your_deepgram_api_key_here';
  }

  /**
   * Transcribe audio from a URL (e.g., Twilio recording)
   */
  async transcribeFromUrl(
    audioUrl: string,
    options?: TranscriptionOptions
  ): Promise<TranscriptionResult> {
    if (!this.isConfigured()) {
      throw new Error('Deepgram API key not configured');
    }

    const params = this.buildQueryParams(options);
    
    console.log('[Deepgram] Transcribing from URL:', audioUrl);

    const response = await fetch(
      `https://api.deepgram.com/v1/listen?${params}`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Token ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url: audioUrl }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('[Deepgram] API Error:', error);
      throw new Error(`Deepgram API error: ${response.status}`);
    }

    const data = await response.json();
    return this.parseResponse(data);
  }

  /**
   * Transcribe audio from binary data
   */
  async transcribeFromBuffer(
    audioBuffer: ArrayBuffer,
    mimeType: string = 'audio/wav',
    options?: TranscriptionOptions
  ): Promise<TranscriptionResult> {
    if (!this.isConfigured()) {
      throw new Error('Deepgram API key not configured');
    }

    const params = this.buildQueryParams(options);

    console.log('[Deepgram] Transcribing from buffer, size:', audioBuffer.byteLength);

    const response = await fetch(
      `https://api.deepgram.com/v1/listen?${params}`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Token ${this.apiKey}`,
          'Content-Type': mimeType,
        },
        body: audioBuffer,
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('[Deepgram] API Error:', error);
      throw new Error(`Deepgram API error: ${response.status}`);
    }

    const data = await response.json();
    return this.parseResponse(data);
  }

  /**
   * Build query parameters for Deepgram API
   */
  private buildQueryParams(options?: TranscriptionOptions): string {
    const opts = { ...this.config.features, ...options };
    
    const params = new URLSearchParams({
      model: options?.model || this.config.model,
      language: options?.language || this.config.language,
      punctuate: String(opts.punctuate ?? true),
      diarize: String(opts.diarize ?? true),
      smart_format: String(opts.smartFormat ?? true),
      utterances: String(opts.utterances ?? true),
    });

    // Add medical keywords for better accuracy
    if (this.config.keywords?.length) {
      params.append('keywords', this.config.keywords.join(','));
    }

    return params.toString();
  }

  /**
   * Parse Deepgram response into our format
   */
  private parseResponse(data: any): TranscriptionResult {
    const result = data.results?.channels?.[0]?.alternatives?.[0];
    
    if (!result) {
      return {
        transcript: '',
        confidence: 0,
        words: [],
        duration: 0,
      };
    }

    const words = result.words?.map((w: any) => ({
      word: w.word,
      start: w.start,
      end: w.end,
      confidence: w.confidence,
      speaker: w.speaker,
    })) || [];

    // Parse utterances (speaker segments)
    const utterances = data.results?.utterances?.map((u: any) => ({
      speaker: u.speaker,
      text: u.transcript,
      start: u.start,
      end: u.end,
    })) || [];

    // Format transcript with speaker labels
    const formattedTranscript = this.formatTranscriptWithSpeakers(utterances);

    return {
      transcript: result.transcript || '',
      confidence: result.confidence || 0,
      words,
      utterances,
      speakers: data.results?.channels?.[0]?.detected_speakers || 2,
      duration: data.metadata?.duration || 0,
      formattedTranscript,
    };
  }

  /**
   * Format transcript with speaker labels (AI vs Patient)
   */
  private formatTranscriptWithSpeakers(
    utterances: Array<{ speaker: number; text: string }>
  ): string {
    if (!utterances?.length) {
      return '';
    }

    return utterances.map(u => {
      // Speaker 0 is typically the first speaker (caller/patient for inbound)
      // Speaker 1 is the AI/system
      const label = u.speaker === 0 ? 'Patient' : 'AI';
      return `${label}: ${u.text}`;
    }).join('\n');
  }

  /**
   * Get WebSocket URL for real-time streaming
   */
  getStreamingUrl(options?: TranscriptionOptions): string {
    const params = this.buildQueryParams(options);
    return `wss://api.deepgram.com/v1/listen?${params}`;
  }

  /**
   * Get authorization header for WebSocket connection
   */
  getAuthHeader(): string {
    return `Token ${this.apiKey}`;
  }
}

// Singleton instance
let deepgramInstance: DeepgramService | null = null;

export function getDeepgramService(): DeepgramService {
  if (!deepgramInstance) {
    deepgramInstance = new DeepgramService();
  }
  return deepgramInstance;
}

export default DeepgramService;
