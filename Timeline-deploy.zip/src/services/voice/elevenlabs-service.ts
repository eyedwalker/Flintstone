/**
 * ElevenLabs Text-to-Speech Service
 * 
 * Provides high-quality voice synthesis with:
 * - Natural sounding voices
 * - Voice cloning capability
 * - Configurable speaking styles
 * - Background noise/ambience options
 */

export interface VoiceSettings {
  stability: number;        // 0-1, higher = more consistent
  similarityBoost: number;  // 0-1, higher = closer to original voice
  style?: number;           // 0-1, style exaggeration
  useSpeakerBoost?: boolean;
}

export interface SpeechOptions {
  voiceId?: string;
  modelId?: string;
  voiceSettings?: Partial<VoiceSettings>;
  outputFormat?: 'mp3_44100_128' | 'mp3_22050_32' | 'pcm_16000' | 'pcm_22050' | 'pcm_44100' | 'ulaw_8000';
  optimizeStreamingLatency?: 0 | 1 | 2 | 3 | 4;
}

export interface Voice {
  voiceId: string;
  name: string;
  category: string;
  description?: string;
  previewUrl?: string;
  settings?: VoiceSettings;
}

export interface ElevenLabsConfig {
  apiKey: string;
  defaultVoiceId: string;
  defaultModel: string;
  defaultSettings: VoiceSettings;
  backgroundNoiseEnabled: boolean;
  backgroundNoiseUrl?: string;
}

// Recommended voices for healthcare AI
export const RECOMMENDED_VOICES = {
  // Professional female voices
  RACHEL: '21m00Tcm4TlvDq8ikWAM',      // Warm, professional
  DOMI: 'AZnzlk1XvdvUeBnXmlld',        // Clear, articulate
  BELLA: 'EXAVITQu4vr4xnSDxMaL',       // Friendly, approachable
  
  // Professional male voices  
  ADAM: 'pNInz6obpgDQGcFmaJgB',        // Deep, authoritative
  JOSH: 'TxGEqnHWrfWFTfGW9XjX',        // Warm, conversational
  ARNOLD: 'VR6AewLTigWG4xSOukaG',      // Clear, professional
  
  // Neutral/calm voices (good for medical)
  ELLI: 'MF3mGyEYCl7XYWbV9V6O',        // Calm, reassuring
  SAM: 'yoZ06aMxZJJ28mfd3POQ',         // Neutral, clear
};

const DEFAULT_CONFIG: Partial<ElevenLabsConfig> = {
  defaultVoiceId: RECOMMENDED_VOICES.RACHEL,
  defaultModel: 'eleven_turbo_v2_5',
  defaultSettings: {
    stability: 0.3,
    similarityBoost: 0.75,
    style: 0.55,
    useSpeakerBoost: true,
  },
  backgroundNoiseEnabled: false,
};

export class ElevenLabsService {
  private apiKey: string;
  private config: ElevenLabsConfig;

  constructor(apiKey?: string) {
    this.apiKey = apiKey || process.env.ELEVENLABS_API_KEY || '';
    this.config = {
      ...DEFAULT_CONFIG,
      apiKey: this.apiKey,
      defaultVoiceId: process.env.ELEVENLABS_VOICE_ID || RECOMMENDED_VOICES.BELLA, // BELLA = Emily voice ID
      backgroundNoiseEnabled: process.env.VOICE_BACKGROUND_NOISE === 'true',
    } as ElevenLabsConfig;
  }

  /**
   * Check if ElevenLabs is configured
   */
  isConfigured(): boolean {
    return !!this.apiKey && this.apiKey !== 'your_elevenlabs_api_key_here';
  }

  /**
   * Convert text to speech and return audio buffer
   */
  async textToSpeech(
    text: string,
    options?: SpeechOptions
  ): Promise<ArrayBuffer> {
    if (!this.isConfigured()) {
      throw new Error('ElevenLabs API key not configured');
    }

    const voiceId = options?.voiceId || this.config.defaultVoiceId;
    const modelId = options?.modelId || this.config.defaultModel;

    console.log('[ElevenLabs] Generating speech for:', text.substring(0, 50) + '...');

    const response = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`,
      {
        method: 'POST',
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': this.apiKey,
        },
        body: JSON.stringify({
          text,
          model_id: modelId,
          voice_settings: {
            stability: options?.voiceSettings?.stability ?? this.config.defaultSettings.stability,
            similarity_boost: options?.voiceSettings?.similarityBoost ?? this.config.defaultSettings.similarityBoost,
            style: options?.voiceSettings?.style ?? this.config.defaultSettings.style,
            use_speaker_boost: options?.voiceSettings?.useSpeakerBoost ?? this.config.defaultSettings.useSpeakerBoost,
          },
        }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('[ElevenLabs] API Error:', error);
      throw new Error(`ElevenLabs API error: ${response.status}`);
    }

    return await response.arrayBuffer();
  }

  /**
   * Get streaming URL for real-time TTS
   */
  async textToSpeechStream(
    text: string,
    options?: SpeechOptions
  ): Promise<ReadableStream<Uint8Array>> {
    if (!this.isConfigured()) {
      throw new Error('ElevenLabs API key not configured');
    }

    const voiceId = options?.voiceId || this.config.defaultVoiceId;
    const modelId = options?.modelId || this.config.defaultModel;
    const latency = options?.optimizeStreamingLatency ?? 3;

    const response = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}/stream?optimize_streaming_latency=${latency}`,
      {
        method: 'POST',
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': this.apiKey,
        },
        body: JSON.stringify({
          text,
          model_id: modelId,
          voice_settings: {
            stability: options?.voiceSettings?.stability ?? this.config.defaultSettings.stability,
            similarity_boost: options?.voiceSettings?.similarityBoost ?? this.config.defaultSettings.similarityBoost,
          },
        }),
      }
    );

    if (!response.ok || !response.body) {
      throw new Error(`ElevenLabs streaming error: ${response.status}`);
    }

    return response.body;
  }

  /**
   * Get WebSocket URL for real-time streaming TTS
   */
  getWebSocketUrl(voiceId?: string, modelId?: string): string {
    const voice = voiceId || this.config.defaultVoiceId;
    const model = modelId || this.config.defaultModel;
    return `wss://api.elevenlabs.io/v1/text-to-speech/${voice}/stream-input?model_id=${model}`;
  }

  /**
   * List available voices
   */
  async getVoices(): Promise<Voice[]> {
    if (!this.isConfigured()) {
      throw new Error('ElevenLabs API key not configured');
    }

    const response = await fetch('https://api.elevenlabs.io/v1/voices', {
      headers: {
        'xi-api-key': this.apiKey,
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch voices: ${response.status}`);
    }

    const data = await response.json();
    return data.voices.map((v: any) => ({
      voiceId: v.voice_id,
      name: v.name,
      category: v.category,
      description: v.description,
      previewUrl: v.preview_url,
      settings: v.settings,
    }));
  }

  /**
   * Get voice settings for specific emotions/tones
   */
  getSettingsForTone(tone: 'warm' | 'professional' | 'empathetic' | 'urgent'): VoiceSettings {
    switch (tone) {
      case 'warm':
        return { stability: 0.4, similarityBoost: 0.8, style: 0.4 };
      case 'professional':
        return { stability: 0.6, similarityBoost: 0.7, style: 0.2 };
      case 'empathetic':
        return { stability: 0.35, similarityBoost: 0.85, style: 0.5 };
      case 'urgent':
        return { stability: 0.7, similarityBoost: 0.6, style: 0.3 };
      default:
        return this.config.defaultSettings;
    }
  }

  /**
   * Check remaining character quota
   */
  async getUsage(): Promise<{ characterCount: number; characterLimit: number }> {
    if (!this.isConfigured()) {
      throw new Error('ElevenLabs API key not configured');
    }

    const response = await fetch('https://api.elevenlabs.io/v1/user/subscription', {
      headers: {
        'xi-api-key': this.apiKey,
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch usage: ${response.status}`);
    }

    const data = await response.json();
    return {
      characterCount: data.character_count,
      characterLimit: data.character_limit,
    };
  }

  /**
   * Set background noise configuration
   */
  setBackgroundNoise(enabled: boolean, noiseUrl?: string): void {
    this.config.backgroundNoiseEnabled = enabled;
    if (noiseUrl) {
      this.config.backgroundNoiseUrl = noiseUrl;
    }
  }

  /**
   * Get current configuration
   */
  getConfig(): Partial<ElevenLabsConfig> {
    return {
      defaultVoiceId: this.config.defaultVoiceId,
      defaultModel: this.config.defaultModel,
      defaultSettings: this.config.defaultSettings,
      backgroundNoiseEnabled: this.config.backgroundNoiseEnabled,
    };
  }
}

// Singleton instance
let elevenLabsInstance: ElevenLabsService | null = null;

export function getElevenLabsService(): ElevenLabsService {
  if (!elevenLabsInstance) {
    elevenLabsInstance = new ElevenLabsService();
  }
  return elevenLabsInstance;
}

export default ElevenLabsService;
