/**
 * Voice Provider Service
 * 
 * Unified interface for voice AI capabilities with feature flag support.
 * Maintains parity with existing Twilio voice while enabling premium providers.
 * 
 * Feature Flags:
 * - USE_DEEPGRAM_STT: Switch STT from Twilio to Deepgram
 * - USE_ELEVENLABS_TTS: Switch TTS from Twilio to ElevenLabs
 * - VOICE_BACKGROUND_NOISE: Add ambient office sounds
 */

import { DeepgramService, getDeepgramService, TranscriptionResult } from './deepgram-service';
import { ElevenLabsService, getElevenLabsService, RECOMMENDED_VOICES } from './elevenlabs-service';

export type STTProvider = 'twilio' | 'deepgram';
export type TTSProvider = 'twilio' | 'elevenlabs';

export interface VoiceProviderConfig {
  sttProvider: STTProvider;
  ttsProvider: TTSProvider;
  backgroundNoiseEnabled: boolean;
  voiceId?: string;
  voiceSettings?: {
    stability?: number;
    similarityBoost?: number;
    style?: number;
  };
}

export interface TranscribeOptions {
  diarize?: boolean;
  language?: string;
  keywords?: string[];
}

export interface SpeakOptions {
  voiceId?: string;
  tone?: 'warm' | 'professional' | 'empathetic' | 'urgent';
  speed?: number;
}

export class VoiceProvider {
  private config: VoiceProviderConfig;
  private deepgram: DeepgramService;
  private elevenlabs: ElevenLabsService;

  constructor() {
    // Determine providers based on feature flags
    const useDeepgram = process.env.USE_DEEPGRAM_STT === 'true';
    const useElevenLabs = process.env.USE_ELEVENLABS_TTS === 'true';
    const backgroundNoise = process.env.VOICE_BACKGROUND_NOISE === 'true';

    this.config = {
      sttProvider: useDeepgram ? 'deepgram' : 'twilio',
      ttsProvider: useElevenLabs ? 'elevenlabs' : 'twilio',
      backgroundNoiseEnabled: backgroundNoise,
      voiceId: process.env.ELEVENLABS_VOICE_ID || RECOMMENDED_VOICES.RACHEL,
    };

    this.deepgram = getDeepgramService();
    this.elevenlabs = getElevenLabsService();

    console.log('[VoiceProvider] Initialized with:', {
      stt: this.config.sttProvider,
      tts: this.config.ttsProvider,
      backgroundNoise: this.config.backgroundNoiseEnabled,
    });
  }

  /**
   * Get current provider configuration
   */
  getConfig(): VoiceProviderConfig {
    return { ...this.config };
  }

  /**
   * Check if premium providers are available
   */
  getProviderStatus(): {
    deepgram: { enabled: boolean; configured: boolean };
    elevenlabs: { enabled: boolean; configured: boolean };
  } {
    return {
      deepgram: {
        enabled: this.config.sttProvider === 'deepgram',
        configured: this.deepgram.isConfigured(),
      },
      elevenlabs: {
        enabled: this.config.ttsProvider === 'elevenlabs',
        configured: this.elevenlabs.isConfigured(),
      },
    };
  }

  // ==================== SPEECH-TO-TEXT ====================

  /**
   * Transcribe audio from URL (recording)
   * Uses Deepgram if enabled, otherwise returns null (use Twilio's built-in)
   */
  async transcribeFromUrl(
    audioUrl: string,
    options?: TranscribeOptions
  ): Promise<TranscriptionResult | null> {
    if (this.config.sttProvider === 'deepgram' && this.deepgram.isConfigured()) {
      console.log('[VoiceProvider] Using Deepgram for transcription');
      return await this.deepgram.transcribeFromUrl(audioUrl, {
        diarize: options?.diarize ?? true,
        language: options?.language ?? 'en-US',
        keywords: options?.keywords,
        model: 'nova-2-medical',
      });
    }

    console.log('[VoiceProvider] Deepgram not available, using Twilio transcription');
    return null; // Caller should fall back to Twilio
  }

  /**
   * Transcribe audio from buffer
   */
  async transcribeFromBuffer(
    audioBuffer: ArrayBuffer,
    mimeType?: string,
    options?: TranscribeOptions
  ): Promise<TranscriptionResult | null> {
    if (this.config.sttProvider === 'deepgram' && this.deepgram.isConfigured()) {
      return await this.deepgram.transcribeFromBuffer(
        audioBuffer,
        mimeType || 'audio/wav',
        {
          diarize: options?.diarize ?? true,
          language: options?.language ?? 'en-US',
        }
      );
    }

    return null;
  }

  /**
   * Get WebSocket URL for real-time streaming STT
   */
  getStreamingSTTUrl(): { url: string; authHeader: string } | null {
    if (this.config.sttProvider === 'deepgram' && this.deepgram.isConfigured()) {
      return {
        url: this.deepgram.getStreamingUrl(),
        authHeader: this.deepgram.getAuthHeader(),
      };
    }
    return null;
  }

  // ==================== TEXT-TO-SPEECH ====================

  /**
   * Convert text to speech
   * Uses ElevenLabs if enabled, otherwise returns null (use Twilio's built-in)
   */
  async textToSpeech(
    text: string,
    options?: SpeakOptions
  ): Promise<ArrayBuffer | null> {
    if (this.config.ttsProvider === 'elevenlabs' && this.elevenlabs.isConfigured()) {
      console.log('[VoiceProvider] Using ElevenLabs for TTS');
      
      const voiceSettings = options?.tone 
        ? this.elevenlabs.getSettingsForTone(options.tone)
        : undefined;

      return await this.elevenlabs.textToSpeech(text, {
        voiceId: options?.voiceId || this.config.voiceId,
        voiceSettings,
      });
    }

    console.log('[VoiceProvider] ElevenLabs not available, using Twilio TTS');
    return null; // Caller should fall back to Twilio
  }

  /**
   * Get streaming TTS
   */
  async textToSpeechStream(
    text: string,
    options?: SpeakOptions
  ): Promise<ReadableStream<Uint8Array> | null> {
    if (this.config.ttsProvider === 'elevenlabs' && this.elevenlabs.isConfigured()) {
      const voiceSettings = options?.tone 
        ? this.elevenlabs.getSettingsForTone(options.tone)
        : undefined;

      return await this.elevenlabs.textToSpeechStream(text, {
        voiceId: options?.voiceId || this.config.voiceId,
        voiceSettings,
      });
    }

    return null;
  }

  /**
   * Get WebSocket URL for real-time TTS
   */
  getStreamingTTSUrl(): string | null {
    if (this.config.ttsProvider === 'elevenlabs' && this.elevenlabs.isConfigured()) {
      return this.elevenlabs.getWebSocketUrl(this.config.voiceId);
    }
    return null;
  }

  // ==================== VOICE MANAGEMENT ====================

  /**
   * List available ElevenLabs voices
   */
  async getAvailableVoices() {
    if (this.elevenlabs.isConfigured()) {
      return await this.elevenlabs.getVoices();
    }
    return [];
  }

  /**
   * Set the voice to use for TTS
   */
  setVoice(voiceId: string): void {
    this.config.voiceId = voiceId;
  }

  /**
   * Get recommended voices for healthcare
   */
  getRecommendedVoices() {
    return RECOMMENDED_VOICES;
  }

  // ==================== BACKGROUND NOISE ====================

  /**
   * Check if background noise is enabled
   */
  isBackgroundNoiseEnabled(): boolean {
    return this.config.backgroundNoiseEnabled;
  }

  /**
   * Toggle background noise
   */
  setBackgroundNoise(enabled: boolean): void {
    this.config.backgroundNoiseEnabled = enabled;
    this.elevenlabs.setBackgroundNoise(enabled);
  }

  // ==================== USAGE & DIAGNOSTICS ====================

  /**
   * Get ElevenLabs usage stats
   */
  async getElevenLabsUsage() {
    if (this.elevenlabs.isConfigured()) {
      return await this.elevenlabs.getUsage();
    }
    return null;
  }

  /**
   * Test connectivity to providers
   */
  async testConnectivity(): Promise<{
    deepgram: boolean;
    elevenlabs: boolean;
  }> {
    const results = { deepgram: false, elevenlabs: false };

    // Test Deepgram
    if (this.deepgram.isConfigured()) {
      try {
        // Simple test - we'd need a real audio URL to fully test
        results.deepgram = true;
      } catch {
        results.deepgram = false;
      }
    }

    // Test ElevenLabs
    if (this.elevenlabs.isConfigured()) {
      try {
        await this.elevenlabs.getVoices();
        results.elevenlabs = true;
      } catch {
        results.elevenlabs = false;
      }
    }

    return results;
  }
}

// Singleton instance
let voiceProviderInstance: VoiceProvider | null = null;

export function getVoiceProvider(): VoiceProvider {
  if (!voiceProviderInstance) {
    voiceProviderInstance = new VoiceProvider();
  }
  return voiceProviderInstance;
}

export default VoiceProvider;
