/**
 * Demo Mode Service
 * Manages demo/test mode settings to prevent real messages from being sent
 * All communications are redirected to configured demo email/phone
 */

export interface DemoModeSettings {
  enabled: boolean;
  demoEmail: string;
  demoPhone: string;
  enabledAt?: string;
  enabledBy?: string;
}

const DEMO_MODE_KEY = 'demo_mode_settings';

class DemoModeServiceClass {
  private settings: DemoModeSettings;

  constructor() {
    this.settings = this.loadSettings();
  }

  private loadSettings(): DemoModeSettings {
    try {
      const stored = localStorage.getItem(DEMO_MODE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error('Failed to load demo mode settings:', e);
    }
    // Default: Demo mode ON with VSP test credentials
    return {
      enabled: true,
      demoEmail: 'daviwa2@vsp.com',
      demoPhone: '+12142085261',
    };
  }

  private saveSettings(): void {
    try {
      localStorage.setItem(DEMO_MODE_KEY, JSON.stringify(this.settings));
    } catch (e) {
      console.error('Failed to save demo mode settings:', e);
    }
  }

  /**
   * Check if demo mode is enabled
   */
  isEnabled(): boolean {
    return this.settings.enabled;
  }

  /**
   * Get current demo mode settings
   */
  getSettings(): DemoModeSettings {
    return { ...this.settings };
  }

  /**
   * Enable demo mode with specified email and phone
   */
  enable(demoEmail: string, demoPhone: string, enabledBy?: string): void {
    if (!demoEmail || !demoPhone) {
      throw new Error('Demo mode requires both email and phone number');
    }
    this.settings = {
      enabled: true,
      demoEmail,
      demoPhone,
      enabledAt: new Date().toISOString(),
      enabledBy,
    };
    this.saveSettings();
  }

  /**
   * Disable demo mode
   */
  disable(): void {
    this.settings = {
      enabled: false,
      demoEmail: '',
      demoPhone: '',
    };
    this.saveSettings();
  }

  /**
   * Update demo settings without changing enabled state
   */
  updateSettings(demoEmail: string, demoPhone: string): void {
    this.settings.demoEmail = demoEmail;
    this.settings.demoPhone = demoPhone;
    this.saveSettings();
  }

  /**
   * Get the email to use for communications
   * Returns demo email if in demo mode, otherwise returns the original
   */
  getEmailForSend(originalEmail: string): string {
    if (this.settings.enabled && this.settings.demoEmail) {
      console.log(`[DEMO MODE] Redirecting email from ${originalEmail} to ${this.settings.demoEmail}`);
      return this.settings.demoEmail;
    }
    return originalEmail;
  }

  /**
   * Get the phone number to use for communications
   * Returns demo phone if in demo mode, otherwise returns the original
   */
  getPhoneForSend(originalPhone: string): string {
    if (this.settings.enabled && this.settings.demoPhone) {
      console.log(`[DEMO MODE] Redirecting SMS from ${originalPhone} to ${this.settings.demoPhone}`);
      return this.settings.demoPhone;
    }
    return originalPhone;
  }

  /**
   * Check if a message would be redirected
   */
  wouldRedirect(): boolean {
    return this.settings.enabled && !!this.settings.demoEmail && !!this.settings.demoPhone;
  }
}

export const DemoModeService = new DemoModeServiceClass();
export default DemoModeService;
