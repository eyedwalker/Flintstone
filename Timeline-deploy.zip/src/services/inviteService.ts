/**
 * Invite Service
 * Handles user invitation management for secure registration
 * Users must receive an invite to their email before they can register
 */

// Types
export interface Invite {
  id: string;
  token: string;
  email: string;
  role: 'admin' | 'manager' | 'associate';
  invitedBy: string;
  invitedByName: string;
  createdAt: string;
  expiresAt: string;
  usedAt?: string;
  status: 'pending' | 'used' | 'expired' | 'revoked';
}

export interface CreateInviteData {
  email: string;
  role: 'admin' | 'manager' | 'associate';
  invitedBy: string;
  invitedByName: string;
  expirationDays?: number;
}

// Constants
const INVITES_KEY = 'user_invites';
const DEFAULT_EXPIRATION_DAYS = 7;

class InviteServiceClass {
  
  /**
   * Generate a secure random token
   */
  private generateToken(): string {
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return Array.from(array, b => b.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Get all invites
   */
  getInvites(): Invite[] {
    const stored = localStorage.getItem(INVITES_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  /**
   * Save invites
   */
  private saveInvites(invites: Invite[]): void {
    localStorage.setItem(INVITES_KEY, JSON.stringify(invites));
  }

  /**
   * Create a new invite
   */
  createInvite(data: CreateInviteData): { success: boolean; invite?: Invite; error?: string } {
    // Check if there's already a pending invite for this email
    const existingInvites = this.getInvites();
    const existingPending = existingInvites.find(
      i => i.email.toLowerCase() === data.email.toLowerCase() && i.status === 'pending'
    );

    if (existingPending) {
      return { success: false, error: 'A pending invite already exists for this email' };
    }

    const expirationDays = data.expirationDays || DEFAULT_EXPIRATION_DAYS;
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + expirationDays);

    const invite: Invite = {
      id: this.generateToken().slice(0, 16),
      token: this.generateToken(),
      email: data.email.toLowerCase(),
      role: data.role,
      invitedBy: data.invitedBy,
      invitedByName: data.invitedByName,
      createdAt: new Date().toISOString(),
      expiresAt: expiresAt.toISOString(),
      status: 'pending',
    };

    existingInvites.push(invite);
    this.saveInvites(existingInvites);

    return { success: true, invite };
  }

  /**
   * Get invite by token
   */
  getInviteByToken(token: string): Invite | null {
    const invites = this.getInvites();
    return invites.find(i => i.token === token) || null;
  }

  /**
   * Get invite by email
   */
  getInviteByEmail(email: string): Invite | null {
    const invites = this.getInvites();
    return invites.find(
      i => i.email.toLowerCase() === email.toLowerCase() && i.status === 'pending'
    ) || null;
  }

  /**
   * Validate an invite token
   */
  validateInvite(token: string): { valid: boolean; invite?: Invite; error?: string } {
    const invite = this.getInviteByToken(token);

    if (!invite) {
      return { valid: false, error: 'Invalid invite token' };
    }

    if (invite.status === 'used') {
      return { valid: false, error: 'This invite has already been used' };
    }

    if (invite.status === 'revoked') {
      return { valid: false, error: 'This invite has been revoked' };
    }

    if (new Date(invite.expiresAt) < new Date()) {
      // Update status to expired
      this.updateInviteStatus(invite.id, 'expired');
      return { valid: false, error: 'This invite has expired' };
    }

    return { valid: true, invite };
  }

  /**
   * Mark invite as used
   */
  markInviteUsed(token: string): void {
    const invites = this.getInvites();
    const invite = invites.find(i => i.token === token);
    
    if (invite) {
      invite.status = 'used';
      invite.usedAt = new Date().toISOString();
      this.saveInvites(invites);
    }
  }

  /**
   * Update invite status
   */
  updateInviteStatus(id: string, status: Invite['status']): void {
    const invites = this.getInvites();
    const invite = invites.find(i => i.id === id);
    
    if (invite) {
      invite.status = status;
      this.saveInvites(invites);
    }
  }

  /**
   * Revoke an invite
   */
  revokeInvite(id: string): { success: boolean; error?: string } {
    const invites = this.getInvites();
    const invite = invites.find(i => i.id === id);

    if (!invite) {
      return { success: false, error: 'Invite not found' };
    }

    if (invite.status !== 'pending') {
      return { success: false, error: 'Only pending invites can be revoked' };
    }

    invite.status = 'revoked';
    this.saveInvites(invites);

    return { success: true };
  }

  /**
   * Resend invite (creates new token, extends expiration)
   */
  resendInvite(id: string, expirationDays?: number): { success: boolean; invite?: Invite; error?: string } {
    const invites = this.getInvites();
    const inviteIndex = invites.findIndex(i => i.id === id);

    if (inviteIndex === -1) {
      return { success: false, error: 'Invite not found' };
    }

    const invite = invites[inviteIndex];

    if (invite.status !== 'pending' && invite.status !== 'expired') {
      return { success: false, error: 'Only pending or expired invites can be resent' };
    }

    // Generate new token and extend expiration
    const days = expirationDays || DEFAULT_EXPIRATION_DAYS;
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + days);

    invite.token = this.generateToken();
    invite.expiresAt = expiresAt.toISOString();
    invite.status = 'pending';

    this.saveInvites(invites);

    return { success: true, invite };
  }

  /**
   * Delete an invite
   */
  deleteInvite(id: string): void {
    const invites = this.getInvites().filter(i => i.id !== id);
    this.saveInvites(invites);
  }

  /**
   * Get pending invites
   */
  getPendingInvites(): Invite[] {
    return this.getInvites().filter(i => i.status === 'pending');
  }

  /**
   * Clean up expired invites
   */
  cleanupExpiredInvites(): void {
    const invites = this.getInvites();
    const now = new Date();
    
    invites.forEach(invite => {
      if (invite.status === 'pending' && new Date(invite.expiresAt) < now) {
        invite.status = 'expired';
      }
    });

    this.saveInvites(invites);
  }

  /**
   * Generate invite URL
   */
  generateInviteURL(token: string): string {
    // Use production domain for invite URLs in emails
    const productionUrl = import.meta.env.VITE_APP_URL;
    const fallbackOrigin = typeof window !== 'undefined' ? window.location.origin : 'http://localhost:5173';
    const baseUrl = productionUrl || fallbackOrigin;
    
    return `${baseUrl}/register?invite=${token}`;
  }

  /**
   * Generate invite email content
   */
  generateInviteEmail(invite: Invite): { subject: string; body: string; html: string } {
    const inviteUrl = this.generateInviteURL(invite.token);
    const expiresDate = new Date(invite.expiresAt).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    const subject = `You've been invited to VisionCare Timeline`;

    const body = `
Hello,

${invite.invitedByName} has invited you to join VisionCare Timeline as a${invite.role === 'admin' ? 'n' : ''} ${invite.role}.

Click the link below to create your account:
${inviteUrl}

This invitation expires on ${expiresDate}.

If you did not expect this invitation, please ignore this email.

Best regards,
VisionCare Timeline Team
    `.trim();

    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: #006FB4; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
    .content { background: #f9f9f9; padding: 30px; border: 1px solid #ddd; border-top: none; border-radius: 0 0 8px 8px; }
    .button { display: inline-block; background: #006FB4; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
    .button:hover { background: #005a94; }
    .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
    .expires { background: #fff3cd; border: 1px solid #ffc107; padding: 10px; border-radius: 5px; margin: 15px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Welcome to VisionCare Timeline</h1>
    </div>
    <div class="content">
      <p>Hello,</p>
      <p><strong>${invite.invitedByName}</strong> has invited you to join VisionCare Timeline as a${invite.role === 'admin' ? 'n' : ''} <strong>${invite.role}</strong>.</p>
      <p style="text-align: center;">
        <a href="${inviteUrl}" class="button">Create Your Account</a>
      </p>
      <div class="expires">
        <strong>⏰ This invitation expires on ${expiresDate}</strong>
      </div>
      <p>If the button doesn't work, copy and paste this link into your browser:</p>
      <p style="word-break: break-all; color: #006FB4;">${inviteUrl}</p>
      <p>If you did not expect this invitation, please ignore this email.</p>
    </div>
    <div class="footer">
      <p>© ${new Date().getFullYear()} VisionCare Timeline. All rights reserved.</p>
    </div>
  </div>
</body>
</html>
    `.trim();

    return { subject, body, html };
  }

  /**
   * Send invite email (integrates with communication service)
   * In production, this would connect to an email service
   */
  async sendInviteEmail(invite: Invite): Promise<{ success: boolean; error?: string }> {
    try {
      const emailContent = this.generateInviteEmail(invite);
      
      // Log for demo purposes
      console.log('[InviteService] Sending invite email to:', invite.email);
      console.log('[InviteService] Subject:', emailContent.subject);
      console.log('[InviteService] Invite URL:', this.generateInviteURL(invite.token));
      
      // In production, integrate with AWS SES or other email service
      // For now, we'll simulate success and show the invite URL
      
      return { success: true };
    } catch (error) {
      console.error('[InviteService] Failed to send invite email:', error);
      return { success: false, error: 'Failed to send invite email' };
    }
  }
}

export const InviteService = new InviteServiceClass();
export default InviteService;
