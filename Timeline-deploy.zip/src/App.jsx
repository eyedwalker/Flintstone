import React, { useState, useRef, useEffect } from 'react';
import { toPng } from 'html-to-image';
import { Download, Copy, Plus, Trash2, GripVertical, Save, FolderOpen, ChevronUp, ChevronDown, FileDown, Upload, FileSpreadsheet, ImagePlus } from 'lucide-react';
import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import TimelineView from './components/TimelineView';
import DataTable from './components/DataTable';

const defaultLanes = [
  { id: '1', name: 'Product Team', color: '#3B82F6', order: 0 },
  { id: '2', name: 'Engineering', color: '#10B981', order: 1 },
];

const defaultCategories = [
  { id: '1', name: 'Key Dates', color: '#FEF08A' },
  { id: '2', name: 'Governance', color: '#FDA4AF' },
  { id: '3', name: 'Product', color: '#86EFAC' },
  { id: '4', name: 'Engineering', color: '#5EEAD4' },
  { id: '5', name: 'Marketing', color: '#93C5FD' },
];

const defaultItems = [
  { id: '1', name: 'Project Kickoff', startDate: '2026-01-15', endDate: '', categoryId: '1', laneId: '1', row: 0 },
  { id: '2', name: 'Requirements Gathering', startDate: '2026-01-20', endDate: '2026-02-05', categoryId: '2', laneId: '1', row: 1 },
  { id: '3', name: 'Design Phase', startDate: '2026-02-01', endDate: '2026-02-20', categoryId: '3', laneId: '1', row: 2 },
  { id: '4', name: 'Development Sprint 1', startDate: '2026-02-15', endDate: '2026-03-10', categoryId: '4', laneId: '2', row: 0 },
  { id: '5', name: 'Stakeholder Review', startDate: '2026-02-24', endDate: '', categoryId: '1', laneId: '1', row: 0 },
  { id: '6', name: 'Development Sprint 2', startDate: '2026-03-10', endDate: '2026-04-01', categoryId: '4', laneId: '2', row: 1 },
  { id: '7', name: 'Launch', startDate: '2026-04-15', endDate: '', categoryId: '5', laneId: '2', row: 2 },
];

function App() {
  const [items, setItems] = useState(defaultItems);
  const [categories, setCategories] = useState(defaultCategories);
  const [lanes, setLanes] = useState(defaultLanes);
  const [activeTab, setActiveTab] = useState('data');
  const [savedTimelines, setSavedTimelines] = useState([]);
  const [currentTimelineName, setCurrentTimelineName] = useState('');
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showLoadDialog, setShowLoadDialog] = useState(false);
  const [showAiDialog, setShowAiDialog] = useState(false);
  const [aiApiKey, setAiApiKey] = useState(localStorage.getItem('openai_api_key') || '');
  const [aiProcessing, setAiProcessing] = useState(false);
  const timelineRef = useRef(null);
  const fileInputRef = useRef(null);
  const csvInputRef = useRef(null);
  const imageInputRef = useRef(null);

  useEffect(() => {
    const saved = localStorage.getItem('savedTimelines');
    if (saved) {
      try {
        setSavedTimelines(JSON.parse(saved));
      } catch (err) {
        console.error('Failed to load saved timelines:', err);
      }
    }
  }, []);

  const saveTimeline = (name) => {
    if (!name.trim()) {
      alert('Please enter a timeline name');
      return;
    }
    const timeline = {
      id: Date.now().toString(),
      name: name.trim(),
      items,
      categories,
      lanes,
      savedAt: new Date().toISOString()
    };
    const updated = [...savedTimelines.filter(t => t.name !== name.trim()), timeline];
    setSavedTimelines(updated);
    localStorage.setItem('savedTimelines', JSON.stringify(updated));
    setCurrentTimelineName(name.trim());
    setShowSaveDialog(false);
    alert(`Timeline "${name}" saved successfully!`);
  };

  const loadTimeline = (timeline) => {
    setItems(timeline.items);
    setCategories(timeline.categories);
    setLanes(timeline.lanes || defaultLanes);
    setCurrentTimelineName(timeline.name);
    setShowLoadDialog(false);
    alert(`Timeline "${timeline.name}" loaded successfully!`);
  };

  const deleteTimeline = (id) => {
    if (confirm('Are you sure you want to delete this timeline?')) {
      const updated = savedTimelines.filter(t => t.id !== id);
      setSavedTimelines(updated);
      localStorage.setItem('savedTimelines', JSON.stringify(updated));
    }
  };

  const newTimeline = () => {
    if (confirm('Create a new timeline? Current unsaved changes will be lost.')) {
      setItems([]);
      setCategories(defaultCategories);
      setLanes(defaultLanes);
      setCurrentTimelineName('');
    }
  };

  const exportToFile = () => {
    const timelineData = {
      name: currentTimelineName || 'Untitled Timeline',
      items,
      categories,
      lanes,
      exportedAt: new Date().toISOString(),
      version: '2.0'
    };
    
    const dataStr = JSON.stringify(timelineData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${timelineData.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_${Date.now()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const importFromFile = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const timelineData = JSON.parse(e.target.result);
        
        if (!timelineData.items || !timelineData.categories) {
          alert('Invalid timeline file format');
          return;
        }
        
        setItems(timelineData.items);
        setCategories(timelineData.categories);
        setLanes(timelineData.lanes || defaultLanes);
        setCurrentTimelineName(timelineData.name || 'Imported Timeline');
        alert(`Timeline "${timelineData.name || 'Untitled'}" imported successfully!`);
      } catch (err) {
        alert('Error reading timeline file. Please ensure it\'s a valid JSON file.');
        console.error('Import error:', err);
      }
    };
    reader.readAsText(file);
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const importFromCSV = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const fileName = file.name.toLowerCase();
    
    if (fileName.endsWith('.csv')) {
      Papa.parse(file, {
        header: true,
        complete: (results) => {
          processImportedData(results.data);
        },
        error: (err) => {
          alert('Error parsing CSV file: ' + err.message);
        }
      });
    } else if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
          const jsonData = XLSX.utils.sheet_to_json(firstSheet);
          processImportedData(jsonData);
        } catch (err) {
          alert('Error parsing Excel file: ' + err.message);
        }
      };
      reader.readAsArrayBuffer(file);
    }
    
    if (csvInputRef.current) {
      csvInputRef.current.value = '';
    }
  };

  const processImportedData = (data) => {
    if (!data || data.length === 0) {
      alert('No data found in file');
      return;
    }
    
    const sampleRow = data[0];
    const nameFields = ['name', 'title', 'item', 'task', 'event', 'milestone'];
    const startFields = ['start', 'startdate', 'start_date', 'begin', 'from'];
    const endFields = ['end', 'enddate', 'end_date', 'finish', 'to'];
    const categoryFields = ['category', 'type', 'group'];
    const laneFields = ['lane', 'team', 'track'];
    
    const findColumn = (fields) => {
      const keys = Object.keys(sampleRow).map(k => k.toLowerCase());
      return fields.find(f => keys.some(k => k.includes(f)));
    };
    
    const nameCol = findColumn(nameFields);
    const startCol = findColumn(startFields);
    const endCol = findColumn(endFields);
    const categoryCol = findColumn(categoryFields);
    const laneCol = findColumn(laneFields);
    
    if (!nameCol || !startCol) {
      alert('Could not find required columns (name and start date). Please ensure your file has headers.');
      return;
    }
    
    const newItems = data.map((row, idx) => {
      const rowLower = {};
      Object.keys(row).forEach(k => {
        rowLower[k.toLowerCase()] = row[k];
      });
      
      return {
        id: String(Date.now() + idx),
        name: rowLower[nameCol] || 'Untitled',
        startDate: formatDate(rowLower[startCol]),
        endDate: endCol ? formatDate(rowLower[endCol]) : '',
        categoryId: categories[0]?.id || '1',
        laneId: lanes[0]?.id || '1',
        row: idx
      };
    }).filter(item => item.startDate);
    
    if (newItems.length > 0) {
      setItems(newItems);
      setCurrentTimelineName('Imported from CSV/Excel');
      alert(`Successfully imported ${newItems.length} items!`);
    } else {
      alert('No valid items found. Please check date formats.');
    }
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    try {
      const date = new Date(dateStr);
      if (isNaN(date.getTime())) return '';
      return date.toISOString().split('T')[0];
    } catch {
      return '';
    }
  };

  const analyzeImageWithAI = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    if (!aiApiKey) {
      setShowAiDialog(true);
      if (imageInputRef.current) {
        imageInputRef.current.value = '';
      }
      return;
    }
    
    setAiProcessing(true);
    
    try {
      const base64 = await fileToBase64(file);
      
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${aiApiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4o',
          messages: [
            {
              role: 'user',
              content: [
                {
                  type: 'text',
                  text: 'Analyze this image and extract timeline information. Look for dates, events, milestones, tasks, or project phases. Return ONLY a valid JSON array in this exact format: [{"name": "event name", "startDate": "YYYY-MM-DD", "endDate": "YYYY-MM-DD or empty string", "category": "type"}]. If no timeline data is found, return an empty array [].'
                },
                {
                  type: 'image_url',
                  image_url: {
                    url: base64
                  }
                }
              ]
            }
          ],
          max_tokens: 1000
        })
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error?.message || 'API request failed');
      }
      
      const result = await response.json();
      const content = result.choices[0]?.message?.content;
      
      if (!content) {
        throw new Error('No response from AI');
      }
      
      const jsonMatch = content.match(/\[.*\]/s);
      if (!jsonMatch) {
        throw new Error('Could not extract timeline data from image');
      }
      
      const timelineData = JSON.parse(jsonMatch[0]);
      
      if (timelineData.length === 0) {
        alert('No timeline information found in the image. Please try a different image.');
        setAiProcessing(false);
        return;
      }
      
      const newItems = timelineData.map((item, idx) => ({
        id: String(Date.now() + idx),
        name: item.name || 'Untitled',
        startDate: item.startDate || new Date().toISOString().split('T')[0],
        endDate: item.endDate || '',
        categoryId: categories[0]?.id || '1',
        laneId: lanes[0]?.id || '1',
        row: idx
      }));
      
      setItems(newItems);
      setCurrentTimelineName('AI Extracted Timeline');
      alert(`Successfully extracted ${newItems.length} timeline items from image!`);
      
    } catch (err) {
      alert('Error analyzing image: ' + err.message);
      console.error('AI analysis error:', err);
    } finally {
      setAiProcessing(false);
      if (imageInputRef.current) {
        imageInputRef.current.value = '';
      }
    }
  };

  const fileToBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const saveApiKey = () => {
    localStorage.setItem('openai_api_key', aiApiKey);
    setShowAiDialog(false);
    alert('API key saved! You can now use AI image analysis.');
  };

  const addLane = () => {
    const newId = String(Date.now());
    const maxOrder = Math.max(...lanes.map(l => l.order), -1);
    setLanes([...lanes, {
      id: newId,
      name: 'New Lane',
      color: '#6B7280',
      order: maxOrder + 1
    }]);
  };

  const updateLane = (id, field, value) => {
    setLanes(lanes.map(lane =>
      lane.id === id ? { ...lane, [field]: value } : lane
    ));
  };

  const deleteLane = (id) => {
    const itemsInLane = items.filter(item => item.laneId === id);
    if (itemsInLane.length > 0) {
      alert(`Cannot delete lane: ${itemsInLane.length} items are assigned to it. Please reassign or delete those items first.`);
      return;
    }
    setLanes(lanes.filter(lane => lane.id !== id));
  };

  const moveLane = (id, direction) => {
    const laneIndex = lanes.findIndex(l => l.id === id);
    if (laneIndex === -1) return;
    
    const newIndex = direction === 'up' ? laneIndex - 1 : laneIndex + 1;
    if (newIndex < 0 || newIndex >= lanes.length) return;

    const reordered = [...lanes];
    [reordered[laneIndex], reordered[newIndex]] = [reordered[newIndex], reordered[laneIndex]];
    
    const updatedWithOrder = reordered.map((lane, idx) => ({ ...lane, order: idx }));
    setLanes(updatedWithOrder);
  };

  const addItem = () => {
    const newId = String(Date.now());
    const maxRow = Math.max(...items.map(i => i.row), -1);
    setItems([...items, {
      id: newId,
      name: 'New Item',
      startDate: new Date().toISOString().split('T')[0],
      endDate: '',
      categoryId: categories[0]?.id || '1',
      laneId: lanes[0]?.id || '1',
      row: maxRow + 1
    }]);
  };

  const updateItem = (id, field, value) => {
    setItems(items.map(item =>
      item.id === id ? { ...item, [field]: value } : item
    ));
  };

  const deleteItem = (id) => {
    setItems(items.filter(item => item.id !== id));
  };

  const addCategory = () => {
    const newId = String(Date.now());
    const colors = ['#FEF08A', '#FDA4AF', '#86EFAC', '#5EEAD4', '#93C5FD', '#DDD6FE', '#FDBA74'];
    setCategories([...categories, {
      id: newId,
      name: 'New Category',
      color: colors[categories.length % colors.length]
    }]);
  };

  const updateCategory = (id, field, value) => {
    setCategories(categories.map(cat =>
      cat.id === id ? { ...cat, [field]: value } : cat
    ));
  };

  const deleteCategory = (id) => {
    setCategories(categories.filter(cat => cat.id !== id));
  };

  const exportAsPng = async () => {
    if (timelineRef.current) {
      try {
        const dataUrl = await toPng(timelineRef.current, {
          backgroundColor: '#ffffff',
          pixelRatio: 2
        });
        const link = document.createElement('a');
        link.download = 'timeline.png';
        link.href = dataUrl;
        link.click();
      } catch (err) {
        console.error('Export failed:', err);
      }
    }
  };

  const copyToClipboard = async () => {
    if (timelineRef.current) {
      try {
        const dataUrl = await toPng(timelineRef.current, {
          backgroundColor: '#ffffff',
          pixelRatio: 2
        });
        const response = await fetch(dataUrl);
        const blob = await response.blob();
        await navigator.clipboard.write([
          new ClipboardItem({ 'image/png': blob })
        ]);
        alert('Timeline copied to clipboard! You can paste it into PowerPoint.');
      } catch (err) {
        console.error('Copy failed:', err);
        alert('Copy failed. Try downloading instead.');
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-gray-900">Timeline Creator</h1>
          <p className="text-sm text-gray-500">Create visual timelines for PowerPoint presentations</p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-4 flex justify-between items-center">
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setShowSaveDialog(true)}
              className="flex items-center gap-2 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              <Save size={16} /> Save Timeline
            </button>
            <button
              onClick={() => setShowLoadDialog(true)}
              className="flex items-center gap-2 px-3 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              <FolderOpen size={16} /> Load Timeline
            </button>
            <button
              onClick={newTimeline}
              className="flex items-center gap-2 px-3 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              <Plus size={16} /> New Timeline
            </button>
            <div className="w-px h-8 bg-gray-300 self-center"></div>
            <button
              onClick={exportToFile}
              className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              title="Export timeline as JSON file"
            >
              <FileDown size={16} /> Export File
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 px-3 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
              title="Import timeline from JSON file"
            >
              <Upload size={16} /> Import JSON
            </button>
            <button
              onClick={() => csvInputRef.current?.click()}
              className="flex items-center gap-2 px-3 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors"
              title="Import from CSV or Excel file"
            >
              <FileSpreadsheet size={16} /> Import CSV/Excel
            </button>
            <button
              onClick={() => imageInputRef.current?.click()}
              disabled={aiProcessing}
              className="flex items-center gap-2 px-3 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              title="AI: Extract timeline from image"
            >
              <ImagePlus size={16} /> {aiProcessing ? 'Analyzing...' : 'AI Image'}
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={importFromFile}
              className="hidden"
            />
            <input
              ref={csvInputRef}
              type="file"
              accept=".csv,.xlsx,.xls"
              onChange={importFromCSV}
              className="hidden"
            />
            <input
              ref={imageInputRef}
              type="file"
              accept="image/*"
              onChange={analyzeImageWithAI}
              className="hidden"
            />
          </div>
          {currentTimelineName && (
            <div className="text-sm text-gray-600">
              Current: <span className="font-semibold">{currentTimelineName}</span>
            </div>
          )}
        </div>

        <div className="mb-6 flex gap-2">
          <button
            onClick={() => setActiveTab('data')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              activeTab === 'data'
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            Data Entry
          </button>
          <button
            onClick={() => setActiveTab('lanes')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              activeTab === 'lanes'
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            Lanes
          </button>
          <button
            onClick={() => setActiveTab('categories')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              activeTab === 'categories'
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            Categories
          </button>
          <button
            onClick={() => setActiveTab('preview')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              activeTab === 'preview'
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            Preview & Export
          </button>
        </div>

        {activeTab === 'data' && (
          <DataTable
            items={items}
            categories={categories}
            lanes={lanes}
            onUpdateItem={updateItem}
            onDeleteItem={deleteItem}
            onAddItem={addItem}
          />
        )}

        {activeTab === 'lanes' && (
          <div className="bg-white rounded-xl shadow-sm border p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Timeline Lanes</h2>
              <button
                onClick={addLane}
                className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus size={16} /> Add Lane
              </button>
            </div>
            <div className="mb-4 p-3 bg-blue-50 rounded-lg text-sm text-blue-800">
              <strong>Lanes</strong> are parallel timelines that help organize different teams or workstreams.
              Items can be assigned to specific lanes in the Data Entry tab.
            </div>
            <div className="space-y-3">
              {lanes.sort((a, b) => a.order - b.order).map((lane, index) => (
                <div key={lane.id} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                  <div className="flex flex-col gap-1">
                    <button
                      onClick={() => moveLane(lane.id, 'up')}
                      disabled={index === 0}
                      className="p-1 text-gray-600 hover:bg-gray-200 rounded disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                    >
                      <ChevronUp size={16} />
                    </button>
                    <button
                      onClick={() => moveLane(lane.id, 'down')}
                      disabled={index === lanes.length - 1}
                      className="p-1 text-gray-600 hover:bg-gray-200 rounded disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                    >
                      <ChevronDown size={16} />
                    </button>
                  </div>
                  <div
                    className="w-8 h-8 rounded flex items-center justify-center text-white font-semibold text-sm"
                    style={{ backgroundColor: lane.color }}
                  >
                    {index + 1}
                  </div>
                  <input
                    type="text"
                    value={lane.name}
                    onChange={(e) => updateLane(lane.id, 'name', e.target.value)}
                    className="flex-1 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <input
                    type="color"
                    value={lane.color}
                    onChange={(e) => updateLane(lane.id, 'color', e.target.value)}
                    className="w-10 h-10 rounded cursor-pointer border-0"
                    title="Lane color"
                  />
                  <button
                    onClick={() => deleteLane(lane.id)}
                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'categories' && (
          <div className="bg-white rounded-xl shadow-sm border p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Categories</h2>
              <button
                onClick={addCategory}
                className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus size={16} /> Add Category
              </button>
            </div>
            <div className="space-y-3">
              {categories.map((cat) => (
                <div key={cat.id} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                  <input
                    type="color"
                    value={cat.color}
                    onChange={(e) => updateCategory(cat.id, 'color', e.target.value)}
                    className="w-10 h-10 rounded cursor-pointer border-0"
                  />
                  <input
                    type="text"
                    value={cat.name}
                    onChange={(e) => updateCategory(cat.id, 'name', e.target.value)}
                    className="flex-1 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <button
                    onClick={() => deleteCategory(cat.id)}
                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'preview' && (
          <div className="space-y-4">
            <div className="flex gap-3">
              <button
                onClick={copyToClipboard}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <Copy size={18} /> Copy to Clipboard
              </button>
              <button
                onClick={exportAsPng}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Download size={18} /> Download PNG
              </button>
            </div>
            <div className="bg-white rounded-xl shadow-sm border p-6 overflow-x-auto">
              <TimelineView
                ref={timelineRef}
                items={items}
                categories={categories}
                lanes={lanes}
              />
            </div>
          </div>
        )}
      </main>

      {showSaveDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl p-6 max-w-md w-full mx-4">
            <h2 className="text-xl font-bold mb-4">Save Timeline</h2>
            <input
              type="text"
              placeholder="Enter timeline name..."
              defaultValue={currentTimelineName}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 mb-4"
              onKeyDown={(e) => {
                if (e.key === 'Enter') saveTimeline(e.target.value);
                if (e.key === 'Escape') setShowSaveDialog(false);
              }}
              autoFocus
            />
            <div className="flex gap-2 justify-end">
              <button
                onClick={() => setShowSaveDialog(false)}
                className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={(e) => {
                  const input = e.target.parentElement.previousElementSibling;
                  saveTimeline(input.value);
                }}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {showLoadDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">Load Timeline</h2>
            {savedTimelines.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No saved timelines yet.</p>
            ) : (
              <div className="space-y-2">
                {savedTimelines.map((timeline) => (
                  <div
                    key={timeline.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{timeline.name}</h3>
                      <p className="text-sm text-gray-500">
                        {timeline.items.length} items • Saved {new Date(timeline.savedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => loadTimeline(timeline)}
                        className="px-3 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors text-sm"
                      >
                        Load
                      </button>
                      <button
                        onClick={() => deleteTimeline(timeline.id)}
                        className="p-1.5 text-red-500 hover:bg-red-50 rounded transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <div className="mt-4 flex justify-end">
              <button
                onClick={() => setShowLoadDialog(false)}
                className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {showAiDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl p-6 max-w-md w-full mx-4">
            <h2 className="text-xl font-bold mb-4">Configure AI Image Analysis</h2>
            <p className="text-sm text-gray-600 mb-4">
              To use AI image analysis, you need an OpenAI API key. Your key will be stored securely in your browser.
            </p>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                OpenAI API Key
              </label>
              <input
                type="password"
                placeholder="sk-..."
                value={aiApiKey}
                onChange={(e) => setAiApiKey(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') saveApiKey();
                  if (e.key === 'Escape') setShowAiDialog(false);
                }}
                autoFocus
              />
              <p className="text-xs text-gray-500 mt-2">
                Get your API key from <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">platform.openai.com/api-keys</a>
              </p>
            </div>
            <div className="flex gap-2 justify-end">
              <button
                onClick={() => setShowAiDialog(false)}
                className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={saveApiKey}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
              >
                Save Key
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
