/**
 * Patient Journey Context
 * Provides global state management for patient journeys
 */

import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { PatientJourneyService } from '../lib/services/patient-journey-service';
import { stepAuditService } from '../lib/services/step-audit-service';
import { OfficeRoomsService } from '../lib/services/office-rooms-service';

const PatientJourneyContext = createContext(null);

export function PatientJourneyProvider({ children }) {
  const [journeys, setJourneys] = useState([]);
  const [selectedJourney, setSelectedJourney] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Load active journeys
  const loadJourneys = useCallback(() => {
    setLoading(true);
    try {
      const activeJourneys = PatientJourneyService.getActiveJourneys();
      setJourneys(activeJourneys);
      setError(null);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial load
  useEffect(() => {
    loadJourneys();
  }, [loadJourneys]);

  // Create a new journey
  const createJourney = useCallback((data) => {
    try {
      const journey = PatientJourneyService.createJourney(data);
      loadJourneys();
      return journey;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, [loadJourneys]);

  // Update a journey with an action
  const updateJourney = useCallback((action) => {
    try {
      const updated = PatientJourneyService.updateJourney(action);
      loadJourneys();
      if (selectedJourney?.id === action.patientJourneyId) {
        setSelectedJourney(updated);
      }
      return updated;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, [loadJourneys, selectedJourney]);

  // Start a step
  const startStep = useCallback((journeyId, stepId, data = {}) => {
    const result = updateJourney({
      type: 'start-step',
      patientJourneyId: journeyId,
      stepId,
      data
    });
    
    // Log the event
    const journey = PatientJourneyService.getJourneyById(journeyId);
    const step = journey?.steps?.find(s => s.id === stepId);
    if (journey && step) {
      stepAuditService.logStepEvent({
        journey,
        step,
        eventType: 'step-started',
        performedBy: data.startedBy || 'user',
        performedByName: data.startedByName,
        location: data.location,
        roomId: data.roomId,
        roomName: data.roomName,
        roomType: data.roomType,
        metadata: data
      });
    }
    
    return result;
  }, [updateJourney]);

  // Complete a step
  const completeStep = useCallback((journeyId, stepId, data = {}) => {
    const result = updateJourney({
      type: 'complete-step',
      patientJourneyId: journeyId,
      stepId,
      data
    });
    
    // Log the event
    const journey = PatientJourneyService.getJourneyById(journeyId);
    const step = journey?.steps?.find(s => s.id === stepId);
    if (journey && step) {
      stepAuditService.logStepEvent({
        journey,
        step,
        eventType: 'step-completed',
        performedBy: data.completedBy || 'user',
        performedByName: data.completedByName,
        location: data.location || data.completedVia,
        roomId: data.roomId,
        roomName: data.roomName,
        roomType: data.roomType,
        externalSystemAction: data.completedVia === 'encompass' ? 'encompass-completed' : undefined,
        outcome: 'success',
        metadata: data
      });
    }
    
    return result;
  }, [updateJourney]);

  // Skip a step
  const skipStep = useCallback((journeyId, stepId, data = {}) => {
    const result = updateJourney({
      type: 'skip-step',
      patientJourneyId: journeyId,
      stepId,
      data
    });
    
    // Log the event
    const journey = PatientJourneyService.getJourneyById(journeyId);
    const step = journey?.steps?.find(s => s.id === stepId);
    if (journey && step) {
      stepAuditService.logStepEvent({
        journey,
        step,
        eventType: 'step-skipped',
        performedBy: data.skippedBy || 'user',
        performedByName: data.skippedByName,
        location: data.location,
        outcome: 'skipped',
        metadata: { notes: data.notes || data.reason, ...data }
      });
    }
    
    return result;
  }, [updateJourney]);

  // Auto-release room when journey leaves in-office phase
  const autoReleaseRoomForJourney = useCallback((journeyId) => {
    try {
      const configs = OfficeRoomsService.getAllConfigs();
      for (const config of configs) {
        const room = (config.rooms || []).find(
          r => r.status === 'occupied' && r.currentJourneyId === journeyId
        );
        if (room) {
          OfficeRoomsService.releasePatientFromRoom(config.officeId, room.id);
        }
      }
    } catch (err) {
      console.error('Failed to auto-release room for journey:', journeyId, err);
    }
  }, []);

  // Transition phase
  const transitionPhase = useCallback((journeyId, newPhase) => {
    try {
      const updated = PatientJourneyService.transitionJourneyPhase(journeyId, newPhase);

      // Auto-release room when leaving in-office
      if (newPhase === 'post-visit' || newPhase === 'completed') {
        autoReleaseRoomForJourney(journeyId);
      }

      loadJourneys();
      if (selectedJourney?.id === journeyId) {
        setSelectedJourney(updated);
      }
      return updated;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, [loadJourneys, selectedJourney, autoReleaseRoomForJourney]);

  // Cancel a journey
  const cancelJourney = useCallback((journeyId) => {
    try {
      PatientJourneyService.cancelJourney(journeyId);
      loadJourneys();
      if (selectedJourney?.id === journeyId) {
        setSelectedJourney(null);
      }
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, [loadJourneys, selectedJourney]);

  // Get journey by ID
  const getJourneyById = useCallback((id) => {
    return PatientJourneyService.getJourneyById(id);
  }, []);

  // Get journey by appointment ID
  const getJourneyByAppointmentId = useCallback((appointmentId) => {
    return PatientJourneyService.getJourneyByAppointmentId(appointmentId);
  }, []);

  const value = {
    journeys,
    selectedJourney,
    setSelectedJourney,
    loading,
    error,
    loadJourneys,
    createJourney,
    updateJourney,
    startStep,
    completeStep,
    skipStep,
    transitionPhase,
    cancelJourney,
    getJourneyById,
    getJourneyByAppointmentId
  };

  return (
    <PatientJourneyContext.Provider value={value}>
      {children}
    </PatientJourneyContext.Provider>
  );
}

export function usePatientJourney() {
  const context = useContext(PatientJourneyContext);
  if (!context) {
    throw new Error('usePatientJourney must be used within a PatientJourneyProvider');
  }
  return context;
}

export default PatientJourneyContext;
