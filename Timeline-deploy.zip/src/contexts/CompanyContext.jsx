/**
 * Company Context
 * Manages active company selection and provides company data to components
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { companyAccessor } from '../lib/accessors/CompanyAccessor';
import { EyefinityService } from '../services/eyefinityService';
import { useAuth } from './AuthContext';

const CompanyContext = createContext(null);

export const useCompany = () => {
  const context = useContext(CompanyContext);
  if (!context) {
    throw new Error('useCompany must be used within CompanyProvider');
  }
  return context;
};

export const CompanyProvider = ({ children }) => {
  const { isAuthenticated } = useAuth();
  const [activeCompany, setActiveCompany] = useState(null);
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isAuthenticated) {
      loadCompanies();
    } else {
      setCompanies([]);
      setActiveCompany(null);
      setLoading(false);
    }
  }, [isAuthenticated]);

  const loadCompanies = async () => {
    try {
      setLoading(true);
      const result = await companyAccessor.getAll();
      
      if (result.success && result.data) {
        setCompanies(result.data);
        
        // Get stored active company ID or use first
        const savedId = localStorage.getItem('activeCompanyId');
        const active = savedId 
          ? result.data.find(c => c.id === savedId) 
          : result.data[0];
        
        if (active) {
          setActiveCompany(active);
        }
      }
    } catch (err) {
      console.error('[CompanyContext] Failed to load companies:', err);
    } finally {
      setLoading(false);
    }
  };

  // Sync active company ID to EyefinityService so all API calls route correctly
  useEffect(() => {
    EyefinityService.setActiveCompanyId(activeCompany?.id || null);
  }, [activeCompany]);

  const switchCompany = (companyId) => {
    const company = companies.find(c => c.id === companyId);
    if (company) {
      setActiveCompany(company);
      localStorage.setItem('activeCompanyId', companyId);
      console.log('[CompanyContext] Switched to company:', company.name);
    }
  };

  const refreshCompanies = async () => {
    await loadCompanies();
  };

  const value = {
    activeCompany,
    companies,
    loading,
    switchCompany,
    refreshCompanies,
  };

  return (
    <CompanyContext.Provider value={value}>
      {children}
    </CompanyContext.Provider>
  );
};
