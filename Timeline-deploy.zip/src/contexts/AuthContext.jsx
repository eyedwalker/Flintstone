import React, { createContext, useContext, useState, useEffect } from 'react';
import { AuthApiService } from '../services/authApiService';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    const initAuth = async () => {
      try {
        // Check if system is initialized (has users)
        const initStatus = await AuthApiService.checkInitialized();
        setInitialized(initStatus.initialized);
        
        // If not initialized, create default admin
        if (!initStatus.initialized) {
          console.log('[Auth] System not initialized, creating default admin...');
          await AuthApiService.initializeAdmin();
          setInitialized(true);
        }
        
        // Validate existing session
        const storedSession = localStorage.getItem('auth_session');
        console.log('[Auth] Stored session:', storedSession ? 'exists' : 'none');
        
        const validation = await AuthApiService.validateSession();
        console.log('[Auth] Validation result:', validation);
        
        if (validation.valid && validation.user) {
          if (storedSession) {
            setSession(JSON.parse(storedSession));
          }
          setCurrentUser({
            ...validation.user,
            name: `${validation.user.firstName} ${validation.user.lastName}`,
            username: validation.user.email,
          });
          console.log('[Auth] User authenticated:', validation.user.email);
        } else {
          // Session invalid, clear storage
          console.log('[Auth] Session invalid, clearing storage. Error:', validation.error);
          localStorage.removeItem('auth_session');
          localStorage.removeItem('currentUser');
        }
      } catch (e) {
        console.error('Auth initialization error:', e);
        localStorage.removeItem('auth_session');
        localStorage.removeItem('currentUser');
      }
      setLoading(false);
    };
    
    initAuth();
  }, []);

  // Login with email and password
  const login = async (emailOrUsername, password) => {
    try {
      const result = await AuthApiService.login(emailOrUsername, password);
      
      if (!result.success) {
        return result;
      }

      if (result.requiresMfa) {
        return result;
      }

      // Session stored by AuthApiService
      if (result.session) {
        setSession(result.session);
      }
      
      if (result.user) {
        const user = {
          ...result.user,
          name: `${result.user.firstName} ${result.user.lastName}`,
          username: result.user.email,
        };
        setCurrentUser(user);
      }

      return result;
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'An unexpected error occurred' };
    }
  };

  const verifyMfa = async (mfaToken, code) => {
    try {
      const result = await AuthApiService.verifyMfa(mfaToken, code);
      
      if (!result.success) {
        return result;
      }

      // Session stored by AuthApiService
      if (result.session) {
        setSession(result.session);
      }
      
      if (result.user) {
        const user = {
          ...result.user,
          name: `${result.user.firstName} ${result.user.lastName}`,
          username: result.user.email,
        };
        setCurrentUser(user);
      }

      return result;
    } catch (error) {
      console.error('MFA verification error:', error);
      return { success: false, error: 'An unexpected error occurred' };
    }
  };

  const logout = async () => {
    await AuthApiService.logout();
    setCurrentUser(null);
    setSession(null);
  };

  const refreshSession = async () => {
    if (!session?.refreshToken) return false;
    
    const result = await AuthApiService.refreshSession();
    if (result.success && result.session) {
      setSession(result.session);
      if (result.user) {
        setCurrentUser({
          ...result.user,
          name: `${result.user.firstName} ${result.user.lastName}`,
          username: result.user.email,
        });
      }
      return true;
    }
    
    // Refresh failed, logout
    await logout();
    return false;
  };

  const value = {
    currentUser,
    session,
    login,
    verifyMfa,
    logout,
    refreshSession,
    isAdmin: currentUser?.role === 'admin',
    isManager: currentUser?.role === 'manager',
    isAssociate: currentUser?.role === 'associate',
    loading,
    isAuthenticated: !!currentUser && !!session,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
