/**
 * Compliance & Regulatory Form Templates
 * Forms 15-18: CL Rx Release, Records Release, ABN, AOB
 */

import { FormTemplate } from '../../lib/types/forms';

// 15. Contact Lens Rx Release (FTC Compliance)
export const contactLensRxReleaseTemplate: FormTemplate = {
  id: 'contact-lens-rx-release',
  title: 'Contact Lens Prescription Release',
  description: 'Acknowledgement of contact lens prescription receipt per FTC Contact Lens Rule',
  category: 'compliance',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'ftc-notice',
      title: 'FTC Contact Lens Rule Notice',
      fields: [
        { id: 'ftcNotice', type: 'textarea', label: 'Your Rights', required: false, readOnly: true, defaultValue: `CONTACT LENS RULE (FTC)

Under federal law (the FTC Contact Lens Rule), you have the right to receive a copy of your contact lens prescription at the completion of your contact lens fitting, at no extra cost.

Your prescription is valid for at least one year (or longer if required by your state) and allows you to purchase contact lenses from any seller you choose.

PRESCRIPTION REQUIREMENTS:
Your contact lens prescription includes:
• Lens power (sphere, cylinder, axis if applicable)
• Lens brand/manufacturer
• Base curve and diameter
• Expiration date

VERIFICATION:
Sellers must verify your prescription before dispensing lenses. They may contact our office for verification.` },
      ],
    },
    {
      id: 'prescription-details',
      title: 'Prescription Information',
      fields: [
        { id: 'patientName', type: 'text', label: 'Patient Name', required: true },
        { id: 'examDate', type: 'date', label: 'Fitting Completion Date', required: true },
        { id: 'expirationDate', type: 'date', label: 'Prescription Expiration Date', required: true },
        { id: 'lensBrand', type: 'text', label: 'Contact Lens Brand', required: true },
      ],
    },
    {
      id: 'acknowledgement',
      title: 'Patient Acknowledgement',
      fields: [
        { id: 'receivedRx', type: 'checkbox', label: 'Prescription Receipt', required: true, options: [
          { value: 'received', label: 'I have received a copy of my contact lens prescription' }
        ]},
        { id: 'understandRights', type: 'checkbox', label: 'Rights Understanding', required: true, options: [
          { value: 'understood', label: 'I understand I may purchase lenses from any seller' }
        ]},
        { id: 'patientSignature', type: 'signature', label: 'Patient Signature', required: true },
        { id: 'signatureDate', type: 'date', label: 'Date', required: true },
      ],
    },
  ],
};

// 16. Authorization for Release of Records
export const recordsReleaseTemplate: FormTemplate = {
  id: 'records-release-authorization',
  title: 'Authorization for Release of Records',
  description: 'HIPAA-compliant authorization to release medical records',
  category: 'compliance',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'patient-info',
      title: 'Patient Information',
      fields: [
        { id: 'patientName', type: 'text', label: 'Patient Name', required: true },
        { id: 'patientDOB', type: 'date', label: 'Date of Birth', required: true },
        { id: 'patientAddress', type: 'text', label: 'Address', required: true },
        { id: 'patientPhone', type: 'phone', label: 'Phone Number', required: true },
      ],
    },
    {
      id: 'release-to',
      title: 'Release Information To',
      fields: [
        { id: 'recipientName', type: 'text', label: 'Name of Person/Organization', required: true },
        { id: 'recipientAddress', type: 'text', label: 'Address', required: true },
        { id: 'recipientPhone', type: 'phone', label: 'Phone Number', required: false },
        { id: 'recipientFax', type: 'text', label: 'Fax Number', required: false },
      ],
    },
    {
      id: 'records-requested',
      title: 'Records to be Released',
      fields: [
        { id: 'recordTypes', type: 'checkbox', label: 'Select records to release', required: true, options: [
          { value: 'complete-record', label: 'Complete medical record' },
          { value: 'exam-records', label: 'Eye exam records' },
          { value: 'prescription', label: 'Eyeglass/Contact lens prescription' },
          { value: 'diagnostic-tests', label: 'Diagnostic test results' },
          { value: 'treatment-records', label: 'Treatment records' },
          { value: 'referral-notes', label: 'Referral/consultation notes' },
          { value: 'images', label: 'Images/photographs' }
        ]},
        { id: 'dateRange', type: 'text', label: 'Date range of records (if applicable)', required: false, placeholder: 'e.g., January 2023 - Present' },
        { id: 'specificInfo', type: 'textarea', label: 'Specific information requested', required: false },
      ],
    },
    {
      id: 'purpose',
      title: 'Purpose of Release',
      fields: [
        { id: 'releasePurpose', type: 'select', label: 'Purpose', required: true, options: [
          { value: 'continuing-care', label: 'Continuing medical care' },
          { value: 'second-opinion', label: 'Second opinion' },
          { value: 'insurance', label: 'Insurance purposes' },
          { value: 'legal', label: 'Legal purposes' },
          { value: 'personal', label: 'Personal records' },
          { value: 'other', label: 'Other' }
        ]},
        { id: 'otherPurpose', type: 'text', label: 'If other, please specify', required: false },
      ],
    },
    {
      id: 'authorization',
      title: 'Authorization',
      fields: [
        { id: 'authorizationText', type: 'textarea', label: 'Authorization Statement', required: false, readOnly: true, defaultValue: `I authorize the release of my protected health information as specified above. I understand that:

• This authorization is voluntary and I may refuse to sign
• I may revoke this authorization in writing at any time
• Information released may be re-disclosed by the recipient
• This authorization expires one year from the date signed unless otherwise specified
• I may request a copy of this signed authorization` },
        { id: 'expirationDate', type: 'date', label: 'Authorization Expiration Date (optional)', required: false },
        { id: 'patientSignature', type: 'signature', label: 'Patient Signature', required: true },
        { id: 'signatureDate', type: 'date', label: 'Date', required: true },
        { id: 'guardianRelationship', type: 'text', label: 'If signing as guardian, relationship to patient', required: false },
      ],
    },
  ],
};

// 17. Advance Beneficiary Notice (ABN)
export const abnTemplate: FormTemplate = {
  id: 'advance-beneficiary-notice',
  title: 'Advance Beneficiary Notice (ABN)',
  description: 'Medicare notice for potentially non-covered services',
  category: 'compliance',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'patient-info',
      title: 'Patient Information',
      fields: [
        { id: 'patientName', type: 'text', label: 'Patient Name', required: true },
        { id: 'medicareNumber', type: 'text', label: 'Medicare Number', required: true },
      ],
    },
    {
      id: 'abn-notice',
      title: 'Notice',
      fields: [
        { id: 'abnText', type: 'textarea', label: 'ABN Notice', required: false, readOnly: true, defaultValue: `ADVANCE BENEFICIARY NOTICE OF NONCOVERAGE (ABN)

NOTE: If Medicare doesn't pay for the items or services listed below, you may have to pay.

Medicare does not pay for everything, even some care that you or your health care provider have good reason to think you need. We expect Medicare may not pay for the items or services listed below.` },
      ],
    },
    {
      id: 'services',
      title: 'Items/Services That May Not Be Covered',
      fields: [
        { id: 'serviceDescription', type: 'textarea', label: 'Description of items/services', required: true, placeholder: 'e.g., Routine vision exam, Contact lens fitting' },
        { id: 'estimatedCost', type: 'text', label: 'Estimated Cost', required: true, placeholder: 'e.g., $150.00' },
        { id: 'reasonNotCovered', type: 'textarea', label: 'Reason Medicare may not pay', required: true, placeholder: 'e.g., Medicare does not cover routine vision exams' },
      ],
    },
    {
      id: 'options',
      title: 'Patient Options',
      fields: [
        { id: 'patientChoice', type: 'radio', label: 'Choose one option:', required: true, options: [
          { value: 'option1', label: 'OPTION 1: I want the items/services listed above. You may ask to be paid now, but I also want Medicare billed for an official decision. I understand that if Medicare doesn\'t pay, I am responsible for payment.' },
          { value: 'option2', label: 'OPTION 2: I want the items/services listed above, but do not bill Medicare. You may ask to be paid now. I cannot appeal if Medicare is not billed.' },
          { value: 'option3', label: 'OPTION 3: I don\'t want the items/services listed above. I understand that I will not be able to appeal to see if Medicare would pay.' }
        ]},
      ],
    },
    {
      id: 'signature',
      title: 'Signature',
      fields: [
        { id: 'additionalInfo', type: 'textarea', label: 'Additional Information', required: false },
        { id: 'patientSignature', type: 'signature', label: 'Patient Signature', required: true },
        { id: 'signatureDate', type: 'date', label: 'Date', required: true },
      ],
    },
  ],
};

// 18. Assignment of Benefits (AOB)
export const assignmentOfBenefitsTemplate: FormTemplate = {
  id: 'assignment-of-benefits',
  title: 'Assignment of Benefits',
  description: 'Authorization for insurance payment assignment',
  category: 'compliance',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'patient-info',
      title: 'Patient Information',
      fields: [
        { id: 'patientName', type: 'text', label: 'Patient Name', required: true },
        { id: 'patientDOB', type: 'date', label: 'Date of Birth', required: true },
        { id: 'insuranceId', type: 'text', label: 'Insurance ID Number', required: true },
      ],
    },
    {
      id: 'assignment',
      title: 'Assignment Authorization',
      fields: [
        { id: 'assignmentText', type: 'textarea', label: 'Assignment Statement', required: false, readOnly: true, defaultValue: `ASSIGNMENT OF BENEFITS

I hereby authorize and direct my insurance company to pay directly to this practice any benefits due to me for services rendered. I understand that I am financially responsible for all charges whether or not covered by insurance.

I authorize the release of any medical information necessary to process insurance claims.

I understand that:
• I am responsible for any deductibles, co-payments, and non-covered services
• If my insurance company denies payment, I am responsible for the full amount
• This assignment remains in effect until revoked by me in writing` },
      ],
    },
    {
      id: 'acknowledgement',
      title: 'Acknowledgement',
      fields: [
        { id: 'authorizePayment', type: 'checkbox', label: 'Payment Authorization', required: true, options: [
          { value: 'authorized', label: 'I authorize payment of benefits directly to this practice' }
        ]},
        { id: 'authorizeRelease', type: 'checkbox', label: 'Information Release', required: true, options: [
          { value: 'authorized', label: 'I authorize release of information to my insurance company' }
        ]},
        { id: 'understandResponsibility', type: 'checkbox', label: 'Financial Responsibility', required: true, options: [
          { value: 'understood', label: 'I understand I am responsible for amounts not covered by insurance' }
        ]},
        { id: 'patientSignature', type: 'signature', label: 'Patient/Guardian Signature', required: true },
        { id: 'signatureDate', type: 'date', label: 'Date', required: true },
      ],
    },
  ],
};

export const complianceForms = [
  contactLensRxReleaseTemplate,
  recordsReleaseTemplate,
  abnTemplate,
  assignmentOfBenefitsTemplate,
];
