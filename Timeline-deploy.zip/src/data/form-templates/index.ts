/**
 * Form Templates Index
 * Central registry for all eyecare form templates
 */

import { FormTemplate } from '../../lib/types/forms';

// Import all form template collections
import { intakeForms } from './intake-forms';
import { clinicalForms } from './clinical-forms';
import { complianceForms } from './compliance-forms';
import { specialtyForms } from './specialty-forms';
import { communicationForms } from './communication-forms';
import { opticalForms } from './optical-forms';
import { ftcRxAcknowledgementTemplate } from './ftc-rx-acknowledgement-template';

// Re-export individual form collections
export * from './intake-forms';
export * from './clinical-forms';
export * from './compliance-forms';
export * from './specialty-forms';
export * from './communication-forms';
export * from './optical-forms';
export * from './ftc-rx-acknowledgement-template';

// All form templates combined
export const allFormTemplates: FormTemplate[] = [
  // Existing FTC form
  ftcRxAcknowledgementTemplate,
  
  // Intake & Registration (Forms 1-6)
  ...intakeForms,
  
  // Clinical & Exam (Forms 7-13)
  ...clinicalForms,
  
  // Compliance & Regulatory (Forms 15-18)
  ...complianceForms,
  
  // Specialty & Procedures (Forms 19-23)
  ...specialtyForms,
  
  // Patient Communication (Forms 24-27)
  ...communicationForms,
  
  // Optical & Retail (Forms 28-30)
  ...opticalForms,
];

// Form templates by category
export const formTemplatesByCategory: Record<string, FormTemplate[]> = {
  intake: intakeForms,
  clinical: clinicalForms,
  compliance: [ftcRxAcknowledgementTemplate, ...complianceForms],
  specialty: specialtyForms,
  communication: communicationForms,
  optical: opticalForms,
};

// Get template by ID
export function getFormTemplateById(id: string): FormTemplate | undefined {
  return allFormTemplates.find(t => t.id === id);
}

// Get templates by category
export function getFormTemplatesByCategory(category: string): FormTemplate[] {
  return allFormTemplates.filter(t => t.category === category);
}

// Get all published templates
export function getPublishedFormTemplates(): FormTemplate[] {
  return allFormTemplates.filter(t => t.isPublished && !t.isArchived);
}

// Category display names
export const formCategoryDisplayNames: Record<string, string> = {
  intake: 'Intake & Registration',
  clinical: 'Clinical & Exam',
  compliance: 'Compliance & Regulatory',
  specialty: 'Specialty & Procedures',
  communication: 'Patient Communication',
  optical: 'Optical & Retail',
};

// Form counts by category
export function getFormCountsByCategory(): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const [category, templates] of Object.entries(formTemplatesByCategory)) {
    counts[category] = templates.length;
  }
  return counts;
}

console.log(`[Forms] Loaded ${allFormTemplates.length} form templates`);
