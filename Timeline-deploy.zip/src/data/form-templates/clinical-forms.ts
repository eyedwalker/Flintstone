/**
 * Clinical & Exam Form Templates
 * Forms 7-13: Dilation Consent, CL Fitting, CL Evaluation, Dry Eye, Glaucoma, Diabetic, Pediatric
 */

import { FormTemplate } from '../../lib/types/forms';

// 7. Dilated Eye Exam Consent
export const dilationConsentTemplate: FormTemplate = {
  id: 'dilation-consent',
  title: 'Dilated Eye Exam Consent',
  description: 'Consent for pupil dilation during your eye exam',
  category: 'clinical',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'dilation-info',
      title: 'About Pupil Dilation',
      fields: [
        { id: 'dilationInfo', type: 'textarea', label: 'Information', required: false, readOnly: true, defaultValue: `WHAT IS DILATION?
Dilating drops temporarily enlarge your pupils, allowing the doctor to see inside your eyes more clearly. This is important for detecting conditions such as glaucoma, macular degeneration, diabetic retinopathy, and other eye diseases.

EFFECTS OF DILATION:
• Your vision will be blurry for 3-6 hours, especially for near tasks
• You will be sensitive to light during this time
• You may have difficulty driving immediately after

RECOMMENDATIONS:
• Bring sunglasses or we will provide disposable ones
• Arrange for someone to drive you if possible
• Avoid tasks requiring sharp near vision for a few hours

RISKS:
Dilation is very safe. In rare cases, it may trigger an acute glaucoma attack in susceptible individuals (about 1 in 20,000). Symptoms include severe eye pain, nausea, and blurred vision. Seek immediate care if this occurs.` },
      ],
    },
    {
      id: 'consent',
      title: 'Consent',
      fields: [
        { id: 'consentToDilation', type: 'radio', label: 'Do you consent to having your eyes dilated today?', required: true, options: [
          { value: 'yes', label: 'Yes, I consent to dilation' },
          { value: 'no', label: 'No, I decline dilation' },
          { value: 'doctor-decides', label: 'Doctor\'s recommendation' }
        ]},
        { id: 'hasRide', type: 'radio', label: 'Do you have someone to drive you home?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No, I will drive myself' },
          { value: 'na', label: 'Not applicable (declining dilation)' }
        ]},
        { id: 'understandEffects', type: 'checkbox', label: 'Acknowledgement', required: true, options: [{ value: 'understood', label: 'I understand the effects of dilation and accept the risks' }] },
        { id: 'patientSignature', type: 'signature', label: 'Patient Signature', required: true },
        { id: 'signatureDate', type: 'date', label: 'Date', required: true },
      ],
    },
  ],
};

// 8. Contact Lens Fitting Agreement
export const contactLensFittingTemplate: FormTemplate = {
  id: 'contact-lens-fitting',
  title: 'Contact Lens Fitting Agreement',
  description: 'Agreement for contact lens fitting services',
  category: 'clinical',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'fitting-info',
      title: 'Contact Lens Fitting Information',
      fields: [
        { id: 'fittingInfo', type: 'textarea', label: 'About Contact Lens Fitting', required: false, readOnly: true, defaultValue: `CONTACT LENS FITTING FEE:
The contact lens fitting fee is separate from your comprehensive eye exam. This fee covers:
• Initial fitting and lens evaluation
• Trial lenses for evaluation
• Follow-up visits during the fitting period
• Instruction on lens insertion, removal, and care

The fitting fee does NOT include the cost of contact lenses.

FOLLOW-UP CARE:
You must return for all scheduled follow-up visits to ensure proper lens fit and eye health. Contact lenses are medical devices that require professional monitoring.

PRESCRIPTION RELEASE:
Per FTC regulations, your contact lens prescription will be provided after a successful fitting is complete (typically 1-2 follow-up visits).

LENS CARE RESPONSIBILITIES:
You are responsible for proper lens care, following the recommended wearing schedule, and returning for annual exams.` },
      ],
    },
    {
      id: 'lens-history',
      title: 'Contact Lens History',
      fields: [
        { id: 'previousCLWearer', type: 'radio', label: 'Have you worn contact lenses before?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No, this is my first time' }
        ]},
        { id: 'currentLensType', type: 'text', label: 'Current lens brand/type (if applicable)', required: false },
        { id: 'wearingSchedule', type: 'select', label: 'Desired wearing schedule', required: true, options: [
          { value: 'daily', label: 'Daily disposable' },
          { value: 'biweekly', label: 'Bi-weekly replacement' },
          { value: 'monthly', label: 'Monthly replacement' },
          { value: 'extended', label: 'Extended wear' },
          { value: 'unsure', label: 'Not sure - need recommendation' }
        ]},
        { id: 'clProblems', type: 'textarea', label: 'Any problems with previous contact lenses?', required: false },
      ],
    },
    {
      id: 'agreement',
      title: 'Agreement',
      fields: [
        { id: 'understandFee', type: 'checkbox', label: 'Fee Acknowledgement', required: true, options: [{ value: 'understood', label: 'I understand the fitting fee is separate from my exam and lens costs' }] },
        { id: 'agreeToFollowUp', type: 'checkbox', label: 'Follow-up Agreement', required: true, options: [{ value: 'agreed', label: 'I agree to return for all scheduled follow-up appointments' }] },
        { id: 'agreeToCareProperly', type: 'checkbox', label: 'Care Agreement', required: true, options: [{ value: 'agreed', label: 'I agree to care for my lenses as instructed' }] },
        { id: 'patientSignature', type: 'signature', label: 'Patient Signature', required: true },
        { id: 'signatureDate', type: 'date', label: 'Date', required: true },
      ],
    },
  ],
};

// 9. Contact Lens Evaluation Form
export const contactLensEvalTemplate: FormTemplate = {
  id: 'contact-lens-evaluation',
  title: 'Contact Lens Evaluation',
  description: 'Evaluate your current contact lens experience',
  category: 'clinical',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'current-lenses',
      title: 'Current Contact Lenses',
      fields: [
        { id: 'currentBrand', type: 'text', label: 'Current lens brand', required: true },
        { id: 'replacementSchedule', type: 'select', label: 'How often do you replace your lenses?', required: true, options: [
          { value: 'daily', label: 'Daily' },
          { value: 'biweekly', label: 'Every 2 weeks' },
          { value: 'monthly', label: 'Monthly' },
          { value: 'quarterly', label: 'Every 3 months' },
          { value: 'yearly', label: 'Yearly' },
          { value: 'irregular', label: 'Irregular/when they bother me' }
        ]},
        { id: 'hoursPerDay', type: 'number', label: 'Average hours worn per day', required: true, validation: { min: 1, max: 24 } },
        { id: 'daysPerWeek', type: 'number', label: 'Days per week worn', required: true, validation: { min: 1, max: 7 } },
        { id: 'sleepInLenses', type: 'radio', label: 'Do you sleep in your lenses?', required: true, options: [
          { value: 'never', label: 'Never' },
          { value: 'occasionally', label: 'Occasionally' },
          { value: 'regularly', label: 'Regularly' }
        ]},
      ],
    },
    {
      id: 'comfort-rating',
      title: 'Comfort & Vision Rating',
      fields: [
        { id: 'overallComfort', type: 'select', label: 'Overall comfort (1=Poor, 10=Excellent)', required: true, options: [
          { value: '1', label: '1 - Very Poor' },
          { value: '2', label: '2' },
          { value: '3', label: '3' },
          { value: '4', label: '4' },
          { value: '5', label: '5 - Average' },
          { value: '6', label: '6' },
          { value: '7', label: '7' },
          { value: '8', label: '8' },
          { value: '9', label: '9' },
          { value: '10', label: '10 - Excellent' }
        ]},
        { id: 'endOfDayComfort', type: 'select', label: 'End of day comfort', required: true, options: [
          { value: '1', label: '1 - Very Poor' },
          { value: '2', label: '2' },
          { value: '3', label: '3' },
          { value: '4', label: '4' },
          { value: '5', label: '5 - Average' },
          { value: '6', label: '6' },
          { value: '7', label: '7' },
          { value: '8', label: '8' },
          { value: '9', label: '9' },
          { value: '10', label: '10 - Excellent' }
        ]},
        { id: 'visionQuality', type: 'select', label: 'Vision quality', required: true, options: [
          { value: '1', label: '1 - Very Poor' },
          { value: '2', label: '2' },
          { value: '3', label: '3' },
          { value: '4', label: '4' },
          { value: '5', label: '5 - Average' },
          { value: '6', label: '6' },
          { value: '7', label: '7' },
          { value: '8', label: '8' },
          { value: '9', label: '9' },
          { value: '10', label: '10 - Excellent' }
        ]},
      ],
    },
    {
      id: 'symptoms',
      title: 'Symptoms',
      fields: [
        { id: 'clSymptoms', type: 'checkbox', label: 'Do you experience any of the following?', required: false, options: [
          { value: 'dryness', label: 'Dryness' },
          { value: 'redness', label: 'Redness' },
          { value: 'itching', label: 'Itching' },
          { value: 'burning', label: 'Burning' },
          { value: 'blurry-vision', label: 'Blurry vision' },
          { value: 'fluctuating-vision', label: 'Fluctuating vision' },
          { value: 'halos', label: 'Halos around lights' },
          { value: 'awareness', label: 'Lens awareness' },
          { value: 'debris', label: 'Debris/deposits on lenses' }
        ]},
        { id: 'symptomsWorseTime', type: 'select', label: 'When are symptoms worst?', required: false, options: [
          { value: 'morning', label: 'Morning' },
          { value: 'afternoon', label: 'Afternoon' },
          { value: 'evening', label: 'Evening' },
          { value: 'all-day', label: 'All day' },
          { value: 'no-symptoms', label: 'No symptoms' }
        ]},
      ],
    },
  ],
};

// 10. Dry Eye Questionnaire (OSDI-based)
export const dryEyeQuestionnaireTemplate: FormTemplate = {
  id: 'dry-eye-questionnaire',
  title: 'Dry Eye Questionnaire',
  description: 'Ocular Surface Disease Index (OSDI) Assessment',
  category: 'clinical',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'symptoms',
      title: 'Eye Symptoms',
      description: 'In the past week, how often have you experienced:',
      fields: [
        { id: 'lightSensitivity', type: 'select', label: 'Sensitivity to light', required: true, options: [
          { value: '0', label: 'None of the time' },
          { value: '1', label: 'Some of the time' },
          { value: '2', label: 'Half of the time' },
          { value: '3', label: 'Most of the time' },
          { value: '4', label: 'All of the time' }
        ]},
        { id: 'grittyFeeling', type: 'select', label: 'Gritty or sandy feeling', required: true, options: [
          { value: '0', label: 'None of the time' },
          { value: '1', label: 'Some of the time' },
          { value: '2', label: 'Half of the time' },
          { value: '3', label: 'Most of the time' },
          { value: '4', label: 'All of the time' }
        ]},
        { id: 'painfulEyes', type: 'select', label: 'Painful or sore eyes', required: true, options: [
          { value: '0', label: 'None of the time' },
          { value: '1', label: 'Some of the time' },
          { value: '2', label: 'Half of the time' },
          { value: '3', label: 'Most of the time' },
          { value: '4', label: 'All of the time' }
        ]},
        { id: 'blurredVision', type: 'select', label: 'Blurred vision', required: true, options: [
          { value: '0', label: 'None of the time' },
          { value: '1', label: 'Some of the time' },
          { value: '2', label: 'Half of the time' },
          { value: '3', label: 'Most of the time' },
          { value: '4', label: 'All of the time' }
        ]},
        { id: 'poorVision', type: 'select', label: 'Poor vision', required: true, options: [
          { value: '0', label: 'None of the time' },
          { value: '1', label: 'Some of the time' },
          { value: '2', label: 'Half of the time' },
          { value: '3', label: 'Most of the time' },
          { value: '4', label: 'All of the time' }
        ]},
      ],
    },
    {
      id: 'vision-problems',
      title: 'Vision Problems',
      description: 'Have problems with your eyes limited you in the past week:',
      fields: [
        { id: 'readingDifficulty', type: 'select', label: 'Reading', required: true, options: [
          { value: '0', label: 'None of the time' },
          { value: '1', label: 'Some of the time' },
          { value: '2', label: 'Half of the time' },
          { value: '3', label: 'Most of the time' },
          { value: '4', label: 'All of the time' },
          { value: 'na', label: 'Not applicable' }
        ]},
        { id: 'nightDriving', type: 'select', label: 'Driving at night', required: true, options: [
          { value: '0', label: 'None of the time' },
          { value: '1', label: 'Some of the time' },
          { value: '2', label: 'Half of the time' },
          { value: '3', label: 'Most of the time' },
          { value: '4', label: 'All of the time' },
          { value: 'na', label: 'Not applicable' }
        ]},
        { id: 'computerWork', type: 'select', label: 'Working with computer or ATM', required: true, options: [
          { value: '0', label: 'None of the time' },
          { value: '1', label: 'Some of the time' },
          { value: '2', label: 'Half of the time' },
          { value: '3', label: 'Most of the time' },
          { value: '4', label: 'All of the time' },
          { value: 'na', label: 'Not applicable' }
        ]},
        { id: 'watchingTV', type: 'select', label: 'Watching TV', required: true, options: [
          { value: '0', label: 'None of the time' },
          { value: '1', label: 'Some of the time' },
          { value: '2', label: 'Half of the time' },
          { value: '3', label: 'Most of the time' },
          { value: '4', label: 'All of the time' },
          { value: 'na', label: 'Not applicable' }
        ]},
      ],
    },
    {
      id: 'environmental',
      title: 'Environmental Triggers',
      description: 'Have your eyes felt uncomfortable in the past week:',
      fields: [
        { id: 'windyConditions', type: 'select', label: 'In windy conditions', required: true, options: [
          { value: '0', label: 'None of the time' },
          { value: '1', label: 'Some of the time' },
          { value: '2', label: 'Half of the time' },
          { value: '3', label: 'Most of the time' },
          { value: '4', label: 'All of the time' },
          { value: 'na', label: 'Not applicable' }
        ]},
        { id: 'lowHumidity', type: 'select', label: 'In low humidity (dry) areas', required: true, options: [
          { value: '0', label: 'None of the time' },
          { value: '1', label: 'Some of the time' },
          { value: '2', label: 'Half of the time' },
          { value: '3', label: 'Most of the time' },
          { value: '4', label: 'All of the time' },
          { value: 'na', label: 'Not applicable' }
        ]},
        { id: 'airConditioned', type: 'select', label: 'In air-conditioned areas', required: true, options: [
          { value: '0', label: 'None of the time' },
          { value: '1', label: 'Some of the time' },
          { value: '2', label: 'Half of the time' },
          { value: '3', label: 'Most of the time' },
          { value: '4', label: 'All of the time' },
          { value: 'na', label: 'Not applicable' }
        ]},
      ],
    },
  ],
};

// 11. Glaucoma Risk Assessment
export const glaucomaRiskTemplate: FormTemplate = {
  id: 'glaucoma-risk-assessment',
  title: 'Glaucoma Risk Assessment',
  description: 'Evaluate your risk factors for glaucoma',
  category: 'clinical',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'demographics',
      title: 'Demographic Risk Factors',
      fields: [
        { id: 'age', type: 'number', label: 'Your age', required: true, validation: { min: 0, max: 120 } },
        { id: 'ethnicity', type: 'select', label: 'Ethnicity', required: true, options: [
          { value: 'african-american', label: 'African American' },
          { value: 'hispanic', label: 'Hispanic/Latino' },
          { value: 'asian', label: 'Asian' },
          { value: 'caucasian', label: 'Caucasian' },
          { value: 'other', label: 'Other' }
        ]},
      ],
    },
    {
      id: 'family-history',
      title: 'Family History',
      fields: [
        { id: 'familyGlaucoma', type: 'radio', label: 'Do any blood relatives have glaucoma?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' },
          { value: 'unknown', label: 'Unknown' }
        ]},
        { id: 'whichRelatives', type: 'checkbox', label: 'If yes, which relatives?', required: false, options: [
          { value: 'parent', label: 'Parent' },
          { value: 'sibling', label: 'Sibling' },
          { value: 'grandparent', label: 'Grandparent' },
          { value: 'aunt-uncle', label: 'Aunt/Uncle' }
        ]},
      ],
    },
    {
      id: 'medical-factors',
      title: 'Medical Risk Factors',
      fields: [
        { id: 'diabetes', type: 'radio', label: 'Do you have diabetes?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'highBloodPressure', type: 'radio', label: 'Do you have high blood pressure?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'steroidUse', type: 'radio', label: 'Have you used steroid medications long-term?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'eyeInjury', type: 'radio', label: 'Have you had a significant eye injury?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'highMyopia', type: 'radio', label: 'Are you highly nearsighted?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' },
          { value: 'unknown', label: 'Not sure' }
        ]},
      ],
    },
    {
      id: 'symptoms',
      title: 'Symptoms',
      fields: [
        { id: 'visionLoss', type: 'radio', label: 'Have you noticed any loss of peripheral (side) vision?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'halos', type: 'radio', label: 'Do you see halos around lights?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'eyePressure', type: 'radio', label: 'Have you ever been told you have elevated eye pressure?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' },
          { value: 'unknown', label: 'Unknown' }
        ]},
      ],
    },
  ],
};

// 12. Diabetic Eye Exam Form
export const diabeticEyeExamTemplate: FormTemplate = {
  id: 'diabetic-eye-exam',
  title: 'Diabetic Eye Exam Form',
  description: 'Pre-exam questionnaire for patients with diabetes',
  category: 'clinical',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'diabetes-info',
      title: 'Diabetes Information',
      fields: [
        { id: 'diabetesType', type: 'select', label: 'Type of diabetes', required: true, options: [
          { value: 'type1', label: 'Type 1' },
          { value: 'type2', label: 'Type 2' },
          { value: 'gestational', label: 'Gestational' },
          { value: 'prediabetes', label: 'Pre-diabetes' },
          { value: 'unknown', label: 'Unknown' }
        ]},
        { id: 'yearsDiagnosed', type: 'number', label: 'Years since diagnosis', required: true, validation: { min: 0, max: 100 } },
        { id: 'lastA1c', type: 'text', label: 'Most recent HbA1c level', required: false, placeholder: 'e.g., 7.2%' },
        { id: 'a1cDate', type: 'date', label: 'Date of last HbA1c test', required: false },
      ],
    },
    {
      id: 'treatment',
      title: 'Diabetes Treatment',
      fields: [
        { id: 'diabetesTreatment', type: 'checkbox', label: 'How do you manage your diabetes?', required: true, options: [
          { value: 'diet', label: 'Diet only' },
          { value: 'oral-meds', label: 'Oral medications' },
          { value: 'insulin', label: 'Insulin injections' },
          { value: 'insulin-pump', label: 'Insulin pump' },
          { value: 'other', label: 'Other' }
        ]},
        { id: 'diabetesDoctor', type: 'text', label: 'Diabetes doctor/endocrinologist name', required: false },
        { id: 'lastDiabetesVisit', type: 'date', label: 'Date of last diabetes doctor visit', required: false },
      ],
    },
    {
      id: 'complications',
      title: 'Diabetes Complications',
      fields: [
        { id: 'diabeticRetinopathy', type: 'radio', label: 'Have you been diagnosed with diabetic retinopathy?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' },
          { value: 'unknown', label: 'Unknown' }
        ]},
        { id: 'retinopathyTreatment', type: 'checkbox', label: 'If yes, what treatment have you had?', required: false, options: [
          { value: 'laser', label: 'Laser treatment' },
          { value: 'injections', label: 'Eye injections' },
          { value: 'surgery', label: 'Surgery' },
          { value: 'monitoring', label: 'Monitoring only' }
        ]},
        { id: 'otherComplications', type: 'checkbox', label: 'Other diabetes-related complications', required: false, options: [
          { value: 'neuropathy', label: 'Neuropathy (nerve damage)' },
          { value: 'nephropathy', label: 'Nephropathy (kidney disease)' },
          { value: 'cardiovascular', label: 'Cardiovascular disease' },
          { value: 'none', label: 'None' }
        ]},
      ],
    },
    {
      id: 'vision-symptoms',
      title: 'Vision Symptoms',
      fields: [
        { id: 'visionChanges', type: 'checkbox', label: 'Have you noticed any of the following?', required: false, options: [
          { value: 'blurry', label: 'Blurry vision' },
          { value: 'fluctuating', label: 'Fluctuating vision' },
          { value: 'floaters', label: 'New floaters' },
          { value: 'dark-spots', label: 'Dark spots in vision' },
          { value: 'difficulty-night', label: 'Difficulty seeing at night' },
          { value: 'color-changes', label: 'Colors look faded' }
        ]},
      ],
    },
  ],
};

// 13. Pediatric Vision Screening
export const pediatricScreeningTemplate: FormTemplate = {
  id: 'pediatric-vision-screening',
  title: 'Pediatric Vision Screening',
  description: 'Vision screening questionnaire for children',
  category: 'clinical',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'child-info',
      title: 'Child Information',
      fields: [
        { id: 'childName', type: 'text', label: 'Child\'s Name', required: true },
        { id: 'childDOB', type: 'date', label: 'Date of Birth', required: true },
        { id: 'grade', type: 'text', label: 'Current Grade/School', required: false },
        { id: 'parentName', type: 'text', label: 'Parent/Guardian Name', required: true },
      ],
    },
    {
      id: 'birth-history',
      title: 'Birth & Development History',
      fields: [
        { id: 'premature', type: 'radio', label: 'Was your child born prematurely?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'birthComplications', type: 'radio', label: 'Were there any birth complications?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'developmentalDelays', type: 'radio', label: 'Any developmental delays?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
      ],
    },
    {
      id: 'vision-behaviors',
      title: 'Vision-Related Behaviors',
      description: 'Does your child exhibit any of the following?',
      fields: [
        { id: 'visionBehaviors', type: 'checkbox', label: 'Check all that apply', required: false, options: [
          { value: 'squinting', label: 'Squinting' },
          { value: 'head-tilt', label: 'Head tilting' },
          { value: 'sits-close-tv', label: 'Sits close to TV' },
          { value: 'holds-books-close', label: 'Holds books/devices very close' },
          { value: 'loses-place', label: 'Loses place when reading' },
          { value: 'finger-tracking', label: 'Uses finger to track while reading' },
          { value: 'avoids-reading', label: 'Avoids reading or close work' },
          { value: 'headaches', label: 'Complains of headaches' },
          { value: 'eye-rubbing', label: 'Frequent eye rubbing' },
          { value: 'eye-turn', label: 'Eyes appear crossed or turned' },
          { value: 'covers-eye', label: 'Covers or closes one eye' }
        ]},
      ],
    },
    {
      id: 'school-performance',
      title: 'School Performance',
      fields: [
        { id: 'schoolDifficulty', type: 'radio', label: 'Is your child having difficulty in school?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'learningDisability', type: 'radio', label: 'Has your child been diagnosed with a learning disability?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'iep', type: 'radio', label: 'Does your child have an IEP or 504 plan?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
      ],
    },
    {
      id: 'family-history',
      title: 'Family Eye History',
      fields: [
        { id: 'familyGlasses', type: 'radio', label: 'Do parents or siblings wear glasses?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'familyEyeConditions', type: 'checkbox', label: 'Any family history of:', required: false, options: [
          { value: 'amblyopia', label: 'Lazy eye (amblyopia)' },
          { value: 'strabismus', label: 'Crossed eyes (strabismus)' },
          { value: 'color-blindness', label: 'Color blindness' },
          { value: 'glaucoma', label: 'Glaucoma' },
          { value: 'retinal', label: 'Retinal problems' }
        ]},
      ],
    },
  ],
};

export const clinicalForms = [
  dilationConsentTemplate,
  contactLensFittingTemplate,
  contactLensEvalTemplate,
  dryEyeQuestionnaireTemplate,
  glaucomaRiskTemplate,
  diabeticEyeExamTemplate,
  pediatricScreeningTemplate,
];
