/**
 * Specialty & Procedure Form Templates
 * Forms 19-23: Ortho-K, Myopia Management, Low Vision, Cataract Pre-Op, LASIK Referral
 */

import { FormTemplate } from '../../lib/types/forms';

// 19. Ortho-K Consent Form
export const orthoKConsentTemplate: FormTemplate = {
  id: 'ortho-k-consent',
  title: 'Orthokeratology (Ortho-K) Consent',
  description: 'Informed consent for orthokeratology treatment',
  category: 'specialty',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'overview',
      title: 'What is Orthokeratology?',
      fields: [
        { id: 'orthoKInfo', type: 'textarea', label: 'Information', required: false, readOnly: true, defaultValue: `ORTHOKERATOLOGY (ORTHO-K)

Orthokeratology is a non-surgical procedure using specially designed rigid gas permeable contact lenses worn during sleep to temporarily reshape the cornea, reducing or eliminating myopia (nearsightedness).

BENEFITS:
• Clear vision during the day without glasses or contacts
• Non-surgical and reversible
• May slow myopia progression in children
• Good option for active lifestyles

IMPORTANT CONSIDERATIONS:
• Results are temporary - lenses must be worn nightly
• Multiple follow-up visits are required
• Not all patients achieve full correction
• Higher risk of infection compared to daytime wear if not properly cared for` },
      ],
    },
    {
      id: 'risks',
      title: 'Risks & Complications',
      fields: [
        { id: 'risksInfo', type: 'textarea', label: 'Risks', required: false, readOnly: true, defaultValue: `POTENTIAL RISKS:

• Corneal infection (microbial keratitis) - rare but serious
• Corneal abrasion or irritation
• Discomfort during adaptation period
• Ghosting or halos around lights
• Incomplete or unstable vision correction
• Corneal warpage (temporary, reversible)

RISK REDUCTION:
Proper lens care and hygiene are critical to minimizing risks. You must follow all care instructions exactly.` },
        { id: 'understandRisks', type: 'checkbox', label: 'Risk Acknowledgement', required: true, options: [
          { value: 'understood', label: 'I understand the risks associated with Ortho-K treatment' }
        ]},
      ],
    },
    {
      id: 'commitment',
      title: 'Patient Commitment',
      fields: [
        { id: 'commitments', type: 'checkbox', label: 'I agree to:', required: true, options: [
          { value: 'follow-instructions', label: 'Follow all lens care instructions exactly' },
          { value: 'attend-followups', label: 'Attend all scheduled follow-up appointments' },
          { value: 'report-problems', label: 'Report any problems immediately' },
          { value: 'annual-exams', label: 'Return for annual comprehensive exams' }
        ]},
      ],
    },
    {
      id: 'consent',
      title: 'Consent',
      fields: [
        { id: 'patientName', type: 'text', label: 'Patient Name', required: true },
        { id: 'consentToTreatment', type: 'checkbox', label: 'Consent', required: true, options: [
          { value: 'consented', label: 'I consent to orthokeratology treatment and understand the information provided' }
        ]},
        { id: 'patientSignature', type: 'signature', label: 'Patient/Guardian Signature', required: true },
        { id: 'signatureDate', type: 'date', label: 'Date', required: true },
      ],
    },
  ],
};

// 20. Myopia Management Consent
export const myopiaManagementTemplate: FormTemplate = {
  id: 'myopia-management-consent',
  title: 'Myopia Management Consent',
  description: 'Consent for myopia control treatment options',
  category: 'specialty',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'overview',
      title: 'Understanding Myopia',
      fields: [
        { id: 'myopiaInfo', type: 'textarea', label: 'Information', required: false, readOnly: true, defaultValue: `MYOPIA (NEARSIGHTEDNESS) AND WHY CONTROL MATTERS

Myopia typically develops in childhood and often progresses until early adulthood. High myopia increases the risk of serious eye conditions later in life, including:

• Retinal detachment
• Glaucoma
• Cataracts
• Myopic maculopathy

Myopia management aims to slow the progression of nearsightedness, reducing these long-term risks.` },
      ],
    },
    {
      id: 'treatment-options',
      title: 'Treatment Options',
      fields: [
        { id: 'selectedTreatment', type: 'checkbox', label: 'Recommended treatment(s)', required: true, options: [
          { value: 'atropine', label: 'Low-dose atropine eye drops' },
          { value: 'ortho-k', label: 'Orthokeratology (Ortho-K) lenses' },
          { value: 'multifocal-cl', label: 'Multifocal contact lenses' },
          { value: 'multifocal-glasses', label: 'Multifocal/progressive glasses' },
          { value: 'outdoor-time', label: 'Increased outdoor time recommendations' }
        ]},
      ],
    },
    {
      id: 'atropine-info',
      title: 'Low-Dose Atropine Information',
      description: 'If atropine is part of your treatment plan',
      fields: [
        { id: 'atropineInfo', type: 'textarea', label: 'About Atropine', required: false, readOnly: true, defaultValue: `LOW-DOSE ATROPINE EYE DROPS

Atropine drops (typically 0.01% - 0.05%) have been shown to slow myopia progression with minimal side effects at low doses.

USAGE:
• One drop in each eye at bedtime
• Used continuously, typically for several years

POSSIBLE SIDE EFFECTS:
• Mild light sensitivity
• Slight pupil dilation
• Difficulty with near focus (minimal at low doses)

This is considered an "off-label" use of atropine, meaning it is not FDA-approved specifically for myopia control, though it is widely used and studied for this purpose.` },
        { id: 'understandAtropine', type: 'checkbox', label: 'Acknowledgement', required: false, options: [
          { value: 'understood', label: 'I understand atropine for myopia is an off-label use' }
        ]},
      ],
    },
    {
      id: 'consent',
      title: 'Consent',
      fields: [
        { id: 'childName', type: 'text', label: 'Child\'s Name', required: true },
        { id: 'parentName', type: 'text', label: 'Parent/Guardian Name', required: true },
        { id: 'consentToTreatment', type: 'checkbox', label: 'Consent', required: true, options: [
          { value: 'consented', label: 'I consent to myopia management treatment for my child' }
        ]},
        { id: 'parentSignature', type: 'signature', label: 'Parent/Guardian Signature', required: true },
        { id: 'signatureDate', type: 'date', label: 'Date', required: true },
      ],
    },
  ],
};

// 21. Low Vision Assessment
export const lowVisionAssessmentTemplate: FormTemplate = {
  id: 'low-vision-assessment',
  title: 'Low Vision Assessment',
  description: 'Functional vision questionnaire for low vision patients',
  category: 'specialty',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'patient-info',
      title: 'Patient Information',
      fields: [
        { id: 'patientName', type: 'text', label: 'Patient Name', required: true },
        { id: 'diagnosis', type: 'text', label: 'Primary Eye Condition', required: true, placeholder: 'e.g., Macular Degeneration, Glaucoma' },
        { id: 'diagnosisDate', type: 'text', label: 'When were you diagnosed?', required: false },
      ],
    },
    {
      id: 'daily-activities',
      title: 'Daily Activities',
      description: 'Rate your difficulty with these tasks (1=No difficulty, 5=Cannot do)',
      fields: [
        { id: 'readingMail', type: 'select', label: 'Reading mail/bills', required: true, options: [
          { value: '1', label: '1 - No difficulty' },
          { value: '2', label: '2 - Slight difficulty' },
          { value: '3', label: '3 - Moderate difficulty' },
          { value: '4', label: '4 - Severe difficulty' },
          { value: '5', label: '5 - Cannot do' }
        ]},
        { id: 'readingNewspaper', type: 'select', label: 'Reading newspaper/books', required: true, options: [
          { value: '1', label: '1 - No difficulty' },
          { value: '2', label: '2 - Slight difficulty' },
          { value: '3', label: '3 - Moderate difficulty' },
          { value: '4', label: '4 - Severe difficulty' },
          { value: '5', label: '5 - Cannot do' }
        ]},
        { id: 'recognizingFaces', type: 'select', label: 'Recognizing faces', required: true, options: [
          { value: '1', label: '1 - No difficulty' },
          { value: '2', label: '2 - Slight difficulty' },
          { value: '3', label: '3 - Moderate difficulty' },
          { value: '4', label: '4 - Severe difficulty' },
          { value: '5', label: '5 - Cannot do' }
        ]},
        { id: 'watchingTV', type: 'select', label: 'Watching TV', required: true, options: [
          { value: '1', label: '1 - No difficulty' },
          { value: '2', label: '2 - Slight difficulty' },
          { value: '3', label: '3 - Moderate difficulty' },
          { value: '4', label: '4 - Severe difficulty' },
          { value: '5', label: '5 - Cannot do' }
        ]},
        { id: 'cooking', type: 'select', label: 'Cooking/preparing food', required: true, options: [
          { value: '1', label: '1 - No difficulty' },
          { value: '2', label: '2 - Slight difficulty' },
          { value: '3', label: '3 - Moderate difficulty' },
          { value: '4', label: '4 - Severe difficulty' },
          { value: '5', label: '5 - Cannot do' }
        ]},
        { id: 'writingChecks', type: 'select', label: 'Writing checks/signing documents', required: true, options: [
          { value: '1', label: '1 - No difficulty' },
          { value: '2', label: '2 - Slight difficulty' },
          { value: '3', label: '3 - Moderate difficulty' },
          { value: '4', label: '4 - Severe difficulty' },
          { value: '5', label: '5 - Cannot do' }
        ]},
      ],
    },
    {
      id: 'mobility',
      title: 'Mobility',
      fields: [
        { id: 'gettingAround', type: 'select', label: 'Getting around inside your home', required: true, options: [
          { value: '1', label: '1 - No difficulty' },
          { value: '2', label: '2 - Slight difficulty' },
          { value: '3', label: '3 - Moderate difficulty' },
          { value: '4', label: '4 - Severe difficulty' },
          { value: '5', label: '5 - Cannot do' }
        ]},
        { id: 'stairs', type: 'select', label: 'Going up/down stairs', required: true, options: [
          { value: '1', label: '1 - No difficulty' },
          { value: '2', label: '2 - Slight difficulty' },
          { value: '3', label: '3 - Moderate difficulty' },
          { value: '4', label: '4 - Severe difficulty' },
          { value: '5', label: '5 - Cannot do' }
        ]},
        { id: 'outdoorMobility', type: 'select', label: 'Walking outdoors', required: true, options: [
          { value: '1', label: '1 - No difficulty' },
          { value: '2', label: '2 - Slight difficulty' },
          { value: '3', label: '3 - Moderate difficulty' },
          { value: '4', label: '4 - Severe difficulty' },
          { value: '5', label: '5 - Cannot do' }
        ]},
        { id: 'driving', type: 'radio', label: 'Do you currently drive?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no-gave-up', label: 'No, gave up due to vision' },
          { value: 'no-never', label: 'Never drove' }
        ]},
      ],
    },
    {
      id: 'goals',
      title: 'Your Goals',
      fields: [
        { id: 'primaryGoals', type: 'checkbox', label: 'What would you most like help with?', required: true, options: [
          { value: 'reading', label: 'Reading' },
          { value: 'writing', label: 'Writing' },
          { value: 'computer', label: 'Computer/tablet use' },
          { value: 'driving', label: 'Driving' },
          { value: 'hobbies', label: 'Hobbies' },
          { value: 'mobility', label: 'Getting around safely' },
          { value: 'independence', label: 'General independence' }
        ]},
        { id: 'additionalGoals', type: 'textarea', label: 'Any other goals or concerns?', required: false },
      ],
    },
  ],
};

// 22. Cataract Surgery Pre-Op Questionnaire
export const cataractPreOpTemplate: FormTemplate = {
  id: 'cataract-pre-op',
  title: 'Cataract Surgery Pre-Op Questionnaire',
  description: 'Pre-surgical health screening for cataract surgery',
  category: 'specialty',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'patient-info',
      title: 'Patient Information',
      fields: [
        { id: 'patientName', type: 'text', label: 'Patient Name', required: true },
        { id: 'surgeryDate', type: 'date', label: 'Scheduled Surgery Date', required: true },
        { id: 'surgeryEye', type: 'select', label: 'Which eye is being operated on?', required: true, options: [
          { value: 'right', label: 'Right eye' },
          { value: 'left', label: 'Left eye' },
          { value: 'both', label: 'Both eyes (staged)' }
        ]},
      ],
    },
    {
      id: 'medical-history',
      title: 'Medical History',
      fields: [
        { id: 'medicalConditions', type: 'checkbox', label: 'Do you have any of the following?', required: false, options: [
          { value: 'diabetes', label: 'Diabetes' },
          { value: 'heart-disease', label: 'Heart disease' },
          { value: 'high-blood-pressure', label: 'High blood pressure' },
          { value: 'bleeding-disorder', label: 'Bleeding disorder' },
          { value: 'pacemaker', label: 'Pacemaker/defibrillator' },
          { value: 'copd-asthma', label: 'COPD or Asthma' },
          { value: 'sleep-apnea', label: 'Sleep apnea' },
          { value: 'kidney-disease', label: 'Kidney disease' }
        ]},
        { id: 'previousSurgeries', type: 'textarea', label: 'List any previous surgeries', required: false },
      ],
    },
    {
      id: 'medications',
      title: 'Current Medications',
      fields: [
        { id: 'bloodThinners', type: 'radio', label: 'Do you take blood thinners?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'bloodThinnerList', type: 'text', label: 'If yes, which ones?', required: false, placeholder: 'e.g., Warfarin, Eliquis, Aspirin' },
        { id: 'tamsulosin', type: 'radio', label: 'Do you take Flomax (tamsulosin) or similar prostate medication?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'allMedications', type: 'textarea', label: 'List all current medications', required: true },
      ],
    },
    {
      id: 'allergies',
      title: 'Allergies',
      fields: [
        { id: 'drugAllergies', type: 'textarea', label: 'Drug allergies (include reaction type)', required: false, placeholder: 'e.g., Penicillin - rash' },
        { id: 'latexAllergy', type: 'radio', label: 'Latex allergy?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'iodineAllergy', type: 'radio', label: 'Iodine/Betadine allergy?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
      ],
    },
    {
      id: 'anesthesia',
      title: 'Anesthesia History',
      fields: [
        { id: 'previousAnesthesia', type: 'radio', label: 'Have you had anesthesia before?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'anesthesiaProblems', type: 'radio', label: 'Any problems with anesthesia?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'anesthesiaDetails', type: 'textarea', label: 'If yes, please describe', required: false },
        { id: 'familyAnesthesiaProblems', type: 'radio', label: 'Any family members with anesthesia problems?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' },
          { value: 'unknown', label: 'Unknown' }
        ]},
      ],
    },
  ],
};

// 23. LASIK/Refractive Surgery Referral Questionnaire
export const lasikReferralTemplate: FormTemplate = {
  id: 'lasik-referral',
  title: 'LASIK/Refractive Surgery Screening',
  description: 'Pre-screening questionnaire for refractive surgery candidacy',
  category: 'specialty',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'basic-info',
      title: 'Basic Information',
      fields: [
        { id: 'patientName', type: 'text', label: 'Patient Name', required: true },
        { id: 'age', type: 'number', label: 'Age', required: true, validation: { min: 18, max: 100 } },
        { id: 'occupation', type: 'text', label: 'Occupation', required: false },
      ],
    },
    {
      id: 'current-vision',
      title: 'Current Vision Correction',
      fields: [
        { id: 'currentCorrection', type: 'select', label: 'What do you currently wear?', required: true, options: [
          { value: 'glasses', label: 'Glasses only' },
          { value: 'contacts', label: 'Contact lenses only' },
          { value: 'both', label: 'Both glasses and contacts' },
          { value: 'neither', label: 'Nothing currently' }
        ]},
        { id: 'yearsWearing', type: 'number', label: 'How many years have you worn correction?', required: true },
        { id: 'rxStable', type: 'radio', label: 'Has your prescription been stable for at least 1 year?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' },
          { value: 'unsure', label: 'Not sure' }
        ]},
      ],
    },
    {
      id: 'motivation',
      title: 'Motivation',
      fields: [
        { id: 'whyInterested', type: 'checkbox', label: 'Why are you interested in refractive surgery?', required: true, options: [
          { value: 'convenience', label: 'Convenience/lifestyle' },
          { value: 'sports', label: 'Sports/athletics' },
          { value: 'occupation', label: 'Occupational requirements' },
          { value: 'contacts-intolerance', label: 'Cannot wear contacts comfortably' },
          { value: 'cosmetic', label: 'Don\'t like wearing glasses' },
          { value: 'other', label: 'Other' }
        ]},
        { id: 'expectations', type: 'textarea', label: 'What are your expectations from surgery?', required: false },
      ],
    },
    {
      id: 'health-screening',
      title: 'Health Screening',
      fields: [
        { id: 'autoimmune', type: 'radio', label: 'Do you have any autoimmune diseases?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'diabetes', type: 'radio', label: 'Do you have diabetes?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'pregnant', type: 'radio', label: 'Are you pregnant or nursing?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' },
          { value: 'na', label: 'Not applicable' }
        ]},
        { id: 'herpes', type: 'radio', label: 'History of eye herpes?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'keratoconus', type: 'radio', label: 'Have you been told you have keratoconus or thin corneas?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' },
          { value: 'unknown', label: 'Unknown' }
        ]},
        { id: 'dryEye', type: 'radio', label: 'Do you have significant dry eye symptoms?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
      ],
    },
    {
      id: 'understanding',
      title: 'Understanding',
      fields: [
        { id: 'understandRisks', type: 'checkbox', label: 'I understand that:', required: true, options: [
          { value: 'not-guaranteed', label: 'Results are not guaranteed' },
          { value: 'may-need-glasses', label: 'I may still need glasses for some tasks' },
          { value: 'reading-glasses', label: 'I will likely need reading glasses after age 40-45' },
          { value: 'rare-complications', label: 'Rare complications can occur' }
        ]},
      ],
    },
  ],
};

export const specialtyForms = [
  orthoKConsentTemplate,
  myopiaManagementTemplate,
  lowVisionAssessmentTemplate,
  cataractPreOpTemplate,
  lasikReferralTemplate,
];
