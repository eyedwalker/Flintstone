/**
 * Patient Communication Form Templates
 * Forms 24-27: Appointment Confirmation, Recall Preferences, Satisfaction Survey, Referral Thank You
 */

import { FormTemplate } from '../../lib/types/forms';

// 24. Appointment Confirmation
export const appointmentConfirmationTemplate: FormTemplate = {
  id: 'appointment-confirmation',
  title: 'Appointment Confirmation',
  description: 'Confirm or reschedule your upcoming appointment',
  category: 'communication',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'appointment-details',
      title: 'Your Appointment',
      fields: [
        { id: 'patientName', type: 'text', label: 'Patient Name', required: true },
        { id: 'appointmentDate', type: 'date', label: 'Appointment Date', required: true },
        { id: 'appointmentTime', type: 'text', label: 'Appointment Time', required: true },
        { id: 'appointmentType', type: 'text', label: 'Appointment Type', required: false },
        { id: 'providerName', type: 'text', label: 'Provider', required: false },
      ],
    },
    {
      id: 'confirmation',
      title: 'Please Confirm',
      fields: [
        { id: 'confirmStatus', type: 'radio', label: 'Can you make this appointment?', required: true, options: [
          { value: 'confirm', label: 'Yes, I confirm this appointment' },
          { value: 'reschedule', label: 'No, I need to reschedule' },
          { value: 'cancel', label: 'I need to cancel' }
        ]},
        { id: 'reschedulePreference', type: 'textarea', label: 'If rescheduling, when would work better for you?', required: false, placeholder: 'e.g., Mornings next week, any Tuesday afternoon' },
        { id: 'cancelReason', type: 'select', label: 'If cancelling, please let us know why', required: false, options: [
          { value: 'schedule-conflict', label: 'Schedule conflict' },
          { value: 'illness', label: 'Illness' },
          { value: 'transportation', label: 'Transportation issue' },
          { value: 'no-longer-needed', label: 'No longer need appointment' },
          { value: 'other', label: 'Other' }
        ]},
      ],
    },
    {
      id: 'reminders',
      title: 'Appointment Reminders',
      fields: [
        { id: 'bringItems', type: 'textarea', label: 'Please remember to bring', required: false, readOnly: true, defaultValue: `• Photo ID
• Insurance cards (vision and medical)
• Current glasses and/or contact lenses
• List of current medications
• Completed new patient forms (if applicable)` },
        { id: 'arrivalTime', type: 'textarea', label: 'Arrival Instructions', required: false, readOnly: true, defaultValue: `Please arrive 15 minutes early for your appointment to complete any necessary paperwork.

If you wear contact lenses and are having a comprehensive exam, you may be asked to remove them for certain tests.` },
      ],
    },
  ],
};

// 25. Recall/Reminder Preferences
export const recallPreferencesTemplate: FormTemplate = {
  id: 'recall-preferences',
  title: 'Communication Preferences',
  description: 'Set your preferred contact methods for appointment reminders',
  category: 'communication',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'contact-info',
      title: 'Contact Information',
      fields: [
        { id: 'patientName', type: 'text', label: 'Patient Name', required: true },
        { id: 'mobilePhone', type: 'phone', label: 'Mobile Phone', required: false },
        { id: 'homePhone', type: 'phone', label: 'Home Phone', required: false },
        { id: 'email', type: 'email', label: 'Email Address', required: false },
      ],
    },
    {
      id: 'reminder-preferences',
      title: 'Appointment Reminder Preferences',
      fields: [
        { id: 'reminderMethod', type: 'checkbox', label: 'How would you like to receive appointment reminders?', required: true, options: [
          { value: 'text', label: 'Text message (SMS)' },
          { value: 'email', label: 'Email' },
          { value: 'phone', label: 'Phone call' },
          { value: 'mail', label: 'Postal mail' }
        ]},
        { id: 'reminderTiming', type: 'checkbox', label: 'When would you like reminders?', required: true, options: [
          { value: '1-week', label: '1 week before' },
          { value: '3-days', label: '3 days before' },
          { value: '1-day', label: '1 day before' },
          { value: 'same-day', label: 'Day of appointment' }
        ]},
      ],
    },
    {
      id: 'recall-preferences',
      title: 'Annual Exam Recall Preferences',
      fields: [
        { id: 'recallMethod', type: 'checkbox', label: 'How should we contact you when it\'s time for your annual exam?', required: true, options: [
          { value: 'text', label: 'Text message (SMS)' },
          { value: 'email', label: 'Email' },
          { value: 'phone', label: 'Phone call' },
          { value: 'mail', label: 'Postcard' }
        ]},
        { id: 'recallTiming', type: 'select', label: 'When should we contact you?', required: true, options: [
          { value: '1-month', label: '1 month before due' },
          { value: '2-weeks', label: '2 weeks before due' },
          { value: 'when-due', label: 'When due' },
          { value: 'prefer-not', label: 'Please don\'t contact me for recalls' }
        ]},
      ],
    },
    {
      id: 'marketing',
      title: 'Promotional Communications',
      fields: [
        { id: 'marketingConsent', type: 'radio', label: 'Would you like to receive special offers and promotions?', required: true, options: [
          { value: 'yes', label: 'Yes, I\'d like to hear about specials' },
          { value: 'no', label: 'No thank you' }
        ]},
      ],
    },
  ],
};

// 26. Patient Satisfaction Survey
export const satisfactionSurveyTemplate: FormTemplate = {
  id: 'patient-satisfaction-survey',
  title: 'Patient Satisfaction Survey',
  description: 'Help us improve by sharing your feedback',
  category: 'communication',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'visit-info',
      title: 'Your Recent Visit',
      fields: [
        { id: 'visitDate', type: 'date', label: 'Date of your visit', required: true },
        { id: 'visitType', type: 'select', label: 'Type of visit', required: true, options: [
          { value: 'comprehensive', label: 'Comprehensive eye exam' },
          { value: 'contact-lens', label: 'Contact lens fitting/follow-up' },
          { value: 'medical', label: 'Medical eye visit' },
          { value: 'glasses', label: 'Glasses purchase/pickup' },
          { value: 'other', label: 'Other' }
        ]},
      ],
    },
    {
      id: 'ratings',
      title: 'Please Rate Your Experience',
      description: '1 = Poor, 5 = Excellent',
      fields: [
        { id: 'easeOfScheduling', type: 'select', label: 'Ease of scheduling your appointment', required: true, options: [
          { value: '1', label: '1 - Poor' },
          { value: '2', label: '2 - Fair' },
          { value: '3', label: '3 - Good' },
          { value: '4', label: '4 - Very Good' },
          { value: '5', label: '5 - Excellent' }
        ]},
        { id: 'waitTime', type: 'select', label: 'Wait time', required: true, options: [
          { value: '1', label: '1 - Poor' },
          { value: '2', label: '2 - Fair' },
          { value: '3', label: '3 - Good' },
          { value: '4', label: '4 - Very Good' },
          { value: '5', label: '5 - Excellent' }
        ]},
        { id: 'staffFriendliness', type: 'select', label: 'Staff friendliness', required: true, options: [
          { value: '1', label: '1 - Poor' },
          { value: '2', label: '2 - Fair' },
          { value: '3', label: '3 - Good' },
          { value: '4', label: '4 - Very Good' },
          { value: '5', label: '5 - Excellent' }
        ]},
        { id: 'doctorCare', type: 'select', label: 'Doctor\'s care and thoroughness', required: true, options: [
          { value: '1', label: '1 - Poor' },
          { value: '2', label: '2 - Fair' },
          { value: '3', label: '3 - Good' },
          { value: '4', label: '4 - Very Good' },
          { value: '5', label: '5 - Excellent' }
        ]},
        { id: 'explanations', type: 'select', label: 'Explanations of findings and recommendations', required: true, options: [
          { value: '1', label: '1 - Poor' },
          { value: '2', label: '2 - Fair' },
          { value: '3', label: '3 - Good' },
          { value: '4', label: '4 - Very Good' },
          { value: '5', label: '5 - Excellent' }
        ]},
        { id: 'opticalExperience', type: 'select', label: 'Optical/eyewear experience (if applicable)', required: false, options: [
          { value: '1', label: '1 - Poor' },
          { value: '2', label: '2 - Fair' },
          { value: '3', label: '3 - Good' },
          { value: '4', label: '4 - Very Good' },
          { value: '5', label: '5 - Excellent' },
          { value: 'na', label: 'N/A' }
        ]},
        { id: 'overallExperience', type: 'select', label: 'Overall experience', required: true, options: [
          { value: '1', label: '1 - Poor' },
          { value: '2', label: '2 - Fair' },
          { value: '3', label: '3 - Good' },
          { value: '4', label: '4 - Very Good' },
          { value: '5', label: '5 - Excellent' }
        ]},
      ],
    },
    {
      id: 'recommendation',
      title: 'Recommendation',
      fields: [
        { id: 'npsScore', type: 'select', label: 'How likely are you to recommend us to friends and family? (0-10)', required: true, options: [
          { value: '0', label: '0 - Not at all likely' },
          { value: '1', label: '1' },
          { value: '2', label: '2' },
          { value: '3', label: '3' },
          { value: '4', label: '4' },
          { value: '5', label: '5 - Neutral' },
          { value: '6', label: '6' },
          { value: '7', label: '7' },
          { value: '8', label: '8' },
          { value: '9', label: '9' },
          { value: '10', label: '10 - Extremely likely' }
        ]},
      ],
    },
    {
      id: 'feedback',
      title: 'Additional Feedback',
      fields: [
        { id: 'whatDidWell', type: 'textarea', label: 'What did we do well?', required: false },
        { id: 'improvements', type: 'textarea', label: 'How can we improve?', required: false },
        { id: 'additionalComments', type: 'textarea', label: 'Any other comments?', required: false },
        { id: 'mayContact', type: 'radio', label: 'May we contact you to follow up?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
      ],
    },
  ],
};

// 27. Referral Thank You / Source Tracking
export const referralThankYouTemplate: FormTemplate = {
  id: 'referral-source-tracking',
  title: 'Welcome - Tell Us About Yourself',
  description: 'Help us know how you found us',
  category: 'communication',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'patient-info',
      title: 'Patient Information',
      fields: [
        { id: 'patientName', type: 'text', label: 'Your Name', required: true },
        { id: 'appointmentDate', type: 'date', label: 'Appointment Date', required: false },
      ],
    },
    {
      id: 'referral-source',
      title: 'How Did You Hear About Us?',
      fields: [
        { id: 'referralSource', type: 'select', label: 'Primary source', required: true, options: [
          { value: 'friend-family', label: 'Friend or family member' },
          { value: 'coworker', label: 'Coworker' },
          { value: 'doctor-referral', label: 'Doctor referral' },
          { value: 'insurance-directory', label: 'Insurance provider directory' },
          { value: 'google-search', label: 'Google search' },
          { value: 'google-maps', label: 'Google Maps' },
          { value: 'facebook', label: 'Facebook' },
          { value: 'instagram', label: 'Instagram' },
          { value: 'yelp', label: 'Yelp' },
          { value: 'drive-by', label: 'Drove/walked by' },
          { value: 'returning', label: 'Returning patient' },
          { value: 'other', label: 'Other' }
        ]},
        { id: 'referrerName', type: 'text', label: 'If referred by someone, who can we thank?', required: false, placeholder: 'Enter name' },
        { id: 'otherSource', type: 'text', label: 'If other, please specify', required: false },
      ],
    },
    {
      id: 'why-chose-us',
      title: 'Why Did You Choose Us?',
      fields: [
        { id: 'reasonsForChoosing', type: 'checkbox', label: 'What factors influenced your decision?', required: false, options: [
          { value: 'location', label: 'Convenient location' },
          { value: 'hours', label: 'Office hours' },
          { value: 'insurance', label: 'Accepts my insurance' },
          { value: 'reputation', label: 'Good reputation/reviews' },
          { value: 'recommendation', label: 'Personal recommendation' },
          { value: 'doctor', label: 'Specific doctor' },
          { value: 'services', label: 'Services offered' },
          { value: 'eyewear', label: 'Eyewear selection' }
        ]},
      ],
    },
    {
      id: 'thank-you',
      title: 'Thank You!',
      fields: [
        { id: 'thankYouMessage', type: 'textarea', label: '', required: false, readOnly: true, defaultValue: `Thank you for choosing our practice! We appreciate your trust in us and look forward to providing you with excellent eye care.

If you were referred by a friend or family member, we'd love to send them a thank-you note. Please make sure to include their name above!` },
      ],
    },
  ],
};

export const communicationForms = [
  appointmentConfirmationTemplate,
  recallPreferencesTemplate,
  satisfactionSurveyTemplate,
  referralThankYouTemplate,
];
