/**
 * Intake & Registration Form Templates
 * Forms 1-6: New Patient Registration, Medical History, Ocular History,
 * Insurance Information, HIPAA Privacy Notice, Financial Policy
 */

import { FormTemplate } from '../../lib/types/forms';

// 1. New Patient Registration Form
export const newPatientRegistrationTemplate: FormTemplate = {
  id: 'new-patient-registration',
  title: 'New Patient Registration',
  description: 'Please complete this form with your personal information',
  category: 'intake',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'personal-info',
      title: 'Personal Information',
      description: 'Your basic contact information',
      fields: [
        { id: 'firstName', type: 'text', label: 'First Name', required: true, placeholder: 'Enter first name' },
        { id: 'middleName', type: 'text', label: 'Middle Name', required: false, placeholder: 'Enter middle name' },
        { id: 'lastName', type: 'text', label: 'Last Name', required: true, placeholder: 'Enter last name' },
        { id: 'preferredName', type: 'text', label: 'Preferred Name', required: false, placeholder: 'What should we call you?' },
        { id: 'dateOfBirth', type: 'date', label: 'Date of Birth', required: true },
        { id: 'gender', type: 'select', label: 'Gender', required: true, options: [
          { value: 'male', label: 'Male' },
          { value: 'female', label: 'Female' },
          { value: 'other', label: 'Other' },
          { value: 'prefer-not', label: 'Prefer not to say' }
        ]},
        { id: 'ssn', type: 'text', label: 'Last 4 of SSN', required: false, placeholder: 'XXXX', validation: { maxLength: 4 } },
      ],
    },
    {
      id: 'contact-info',
      title: 'Contact Information',
      description: 'How can we reach you?',
      fields: [
        { id: 'address', type: 'text', label: 'Street Address', required: true, placeholder: '123 Main St' },
        { id: 'address2', type: 'text', label: 'Apt/Suite/Unit', required: false, placeholder: 'Apt 4B' },
        { id: 'city', type: 'text', label: 'City', required: true },
        { id: 'state', type: 'text', label: 'State', required: true },
        { id: 'zipCode', type: 'text', label: 'ZIP Code', required: true, validation: { pattern: '^\\d{5}(-\\d{4})?$' } },
        { id: 'homePhone', type: 'phone', label: 'Home Phone', required: false },
        { id: 'mobilePhone', type: 'phone', label: 'Mobile Phone', required: true },
        { id: 'workPhone', type: 'phone', label: 'Work Phone', required: false },
        { id: 'email', type: 'email', label: 'Email Address', required: true },
        { id: 'preferredContact', type: 'select', label: 'Preferred Contact Method', required: true, options: [
          { value: 'mobile', label: 'Mobile Phone' },
          { value: 'home', label: 'Home Phone' },
          { value: 'work', label: 'Work Phone' },
          { value: 'email', label: 'Email' }
        ]},
      ],
    },
    {
      id: 'emergency-contact',
      title: 'Emergency Contact',
      description: 'Who should we contact in an emergency?',
      fields: [
        { id: 'emergencyName', type: 'text', label: 'Emergency Contact Name', required: true },
        { id: 'emergencyRelationship', type: 'text', label: 'Relationship', required: true },
        { id: 'emergencyPhone', type: 'phone', label: 'Emergency Contact Phone', required: true },
      ],
    },
    {
      id: 'employer-info',
      title: 'Employment Information',
      description: 'Optional employment details',
      fields: [
        { id: 'employmentStatus', type: 'select', label: 'Employment Status', required: false, options: [
          { value: 'employed', label: 'Employed' },
          { value: 'self-employed', label: 'Self-Employed' },
          { value: 'retired', label: 'Retired' },
          { value: 'student', label: 'Student' },
          { value: 'unemployed', label: 'Unemployed' }
        ]},
        { id: 'employerName', type: 'text', label: 'Employer Name', required: false },
        { id: 'occupation', type: 'text', label: 'Occupation', required: false },
      ],
    },
    {
      id: 'referral',
      title: 'How Did You Hear About Us?',
      fields: [
        { id: 'referralSource', type: 'select', label: 'Referral Source', required: false, options: [
          { value: 'friend-family', label: 'Friend/Family' },
          { value: 'doctor', label: 'Doctor Referral' },
          { value: 'insurance', label: 'Insurance Directory' },
          { value: 'google', label: 'Google Search' },
          { value: 'social-media', label: 'Social Media' },
          { value: 'walk-in', label: 'Walk-in' },
          { value: 'other', label: 'Other' }
        ]},
        { id: 'referralName', type: 'text', label: 'If referred by someone, who?', required: false },
      ],
    },
  ],
};

// 2. Patient Medical History Form
export const medicalHistoryTemplate: FormTemplate = {
  id: 'medical-history',
  title: 'Medical History',
  description: 'Please provide your complete medical history',
  category: 'intake',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'current-health',
      title: 'Current Health Status',
      fields: [
        { id: 'generalHealth', type: 'select', label: 'How would you rate your overall health?', required: true, options: [
          { value: 'excellent', label: 'Excellent' },
          { value: 'good', label: 'Good' },
          { value: 'fair', label: 'Fair' },
          { value: 'poor', label: 'Poor' }
        ]},
        { id: 'primaryPhysician', type: 'text', label: 'Primary Care Physician', required: false },
        { id: 'physicianPhone', type: 'phone', label: 'Physician Phone', required: false },
        { id: 'lastPhysicalDate', type: 'date', label: 'Date of Last Physical Exam', required: false },
      ],
    },
    {
      id: 'medical-conditions',
      title: 'Medical Conditions',
      description: 'Check all conditions that apply to you',
      fields: [
        { id: 'conditions', type: 'checkbox', label: 'Do you have any of the following conditions?', required: false, options: [
          { value: 'diabetes', label: 'Diabetes' },
          { value: 'hypertension', label: 'High Blood Pressure' },
          { value: 'heart-disease', label: 'Heart Disease' },
          { value: 'thyroid', label: 'Thyroid Disorder' },
          { value: 'arthritis', label: 'Arthritis' },
          { value: 'autoimmune', label: 'Autoimmune Disease' },
          { value: 'cancer', label: 'Cancer' },
          { value: 'hiv-aids', label: 'HIV/AIDS' },
          { value: 'hepatitis', label: 'Hepatitis' },
          { value: 'kidney', label: 'Kidney Disease' },
          { value: 'asthma', label: 'Asthma' },
          { value: 'migraines', label: 'Migraines' },
          { value: 'seizures', label: 'Seizures' },
          { value: 'mental-health', label: 'Mental Health Condition' },
        ]},
        { id: 'otherConditions', type: 'textarea', label: 'Other conditions not listed above', required: false },
      ],
    },
    {
      id: 'medications',
      title: 'Current Medications',
      fields: [
        { id: 'takingMedications', type: 'radio', label: 'Are you currently taking any medications?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'medicationList', type: 'textarea', label: 'List all medications (include dosage if known)', required: false, placeholder: 'e.g., Metformin 500mg twice daily' },
        { id: 'supplements', type: 'textarea', label: 'Vitamins/Supplements', required: false },
      ],
    },
    {
      id: 'allergies',
      title: 'Allergies',
      fields: [
        { id: 'hasAllergies', type: 'radio', label: 'Do you have any allergies?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'drugAllergies', type: 'textarea', label: 'Drug Allergies', required: false, placeholder: 'List any drug allergies and reactions' },
        { id: 'otherAllergies', type: 'textarea', label: 'Other Allergies (food, environmental)', required: false },
      ],
    },
    {
      id: 'surgeries',
      title: 'Surgical History',
      fields: [
        { id: 'hadSurgery', type: 'radio', label: 'Have you had any surgeries?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'surgeryList', type: 'textarea', label: 'List surgeries and approximate dates', required: false },
      ],
    },
    {
      id: 'lifestyle',
      title: 'Lifestyle',
      fields: [
        { id: 'smoker', type: 'radio', label: 'Do you smoke or use tobacco?', required: true, options: [
          { value: 'never', label: 'Never' },
          { value: 'former', label: 'Former smoker' },
          { value: 'current', label: 'Current smoker' }
        ]},
        { id: 'alcohol', type: 'radio', label: 'Do you consume alcohol?', required: true, options: [
          { value: 'never', label: 'Never' },
          { value: 'occasionally', label: 'Occasionally' },
          { value: 'regularly', label: 'Regularly' }
        ]},
      ],
    },
  ],
};

// 3. Ocular History Questionnaire
export const ocularHistoryTemplate: FormTemplate = {
  id: 'ocular-history',
  title: 'Ocular History',
  description: 'Information about your eye health history',
  category: 'intake',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'current-vision',
      title: 'Current Vision',
      fields: [
        { id: 'wearsCorrection', type: 'radio', label: 'Do you currently wear glasses or contact lenses?', required: true, options: [
          { value: 'glasses', label: 'Glasses only' },
          { value: 'contacts', label: 'Contact lenses only' },
          { value: 'both', label: 'Both glasses and contacts' },
          { value: 'neither', label: 'Neither' }
        ]},
        { id: 'lastEyeExam', type: 'date', label: 'Date of last eye exam', required: false },
        { id: 'reasonForVisit', type: 'textarea', label: 'Main reason for today\'s visit', required: true },
      ],
    },
    {
      id: 'vision-symptoms',
      title: 'Vision Symptoms',
      description: 'Check any symptoms you are currently experiencing',
      fields: [
        { id: 'symptoms', type: 'checkbox', label: 'Current symptoms', required: false, options: [
          { value: 'blurry-distance', label: 'Blurry distance vision' },
          { value: 'blurry-near', label: 'Blurry near vision' },
          { value: 'double-vision', label: 'Double vision' },
          { value: 'headaches', label: 'Headaches with visual tasks' },
          { value: 'eye-strain', label: 'Eye strain/fatigue' },
          { value: 'dry-eyes', label: 'Dry or irritated eyes' },
          { value: 'watery-eyes', label: 'Watery/tearing eyes' },
          { value: 'light-sensitivity', label: 'Light sensitivity' },
          { value: 'floaters', label: 'Floaters or spots' },
          { value: 'flashes', label: 'Flashing lights' },
          { value: 'halos', label: 'Halos around lights' },
          { value: 'redness', label: 'Eye redness' },
          { value: 'discharge', label: 'Eye discharge' },
          { value: 'pain', label: 'Eye pain' },
        ]},
      ],
    },
    {
      id: 'eye-conditions',
      title: 'Eye Conditions',
      description: 'Have you ever been diagnosed with any of the following?',
      fields: [
        { id: 'eyeConditions', type: 'checkbox', label: 'Eye conditions', required: false, options: [
          { value: 'glaucoma', label: 'Glaucoma' },
          { value: 'cataracts', label: 'Cataracts' },
          { value: 'macular-degeneration', label: 'Macular Degeneration' },
          { value: 'diabetic-retinopathy', label: 'Diabetic Retinopathy' },
          { value: 'amblyopia', label: 'Amblyopia (Lazy Eye)' },
          { value: 'strabismus', label: 'Strabismus (Crossed Eyes)' },
          { value: 'keratoconus', label: 'Keratoconus' },
          { value: 'dry-eye-syndrome', label: 'Dry Eye Syndrome' },
          { value: 'retinal-detachment', label: 'Retinal Detachment' },
        ]},
        { id: 'otherEyeConditions', type: 'textarea', label: 'Other eye conditions', required: false },
      ],
    },
    {
      id: 'eye-surgery',
      title: 'Eye Surgery History',
      fields: [
        { id: 'hadEyeSurgery', type: 'radio', label: 'Have you had any eye surgeries?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'eyeSurgeryList', type: 'textarea', label: 'List eye surgeries and dates', required: false },
      ],
    },
    {
      id: 'family-eye-history',
      title: 'Family Eye History',
      description: 'Do any blood relatives have the following conditions?',
      fields: [
        { id: 'familyEyeConditions', type: 'checkbox', label: 'Family eye conditions', required: false, options: [
          { value: 'glaucoma', label: 'Glaucoma' },
          { value: 'macular-degeneration', label: 'Macular Degeneration' },
          { value: 'cataracts', label: 'Cataracts (before age 60)' },
          { value: 'retinal-detachment', label: 'Retinal Detachment' },
          { value: 'blindness', label: 'Blindness' },
          { value: 'color-blindness', label: 'Color Blindness' },
        ]},
      ],
    },
  ],
};

// 4. Insurance Information Form
export const insuranceInfoTemplate: FormTemplate = {
  id: 'insurance-information',
  title: 'Insurance Information',
  description: 'Please provide your insurance details',
  category: 'intake',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'vision-insurance',
      title: 'Vision Insurance',
      fields: [
        { id: 'hasVisionInsurance', type: 'radio', label: 'Do you have vision insurance?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'visionInsuranceCarrier', type: 'text', label: 'Vision Insurance Carrier', required: false, placeholder: 'e.g., VSP, EyeMed' },
        { id: 'visionMemberId', type: 'text', label: 'Member ID', required: false },
        { id: 'visionGroupNumber', type: 'text', label: 'Group Number', required: false },
        { id: 'visionSubscriberName', type: 'text', label: 'Subscriber Name (if different)', required: false },
        { id: 'visionSubscriberDOB', type: 'date', label: 'Subscriber Date of Birth', required: false },
        { id: 'visionRelationship', type: 'select', label: 'Relationship to Subscriber', required: false, options: [
          { value: 'self', label: 'Self' },
          { value: 'spouse', label: 'Spouse' },
          { value: 'child', label: 'Child' },
          { value: 'other', label: 'Other' }
        ]},
      ],
    },
    {
      id: 'medical-insurance',
      title: 'Medical Insurance',
      description: 'Medical insurance may be used for medical eye conditions',
      fields: [
        { id: 'hasMedicalInsurance', type: 'radio', label: 'Do you have medical insurance?', required: true, options: [
          { value: 'yes', label: 'Yes' },
          { value: 'no', label: 'No' }
        ]},
        { id: 'medicalInsuranceCarrier', type: 'text', label: 'Medical Insurance Carrier', required: false },
        { id: 'medicalMemberId', type: 'text', label: 'Member ID', required: false },
        { id: 'medicalGroupNumber', type: 'text', label: 'Group Number', required: false },
      ],
    },
    {
      id: 'insurance-cards',
      title: 'Insurance Cards',
      description: 'Upload photos of your insurance cards (front and back)',
      fields: [
        { id: 'visionCardFront', type: 'file', label: 'Vision Insurance Card (Front)', required: false, validation: { allowedTypes: ['image/jpeg', 'image/png', 'application/pdf'], maxSize: 10485760 } },
        { id: 'visionCardBack', type: 'file', label: 'Vision Insurance Card (Back)', required: false, validation: { allowedTypes: ['image/jpeg', 'image/png', 'application/pdf'], maxSize: 10485760 } },
        { id: 'medicalCardFront', type: 'file', label: 'Medical Insurance Card (Front)', required: false, validation: { allowedTypes: ['image/jpeg', 'image/png', 'application/pdf'], maxSize: 10485760 } },
        { id: 'medicalCardBack', type: 'file', label: 'Medical Insurance Card (Back)', required: false, validation: { allowedTypes: ['image/jpeg', 'image/png', 'application/pdf'], maxSize: 10485760 } },
      ],
    },
  ],
};

// 5. HIPAA Privacy Notice
export const hipaaPrivacyTemplate: FormTemplate = {
  id: 'hipaa-privacy-notice',
  title: 'HIPAA Privacy Notice',
  description: 'Notice of Privacy Practices Acknowledgement',
  category: 'compliance',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'hipaa-notice',
      title: 'Notice of Privacy Practices',
      fields: [
        { id: 'hipaaText', type: 'textarea', label: 'HIPAA Notice', required: false, readOnly: true, defaultValue: `THIS NOTICE DESCRIBES HOW MEDICAL INFORMATION ABOUT YOU MAY BE USED AND DISCLOSED AND HOW YOU CAN GET ACCESS TO THIS INFORMATION. PLEASE REVIEW IT CAREFULLY.

We are required by law to maintain the privacy of your protected health information (PHI), to provide you with notice of our legal duties and privacy practices, and to notify you following a breach of unsecured PHI.

Your PHI may be used and disclosed for:
• Treatment - To provide, coordinate, or manage your healthcare
• Payment - To obtain payment for your healthcare services
• Healthcare Operations - To support our business activities

You have rights regarding your PHI:
• Request restrictions on uses and disclosures
• Request confidential communications
• Inspect and copy your PHI
• Request amendments to your PHI
• Receive an accounting of disclosures
• Receive a paper copy of this notice` },
      ],
    },
    {
      id: 'acknowledgement',
      title: 'Acknowledgement',
      fields: [
        { id: 'acknowledgeHipaa', type: 'checkbox', label: 'I acknowledge that I have received or been offered a copy of the Notice of Privacy Practices', required: true, options: [{ value: 'acknowledged', label: 'I acknowledge receipt' }] },
        { id: 'patientSignature', type: 'signature', label: 'Patient Signature', required: true },
        { id: 'signatureDate', type: 'date', label: 'Date', required: true },
      ],
    },
  ],
};

// 6. Financial Policy Agreement
export const financialPolicyTemplate: FormTemplate = {
  id: 'financial-policy',
  title: 'Financial Policy Agreement',
  description: 'Our office financial policies and your agreement',
  category: 'intake',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'policy-overview',
      title: 'Financial Policy',
      fields: [
        { id: 'policyText', type: 'textarea', label: 'Financial Policy', required: false, readOnly: true, defaultValue: `PAYMENT POLICY:
Payment is due at the time of service. We accept cash, checks, and major credit cards.

INSURANCE:
We will bill your insurance as a courtesy. You are responsible for any amounts not covered by insurance including deductibles, copays, and non-covered services.

VISION vs MEDICAL INSURANCE:
Routine vision exams are billed to vision insurance. Medical conditions (infections, injuries, dry eye, etc.) are billed to medical insurance.

CONTACT LENS PATIENTS:
Contact lens fitting fees are separate from the eye exam and are due at time of fitting.

CANCELLATION POLICY:
Please provide 24-hour notice for cancellations. Repeated no-shows may result in a missed appointment fee.

RETURNED CHECKS:
A $35 fee will be charged for returned checks.` },
      ],
    },
    {
      id: 'agreement',
      title: 'Agreement',
      fields: [
        { id: 'agreeToPolicy', type: 'checkbox', label: 'I have read and agree to the financial policy', required: true, options: [{ value: 'agreed', label: 'I agree to the financial policy' }] },
        { id: 'authorizeInsurance', type: 'checkbox', label: 'I authorize the release of information to my insurance company and assignment of benefits', required: true, options: [{ value: 'authorized', label: 'I authorize release and assignment' }] },
        { id: 'responsiblePartyName', type: 'text', label: 'Responsible Party Name', required: true },
        { id: 'responsiblePartySignature', type: 'signature', label: 'Signature', required: true },
        { id: 'agreementDate', type: 'date', label: 'Date', required: true },
      ],
    },
  ],
};

export const intakeForms = [
  newPatientRegistrationTemplate,
  medicalHistoryTemplate,
  ocularHistoryTemplate,
  insuranceInfoTemplate,
  hipaaPrivacyTemplate,
  financialPolicyTemplate,
];
