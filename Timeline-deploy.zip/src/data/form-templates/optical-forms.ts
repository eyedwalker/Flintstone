/**
 * Optical & Retail Form Templates
 * Forms 28-30: Eyewear Order Agreement, Special Order Consent, Frame Adjustment Waiver
 */

import { FormTemplate } from '../../lib/types/forms';

// 28. Eyewear Order Agreement
export const eyewearOrderTemplate: FormTemplate = {
  id: 'eyewear-order-agreement',
  title: 'Eyewear Order Agreement',
  description: 'Confirm your eyewear order details and policies',
  category: 'optical',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'patient-info',
      title: 'Patient Information',
      fields: [
        { id: 'patientName', type: 'text', label: 'Patient Name', required: true },
        { id: 'orderDate', type: 'date', label: 'Order Date', required: true },
        { id: 'phoneNumber', type: 'phone', label: 'Phone Number', required: true },
      ],
    },
    {
      id: 'order-details',
      title: 'Order Details',
      fields: [
        { id: 'frameBrand', type: 'text', label: 'Frame Brand/Model', required: true },
        { id: 'frameColor', type: 'text', label: 'Frame Color', required: true },
        { id: 'lensType', type: 'select', label: 'Lens Type', required: true, options: [
          { value: 'single-vision', label: 'Single Vision' },
          { value: 'bifocal', label: 'Bifocal' },
          { value: 'progressive', label: 'Progressive' },
          { value: 'computer', label: 'Computer/Office' },
          { value: 'reading', label: 'Reading Only' }
        ]},
        { id: 'lensOptions', type: 'checkbox', label: 'Lens Options', required: false, options: [
          { value: 'anti-reflective', label: 'Anti-reflective coating' },
          { value: 'photochromic', label: 'Photochromic (transitions)' },
          { value: 'blue-light', label: 'Blue light filter' },
          { value: 'polarized', label: 'Polarized' },
          { value: 'high-index', label: 'High-index (thinner)' },
          { value: 'scratch-resistant', label: 'Scratch-resistant coating' }
        ]},
        { id: 'tintColor', type: 'text', label: 'Tint/Color (if applicable)', required: false },
      ],
    },
    {
      id: 'pricing',
      title: 'Pricing',
      fields: [
        { id: 'framePrice', type: 'text', label: 'Frame Price', required: false },
        { id: 'lensPrice', type: 'text', label: 'Lens Price', required: false },
        { id: 'insuranceApplied', type: 'text', label: 'Insurance Applied', required: false },
        { id: 'patientResponsibility', type: 'text', label: 'Patient Responsibility', required: true },
        { id: 'depositPaid', type: 'text', label: 'Deposit Paid', required: false },
        { id: 'balanceDue', type: 'text', label: 'Balance Due at Pickup', required: false },
      ],
    },
    {
      id: 'policies',
      title: 'Policies',
      fields: [
        { id: 'policiesText', type: 'textarea', label: 'Order Policies', required: false, readOnly: true, defaultValue: `EYEWEAR ORDER POLICIES

ESTIMATED COMPLETION: Your eyewear will be ready in approximately 7-14 business days. We will contact you when ready for pickup.

PAYMENT: A deposit is required at the time of order. Balance is due upon pickup.

ADJUSTMENTS: We provide free adjustments for the life of your glasses purchased from our office.

WARRANTY: Manufacturer defects are covered for one year. Scratches and breakage are not covered under warranty.

ADAPTATION PERIOD: New prescriptions and progressive lenses may require an adaptation period of 1-2 weeks.

RETURNS/EXCHANGES:
• Prescription accuracy is guaranteed - we will remake lenses if needed
• Frame exchanges may be available within 30 days (restrictions apply)
• Custom orders and special tints are non-refundable
• Deposits are non-refundable after lenses are ordered` },
      ],
    },
    {
      id: 'agreement',
      title: 'Agreement',
      fields: [
        { id: 'verifiedOrder', type: 'checkbox', label: 'Order Verification', required: true, options: [
          { value: 'verified', label: 'I have verified my order details are correct' }
        ]},
        { id: 'understandPolicies', type: 'checkbox', label: 'Policy Agreement', required: true, options: [
          { value: 'understood', label: 'I understand and agree to the order policies' }
        ]},
        { id: 'patientSignature', type: 'signature', label: 'Patient Signature', required: true },
        { id: 'signatureDate', type: 'date', label: 'Date', required: true },
      ],
    },
  ],
};

// 29. Special Order Consent
export const specialOrderConsentTemplate: FormTemplate = {
  id: 'special-order-consent',
  title: 'Special Order Consent',
  description: 'Acknowledgement for non-returnable custom orders',
  category: 'optical',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'patient-info',
      title: 'Patient Information',
      fields: [
        { id: 'patientName', type: 'text', label: 'Patient Name', required: true },
        { id: 'orderDate', type: 'date', label: 'Order Date', required: true },
      ],
    },
    {
      id: 'special-order-details',
      title: 'Special Order Details',
      fields: [
        { id: 'orderType', type: 'checkbox', label: 'This order includes:', required: true, options: [
          { value: 'special-order-frame', label: 'Special order frame (not in stock)' },
          { value: 'custom-tint', label: 'Custom tint or color' },
          { value: 'high-rx', label: 'High prescription lenses' },
          { value: 'specialty-lens', label: 'Specialty lens design' },
          { value: 'custom-measurements', label: 'Custom measurements' },
          { value: 'engraving', label: 'Personalized engraving' },
          { value: 'other', label: 'Other special order' }
        ]},
        { id: 'orderDescription', type: 'textarea', label: 'Description of special order', required: true },
        { id: 'estimatedCost', type: 'text', label: 'Estimated Total Cost', required: true },
      ],
    },
    {
      id: 'acknowledgement',
      title: 'Acknowledgement',
      fields: [
        { id: 'specialOrderTerms', type: 'textarea', label: 'Special Order Terms', required: false, readOnly: true, defaultValue: `SPECIAL ORDER TERMS

By signing below, I acknowledge and agree to the following:

1. NON-REFUNDABLE: Special orders are custom made for me and cannot be returned or exchanged for a refund.

2. DEPOSIT REQUIRED: A 50% deposit is required to place this order. The deposit is non-refundable once the order is placed with the manufacturer.

3. FINAL SALE: This is a final sale. No returns, refunds, or exchanges will be accepted.

4. PRESCRIPTION GUARANTEE: The prescription accuracy is still guaranteed. If there is a prescription error, lenses will be remade at no charge.

5. ESTIMATED TIME: Special orders may take 2-4 weeks or longer depending on availability.

6. BALANCE DUE: The remaining balance is due upon pickup.` },
        { id: 'understandNonRefundable', type: 'checkbox', label: 'Non-Refundable Acknowledgement', required: true, options: [
          { value: 'understood', label: 'I understand this special order is NON-REFUNDABLE' }
        ]},
        { id: 'agreeToDeposit', type: 'checkbox', label: 'Deposit Agreement', required: true, options: [
          { value: 'agreed', label: 'I agree to pay the required deposit' }
        ]},
        { id: 'patientSignature', type: 'signature', label: 'Patient Signature', required: true },
        { id: 'signatureDate', type: 'date', label: 'Date', required: true },
      ],
    },
  ],
};

// 30. Frame Adjustment Waiver
export const frameAdjustmentWaiverTemplate: FormTemplate = {
  id: 'frame-adjustment-waiver',
  title: 'Outside Frame Adjustment Waiver',
  description: 'Liability waiver for adjustments on frames not purchased here',
  category: 'optical',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'patient-info',
      title: 'Patient Information',
      fields: [
        { id: 'patientName', type: 'text', label: 'Patient Name', required: true },
        { id: 'serviceDate', type: 'date', label: 'Date', required: true },
      ],
    },
    {
      id: 'frame-info',
      title: 'Frame Information',
      fields: [
        { id: 'frameBrand', type: 'text', label: 'Frame Brand/Model (if known)', required: false },
        { id: 'wherePurchased', type: 'text', label: 'Where were these glasses purchased?', required: true },
        { id: 'serviceRequested', type: 'checkbox', label: 'Service requested', required: true, options: [
          { value: 'adjustment', label: 'Frame adjustment/fitting' },
          { value: 'nose-pad', label: 'Nose pad replacement' },
          { value: 'screw', label: 'Screw tightening/replacement' },
          { value: 'temple-tip', label: 'Temple tip replacement' },
          { value: 'repair', label: 'Minor repair' }
        ]},
      ],
    },
    {
      id: 'waiver',
      title: 'Liability Waiver',
      fields: [
        { id: 'waiverText', type: 'textarea', label: 'Waiver Terms', required: false, readOnly: true, defaultValue: `OUTSIDE FRAME ADJUSTMENT/REPAIR WAIVER

I understand and acknowledge the following:

1. RISK OF DAMAGE: Frames not purchased from this office may be made of materials unfamiliar to our staff or may have existing weaknesses that could cause breakage during adjustment.

2. NO WARRANTY: This office cannot warrant or guarantee frames purchased elsewhere. Any damage that occurs during adjustment or repair is not covered.

3. RELEASE OF LIABILITY: I release this office and its staff from any liability for damage that may occur to my eyewear during the adjustment or repair process.

4. BEST EFFORTS: Our staff will use reasonable care, but some frames may break despite careful handling due to age, material fatigue, or manufacturing defects.

5. NO REPLACEMENT: If my frame breaks during adjustment, I understand this office is not responsible for replacing the frame.

SERVICE FEE: A nominal service fee may apply for outside frame adjustments.` },
        { id: 'understandRisks', type: 'checkbox', label: 'Risk Acknowledgement', required: true, options: [
          { value: 'understood', label: 'I understand there is a risk of damage to my eyewear' }
        ]},
        { id: 'releaseFromLiability', type: 'checkbox', label: 'Liability Release', required: true, options: [
          { value: 'released', label: 'I release this office from liability for any damage that may occur' }
        ]},
        { id: 'patientSignature', type: 'signature', label: 'Patient Signature', required: true },
        { id: 'signatureDate', type: 'date', label: 'Date', required: true },
      ],
    },
  ],
};

export const opticalForms = [
  eyewearOrderTemplate,
  specialOrderConsentTemplate,
  frameAdjustmentWaiverTemplate,
];
