/**
 * FTC Rx Acknowledgement Form Template
 * Required acknowledgement form for eyeglass prescription delivery per FTC Eyeglass Rule
 */

import { FormTemplate } from '../../lib/types/forms';

export const ftcRxAcknowledgementTemplate: FormTemplate = {
  id: 'ftc-rx-acknowledgement',
  title: 'Prescription Acknowledgement',
  description: 'Please acknowledge receipt of your eyeglass prescription as required by FTC regulations',
  category: 'compliance',
  isPublished: true,
  isArchived: false,
  isSystem: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: 'ftc-notice',
      title: 'FTC Notice',
      description: 'Important information about your prescription rights',
      fields: [
        {
          id: 'ftcNotice',
          type: 'textarea',
          label: 'Your Rights Under the FTC Eyeglass Rule',
          description: `Under federal law (the FTC Eyeglass Rule), you have the right to receive a copy of your eyeglass prescription immediately after your eye exam, at no extra cost. You are free to purchase eyewear from any seller you choose - whether from this practice or from another seller.`,
          required: false,
          readOnly: true,
        },
      ],
    },
    {
      id: 'patient-info',
      title: 'Patient Information',
      description: 'Confirm your information',
      fields: [
        {
          id: 'patientName',
          type: 'text',
          label: 'Patient Name',
          placeholder: 'Enter your full name',
          required: true,
        },
        {
          id: 'examDate',
          type: 'date',
          label: 'Exam Date',
          required: true,
        },
      ],
    },
    {
      id: 'acknowledgement',
      title: 'Acknowledgement',
      description: 'Please confirm receipt of your prescription',
      fields: [
        {
          id: 'acknowledgeReceipt',
          type: 'checkbox',
          label: 'I acknowledge that I have received a copy of my eyeglass prescription',
          required: true,
        },
        {
          id: 'understandRights',
          type: 'checkbox',
          label: 'I understand that I am free to purchase eyewear from this practice or from another seller of my choice',
          required: true,
        },
      ],
    },
    {
      id: 'signature',
      title: 'Signature',
      description: 'Please sign below to complete your acknowledgement',
      fields: [
        {
          id: 'signature',
          type: 'signature',
          label: 'Patient Signature',
          required: true,
        },
        {
          id: 'signatureDate',
          type: 'date',
          label: 'Date',
          required: true,
        },
      ],
    },
  ],
};
