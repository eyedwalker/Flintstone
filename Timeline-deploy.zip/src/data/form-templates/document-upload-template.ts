/**
 * Document Upload Form Template
 * System template for document upload requests
 */

import { v4 as uuidv4 } from 'uuid';
import { FormTemplate } from '../../lib/types/forms';

export const documentUploadFormTemplate: FormTemplate = {
  id: 'system-document-upload',
  title: 'Document Upload',
  description: 'Please upload the requested document',
  category: 'system',
  isPublished: true,
  isSystem: true,
  isArchived: false,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: uuidv4(),
      title: 'Document Information',
      description: 'This document has been requested by your healthcare provider',
      fields: [
        {
          id: 'documentType',
          type: 'text',
          label: 'Document Type',
          required: false,
          readOnly: true,
          systemField: 'documentType',
        },
        {
          id: 'documentDescription',
          type: 'textarea',
          label: 'Description',
          required: false,
          readOnly: true,
          systemField: 'documentDescription',
        },
      ],
    },
    {
      id: uuidv4(),
      title: 'Upload Document',
      description: 'Please upload the requested document in PDF, JPG, or PNG format',
      fields: [
        {
          id: 'documentFile',
          type: 'file',
          label: 'Document',
          placeholder: 'Select or drag file here',
          required: true,
          validation: {
            maxSize: 10485760, // 10MB
            allowedTypes: ['application/pdf', 'image/jpeg', 'image/png'],
          },
          systemField: 'documentFile',
        },
        {
          id: 'documentNotes',
          type: 'textarea',
          label: 'Notes (Optional)',
          placeholder: 'Add any notes about this document',
          required: false,
          systemField: 'documentNotes',
        },
      ],
    },
  ],
};

export const insuranceCardUploadTemplate: FormTemplate = {
  id: 'insurance-card-upload',
  title: 'Insurance Card Upload',
  description: 'Please upload images of your insurance card (front and back)',
  category: 'system',
  isPublished: true,
  isSystem: true,
  isArchived: false,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: uuidv4(),
      title: 'Insurance Card Images',
      description: 'Please upload clear photos of both sides of your insurance card',
      fields: [
        {
          id: 'insuranceCardFront',
          type: 'file',
          label: 'Front of Insurance Card',
          placeholder: 'Take a photo or select file',
          required: true,
          validation: {
            maxSize: 10485760,
            allowedTypes: ['image/jpeg', 'image/png', 'image/heic'],
          },
        },
        {
          id: 'insuranceCardBack',
          type: 'file',
          label: 'Back of Insurance Card',
          placeholder: 'Take a photo or select file',
          required: true,
          validation: {
            maxSize: 10485760,
            allowedTypes: ['image/jpeg', 'image/png', 'image/heic'],
          },
        },
      ],
    },
    {
      id: uuidv4(),
      title: 'Insurance Information',
      description: 'Please verify your insurance information',
      fields: [
        {
          id: 'insuranceProvider',
          type: 'text',
          label: 'Insurance Provider',
          placeholder: 'e.g., VSP, EyeMed, Blue Cross',
          required: false,
        },
        {
          id: 'memberId',
          type: 'text',
          label: 'Member ID',
          placeholder: 'Found on your insurance card',
          required: false,
        },
        {
          id: 'groupNumber',
          type: 'text',
          label: 'Group Number',
          placeholder: 'Found on your insurance card',
          required: false,
        },
      ],
    },
  ],
};

export const driversLicenseUploadTemplate: FormTemplate = {
  id: 'drivers-license-upload',
  title: "Driver's License Upload",
  description: "Please upload an image of your driver's license or state ID",
  category: 'system',
  isPublished: true,
  isSystem: true,
  isArchived: false,
  createdAt: new Date(),
  updatedAt: new Date(),
  sections: [
    {
      id: uuidv4(),
      title: 'ID Document',
      description: 'Please upload a clear photo of your ID',
      fields: [
        {
          id: 'idFront',
          type: 'file',
          label: 'Front of ID',
          placeholder: 'Take a photo or select file',
          required: true,
          validation: {
            maxSize: 10485760,
            allowedTypes: ['image/jpeg', 'image/png', 'image/heic'],
          },
        },
        {
          id: 'idBack',
          type: 'file',
          label: 'Back of ID (if applicable)',
          placeholder: 'Take a photo or select file',
          required: false,
          validation: {
            maxSize: 10485760,
            allowedTypes: ['image/jpeg', 'image/png', 'image/heic'],
          },
        },
      ],
    },
  ],
};
