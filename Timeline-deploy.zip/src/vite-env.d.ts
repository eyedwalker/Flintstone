/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_ANTHROPIC_API_KEY: string;
  readonly VITE_EYEFINITY_ACCESS_TOKEN: string;
  readonly VITE_EYEFINITY_BASE_URL: string;
  readonly VITE_DEFAULT_OFFICE_ID: string;
  readonly VITE_APP_URL: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
