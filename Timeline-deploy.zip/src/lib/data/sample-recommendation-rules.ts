/**
 * Sample Recommendation Rules
 * 
 * Pre-configured rules demonstrating various recommendation scenarios
 */

import { RecommendationRule } from '../types/recommendation';

export const SAMPLE_RECOMMENDATION_RULES: RecommendationRule[] = [
  // TEST RULE - Will show for ALL patients to demonstrate functionality
  {
    id: 'rule-test-welcome',
    name: 'Welcome Test Rule',
    description: 'Simple test rule that shows for all adult patients - demonstrates recommendation system',
    enabled: true,
    priority: 95,
    conditions: [
      { field: 'patient.age', operator: '>', value: 18 }
    ],
    recommendation: {
      type: 'content',
      title: '👋 Welcome {{patient.firstName}}!',
      description: 'This is a test recommendation to show you how the system works. You are {{patient.age}} years old and currently at: {{journey.currentStep}}. This demonstrates our personalized recommendation engine with mail merge capabilities.',
      mediaType: 'text',
      ctaText: 'Learn More',
      ctaUrl: '/recommendations-admin'
    },
    displayConfig: {
      locations: ['patient-details-sidebar', 'journey-step'],
      timing: 'immediate',
      maxDisplaysPerPatient: 10
    },
    createdAt: new Date('2025-01-01'),
    updatedAt: new Date('2025-01-01'),
    metrics: {
      impressions: 0,
      clicks: 0,
      conversions: 0,
      dismissals: 0,
      lastUpdated: new Date()
    },
    category: 'test',
    tags: ['test', 'demo', 'welcome']
  },

  // Fishing/Hunting Lens Package
  {
    id: 'rule-outdoor-sports-lens',
    name: 'Outdoor Sports Lens Package',
    description: 'Recommend specialized polarized lenses for fishing and hunting enthusiasts',
    enabled: true,
    priority: 85,
    conditions: [
      { field: 'patient.age', operator: '>=', value: 40 },
      { field: 'patient.age', operator: '<=', value: 65, logicalOperator: 'AND' },
      { field: 'patient.lifestyle.hobbies', operator: 'contains', value: 'fishing', logicalOperator: 'AND' }
    ],
    recommendation: {
      type: 'product',
      title: 'Enhance Your Outdoor Experience',
      description: 'Based on your interest in {{patient.lifestyle.hobbies[0]}}, we recommend our Outdoor Sports Lens Package with polarized technology to reduce glare and enhance visibility.',
      mediaType: 'image',
      mediaContent: '/assets/recommendations/outdoor-lens-package.jpg',
      ctaText: 'Learn More',
      ctaUrl: '/products/outdoor-lens?patient={{patient.id}}&age={{patient.age}}&ref=timeline'
    },
    displayConfig: {
      locations: ['journey-step', 'patient-details-sidebar', 'checkout-summary'],
      journeySteps: ['Dilation', 'Exam', 'Optician'],
      timing: 'immediate',
      maxDisplaysPerPatient: 3
    },
    createdAt: new Date('2025-01-01'),
    updatedAt: new Date('2025-01-01'),
    metrics: {
      impressions: 0,
      clicks: 0,
      conversions: 0,
      dismissals: 0,
      lastUpdated: new Date()
    },
    category: 'lifestyle-products',
    tags: ['lifestyle', 'outdoor', 'polarized-lenses']
  },

  // Annual Contact Lens Renewal
  {
    id: 'rule-contact-renewal',
    name: 'Annual Contact Lens Renewal',
    description: 'Remind patients to reorder contact lenses purchased last year',
    enabled: true,
    priority: 90,
    conditions: [
      { field: 'purchaseHistory[0].productType', operator: '==', value: 'contact-lenses' },
      { field: 'appointment.type', operator: 'in', value: ['Annual Exam', 'Contact Lens Exam'], logicalOperator: 'AND' }
    ],
    recommendation: {
      type: 'product',
      title: 'Time to Reorder Your Contacts',
      description: 'You purchased {{purchaseHistory[0].productName}} last year on {{purchaseHistory[0].purchaseDate|shortdate}}. Reorder today for uninterrupted wear!',
      mediaType: 'url',
      mediaContent: '/reorder/contacts?lastOrder={{purchaseHistory[0].id}}',
      ctaText: 'Reorder Now',
      ctaUrl: '/reorder/contacts?patient={{patient.id}}&previous={{purchaseHistory[0].id}}'
    },
    displayConfig: {
      locations: ['patient-details-header', 'checkout-summary', 'post-visit-summary'],
      timing: 'immediate',
      maxDisplaysPerPatient: 2,
      cooldownPeriod: 720 // 30 days
    },
    createdAt: new Date('2025-01-01'),
    updatedAt: new Date('2025-01-01'),
    metrics: {
      impressions: 0,
      clicks: 0,
      conversions: 0,
      dismissals: 0,
      lastUpdated: new Date()
    },
    category: 'product-renewal',
    tags: ['contacts', 'renewal', 'reorder']
  },

  // Bifocal/Progressive Introduction
  {
    id: 'rule-bifocal-intro',
    name: 'Bifocal/Progressive Introduction',
    description: 'Introduce progressive lenses to patients in presbyopia age range',
    enabled: true,
    priority: 75,
    conditions: [
      { field: 'patient.age', operator: '>=', value: 42 },
      { field: 'patient.age', operator: '<=', value: 50, logicalOperator: 'AND' }
    ],
    recommendation: {
      type: 'service',
      title: 'Considering Progressive Lenses?',
      description: 'Most patients your age benefit from progressive lenses for seamless near and far vision. Let\'s discuss your options with Dr. {{appointment.provider.name}}.',
      mediaType: 'text',
      ctaText: 'Learn About Progressives',
      ctaUrl: '/education/progressive-lenses?patient={{patient.id}}'
    },
    displayConfig: {
      locations: ['journey-step', 'patient-details-sidebar'],
      journeySteps: ['Check-In', 'Pre-Testing', 'Waiting for Doctor'],
      timing: 'immediate',
      maxDisplaysPerPatient: 2
    },
    createdAt: new Date('2025-01-01'),
    updatedAt: new Date('2025-01-01'),
    metrics: {
      impressions: 0,
      clicks: 0,
      conversions: 0,
      dismissals: 0,
      lastUpdated: new Date()
    },
    category: 'age-based-products',
    tags: ['progressive', 'bifocal', 'presbyopia']
  },

  // Blue Light Protection for Screen Users
  {
    id: 'rule-blue-light',
    name: 'Blue Light Protection',
    description: 'Recommend blue light filtering for high screen time users',
    enabled: true,
    priority: 70,
    conditions: [
      { field: 'patient.lifestyle.screenTime', operator: '>=', value: 6 }
    ],
    recommendation: {
      type: 'product',
      title: 'Protect Your Eyes from Screen Strain',
      description: 'With {{patient.lifestyle.screenTime}} hours of daily screen time, blue light filtering lenses can reduce eye fatigue and improve comfort.',
      mediaType: 'image',
      mediaContent: '/assets/recommendations/blue-light-lenses.jpg',
      ctaText: 'Explore Options',
      ctaUrl: '/products/blue-light-protection?patient={{patient.id}}'
    },
    displayConfig: {
      locations: ['journey-step', 'patient-details-sidebar', 'checkout-summary'],
      journeySteps: ['Optician', 'Checkout'],
      timing: 'immediate',
      maxDisplaysPerPatient: 2
    },
    createdAt: new Date('2025-01-01'),
    updatedAt: new Date('2025-01-01'),
    metrics: {
      impressions: 0,
      clicks: 0,
      conversions: 0,
      dismissals: 0,
      lastUpdated: new Date()
    },
    category: 'lifestyle-products',
    tags: ['blue-light', 'screen-protection', 'digital-devices']
  },

  // Sunglasses for Outdoor Enthusiasts
  {
    id: 'rule-sunglasses',
    name: 'Prescription Sunglasses',
    description: 'Recommend sunglasses to patients who spend time outdoors',
    enabled: true,
    priority: 80,
    conditions: [
      { field: 'patient.lifestyle.outdoorActivities', operator: 'exists', value: true }
    ],
    recommendation: {
      type: 'product',
      title: 'Don\'t Forget Sun Protection',
      description: 'Perfect vision outdoors requires UV protection. Add prescription sunglasses to complete your eyewear wardrobe.',
      mediaType: 'image',
      mediaContent: '/assets/recommendations/prescription-sunglasses.jpg',
      ctaText: 'Browse Sunglasses',
      ctaUrl: '/products/sunglasses?patient={{patient.id}}&style=active'
    },
    displayConfig: {
      locations: ['journey-step', 'checkout-summary'],
      journeySteps: ['Optician', 'Checkout'],
      timing: 'immediate',
      maxDisplaysPerPatient: 2
    },
    createdAt: new Date('2025-01-01'),
    updatedAt: new Date('2025-01-01'),
    metrics: {
      impressions: 0,
      clicks: 0,
      conversions: 0,
      dismissals: 0,
      lastUpdated: new Date()
    },
    category: 'lifestyle-products',
    tags: ['sunglasses', 'uv-protection', 'outdoor']
  },

  // Annual Exam Reminder
  {
    id: 'rule-annual-exam',
    name: 'Annual Exam Reminder',
    description: 'Encourage patients to schedule their next annual exam',
    enabled: true,
    priority: 65,
    conditions: [
      { field: 'appointment.type', operator: '==', value: 'Annual Exam' }
    ],
    recommendation: {
      type: 'action',
      title: 'Schedule Your Next Visit',
      description: 'Regular eye exams are essential for maintaining healthy vision. Book your next appointment before you leave!',
      mediaType: 'text',
      ctaText: 'Schedule Now',
      ctaUrl: '/appointments/schedule?patient={{patient.id}}&type=annual&provider={{appointment.provider.id}}'
    },
    displayConfig: {
      locations: ['post-visit-summary', 'checkout-summary'],
      timing: 'before-checkout',
      maxDisplaysPerPatient: 1
    },
    createdAt: new Date('2025-01-01'),
    updatedAt: new Date('2025-01-01'),
    metrics: {
      impressions: 0,
      clicks: 0,
      conversions: 0,
      dismissals: 0,
      lastUpdated: new Date()
    },
    category: 'scheduling',
    tags: ['annual-exam', 'scheduling', 'retention']
  },

  // Dry Eye Treatment
  {
    id: 'rule-dry-eye',
    name: 'Dry Eye Treatment Options',
    description: 'Recommend dry eye products to patients with symptoms',
    enabled: true,
    priority: 75,
    conditions: [
      { field: 'patient.lifestyle.dryEyeSymptoms', operator: '==', value: true }
    ],
    recommendation: {
      type: 'product',
      title: 'Relief for Dry, Irritated Eyes',
      description: 'We have several treatment options for dry eye symptoms, including preservative-free drops and specialized therapies.',
      mediaType: 'image',
      mediaContent: '/assets/recommendations/dry-eye-products.jpg',
      ctaText: 'Explore Treatments',
      ctaUrl: '/products/dry-eye?patient={{patient.id}}'
    },
    displayConfig: {
      locations: ['journey-step', 'patient-details-sidebar'],
      journeySteps: ['Pre-Testing', 'Exam', 'Optician'],
      timing: 'immediate',
      maxDisplaysPerPatient: 2
    },
    createdAt: new Date('2025-01-01'),
    updatedAt: new Date('2025-01-01'),
    metrics: {
      impressions: 0,
      clicks: 0,
      conversions: 0,
      dismissals: 0,
      lastUpdated: new Date()
    },
    category: 'medical-products',
    tags: ['dry-eye', 'eye-drops', 'therapy']
  },

  // Insurance Benefits Maximization
  {
    id: 'rule-insurance-benefits',
    name: 'Use Your Insurance Benefits',
    description: 'Remind patients with insurance to maximize their benefits',
    enabled: true,
    priority: 85,
    conditions: [
      { field: 'insuranceInfo.carrier', operator: 'exists', value: true }
    ],
    recommendation: {
      type: 'content',
      title: 'Maximize Your {{insuranceInfo.carrier}} Benefits',
      description: 'Your insurance plan may cover additional products or services. Let\'s review your benefits to ensure you\'re getting everything you\'re entitled to.',
      mediaType: 'text',
      ctaText: 'Review Benefits',
      ctaUrl: '/insurance/benefits?patient={{patient.id}}&carrier={{insuranceInfo.carrier}}'
    },
    displayConfig: {
      locations: ['journey-step', 'checkout-summary'],
      journeySteps: ['Check-In', 'Optician', 'Checkout'],
      timing: 'immediate',
      maxDisplaysPerPatient: 1
    },
    createdAt: new Date('2025-01-01'),
    updatedAt: new Date('2025-01-01'),
    metrics: {
      impressions: 0,
      clicks: 0,
      conversions: 0,
      dismissals: 0,
      lastUpdated: new Date()
    },
    category: 'insurance',
    tags: ['insurance', 'benefits', 'cost-savings']
  }
];

/**
 * Initialize sample rules in storage
 */
export function initializeSampleRules(): void {
  const stored = localStorage.getItem('recommendation_rules');
  
  // Only initialize if no rules exist
  if (!stored) {
    localStorage.setItem('recommendation_rules', JSON.stringify(SAMPLE_RECOMMENDATION_RULES));
    console.log('Initialized sample recommendation rules');
  }
}
