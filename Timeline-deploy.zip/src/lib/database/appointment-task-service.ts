/**
 * Appointment and Task Management Database Service
 * Handles real-time sync, task automation, and AI communication tracking
 */

export interface Appointment {
  id?: number;
  appointmentId: string; // External API ID
  patientId: string;
  patientLegacyId?: number;
  patientName: string;
  patientPhone?: string;
  patientEmail?: string;
  providerId?: string;
  providerName?: string;
  officeId?: string;
  appointmentDate: string; // YYYY-MM-DD
  appointmentTime: string; // HH:MM
  appointmentType?: string;
  durationMinutes?: number;
  status: 'scheduled' | 'confirmed' | 'checked_in' | 'in_progress' | 'completed' | 'cancelled' | 'no_show';
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
  lastSyncedAt?: string;
  externalData?: any; // Full API response
}

export interface AppointmentTask {
  id?: number;
  appointmentId: number;
  taskType: 'reminder_call' | 'confirmation_sms' | 'insurance_verification' | 'prep_instructions' | 'follow_up';
  taskStatus: 'pending' | 'in_progress' | 'completed' | 'failed' | 'skipped';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assignedTo?: string;
  dueDate?: string;
  completedAt?: string;
  attempts: number;
  maxAttempts: number;
  taskData?: any;
  resultData?: any;
  createdAt?: string;
  updatedAt?: string;
}

export interface CommunicationLog {
  id?: number;
  appointmentId?: number;
  patientId?: string;
  communicationType: 'sms' | 'email' | 'voice' | 'chat';
  direction: 'inbound' | 'outbound';
  content: string;
  aiProcessed: boolean;
  aiResponse?: string;
  aiIntent?: string;
  aiConfidence?: number;
  staffEscalated: boolean;
  phoneNumber?: string;
  emailAddress?: string;
  messageId?: string;
  createdAt?: string;
  processedAt?: string;
}

class AppointmentTaskServiceClass {
  // ==================== APPOINTMENTS ====================

  async syncAppointment(appointmentData: Partial<Appointment>, companyId: string): Promise<Appointment> {
    try {
      // Note: This is a transitional method. New code should use AppointmentAccessor directly.
      // This converts from the old localStorage format to database format.
      
      // Map old interface to database format
      const dbAppointment = {
        company_id: companyId,
        office_id: appointmentData.officeId || '',
        patient_id: appointmentData.patientId || '',
        provider_id: appointmentData.providerId,
        eyefinity_appointment_id: appointmentData.appointmentId,
        appointment_date: appointmentData.appointmentDate || new Date().toISOString().split('T')[0],
        duration_minutes: appointmentData.durationMinutes || 30,
        appointment_type: appointmentData.appointmentType || 'General',
        status: this.mapStatus(appointmentData.status || 'scheduled'),
        reason_for_visit: appointmentData.appointmentType, // Use appointmentType as reason
        notes: appointmentData.notes,
        reminder_sent: false,
        settings: appointmentData.externalData || {}
      };

      // Check if appointment already exists by Eyefinity ID
      const { appointmentAccessor } = await import('../accessors/AppointmentAccessor');
      
      if (appointmentData.appointmentId) {
        const existing = await appointmentAccessor.getByEyefinityId(appointmentData.appointmentId, companyId);
        
        if (existing.success && existing.data) {
          // Update existing
          const oldStatus = existing.data.status;
          const updateResult = await appointmentAccessor.update(existing.data.id, dbAppointment);
          
          if (!updateResult.success) {
            throw new Error(updateResult.error);
          }
          
          // Log status change if different (skip for now - logStatusChange expects numeric ID)
          // TODO: Update logStatusChange to handle UUID IDs
          // if (oldStatus !== dbAppointment.status) {
          //   await this.logStatusChange(existing.data.id, oldStatus, dbAppointment.status, 'system');
          // }
          
          return this.mapToOldFormat(updateResult.data);
        }
      }
      
      // Create new
      const createResult = await appointmentAccessor.create(dbAppointment);
      
      if (!createResult.success || !createResult.data) {
        throw new Error(createResult.error || 'Failed to create appointment');
      }
      
      // Create automated tasks for new appointments (skip for now - expects numeric ID)
      // TODO: Update createAutomatedTasks to handle UUID IDs
      // await this.createAutomatedTasks(createResult.data.id);
      
      return this.mapToOldFormat(createResult.data);
    } catch (error) {
      console.error('[AppointmentTaskService] Sync error:', error);
      throw error;
    }
  }

  // Map old status to new status format
  private mapStatus(oldStatus: string): 'scheduled' | 'confirmed' | 'checked_in' | 'in_progress' | 'completed' | 'cancelled' | 'no_show' {
    const statusMap: Record<string, any> = {
      'scheduled': 'scheduled',
      'confirmed': 'confirmed',
      'checked_in': 'checked_in',
      'in_progress': 'in_progress',
      'completed': 'completed',
      'cancelled': 'cancelled',
      'no_show': 'no_show'
    };
    return statusMap[oldStatus] || 'scheduled';
  }

  // Map database appointment back to old format for compatibility
  private mapToOldFormat(dbAppt: any): Appointment {
    return {
      id: Date.now(), // Legacy numeric ID
      appointmentId: dbAppt.eyefinity_appointment_id || dbAppt.id,
      patientId: dbAppt.patient_id,
      patientLegacyId: undefined,
      patientName: '', // TODO: Join with patient data
      patientPhone: '',
      patientEmail: '',
      providerId: dbAppt.provider_id,
      providerName: '',
      officeId: dbAppt.office_id,
      appointmentDate: dbAppt.appointment_date,
      appointmentTime: '', // TODO: Parse from appointment_date if it includes time
      appointmentType: dbAppt.appointment_type,
      durationMinutes: dbAppt.duration_minutes,
      status: dbAppt.status,
      notes: dbAppt.notes,
      createdAt: dbAppt.created_at,
      updatedAt: dbAppt.updated_at,
      lastSyncedAt: dbAppt.updated_at,
      externalData: dbAppt.settings
    };
  }

  async getAppointment(appointmentId: string): Promise<Appointment | null> {
    const appointments = this.getStoredAppointments();
    return appointments.find(apt => apt.appointmentId === appointmentId) || null;
  }

  async getAppointmentsByDate(date: string): Promise<Appointment[]> {
    const appointments = this.getStoredAppointments();
    return appointments.filter(apt => apt.appointmentDate === date);
  }

  async getAppointmentsByPatient(patientId: string): Promise<Appointment[]> {
    const appointments = this.getStoredAppointments();
    return appointments
      .filter(apt => apt.patientId === patientId)
      .sort((a, b) => new Date(b.appointmentDate).getTime() - new Date(a.appointmentDate).getTime());
  }

  // ==================== TASKS ====================

  async createTask(task: Omit<AppointmentTask, 'id' | 'createdAt' | 'updatedAt'>): Promise<AppointmentTask> {
    const tasks = this.getStoredTasks();
    const now = new Date().toISOString();
    
    const newTask: AppointmentTask = {
      ...task,
      id: Date.now() + Math.random(),
      createdAt: now,
      updatedAt: now
    };

    tasks.push(newTask);
    this.saveTasks(tasks);
    return newTask;
  }

  async updateTaskStatus(
    taskId: number, 
    status: AppointmentTask['taskStatus'], 
    resultData?: any
  ): Promise<void> {
    const tasks = this.getStoredTasks();
    const taskIndex = tasks.findIndex(t => t.id === taskId);
    
    if (taskIndex >= 0) {
      tasks[taskIndex].taskStatus = status;
      tasks[taskIndex].updatedAt = new Date().toISOString();
      tasks[taskIndex].attempts = (tasks[taskIndex].attempts || 0) + 1;
      
      if (status === 'completed') {
        tasks[taskIndex].completedAt = new Date().toISOString();
      }
      
      if (resultData) {
        tasks[taskIndex].resultData = resultData;
      }

      this.saveTasks(tasks);
    }
  }

  async getPendingTasks(limit: number = 50): Promise<AppointmentTask[]> {
    const tasks = this.getStoredTasks();
    return tasks
      .filter(t => t.taskStatus === 'pending' && t.attempts < t.maxAttempts)
      .sort((a, b) => {
        // Sort by priority and due date
        const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
        const aPriority = priorityOrder[a.priority] || 2;
        const bPriority = priorityOrder[b.priority] || 2;
        
        if (aPriority !== bPriority) return bPriority - aPriority;
        
        const aDate = a.dueDate ? new Date(a.dueDate).getTime() : Date.now();
        const bDate = b.dueDate ? new Date(b.dueDate).getTime() : Date.now();
        return aDate - bDate;
      })
      .slice(0, limit);
  }

  async getTasksForAppointment(appointmentId: number): Promise<AppointmentTask[]> {
    const tasks = this.getStoredTasks();
    return tasks.filter(t => t.appointmentId === appointmentId);
  }

  // ==================== COMMUNICATION LOG ====================

  async logCommunication(log: Omit<CommunicationLog, 'id' | 'createdAt'>): Promise<CommunicationLog> {
    const logs = this.getStoredCommunicationLogs();
    const now = new Date().toISOString();
    
    const newLog: CommunicationLog = {
      ...log,
      id: Date.now() + Math.random(),
      createdAt: now
    };

    logs.push(newLog);
    this.saveCommunicationLogs(logs);
    return newLog;
  }

  async updateCommunicationAI(
    logId: number, 
    aiResponse: string, 
    intent?: string, 
    confidence?: number
  ): Promise<void> {
    const logs = this.getStoredCommunicationLogs();
    const logIndex = logs.findIndex(l => l.id === logId);
    
    if (logIndex >= 0) {
      logs[logIndex].aiProcessed = true;
      logs[logIndex].aiResponse = aiResponse;
      logs[logIndex].aiIntent = intent;
      logs[logIndex].aiConfidence = confidence;
      logs[logIndex].processedAt = new Date().toISOString();
      
      this.saveCommunicationLogs(logs);
    }
  }

  async getCommunicationHistory(patientId: string, limit: number = 20): Promise<CommunicationLog[]> {
    const logs = this.getStoredCommunicationLogs();
    return logs
      .filter(l => l.patientId === patientId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
      .slice(0, limit);
  }

  // ==================== AUTOMATION ====================

  async createAutomatedTasks(appointmentId: number): Promise<void> {
    const appointment = this.getStoredAppointments().find(a => a.id === appointmentId);
    if (!appointment) return;

    const appointmentDateTime = new Date(`${appointment.appointmentDate}T${appointment.appointmentTime}`);
    
    // Create standard automated tasks
    const tasks: Omit<AppointmentTask, 'id' | 'createdAt' | 'updatedAt'>[] = [
      {
        appointmentId,
        taskType: 'reminder_call',
        taskStatus: 'pending',
        priority: 'medium',
        assignedTo: 'AI',
        dueDate: new Date(appointmentDateTime.getTime() - 48 * 60 * 60 * 1000).toISOString(), // 48 hours before
        attempts: 0,
        maxAttempts: 2,
        taskData: {
          messageTemplate: `Hi ${appointment.patientName}, this is a reminder that you have an appointment with ${appointment.providerName} on ${appointment.appointmentDate} at ${appointment.appointmentTime}. Please call us if you need to reschedule.`,
          phone: appointment.patientPhone,
          communicationType: 'voice'
        }
      },
      {
        appointmentId,
        taskType: 'confirmation_sms',
        taskStatus: 'pending',
        priority: 'medium',
        assignedTo: 'AI',
        dueDate: new Date(appointmentDateTime.getTime() - 24 * 60 * 60 * 1000).toISOString(), // 24 hours before
        attempts: 0,
        maxAttempts: 2,
        taskData: {
          messageTemplate: `Hi ${appointment.patientName}! Reminder: Eye exam tomorrow ${appointment.appointmentDate} at ${appointment.appointmentTime} with ${appointment.providerName}. Reply YES to confirm or RESCHEDULE if needed.`,
          phone: appointment.patientPhone,
          communicationType: 'sms'
        }
      },
      {
        appointmentId,
        taskType: 'prep_instructions',
        taskStatus: 'pending',
        priority: 'low',
        assignedTo: 'AI',
        dueDate: new Date(appointmentDateTime.getTime() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours before
        attempts: 0,
        maxAttempts: 1,
        taskData: {
          messageTemplate: `Good ${appointmentDateTime.getHours() < 12 ? 'morning' : 'afternoon'} ${appointment.patientName}! Your appointment is today at ${appointment.appointmentTime}. Please bring your insurance card, current glasses/contacts, and arrive 15 minutes early.`,
          phone: appointment.patientPhone,
          communicationType: 'sms'
        }
      }
    ];

    for (const task of tasks) {
      await this.createTask(task);
    }
  }

  async logStatusChange(
    appointmentId: number, 
    oldStatus: string, 
    newStatus: string, 
    changedBy: string, 
    reason?: string
  ): Promise<void> {
    // In a real implementation, this would log to appointment_status_history table
    console.log(`[AppointmentTaskService] Status change: ${appointmentId} ${oldStatus} → ${newStatus} by ${changedBy}`);
  }

  // ==================== STORAGE (Replace with real database) ====================

  private getStoredAppointments(): Appointment[] {
    if (typeof localStorage !== 'undefined') {
      const stored = localStorage.getItem('appointments');
      return stored ? JSON.parse(stored) : [];
    }
    return [];
  }

  private saveAppointments(appointments: Appointment[]): void {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('appointments', JSON.stringify(appointments));
    }
  }

  private getStoredTasks(): AppointmentTask[] {
    if (typeof localStorage !== 'undefined') {
      const stored = localStorage.getItem('appointment_tasks');
      return stored ? JSON.parse(stored) : [];
    }
    return [];
  }

  private saveTasks(tasks: AppointmentTask[]): void {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('appointment_tasks', JSON.stringify(tasks));
    }
  }

  private getStoredCommunicationLogs(): CommunicationLog[] {
    if (typeof localStorage !== 'undefined') {
      const stored = localStorage.getItem('communication_log');
      return stored ? JSON.parse(stored) : [];
    }
    return [];
  }

  private saveCommunicationLogs(logs: CommunicationLog[]): void {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('communication_log', JSON.stringify(logs));
    }
  }
}

export const AppointmentTaskService = new AppointmentTaskServiceClass();
