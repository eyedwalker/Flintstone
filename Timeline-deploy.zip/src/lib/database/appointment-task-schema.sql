-- Appointment and Task Management Database Schema
-- Supports real-time sync, status tracking, and AI communication integration

-- Appointments table (synced from external API)
CREATE TABLE appointments (
  id SERIAL PRIMARY KEY,
  appointment_id VARCHAR(255) UNIQUE NOT NULL, -- External API ID
  patient_id VARCHAR(255) NOT NULL,
  patient_legacy_id INTEGER,
  patient_name VARCHAR(255) NOT NULL,
  patient_phone VARCHAR(20),
  patient_email VARCHAR(255),
  provider_id VARCHAR(255),
  provider_name VARCHAR(255),
  office_id VARCHAR(255),
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  appointment_type VARCHAR(100),
  duration_minutes INTEGER DEFAULT 30,
  status VARCHAR(50) DEFAULT 'scheduled', -- scheduled, confirmed, checked_in, in_progress, completed, cancelled, no_show
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_synced_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  external_data JSONB -- Store full API response for reference
);

-- Tasks related to appointments (workflow management)
CREATE TABLE appointment_tasks (
  id SERIAL PRIMARY KEY,
  appointment_id INTEGER REFERENCES appointments(id) ON DELETE CASCADE,
  task_type VARCHAR(100) NOT NULL, -- reminder_call, confirmation_sms, insurance_verification, prep_instructions, follow_up
  task_status VARCHAR(50) DEFAULT 'pending', -- pending, in_progress, completed, failed, skipped
  priority VARCHAR(20) DEFAULT 'medium', -- low, medium, high, urgent
  assigned_to VARCHAR(255), -- staff member or 'AI'
  due_date TIMESTAMP,
  completed_at TIMESTAMP,
  attempts INTEGER DEFAULT 0,
  max_attempts INTEGER DEFAULT 3,
  task_data JSONB, -- Store task-specific data (phone numbers, message templates, etc.)
  result_data JSONB, -- Store task execution results
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Communication log (AI interactions)
CREATE TABLE communication_log (
  id SERIAL PRIMARY KEY,
  appointment_id INTEGER REFERENCES appointments(id) ON DELETE SET NULL,
  patient_id VARCHAR(255),
  communication_type VARCHAR(50) NOT NULL, -- sms, email, voice, chat
  direction VARCHAR(20) NOT NULL, -- inbound, outbound
  content TEXT NOT NULL,
  ai_processed BOOLEAN DEFAULT FALSE,
  ai_response TEXT,
  ai_intent VARCHAR(100), -- appointment_scheduling, rescheduling, cancellation, question, emergency
  ai_confidence DECIMAL(3,2), -- 0.00 to 1.00
  staff_escalated BOOLEAN DEFAULT FALSE,
  phone_number VARCHAR(20),
  email_address VARCHAR(255),
  message_id VARCHAR(255), -- Twilio SID, email message ID, etc.
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  processed_at TIMESTAMP
);

-- Task templates for automation
CREATE TABLE task_templates (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  task_type VARCHAR(100) NOT NULL,
  trigger_condition VARCHAR(255) NOT NULL, -- appointment_created, 24_hours_before, day_of_appointment, etc.
  priority VARCHAR(20) DEFAULT 'medium',
  auto_assign_to VARCHAR(255) DEFAULT 'AI',
  template_data JSONB NOT NULL, -- Message templates, timing rules, etc.
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Appointment status history (audit trail)
CREATE TABLE appointment_status_history (
  id SERIAL PRIMARY KEY,
  appointment_id INTEGER REFERENCES appointments(id) ON DELETE CASCADE,
  old_status VARCHAR(50),
  new_status VARCHAR(50) NOT NULL,
  changed_by VARCHAR(255), -- user ID or 'system' or 'AI'
  change_reason VARCHAR(255),
  notes TEXT,
  changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX idx_appointments_patient_id ON appointments(patient_id);
CREATE INDEX idx_appointments_date ON appointments(appointment_date);
CREATE INDEX idx_appointments_status ON appointments(status);
CREATE INDEX idx_appointments_last_synced ON appointments(last_synced_at);
CREATE INDEX idx_appointment_tasks_status ON appointment_tasks(task_status);
CREATE INDEX idx_appointment_tasks_due_date ON appointment_tasks(due_date);
CREATE INDEX idx_communication_log_patient_id ON communication_log(patient_id);
CREATE INDEX idx_communication_log_ai_processed ON communication_log(ai_processed);
CREATE INDEX idx_communication_log_created_at ON communication_log(created_at);

-- Sample task templates
INSERT INTO task_templates (name, task_type, trigger_condition, template_data) VALUES 
('48hr Appointment Reminder', 'reminder_call', '48_hours_before', 
 '{"message_template": "Hi {patient_name}, this is a reminder that you have an appointment with {provider_name} on {appointment_date} at {appointment_time}. Please call us at {office_phone} if you need to reschedule.", "voice_enabled": true, "sms_enabled": true}'),
 
('24hr Confirmation SMS', 'confirmation_sms', '24_hours_before',
 '{"message_template": "Hi {patient_name}! Reminder: Eye exam tomorrow {appointment_date} at {appointment_time} with {provider_name}. Reply YES to confirm or RESCHEDULE if needed.", "auto_confirm": true}'),
 
('Day-of Prep Instructions', 'prep_instructions', 'day_of_appointment',
 '{"message_template": "Good morning {patient_name}! Your appointment is today at {appointment_time}. Please bring your insurance card, current glasses/contacts, and arrive 15 minutes early. See you soon!", "send_time": "08:00"}'),
 
('Post-Visit Follow-up', 'follow_up', '24_hours_after',
 '{"message_template": "Hi {patient_name}, thank you for visiting us yesterday. How are you feeling? Any questions about your treatment plan? We are here to help!", "delay_hours": 24}');

-- Views for common queries
CREATE VIEW active_appointments AS
SELECT a.*, 
       COUNT(at.id) as pending_tasks,
       MAX(cl.created_at) as last_communication
FROM appointments a
LEFT JOIN appointment_tasks at ON a.id = at.appointment_id AND at.task_status = 'pending'
LEFT JOIN communication_log cl ON a.id = cl.appointment_id
WHERE a.status IN ('scheduled', 'confirmed', 'checked_in')
  AND a.appointment_date >= CURRENT_DATE
GROUP BY a.id;

CREATE VIEW overdue_tasks AS
SELECT at.*, a.patient_name, a.appointment_date, a.appointment_time
FROM appointment_tasks at
JOIN appointments a ON at.appointment_id = a.id
WHERE at.task_status = 'pending' 
  AND at.due_date < NOW()
  AND at.attempts < at.max_attempts;

CREATE VIEW ai_escalations AS
SELECT cl.*, a.patient_name, a.appointment_date
FROM communication_log cl
LEFT JOIN appointments a ON cl.appointment_id = a.id
WHERE cl.ai_processed = TRUE 
  AND (cl.ai_confidence < 0.7 OR cl.staff_escalated = TRUE)
  AND cl.created_at > NOW() - INTERVAL '24 hours';
