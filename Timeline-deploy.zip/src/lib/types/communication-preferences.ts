/**
 * Communication Preferences and AI Communication Configuration Types
 */

export type CommunicationChannel = 'voice' | 'sms' | 'email';

export interface PatientCommunicationPreferences {
  patientId: string;
  preferredChannel: CommunicationChannel;
  fallbackChannel: CommunicationChannel;
  doNotContactBefore: string; // "08:00" 24hr format
  doNotContactAfter: string;  // "20:00" 24hr format
  optOutSMS: boolean;
  optOutEmail: boolean;
  optOutVoice: boolean;
  language: string;
  timezone: string;
  updatedAt: Date;
}

export interface AICommunicationTrigger {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  triggerType: 
    | 'appointment_reminder'
    | 'forms_incomplete'
    | 'insurance_verification'
    | 'journey_step_started'
    | 'journey_step_overdue'
    | 'post_visit_followup'
    | 'recall_reminder'
    | 'custom';
  
  // When to trigger
  timing: {
    daysBeforeAppointment?: number;
    hoursBeforeAppointment?: number;
    delayMinutes?: number; // Delay after event
    repeatAfterHours?: number; // Repeat if no response
    maxAttempts: number;
  };
  
  // Channel selection rules
  channelRules: ChannelSelectionRule[];
  
  // Message configuration
  messageConfig: {
    templateId?: string;
    useAIGenerated: boolean;
    aiPromptHint?: string;
    includeCallToAction: boolean;
  };
  
  // Conditions
  conditions?: {
    journeyPhase?: string[];
    appointmentTypes?: string[];
    patientTags?: string[];
  };
}

export interface ChannelSelectionRule {
  id: string;
  priority: number; // Lower = higher priority
  condition: 'patient_preference' | 'time_of_day' | 'urgency' | 'fallback';
  
  // For time_of_day
  timeRange?: {
    start: string; // "08:00"
    end: string;   // "17:00"
  };
  
  // For urgency
  urgencyLevel?: 'low' | 'medium' | 'high' | 'critical';
  
  // Channel to use if condition matches
  useChannel: CommunicationChannel;
  
  // Skip if patient opted out
  respectOptOut: boolean;
}

export interface AICommunicationSettings {
  officeId: string;
  
  // Global settings
  globalEnabled: boolean;
  requireApprovalForOutbound: boolean;
  
  // Quiet hours (no automated communications)
  quietHours: {
    enabled: boolean;
    start: string; // "21:00"
    end: string;   // "08:00"
    timezone: string;
  };
  
  // Default channel selection
  defaultChannelOrder: CommunicationChannel[];
  
  // Triggers
  triggers: AICommunicationTrigger[];
  
  // Escalation settings
  escalation: {
    escalateOnNoResponse: boolean;
    noResponseHours: number;
    escalateOnNegativeSentiment: boolean;
    escalateKeywords: string[];
    notifyStaffVia: ('email' | 'sms' | 'in_app')[];
    alertRecipients: EscalationRecipient[];
    autoEscalateAfterMinutes: number;
  };
}

export interface EscalationRecipient {
  id: string;
  name: string;
  phone: string;
  email?: string;
  role: 'manager' | 'supervisor' | 'on-call' | 'staff';
  notifyVia: ('sms' | 'voice' | 'email')[];
  priorityThreshold: 'low' | 'medium' | 'high' | 'urgent';
}

export interface AICommunicationSettings {
  officeId: string;
  
  // Global settings
  globalEnabled: boolean;
  requireApprovalForOutbound: boolean;
  
  // Quiet hours (no automated communications)
  quietHours: {
    enabled: boolean;
    start: string; // "21:00"
    end: string;   // "08:00"
    timezone: string;
  };
  
  // Default channel selection
  defaultChannelOrder: CommunicationChannel[];
  
  // Triggers
  triggers: AICommunicationTrigger[];
  
  // Escalation settings
  escalation: {
    escalateOnNoResponse: boolean;
    noResponseHours: number;
    escalateOnNegativeSentiment: boolean;
    escalateKeywords: string[];
    notifyStaffVia: ('email' | 'sms' | 'in_app')[];
    alertRecipients: EscalationRecipient[];
    autoEscalateAfterMinutes: number;
  };
  
  // Voice-specific settings
  voiceSettings: {
    useAIVoice: boolean;
    voicePersonaId?: string;
    maxCallDurationSeconds: number;
    enableVoicemail: boolean;
    voicemailTranscription: boolean;
    callRecording: boolean;
    aiConversationMode: boolean;
    twilioVoice: string;
    officeTransferNumber: string;
    maxConversationTurns: number;
  };
  
  // SMS-specific settings
  smsSettings: {
    useAIReplies: boolean;
    maxMessageLength: number;
    includeOptOutInstructions: boolean;
    optOutKeywords: string[];
  };
  
  // Email-specific settings  
  emailSettings: {
    useAIReplies: boolean;
    fromName: string;
    fromEmail: string;
    replyToEmail: string;
    includeUnsubscribeLink: boolean;
    trackOpens: boolean;
    trackClicks: boolean;
  };
  
  updatedAt: Date;
  updatedBy?: string;
}

export const DEFAULT_TRIGGERS: AICommunicationTrigger[] = [
  {
    id: 'appt_reminder_24h',
    name: '24-Hour Appointment Reminder',
    description: 'Send reminder 24 hours before appointment',
    enabled: true,
    triggerType: 'appointment_reminder',
    timing: {
      hoursBeforeAppointment: 24,
      maxAttempts: 1,
    },
    channelRules: [
      { id: 'r1', priority: 1, condition: 'patient_preference', useChannel: 'sms', respectOptOut: true },
      { id: 'r2', priority: 2, condition: 'fallback', useChannel: 'email', respectOptOut: true },
    ],
    messageConfig: {
      templateId: 'appt_reminder_sms',
      useAIGenerated: false,
      includeCallToAction: true,
    },
  },
  {
    id: 'forms_incomplete',
    name: 'Incomplete Forms Reminder',
    description: 'Remind patient to complete pre-visit forms',
    enabled: true,
    triggerType: 'forms_incomplete',
    timing: {
      daysBeforeAppointment: 3,
      repeatAfterHours: 24,
      maxAttempts: 2,
    },
    channelRules: [
      { id: 'r1', priority: 1, condition: 'patient_preference', useChannel: 'sms', respectOptOut: true },
      { id: 'r2', priority: 2, condition: 'fallback', useChannel: 'email', respectOptOut: true },
    ],
    messageConfig: {
      templateId: 'forms_ready_sms',
      useAIGenerated: false,
      includeCallToAction: true,
    },
  },
  {
    id: 'insurance_verify',
    name: 'Insurance Verification Request',
    description: 'Request insurance verification before appointment',
    enabled: true,
    triggerType: 'insurance_verification',
    timing: {
      daysBeforeAppointment: 5,
      repeatAfterHours: 48,
      maxAttempts: 2,
    },
    channelRules: [
      { id: 'r1', priority: 1, condition: 'patient_preference', useChannel: 'sms', respectOptOut: true },
      { id: 'r2', priority: 2, condition: 'fallback', useChannel: 'voice', respectOptOut: true },
    ],
    messageConfig: {
      templateId: 'insurance_verify_sms',
      useAIGenerated: false,
      includeCallToAction: true,
    },
  },
  {
    id: 'journey_step_started',
    name: 'Journey Step Notification',
    description: 'Notify patient when a journey step requires their action',
    enabled: true,
    triggerType: 'journey_step_started',
    timing: {
      delayMinutes: 5,
      maxAttempts: 1,
    },
    channelRules: [
      { id: 'r1', priority: 1, condition: 'patient_preference', useChannel: 'sms', respectOptOut: true },
    ],
    messageConfig: {
      useAIGenerated: true,
      aiPromptHint: 'Inform patient about the current step in their visit journey',
      includeCallToAction: true,
    },
  },
  {
    id: 'post_visit_followup',
    name: 'Post-Visit Follow-up',
    description: 'Send follow-up after visit completion',
    enabled: true,
    triggerType: 'post_visit_followup',
    timing: {
      delayMinutes: 60, // 1 hour after checkout
      maxAttempts: 1,
    },
    channelRules: [
      { id: 'r1', priority: 1, condition: 'patient_preference', useChannel: 'email', respectOptOut: true },
      { id: 'r2', priority: 2, condition: 'fallback', useChannel: 'sms', respectOptOut: true },
    ],
    messageConfig: {
      templateId: 'follow_up_sms',
      useAIGenerated: false,
      includeCallToAction: false,
    },
  },
];

export const DEFAULT_AI_COMMUNICATION_SETTINGS: Omit<AICommunicationSettings, 'officeId'> = {
  globalEnabled: true,
  requireApprovalForOutbound: false,
  
  quietHours: {
    enabled: true,
    start: '21:00',
    end: '08:00',
    timezone: 'America/Chicago',
  },
  
  defaultChannelOrder: ['sms', 'email', 'voice'],
  
  triggers: DEFAULT_TRIGGERS,
  
  escalation: {
    escalateOnNoResponse: true,
    noResponseHours: 24,
    escalateOnNegativeSentiment: true,
    escalateKeywords: ['urgent', 'emergency', 'pain', 'bleeding', 'can\'t see', 'vision loss'],
    notifyStaffVia: ['in_app'],
    alertRecipients: [],
    autoEscalateAfterMinutes: 15,
  },
  
  voiceSettings: {
    useAIVoice: true,
    maxCallDurationSeconds: 120,
    enableVoicemail: true,
    voicemailTranscription: true,
    callRecording: true,
    aiConversationMode: true,
    twilioVoice: 'Polly.Joanna',
    officeTransferNumber: '',
    maxConversationTurns: 10,
  },
  
  smsSettings: {
    useAIReplies: true,
    maxMessageLength: 160,
    includeOptOutInstructions: true,
    optOutKeywords: ['STOP', 'UNSUBSCRIBE', 'CANCEL', 'QUIT'],
  },
  
  emailSettings: {
    useAIReplies: true,
    fromName: 'Eye Care Office',
    fromEmail: 'noreply@eyecare.com',
    replyToEmail: 'support@eyecare.com',
    includeUnsubscribeLink: true,
    trackOpens: true,
    trackClicks: true,
  },
  
  updatedAt: new Date(),
};
