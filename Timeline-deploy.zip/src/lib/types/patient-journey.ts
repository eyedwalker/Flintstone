/**
 * Patient Journey Types
 * Defines types for tracking patient progress through pre-visit, in-office, and post-visit phases
 */

// Step types for different phases of the patient journey
export type JourneyStepType = 'pre-visit' | 'in-office' | 'post-visit';

// Communication types for journey steps
export type CommunicationType = 'sms' | 'email' | 'form' | 'phone' | 'in-person' | 'none';

export type JourneyStepStatus = 'pending' | 'in-progress' | 'completed' | 'skipped' | 'cancelled';

export type JourneyPhase = 'pre-visit' | 'in-office' | 'post-visit' | 'completed';

export type JourneyPriority = 'normal' | 'urgent' | 'vip';

export interface RoomDetails {
  id: string;
  name: string;
  waitTimeThresholds: {
    warning: number;
    critical: number;
  };
}

export interface CommunicationRecord {
  id: string;
  templateId?: string;
  templateName?: string;
  type: CommunicationType;
  sentAt: Date;
  status: 'sent' | 'delivered' | 'failed' | 'read';
  messageId?: string;
  content?: string;
}

export interface FormRecord {
  id: string;
  formId: string;
  formName: string;
  sentAt: Date;
  status: 'sent' | 'viewed' | 'completed' | 'expired';
  submissionId?: string;
  accessLink?: string;
}

export interface DocumentRequest {
  id: string;
  type: 'insurance-card' | 'drivers-license' | 'other';
  description?: string;
  requestedAt: Date;
  status: 'requested' | 'received' | 'expired';
  documentUrl?: string;
}

export interface JourneyStep {
  id: string;
  title: string;
  description?: string;
  status: JourneyStepStatus;
  startTime?: Date;
  endTime?: Date;
  duration?: number; // Duration in minutes
  staffId?: string;
  staffName?: string;
  staffRole?: string;
  room?: string;
  roomDetails?: RoomDetails;
  notes?: string;
  reasonCodes?: string[];
  
  // Fields for journey step phase
  stepType: JourneyStepType;
  scheduledTime?: Date; // When this step should happen (used for scheduling)
  
  // Communication fields
  communicationType?: CommunicationType;
  templateId?: string; // Reference to a message template
  responseRequired: boolean;
  responseReceived?: boolean;
  responseData?: Record<string, any>; // Structured data from responses
  
  // Enhanced tracking
  communications?: CommunicationRecord[];
  forms?: FormRecord[];
  documentRequests?: DocumentRequest[];
}

export interface PatientJourney {
  id: string;
  patientId: string;
  patientName: string;
  taskId?: string;
  appointmentId?: string;
  status: 'active' | 'completed' | 'cancelled';
  steps: JourneyStep[];
  currentStepId?: string;
  checkInTime: Date;
  checkOutTime?: Date;
  totalDuration?: number; // Total time in minutes
  providerId?: string;
  providerName?: string;
  reasonForVisit?: string;
  priority: JourneyPriority;
  createdAt: Date;
  updatedAt: Date;
  
  // Legacy/External IDs for integration with external systems (Encompass, etc.)
  legacyPatientId?: string; // Patient ID from external system
  legacyAppointmentId?: string; // Appointment ID from external system
  
  // New fields for pre-visit and post-visit functionality
  journeyPhase: JourneyPhase;
  scheduledAppointmentDate?: Date; // For timing pre/post visit steps
  preVisitStartDate?: Date;
  inOfficeStartDate?: Date; // Same as checkInTime
  postVisitStartDate?: Date;
  
  // Calculated fields (added at runtime)
  waitTime?: number;
  progressPercentage?: number;
}

// Helper type for office view
export interface OfficePatientJourney extends PatientJourney {
  waitTime?: number; // Wait time in minutes
  progressPercentage?: number; // Progress through journey (0-100)
}

// Journey action types
export type JourneyActionType = 
  | 'start-step'
  | 'complete-step'
  | 'skip-step'
  | 'cancel-step'
  | 'add-note'
  | 'change-room'
  | 'schedule-step'
  | 'transition-phase'
  | 'send-template'
  | 'process-response'
  | 'send-form'
  | 'process-form'
  | 'request-document'
  | 'process-document';

export interface JourneyAction {
  type: JourneyActionType;
  stepId: string;
  patientJourneyId: string;
  taskId?: string;
  data?: Record<string, any>;
  performedBy?: string;
}

// Type for creating a new patient journey
export interface CreateJourneyData {
  patientId: string;
  patientName: string;
  taskId?: string;
  appointmentId?: string;
  providerId?: string;
  providerName?: string;
  reasonForVisit?: string;
  priority?: JourneyPriority;
  scheduledAppointmentDate?: Date;
  startPhase?: 'pre-visit' | 'in-office';
  createdBy?: string;
  legacyPatientId?: string;
  legacyAppointmentId?: string;
  appointmentContext?: {
    appointmentType?: string;
    isNewPatient?: boolean;
    officeId?: string;
    providerId?: string;
    hasInsurance?: boolean;
  };
}

// Schema for scheduled tasks related to patient journeys
export interface ScheduledJourneyTask {
  id: string;
  patientJourneyId: string;
  stepId: string;
  scheduledTime: Date;
  completed: boolean;
  completedTime?: Date;
  taskType: 'send-communication' | 'process-response' | 'update-journey';
  templateId?: string;
  taskData?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

// Journey step template configuration
export interface JourneyStepTemplate {
  id: string;
  title: string;
  description?: string;
  stepType: JourneyStepType;
  order: number;
  
  // Form configuration for this step
  formConfig?: {
    enabled: boolean;
    templateIds: string[];        // Form templates to send
    autoSend: boolean;            // Auto-send when step starts
    required: boolean;            // Must complete forms to proceed
  };
  
  // Communication configuration
  communicationConfig?: {
    enabled: boolean;
    methods: ('email' | 'sms' | 'both')[];
    templateId?: string;          // Message template to use
    timing?: {
      daysBeforeAppointment?: number;
      daysAfterAppointment?: number;
    };
    autoSend: boolean;
  };
  
  // Room configuration for in-office steps
  roomConfig?: {
    roomTypes: string[];          // Allowed room types for this step
    defaultRoomType?: string;     // Default room type
    requireRoom: boolean;         // Must assign room
    expectedDuration?: number;    // Expected minutes in room
  };
  
  // Timing configuration
  timing?: {
    expectedDuration?: number;    // Expected duration in minutes
    warningThreshold?: number;    // Minutes before showing warning
    criticalThreshold?: number;   // Minutes before showing critical alert
  };
  
  isActive: boolean;
  isRequired: boolean;            // Cannot skip this step
}

// Journey path template (pre-visit, in-office, post-visit paths)
export interface JourneyPathTemplate {
  id: string;
  name: string;
  description?: string;
  phase: JourneyPhase;
  steps: JourneyStepTemplate[];
  
  // Conditions for using this path
  conditions?: {
    appointmentTypes?: string[];  // Only for these appointment types
    patientTypes?: ('new' | 'existing')[];
    insuranceTypes?: string[];
  };
  
  isDefault: boolean;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Complete journey template combining all paths
export interface JourneyTemplate {
  id: string;
  name: string;
  description?: string;
  preVisitPath?: JourneyPathTemplate;
  inOfficePath?: JourneyPathTemplate;
  postVisitPath?: JourneyPathTemplate;
  
  // Associated appointment types
  appointmentTypes: string[];
  
  isDefault: boolean;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}
