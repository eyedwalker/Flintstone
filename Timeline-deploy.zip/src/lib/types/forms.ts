/**
 * Forms System Types
 * Defines types for dynamic form templates, submissions, and responses
 */

// Form field types
export const formFieldTypes = [
  'text',
  'textarea',
  'number',
  'select',
  'radio',
  'checkbox',
  'date',
  'email',
  'phone',
  'signature',
  'file',
  'idDocument'
] as const;

export type FormFieldType = typeof formFieldTypes[number];

// Status of form submissions
export const formSubmissionStatuses = [
  'sent',
  'viewed',
  'in_progress',
  'completed',
  'expired'
] as const;

export type FormSubmissionStatus = typeof formSubmissionStatuses[number];

// Form field option (for select, radio, checkbox)
export interface FormFieldOption {
  value: string;
  label: string;
}

// Field validation rules
export interface FormFieldValidation {
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  min?: number;
  max?: number;
  maxSize?: number; // For file uploads (bytes)
  allowedTypes?: string[]; // For file uploads (MIME types)
}

// Form field definition
export interface FormField {
  id: string;
  type: FormFieldType;
  label: string;
  description?: string;
  placeholder?: string;
  required: boolean;
  options?: FormFieldOption[];
  validation?: FormFieldValidation;
  defaultValue?: any;
  readOnly?: boolean;
  systemField?: string; // For system-populated fields
}

// Form section
export interface FormSection {
  id: string;
  title: string;
  description?: string;
  fields: FormField[];
}

// Office branding for forms
export interface FormBranding {
  logoUrl?: string;
  primaryColor?: string;
  secondaryColor?: string;
  headerText?: string;
  footerText?: string;
}

// Form template
export interface FormTemplate {
  id: string;
  title: string;
  description?: string;
  category: string;
  sections: FormSection[];
  isPublished: boolean;
  isArchived: boolean;
  isSystem: boolean;
  branding?: FormBranding;
  createdAt: Date;
  updatedAt: Date;
}

// Verification settings
export interface VerificationSettings {
  method: 'dob' | 'phone' | 'email' | 'zipLastName' | 'none';
  required: boolean;
  verified: boolean;
  attempts: number;
  lastAttempt?: Date;
  lockedUntil?: Date;
  bypassVerification: boolean;
}

// File attachment
export interface FileAttachment {
  fieldId: string;
  fileName: string;
  fileSize: number;
  fileType: string;
  filePath: string;
  uploadedAt: Date;
  dataUrl?: string; // For local storage
}

// Form submission
export interface FormSubmission {
  submissionId: string;
  patientId: string;
  patientName?: string;
  taskId?: string;
  appointmentId?: string;
  templateId: string;
  formTitle: string;
  formType: 'standard' | 'document-upload';
  status: FormSubmissionStatus;
  responses: Record<string, any>;
  verificationSettings?: VerificationSettings;
  documentType?: string;
  documentDescription?: string;
  fileAttachments: FileAttachment[];
  expiresAt?: Date;
  completedAt?: Date;
  accessToken: string;
  accessLink: string;
  viewCount: number;
  lastViewed?: Date;
  journeyId?: string;
  journeyStepId?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Form responses type
export type FormResponses = Record<string, string | string[] | boolean | number | Date | null>;

// Prefill options for forms
export interface FormPrefillOptions {
  enabled: boolean;
  autoAcceptAcknowledgements: boolean;
  autoSignWithName: boolean;
  signatureText?: string;
  prefillDate: boolean;
}

// Create submission data
export interface CreateFormSubmissionData {
  patientId: string;
  patientName?: string;
  patientEmail?: string;
  patientPhone?: string;
  patientData?: Record<string, any>;
  taskId?: string;
  appointmentId?: string;
  templateId: string;
  formType?: 'standard' | 'document-upload';
  documentType?: string;
  documentDescription?: string;
  journeyId?: string;
  journeyStepId?: string;
  prefilledResponses?: Record<string, any>;
  prefillOptions?: FormPrefillOptions;
  verificationMethod?: VerificationSettings['method'];
}

// Form access result
export interface FormAccessResult {
  submission: FormSubmission;
  template: FormTemplate;
}

// Form validation result
export interface FormValidationResult {
  valid: boolean;
  formSubmission?: {
    submissionId: string;
    formTitle: string;
    templateId: string;
    status: FormSubmissionStatus;
    formType: string;
    documentType?: string;
    patientName?: string;
    expiresAt?: Date;
    verification: {
      required: boolean;
      verified: boolean;
      method: string;
      attempts: number;
    };
  };
  error?: string;
  expired?: boolean;
  completed?: boolean;
}

// Delivery result
export interface FormDeliveryResult {
  emailSent: boolean;
  smsSent: boolean;
  emailResult?: { success: boolean; messageId?: string; error?: string };
  smsResult?: { success: boolean; messageId?: string; error?: string };
}
