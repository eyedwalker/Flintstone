/**
 * Office Rooms Types
 * Defines room configuration and tracking for in-office patient journeys
 */

// Room types for eye care practice
export type RoomType = 
  | 'waiting'
  | 'pre-testing'
  | 'exam-room'
  | 'dilation'
  | 'optical'
  | 'contact-lens'
  | 'doctor-office'
  | 'dispensary'
  | 'checkout'
  | 'other';

// Room status
export type RoomStatus = 
  | 'available'
  | 'occupied'
  | 'cleaning'
  | 'maintenance'
  | 'reserved';

// Room definition
export interface OfficeRoom {
  id: string;
  officeId: string;
  name: string;
  shortName?: string;         // For display on board (e.g., "E1", "PT2")
  type: RoomType;
  capacity: number;           // Usually 1 for exam rooms
  equipment?: string[];       // Equipment in the room
  isActive: boolean;
  displayOrder: number;       // Order to show on board
  color?: string;             // Color coding for board
  defaultDurationMinutes?: number;  // Expected time in this room
  
  // Current status
  status: RoomStatus;
  currentPatientId?: string;
  currentPatientName?: string;
  currentJourneyId?: string;
  occupiedSince?: Date;
  expectedEndTime?: Date;
}

// Room occupancy record for tracking
export interface RoomOccupancy {
  id: string;
  roomId: string;
  roomName: string;
  patientId: string;
  patientName: string;
  journeyId: string;
  stepId: string;
  stepTitle: string;
  
  // Timing
  startTime: Date;
  endTime?: Date;
  durationMinutes?: number;
  expectedDurationMinutes?: number;
  isOvertime?: boolean;
  
  // Staff
  staffId?: string;
  staffName?: string;
}

// Office room configuration
export interface OfficeRoomConfig {
  officeId: string;
  officeName: string;
  rooms: OfficeRoom[];
  
  // Display settings
  showWaitingArea: boolean;
  showCheckoutArea: boolean;
  alertThresholdMinutes: number;  // When to show warning for long room times
  
  // Defaults
  defaultExamDuration: number;
  defaultPreTestDuration: number;
  defaultDilationWaitTime: number;
  
  updatedAt: Date;
  updatedBy?: string;
}

// Room assignment for journey step
export interface RoomAssignment {
  roomId: string;
  roomName: string;
  assignedAt: Date;
  assignedBy?: string;
  expectedDuration?: number;
}

// Default room configurations for different office sizes
export const DEFAULT_ROOM_CONFIGS: Record<string, Omit<OfficeRoom, 'id' | 'officeId'>[]> = {
  small: [
    { name: 'Waiting Area', shortName: 'WA', type: 'waiting', capacity: 10, isActive: true, displayOrder: 1, color: '#E5E7EB', status: 'available' },
    { name: 'Pre-Test 1', shortName: 'PT1', type: 'pre-testing', capacity: 1, isActive: true, displayOrder: 2, color: '#DBEAFE', defaultDurationMinutes: 15, status: 'available' },
    { name: 'Exam Room 1', shortName: 'E1', type: 'exam-room', capacity: 1, isActive: true, displayOrder: 3, color: '#D1FAE5', defaultDurationMinutes: 20, status: 'available' },
    { name: 'Exam Room 2', shortName: 'E2', type: 'exam-room', capacity: 1, isActive: true, displayOrder: 4, color: '#D1FAE5', defaultDurationMinutes: 20, status: 'available' },
    { name: 'Dilation Area', shortName: 'DIL', type: 'dilation', capacity: 4, isActive: true, displayOrder: 5, color: '#FEF3C7', defaultDurationMinutes: 20, status: 'available' },
    { name: 'Optical', shortName: 'OPT', type: 'optical', capacity: 3, isActive: true, displayOrder: 6, color: '#FCE7F3', defaultDurationMinutes: 30, status: 'available' },
    { name: 'Checkout', shortName: 'CO', type: 'checkout', capacity: 2, isActive: true, displayOrder: 7, color: '#E5E7EB', status: 'available' },
  ],
  medium: [
    { name: 'Waiting Area', shortName: 'WA', type: 'waiting', capacity: 20, isActive: true, displayOrder: 1, color: '#E5E7EB', status: 'available' },
    { name: 'Pre-Test 1', shortName: 'PT1', type: 'pre-testing', capacity: 1, isActive: true, displayOrder: 2, color: '#DBEAFE', defaultDurationMinutes: 15, status: 'available' },
    { name: 'Pre-Test 2', shortName: 'PT2', type: 'pre-testing', capacity: 1, isActive: true, displayOrder: 3, color: '#DBEAFE', defaultDurationMinutes: 15, status: 'available' },
    { name: 'Exam Room 1', shortName: 'E1', type: 'exam-room', capacity: 1, isActive: true, displayOrder: 4, color: '#D1FAE5', defaultDurationMinutes: 20, status: 'available' },
    { name: 'Exam Room 2', shortName: 'E2', type: 'exam-room', capacity: 1, isActive: true, displayOrder: 5, color: '#D1FAE5', defaultDurationMinutes: 20, status: 'available' },
    { name: 'Exam Room 3', shortName: 'E3', type: 'exam-room', capacity: 1, isActive: true, displayOrder: 6, color: '#D1FAE5', defaultDurationMinutes: 20, status: 'available' },
    { name: 'Contact Lens Room', shortName: 'CL', type: 'contact-lens', capacity: 2, isActive: true, displayOrder: 7, color: '#E0E7FF', defaultDurationMinutes: 30, status: 'available' },
    { name: 'Dilation Area', shortName: 'DIL', type: 'dilation', capacity: 6, isActive: true, displayOrder: 8, color: '#FEF3C7', defaultDurationMinutes: 20, status: 'available' },
    { name: 'Optical', shortName: 'OPT', type: 'optical', capacity: 4, isActive: true, displayOrder: 9, color: '#FCE7F3', defaultDurationMinutes: 30, status: 'available' },
    { name: 'Checkout', shortName: 'CO', type: 'checkout', capacity: 2, isActive: true, displayOrder: 10, color: '#E5E7EB', status: 'available' },
  ],
  large: [
    { name: 'Waiting Area', shortName: 'WA', type: 'waiting', capacity: 30, isActive: true, displayOrder: 1, color: '#E5E7EB', status: 'available' },
    { name: 'Pre-Test 1', shortName: 'PT1', type: 'pre-testing', capacity: 1, isActive: true, displayOrder: 2, color: '#DBEAFE', defaultDurationMinutes: 15, status: 'available' },
    { name: 'Pre-Test 2', shortName: 'PT2', type: 'pre-testing', capacity: 1, isActive: true, displayOrder: 3, color: '#DBEAFE', defaultDurationMinutes: 15, status: 'available' },
    { name: 'Pre-Test 3', shortName: 'PT3', type: 'pre-testing', capacity: 1, isActive: true, displayOrder: 4, color: '#DBEAFE', defaultDurationMinutes: 15, status: 'available' },
    { name: 'Exam Room 1', shortName: 'E1', type: 'exam-room', capacity: 1, isActive: true, displayOrder: 5, color: '#D1FAE5', defaultDurationMinutes: 20, status: 'available' },
    { name: 'Exam Room 2', shortName: 'E2', type: 'exam-room', capacity: 1, isActive: true, displayOrder: 6, color: '#D1FAE5', defaultDurationMinutes: 20, status: 'available' },
    { name: 'Exam Room 3', shortName: 'E3', type: 'exam-room', capacity: 1, isActive: true, displayOrder: 7, color: '#D1FAE5', defaultDurationMinutes: 20, status: 'available' },
    { name: 'Exam Room 4', shortName: 'E4', type: 'exam-room', capacity: 1, isActive: true, displayOrder: 8, color: '#D1FAE5', defaultDurationMinutes: 20, status: 'available' },
    { name: 'Contact Lens 1', shortName: 'CL1', type: 'contact-lens', capacity: 1, isActive: true, displayOrder: 9, color: '#E0E7FF', defaultDurationMinutes: 30, status: 'available' },
    { name: 'Contact Lens 2', shortName: 'CL2', type: 'contact-lens', capacity: 1, isActive: true, displayOrder: 10, color: '#E0E7FF', defaultDurationMinutes: 30, status: 'available' },
    { name: 'Dilation Area', shortName: 'DIL', type: 'dilation', capacity: 8, isActive: true, displayOrder: 11, color: '#FEF3C7', defaultDurationMinutes: 20, status: 'available' },
    { name: 'Optical 1', shortName: 'O1', type: 'optical', capacity: 2, isActive: true, displayOrder: 12, color: '#FCE7F3', defaultDurationMinutes: 30, status: 'available' },
    { name: 'Optical 2', shortName: 'O2', type: 'optical', capacity: 2, isActive: true, displayOrder: 13, color: '#FCE7F3', defaultDurationMinutes: 30, status: 'available' },
    { name: 'Doctor Office', shortName: 'DO', type: 'doctor-office', capacity: 2, isActive: true, displayOrder: 14, color: '#FEE2E2', defaultDurationMinutes: 15, status: 'available' },
    { name: 'Checkout 1', shortName: 'CO1', type: 'checkout', capacity: 1, isActive: true, displayOrder: 15, color: '#E5E7EB', status: 'available' },
    { name: 'Checkout 2', shortName: 'CO2', type: 'checkout', capacity: 1, isActive: true, displayOrder: 16, color: '#E5E7EB', status: 'available' },
  ],
};

// Room type display configuration
export const ROOM_TYPE_CONFIG: Record<RoomType, { label: string; icon: string; color: string }> = {
  waiting: { label: 'Waiting Area', icon: 'Users', color: '#6B7280' },
  'pre-testing': { label: 'Pre-Testing', icon: 'Activity', color: '#3B82F6' },
  'exam-room': { label: 'Exam Room', icon: 'Eye', color: '#10B981' },
  dilation: { label: 'Dilation', icon: 'Clock', color: '#F59E0B' },
  optical: { label: 'Optical', icon: 'Glasses', color: '#EC4899' },
  'contact-lens': { label: 'Contact Lens', icon: 'Circle', color: '#6366F1' },
  'doctor-office': { label: 'Doctor Office', icon: 'User', color: '#EF4444' },
  dispensary: { label: 'Dispensary', icon: 'Package', color: '#8B5CF6' },
  checkout: { label: 'Checkout', icon: 'CreditCard', color: '#6B7280' },
  other: { label: 'Other', icon: 'MoreHorizontal', color: '#9CA3AF' },
};
