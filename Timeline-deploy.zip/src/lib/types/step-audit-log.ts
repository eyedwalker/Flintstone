/**
 * Step Audit Log Types
 * Comprehensive logging for journey step transitions, wait times, and performance tracking
 */

export type StepEventType = 
  | 'step-started'
  | 'step-completed'
  | 'step-skipped'
  | 'step-failed'
  | 'step-paused'
  | 'step-resumed'
  | 'patient-waiting'
  | 'room-assigned'
  | 'room-cleared'
  | 'encompass-launched'
  | 'form-submitted'
  | 'communication-sent'
  | 'response-received';

export interface StepAuditLog {
  id: string;
  journeyId: string;
  stepId: string;
  stepTitle: string;
  patientId: string;
  patientName: string;
  
  // Event details
  eventType: StepEventType;
  eventTimestamp: Date;
  
  // User/system context
  performedBy?: string; // User ID or 'system' or 'automated'
  performedByName?: string;
  location?: string; // Where action occurred (e.g., 'room-PT1', 'check-in', 'encompass-popup')
  
  // Timing data
  stepStartTime?: Date;
  stepEndTime?: Date;
  stepDuration?: number; // Minutes
  waitTime?: number; // Minutes patient waited before step started
  
  // Room data
  roomId?: string;
  roomName?: string;
  roomType?: string;
  
  // External system integration
  externalSystemAction?: string; // e.g., 'encompass-launched', 'form-sent'
  externalSystemUrl?: string;
  externalPatientId?: string;
  externalAppointmentId?: string;
  
  // Journey phase context
  journeyPhase: 'pre-visit' | 'in-office' | 'post-visit';
  
  // Additional metadata
  metadata?: Record<string, any>;
  
  // Provider context
  providerId?: string;
  providerName?: string;
  
  // Office context
  officeId?: string;
  officeName?: string;
  
  // Outcome
  outcome?: 'success' | 'failed' | 'skipped' | 'cancelled';
  errorMessage?: string;
  
  // Workflow metrics
  isOvertime?: boolean;
  expectedDuration?: number;
  
  createdAt: Date;
}

export interface StepAuditSummary {
  journeyId: string;
  patientName: string;
  totalSteps: number;
  completedSteps: number;
  skippedSteps: number;
  failedSteps: number;
  
  totalDuration: number; // Minutes
  totalWaitTime: number; // Minutes
  averageStepDuration: number;
  averageWaitTime: number;
  
  journeyStartTime: Date;
  journeyEndTime?: Date;
  
  stepsOvertime: number;
  encompassLaunches: number;
  roomChanges: number;
  
  logs: StepAuditLog[];
}

export interface ReportingMetrics {
  // Time period
  startDate: Date;
  endDate: Date;
  
  // Volume metrics
  totalJourneys: number;
  totalSteps: number;
  completedJourneys: number;
  
  // Performance metrics
  averageJourneyDuration: number;
  averageWaitTime: number;
  averageStepDuration: number;
  
  // Efficiency metrics
  stepsCompletedOnTime: number;
  stepsOvertime: number;
  overtimeRate: number; // Percentage
  
  // Room utilization
  roomUtilizationRate: number; // Percentage
  averageRoomTurnoverTime: number;
  
  // By phase
  preVisitMetrics: PhaseMetrics;
  inOfficeMetrics: PhaseMetrics;
  postVisitMetrics: PhaseMetrics;
  
  // By step type
  stepTypeMetrics: Record<string, StepTypeMetrics>;
  
  // By provider
  providerMetrics: Record<string, ProviderMetrics>;
}

export interface PhaseMetrics {
  totalSteps: number;
  averageDuration: number;
  averageWaitTime: number;
  completionRate: number;
  overtimeRate: number;
}

export interface StepTypeMetrics {
  stepTitle: string;
  count: number;
  averageDuration: number;
  averageWaitTime: number;
  completionRate: number;
  overtimeRate: number;
  encompassLaunches?: number;
}

export interface ProviderMetrics {
  providerId: string;
  providerName: string;
  totalJourneys: number;
  averageJourneyDuration: number;
  patientSatisfactionScore?: number;
}

export interface AuditLogQuery {
  // Filters
  journeyId?: string;
  patientId?: string;
  stepId?: string;
  eventType?: StepEventType | StepEventType[];
  performedBy?: string;
  roomId?: string;
  providerId?: string;
  officeId?: string;
  
  // Date range
  startDate?: Date;
  endDate?: Date;
  
  // Pagination
  page?: number;
  limit?: number;
  
  // Sorting
  sortBy?: 'eventTimestamp' | 'stepDuration' | 'waitTime';
  sortOrder?: 'asc' | 'desc';
}

export interface AuditLogQueryResult {
  logs: StepAuditLog[];
  total: number;
  page: number;
  limit: number;
  hasMore: boolean;
}
