/**
 * ID Document Types
 * Types for insurance cards, driver's licenses, and other identity documents
 */

// Document types
export const DocumentType = {
  INSURANCE_CARD: 'insuranceCard',
  DRIVERS_LICENSE: 'driversLicense',
  OTHER: 'other',
} as const;

export type DocumentTypeValue = typeof DocumentType[keyof typeof DocumentType];

// ID Document
export interface IDDocument {
  id?: string;
  patientId: string;
  documentType: DocumentTypeValue;
  frontImage: string; // URL or Base64
  backImage?: string;
  uploadedAt: Date;
  // Insurance-specific fields
  insuranceProvider?: string;
  insuranceMemberId?: string;
  insuranceGroupId?: string;
  isPrimary?: boolean;
  // Driver's license specific fields
  licenseNumber?: string;
  expirationDate?: string;
  stateIssued?: string;
  // Common metadata
  description?: string;
  updatedAt?: Date;
}

// Upload field props
export interface IDDocumentUploadFieldProps {
  documentType: DocumentTypeValue;
  patientId: string;
  onUpload?: (document: IDDocument) => void;
  onError?: (error: Error) => void;
  showMetadataFields?: boolean;
  defaultValues?: Partial<IDDocument>;
}

// API response types
export interface UploadDocumentResponse {
  success: boolean;
  document?: IDDocument;
  error?: string;
}

export interface GetDocumentsResponse {
  success: boolean;
  documents: IDDocument[];
  error?: string;
}

// OCR extraction result
export interface ExtractedMetadata {
  insuranceProvider?: string;
  insuranceMemberId?: string;
  insuranceGroupId?: string;
  licenseNumber?: string;
  expirationDate?: string;
  stateIssued?: string;
  firstName?: string;
  lastName?: string;
  dateOfBirth?: string;
  address?: string;
}
