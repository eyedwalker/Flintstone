/**
 * Recommendation System Type Definitions
 * 
 * Comprehensive type system for intelligent, rule-based patient recommendations
 */

// Display locations where recommendations can appear
export type DisplayLocation =
  | 'journey-step'
  | 'patient-details-sidebar'
  | 'patient-details-header'
  | 'checkout-summary'
  | 'post-visit-summary'
  | 'appointment-confirmation'
  | 'room-assignment'
  | 'mobile-notification'
  | 'email-followup';

// Recommendation types
export type RecommendationType = 'product' | 'service' | 'content' | 'action';

// Media types for recommendation content
export type MediaType = 'text' | 'image' | 'video' | 'url';

// Condition operators for rule evaluation
export type ConditionOperator = 
  | '==' 
  | '!=' 
  | '>' 
  | '<' 
  | '>=' 
  | '<=' 
  | 'contains' 
  | 'not-contains'
  | 'in' 
  | 'not-in'
  | 'regex'
  | 'exists'
  | 'not-exists';

// Logical operators for combining conditions
export type LogicalOperator = 'AND' | 'OR';

// Timing for when to display recommendations
export type DisplayTiming = 'immediate' | 'after-step' | 'before-checkout' | 'scheduled';

// Recommendation status lifecycle
export type RecommendationStatus = 
  | 'pending' 
  | 'displayed' 
  | 'clicked' 
  | 'converted' 
  | 'dismissed'
  | 'expired';

/**
 * Rule condition for targeting patients
 */
export interface RuleCondition {
  field: string; // e.g., 'patient.age', 'appointment.type', 'lifestyle.hobbies'
  operator: ConditionOperator;
  value: any;
  logicalOperator?: LogicalOperator; // How to combine with next condition
}

/**
 * Display configuration for recommendations
 */
export interface DisplayConfig {
  locations: DisplayLocation[];
  journeySteps?: string[]; // Specific journey step IDs/names
  timing?: DisplayTiming;
  displayDuration?: number; // milliseconds
  maxDisplaysPerPatient?: number;
  cooldownPeriod?: number; // hours before showing again
}

/**
 * Recommendation content definition
 */
export interface RecommendationContent {
  type: RecommendationType;
  title: string;
  description: string;
  mediaType: MediaType;
  mediaContent?: string; // URL, image path, or video URL (supports mail merge)
  ctaText?: string; // Call-to-action button text
  ctaUrl?: string; // Call-to-action URL (supports mail merge)
  metadata?: Record<string, any>; // Additional custom data
}

/**
 * Performance metrics for recommendations
 */
export interface RecommendationMetrics {
  impressions: number;
  clicks: number;
  conversions: number;
  dismissals: number;
  conversionRate?: number;
  clickThroughRate?: number;
  lastUpdated: Date;
}

/**
 * Recommendation rule definition
 */
export interface RecommendationRule {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  priority: number; // Higher = more important (1-100)
  
  // Targeting
  conditions: RuleCondition[];
  
  // Content
  recommendation: RecommendationContent;
  
  // Display
  displayConfig: DisplayConfig;
  
  // Metadata
  createdAt: Date;
  updatedAt: Date;
  createdBy?: string;
  
  // Performance
  metrics: RecommendationMetrics;
  
  // Advanced
  tags?: string[];
  category?: string;
  validFrom?: Date;
  validUntil?: Date;
}

/**
 * Generated recommendation for a specific patient
 */
export interface Recommendation {
  id: string;
  ruleId: string;
  patientId: string;
  journeyId?: string;
  
  // Content (with mail merge applied)
  title: string;
  description: string;
  mediaType: MediaType;
  mediaUrl?: string;
  ctaText?: string;
  ctaUrl?: string;
  
  // Display
  displayLocations: DisplayLocation[];
  priority: number;
  
  // State
  status: RecommendationStatus;
  displayedAt?: Date;
  clickedAt?: Date;
  convertedAt?: Date;
  dismissedAt?: Date;
  
  // Context
  generatedAt: Date;
  expiresAt?: Date;
  
  // Metadata
  metadata?: Record<string, any>;
  ruleMetadata?: Record<string, any>;
}

/**
 * Context for evaluating recommendations
 */
export interface RecommendationContext {
  patient: {
    id: string;
    firstName: string;
    lastName: string;
    age: number;
    dateOfBirth: Date;
    gender?: string;
    email?: string;
    phone?: string;
    lifestyle?: Record<string, any>;
    preferences?: Record<string, any>;
  };
  
  appointment?: {
    id: string;
    date: Date;
    time?: string;
    type: string;
    status: string;
    provider?: {
      id: string;
      name: string;
    };
    office?: {
      id: string;
      name: string;
    };
  };
  
  journey?: {
    id: string;
    journeyPhase: string;
    currentStep?: string;
    status: string;
    checkInTime?: Date;
  };
  
  purchaseHistory?: Array<{
    id: string;
    productType: string;
    productName: string;
    purchaseDate: Date;
    amount: number;
    sku?: string;
  }>;
  
  insuranceInfo?: {
    carrier: string;
    planName: string;
    memberId: string;
  };
  
  customData?: Record<string, any>;
}

/**
 * Scored recommendation with evaluation details
 */
export interface ScoredRecommendation {
  recommendation: Recommendation;
  score: number;
  matchedConditions: number;
  totalConditions: number;
  relevanceFactors: {
    priorityScore: number;
    recencyScore: number;
    performanceScore: number;
    contextScore: number;
  };
}

/**
 * External recommendation from third-party systems
 */
export interface ExternalRecommendation {
  externalId: string;
  source: string; // e.g., 'lens-optimizer', 'crm-system'
  patientId: string;
  
  // Content
  title: string;
  description: string;
  mediaType: MediaType;
  mediaUrl?: string;
  ctaText?: string;
  ctaUrl?: string;
  
  // Display preferences
  displayLocations?: DisplayLocation[];
  priority?: number;
  expiresAt?: Date;
  
  // Metadata
  metadata?: Record<string, any>;
  createdAt: Date;
}

/**
 * Mail merge token for dynamic content
 */
export interface MailMergeToken {
  token: string; // e.g., '{{patient.firstName}}'
  field: string; // e.g., 'patient.firstName'
  value: any;
  resolved: boolean;
}

/**
 * Recommendation event for analytics
 */
export interface RecommendationEvent {
  id: string;
  recommendationId: string;
  patientId: string;
  eventType: 'impression' | 'click' | 'conversion' | 'dismissal';
  timestamp: Date;
  location: DisplayLocation;
  metadata?: Record<string, any>;
}
