/**
 * Form Rules Types
 * Defines rules for determining which forms patients need to complete
 */

// Rule frequency types
export type FormFrequency = 
  | 'once'           // One-time only (e.g., HIPAA acknowledgment)
  | 'annual'         // Once per year
  | 'per-visit'      // Every appointment
  | 'on-change'      // When specific data changes (e.g., insurance change)
  | 'conditional';   // Based on other conditions

// Rule trigger types
export type FormTrigger =
  | 'appointment-scheduled'  // When appointment is booked
  | 'pre-visit'              // X days before appointment
  | 'check-in'               // At check-in
  | 'post-visit'             // After appointment
  | 'insurance-change'       // When insurance info changes
  | 'manual';                // Staff manually sends

// Condition types for form rules
export type FormConditionType =
  | 'appointment-type'       // Based on appointment/visit type
  | 'patient-type'           // New vs existing patient
  | 'insurance-type'         // Insurance carrier or plan type
  | 'age-range'              // Patient age
  | 'last-completion'        // Time since last completion
  | 'has-insurance'          // Whether patient has insurance
  | 'provider'               // Specific provider
  | 'office';                // Specific office location

// Condition operators
export type ConditionOperator = 
  | 'equals' 
  | 'not-equals' 
  | 'contains' 
  | 'not-contains'
  | 'greater-than'
  | 'less-than'
  | 'in-list'
  | 'not-in-list';

// Individual condition
export interface FormCondition {
  type: FormConditionType;
  operator: ConditionOperator;
  value: string | number | string[];
}

// Form rule definition
export interface FormRule {
  id: string;
  name: string;
  description?: string;
  templateId: string;           // Which form template this rule applies to
  frequency: FormFrequency;
  trigger: FormTrigger;
  priority: number;             // Higher priority rules evaluated first (1-100)
  isActive: boolean;
  
  // Conditions (all must be true - AND logic)
  conditions: FormCondition[];
  
  // Exclusion conditions (if any true, form is NOT required)
  exclusions?: FormCondition[];
  
  // Timing configuration
  timing?: {
    daysBeforeAppointment?: number;  // For pre-visit triggers
    daysAfterAppointment?: number;   // For post-visit triggers
    reminderIntervals?: number[];    // Days between reminders [3, 1] = 3 days, then 1 day
    expirationDays?: number;         // Days until form link expires
  };
  
  // Communication preferences
  communication?: {
    methods: ('email' | 'sms' | 'both')[];
    templateId?: string;             // Communication template to use
    includeInBundle?: boolean;       // Bundle with other forms in same message
  };
  
  // Metadata
  createdAt: Date;
  updatedAt: Date;
  createdBy?: string;
}

// Pre-defined appointment types for eye care
export const APPOINTMENT_TYPES = [
  'comprehensive-exam',
  'routine-exam',
  'contact-lens-exam',
  'contact-lens-followup',
  'medical-eye-exam',
  'emergency',
  'post-op',
  'glasses-pickup',
  'adjustment',
  'retinal-imaging',
  'visual-field',
  'dilation',
  'pediatric-exam',
  'low-vision',
  'dry-eye-evaluation',
] as const;

export type AppointmentType = typeof APPOINTMENT_TYPES[number];

// Pre-defined insurance types
export const INSURANCE_TYPES = [
  'vsp',
  'eyemed',
  'spectera',
  'davis-vision',
  'superior-vision',
  'medicare',
  'medicaid',
  'private-medical',
  'self-pay',
  'other',
] as const;

export type InsuranceType = typeof INSURANCE_TYPES[number];

// Form requirement result
export interface FormRequirement {
  templateId: string;
  templateTitle: string;
  ruleId: string;
  ruleName: string;
  reason: string;
  priority: number;
  trigger: FormTrigger;
  dueDate?: Date;
  isOverdue?: boolean;
  lastCompleted?: Date;
  status: 'required' | 'recommended' | 'optional';
}

// Patient form status for eligibility checking
export interface PatientFormStatus {
  patientId: string;
  templateId: string;
  lastCompletedAt?: Date;
  completionCount: number;
  lastSentAt?: Date;
  pendingSubmissionId?: string;
}

// Form eligibility check context
export interface FormEligibilityContext {
  patientId: string;
  patientName: string;
  dateOfBirth?: Date;
  isNewPatient: boolean;
  appointmentId?: string;
  appointmentType?: string;
  appointmentDate?: Date;
  providerId?: string;
  providerName?: string;
  officeId?: string;
  insuranceType?: string;
  insuranceCarrier?: string;
  hasInsurance: boolean;
}

// Default form rules for eye care practice
export const DEFAULT_FORM_RULES: Omit<FormRule, 'id' | 'createdAt' | 'updatedAt'>[] = [
  // HIPAA - Annual
  {
    name: 'HIPAA Privacy Notice',
    description: 'HIPAA acknowledgment required annually',
    templateId: 'hipaa-privacy',
    frequency: 'annual',
    trigger: 'pre-visit',
    priority: 100,
    isActive: true,
    conditions: [],
    timing: {
      daysBeforeAppointment: 7,
      reminderIntervals: [3, 1],
      expirationDays: 30,
    },
    communication: {
      methods: ['both'],
      includeInBundle: true,
    },
  },
  
  // Patient Intake - New patients only
  {
    name: 'New Patient Intake',
    description: 'Comprehensive intake form for new patients',
    templateId: 'patient-intake',
    frequency: 'once',
    trigger: 'pre-visit',
    priority: 95,
    isActive: true,
    conditions: [
      { type: 'patient-type', operator: 'equals', value: 'new' },
    ],
    timing: {
      daysBeforeAppointment: 7,
      reminderIntervals: [3, 1],
      expirationDays: 30,
    },
    communication: {
      methods: ['both'],
      includeInBundle: true,
    },
  },
  
  // Patient Update - Annual for existing patients
  {
    name: 'Annual Patient Update',
    description: 'Update demographics and medical history annually',
    templateId: 'patient-update',
    frequency: 'annual',
    trigger: 'pre-visit',
    priority: 90,
    isActive: true,
    conditions: [
      { type: 'patient-type', operator: 'equals', value: 'existing' },
    ],
    timing: {
      daysBeforeAppointment: 7,
      reminderIntervals: [3, 1],
      expirationDays: 30,
    },
    communication: {
      methods: ['both'],
      includeInBundle: true,
    },
  },
  
  // Contact Lens Agreement - Per contact lens visit
  {
    name: 'Contact Lens Agreement',
    description: 'Required for contact lens exams and fittings',
    templateId: 'contact-lens-agreement',
    frequency: 'annual',
    trigger: 'pre-visit',
    priority: 85,
    isActive: true,
    conditions: [
      { type: 'appointment-type', operator: 'in-list', value: ['contact-lens-exam', 'contact-lens-followup'] },
    ],
    timing: {
      daysBeforeAppointment: 3,
      reminderIntervals: [1],
      expirationDays: 14,
    },
    communication: {
      methods: ['both'],
      includeInBundle: true,
    },
  },
  
  // Insurance Card Upload - When has insurance
  {
    name: 'Insurance Card Upload',
    description: 'Upload insurance cards for verification',
    templateId: 'insurance-card-upload',
    frequency: 'on-change',
    trigger: 'pre-visit',
    priority: 80,
    isActive: true,
    conditions: [
      { type: 'has-insurance', operator: 'equals', value: 'true' },
    ],
    timing: {
      daysBeforeAppointment: 5,
      reminderIntervals: [2],
      expirationDays: 30,
    },
    communication: {
      methods: ['both'],
      includeInBundle: true,
    },
  },
  
  // Driver's License - Annual for ID verification
  {
    name: "Driver's License Upload",
    description: 'ID verification annually',
    templateId: 'drivers-license-upload',
    frequency: 'annual',
    trigger: 'pre-visit',
    priority: 75,
    isActive: true,
    conditions: [
      { type: 'age-range', operator: 'greater-than', value: 16 },
    ],
    timing: {
      daysBeforeAppointment: 5,
      reminderIntervals: [2],
      expirationDays: 30,
    },
    communication: {
      methods: ['both'],
      includeInBundle: true,
    },
  },
  
  // Medical History - For medical eye exams
  {
    name: 'Medical Eye Exam Questionnaire',
    description: 'Detailed medical history for medical visits',
    templateId: 'medical-eye-questionnaire',
    frequency: 'per-visit',
    trigger: 'pre-visit',
    priority: 85,
    isActive: true,
    conditions: [
      { type: 'appointment-type', operator: 'in-list', value: ['medical-eye-exam', 'emergency', 'dry-eye-evaluation'] },
    ],
    timing: {
      daysBeforeAppointment: 3,
      reminderIntervals: [1],
      expirationDays: 7,
    },
    communication: {
      methods: ['both'],
      includeInBundle: true,
    },
  },
  
  // Pediatric Form - For patients under 18
  {
    name: 'Pediatric Patient Form',
    description: 'Guardian consent and pediatric history',
    templateId: 'pediatric-form',
    frequency: 'annual',
    trigger: 'pre-visit',
    priority: 90,
    isActive: true,
    conditions: [
      { type: 'age-range', operator: 'less-than', value: 18 },
    ],
    timing: {
      daysBeforeAppointment: 7,
      reminderIntervals: [3, 1],
      expirationDays: 30,
    },
    communication: {
      methods: ['both'],
      includeInBundle: true,
    },
  },
  
  // Post-Visit Survey - After every visit
  {
    name: 'Patient Satisfaction Survey',
    description: 'Feedback survey after appointment',
    templateId: 'satisfaction-survey',
    frequency: 'per-visit',
    trigger: 'post-visit',
    priority: 50,
    isActive: true,
    conditions: [],
    exclusions: [
      { type: 'appointment-type', operator: 'in-list', value: ['glasses-pickup', 'adjustment'] },
    ],
    timing: {
      daysAfterAppointment: 1,
      reminderIntervals: [3],
      expirationDays: 14,
    },
    communication: {
      methods: ['email'],
      includeInBundle: false,
    },
  },
  
  // No forms needed for these visit types
  {
    name: 'Glasses Pickup - No Forms',
    description: 'Skip forms for glasses pickup',
    templateId: 'none',
    frequency: 'per-visit',
    trigger: 'appointment-scheduled',
    priority: 100,
    isActive: true,
    conditions: [
      { type: 'appointment-type', operator: 'in-list', value: ['glasses-pickup', 'adjustment'] },
    ],
    timing: {},
    communication: {
      methods: [],
      includeInBundle: false,
    },
  },
];
