/**
 * Journey Rules Types
 * Defines types for the rules engine that customizes patient journeys
 */

import { JourneyStep, JourneyPhase } from './patient-journey';

/**
 * Operators available for rule conditions
 */
export type ConditionOperator = 
  | 'equals' 
  | 'notEquals' 
  | 'contains' 
  | 'greaterThan' 
  | 'lessThan' 
  | 'exists' 
  | 'notExists';

/**
 * Single condition for a journey rule
 */
export interface RuleCondition {
  field: string;            // e.g., 'appointmentType', 'patientAge', 'isNewPatient'
  operator: ConditionOperator;
  value?: any;
}

/**
 * Rule for determining which journey steps to apply
 */
export interface JourneyStepRule {
  id: string;
  name: string;
  description: string;
  conditions: RuleCondition[];
  stepTemplateIds: string[];  // Steps to apply when rule matches
  priority: number;           // For rule ordering (higher = evaluated first)
  isActive: boolean;
  phase: JourneyPhase | 'all';
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Context used for evaluating journey rules
 */
export interface AppointmentContext {
  patientId: string;
  appointmentId?: string;
  appointmentType?: string;
  providerId?: string;
  officeId: string;
  isNewPatient: boolean;
  hasInsurance: boolean;
  insuranceProvider?: string;
  age?: number;
  previousVisitCount: number;
  reasonForVisit?: string;
  phase?: JourneyPhase;
  [key: string]: any;  // Allow for extensible properties
}

/**
 * Journey step recommendation from the recommendation engine
 */
export interface JourneyStepRecommendation {
  id: string;
  title: string;
  description: string;
  estimatedDuration: number;
  staffRole: string;
  reasonCodes: string[];
}

/**
 * Form recommendation
 */
export interface FormRecommendation {
  id: string;
  title: string;
  description: string;
  priority: 'required' | 'recommended' | 'optional';
  reasonCode: string;
}

/**
 * Patient context for generating recommendations
 */
export interface PatientContext {
  patient: {
    id: string;
    name: string;
    Dob?: string;
    [key: string]: any;
  };
  task?: {
    _id?: string;
    providerId?: string;
    providerName?: string;
    reasonForVisit?: string;
    insuranceProvider?: string;
    [key: string]: any;
  };
  previousEyewear?: Array<{
    orderType?: string;
    [key: string]: any;
  }>;
  lifestyleInfo?: {
    screenTime?: 'low' | 'medium' | 'high';
    outdoorActivities?: boolean;
    drivingFrequency?: 'rarely' | 'sometimes' | 'frequently';
    occupation?: string;
  };
}

/**
 * Full recommendation response
 */
export interface RecommendationResponse {
  journeySteps: JourneyStepRecommendation[];
  forms: FormRecommendation[];
}
