import twilio from 'twilio';

// Initialize Twilio client
const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

export async function sendSMS(to: string, body: string) {
  try {
    const message = await client.messages.create({
      body,
      to,
      from: process.env.TWILIO_PHONE_NUMBER || '',
    });
    return { success: true, messageId: message.sid };
  } catch (error: any) {
    console.error('Error sending SMS:', error);
    return { success: false, error: error?.message || 'Failed to send SMS' };
  }
}

export type TwilioVoice = 'Polly.Joanna' | 'Polly.Matthew' | 'Polly.Amy' | 'Polly.Emma' | 'Polly.Brian';

function escapeXml(unsafe: string): string {
  return unsafe.replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '&': return '&amp;';
      case '\'': return '&apos;';
      case '"': return '&quot;';
      default: return c;
    }
  });
}

export interface VoiceCallOptions {
  voice?: TwilioVoice;
  record?: boolean;
  recordingStatusCallback?: string;
  statusCallback?: string;
  timeout?: number;
}

export async function makeVoiceCall(
  to: string, 
  message: string, 
  options: VoiceCallOptions = {}
) {
  const { 
    voice = 'Polly.Joanna', 
    record = true,
    recordingStatusCallback,
    statusCallback,
    timeout = 30
  } = options;

  try {
    const escapedMessage = escapeXml(message);
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
      <Response>
        ${record ? `<Record recordingStatusCallback="${recordingStatusCallback || ''}" maxLength="3600" transcribe="false" />` : ''}
        <Say voice="${voice}">${escapedMessage}</Say>
      </Response>`;

    const callOptions: any = {
      twiml,
      to,
      from: process.env.TWILIO_PHONE_NUMBER || '',
      timeout,
    };

    if (record) {
      callOptions.record = true;
    }

    if (statusCallback) {
      callOptions.statusCallback = statusCallback;
      callOptions.statusCallbackEvent = ['initiated', 'ringing', 'answered', 'completed'];
    }

    const call = await client.calls.create(callOptions);
    return { success: true, callId: call.sid };
  } catch (error: any) {
    console.error('Error making voice call:', error);
    return { success: false, error: error?.message || 'Failed to make voice call' };
  }
}

export async function makeVoiceCallWithGather(
  to: string, 
  greeting: string, 
  gatherPrompt: string,
  actionUrl: string,
  voice: TwilioVoice = 'Polly.Joanna'
) {
  try {
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
      <Response>
        <Say voice="${voice}">${escapeXml(greeting)}</Say>
        <Gather input="dtmf speech" timeout="10" action="${actionUrl}" method="POST">
          <Say voice="${voice}">${escapeXml(gatherPrompt)}</Say>
        </Gather>
        <Say voice="${voice}">We didn't receive any input. Goodbye!</Say>
      </Response>`;

    const call = await client.calls.create({
      twiml,
      to,
      from: process.env.TWILIO_PHONE_NUMBER || '',
    });
    return { success: true, callId: call.sid };
  } catch (error: any) {
    console.error('Error making voice call with gather:', error);
    return { success: false, error: error?.message || 'Failed to make voice call' };
  }
}

export { client as twilioClient };
