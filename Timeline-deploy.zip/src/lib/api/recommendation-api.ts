/**
 * Recommendation API
 * 
 * External API for third-party systems to submit recommendations
 */

import { ExternalRecommendation, Recommendation, DisplayLocation } from '../types/recommendation';
import { RecommendationService } from '../services/recommendation-service';

/**
 * API Request for submitting an external recommendation
 */
export interface SubmitRecommendationRequest {
  apiKey: string; // Authentication
  externalId: string;
  source: string;
  patientId: string;
  title: string;
  description: string;
  mediaType?: 'text' | 'image' | 'video' | 'url';
  mediaUrl?: string;
  ctaText?: string;
  ctaUrl?: string;
  displayLocations?: DisplayLocation[];
  priority?: number;
  expiresAt?: string; // ISO date string
  metadata?: Record<string, any>;
}

/**
 * API Response
 */
export interface RecommendationApiResponse {
  success: boolean;
  recommendation?: Recommendation;
  error?: string;
  message?: string;
}

/**
 * API Key validation
 */
const VALID_API_KEYS = new Set([
  'demo-api-key-12345',
  'lens-optimizer-key-67890',
  'crm-integration-key-abcde'
]);

export class RecommendationApi {
  /**
   * Submit an external recommendation
   */
  static async submitRecommendation(request: SubmitRecommendationRequest): Promise<RecommendationApiResponse> {
    try {
      // Validate API key
      if (!this.validateApiKey(request.apiKey)) {
        return {
          success: false,
          error: 'Invalid API key',
          message: 'The provided API key is not valid. Please check your credentials.'
        };
      }

      // Validate required fields
      const validation = this.validateRequest(request);
      if (!validation.valid) {
        return {
          success: false,
          error: 'Validation error',
          message: validation.message
        };
      }

      // Create external recommendation
      const external: ExternalRecommendation = {
        externalId: request.externalId,
        source: request.source,
        patientId: request.patientId,
        title: request.title,
        description: request.description,
        mediaType: request.mediaType || 'text',
        mediaUrl: request.mediaUrl,
        ctaText: request.ctaText,
        ctaUrl: request.ctaUrl,
        displayLocations: request.displayLocations,
        priority: request.priority,
        expiresAt: request.expiresAt ? new Date(request.expiresAt) : undefined,
        metadata: request.metadata,
        createdAt: new Date()
      };

      // Add to recommendation service
      const recommendation = RecommendationService.addExternalRecommendation(external);

      return {
        success: true,
        recommendation,
        message: 'Recommendation submitted successfully'
      };
    } catch (error) {
      console.error('Error submitting recommendation:', error);
      return {
        success: false,
        error: 'Internal error',
        message: error instanceof Error ? error.message : 'An unexpected error occurred'
      };
    }
  }

  /**
   * Get recommendations for a patient (read-only endpoint)
   */
  static async getRecommendations(
    apiKey: string,
    patientId: string,
    displayLocation?: DisplayLocation
  ): Promise<RecommendationApiResponse> {
    try {
      // Validate API key
      if (!this.validateApiKey(apiKey)) {
        return {
          success: false,
          error: 'Invalid API key'
        };
      }

      const recommendations = RecommendationService.getRecommendations(patientId, displayLocation);

      return {
        success: true,
        recommendation: recommendations[0], // Return first for backward compatibility
        message: `Found ${recommendations.length} recommendations`
      };
    } catch (error) {
      console.error('Error getting recommendations:', error);
      return {
        success: false,
        error: 'Internal error',
        message: error instanceof Error ? error.message : 'An unexpected error occurred'
      };
    }
  }

  /**
   * Validate API key
   */
  private static validateApiKey(apiKey: string): boolean {
    return VALID_API_KEYS.has(apiKey);
  }

  /**
   * Validate request fields
   */
  private static validateRequest(request: SubmitRecommendationRequest): { valid: boolean; message?: string } {
    if (!request.externalId) {
      return { valid: false, message: 'externalId is required' };
    }

    if (!request.source) {
      return { valid: false, message: 'source is required' };
    }

    if (!request.patientId) {
      return { valid: false, message: 'patientId is required' };
    }

    if (!request.title) {
      return { valid: false, message: 'title is required' };
    }

    if (!request.description) {
      return { valid: false, message: 'description is required' };
    }

    // Validate media type
    if (request.mediaType && !['text', 'image', 'video', 'url'].includes(request.mediaType)) {
      return { valid: false, message: 'Invalid mediaType. Must be one of: text, image, video, url' };
    }

    // Validate display locations
    const validLocations: DisplayLocation[] = [
      'journey-step',
      'patient-details-sidebar',
      'patient-details-header',
      'checkout-summary',
      'post-visit-summary',
      'appointment-confirmation',
      'room-assignment',
      'mobile-notification',
      'email-followup'
    ];

    if (request.displayLocations) {
      for (const loc of request.displayLocations) {
        if (!validLocations.includes(loc)) {
          return { valid: false, message: `Invalid display location: ${loc}` };
        }
      }
    }

    // Validate priority range
    if (request.priority !== undefined && (request.priority < 1 || request.priority > 100)) {
      return { valid: false, message: 'priority must be between 1 and 100' };
    }

    // Validate expiresAt date
    if (request.expiresAt) {
      const date = new Date(request.expiresAt);
      if (isNaN(date.getTime())) {
        return { valid: false, message: 'Invalid expiresAt date format. Use ISO 8601 format.' };
      }
    }

    return { valid: true };
  }

  /**
   * Register a new API key (admin function)
   */
  static registerApiKey(apiKey: string): boolean {
    if (VALID_API_KEYS.has(apiKey)) {
      return false; // Already exists
    }
    VALID_API_KEYS.add(apiKey);
    return true;
  }

  /**
   * Revoke an API key (admin function)
   */
  static revokeApiKey(apiKey: string): boolean {
    return VALID_API_KEYS.delete(apiKey);
  }
}

/**
 * Example usage for external systems
 */
export const RECOMMENDATION_API_EXAMPLES = {
  /**
   * Example: Submit a product recommendation
   */
  productRecommendation: {
    apiKey: 'your-api-key-here',
    externalId: 'lens-opt-12345',
    source: 'lens-optimizer',
    patientId: 'patient-001',
    title: 'Premium Anti-Glare Coating',
    description: 'Based on your prescription and lifestyle, we recommend our premium anti-glare coating for optimal clarity.',
    mediaType: 'image' as const,
    mediaUrl: 'https://cdn.example.com/products/anti-glare.jpg',
    ctaText: 'Add to Order',
    ctaUrl: '/products/coatings?sku=ANTI-GLARE-PREM',
    displayLocations: ['journey-step', 'checkout-summary'] as DisplayLocation[],
    priority: 85,
    metadata: {
      productSku: 'ANTI-GLARE-PREM',
      calculatedScore: 0.92,
      algorithm: 'lens-optimizer-v2'
    }
  },

  /**
   * Example: Submit a service recommendation
   */
  serviceRecommendation: {
    apiKey: 'your-api-key-here',
    externalId: 'crm-follow-up-456',
    source: 'crm-system',
    patientId: 'patient-001',
    title: 'Schedule Your 6-Month Checkup',
    description: 'It\'s been 6 months since your last visit. Book your follow-up appointment to maintain optimal eye health.',
    mediaType: 'text' as const,
    ctaText: 'Book Appointment',
    ctaUrl: '/appointments/schedule?type=followup&patient={{patientId}}',
    displayLocations: ['patient-details-sidebar', 'email-followup'] as DisplayLocation[],
    priority: 70,
    expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
    metadata: {
      lastVisitDate: '2025-07-15',
      reminderType: 'preventive-care'
    }
  },

  /**
   * Example: Submit a promotional recommendation
   */
  promotionalRecommendation: {
    apiKey: 'your-api-key-here',
    externalId: 'promo-summer-2025',
    source: 'marketing-automation',
    patientId: 'patient-001',
    title: 'Summer Sale: 40% Off Sunglasses',
    description: 'Protect your eyes this summer! Get 40% off all prescription sunglasses through July 31st.',
    mediaType: 'image' as const,
    mediaUrl: 'https://cdn.example.com/promos/summer-sunglasses.jpg',
    ctaText: 'Shop Now',
    ctaUrl: '/products/sunglasses?promo=SUMMER40',
    displayLocations: ['patient-details-header', 'post-visit-summary'] as DisplayLocation[],
    priority: 60,
    expiresAt: '2025-07-31T23:59:59Z',
    metadata: {
      campaignId: 'summer-2025',
      discount: 0.40,
      promoCode: 'SUMMER40'
    }
  }
};

/**
 * cURL examples for external systems
 */
export const CURL_EXAMPLES = `
# Submit a product recommendation
curl -X POST https://api.timeline.example.com/recommendations \\
  -H "Content-Type: application/json" \\
  -d '{
    "apiKey": "your-api-key-here",
    "externalId": "lens-opt-12345",
    "source": "lens-optimizer",
    "patientId": "patient-001",
    "title": "Premium Anti-Glare Coating",
    "description": "Based on your prescription and lifestyle, we recommend our premium anti-glare coating.",
    "mediaType": "image",
    "mediaUrl": "https://cdn.example.com/products/anti-glare.jpg",
    "ctaText": "Add to Order",
    "ctaUrl": "/products/coatings?sku=ANTI-GLARE-PREM",
    "displayLocations": ["journey-step", "checkout-summary"],
    "priority": 85,
    "metadata": {
      "productSku": "ANTI-GLARE-PREM",
      "calculatedScore": 0.92
    }
  }'

# Get recommendations for a patient
curl -X GET "https://api.timeline.example.com/recommendations?patientId=patient-001&location=journey-step" \\
  -H "X-API-Key: your-api-key-here"
`;
