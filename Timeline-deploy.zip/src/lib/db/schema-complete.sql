/**
 * Complete Patient Care Timeline Database Schema
 * Includes all entities for patient management, appointments, exams, prescriptions, insurance, orders, and recalls
 * Designed for multi-tenant SaaS with Eyefinity integration
 */

-- =====================================================
-- CORE ORGANIZATIONAL ENTITIES
-- =====================================================

CREATE TABLE IF NOT EXISTS accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'cancelled')),
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  eyefinity_company_id TEXT,
  eyefinity_base_url TEXT,
  eyefinity_api_key TEXT,
  eyefinity_api_secret TEXT,
  eyefinity_tenant_uid TEXT,
  oauth_token TEXT,
  oauth_refresh_token TEXT,
  oauth_token_expires_at TIMESTAMPTZ,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS offices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  eyefinity_location_id TEXT,
  phone TEXT,
  email TEXT,
  timezone TEXT DEFAULT 'America/Chicago',
  address JSONB DEFAULT '{}',
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS staff (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  eyefinity_staff_id TEXT,
  eyefinity_provider_id TEXT,
  email TEXT,
  phone TEXT,
  role TEXT NOT NULL CHECK (role IN ('doctor', 'technician', 'optician', 'front_desk', 'manager', 'other')),
  specialty TEXT,
  active BOOLEAN DEFAULT true,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS staff_offices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_id UUID NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  is_primary BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(staff_id, office_id)
);

-- =====================================================
-- PATIENT MANAGEMENT
-- =====================================================

CREATE TABLE IF NOT EXISTS patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  eyefinity_patient_id TEXT,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  date_of_birth DATE,
  gender TEXT CHECK (gender IN ('male', 'female', 'other', 'unknown')),
  email TEXT,
  phone TEXT,
  mobile_phone TEXT,
  address JSONB DEFAULT '{}',
  emergency_contact JSONB DEFAULT '{}',
  preferred_language TEXT DEFAULT 'en',
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'deceased')),
  notes TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS patient_insurance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  eyefinity_insurance_id TEXT,
  carrier_name TEXT NOT NULL,
  policy_number TEXT,
  group_number TEXT,
  subscriber_name TEXT,
  subscriber_dob DATE,
  relationship_to_subscriber TEXT,
  priority TEXT DEFAULT 'primary' CHECK (priority IN ('primary', 'secondary', 'tertiary')),
  effective_date DATE,
  termination_date DATE,
  is_active BOOLEAN DEFAULT true,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- APPOINTMENTS & SCHEDULING
-- =====================================================

CREATE TABLE IF NOT EXISTS appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  provider_id UUID REFERENCES staff(id) ON DELETE SET NULL,
  eyefinity_appointment_id TEXT,
  appointment_date TIMESTAMPTZ NOT NULL,
  duration_minutes INTEGER DEFAULT 30,
  appointment_type TEXT NOT NULL,
  status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'confirmed', 'checked_in', 'in_progress', 'completed', 'cancelled', 'no_show')),
  reason_for_visit TEXT,
  notes TEXT,
  reminder_sent BOOLEAN DEFAULT false,
  reminder_sent_at TIMESTAMPTZ,
  checked_in_at TIMESTAMPTZ,
  checked_out_at TIMESTAMPTZ,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- CLINICAL DATA
-- =====================================================

CREATE TABLE IF NOT EXISTS encounters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  provider_id UUID REFERENCES staff(id) ON DELETE SET NULL,
  encounter_date TIMESTAMPTZ NOT NULL,
  encounter_type TEXT NOT NULL,
  chief_complaint TEXT,
  subjective TEXT,
  objective TEXT,
  assessment TEXT,
  plan TEXT,
  status TEXT DEFAULT 'open' CHECK (status IN ('open', 'signed', 'amended', 'corrected')),
  signed_at TIMESTAMPTZ,
  signed_by UUID REFERENCES staff(id) ON DELETE SET NULL,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS exams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  encounter_id UUID NOT NULL REFERENCES encounters(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  eyefinity_exam_id TEXT,
  exam_date DATE NOT NULL,
  exam_type TEXT NOT NULL,
  visual_acuity JSONB DEFAULT '{}',
  refraction JSONB DEFAULT '{}',
  intraocular_pressure JSONB DEFAULT '{}',
  dilated BOOLEAN DEFAULT false,
  findings TEXT,
  diagnosis_codes TEXT[],
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS prescriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES encounters(id) ON DELETE SET NULL,
  provider_id UUID REFERENCES staff(id) ON DELETE SET NULL,
  eyefinity_rx_id TEXT,
  prescription_date DATE NOT NULL,
  prescription_type TEXT NOT NULL CHECK (prescription_type IN ('eyeglasses', 'contact_lenses', 'medication')),
  od_sphere DECIMAL(5,2),
  od_cylinder DECIMAL(5,2),
  od_axis INTEGER,
  od_add DECIMAL(4,2),
  os_sphere DECIMAL(5,2),
  os_cylinder DECIMAL(5,2),
  os_axis INTEGER,
  os_add DECIMAL(4,2),
  pd DECIMAL(4,1),
  expiration_date DATE,
  medication_name TEXT,
  medication_dosage TEXT,
  medication_instructions TEXT,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'expired', 'replaced', 'cancelled')),
  notes TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- ORDERS & INVENTORY
-- =====================================================

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  prescription_id UUID REFERENCES prescriptions(id) ON DELETE SET NULL,
  eyefinity_order_id TEXT,
  order_date DATE NOT NULL,
  order_type TEXT NOT NULL,
  frame_description TEXT,
  lens_type TEXT,
  lens_material TEXT,
  coatings TEXT[],
  total_price DECIMAL(10,2),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'ordered', 'received', 'ready', 'dispensed', 'cancelled')),
  ordered_date DATE,
  expected_date DATE,
  received_date DATE,
  dispensed_date DATE,
  notes TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- RECALLS & REMINDERS
-- =====================================================

CREATE TABLE IF NOT EXISTS recalls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  recall_type TEXT NOT NULL,
  due_date DATE NOT NULL,
  last_exam_date DATE,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'contacted', 'scheduled', 'completed', 'declined', 'cancelled')),
  contact_method TEXT,
  contacted_at TIMESTAMPTZ,
  notes TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- SYNC & INTEGRATION LOGGING
-- =====================================================

CREATE TABLE IF NOT EXISTS sync_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  sync_type TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  eyefinity_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('success', 'partial', 'failed', 'skipped')),
  records_processed INTEGER DEFAULT 0,
  records_created INTEGER DEFAULT 0,
  records_updated INTEGER DEFAULT 0,
  records_failed INTEGER DEFAULT 0,
  error_message TEXT,
  metadata JSONB DEFAULT '{}',
  started_at TIMESTAMPTZ NOT NULL,
  completed_at TIMESTAMPTZ,
  duration_ms INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

-- Core organizational indexes
CREATE INDEX IF NOT EXISTS idx_companies_account_id ON companies(account_id);
CREATE INDEX IF NOT EXISTS idx_offices_company_id ON offices(company_id);
CREATE INDEX IF NOT EXISTS idx_staff_offices_staff_id ON staff_offices(staff_id);
CREATE INDEX IF NOT EXISTS idx_staff_offices_office_id ON staff_offices(office_id);

-- Eyefinity integration indexes
CREATE INDEX IF NOT EXISTS idx_staff_eyefinity_staff_id ON staff(eyefinity_staff_id);
CREATE INDEX IF NOT EXISTS idx_staff_eyefinity_provider_id ON staff(eyefinity_provider_id);
CREATE INDEX IF NOT EXISTS idx_offices_eyefinity_location_id ON offices(eyefinity_location_id);
CREATE INDEX IF NOT EXISTS idx_patients_eyefinity_patient_id ON patients(eyefinity_patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_eyefinity_id ON appointments(eyefinity_appointment_id);
CREATE INDEX IF NOT EXISTS idx_exams_eyefinity_exam_id ON exams(eyefinity_exam_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_eyefinity_rx_id ON prescriptions(eyefinity_rx_id);
CREATE INDEX IF NOT EXISTS idx_orders_eyefinity_order_id ON orders(eyefinity_order_id);

-- Patient management indexes
CREATE INDEX IF NOT EXISTS idx_patients_company_id ON patients(company_id);
CREATE INDEX IF NOT EXISTS idx_patients_last_name ON patients(last_name);
CREATE INDEX IF NOT EXISTS idx_patients_status ON patients(status);
CREATE INDEX IF NOT EXISTS idx_patient_insurance_patient_id ON patient_insurance(patient_id);
CREATE INDEX IF NOT EXISTS idx_patient_insurance_active ON patient_insurance(is_active);

-- Appointment indexes
CREATE INDEX IF NOT EXISTS idx_appointments_company_id ON appointments(company_id);
CREATE INDEX IF NOT EXISTS idx_appointments_office_id ON appointments(office_id);
CREATE INDEX IF NOT EXISTS idx_appointments_patient_id ON appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_provider_id ON appointments(provider_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON appointments(status);

-- Clinical data indexes
CREATE INDEX IF NOT EXISTS idx_encounters_patient_id ON encounters(patient_id);
CREATE INDEX IF NOT EXISTS idx_encounters_appointment_id ON encounters(appointment_id);
CREATE INDEX IF NOT EXISTS idx_encounters_date ON encounters(encounter_date);
CREATE INDEX IF NOT EXISTS idx_exams_patient_id ON exams(patient_id);
CREATE INDEX IF NOT EXISTS idx_exams_encounter_id ON exams(encounter_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_patient_id ON prescriptions(patient_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_status ON prescriptions(status);

-- Orders indexes
CREATE INDEX IF NOT EXISTS idx_orders_patient_id ON orders(patient_id);
CREATE INDEX IF NOT EXISTS idx_orders_office_id ON orders(office_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_order_date ON orders(order_date);

-- Recalls indexes
CREATE INDEX IF NOT EXISTS idx_recalls_patient_id ON recalls(patient_id);
CREATE INDEX IF NOT EXISTS idx_recalls_office_id ON recalls(office_id);
CREATE INDEX IF NOT EXISTS idx_recalls_due_date ON recalls(due_date);
CREATE INDEX IF NOT EXISTS idx_recalls_status ON recalls(status);

-- Sync logs indexes
CREATE INDEX IF NOT EXISTS idx_sync_logs_company_id ON sync_logs(company_id);
CREATE INDEX IF NOT EXISTS idx_sync_logs_entity_type ON sync_logs(entity_type);
CREATE INDEX IF NOT EXISTS idx_sync_logs_started_at ON sync_logs(started_at DESC);
CREATE INDEX IF NOT EXISTS idx_sync_logs_status ON sync_logs(status);

-- =====================================================
-- INSURANCE BENEFIT VERIFICATION
-- =====================================================

CREATE TABLE IF NOT EXISTS payer_credentials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  office_id UUID REFERENCES offices(id) ON DELETE CASCADE,
  payer_type TEXT NOT NULL CHECK (payer_type IN ('vsp', 'eyemed', 'davis-vision', 'spectera', 'superior-vision')),
  portal_username TEXT NOT NULL,
  portal_password_encrypted TEXT NOT NULL,
  mfa_method TEXT CHECK (mfa_method IN ('none', 'email', 'sms', 'totp')),
  mfa_secret_encrypted TEXT,
  portal_url TEXT,
  last_login_at TIMESTAMPTZ,
  last_login_status TEXT,
  is_active BOOLEAN DEFAULT true,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(company_id, office_id, payer_type)
);

CREATE TABLE IF NOT EXISTS verification_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  office_id UUID REFERENCES offices(id),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
  payer_type TEXT NOT NULL,
  member_id TEXT NOT NULL,
  subscriber_dob DATE,
  patient_dob DATE,
  relationship TEXT DEFAULT 'self',
  status TEXT NOT NULL DEFAULT 'queued' CHECK (status IN (
    'queued', 'in_progress', 'mfa_waiting', 'completed', 'failed', 'expired'
  )),
  priority INTEGER DEFAULT 5,
  attempts INTEGER DEFAULT 0,
  max_attempts INTEGER DEFAULT 3,
  last_error TEXT,
  worker_id TEXT,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  mfa_requested_at TIMESTAMPTZ,
  mfa_code TEXT,
  triggered_by TEXT DEFAULT 'manual',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS verification_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES verification_jobs(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  payer_type TEXT NOT NULL,
  is_eligible BOOLEAN NOT NULL,
  eligibility_status TEXT,
  plan_name TEXT,
  plan_type TEXT,
  effective_date DATE,
  termination_date DATE,
  exam_copay DECIMAL(8,2),
  frames_allowance DECIMAL(8,2),
  frames_copay DECIMAL(8,2),
  lenses_copay DECIMAL(8,2),
  contacts_allowance DECIMAL(8,2),
  contacts_copay DECIMAL(8,2),
  exam_eligible_date DATE,
  frames_eligible_date DATE,
  lenses_eligible_date DATE,
  contacts_eligible_date DATE,
  raw_benefits JSONB DEFAULT '{}',
  raw_html TEXT,
  parsed_by TEXT DEFAULT 'claude',
  confidence_score DECIMAL(3,2),
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Verification indexes
CREATE INDEX IF NOT EXISTS idx_payer_credentials_company ON payer_credentials(company_id);
CREATE INDEX IF NOT EXISTS idx_payer_credentials_active ON payer_credentials(is_active);
CREATE INDEX IF NOT EXISTS idx_verification_jobs_status ON verification_jobs(status);
CREATE INDEX IF NOT EXISTS idx_verification_jobs_patient ON verification_jobs(patient_id);
CREATE INDEX IF NOT EXISTS idx_verification_jobs_priority ON verification_jobs(priority, created_at);
CREATE INDEX IF NOT EXISTS idx_verification_jobs_appointment ON verification_jobs(appointment_id);
CREATE INDEX IF NOT EXISTS idx_verification_results_patient ON verification_results(patient_id);
CREATE INDEX IF NOT EXISTS idx_verification_results_job ON verification_results(job_id);
CREATE INDEX IF NOT EXISTS idx_verification_results_expires ON verification_results(expires_at);

-- =====================================================
-- TRIGGERS FOR AUTO-UPDATE TIMESTAMPS
-- =====================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop existing triggers
DROP TRIGGER IF EXISTS update_accounts_updated_at ON accounts;
DROP TRIGGER IF EXISTS update_companies_updated_at ON companies;
DROP TRIGGER IF EXISTS update_offices_updated_at ON offices;
DROP TRIGGER IF EXISTS update_staff_updated_at ON staff;
DROP TRIGGER IF EXISTS update_patients_updated_at ON patients;
DROP TRIGGER IF EXISTS update_patient_insurance_updated_at ON patient_insurance;
DROP TRIGGER IF EXISTS update_appointments_updated_at ON appointments;
DROP TRIGGER IF EXISTS update_encounters_updated_at ON encounters;
DROP TRIGGER IF EXISTS update_exams_updated_at ON exams;
DROP TRIGGER IF EXISTS update_prescriptions_updated_at ON prescriptions;
DROP TRIGGER IF EXISTS update_orders_updated_at ON orders;
DROP TRIGGER IF EXISTS update_recalls_updated_at ON recalls;
DROP TRIGGER IF EXISTS update_payer_credentials_updated_at ON payer_credentials;
DROP TRIGGER IF EXISTS update_verification_jobs_updated_at ON verification_jobs;

-- Create triggers
CREATE TRIGGER update_accounts_updated_at BEFORE UPDATE ON accounts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_companies_updated_at BEFORE UPDATE ON companies FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_offices_updated_at BEFORE UPDATE ON offices FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_staff_updated_at BEFORE UPDATE ON staff FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_patients_updated_at BEFORE UPDATE ON patients FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_patient_insurance_updated_at BEFORE UPDATE ON patient_insurance FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON appointments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_encounters_updated_at BEFORE UPDATE ON encounters FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_exams_updated_at BEFORE UPDATE ON exams FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_prescriptions_updated_at BEFORE UPDATE ON prescriptions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_recalls_updated_at BEFORE UPDATE ON recalls FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_payer_credentials_updated_at BEFORE UPDATE ON payer_credentials FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_verification_jobs_updated_at BEFORE UPDATE ON verification_jobs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- ROW LEVEL SECURITY (RLS)
-- =====================================================

ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE offices ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff_offices ENABLE ROW LEVEL SECURITY;
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE patient_insurance ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE encounters ENABLE ROW LEVEL SECURITY;
ALTER TABLE exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE prescriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE recalls ENABLE ROW LEVEL SECURITY;
ALTER TABLE sync_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE payer_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE verification_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE verification_results ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "Allow all operations on accounts" ON accounts;
DROP POLICY IF EXISTS "Allow all operations on companies" ON companies;
DROP POLICY IF EXISTS "Allow all operations on offices" ON offices;
DROP POLICY IF EXISTS "Allow all operations on staff" ON staff;
DROP POLICY IF EXISTS "Allow all operations on staff_offices" ON staff_offices;
DROP POLICY IF EXISTS "Allow all operations on patients" ON patients;
DROP POLICY IF EXISTS "Allow all operations on patient_insurance" ON patient_insurance;
DROP POLICY IF EXISTS "Allow all operations on appointments" ON appointments;
DROP POLICY IF EXISTS "Allow all operations on encounters" ON encounters;
DROP POLICY IF EXISTS "Allow all operations on exams" ON exams;
DROP POLICY IF EXISTS "Allow all operations on prescriptions" ON prescriptions;
DROP POLICY IF EXISTS "Allow all operations on orders" ON orders;
DROP POLICY IF EXISTS "Allow all operations on recalls" ON recalls;
DROP POLICY IF EXISTS "Allow all operations on sync_logs" ON sync_logs;
DROP POLICY IF EXISTS "Allow all operations on payer_credentials" ON payer_credentials;
DROP POLICY IF EXISTS "Allow all operations on verification_jobs" ON verification_jobs;
DROP POLICY IF EXISTS "Allow all operations on verification_results" ON verification_results;

-- Create permissive policies (for development - restrict in production)
CREATE POLICY "Allow all operations on accounts" ON accounts FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on companies" ON companies FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on offices" ON offices FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on staff" ON staff FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on staff_offices" ON staff_offices FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on patients" ON patients FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on patient_insurance" ON patient_insurance FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on appointments" ON appointments FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on encounters" ON encounters FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on exams" ON exams FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on prescriptions" ON prescriptions FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on orders" ON orders FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on recalls" ON recalls FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on sync_logs" ON sync_logs FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on payer_credentials" ON payer_credentials FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on verification_jobs" ON verification_jobs FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on verification_results" ON verification_results FOR ALL USING (true) WITH CHECK (true);
