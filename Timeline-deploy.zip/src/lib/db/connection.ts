/**
 * PostgreSQL Database Connection — API Proxy Client
 *
 * Drop-in replacement for the Supabase SDK client.
 * Instead of connecting to Supabase directly, proxies all queries
 * through the /api/db/crud endpoint with tenant-scoped RLS.
 *
 * The global fetch interceptor in main.jsx auto-injects the Bearer token.
 */

const CRUD_ENDPOINT = '/api/db/crud';

// ============================================================
// ApiQueryBuilder — Thenable fluent query builder
// ============================================================

class ApiQueryBuilder {
  private _table: string;
  private _operation: string = 'select';
  private _columns: string = '*';
  private _filters: Array<{ column: string; op: string; value: any }> = [];
  private _orFilters: string[] = [];
  private _orderClauses: Array<{ column: string; ascending?: boolean }> = [];
  private _limitVal: number | null = null;
  private _offsetVal: number | null = null;
  private _rangeFrom: number | null = null;
  private _rangeTo: number | null = null;
  private _singleRow: boolean = false;
  private _maybeSingle: boolean = false;
  private _insertData: any = null;
  private _updateData: any = null;
  private _upsertData: any = null;
  private _upsertConflict: string | null = null;
  private _countMode: string | null = null;
  private _headOnly: boolean = false;

  constructor(table: string) {
    this._table = table;
  }

  // --- Operations ---

  select(columns?: string, options?: { count?: string; head?: boolean }) {
    // If called after insert/update/upsert, don't override — it just means "return data"
    // (Supabase uses .select() after mutations to indicate RETURNING *)
    if (!['insert', 'update', 'upsert'].includes(this._operation)) {
      this._operation = 'select';
    }
    this._columns = columns || '*';
    if (options?.count === 'exact') this._countMode = 'exact';
    if (options?.head) this._headOnly = true;
    return this;
  }

  insert(data: any) {
    this._operation = 'insert';
    this._insertData = data;
    return this;
  }

  update(data: any) {
    this._operation = 'update';
    this._updateData = data;
    return this;
  }

  upsert(data: any, options?: { onConflict?: string }) {
    this._operation = 'upsert';
    this._upsertData = data;
    this._upsertConflict = options?.onConflict || null;
    return this;
  }

  delete() {
    this._operation = 'delete';
    return this;
  }

  // --- Filters ---

  eq(column: string, value: any) {
    this._filters.push({ column, op: '=', value });
    return this;
  }

  neq(column: string, value: any) {
    this._filters.push({ column, op: '!=', value });
    return this;
  }

  gt(column: string, value: any) {
    this._filters.push({ column, op: '>', value });
    return this;
  }

  gte(column: string, value: any) {
    this._filters.push({ column, op: '>=', value });
    return this;
  }

  lt(column: string, value: any) {
    this._filters.push({ column, op: '<', value });
    return this;
  }

  lte(column: string, value: any) {
    this._filters.push({ column, op: '<=', value });
    return this;
  }

  in(column: string, values: any[]) {
    this._filters.push({ column, op: 'IN', value: values });
    return this;
  }

  is(column: string, value: any) {
    if (value === null) {
      this._filters.push({ column, op: 'IS NULL', value: null });
    } else {
      this._filters.push({ column, op: 'IS NOT NULL', value: null });
    }
    return this;
  }

  or(filterString: string) {
    this._orFilters.push(filterString);
    return this;
  }

  ilike(column: string, pattern: string) {
    this._filters.push({ column, op: 'ILIKE', value: pattern });
    return this;
  }

  like(column: string, pattern: string) {
    this._filters.push({ column, op: 'LIKE', value: pattern });
    return this;
  }

  match(filterObj: Record<string, any>) {
    for (const [key, value] of Object.entries(filterObj)) {
      this._filters.push({ column: key, op: '=', value });
    }
    return this;
  }

  // --- Result modifiers ---

  order(column: string, options?: { ascending?: boolean }) {
    this._orderClauses.push({ column, ascending: options?.ascending });
    return this;
  }

  limit(n: number) {
    this._limitVal = n;
    return this;
  }

  range(from: number, to: number) {
    this._rangeFrom = from;
    this._rangeTo = to;
    return this;
  }

  single() {
    this._singleRow = true;
    this._limitVal = 1;
    return this;
  }

  maybeSingle() {
    this._maybeSingle = true;
    this._limitVal = 1;
    return this;
  }

  // --- Thenable execution ---

  then(resolve: (value: any) => void, reject?: (reason: any) => void) {
    this._execute().then(resolve, reject);
  }

  private async _execute(): Promise<{ data: any; error: any; count?: number }> {
    try {
      const body: any = {
        table: this._table,
        operation: this._operation,
        columns: this._columns,
        filters: this._filters,
        orFilters: this._orFilters,
        order: this._orderClauses,
        single: this._singleRow,
        maybeSingle: this._maybeSingle,
      };

      if (this._limitVal !== null) body.limit = this._limitVal;
      if (this._offsetVal !== null) body.offset = this._offsetVal;
      if (this._rangeFrom !== null) body.rangeFrom = this._rangeFrom;
      if (this._rangeTo !== null) body.rangeTo = this._rangeTo;
      if (this._countMode) body.countMode = this._countMode;
      if (this._headOnly) body.headOnly = true;

      if (this._operation === 'insert') body.data = this._insertData;
      if (this._operation === 'update') body.data = this._updateData;
      if (this._operation === 'upsert') {
        body.data = this._upsertData;
        if (this._upsertConflict) body.upsertConflict = this._upsertConflict;
      }

      const response = await fetch(CRUD_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        const errBody = await response.json().catch(() => ({ error: response.statusText }));
        return { data: null, error: errBody.error || { message: response.statusText } };
      }

      return await response.json();
    } catch (err: any) {
      return { data: null, error: { message: err.message || 'Network error' } };
    }
  }
}

// ============================================================
// ApiProxyClient — Drop-in replacement for SupabaseClient
// ============================================================

class ApiProxyClient {
  from(table: string): ApiQueryBuilder {
    return new ApiQueryBuilder(table);
  }

  async rpc(funcName: string, params?: Record<string, any>): Promise<{ data: any; error: any }> {
    try {
      const response = await fetch(CRUD_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          operation: 'rpc',
          rpcName: funcName,
          rpcParams: params || {},
        }),
      });

      if (!response.ok) {
        const errBody = await response.json().catch(() => ({ error: response.statusText }));
        return { data: null, error: errBody.error || { message: response.statusText } };
      }

      return await response.json();
    } catch (err: any) {
      return { data: null, error: { message: err.message || 'Network error' } };
    }
  }
}

// ============================================================
// Singleton + Exported API (same signatures as before)
// ============================================================

let proxyClient: ApiProxyClient | null = null;

/**
 * Get database client (API proxy, drop-in for SupabaseClient)
 */
export function getSupabase(): ApiProxyClient {
  if (!proxyClient) {
    proxyClient = new ApiProxyClient();
  }
  return proxyClient;
}

/**
 * Set tenant context for row-level security
 */
export async function setTenantContext(accountId: string): Promise<void> {
  try {
    const client = getSupabase();
    await client.rpc('set_tenant_context', { account_id: accountId });
  } catch (error) {
    console.error('Failed to set tenant context:', error);
  }
}

/**
 * Execute a query
 */
export async function query<T = any>(
  table: string,
  options?: {
    select?: string;
    filter?: Record<string, any>;
    order?: { column: string; ascending?: boolean };
    limit?: number;
  }
): Promise<T[]> {
  const db = getSupabase();
  let q = db.from(table).select(options?.select || '*');

  if (options?.filter) {
    for (const [key, value] of Object.entries(options.filter)) {
      q = q.eq(key, value);
    }
  }

  if (options?.order) {
    q = q.order(options.order.column, { ascending: options.order.ascending ?? false });
  }

  if (options?.limit) {
    q = q.limit(options.limit);
  }

  const { data, error } = await q;

  if (error) throw error;
  return (data || []) as T[];
}

/**
 * Get single row by ID
 */
export async function queryOne<T = any>(
  table: string,
  id: string
): Promise<T | null> {
  const db = getSupabase();
  const { data, error } = await db
    .from(table)
    .select('*')
    .eq('id', id)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  return data as T | null;
}

/**
 * Insert a row
 */
export async function insert<T = any>(
  table: string,
  data: Record<string, any>
): Promise<T> {
  const db = getSupabase();
  const { data: result, error } = await db
    .from(table)
    .insert(data)
    .select()
    .single();

  if (error) throw error;
  return result as T;
}

/**
 * Upsert (insert or update on conflict)
 */
export async function upsert<T = any>(
  table: string,
  data: Record<string, any>,
  onConflict?: string
): Promise<T> {
  const db = getSupabase();
  const { data: result, error } = await db
    .from(table)
    .upsert(data, { onConflict })
    .select()
    .single();

  if (error) throw error;
  return result as T;
}

/**
 * Update rows
 */
export async function update<T = any>(
  table: string,
  data: Record<string, any>,
  filter: Record<string, any>
): Promise<T[]> {
  const db = getSupabase();
  let q = db.from(table).update(data);

  for (const [key, value] of Object.entries(filter)) {
    q = q.eq(key, value);
  }

  const { data: result, error } = await q.select();

  if (error) throw error;
  return (result || []) as T[];
}

/**
 * Delete rows
 */
export async function deleteRows(
  table: string,
  filter: Record<string, any>
): Promise<number> {
  const db = getSupabase();
  let q = db.from(table).delete();

  for (const [key, value] of Object.entries(filter)) {
    q = q.eq(key, value);
  }

  const { error, count } = await q;

  if (error) throw error;
  return count || 0;
}

/**
 * Execute raw SQL (proxied through RPC)
 */
export async function rawQuery<T = any>(sql: string): Promise<T[]> {
  const db = getSupabase();
  const { data, error } = await db.rpc('exec_sql', { query: sql });

  if (error) throw error;
  return (data || []) as T[];
}

/**
 * Check if database is connected
 */
export async function isConnected(): Promise<boolean> {
  try {
    const db = getSupabase();
    const { error } = await db.from('accounts').select('id').limit(1);
    return !error;
  } catch {
    return false;
  }
}

export default {
  getSupabase,
  query,
  queryOne,
  insert,
  upsert,
  update,
  deleteRows,
  rawQuery,
  isConnected,
};
