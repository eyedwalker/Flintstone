/**
 * Migration: Create call_enrichments table
 * Stores AI call transcripts, sentiment, and staff ratings
 * Linked to Twilio calls via call_sid (globally unique)
 */

CREATE TABLE IF NOT EXISTS call_enrichments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  office_id UUID REFERENCES offices(id) ON DELETE SET NULL,
  call_sid TEXT NOT NULL UNIQUE,
  from_phone TEXT,
  to_phone TEXT,
  direction TEXT,
  duration_seconds INTEGER,
  sentiment_score NUMERIC(3,1),
  emotion TEXT,
  emotion_confidence NUMERIC(3,2),
  escalation_needed BOOLEAN DEFAULT FALSE,
  escalation_reason TEXT,
  ai_performance_score NUMERIC(3,1),
  staff_rating TEXT CHECK (staff_rating IN ('thumbs_up', 'thumbs_down')),
  staff_notes TEXT,
  reviewed_by TEXT,
  reviewed_at TIMESTAMPTZ,
  transcript TEXT,
  recording_url TEXT,
  call_started_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_call_enrichments_call_sid ON call_enrichments(call_sid);
CREATE INDEX IF NOT EXISTS idx_call_enrichments_company_id ON call_enrichments(company_id);
CREATE INDEX IF NOT EXISTS idx_call_enrichments_created_at ON call_enrichments(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_call_enrichments_escalation ON call_enrichments(escalation_needed) WHERE escalation_needed = TRUE;

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_call_enrichments_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS call_enrichments_updated_at ON call_enrichments;
CREATE TRIGGER call_enrichments_updated_at
  BEFORE UPDATE ON call_enrichments
  FOR EACH ROW
  EXECUTE FUNCTION update_call_enrichments_updated_at();

-- Grant access to PostgREST roles (required for Supabase JS client)
GRANT ALL ON call_enrichments TO anon;
GRANT ALL ON call_enrichments TO authenticated;
GRANT ALL ON call_enrichments TO service_role;
