-- Form Submissions Cache Table
-- Run this in Supabase SQL Editor to enable form persistence

CREATE TABLE IF NOT EXISTS form_submissions_cache (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  submission_id TEXT NOT NULL,
  access_token TEXT UNIQUE NOT NULL,
  submission_data JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast token lookup
CREATE INDEX IF NOT EXISTS idx_form_submissions_token ON form_submissions_cache(access_token);

-- Enable Row Level Security (but allow all for now)
ALTER TABLE form_submissions_cache ENABLE ROW LEVEL SECURITY;

-- Allow all operations (adjust for production)
CREATE POLICY "Allow all operations on form_submissions_cache" ON form_submissions_cache
  FOR ALL USING (true) WITH CHECK (true);
