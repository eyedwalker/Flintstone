-- Add Eyefinity-specific fields to companies table
ALTER TABLE companies 
ADD COLUMN IF NOT EXISTS tenant_uid TEXT,
ADD COLUMN IF NOT EXISTS oauth_host TEXT DEFAULT 'api-sandbox.eyefinity.com',
ADD COLUMN IF NOT EXISTS api_base_url TEXT DEFAULT 'https://api-sandbox.eyefinity.com';

-- Rename existing fields to match Eyefinity naming
-- eyefinity_api_key -> epm_client_id
-- eyefinity_api_secret -> epm_client_secret
-- eyefinity_company_id can stay as is (optional identifier)

COMMENT ON COLUMN companies.tenant_uid IS 'Eyefinity Tenant UID (12345678-1234-1234-1234-123456789012)';
COMMENT ON COLUMN companies.oauth_host IS 'Eyefinity OAuth host (api-sandbox.eyefinity.com or api.eyefinity.com)';
COMMENT ON COLUMN companies.api_base_url IS 'Eyefinity API base URL';
