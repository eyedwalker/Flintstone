-- Patient Frame Scanner & Measurement Tool Database Schema
-- Migration: Add tables for frame scanning, favorites, and measurements

-- Frame catalog (for UPC lookup)
CREATE TABLE IF NOT EXISTS frame_catalog (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  upc_code VARCHAR(13) UNIQUE NOT NULL,
  manufacturer VARCHAR(255),
  brand VARCHAR(255),
  model_name VARCHAR(255),
  model_number VARCHAR(100),
  color_name VARCHAR(100),
  color_code VARCHAR(50),
  
  -- Dimensions (in mm)
  lens_width INTEGER,
  bridge_width INTEGER,
  temple_length INTEGER,
  frame_width INTEGER,
  
  -- Details
  material VARCHAR(100),
  frame_type VARCHAR(50), -- 'full-rim', 'semi-rimless', 'rimless'
  shape VARCHAR(50), -- 'rectangle', 'oval', 'round', 'cat-eye', 'aviator', 'wayfarer'
  
  -- Pricing
  wholesale_price DECIMAL(10,2),
  retail_price DECIMAL(10,2),
  
  -- Media
  image_url TEXT,
  additional_images JSONB DEFAULT '[]',
  
  -- Metadata
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Patient favorite frames
CREATE TABLE IF NOT EXISTS patient_favorite_frames (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  upc_code VARCHAR(13) NOT NULL,
  frame_name VARCHAR(255),
  frame_manufacturer VARCHAR(255),
  frame_model VARCHAR(255),
  frame_color VARCHAR(100),
  frame_size VARCHAR(50),
  scanned_at TIMESTAMP DEFAULT NOW(),
  image_url TEXT,
  notes TEXT,
  is_purchased BOOLEAN DEFAULT FALSE,
  purchased_at TIMESTAMP,
  
  UNIQUE(patient_id, upc_code)
);

-- Patient measurements
CREATE TABLE IF NOT EXISTS patient_measurements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  measured_at TIMESTAMP DEFAULT NOW(),
  
  -- Measurements in mm
  pd_right DECIMAL(4,1),
  pd_left DECIMAL(4,1),
  pd_total DECIMAL(4,1),
  seg_height_right DECIMAL(4,1),
  seg_height_left DECIMAL(4,1),
  oc_height_right DECIMAL(4,1),
  oc_height_left DECIMAL(4,1),
  
  -- Frame info if wearing during measurement
  frame_id UUID REFERENCES patient_favorite_frames(id) ON DELETE SET NULL,
  
  -- Metadata
  measurement_method VARCHAR(50), -- 'camera', 'lidar', 'manual', 'professional'
  calibration_factor DECIMAL(8,4),
  confidence_score DECIMAL(3,2), -- 0.00 - 1.00
  device_type VARCHAR(100),
  device_model VARCHAR(100),
  has_lidar BOOLEAN DEFAULT FALSE,
  browser_info TEXT,
  
  -- Raw data
  face_landmarks JSONB,
  frame_markers JSONB,
  calibration_data JSONB,
  image_url TEXT,
  
  -- Validation
  verified_by_staff UUID REFERENCES staff(id) ON DELETE SET NULL,
  verified_at TIMESTAMP,
  is_approved BOOLEAN DEFAULT FALSE,
  staff_notes TEXT,
  
  -- Patient notes
  notes TEXT
);

-- Patient access tokens (for passwordless access to scanner)
CREATE TABLE IF NOT EXISTS patient_scanner_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  token VARCHAR(255) UNIQUE NOT NULL,
  token_type VARCHAR(50) DEFAULT 'frame-scanner', -- 'frame-scanner', 'measurements', 'full-access'
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  last_used_at TIMESTAMP,
  uses_count INTEGER DEFAULT 0,
  max_uses INTEGER, -- NULL = unlimited
  is_revoked BOOLEAN DEFAULT FALSE,
  revoked_at TIMESTAMP,
  revoked_by UUID REFERENCES staff(id) ON DELETE SET NULL
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_frame_catalog_upc ON frame_catalog(upc_code);
CREATE INDEX IF NOT EXISTS idx_frame_catalog_brand ON frame_catalog(brand);
CREATE INDEX IF NOT EXISTS idx_frame_catalog_manufacturer ON frame_catalog(manufacturer);

CREATE INDEX IF NOT EXISTS idx_patient_favorites_patient ON patient_favorite_frames(patient_id);
CREATE INDEX IF NOT EXISTS idx_patient_favorites_company ON patient_favorite_frames(company_id);
CREATE INDEX IF NOT EXISTS idx_patient_favorites_upc ON patient_favorite_frames(upc_code);

CREATE INDEX IF NOT EXISTS idx_patient_measurements_patient ON patient_measurements(patient_id);
CREATE INDEX IF NOT EXISTS idx_patient_measurements_company ON patient_measurements(company_id);
CREATE INDEX IF NOT EXISTS idx_patient_measurements_date ON patient_measurements(measured_at);

CREATE INDEX IF NOT EXISTS idx_scanner_tokens_token ON patient_scanner_tokens(token);
CREATE INDEX IF NOT EXISTS idx_scanner_tokens_patient ON patient_scanner_tokens(patient_id);
CREATE INDEX IF NOT EXISTS idx_scanner_tokens_expires ON patient_scanner_tokens(expires_at);

-- Add some sample frame catalog data for testing
INSERT INTO frame_catalog (upc_code, manufacturer, brand, model_name, color_name, lens_width, bridge_width, temple_length, material, frame_type, shape, retail_price, image_url)
VALUES 
  ('123456789012', 'Ray-Ban', 'Ray-Ban', 'Wayfarer Classic', 'Black', 50, 22, 150, 'Acetate', 'full-rim', 'wayfarer', 154.00, '/images/frames/rayban-wayfarer-black.jpg'),
  ('123456789013', 'Oakley', 'Oakley', 'Holbrook', 'Matte Black', 55, 18, 137, 'O-Matter', 'full-rim', 'rectangle', 173.00, '/images/frames/oakley-holbrook.jpg'),
  ('123456789014', 'Warby Parker', 'Warby Parker', 'Haskell', 'Crystal', 49, 20, 145, 'Acetate', 'full-rim', 'round', 95.00, '/images/frames/warby-haskell.jpg')
ON CONFLICT (upc_code) DO NOTHING;

-- Patient face profiles (geometric representation for virtual try-on)
CREATE TABLE IF NOT EXISTS patient_face_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),

  -- Face dimensions in mm
  face_width DECIMAL(5,1),
  face_height DECIMAL(5,1),
  jaw_width DECIMAL(5,1),
  cheekbone_width DECIMAL(5,1),
  forehead_width DECIMAL(5,1),

  -- Face shape classification
  face_shape VARCHAR(20), -- oval, round, square, heart, oblong, diamond
  face_shape_confidence DECIMAL(3,2),

  -- PD measurements
  pd_total DECIMAL(4,1),
  pd_right DECIMAL(4,1),
  pd_left DECIMAL(4,1),

  -- Normalized face outline points (for rendering geometric wireframe)
  outline_points JSONB,

  -- SVG representation of the face geometry
  face_svg TEXT,

  -- Source measurement reference
  measurement_id UUID REFERENCES patient_measurements(id) ON DELETE SET NULL,

  -- Frame recommendation data
  recommended_frame_widths JSONB, -- { min: number, ideal: number, max: number }
  recommended_bridge_widths JSONB,
  recommended_temple_lengths JSONB,

  -- Metadata
  is_active BOOLEAN DEFAULT TRUE,
  source VARCHAR(50), -- 'self_service', 'staff_measured', 'imported'
  notes TEXT,

  UNIQUE(patient_id, company_id) -- one active profile per patient per company
);

CREATE INDEX IF NOT EXISTS idx_face_profiles_patient ON patient_face_profiles(patient_id);
CREATE INDEX IF NOT EXISTS idx_face_profiles_company ON patient_face_profiles(company_id);
CREATE INDEX IF NOT EXISTS idx_face_profiles_shape ON patient_face_profiles(face_shape);

-- Comments for documentation
COMMENT ON TABLE frame_catalog IS 'Catalog of eyeglass frames with UPC codes for lookup';
COMMENT ON TABLE patient_favorite_frames IS 'Patient-scanned favorite frames';
COMMENT ON TABLE patient_measurements IS 'Patient self-service measurements (PD, seg height, OC height)';
COMMENT ON TABLE patient_scanner_tokens IS 'Temporary access tokens for patient scanner links';
