-- Migration script for head movement calibration data storage
-- This adds columns to store 3D facial data and movement sequences

-- Update the patient_measurements table to store depth and movement data
ALTER TABLE IF EXISTS patient_measurements
ADD COLUMN IF NOT EXISTS movement_sequence JSONB,
ADD COLUMN IF NOT EXISTS depth_map JSONB,
ADD COLUMN IF NOT EXISTS has_3d_data BOOLEAN DEFAULT FALSE;

-- Update the patient_face_profiles table to store depth-enhanced face model
ALTER TABLE IF EXISTS patient_face_profile
ADD COLUMN IF NOT EXISTS depth_enhanced_geometry JSONB,
ADD COLUMN IF NOT EXISTS movement_quality_score FLOAT,
ADD COLUMN IF NOT EXISTS reference_frame_id VARCHAR;

-- Add index for efficient querying of 3D-enhanced measurements
CREATE INDEX IF NOT EXISTS idx_patient_measurements_has_3d_data ON patient_measurements(has_3d_data);

-- Create a new table to store movement sequence frames if detailed analysis is needed
CREATE TABLE IF NOT EXISTS patient_movement_frames (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  patient_id VARCHAR NOT NULL,
  company_id VARCHAR NOT NULL,
  measurement_id UUID REFERENCES patient_measurements(id),
  frame_index INTEGER NOT NULL,
  timestamp BIGINT NOT NULL,
  movement_type VARCHAR NOT NULL,
  landmarks JSONB NOT NULL,
  head_pose JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Composite index for efficient retrieval of frames for a measurement
  CONSTRAINT unique_movement_frame UNIQUE(measurement_id, frame_index),
  
  -- Foreign key to ensure data consistency
  FOREIGN KEY (patient_id, company_id) REFERENCES patient(id, company_id)
);

-- Add index for efficient retrieval of movement frames by measurement
CREATE INDEX IF NOT EXISTS idx_patient_movement_frames_measurement_id ON patient_movement_frames(measurement_id);

-- Comments for documentation
COMMENT ON COLUMN patient_measurements.movement_sequence IS 'Summarized movement sequence data from head calibration';
COMMENT ON COLUMN patient_measurements.depth_map IS 'Depth values for key facial landmarks (0-1 where 1 is closest to camera)';
COMMENT ON COLUMN patient_measurements.has_3d_data IS 'Whether this measurement includes 3D-enhanced data';
COMMENT ON COLUMN patient_face_profile.depth_enhanced_geometry IS '3D geometric representation of face including depth information';
COMMENT ON COLUMN patient_face_profile.movement_quality_score IS 'Quality score (0-1) for the movement sequence used for depth estimation';
COMMENT ON COLUMN patient_face_profile.reference_frame_id IS 'ID of the reference frame with most neutral head pose';
