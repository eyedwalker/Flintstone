-- Audit Logs Table for Patient Journey Analytics Dashboard
-- Run this in Supabase SQL Editor to create the table

CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  journey_id TEXT NOT NULL,
  step_id TEXT NOT NULL,
  step_title TEXT,
  patient_id TEXT NOT NULL,
  patient_name TEXT,
  event_type TEXT NOT NULL,
  event_timestamp TIMESTAMPTZ NOT NULL,
  performed_by TEXT,
  performed_by_name TEXT,
  location TEXT,
  step_start_time TIMESTAMPTZ,
  step_end_time TIMESTAMPTZ,
  step_duration NUMERIC,
  wait_time NUMERIC,
  room_id TEXT,
  room_name TEXT,
  room_type TEXT,
  external_system_action TEXT,
  external_system_url TEXT,
  external_patient_id TEXT,
  external_appointment_id TEXT,
  journey_phase TEXT CHECK (journey_phase IN ('pre-visit', 'in-office', 'post-visit')),
  metadata JSONB DEFAULT '{}'::jsonb,
  provider_id TEXT,
  provider_name TEXT,
  office_id TEXT,
  office_name TEXT,
  company_id TEXT,
  outcome TEXT CHECK (outcome IN ('success', 'failed', 'skipped', 'cancelled')),
  error_message TEXT,
  is_overtime BOOLEAN DEFAULT false,
  expected_duration NUMERIC,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_audit_logs_office_id ON audit_logs(office_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_event_timestamp ON audit_logs(event_timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_logs_journey_id ON audit_logs(journey_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_patient_id ON audit_logs(patient_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_event_type ON audit_logs(event_type);
CREATE INDEX IF NOT EXISTS idx_audit_logs_company_id ON audit_logs(company_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_provider_id ON audit_logs(provider_id);
-- Composite index for date-range + office queries (most common dashboard query)
CREATE INDEX IF NOT EXISTS idx_audit_logs_office_timestamp ON audit_logs(office_id, event_timestamp DESC);
