-- Tasks table for patient care workflow
CREATE TABLE IF NOT EXISTS tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID,
  office_id UUID,
  
  title TEXT NOT NULL,
  description TEXT,
  
  -- Task classification
  category TEXT NOT NULL, -- 'clinical', 'administrative', 'follow_up', 'insurance', 'referral', 'other'
  priority TEXT NOT NULL DEFAULT 'medium', -- 'low', 'medium', 'high', 'urgent'
  status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'in_progress', 'completed', 'cancelled', 'blocked'
  
  -- Associations (stored as UUIDs, FK constraints can be added later when tables exist)
  patient_id UUID,
  journey_id UUID,
  assigned_to UUID,
  
  -- Timing
  due_date DATE,
  due_time TIME,
  completed_at TIMESTAMPTZ,
  
  -- Metadata
  notes TEXT,
  tags TEXT[], -- Array of tag strings
  settings JSONB DEFAULT '{}',
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_tasks_company ON tasks(company_id);
CREATE INDEX IF NOT EXISTS idx_tasks_office ON tasks(office_id);
CREATE INDEX IF NOT EXISTS idx_tasks_patient ON tasks(patient_id);
CREATE INDEX IF NOT EXISTS idx_tasks_journey ON tasks(journey_id);
CREATE INDEX IF NOT EXISTS idx_tasks_assigned ON tasks(assigned_to);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_due_date ON tasks(due_date);
CREATE INDEX IF NOT EXISTS idx_tasks_category ON tasks(category);

-- RLS policies (simplified - can be enhanced later when staff table exists)
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

-- Allow all operations for now - add proper isolation later
CREATE POLICY tasks_allow_all ON tasks
  FOR ALL
  USING (true);

-- Trigger for updated_at
CREATE TRIGGER update_tasks_updated_at
  BEFORE UPDATE ON tasks
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
