/**
 * Multi-Tenant Database Schema - Safe Version
 * Handles existing tables/policies gracefully
 */

-- Drop existing policies first to avoid conflicts
DROP POLICY IF EXISTS "Allow all operations on accounts" ON accounts;
DROP POLICY IF EXISTS "Allow all operations on companies" ON companies;
DROP POLICY IF EXISTS "Allow all operations on offices" ON offices;
DROP POLICY IF EXISTS "Allow all operations on staff" ON staff;
DROP POLICY IF EXISTS "Allow all operations on staff_offices" ON staff_offices;

-- Create tables (only if not exists)
CREATE TABLE IF NOT EXISTS accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  eyefinity_company_id TEXT,
  eyefinity_base_url TEXT,
  eyefinity_api_key TEXT,
  eyefinity_api_secret TEXT,
  oauth_token TEXT,
  oauth_refresh_token TEXT,
  oauth_token_expires_at TIMESTAMPTZ,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS offices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  eyefinity_office_id TEXT,
  phone TEXT,
  email TEXT,
  timezone TEXT DEFAULT 'America/Chicago',
  address JSONB,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS staff (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  eyefinity_staff_id TEXT,
  eyefinity_provider_id TEXT,
  email TEXT,
  phone TEXT,
  role TEXT NOT NULL,
  specialty TEXT,
  active BOOLEAN DEFAULT true,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS staff_offices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_id UUID NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  is_primary BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(staff_id, office_id)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_companies_account_id ON companies(account_id);
CREATE INDEX IF NOT EXISTS idx_offices_company_id ON offices(company_id);
CREATE INDEX IF NOT EXISTS idx_staff_offices_staff_id ON staff_offices(staff_id);
CREATE INDEX IF NOT EXISTS idx_staff_offices_office_id ON staff_offices(office_id);
CREATE INDEX IF NOT EXISTS idx_staff_eyefinity_staff_id ON staff(eyefinity_staff_id);
CREATE INDEX IF NOT EXISTS idx_staff_eyefinity_provider_id ON staff(eyefinity_provider_id);
CREATE INDEX IF NOT EXISTS idx_offices_eyefinity_office_id ON offices(eyefinity_office_id);

-- Drop existing update triggers
DROP TRIGGER IF EXISTS update_accounts_updated_at ON accounts;
DROP TRIGGER IF EXISTS update_companies_updated_at ON companies;
DROP TRIGGER IF EXISTS update_offices_updated_at ON offices;
DROP TRIGGER IF EXISTS update_staff_updated_at ON staff;

-- Create or replace the trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
CREATE TRIGGER update_accounts_updated_at
  BEFORE UPDATE ON accounts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_companies_updated_at
  BEFORE UPDATE ON companies
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_offices_updated_at
  BEFORE UPDATE ON offices
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_staff_updated_at
  BEFORE UPDATE ON staff
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE offices ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff_offices ENABLE ROW LEVEL SECURITY;

-- Create permissive policies (for development - restrict in production)
CREATE POLICY "Allow all operations on accounts" ON accounts
  FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Allow all operations on companies" ON companies
  FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Allow all operations on offices" ON offices
  FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Allow all operations on staff" ON staff
  FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Allow all operations on staff_offices" ON staff_offices
  FOR ALL USING (true) WITH CHECK (true);
