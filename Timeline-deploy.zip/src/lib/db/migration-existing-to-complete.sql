/**
 * Migration Script: Update Existing Schema to Complete Schema
 * Safely adds new tables and columns without breaking existing data
 */

-- =====================================================
-- STEP 1: Update existing companies table
-- =====================================================

-- Add missing column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'companies' AND column_name = 'eyefinity_tenant_uid') THEN
    ALTER TABLE companies ADD COLUMN eyefinity_tenant_uid TEXT;
  END IF;
END $$;

-- =====================================================
-- STEP 2: Fix offices table column name
-- =====================================================

-- Rename eyefinity_office_id to eyefinity_location_id if needed
DO $$ 
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns 
             WHERE table_name = 'offices' AND column_name = 'eyefinity_office_id') THEN
    ALTER TABLE offices RENAME COLUMN eyefinity_office_id TO eyefinity_location_id;
  END IF;
END $$;

-- Drop old index and create new one with correct name
DROP INDEX IF EXISTS idx_offices_eyefinity_office_id;
CREATE INDEX IF NOT EXISTS idx_offices_eyefinity_location_id ON offices(eyefinity_location_id);

-- =====================================================
-- STEP 3: Create new tables (only if they don't exist)
-- =====================================================

CREATE TABLE IF NOT EXISTS patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  eyefinity_patient_id TEXT,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  date_of_birth DATE,
  gender TEXT CHECK (gender IN ('male', 'female', 'other', 'unknown')),
  email TEXT,
  phone TEXT,
  mobile_phone TEXT,
  address JSONB DEFAULT '{}',
  emergency_contact JSONB DEFAULT '{}',
  preferred_language TEXT DEFAULT 'en',
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'deceased')),
  notes TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS patient_insurance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  eyefinity_insurance_id TEXT,
  carrier_name TEXT NOT NULL,
  policy_number TEXT,
  group_number TEXT,
  subscriber_name TEXT,
  subscriber_dob DATE,
  relationship_to_subscriber TEXT,
  priority TEXT DEFAULT 'primary' CHECK (priority IN ('primary', 'secondary', 'tertiary')),
  effective_date DATE,
  termination_date DATE,
  is_active BOOLEAN DEFAULT true,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  provider_id UUID REFERENCES staff(id) ON DELETE SET NULL,
  eyefinity_appointment_id TEXT,
  appointment_date TIMESTAMPTZ NOT NULL,
  duration_minutes INTEGER DEFAULT 30,
  appointment_type TEXT NOT NULL,
  status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'confirmed', 'checked_in', 'in_progress', 'completed', 'cancelled', 'no_show')),
  reason_for_visit TEXT,
  notes TEXT,
  reminder_sent BOOLEAN DEFAULT false,
  reminder_sent_at TIMESTAMPTZ,
  checked_in_at TIMESTAMPTZ,
  checked_out_at TIMESTAMPTZ,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS encounters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  provider_id UUID REFERENCES staff(id) ON DELETE SET NULL,
  encounter_date TIMESTAMPTZ NOT NULL,
  encounter_type TEXT NOT NULL,
  chief_complaint TEXT,
  subjective TEXT,
  objective TEXT,
  assessment TEXT,
  plan TEXT,
  status TEXT DEFAULT 'open' CHECK (status IN ('open', 'signed', 'amended', 'corrected')),
  signed_at TIMESTAMPTZ,
  signed_by UUID REFERENCES staff(id) ON DELETE SET NULL,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS exams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  encounter_id UUID NOT NULL REFERENCES encounters(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  eyefinity_exam_id TEXT,
  exam_date DATE NOT NULL,
  exam_type TEXT NOT NULL,
  visual_acuity JSONB DEFAULT '{}',
  refraction JSONB DEFAULT '{}',
  intraocular_pressure JSONB DEFAULT '{}',
  dilated BOOLEAN DEFAULT false,
  findings TEXT,
  diagnosis_codes TEXT[],
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS prescriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES encounters(id) ON DELETE SET NULL,
  provider_id UUID REFERENCES staff(id) ON DELETE SET NULL,
  eyefinity_rx_id TEXT,
  prescription_date DATE NOT NULL,
  prescription_type TEXT NOT NULL CHECK (prescription_type IN ('eyeglasses', 'contact_lenses', 'medication')),
  od_sphere DECIMAL(5,2),
  od_cylinder DECIMAL(5,2),
  od_axis INTEGER,
  od_add DECIMAL(4,2),
  os_sphere DECIMAL(5,2),
  os_cylinder DECIMAL(5,2),
  os_axis INTEGER,
  os_add DECIMAL(4,2),
  pd DECIMAL(4,1),
  expiration_date DATE,
  medication_name TEXT,
  medication_dosage TEXT,
  medication_instructions TEXT,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'expired', 'replaced', 'cancelled')),
  notes TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  prescription_id UUID REFERENCES prescriptions(id) ON DELETE SET NULL,
  eyefinity_order_id TEXT,
  order_date DATE NOT NULL,
  order_type TEXT NOT NULL,
  frame_description TEXT,
  lens_type TEXT,
  lens_material TEXT,
  coatings TEXT[],
  total_price DECIMAL(10,2),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'ordered', 'received', 'ready', 'dispensed', 'cancelled')),
  ordered_date DATE,
  expected_date DATE,
  received_date DATE,
  dispensed_date DATE,
  notes TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS recalls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  recall_type TEXT NOT NULL,
  due_date DATE NOT NULL,
  last_exam_date DATE,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'contacted', 'scheduled', 'completed', 'declined', 'cancelled')),
  contact_method TEXT,
  contacted_at TIMESTAMPTZ,
  notes TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sync_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  sync_type TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  eyefinity_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('success', 'partial', 'failed', 'skipped')),
  records_processed INTEGER DEFAULT 0,
  records_created INTEGER DEFAULT 0,
  records_updated INTEGER DEFAULT 0,
  records_failed INTEGER DEFAULT 0,
  error_message TEXT,
  metadata JSONB DEFAULT '{}',
  started_at TIMESTAMPTZ NOT NULL,
  completed_at TIMESTAMPTZ,
  duration_ms INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- STEP 4: Create all indexes
-- =====================================================

-- Patient indexes
CREATE INDEX IF NOT EXISTS idx_patients_eyefinity_patient_id ON patients(eyefinity_patient_id);
CREATE INDEX IF NOT EXISTS idx_patients_company_id ON patients(company_id);
CREATE INDEX IF NOT EXISTS idx_patients_last_name ON patients(last_name);
CREATE INDEX IF NOT EXISTS idx_patients_status ON patients(status);
CREATE INDEX IF NOT EXISTS idx_patient_insurance_patient_id ON patient_insurance(patient_id);
CREATE INDEX IF NOT EXISTS idx_patient_insurance_active ON patient_insurance(is_active);

-- Appointment indexes
CREATE INDEX IF NOT EXISTS idx_appointments_eyefinity_id ON appointments(eyefinity_appointment_id);
CREATE INDEX IF NOT EXISTS idx_appointments_company_id ON appointments(company_id);
CREATE INDEX IF NOT EXISTS idx_appointments_office_id ON appointments(office_id);
CREATE INDEX IF NOT EXISTS idx_appointments_patient_id ON appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_provider_id ON appointments(provider_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON appointments(status);

-- Clinical data indexes
CREATE INDEX IF NOT EXISTS idx_encounters_patient_id ON encounters(patient_id);
CREATE INDEX IF NOT EXISTS idx_encounters_appointment_id ON encounters(appointment_id);
CREATE INDEX IF NOT EXISTS idx_encounters_date ON encounters(encounter_date);
CREATE INDEX IF NOT EXISTS idx_exams_patient_id ON exams(patient_id);
CREATE INDEX IF NOT EXISTS idx_exams_encounter_id ON exams(encounter_id);
CREATE INDEX IF NOT EXISTS idx_exams_eyefinity_exam_id ON exams(eyefinity_exam_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_patient_id ON prescriptions(patient_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_eyefinity_rx_id ON prescriptions(eyefinity_rx_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_status ON prescriptions(status);

-- Orders indexes
CREATE INDEX IF NOT EXISTS idx_orders_eyefinity_order_id ON orders(eyefinity_order_id);
CREATE INDEX IF NOT EXISTS idx_orders_patient_id ON orders(patient_id);
CREATE INDEX IF NOT EXISTS idx_orders_office_id ON orders(office_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_order_date ON orders(order_date);

-- Recalls indexes
CREATE INDEX IF NOT EXISTS idx_recalls_patient_id ON recalls(patient_id);
CREATE INDEX IF NOT EXISTS idx_recalls_office_id ON recalls(office_id);
CREATE INDEX IF NOT EXISTS idx_recalls_due_date ON recalls(due_date);
CREATE INDEX IF NOT EXISTS idx_recalls_status ON recalls(status);

-- Sync logs indexes
CREATE INDEX IF NOT EXISTS idx_sync_logs_company_id ON sync_logs(company_id);
CREATE INDEX IF NOT EXISTS idx_sync_logs_entity_type ON sync_logs(entity_type);
CREATE INDEX IF NOT EXISTS idx_sync_logs_started_at ON sync_logs(started_at DESC);
CREATE INDEX IF NOT EXISTS idx_sync_logs_status ON sync_logs(status);

-- =====================================================
-- STEP 5: Create triggers for new tables
-- =====================================================

DROP TRIGGER IF EXISTS update_patients_updated_at ON patients;
DROP TRIGGER IF EXISTS update_patient_insurance_updated_at ON patient_insurance;
DROP TRIGGER IF EXISTS update_appointments_updated_at ON appointments;
DROP TRIGGER IF EXISTS update_encounters_updated_at ON encounters;
DROP TRIGGER IF EXISTS update_exams_updated_at ON exams;
DROP TRIGGER IF EXISTS update_prescriptions_updated_at ON prescriptions;
DROP TRIGGER IF EXISTS update_orders_updated_at ON orders;
DROP TRIGGER IF EXISTS update_recalls_updated_at ON recalls;

CREATE TRIGGER update_patients_updated_at BEFORE UPDATE ON patients FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_patient_insurance_updated_at BEFORE UPDATE ON patient_insurance FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON appointments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_encounters_updated_at BEFORE UPDATE ON encounters FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_exams_updated_at BEFORE UPDATE ON exams FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_prescriptions_updated_at BEFORE UPDATE ON prescriptions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_recalls_updated_at BEFORE UPDATE ON recalls FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- STEP 6: Enable RLS on new tables
-- =====================================================

ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE patient_insurance ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE encounters ENABLE ROW LEVEL SECURITY;
ALTER TABLE exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE prescriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE recalls ENABLE ROW LEVEL SECURITY;
ALTER TABLE sync_logs ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- STEP 7: Create RLS policies for new tables
-- =====================================================

DROP POLICY IF EXISTS "Allow all operations on patients" ON patients;
DROP POLICY IF EXISTS "Allow all operations on patient_insurance" ON patient_insurance;
DROP POLICY IF EXISTS "Allow all operations on appointments" ON appointments;
DROP POLICY IF EXISTS "Allow all operations on encounters" ON encounters;
DROP POLICY IF EXISTS "Allow all operations on exams" ON exams;
DROP POLICY IF EXISTS "Allow all operations on prescriptions" ON prescriptions;
DROP POLICY IF EXISTS "Allow all operations on orders" ON orders;
DROP POLICY IF EXISTS "Allow all operations on recalls" ON recalls;
DROP POLICY IF EXISTS "Allow all operations on sync_logs" ON sync_logs;

CREATE POLICY "Allow all operations on patients" ON patients FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on patient_insurance" ON patient_insurance FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on appointments" ON appointments FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on encounters" ON encounters FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on exams" ON exams FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on prescriptions" ON prescriptions FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on orders" ON orders FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on recalls" ON recalls FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on sync_logs" ON sync_logs FOR ALL USING (true) WITH CHECK (true);
