-- Multi-Tenant Database Schema for Patient Care Application
-- Hierarchy: Account → Company → Office

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ====================
-- ACCOUNTS TABLE (Top Level Tenant)
-- ====================
CREATE TABLE IF NOT EXISTS accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  settings JSONB NOT NULL DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'cancelled'))
);

CREATE INDEX idx_accounts_status ON accounts(status);
CREATE INDEX idx_accounts_created_at ON accounts(created_at);

-- ====================
-- COMPANIES TABLE (Mid Level Tenant)
-- ====================
CREATE TABLE IF NOT EXISTS companies (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  eyefinity_company_id TEXT UNIQUE,
  eyefinity_api_key TEXT,
  eyefinity_api_secret TEXT,
  eyefinity_base_url TEXT,
  oauth_token TEXT,
  oauth_refresh_token TEXT,
  oauth_token_expires_at TIMESTAMP WITH TIME ZONE,
  twilio_account_sid TEXT,
  twilio_auth_token TEXT,
  twilio_phone_number TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  settings JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX idx_companies_account_id ON companies(account_id);
CREATE INDEX idx_companies_eyefinity_company_id ON companies(eyefinity_company_id);
CREATE INDEX idx_companies_created_at ON companies(created_at);

-- ====================
-- OFFICES TABLE (Bottom Level Tenant)
-- ====================
CREATE TABLE IF NOT EXISTS offices (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  eyefinity_location_id TEXT,
  address JSONB NOT NULL DEFAULT '{}'::jsonb,
  timezone TEXT NOT NULL DEFAULT 'America/Chicago',
  phone TEXT,
  email TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  settings JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX idx_offices_company_id ON offices(company_id);
CREATE INDEX idx_offices_eyefinity_location_id ON offices(eyefinity_location_id);
CREATE INDEX idx_offices_created_at ON offices(created_at);

-- ====================
-- STAFF TABLE
-- ====================
CREATE TABLE IF NOT EXISTS staff (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  role TEXT NOT NULL CHECK (role IN ('doctor', 'technician', 'optician', 'front_desk', 'manager', 'other')),
  eyefinity_provider_id TEXT,
  specialty TEXT,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  settings JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX idx_staff_role ON staff(role);
CREATE INDEX idx_staff_active ON staff(active);
CREATE INDEX idx_staff_eyefinity_provider_id ON staff(eyefinity_provider_id);

-- ====================
-- STAFF-OFFICE JUNCTION TABLE
-- ====================
CREATE TABLE IF NOT EXISTS staff_offices (
  staff_id UUID NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  office_id UUID NOT NULL REFERENCES offices(id) ON DELETE CASCADE,
  is_primary BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  PRIMARY KEY (staff_id, office_id)
);

CREATE INDEX idx_staff_offices_office_id ON staff_offices(office_id);
CREATE INDEX idx_staff_offices_is_primary ON staff_offices(is_primary);

-- ====================
-- TENANT CONTEXT FUNCTION
-- ====================
CREATE OR REPLACE FUNCTION set_tenant_context(account_id UUID)
RETURNS void AS $$
BEGIN
  PERFORM set_config('app.current_account_id', account_id::text, false);
END;
$$ LANGUAGE plpgsql;

-- ====================
-- ROW LEVEL SECURITY POLICIES
-- ====================

-- Enable RLS on all tables
ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE offices ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff_offices ENABLE ROW LEVEL SECURITY;

-- Account isolation policy (strict — no COALESCE fallback)
DROP POLICY IF EXISTS account_isolation ON accounts;
CREATE POLICY account_isolation ON accounts
  USING (
    id = current_setting('app.current_account_id', true)::uuid
  );

-- Company isolation policy (strict)
DROP POLICY IF EXISTS company_isolation ON companies;
CREATE POLICY company_isolation ON companies
  USING (
    account_id = current_setting('app.current_account_id', true)::uuid
  );

-- Office isolation policy (strict)
DROP POLICY IF EXISTS office_isolation ON offices;
CREATE POLICY office_isolation ON offices
  USING (
    company_id IN (
      SELECT id FROM companies
      WHERE account_id = current_setting('app.current_account_id', true)::uuid
    )
  );

-- Staff isolation policy (strict)
DROP POLICY IF EXISTS staff_isolation ON staff;
CREATE POLICY staff_isolation ON staff
  USING (
    id IN (
      SELECT s.id FROM staff s
      JOIN staff_offices so ON s.id = so.staff_id
      JOIN offices o ON so.office_id = o.id
      JOIN companies c ON o.company_id = c.id
      WHERE c.account_id = current_setting('app.current_account_id', true)::uuid
    )
  );

-- Staff offices isolation policy (strict)
DROP POLICY IF EXISTS staff_offices_isolation ON staff_offices;
CREATE POLICY staff_offices_isolation ON staff_offices
  USING (
    office_id IN (
      SELECT o.id FROM offices o
      JOIN companies c ON o.company_id = c.id
      WHERE c.account_id = current_setting('app.current_account_id', true)::uuid
    )
  );

-- ====================
-- UPDATED_AT TRIGGER FUNCTION
-- ====================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply triggers to all tables with updated_at
DROP TRIGGER IF EXISTS update_accounts_updated_at ON accounts;
CREATE TRIGGER update_accounts_updated_at
  BEFORE UPDATE ON accounts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_companies_updated_at ON companies;
CREATE TRIGGER update_companies_updated_at
  BEFORE UPDATE ON companies
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_offices_updated_at ON offices;
CREATE TRIGGER update_offices_updated_at
  BEFORE UPDATE ON offices
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_staff_updated_at ON staff;
CREATE TRIGGER update_staff_updated_at
  BEFORE UPDATE ON staff
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ====================
-- SEED DATA (Optional - for testing)
-- ====================

-- Create a demo account
INSERT INTO accounts (name, status, settings) 
VALUES ('Demo Account', 'active', '{"tier": "trial"}'::jsonb)
ON CONFLICT DO NOTHING;

-- Get the demo account ID for use in subsequent inserts
DO $$
DECLARE
  demo_account_id UUID;
BEGIN
  SELECT id INTO demo_account_id FROM accounts WHERE name = 'Demo Account' LIMIT 1;
  
  IF demo_account_id IS NOT NULL THEN
    -- Create a demo company
    INSERT INTO companies (account_id, name, eyefinity_company_id, eyefinity_base_url, settings)
    VALUES (
      demo_account_id, 
      'Demo Eye Care Center', 
      '936',
      'https://api-integration.eyefinity.com',
      '{"business_hours": {"monday": "9:00-17:00"}}'::jsonb
    )
    ON CONFLICT DO NOTHING;
  END IF;
END $$;

COMMENT ON TABLE accounts IS 'Top-level tenant: represents a customer account that can have multiple companies';
COMMENT ON TABLE companies IS 'Mid-level tenant: represents a company/practice within an account';
COMMENT ON TABLE offices IS 'Bottom-level tenant: represents individual office locations';
COMMENT ON TABLE staff IS 'Staff members including doctors, technicians, and other personnel';
COMMENT ON TABLE staff_offices IS 'Junction table linking staff to offices they work at';
