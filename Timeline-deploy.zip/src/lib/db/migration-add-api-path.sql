-- Add api_path field to companies table for configurable API path prefix
-- Default to 'al-pe' for existing records

ALTER TABLE companies 
ADD COLUMN IF NOT EXISTS api_path TEXT DEFAULT 'al-pe';

COMMENT ON COLUMN companies.api_path IS 'API path prefix (e.g., al-pe, api, v1) - used to construct full API URL';
