/**
 * Feature Flags Configuration
 * 
 * Controls which features are enabled/disabled
 * Set USE_DATABASE=true in .env when ready to enable persistence
 */

export const FeatureFlags = {
  /**
   * Database persistence flag
   * When FALSE: App works exactly as before (in-memory, APIs only)
   * When TRUE: Enrichments (sentiment, ratings, escalations) persist to Supabase
   * 
   * Data flow with DB enabled:
   * - Twilio API → Fresh call/SMS data (always from API)
   * - Eyefinity API → Fresh patient/appointment data (always from API)
   * - Supabase DB → Our enrichments (sentiment, ratings, notes, escalations)
   */
  USE_DATABASE: process.env.USE_DATABASE === 'true',

  /**
   * AI Sentiment Analysis
   * When TRUE: Calls are analyzed for emotion/satisfaction
   */
  AI_SENTIMENT: process.env.AI_SENTIMENT !== 'false', // Default ON

  /**
   * Demo Mode
   * When TRUE: Redirects SMS/calls to demo contacts
   */
  DEMO_MODE: process.env.DEMO_MODE === 'true',

  // ==================== VOICE AI PROVIDERS ====================

  /**
   * Use Deepgram for Speech-to-Text (STT)
   * When FALSE: Uses Twilio's built-in transcription (default)
   * When TRUE: Uses Deepgram for higher quality transcription with:
   *   - Medical vocabulary support
   *   - Speaker diarization (AI vs Patient)
   *   - Real-time streaming capability
   */
  USE_DEEPGRAM_STT: process.env.USE_DEEPGRAM_STT === 'true',

  /**
   * Use ElevenLabs for Text-to-Speech (TTS)
   * When FALSE: Uses Twilio's built-in TTS voices (default)
   * When TRUE: Uses ElevenLabs for premium voice synthesis with:
   *   - Natural sounding voices
   *   - Voice cloning capability
   *   - Configurable speaking styles
   */
  USE_ELEVENLABS_TTS: process.env.USE_ELEVENLABS_TTS === 'true',

  /**
   * Enable background noise/ambience for calls
   * When TRUE: Adds subtle office ambience to make AI sound more natural
   */
  VOICE_BACKGROUND_NOISE: process.env.VOICE_BACKGROUND_NOISE === 'true',
};

/**
 * Check if database is enabled
 */
export function isDbEnabled(): boolean {
  return FeatureFlags.USE_DATABASE;
}

/**
 * Check if AI sentiment is enabled
 */
export function isSentimentEnabled(): boolean {
  return FeatureFlags.AI_SENTIMENT;
}

/**
 * Check if Deepgram STT is enabled
 */
export function useDeepgramSTT(): boolean {
  return FeatureFlags.USE_DEEPGRAM_STT;
}

/**
 * Check if ElevenLabs TTS is enabled
 */
export function useElevenLabsTTS(): boolean {
  return FeatureFlags.USE_ELEVENLABS_TTS;
}

/**
 * Check if background noise is enabled
 */
export function useBackgroundNoise(): boolean {
  return FeatureFlags.VOICE_BACKGROUND_NOISE;
}

/**
 * Get feature flag status for debugging
 */
export function getFeatureStatus(): Record<string, boolean> {
  return {
    database: FeatureFlags.USE_DATABASE,
    aiSentiment: FeatureFlags.AI_SENTIMENT,
    demoMode: FeatureFlags.DEMO_MODE,
    deepgramSTT: FeatureFlags.USE_DEEPGRAM_STT,
    elevenLabsTTS: FeatureFlags.USE_ELEVENLABS_TTS,
    backgroundNoise: FeatureFlags.VOICE_BACKGROUND_NOISE,
  };
}

export default FeatureFlags;
