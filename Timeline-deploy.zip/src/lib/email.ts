import nodemailer from 'nodemailer';

// Initialize email transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USERNAME,
    pass: process.env.SMTP_PASSWORD,
  },
});

export interface EmailOptions {
  to: string;
  subject: string;
  text: string;
  html?: string;
  cc?: string;
  bcc?: string;
  attachments?: Array<{
    filename: string;
    content?: string | Buffer;
    path?: string;
  }>;
}

export async function sendEmail(options: EmailOptions) {
  try {
    const info = await transporter.sendMail({
      from: `"${process.env.SMTP_FROM_NAME || 'Eye Care Practice'}" <${process.env.SMTP_FROM_EMAIL || process.env.SMTP_USERNAME}>`,
      to: options.to,
      cc: options.cc,
      bcc: options.bcc,
      subject: options.subject,
      text: options.text,
      html: options.html,
      attachments: options.attachments,
    });
    return { success: true, messageId: info.messageId };
  } catch (error: any) {
    console.error('Error sending email:', error);
    return { success: false, error: error?.message || 'Failed to send email' };
  }
}

export async function sendAppointmentReminder(
  to: string,
  patientName: string,
  appointmentDate: string,
  appointmentTime: string,
  providerName: string,
  officeName: string,
  officeAddress?: string
) {
  const subject = `Appointment Reminder - ${appointmentDate}`;
  const text = `
Dear ${patientName},

This is a friendly reminder about your upcoming appointment:

Date: ${appointmentDate}
Time: ${appointmentTime}
Provider: ${providerName}
Location: ${officeName}${officeAddress ? `\n${officeAddress}` : ''}

Please arrive 15 minutes early to complete any necessary paperwork.

If you need to reschedule or cancel, please call our office.

Thank you,
${officeName}
  `.trim();

  const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background-color: #006FB4; color: white; padding: 20px; text-align: center; }
    .content { padding: 20px; background-color: #f9f9f9; }
    .details { background-color: white; padding: 15px; border-radius: 5px; margin: 15px 0; }
    .detail-row { margin: 10px 0; }
    .label { font-weight: bold; color: #006FB4; }
    .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Appointment Reminder</h1>
    </div>
    <div class="content">
      <p>Dear ${patientName},</p>
      <p>This is a friendly reminder about your upcoming appointment:</p>
      <div class="details">
        <div class="detail-row"><span class="label">Date:</span> ${appointmentDate}</div>
        <div class="detail-row"><span class="label">Time:</span> ${appointmentTime}</div>
        <div class="detail-row"><span class="label">Provider:</span> ${providerName}</div>
        <div class="detail-row"><span class="label">Location:</span> ${officeName}${officeAddress ? `<br/>${officeAddress}` : ''}</div>
      </div>
      <p>Please arrive 15 minutes early to complete any necessary paperwork.</p>
      <p>If you need to reschedule or cancel, please call our office.</p>
    </div>
    <div class="footer">
      <p>Thank you,<br/>${officeName}</p>
    </div>
  </div>
</body>
</html>
  `.trim();

  return sendEmail({ to, subject, text, html });
}

export async function sendFormRequest(
  to: string,
  patientName: string,
  formLink: string,
  officeName: string
) {
  const subject = `Please Complete Your Patient Forms - ${officeName}`;
  const text = `
Dear ${patientName},

Please complete your patient forms before your upcoming appointment.

Click here to access your forms: ${formLink}

Thank you,
${officeName}
  `.trim();

  const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background-color: #006FB4; color: white; padding: 20px; text-align: center; }
    .content { padding: 20px; background-color: #f9f9f9; }
    .button { display: inline-block; background-color: #006FB4; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
    .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Patient Forms Request</h1>
    </div>
    <div class="content">
      <p>Dear ${patientName},</p>
      <p>Please complete your patient forms before your upcoming appointment.</p>
      <p style="text-align: center;">
        <a href="${formLink}" class="button">Complete Forms</a>
      </p>
      <p>Or copy this link: ${formLink}</p>
    </div>
    <div class="footer">
      <p>Thank you,<br/>${officeName}</p>
    </div>
  </div>
</body>
</html>
  `.trim();

  return sendEmail({ to, subject, text, html });
}

export { transporter };
