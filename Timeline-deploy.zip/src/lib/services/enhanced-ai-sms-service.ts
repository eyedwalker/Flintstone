import Anthropic from '@anthropic-ai/sdk';

// Enhanced AI SMS Service with advanced features
export interface PatientContext {
  firstName: string;
  lastName: string;
  phone: string;
  appointmentDateTime?: Date;
  doctorName?: string;
  officeName?: string;
  reasonForVisit?: string;
  taskType?: string;
  taskStatus?: string;
  previousMessages?: Array<{
    message: string;
    timestamp: Date;
    direction: 'inbound' | 'outbound';
  }>;
  patientPreferences?: {
    preferredLanguage?: string;
    communicationStyle?: 'formal' | 'casual' | 'empathetic';
    timezone?: string;
  };
  medicalContext?: {
    isUrgent?: boolean;
    hasAllergies?: boolean;
    isNewPatient?: boolean;
    lastVisitDate?: Date;
  };
}

export interface MessageIntent {
  intent: 'emergency' | 'confirmation' | 'cancellation' | 'question' | 'scheduling' | 'booking' | 'general' | 'complaint' | 'compliment' | 'insurance' | 'directions';
  confidence: number;
  urgency: 'low' | 'medium' | 'high' | 'critical';
  sentiment: 'positive' | 'neutral' | 'negative';
  keywords: string[];
  requiresHumanFollowup: boolean;
  bookingDetails?: {
    wantsToBook: boolean;
    preferredDate?: string;
    preferredTime?: string;
    preferredDoctor?: string;
  };
}

export interface GenerateReplyOptions {
  includeOptOut?: boolean;
  maxLength?: number;
  tone?: 'professional' | 'friendly' | 'empathetic' | 'urgent';
  includeNextSteps?: boolean;
  personalize?: boolean;
}

export interface AIReplyResult {
  reply: string;
  intent: MessageIntent;
  confidence: number;
  mode: 'ai' | 'fallback';
  processingTime: number;
  tokens?: {
    input: number;
    output: number;
  };
  suggestions?: string[];
}

// Initialize Anthropic client conditionally
const anthropic = process.env.ANTHROPIC_API_KEY 
  ? new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
  : null;

export class EnhancedAISMSService {
  private static readonly MAX_SMS_LENGTH = 160;
  private static readonly FALLBACK_REPLIES: Record<string, string> = {
    emergency: "For urgent matters, please call our office immediately at [OFFICE_PHONE] or dial 911 for emergencies.",
    confirmation: "Thank you for confirming! We look forward to seeing you.",
    cancellation: "We understand you need to reschedule. Please call our office to arrange a new appointment.",
    question: "Thank you for your question. Our staff will respond shortly during business hours.",
    scheduling: "To schedule or reschedule, please call our office during business hours.",
    booking: "I can help you book an appointment! Reply with your preferred day (e.g., 'Monday' or 'tomorrow') and I'll find available times.",
    general: "Thank you for your message. We'll respond during business hours.",
    complaint: "We apologize for any inconvenience. Please call our office so we can address your concerns directly.",
    compliment: "Thank you for your kind words! We appreciate your feedback.",
    insurance: "For insurance questions, please call our office with your insurance card information.",
    directions: "For directions to our office, please visit our website or call us for assistance."
  };

  /**
   * Enhanced message intent analysis with multiple categories and sentiment
   */
  private static async analyzeMessageIntent(message: string, context: PatientContext): Promise<MessageIntent> {
    if (!anthropic) {
      return this.fallbackIntentAnalysis(message);
    }

    const prompt = `Analyze this SMS message from a patient and determine the intent, urgency, sentiment, and other factors.

Patient Context:
- Name: ${context.firstName} ${context.lastName}
- Appointment: ${context.appointmentDateTime ? new Date(context.appointmentDateTime).toLocaleDateString() : 'Not scheduled'}
- Doctor: ${context.doctorName || 'Not specified'}
- Reason: ${context.reasonForVisit || 'Not specified'}
- Previous messages: ${context.previousMessages?.length || 0}

Message: "${message}"

IMPORTANT: Use "booking" intent when patient wants to BOOK/SCHEDULE a NEW appointment (contains words like "book", "need appointment", "schedule appointment", "make appointment").
Use "scheduling" only for general scheduling questions without explicit booking request.

Analyze and respond with JSON only:
{
  "intent": "emergency|confirmation|cancellation|question|booking|scheduling|general|complaint|compliment|insurance|directions",
  "confidence": 0.0-1.0,
  "urgency": "low|medium|high|critical",
  "sentiment": "positive|neutral|negative",
  "keywords": ["key", "words", "found"],
  "requiresHumanFollowup": true/false,
  "bookingDetails": {"wantsToBook": true/false, "preferredDate": "day mentioned or null", "preferredTime": "time mentioned or null", "preferredDoctor": "doctor name or null"}
}`;

    try {
      const response = await anthropic.messages.create({
        model: 'claude-3-haiku-20240307',
        max_tokens: 200,
        messages: [{ role: 'user', content: prompt }]
      });

      const content = response.content[0];
      if (content.type === 'text') {
        const analysis = JSON.parse(content.text);
        return analysis;
      }
    } catch (error) {
      console.error('AI intent analysis failed:', error);
    }

    return this.fallbackIntentAnalysis(message);
  }

  /**
   * Fallback intent analysis using keyword matching
   */
  private static fallbackIntentAnalysis(message: string): MessageIntent {
    const lowerMessage = message.toLowerCase();
    
    // Emergency keywords
    if (lowerMessage.includes('emergency') || lowerMessage.includes('urgent') || 
        lowerMessage.includes('pain') || lowerMessage.includes('help')) {
      return {
        intent: 'emergency',
        confidence: 0.8,
        urgency: 'critical',
        sentiment: 'negative',
        keywords: ['emergency', 'urgent', 'pain', 'help'].filter((k: string) => lowerMessage.includes(k)),
        requiresHumanFollowup: true
      };
    }

    // Confirmation keywords
    if (lowerMessage.includes('yes') || lowerMessage.includes('confirm') || 
        lowerMessage.includes('ok') || lowerMessage.includes('good')) {
      return {
        intent: 'confirmation',
        confidence: 0.7,
        urgency: 'low',
        sentiment: 'positive',
        keywords: ['yes', 'confirm', 'ok'].filter((k: string) => lowerMessage.includes(k)),
        requiresHumanFollowup: false
      };
    }

    // Cancellation keywords
    if (lowerMessage.includes('cancel') || lowerMessage.includes('reschedule') || 
        lowerMessage.includes('change') || lowerMessage.includes('move')) {
      return {
        intent: 'cancellation',
        confidence: 0.8,
        urgency: 'medium',
        sentiment: 'neutral',
        keywords: ['cancel', 'reschedule', 'change'].filter((k: string) => lowerMessage.includes(k)),
        requiresHumanFollowup: true
      };
    }

    // Booking keywords (more specific - wants to actually book)
    if ((lowerMessage.includes('book') || lowerMessage.includes('make an appointment') || 
        lowerMessage.includes('schedule an appointment') || lowerMessage.includes('need an appointment') ||
        lowerMessage.includes('want an appointment') || lowerMessage.includes('set up an appointment')) &&
        !lowerMessage.includes('cancel')) {
      // Try to extract date/time preferences
      const dateMatch = lowerMessage.match(/\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday|tomorrow|today|next week)\b/i);
      const timeMatch = lowerMessage.match(/\b(\d{1,2}(?::\d{2})?\s*(?:am|pm)?|morning|afternoon|evening)\b/i);
      const doctorMatch = lowerMessage.match(/\b(?:dr\.?|doctor)\s+([a-z]+)/i);
      
      return {
        intent: 'booking',
        confidence: 0.85,
        urgency: 'medium',
        sentiment: 'neutral',
        keywords: ['book', 'appointment', 'schedule'].filter((k: string) => lowerMessage.includes(k)),
        requiresHumanFollowup: false,
        bookingDetails: {
          wantsToBook: true,
          preferredDate: dateMatch?.[1],
          preferredTime: timeMatch?.[1],
          preferredDoctor: doctorMatch?.[1]
        }
      };
    }

    // Scheduling keywords (general inquiry)
    if (lowerMessage.includes('appointment') || lowerMessage.includes('schedule') || 
        lowerMessage.includes('available')) {
      return {
        intent: 'scheduling',
        confidence: 0.7,
        urgency: 'medium',
        sentiment: 'neutral',
        keywords: ['appointment', 'schedule', 'book'].filter((k: string) => lowerMessage.includes(k)),
        requiresHumanFollowup: true
      };
    }

    // Complaint keywords
    if (lowerMessage.includes('complaint') || lowerMessage.includes('problem') || 
        lowerMessage.includes('issue') || lowerMessage.includes('dissatisfied')) {
      return {
        intent: 'complaint',
        confidence: 0.7,
        urgency: 'high',
        sentiment: 'negative',
        keywords: ['complaint', 'problem', 'issue'].filter((k: string) => lowerMessage.includes(k)),
        requiresHumanFollowup: true
      };
    }

    // Default to general
    return {
      intent: 'general',
      confidence: 0.5,
      urgency: 'low',
      sentiment: 'neutral',
      keywords: [],
      requiresHumanFollowup: false
    };
  }

  /**
   * Generate AI-powered SMS reply with enhanced features
   */
  static async generateEnhancedReply(
    incomingMessage: string, 
    patientContext: PatientContext, 
    options: GenerateReplyOptions = {}
  ): Promise<AIReplyResult> {
    const startTime = Date.now();
    
    // Set defaults
    const opts = {
      includeOptOut: false,
      maxLength: this.MAX_SMS_LENGTH,
      tone: 'professional' as const,
      includeNextSteps: true,
      personalize: true,
      ...options
    };

    // Analyze intent first
    const intent = await this.analyzeMessageIntent(incomingMessage, patientContext);

    // Generate reply
    if (!anthropic) {
      const fallbackReply = this.generateFallbackReply(incomingMessage, patientContext, intent, opts);
      return {
        reply: fallbackReply,
        intent,
        confidence: 0.5,
        mode: 'fallback',
        processingTime: Date.now() - startTime
      };
    }

    try {
      const reply = await this.generateAIReply(incomingMessage, patientContext, intent, opts);
      return {
        reply,
        intent,
        confidence: 0.9,
        mode: 'ai',
        processingTime: Date.now() - startTime,
        suggestions: this.generateSuggestions(intent)
      };
    } catch (error) {
      console.error('AI reply generation failed:', error);
      const fallbackReply = this.generateFallbackReply(incomingMessage, patientContext, intent, opts);
      return {
        reply: fallbackReply,
        intent,
        confidence: 0.5,
        mode: 'fallback',
        processingTime: Date.now() - startTime
      };
    }
  }

  /**
   * Generate AI reply using Anthropic Claude
   */
  private static async generateAIReply(
    message: string,
    context: PatientContext,
    intent: MessageIntent,
    options: GenerateReplyOptions
  ): Promise<string> {
    const prompt = this.buildEnhancedPrompt(message, context, intent, options);

    const response = await anthropic!.messages.create({
      model: 'claude-3-haiku-20240307',
      max_tokens: 150,
      messages: [{ role: 'user', content: prompt }]
    });

    const content = response.content[0];
    if (content.type === 'text') {
      let reply = content.text.trim();
      
      // Ensure SMS length limit
      if (reply.length > options.maxLength!) {
        reply = reply.substring(0, options.maxLength! - 3) + '...';
      }

      // Add opt-out if requested
      if (options.includeOptOut && reply.length < options.maxLength! - 20) {
        reply += ' Reply STOP to opt out.';
      }

      return reply;
    }

    throw new Error('Invalid AI response format');
  }

  /**
   * Build enhanced prompt for AI reply generation
   */
  private static buildEnhancedPrompt(
    message: string,
    context: PatientContext,
    intent: MessageIntent,
    options: GenerateReplyOptions
  ): string {
    const timeContext = context.appointmentDateTime 
      ? `Appointment: ${new Date(context.appointmentDateTime).toLocaleDateString()} with ${context.doctorName || 'doctor'}`
      : 'No scheduled appointment';

    const previousContext = context.previousMessages?.length 
      ? `Previous messages: ${context.previousMessages.length} exchanges`
      : 'First message';

    const urgencyContext = intent.urgency === 'critical' || intent.urgency === 'high'
      ? 'This message requires urgent attention.'
      : 'Standard response time is acceptable.';

    return `You are a professional medical office assistant responding to patient SMS messages.

Patient Information:
- Name: ${context.firstName} ${context.lastName}
- ${timeContext}
- Office: ${context.officeName || 'Medical Office'}
- Reason: ${context.reasonForVisit || 'General care'}
- ${previousContext}

Message Analysis:
- Intent: ${intent.intent}
- Urgency: ${intent.urgency}
- Sentiment: ${intent.sentiment}
- ${urgencyContext}

Patient Message: "${message}"

Guidelines:
- Keep response under ${options.maxLength} characters
- Use ${options.tone} tone
- ${options.personalize ? `Address patient as ${context.firstName}` : 'Use professional address'}
- ${options.includeNextSteps ? 'Include clear next steps when appropriate' : 'Keep response brief'}
- For emergencies: Direct to call office or 911
- For scheduling: Direct to call office
- For confirmations: Acknowledge positively
- Be empathetic and professional
- Never provide medical advice

Generate a concise, helpful SMS response:`;
  }

  /**
   * Generate fallback reply for when AI is unavailable
   */
  private static generateFallbackReply(
    message: string,
    context: PatientContext,
    intent: MessageIntent,
    options: GenerateReplyOptions
  ): string {
    let baseReply = this.FALLBACK_REPLIES[intent.intent] || this.FALLBACK_REPLIES.general;
    
    // Personalize if requested
    if (options.personalize && context.firstName) {
      baseReply = `Hi ${context.firstName}! ${baseReply}`;
    }

    // Add opt-out if requested and space allows
    if (options.includeOptOut && baseReply.length < options.maxLength! - 20) {
      baseReply += ' Reply STOP to opt out.';
    }

    // Ensure length limit
    if (baseReply.length > options.maxLength!) {
      baseReply = baseReply.substring(0, options.maxLength! - 3) + '...';
    }

    return baseReply;
  }

  /**
   * Generate suggestions for follow-up actions
   */
  private static generateSuggestions(intent: MessageIntent): string[] {
    const suggestions: Record<string, string[]> = {
      emergency: ['Call patient immediately', 'Escalate to medical staff', 'Document in medical record'],
      complaint: ['Schedule follow-up call', 'Escalate to manager', 'Document complaint'],
      cancellation: ['Offer alternative times', 'Update calendar', 'Send confirmation'],
      scheduling: ['Check availability', 'Send appointment options', 'Confirm preferences'],
      booking: ['Check Eyefinity availability', 'Send available slots', 'Confirm booking'],
      question: ['Research answer', 'Consult with medical staff', 'Provide detailed response'],
      general: ['Acknowledge receipt', 'File for reference', 'Follow up if needed']
    };

    return suggestions[intent.intent] || suggestions.general;
  }

  /**
   * Check if intent is a booking request
   */
  static isBookingRequest(intent: MessageIntent): boolean {
    return intent.intent === 'booking' && intent.bookingDetails?.wantsToBook === true;
  }

  /**
   * Batch process multiple messages
   */
  static async processMessageBatch(
    messages: Array<{ message: string; context: PatientContext; options?: GenerateReplyOptions }>
  ): Promise<AIReplyResult[]> {
    const results = await Promise.all(
      messages.map(({ message, context, options }) =>
        this.generateEnhancedReply(message, context, options)
      )
    );

    return results;
  }

  /**
   * Get service health status
   */
  static getServiceHealth(): {
    aiAvailable: boolean;
    fallbackActive: boolean;
    lastCheck: Date;
    version: string;
  } {
    return {
      aiAvailable: !!anthropic,
      fallbackActive: !anthropic,
      lastCheck: new Date(),
      version: '2.0.0'
    };
  }
}
