/**
 * AI Communication Orchestrator
 * Handles channel selection, trigger evaluation, and automated communication dispatch
 */

import {
  AICommunicationSettings,
  AICommunicationTrigger,
  CommunicationChannel,
  PatientCommunicationPreferences,
  DEFAULT_AI_COMMUNICATION_SETTINGS,
} from '../types/communication-preferences';

const SETTINGS_STORAGE_KEY = 'ai_communication_settings';
const PREFERENCES_STORAGE_KEY = 'patient_communication_preferences';
const COMMUNICATION_LOG_KEY = 'ai_communication_log';

export interface CommunicationLogEntry {
  id: string;
  patientId: string;
  patientName: string;
  triggerId: string;
  triggerName: string;
  channel: CommunicationChannel;
  status: 'pending' | 'sent' | 'delivered' | 'failed' | 'no_channel_available';
  message: string;
  attemptNumber: number;
  timestamp: Date;
  error?: string;
  metadata?: Record<string, any>;
}

export interface ChannelSelectionResult {
  channel: CommunicationChannel | null;
  reason: string;
  patientOptedOut: boolean;
  inQuietHours: boolean;
}

export class AICommunicationOrchestrator {
  
  // ==================== SETTINGS MANAGEMENT ====================
  
  static getSettings(officeId: string): AICommunicationSettings {
    const stored = localStorage.getItem(`${SETTINGS_STORAGE_KEY}_${officeId}`);
    if (stored) {
      return JSON.parse(stored);
    }
    return {
      ...DEFAULT_AI_COMMUNICATION_SETTINGS,
      officeId,
      updatedAt: new Date(),
    };
  }
  
  static saveSettings(settings: AICommunicationSettings): void {
    settings.updatedAt = new Date();
    localStorage.setItem(`${SETTINGS_STORAGE_KEY}_${settings.officeId}`, JSON.stringify(settings));
  }
  
  static updateTrigger(officeId: string, trigger: AICommunicationTrigger): void {
    const settings = this.getSettings(officeId);
    const index = settings.triggers.findIndex(t => t.id === trigger.id);
    if (index >= 0) {
      settings.triggers[index] = trigger;
    } else {
      settings.triggers.push(trigger);
    }
    this.saveSettings(settings);
  }
  
  static deleteTrigger(officeId: string, triggerId: string): void {
    const settings = this.getSettings(officeId);
    settings.triggers = settings.triggers.filter(t => t.id !== triggerId);
    this.saveSettings(settings);
  }
  
  // ==================== PATIENT PREFERENCES ====================
  
  static getPatientPreferences(patientId: string): PatientCommunicationPreferences | null {
    const allPrefs = this.getAllPatientPreferences();
    return allPrefs.find(p => p.patientId === patientId) || null;
  }
  
  static getAllPatientPreferences(): PatientCommunicationPreferences[] {
    const stored = localStorage.getItem(PREFERENCES_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  }
  
  static savePatientPreferences(prefs: PatientCommunicationPreferences): void {
    const allPrefs = this.getAllPatientPreferences();
    const index = allPrefs.findIndex(p => p.patientId === prefs.patientId);
    prefs.updatedAt = new Date();
    if (index >= 0) {
      allPrefs[index] = prefs;
    } else {
      allPrefs.push(prefs);
    }
    localStorage.setItem(PREFERENCES_STORAGE_KEY, JSON.stringify(allPrefs));
  }
  
  static getDefaultPatientPreferences(patientId: string): PatientCommunicationPreferences {
    return {
      patientId,
      preferredChannel: 'sms',
      fallbackChannel: 'email',
      doNotContactBefore: '08:00',
      doNotContactAfter: '21:00',
      optOutSMS: false,
      optOutEmail: false,
      optOutVoice: false,
      language: 'en',
      timezone: 'America/Chicago',
      updatedAt: new Date(),
    };
  }
  
  // ==================== CHANNEL SELECTION ====================
  
  static selectChannel(
    patientId: string,
    trigger: AICommunicationTrigger,
    settings: AICommunicationSettings,
    urgency: 'low' | 'medium' | 'high' | 'critical' = 'medium'
  ): ChannelSelectionResult {
    const patientPrefs = this.getPatientPreferences(patientId) || 
                         this.getDefaultPatientPreferences(patientId);
    
    // Check quiet hours
    if (settings.quietHours.enabled && this.isInQuietHours(settings)) {
      return {
        channel: null,
        reason: 'Currently in quiet hours',
        patientOptedOut: false,
        inQuietHours: true,
      };
    }
    
    // Check patient contact hours
    if (!this.isWithinContactHours(patientPrefs)) {
      return {
        channel: null,
        reason: 'Outside patient contact hours',
        patientOptedOut: false,
        inQuietHours: false,
      };
    }
    
    // Sort rules by priority
    const sortedRules = [...trigger.channelRules].sort((a, b) => a.priority - b.priority);
    
    for (const rule of sortedRules) {
      let shouldUse = false;
      
      switch (rule.condition) {
        case 'patient_preference':
          shouldUse = rule.useChannel === patientPrefs.preferredChannel;
          break;
        case 'time_of_day':
          if (rule.timeRange) {
            shouldUse = this.isInTimeRange(rule.timeRange.start, rule.timeRange.end);
          }
          break;
        case 'urgency':
          shouldUse = rule.urgencyLevel === urgency;
          break;
        case 'fallback':
          shouldUse = true; // Always matches as fallback
          break;
      }
      
      if (shouldUse) {
        // Check opt-out
        if (rule.respectOptOut) {
          const optedOut = this.isChannelOptedOut(rule.useChannel, patientPrefs);
          if (optedOut) {
            continue; // Try next rule
          }
        }
        
        return {
          channel: rule.useChannel,
          reason: `Selected by rule: ${rule.condition}`,
          patientOptedOut: false,
          inQuietHours: false,
        };
      }
    }
    
    // No channel available
    return {
      channel: null,
      reason: 'No available channel (all opted out or no matching rules)',
      patientOptedOut: true,
      inQuietHours: false,
    };
  }
  
  private static isChannelOptedOut(
    channel: CommunicationChannel, 
    prefs: PatientCommunicationPreferences
  ): boolean {
    switch (channel) {
      case 'sms': return prefs.optOutSMS;
      case 'email': return prefs.optOutEmail;
      case 'voice': return prefs.optOutVoice;
      default: return false;
    }
  }
  
  private static isInQuietHours(settings: AICommunicationSettings): boolean {
    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    
    const { start, end } = settings.quietHours;
    
    // Handle overnight quiet hours (e.g., 21:00 to 08:00)
    if (start > end) {
      return currentTime >= start || currentTime < end;
    }
    return currentTime >= start && currentTime < end;
  }
  
  private static isWithinContactHours(prefs: PatientCommunicationPreferences): boolean {
    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    
    return currentTime >= prefs.doNotContactBefore && currentTime < prefs.doNotContactAfter;
  }
  
  private static isInTimeRange(start: string, end: string): boolean {
    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    return currentTime >= start && currentTime < end;
  }
  
  // ==================== TRIGGER EVALUATION ====================
  
  static evaluateTriggers(
    officeId: string,
    context: {
      patientId: string;
      patientName: string;
      appointmentDate?: Date;
      journeyPhase?: string;
      journeyStepId?: string;
      eventType: AICommunicationTrigger['triggerType'];
    }
  ): AICommunicationTrigger[] {
    const settings = this.getSettings(officeId);
    
    if (!settings.globalEnabled) {
      return [];
    }
    
    const matchingTriggers: AICommunicationTrigger[] = [];
    
    for (const trigger of settings.triggers) {
      if (!trigger.enabled) continue;
      if (trigger.triggerType !== context.eventType) continue;
      
      // Check conditions
      if (trigger.conditions) {
        if (trigger.conditions.journeyPhase && context.journeyPhase) {
          if (!trigger.conditions.journeyPhase.includes(context.journeyPhase)) {
            continue;
          }
        }
      }
      
      // Check timing
      if (context.appointmentDate && trigger.timing.daysBeforeAppointment) {
        const daysUntil = Math.ceil(
          (context.appointmentDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24)
        );
        if (daysUntil !== trigger.timing.daysBeforeAppointment) {
          continue;
        }
      }
      
      if (context.appointmentDate && trigger.timing.hoursBeforeAppointment) {
        const hoursUntil = Math.ceil(
          (context.appointmentDate.getTime() - Date.now()) / (1000 * 60 * 60)
        );
        if (hoursUntil !== trigger.timing.hoursBeforeAppointment) {
          continue;
        }
      }
      
      // Check max attempts
      const previousAttempts = this.getAttemptCount(context.patientId, trigger.id);
      if (previousAttempts >= trigger.timing.maxAttempts) {
        continue;
      }
      
      matchingTriggers.push(trigger);
    }
    
    return matchingTriggers;
  }
  
  // ==================== COMMUNICATION LOG ====================
  
  static getCommunicationLog(): CommunicationLogEntry[] {
    const stored = localStorage.getItem(COMMUNICATION_LOG_KEY);
    return stored ? JSON.parse(stored) : [];
  }
  
  static logCommunication(entry: Omit<CommunicationLogEntry, 'id' | 'timestamp'>): CommunicationLogEntry {
    const log = this.getCommunicationLog();
    const newEntry: CommunicationLogEntry = {
      ...entry,
      id: `comm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
    };
    log.push(newEntry);
    localStorage.setItem(COMMUNICATION_LOG_KEY, JSON.stringify(log));
    return newEntry;
  }
  
  static getAttemptCount(patientId: string, triggerId: string): number {
    const log = this.getCommunicationLog();
    const last24Hours = Date.now() - (24 * 60 * 60 * 1000);
    
    return log.filter(
      entry => 
        entry.patientId === patientId && 
        entry.triggerId === triggerId &&
        new Date(entry.timestamp).getTime() > last24Hours
    ).length;
  }
  
  static getPatientCommunicationHistory(patientId: string): CommunicationLogEntry[] {
    return this.getCommunicationLog()
      .filter(entry => entry.patientId === patientId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }
  
  // ==================== DISPATCH COMMUNICATION ====================
  
  static async dispatchCommunication(
    officeId: string,
    trigger: AICommunicationTrigger,
    context: {
      patientId: string;
      patientName: string;
      phone?: string;
      email?: string;
      appointmentDate?: string;
      appointmentTime?: string;
      providerName?: string;
      journeyStep?: string;
    },
    message: string
  ): Promise<CommunicationLogEntry> {
    const settings = this.getSettings(officeId);
    
    // Select channel
    const channelResult = this.selectChannel(context.patientId, trigger, settings);
    
    if (!channelResult.channel) {
      return this.logCommunication({
        patientId: context.patientId,
        patientName: context.patientName,
        triggerId: trigger.id,
        triggerName: trigger.name,
        channel: 'sms', // Default for logging
        status: 'no_channel_available',
        message,
        attemptNumber: this.getAttemptCount(context.patientId, trigger.id) + 1,
        error: channelResult.reason,
      });
    }
    
    // Dispatch based on channel
    try {
      let status: CommunicationLogEntry['status'] = 'sent';
      
      switch (channelResult.channel) {
        case 'sms':
          // In production, call actual Twilio service
          console.log(`[AI Orchestrator] Sending SMS to ${context.phone}: ${message}`);
          break;
        case 'voice':
          // In production, call Twilio voice
          console.log(`[AI Orchestrator] Initiating voice call to ${context.phone}: ${message}`);
          break;
        case 'email':
          // In production, call AWS SES
          console.log(`[AI Orchestrator] Sending email to ${context.email}: ${message}`);
          break;
      }
      
      return this.logCommunication({
        patientId: context.patientId,
        patientName: context.patientName,
        triggerId: trigger.id,
        triggerName: trigger.name,
        channel: channelResult.channel,
        status,
        message,
        attemptNumber: this.getAttemptCount(context.patientId, trigger.id) + 1,
        metadata: {
          channelSelectionReason: channelResult.reason,
        },
      });
    } catch (error: any) {
      return this.logCommunication({
        patientId: context.patientId,
        patientName: context.patientName,
        triggerId: trigger.id,
        triggerName: trigger.name,
        channel: channelResult.channel,
        status: 'failed',
        message,
        attemptNumber: this.getAttemptCount(context.patientId, trigger.id) + 1,
        error: error.message,
      });
    }
  }
}
