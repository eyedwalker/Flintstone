/**
 * Voice Call Service
 * Handles outbound voice calls via Twilio and browser-based calling
 */

export type CallStatus = 
  | 'idle'
  | 'connecting'
  | 'ringing'
  | 'in-progress'
  | 'completed'
  | 'failed'
  | 'busy'
  | 'no-answer'
  | 'canceled';

export interface CallRecord {
  id: string;
  patientId: string;
  patientName: string;
  phoneNumber: string;
  direction: 'outbound' | 'inbound';
  status: CallStatus;
  startTime: Date;
  endTime?: Date;
  duration?: number; // seconds
  recordingUrl?: string;
  transcription?: string;
  notes?: string;
  calledBy?: string;
  callType: 'patient' | 'office';
}

export interface ActiveCall {
  callId: string;
  phoneNumber: string;
  patientId?: string;
  patientName?: string;
  status: CallStatus;
  startTime: Date;
  isMuted: boolean;
  isOnHold: boolean;
}

const CALL_HISTORY_KEY = 'voice_call_history';
const OFFICE_PHONE = '+15551234567'; // Demo office number

class VoiceCallServiceClass {
  private activeCall: ActiveCall | null = null;
  private listeners: Set<(call: ActiveCall | null) => void> = new Set();

  // Get call history
  getCallHistory(): CallRecord[] {
    const stored = localStorage.getItem(CALL_HISTORY_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  // Get patient call history
  getPatientCallHistory(patientId: string): CallRecord[] {
    return this.getCallHistory()
      .filter(c => c.patientId === patientId)
      .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());
  }

  // Save call record
  private saveCallRecord(record: CallRecord): void {
    const history = this.getCallHistory();
    const existingIndex = history.findIndex(c => c.id === record.id);
    if (existingIndex >= 0) {
      history[existingIndex] = record;
    } else {
      history.push(record);
    }
    localStorage.setItem(CALL_HISTORY_KEY, JSON.stringify(history));
  }

  // Subscribe to active call changes
  subscribe(listener: (call: ActiveCall | null) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners(): void {
    this.listeners.forEach(listener => listener(this.activeCall));
  }

  // Get active call
  getActiveCall(): ActiveCall | null {
    return this.activeCall;
  }

  // Initiate outbound call to patient
  async callPatient(
    patientId: string,
    patientName: string,
    phoneNumber: string,
    calledBy: string
  ): Promise<CallRecord> {
    if (this.activeCall) {
      throw new Error('A call is already in progress');
    }

    const callId = `call_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const startTime = new Date();

    // Create active call
    this.activeCall = {
      callId,
      phoneNumber,
      patientId,
      patientName,
      status: 'connecting',
      startTime,
      isMuted: false,
      isOnHold: false,
    };
    this.notifyListeners();

    // Create call record
    const callRecord: CallRecord = {
      id: callId,
      patientId,
      patientName,
      phoneNumber,
      direction: 'outbound',
      status: 'connecting',
      startTime,
      calledBy,
      callType: 'patient',
    };
    this.saveCallRecord(callRecord);

    // Simulate call connection (in production, this would use Twilio Client SDK)
    console.log(`[VoiceCallService] Initiating call to ${phoneNumber} (${patientName})`);

    // Simulate ringing after 1 second
    setTimeout(() => {
      if (this.activeCall?.callId === callId) {
        this.activeCall.status = 'ringing';
        callRecord.status = 'ringing';
        this.saveCallRecord(callRecord);
        this.notifyListeners();
      }
    }, 1000);

    // Simulate connection after 3 seconds
    setTimeout(() => {
      if (this.activeCall?.callId === callId) {
        this.activeCall.status = 'in-progress';
        callRecord.status = 'in-progress';
        this.saveCallRecord(callRecord);
        this.notifyListeners();
      }
    }, 3000);

    return callRecord;
  }

  // Call office
  async callOffice(calledBy: string): Promise<CallRecord> {
    if (this.activeCall) {
      throw new Error('A call is already in progress');
    }

    const callId = `call_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const startTime = new Date();

    this.activeCall = {
      callId,
      phoneNumber: OFFICE_PHONE,
      status: 'connecting',
      startTime,
      isMuted: false,
      isOnHold: false,
    };
    this.notifyListeners();

    const callRecord: CallRecord = {
      id: callId,
      patientId: 'office',
      patientName: 'Office',
      phoneNumber: OFFICE_PHONE,
      direction: 'outbound',
      status: 'connecting',
      startTime,
      calledBy,
      callType: 'office',
    };
    this.saveCallRecord(callRecord);

    console.log(`[VoiceCallService] Calling office at ${OFFICE_PHONE}`);

    // Simulate connection
    setTimeout(() => {
      if (this.activeCall?.callId === callId) {
        this.activeCall.status = 'ringing';
        callRecord.status = 'ringing';
        this.saveCallRecord(callRecord);
        this.notifyListeners();
      }
    }, 1000);

    setTimeout(() => {
      if (this.activeCall?.callId === callId) {
        this.activeCall.status = 'in-progress';
        callRecord.status = 'in-progress';
        this.saveCallRecord(callRecord);
        this.notifyListeners();
      }
    }, 2500);

    return callRecord;
  }

  // End current call
  endCall(): CallRecord | null {
    if (!this.activeCall) {
      return null;
    }

    const endTime = new Date();
    const duration = Math.round((endTime.getTime() - this.activeCall.startTime.getTime()) / 1000);

    // Update call record
    const history = this.getCallHistory();
    const callRecord = history.find(c => c.id === this.activeCall!.callId);
    if (callRecord) {
      callRecord.status = 'completed';
      callRecord.endTime = endTime;
      callRecord.duration = duration;
      this.saveCallRecord(callRecord);
    }

    console.log(`[VoiceCallService] Call ended. Duration: ${duration}s`);

    this.activeCall = null;
    this.notifyListeners();

    return callRecord || null;
  }

  // Toggle mute
  toggleMute(): boolean {
    if (!this.activeCall) return false;
    this.activeCall.isMuted = !this.activeCall.isMuted;
    this.notifyListeners();
    console.log(`[VoiceCallService] Mute ${this.activeCall.isMuted ? 'enabled' : 'disabled'}`);
    return this.activeCall.isMuted;
  }

  // Toggle hold
  toggleHold(): boolean {
    if (!this.activeCall) return false;
    this.activeCall.isOnHold = !this.activeCall.isOnHold;
    this.notifyListeners();
    console.log(`[VoiceCallService] Hold ${this.activeCall.isOnHold ? 'enabled' : 'disabled'}`);
    return this.activeCall.isOnHold;
  }

  // Send DTMF tones
  sendDTMF(digit: string): void {
    if (!this.activeCall || this.activeCall.status !== 'in-progress') return;
    console.log(`[VoiceCallService] Sending DTMF: ${digit}`);
    // In production, would send via Twilio
  }

  // Add notes to call
  addCallNotes(callId: string, notes: string): void {
    const history = this.getCallHistory();
    const callRecord = history.find(c => c.id === callId);
    if (callRecord) {
      callRecord.notes = notes;
      this.saveCallRecord(callRecord);
    }
  }

  // Format duration for display
  formatDuration(seconds: number): string {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }

  // Get status display text
  getStatusText(status: CallStatus): string {
    const statusMap: Record<CallStatus, string> = {
      'idle': 'Ready',
      'connecting': 'Connecting...',
      'ringing': 'Ringing...',
      'in-progress': 'In Call',
      'completed': 'Call Ended',
      'failed': 'Call Failed',
      'busy': 'Line Busy',
      'no-answer': 'No Answer',
      'canceled': 'Canceled',
    };
    return statusMap[status] || status;
  }
}

export const VoiceCallService = new VoiceCallServiceClass();
