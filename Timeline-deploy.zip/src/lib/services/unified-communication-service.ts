/// <reference types="vite/client" />
/**
 * Unified Communication Service
 * Handles SMS, Email, and Voice communications with real API integrations
 */

import { CommunicationMessage } from '../../services/communicationService';

export type CommunicationChannel = 'sms' | 'email' | 'voice';

export interface SendSMSRequest {
  to: string;
  message: string;
  patientId: string;
  patientName: string;
  sentBy: string;
}

export interface SendEmailRequest {
  to: string;
  subject: string;
  body: string;
  patientId: string;
  patientName: string;
  sentBy: string;
  isHtml?: boolean;
}

export interface MakeCallRequest {
  to: string;
  message: string;
  patientId: string;
  patientName: string;
  calledBy: string;
  useAIVoice?: boolean;
}

export interface CommunicationResult {
  success: boolean;
  messageId?: string;
  error?: string;
  channel: CommunicationChannel;
}

const COMM_STORAGE_KEY = 'unified_communications';

class UnifiedCommunicationServiceClass {
  private apiBaseUrl = import.meta.env.VITE_API_BASE_URL || '';
  private twilioEnabled = !!import.meta.env.VITE_TWILIO_ACCOUNT_SID;
  private sesEnabled = !!import.meta.env.VITE_AWS_SES_REGION;

  // ==================== SMS ====================

  async sendSMS(request: SendSMSRequest): Promise<CommunicationResult> {
    console.log(`[UnifiedComm] Sending SMS to ${request.to}: ${request.message}`);

    // Store locally first
    const message = this.storeMessage({
      patientId: request.patientId,
      type: 'sms',
      direction: 'outbound',
      content: request.message,
      status: 'pending',
      sentBy: request.sentBy,
    });

    if (this.twilioEnabled && this.apiBaseUrl) {
      try {
        const response = await fetch(`${this.apiBaseUrl}/api/communications/sms`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: request.to,
            message: request.message,
            patientId: request.patientId,
          }),
        });

        if (response.ok) {
          const result = await response.json();
          this.updateMessageStatus(message.id, 'sent');
          return { success: true, messageId: result.messageId, channel: 'sms' };
        } else {
          this.updateMessageStatus(message.id, 'failed');
          return { success: false, error: 'API request failed', channel: 'sms' };
        }
      } catch (error: any) {
        console.error('[UnifiedComm] SMS API error:', error);
        // Fall back to demo mode
      }
    }

    // Demo mode - simulate success
    setTimeout(() => this.updateMessageStatus(message.id, 'delivered'), 1500);
    return { success: true, messageId: message.id, channel: 'sms' };
  }

  // ==================== EMAIL ====================

  async sendEmail(request: SendEmailRequest): Promise<CommunicationResult> {
    console.log(`[UnifiedComm] Sending email to ${request.to}: ${request.subject}`);

    const message = this.storeMessage({
      patientId: request.patientId,
      type: 'email',
      direction: 'outbound',
      content: `Subject: ${request.subject}\n\n${request.body}`,
      status: 'pending',
      sentBy: request.sentBy,
    });

    if (this.sesEnabled && this.apiBaseUrl) {
      try {
        const response = await fetch(`${this.apiBaseUrl}/api/communications/email`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: request.to,
            subject: request.subject,
            body: request.body,
            isHtml: request.isHtml,
            patientId: request.patientId,
          }),
        });

        if (response.ok) {
          const result = await response.json();
          this.updateMessageStatus(message.id, 'sent');
          return { success: true, messageId: result.messageId, channel: 'email' };
        } else {
          this.updateMessageStatus(message.id, 'failed');
          return { success: false, error: 'API request failed', channel: 'email' };
        }
      } catch (error: any) {
        console.error('[UnifiedComm] Email API error:', error);
      }
    }

    // Demo mode
    setTimeout(() => this.updateMessageStatus(message.id, 'delivered'), 2000);
    return { success: true, messageId: message.id, channel: 'email' };
  }

  // ==================== VOICE ====================

  async makeCall(request: MakeCallRequest): Promise<CommunicationResult> {
    console.log(`[UnifiedComm] Making call to ${request.to}`);

    const message = this.storeMessage({
      patientId: request.patientId,
      type: 'voice',
      direction: 'outbound',
      content: request.message,
      status: 'pending',
      sentBy: request.calledBy,
      callStatus: 'initiating',
    });

    if (this.twilioEnabled && this.apiBaseUrl) {
      try {
        const response = await fetch(`${this.apiBaseUrl}/api/communications/voice`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: request.to,
            message: request.message,
            patientId: request.patientId,
            useAIVoice: request.useAIVoice,
          }),
        });

        if (response.ok) {
          const result = await response.json();
          this.updateMessageStatus(message.id, 'sent');
          return { success: true, messageId: result.callId, channel: 'voice' };
        } else {
          this.updateMessageStatus(message.id, 'failed');
          return { success: false, error: 'API request failed', channel: 'voice' };
        }
      } catch (error: any) {
        console.error('[UnifiedComm] Voice API error:', error);
      }
    }

    // Demo mode
    setTimeout(() => this.updateMessageStatus(message.id, 'delivered'), 1000);
    return { success: true, messageId: message.id, channel: 'voice' };
  }

  // ==================== INBOUND HANDLERS ====================

  handleInboundSMS(
    fromPhone: string,
    message: string,
    patientId: string
  ): CommunicationMessage {
    return this.storeMessage({
      patientId,
      type: 'sms',
      direction: 'inbound',
      content: message,
      status: 'read',
    });
  }

  handleInboundEmail(
    fromEmail: string,
    subject: string,
    body: string,
    patientId: string
  ): CommunicationMessage {
    return this.storeMessage({
      patientId,
      type: 'email',
      direction: 'inbound',
      content: `Subject: ${subject}\n\n${body}`,
      status: 'read',
    });
  }

  handleInboundCall(
    fromPhone: string,
    duration: number,
    transcription: string,
    patientId: string
  ): CommunicationMessage {
    return this.storeMessage({
      patientId,
      type: 'voice',
      direction: 'inbound',
      content: transcription || 'Voice call received',
      status: 'read',
      callDuration: duration,
      callStatus: 'completed',
    });
  }

  // ==================== STORAGE ====================

  private storeMessage(
    data: Omit<CommunicationMessage, 'id' | 'timestamp'>
  ): CommunicationMessage {
    const messages = this.getAllMessages();
    const message: CommunicationMessage = {
      ...data,
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
    };
    messages.push(message);
    localStorage.setItem(COMM_STORAGE_KEY, JSON.stringify(messages));
    return message;
  }

  private updateMessageStatus(
    messageId: string,
    status: CommunicationMessage['status']
  ): void {
    const messages = this.getAllMessages();
    const index = messages.findIndex(m => m.id === messageId);
    if (index !== -1) {
      messages[index].status = status;
      localStorage.setItem(COMM_STORAGE_KEY, JSON.stringify(messages));
    }
  }

  getAllMessages(): CommunicationMessage[] {
    const stored = localStorage.getItem(COMM_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  getPatientMessages(patientId: string): CommunicationMessage[] {
    return this.getAllMessages()
      .filter(m => m.patientId === patientId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  getPatientMessagesByChannel(
    patientId: string,
    channel: CommunicationChannel
  ): CommunicationMessage[] {
    return this.getPatientMessages(patientId).filter(m => m.type === channel);
  }

  // ==================== WEBHOOK SETUP INFO ====================

  getWebhookSetupInfo(): {
    smsWebhook: string;
    emailWebhook: string;
    voiceWebhook: string;
  } {
    const baseUrl = this.apiBaseUrl || window.location.origin;
    return {
      smsWebhook: `${baseUrl}/api/webhooks/twilio-sms`,
      emailWebhook: `${baseUrl}/api/webhooks/ses-email`,
      voiceWebhook: `${baseUrl}/api/webhooks/twilio-voice`,
    };
  }
}

export const UnifiedCommunicationService = new UnifiedCommunicationServiceClass();
