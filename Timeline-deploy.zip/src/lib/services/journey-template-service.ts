/**
 * Journey Template Service
 * Manages journey path templates with form, communication, and room configurations
 */

import type {
  JourneyTemplate,
  JourneyPathTemplate,
  JourneyStepTemplate,
} from '../types/patient-journey';

const TEMPLATES_STORAGE_KEY = 'timeline_journey_templates';

// Default pre-visit steps with form configuration
const DEFAULT_PRE_VISIT_STEPS: JourneyStepTemplate[] = [
  {
    id: 'pv-1',
    title: 'Send Appointment Confirmation',
    description: 'Confirm appointment and provide pre-visit instructions',
    stepType: 'pre-visit',
    order: 1,
    communicationConfig: {
      enabled: true,
      methods: ['both'],
      templateId: 'appointment-confirmation',
      timing: { daysBeforeAppointment: 7 },
      autoSend: true,
    },
    isActive: true,
    isRequired: false,
  },
  {
    id: 'pv-2',
    title: 'Complete Patient Forms',
    description: 'Send and collect patient intake forms',
    stepType: 'pre-visit',
    order: 2,
    formConfig: {
      enabled: true,
      templateIds: ['patient-intake', 'hipaa-privacy'],
      autoSend: true,
      required: true,
    },
    communicationConfig: {
      enabled: true,
      methods: ['both'],
      templateId: 'forms-request',
      timing: { daysBeforeAppointment: 5 },
      autoSend: true,
    },
    isActive: true,
    isRequired: true,
  },
  {
    id: 'pv-3',
    title: 'Insurance Verification',
    description: 'Collect and verify insurance information',
    stepType: 'pre-visit',
    order: 3,
    formConfig: {
      enabled: true,
      templateIds: ['insurance-card-upload'],
      autoSend: true,
      required: false,
    },
    isActive: true,
    isRequired: false,
  },
  {
    id: 'pv-4',
    title: 'Appointment Reminder',
    description: 'Send day-before reminder',
    stepType: 'pre-visit',
    order: 4,
    communicationConfig: {
      enabled: true,
      methods: ['sms'],
      templateId: 'appointment-reminder',
      timing: { daysBeforeAppointment: 1 },
      autoSend: true,
    },
    isActive: true,
    isRequired: false,
  },
];

// Default in-office steps with room configuration
const DEFAULT_IN_OFFICE_STEPS: JourneyStepTemplate[] = [
  {
    id: 'io-1',
    title: 'Check-In',
    description: 'Patient arrives and checks in',
    stepType: 'in-office',
    order: 1,
    roomConfig: {
      roomTypes: ['waiting'],
      defaultRoomType: 'waiting',
      requireRoom: false,
      expectedDuration: 5,
    },
    timing: {
      expectedDuration: 5,
      warningThreshold: 10,
      criticalThreshold: 15,
    },
    isActive: true,
    isRequired: true,
  },
  {
    id: 'io-2',
    title: 'Pre-Testing',
    description: 'Preliminary tests and measurements',
    stepType: 'in-office',
    order: 2,
    roomConfig: {
      roomTypes: ['pre-testing'],
      defaultRoomType: 'pre-testing',
      requireRoom: true,
      expectedDuration: 15,
    },
    timing: {
      expectedDuration: 15,
      warningThreshold: 20,
      criticalThreshold: 30,
    },
    isActive: true,
    isRequired: true,
  },
  {
    id: 'io-3',
    title: 'Doctor Examination',
    description: 'Comprehensive eye examination',
    stepType: 'in-office',
    order: 3,
    roomConfig: {
      roomTypes: ['exam-room'],
      defaultRoomType: 'exam-room',
      requireRoom: true,
      expectedDuration: 20,
    },
    timing: {
      expectedDuration: 20,
      warningThreshold: 30,
      criticalThreshold: 45,
    },
    isActive: true,
    isRequired: true,
  },
  {
    id: 'io-4',
    title: 'Dilation (if needed)',
    description: 'Wait for dilation to take effect',
    stepType: 'in-office',
    order: 4,
    roomConfig: {
      roomTypes: ['dilation', 'waiting'],
      defaultRoomType: 'dilation',
      requireRoom: true,
      expectedDuration: 20,
    },
    timing: {
      expectedDuration: 20,
      warningThreshold: 25,
      criticalThreshold: 35,
    },
    isActive: true,
    isRequired: false,
  },
  {
    id: 'io-5',
    title: 'Optical Consultation',
    description: 'Frame selection and lens options',
    stepType: 'in-office',
    order: 5,
    roomConfig: {
      roomTypes: ['optical'],
      defaultRoomType: 'optical',
      requireRoom: true,
      expectedDuration: 30,
    },
    timing: {
      expectedDuration: 30,
      warningThreshold: 40,
      criticalThreshold: 60,
    },
    isActive: true,
    isRequired: false,
  },
  {
    id: 'io-6',
    title: 'Check-Out',
    description: 'Payment and scheduling follow-up',
    stepType: 'in-office',
    order: 6,
    roomConfig: {
      roomTypes: ['checkout'],
      defaultRoomType: 'checkout',
      requireRoom: false,
      expectedDuration: 10,
    },
    timing: {
      expectedDuration: 10,
      warningThreshold: 15,
      criticalThreshold: 25,
    },
    isActive: true,
    isRequired: true,
  },
];

// Default post-visit steps
const DEFAULT_POST_VISIT_STEPS: JourneyStepTemplate[] = [
  {
    id: 'pov-1',
    title: 'Send Thank You',
    description: 'Thank patient for visit and provide summary',
    stepType: 'post-visit',
    order: 1,
    communicationConfig: {
      enabled: true,
      methods: ['email'],
      templateId: 'visit-summary',
      timing: { daysAfterAppointment: 0 },
      autoSend: true,
    },
    isActive: true,
    isRequired: false,
  },
  {
    id: 'pov-2',
    title: 'Patient Satisfaction Survey',
    description: 'Collect feedback on visit experience',
    stepType: 'post-visit',
    order: 2,
    formConfig: {
      enabled: true,
      templateIds: ['satisfaction-survey'],
      autoSend: true,
      required: false,
    },
    communicationConfig: {
      enabled: true,
      methods: ['email'],
      templateId: 'survey-request',
      timing: { daysAfterAppointment: 1 },
      autoSend: true,
    },
    isActive: true,
    isRequired: false,
  },
  {
    id: 'pov-3',
    title: 'Order Ready Notification',
    description: 'Notify when eyewear is ready for pickup',
    stepType: 'post-visit',
    order: 3,
    communicationConfig: {
      enabled: true,
      methods: ['both'],
      templateId: 'order-ready',
      autoSend: false, // Triggered when order arrives
    },
    isActive: true,
    isRequired: false,
  },
  {
    id: 'pov-4',
    title: 'Recall Reminder',
    description: 'Schedule and send recall reminder',
    stepType: 'post-visit',
    order: 4,
    communicationConfig: {
      enabled: true,
      methods: ['both'],
      templateId: 'recall-reminder',
      autoSend: false, // Triggered at recall date
    },
    isActive: true,
    isRequired: false,
  },
];

// Contact lens specific steps
const CONTACT_LENS_IN_OFFICE_STEPS: JourneyStepTemplate[] = [
  ...DEFAULT_IN_OFFICE_STEPS.slice(0, 3),
  {
    id: 'cl-io-4',
    title: 'Contact Lens Fitting',
    description: 'Fit and evaluate contact lenses',
    stepType: 'in-office',
    order: 4,
    roomConfig: {
      roomTypes: ['contact-lens', 'exam-room'],
      defaultRoomType: 'contact-lens',
      requireRoom: true,
      expectedDuration: 30,
    },
    timing: {
      expectedDuration: 30,
      warningThreshold: 40,
      criticalThreshold: 60,
    },
    isActive: true,
    isRequired: true,
  },
  {
    id: 'cl-io-5',
    title: 'Contact Lens Training',
    description: 'Teach insertion and removal',
    stepType: 'in-office',
    order: 5,
    roomConfig: {
      roomTypes: ['contact-lens'],
      defaultRoomType: 'contact-lens',
      requireRoom: true,
      expectedDuration: 20,
    },
    timing: {
      expectedDuration: 20,
      warningThreshold: 30,
      criticalThreshold: 45,
    },
    isActive: true,
    isRequired: false,
  },
  DEFAULT_IN_OFFICE_STEPS[5], // Check-out
];

export class JourneyTemplateService {
  // Get all templates
  static getTemplates(): JourneyTemplate[] {
    const stored = localStorage.getItem(TEMPLATES_STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
    
    // Initialize with default templates
    const defaults = this.getDefaultTemplates();
    localStorage.setItem(TEMPLATES_STORAGE_KEY, JSON.stringify(defaults));
    return defaults;
  }

  // Get default templates
  static getDefaultTemplates(): JourneyTemplate[] {
    const now = new Date();
    
    return [
      {
        id: 'template-comprehensive',
        name: 'Comprehensive Eye Exam',
        description: 'Standard journey for comprehensive eye examinations',
        preVisitPath: {
          id: 'path-pv-1',
          name: 'Standard Pre-Visit',
          phase: 'pre-visit',
          steps: DEFAULT_PRE_VISIT_STEPS,
          isDefault: true,
          isActive: true,
          createdAt: now,
          updatedAt: now,
        },
        inOfficePath: {
          id: 'path-io-1',
          name: 'Standard In-Office',
          phase: 'in-office',
          steps: DEFAULT_IN_OFFICE_STEPS,
          isDefault: true,
          isActive: true,
          createdAt: now,
          updatedAt: now,
        },
        postVisitPath: {
          id: 'path-pov-1',
          name: 'Standard Post-Visit',
          phase: 'post-visit',
          steps: DEFAULT_POST_VISIT_STEPS,
          isDefault: true,
          isActive: true,
          createdAt: now,
          updatedAt: now,
        },
        appointmentTypes: ['Comprehensive Eye Exam', 'Routine Eye Exam', 'Medical Eye Exam'],
        isDefault: true,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'template-contact-lens',
        name: 'Contact Lens Exam',
        description: 'Journey for contact lens fitting and follow-up',
        preVisitPath: {
          id: 'path-pv-cl',
          name: 'Contact Lens Pre-Visit',
          phase: 'pre-visit',
          steps: [
            ...DEFAULT_PRE_VISIT_STEPS.slice(0, 2),
            {
              id: 'pv-cl-3',
              title: 'Contact Lens Agreement',
              description: 'Send contact lens agreement form',
              stepType: 'pre-visit',
              order: 3,
              formConfig: {
                enabled: true,
                templateIds: ['contact-lens-agreement'],
                autoSend: true,
                required: true,
              },
              isActive: true,
              isRequired: true,
            },
            ...DEFAULT_PRE_VISIT_STEPS.slice(2),
          ],
          isDefault: false,
          isActive: true,
          createdAt: now,
          updatedAt: now,
        },
        inOfficePath: {
          id: 'path-io-cl',
          name: 'Contact Lens In-Office',
          phase: 'in-office',
          steps: CONTACT_LENS_IN_OFFICE_STEPS,
          isDefault: false,
          isActive: true,
          createdAt: now,
          updatedAt: now,
        },
        postVisitPath: {
          id: 'path-pov-cl',
          name: 'Contact Lens Post-Visit',
          phase: 'post-visit',
          steps: [
            ...DEFAULT_POST_VISIT_STEPS.slice(0, 2),
            {
              id: 'pov-cl-3',
              title: 'Contact Lens Follow-Up',
              description: 'Schedule follow-up appointment',
              stepType: 'post-visit',
              order: 3,
              communicationConfig: {
                enabled: true,
                methods: ['both'],
                templateId: 'cl-followup-reminder',
                timing: { daysAfterAppointment: 7 },
                autoSend: true,
              },
              isActive: true,
              isRequired: false,
            },
          ],
          isDefault: false,
          isActive: true,
          createdAt: now,
          updatedAt: now,
        },
        appointmentTypes: ['Contact Lens Exam', 'Contact Lens Follow-up'],
        isDefault: false,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      },
    ];
  }

  // Save templates
  static saveTemplates(templates: JourneyTemplate[]): void {
    localStorage.setItem(TEMPLATES_STORAGE_KEY, JSON.stringify(templates));
  }

  // Get template by ID
  static getTemplateById(templateId: string): JourneyTemplate | null {
    const templates = this.getTemplates();
    return templates.find(t => t.id === templateId) || null;
  }

  // Get template for appointment type
  static getTemplateForAppointmentType(appointmentType: string): JourneyTemplate | null {
    const templates = this.getTemplates();
    // Normalize for case/format-insensitive matching (e.g. "contact-lens-exam" matches "Contact Lens Exam")
    const normalize = (s: string) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    const normalized = normalize(appointmentType);
    const match = templates.find(t =>
      t.isActive && t.appointmentTypes.some(at => normalize(at) === normalized)
    );
    return match || templates.find(t => t.isDefault && t.isActive) || null;
  }

  // Add new template
  static addTemplate(template: Omit<JourneyTemplate, 'id' | 'createdAt' | 'updatedAt'>): JourneyTemplate {
    const templates = this.getTemplates();
    const newTemplate: JourneyTemplate = {
      ...template,
      id: `template-${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    templates.push(newTemplate);
    this.saveTemplates(templates);
    return newTemplate;
  }

  // Update template
  static updateTemplate(templateId: string, updates: Partial<JourneyTemplate>): JourneyTemplate | null {
    const templates = this.getTemplates();
    const index = templates.findIndex(t => t.id === templateId);
    if (index === -1) return null;
    
    templates[index] = {
      ...templates[index],
      ...updates,
      updatedAt: new Date(),
    };
    this.saveTemplates(templates);
    return templates[index];
  }

  // Delete template
  static deleteTemplate(templateId: string): boolean {
    const templates = this.getTemplates();
    const filtered = templates.filter(t => t.id !== templateId);
    if (filtered.length === templates.length) return false;
    this.saveTemplates(filtered);
    return true;
  }

  // Update step in a path
  static updateStep(
    templateId: string, 
    pathPhase: 'preVisitPath' | 'inOfficePath' | 'postVisitPath',
    stepId: string,
    updates: Partial<JourneyStepTemplate>
  ): JourneyStepTemplate | null {
    const template = this.getTemplateById(templateId);
    if (!template) return null;
    
    const path = template[pathPhase];
    if (!path) return null;
    
    const stepIndex = path.steps.findIndex(s => s.id === stepId);
    if (stepIndex === -1) return null;
    
    path.steps[stepIndex] = { ...path.steps[stepIndex], ...updates };
    this.updateTemplate(templateId, { [pathPhase]: path });
    
    return path.steps[stepIndex];
  }

  // Get steps for a specific phase
  static getStepsForPhase(templateId: string, phase: 'pre-visit' | 'in-office' | 'post-visit'): JourneyStepTemplate[] {
    const template = this.getTemplateById(templateId);
    if (!template) return [];
    
    const pathKey = phase === 'pre-visit' ? 'preVisitPath' : 
                    phase === 'in-office' ? 'inOfficePath' : 'postVisitPath';
    
    return template[pathKey]?.steps || [];
  }
}

export default JourneyTemplateService;
