/**
 * External API Service
 * Provides RESTful API endpoints for external system integration
 * Supports authentication, journey data access, and real-time updates
 */

import { PatientJourneyService } from './patient-journey-service';
import { stepAuditService } from './step-audit-service';
import { PatientJourney, JourneyStep } from '../types/patient-journey';
import { StepAuditLog, ReportingMetrics } from '../types/step-audit-log';

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: string;
  requestId: string;
}

export interface ApiKey {
  key: string;
  name: string;
  permissions: ApiPermission[];
  createdAt: Date;
  expiresAt?: Date;
  isActive: boolean;
}

export type ApiPermission = 
  | 'read:journeys'
  | 'write:journeys'
  | 'read:audit-logs'
  | 'read:reports'
  | 'webhook:receive';

export interface WebhookConfig {
  id: string;
  url: string;
  events: WebhookEvent[];
  isActive: boolean;
  secret?: string;
}

export type WebhookEvent =
  | 'journey.created'
  | 'journey.completed'
  | 'step.started'
  | 'step.completed'
  | 'step.failed'
  | 'phase.transitioned';

class ExternalApiService {
  private readonly STORAGE_KEY_API_KEYS = 'external_api_keys';
  private readonly STORAGE_KEY_WEBHOOKS = 'external_api_webhooks';
  private apiKeys: ApiKey[] = [];
  private webhooks: WebhookConfig[] = [];

  constructor() {
    this.loadConfig();
  }

  /**
   * Load configuration from storage
   */
  private loadConfig(): void {
    try {
      const keysData = localStorage.getItem(this.STORAGE_KEY_API_KEYS);
      if (keysData) {
        this.apiKeys = JSON.parse(keysData).map((k: any) => ({
          ...k,
          createdAt: new Date(k.createdAt),
          expiresAt: k.expiresAt ? new Date(k.expiresAt) : undefined
        }));
      }

      const webhooksData = localStorage.getItem(this.STORAGE_KEY_WEBHOOKS);
      if (webhooksData) {
        this.webhooks = JSON.parse(webhooksData);
      }
    } catch (error) {
      console.error('Error loading API config:', error);
    }
  }

  /**
   * Save configuration to storage
   */
  private saveConfig(): void {
    try {
      localStorage.setItem(this.STORAGE_KEY_API_KEYS, JSON.stringify(this.apiKeys));
      localStorage.setItem(this.STORAGE_KEY_WEBHOOKS, JSON.stringify(this.webhooks));
    } catch (error) {
      console.error('Error saving API config:', error);
    }
  }

  /**
   * Generate a new API key
   */
  generateApiKey(name: string, permissions: ApiPermission[], expiresInDays?: number): ApiKey {
    const key = `timeline_${this.generateRandomKey()}`;
    const apiKey: ApiKey = {
      key,
      name,
      permissions,
      createdAt: new Date(),
      expiresAt: expiresInDays ? new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000) : undefined,
      isActive: true
    };

    this.apiKeys.push(apiKey);
    this.saveConfig();
    return apiKey;
  }

  /**
   * Validate API key and check permissions
   */
  validateApiKey(key: string, requiredPermission?: ApiPermission): ApiResponse<{ valid: boolean; permissions: ApiPermission[] }> {
    const apiKey = this.apiKeys.find(k => k.key === key);

    if (!apiKey) {
      return this.errorResponse('Invalid API key');
    }

    if (!apiKey.isActive) {
      return this.errorResponse('API key is inactive');
    }

    if (apiKey.expiresAt && apiKey.expiresAt < new Date()) {
      return this.errorResponse('API key has expired');
    }

    if (requiredPermission && !apiKey.permissions.includes(requiredPermission)) {
      return this.errorResponse('Insufficient permissions');
    }

    return this.successResponse({
      valid: true,
      permissions: apiKey.permissions
    });
  }

  /**
   * API: Get all active journeys
   */
  getJourneys(apiKey: string, filters?: {
    phase?: string;
    patientId?: string;
    providerId?: string;
  }): ApiResponse<PatientJourney[]> {
    const auth = this.validateApiKey(apiKey, 'read:journeys');
    if (!auth.success) return this.errorResponse(auth.error || 'Authentication failed');

    let journeys = PatientJourneyService.getActiveJourneys();

    // Apply filters
    if (filters?.phase) {
      journeys = journeys.filter(j => j.journeyPhase === filters.phase);
    }
    if (filters?.patientId) {
      journeys = journeys.filter(j => j.patientId === filters.patientId);
    }
    if (filters?.providerId) {
      journeys = journeys.filter(j => j.providerId === filters.providerId);
    }

    return this.successResponse(journeys);
  }

  /**
   * API: Get journey by ID
   */
  getJourneyById(apiKey: string, journeyId: string): ApiResponse<PatientJourney | null> {
    const auth = this.validateApiKey(apiKey, 'read:journeys');
    if (!auth.success) return this.errorResponse(auth.error || 'Authentication failed');

    const journey = PatientJourneyService.getJourneyById(journeyId);
    return this.successResponse(journey);
  }

  /**
   * API: Get journey audit logs
   */
  getJourneyAuditLogs(apiKey: string, journeyId: string): ApiResponse<StepAuditLog[]> {
    const auth = this.validateApiKey(apiKey, 'read:audit-logs');
    if (!auth.success) return this.errorResponse(auth.error || 'Authentication failed');

    const logs = stepAuditService.getJourneyLogs(journeyId);
    return this.successResponse(logs);
  }

  /**
   * API: Get journey summary with metrics
   */
  getJourneySummary(apiKey: string, journeyId: string): ApiResponse<any> {
    const auth = this.validateApiKey(apiKey, 'read:audit-logs');
    if (!auth.success) return this.errorResponse(auth.error || 'Authentication failed');

    const summary = stepAuditService.getJourneySummary(journeyId);
    return this.successResponse(summary);
  }

  /**
   * API: Query audit logs
   */
  queryAuditLogs(apiKey: string, query: any): ApiResponse<any> {
    const auth = this.validateApiKey(apiKey, 'read:audit-logs');
    if (!auth.success) return this.errorResponse(auth.error || 'Authentication failed');

    const result = stepAuditService.queryLogs(query);
    return this.successResponse(result);
  }

  /**
   * API: Get reporting metrics
   */
  getReportingMetrics(apiKey: string, startDate: Date, endDate: Date): ApiResponse<ReportingMetrics> {
    const auth = this.validateApiKey(apiKey, 'read:reports');
    if (!auth.success) return this.errorResponse(auth.error || 'Authentication failed');

    const metrics = stepAuditService.generateMetrics(startDate, endDate);
    return this.successResponse(metrics);
  }

  /**
   * API: Export audit logs as CSV
   */
  exportAuditLogsCSV(apiKey: string, query?: any): ApiResponse<string> {
    const auth = this.validateApiKey(apiKey, 'read:audit-logs');
    if (!auth.success) return this.errorResponse(auth.error || 'Authentication failed');

    const csv = stepAuditService.exportToCSV(query);
    return this.successResponse(csv);
  }

  /**
   * API: Create/Update journey (for external system integration)
   */
  upsertJourney(apiKey: string, data: any): ApiResponse<PatientJourney> {
    const auth = this.validateApiKey(apiKey, 'write:journeys');
    if (!auth.success) return this.errorResponse(auth.error || 'Authentication failed');

    try {
      const journey = PatientJourneyService.createJourney(data);
      
      // Trigger webhook
      this.triggerWebhook('journey.created', { journey });
      
      return this.successResponse(journey);
    } catch (error: any) {
      return this.errorResponse(error.message);
    }
  }

  /**
   * API: Update step status
   */
  updateStepStatus(apiKey: string, journeyId: string, stepId: string, action: 'start' | 'complete' | 'skip'): ApiResponse<PatientJourney> {
    const auth = this.validateApiKey(apiKey, 'write:journeys');
    if (!auth.success) return this.errorResponse(auth.error || 'Authentication failed');

    try {
      const updated = PatientJourneyService.updateJourney({
        type: `${action}-step`,
        patientJourneyId: journeyId,
        stepId,
        data: { performedBy: 'external-api' }
      });

      if (!updated) {
        return this.errorResponse('Journey not found or update failed');
      }

      // Trigger webhook
      this.triggerWebhook(`step.${action === 'complete' ? 'completed' : 'started'}`, {
        journey: updated,
        stepId
      });

      return this.successResponse(updated);
    } catch (error: any) {
      return this.errorResponse(error.message);
    }
  }

  /**
   * Register a webhook endpoint
   */
  registerWebhook(url: string, events: WebhookEvent[], secret?: string): WebhookConfig {
    const webhook: WebhookConfig = {
      id: this.generateRandomKey(),
      url,
      events,
      isActive: true,
      secret
    };

    this.webhooks.push(webhook);
    this.saveConfig();
    return webhook;
  }

  /**
   * Trigger webhook for an event
   */
  private async triggerWebhook(event: WebhookEvent, data: any): Promise<void> {
    const activeWebhooks = this.webhooks.filter(w => w.isActive && w.events.includes(event));

    for (const webhook of activeWebhooks) {
      try {
        const payload = {
          event,
          timestamp: new Date().toISOString(),
          data
        };

        // In a real implementation, this would make an HTTP POST request
        console.log('Webhook triggered:', {
          url: webhook.url,
          event,
          payload
        });

        // Example: await fetch(webhook.url, { method: 'POST', body: JSON.stringify(payload) });
      } catch (error) {
        console.error('Webhook delivery failed:', error);
      }
    }
  }

  /**
   * Generate random API key
   */
  private generateRandomKey(): string {
    return Array.from({ length: 32 }, () => 
      Math.random().toString(36).charAt(2)
    ).join('');
  }

  /**
   * Create success response
   */
  private successResponse<T>(data: T): ApiResponse<T> {
    return {
      success: true,
      data,
      timestamp: new Date().toISOString(),
      requestId: this.generateRandomKey()
    };
  }

  /**
   * Create error response
   */
  private errorResponse(error: string): ApiResponse {
    return {
      success: false,
      error,
      timestamp: new Date().toISOString(),
      requestId: this.generateRandomKey()
    };
  }

  /**
   * Get all API keys
   */
  getApiKeys(): ApiKey[] {
    return [...this.apiKeys];
  }

  /**
   * Revoke API key
   */
  revokeApiKey(key: string): void {
    const apiKey = this.apiKeys.find(k => k.key === key);
    if (apiKey) {
      apiKey.isActive = false;
      this.saveConfig();
    }
  }

  /**
   * Get all webhooks
   */
  getWebhooks(): WebhookConfig[] {
    return [...this.webhooks];
  }

  /**
   * Delete webhook
   */
  deleteWebhook(id: string): void {
    this.webhooks = this.webhooks.filter(w => w.id !== id);
    this.saveConfig();
  }

  /**
   * Get API documentation
   */
  getApiDocumentation(): any {
    return {
      version: '1.0.0',
      baseUrl: '/api/v1',
      authentication: {
        type: 'API Key',
        header: 'X-API-Key',
        description: 'Include your API key in the X-API-Key header'
      },
      endpoints: [
        {
          method: 'GET',
          path: '/journeys',
          description: 'Get all active journeys',
          permissions: ['read:journeys'],
          queryParams: {
            phase: 'Filter by journey phase (pre-visit, in-office, post-visit)',
            patientId: 'Filter by patient ID',
            providerId: 'Filter by provider ID'
          }
        },
        {
          method: 'GET',
          path: '/journeys/:id',
          description: 'Get journey by ID',
          permissions: ['read:journeys']
        },
        {
          method: 'GET',
          path: '/journeys/:id/audit-logs',
          description: 'Get audit logs for a journey',
          permissions: ['read:audit-logs']
        },
        {
          method: 'GET',
          path: '/journeys/:id/summary',
          description: 'Get journey summary with metrics',
          permissions: ['read:audit-logs']
        },
        {
          method: 'POST',
          path: '/journeys',
          description: 'Create a new journey',
          permissions: ['write:journeys'],
          body: {
            patientId: 'string (required)',
            patientName: 'string (required)',
            appointmentId: 'string',
            providerId: 'string',
            providerName: 'string',
            reasonForVisit: 'string'
          }
        },
        {
          method: 'POST',
          path: '/journeys/:id/steps/:stepId/start',
          description: 'Start a step',
          permissions: ['write:journeys']
        },
        {
          method: 'POST',
          path: '/journeys/:id/steps/:stepId/complete',
          description: 'Complete a step',
          permissions: ['write:journeys']
        },
        {
          method: 'GET',
          path: '/audit-logs',
          description: 'Query audit logs',
          permissions: ['read:audit-logs'],
          queryParams: {
            journeyId: 'Filter by journey ID',
            startDate: 'ISO date string',
            endDate: 'ISO date string',
            eventType: 'Filter by event type',
            page: 'Page number (default: 1)',
            limit: 'Results per page (default: 50)'
          }
        },
        {
          method: 'GET',
          path: '/reports/metrics',
          description: 'Get reporting metrics',
          permissions: ['read:reports'],
          queryParams: {
            startDate: 'ISO date string (required)',
            endDate: 'ISO date string (required)'
          }
        },
        {
          method: 'GET',
          path: '/audit-logs/export',
          description: 'Export audit logs as CSV',
          permissions: ['read:audit-logs']
        }
      ],
      webhooks: {
        events: [
          'journey.created',
          'journey.completed',
          'step.started',
          'step.completed',
          'step.failed',
          'phase.transitioned'
        ],
        payload: {
          event: 'Event name',
          timestamp: 'ISO date string',
          data: 'Event-specific data'
        }
      }
    };
  }
}

// Export singleton instance
export const externalApiService = new ExternalApiService();
