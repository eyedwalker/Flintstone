/**
 * Form Submission Service
 * Manages form submissions, access tokens, and patient form completion
 */

import { v4 as uuidv4 } from 'uuid';
import DemoModeService from '../../services/demoModeService';
import { 
  FormSubmission, 
  FormTemplate, 
  CreateFormSubmissionData,
  FormAccessResult,
  FormValidationResult,
  FormDeliveryResult,
  FileAttachment
} from '../types/forms';
import { patientIntakeFormTemplate } from '../../data/form-templates/patient-intake-form';
import { 
  documentUploadFormTemplate, 
  insuranceCardUploadTemplate,
  driversLicenseUploadTemplate 
} from '../../data/form-templates/document-upload-template';
import { allFormTemplates } from '../../data/form-templates';
import FormPrefillService, { PatientData, PrefillOptions, defaultPrefillOptions } from './form-prefill-service';

const SUBMISSIONS_STORAGE_KEY = 'form_submissions';
const TEMPLATES_STORAGE_KEY = 'form_templates';

// Generate a secure access token
function generateAccessToken(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let token = '';
  for (let i = 0; i < 32; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return token;
}

class FormSubmissionServiceClass {
  private baseUrl = window.location.origin;

  // Get all form templates
  getTemplates(): FormTemplate[] {
    const stored = localStorage.getItem(TEMPLATES_STORAGE_KEY);
    const customTemplates: FormTemplate[] = stored ? JSON.parse(stored) : [];
    
    // Combine with system templates (includes all eyecare forms)
    return [
      patientIntakeFormTemplate,
      documentUploadFormTemplate,
      insuranceCardUploadTemplate,
      driversLicenseUploadTemplate,
      ...allFormTemplates,
      ...customTemplates,
    ];
  }

  // Get template by ID
  getTemplateById(templateId: string): FormTemplate | null {
    const templates = this.getTemplates();
    return templates.find(t => t.id === templateId) || null;
  }

  // Get all submissions from localStorage (sync fallback)
  getAllSubmissions(): FormSubmission[] {
    const stored = localStorage.getItem(SUBMISSIONS_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  // Fetch all submissions from the database via API
  async fetchAllSubmissions(): Promise<FormSubmission[]> {
    try {
      const response = await fetch('/api/forms/submission');
      if (!response.ok) {
        throw new Error(`API returned ${response.status}`);
      }
      const result = await response.json();
      const submissions: FormSubmission[] = result.submissions || [];

      // Sync to localStorage so other methods stay consistent
      this.saveSubmissions(submissions);
      return submissions;
    } catch (err) {
      console.error('[FormSubmission] API fetch failed, falling back to localStorage:', err);
      return this.getAllSubmissions();
    }
  }

  // Save submissions
  private saveSubmissions(submissions: FormSubmission[]): void {
    localStorage.setItem(SUBMISSIONS_STORAGE_KEY, JSON.stringify(submissions));
  }

  // Get submissions by patient ID (sync, from localStorage)
  getSubmissionsByPatientId(patientId: string): FormSubmission[] {
    return this.getAllSubmissions().filter(s => s.patientId === patientId);
  }

  // Fetch submissions by patient ID from the API
  async fetchSubmissionsByPatientId(patientId: string): Promise<FormSubmission[]> {
    const all = await this.fetchAllSubmissions();
    return all.filter(s => s.patientId === patientId);
  }

  // Get submission by ID
  getSubmissionById(submissionId: string): FormSubmission | null {
    return this.getAllSubmissions().find(s => s.submissionId === submissionId) || null;
  }

  // Get submission by access token
  getSubmissionByToken(accessToken: string): FormSubmission | null {
    return this.getAllSubmissions().find(s => s.accessToken === accessToken) || null;
  }

  // Create a new form submission with auto-prefill (enabled by default)
  createSubmission(data: CreateFormSubmissionData): FormSubmission {
    const template = this.getTemplateById(data.templateId);
    if (!template) {
      throw new Error(`Template not found: ${data.templateId}`);
    }

    const submissionId = uuidv4();
    const accessToken = generateAccessToken();
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30); // 30 days expiration

    const accessLink = `${this.baseUrl}/forms/patient/${accessToken}`;

    // Auto-prefill is ON by default
    const prefillOptions = data.prefillOptions || defaultPrefillOptions;
    
    // Extract patient data from provided data or build from basic info
    const patientData: PatientData = data.patientData 
      ? FormPrefillService.extractPatientData(data.patientData)
      : {
          fullName: data.patientName,
          email: data.patientEmail,
          mobilePhone: data.patientPhone,
          examDate: new Date().toISOString().split('T')[0],
        };

    // Generate prefilled responses
    const prefilledFromPatient = FormPrefillService.generatePrefillData(patientData, prefillOptions);
    
    // Merge: explicit prefilledResponses override auto-generated ones
    const mergedResponses = FormPrefillService.mergeWithExisting(
      prefilledFromPatient,
      data.prefilledResponses || {}
    );

    const submission: FormSubmission = {
      submissionId,
      patientId: data.patientId,
      patientName: data.patientName,
      taskId: data.taskId,
      appointmentId: data.appointmentId,
      templateId: data.templateId,
      formTitle: template.title,
      formType: data.formType || 'standard',
      status: 'sent',
      responses: mergedResponses,
      verificationSettings: {
        method: data.verificationMethod || 'none',
        required: data.verificationMethod !== 'none',
        verified: false,
        attempts: 0,
        bypassVerification: false,
      },
      documentType: data.documentType,
      documentDescription: data.documentDescription,
      fileAttachments: [],
      expiresAt,
      accessToken,
      accessLink,
      viewCount: 0,
      journeyId: data.journeyId,
      journeyStepId: data.journeyStepId,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const submissions = this.getAllSubmissions();
    submissions.push(submission);
    this.saveSubmissions(submissions);

    // Store via API for cross-device access (patient portal)
    // Save promise so callers can await if needed
    this._lastApiStore = this.storeSubmissionViaAPI(submission, template).catch(err => {
      console.error('[FormSubmission] API storage failed:', err);
    });

    return submission;
  }

  // Wait for the most recent API storage to complete
  async waitForApiStorage(): Promise<void> {
    if (this._lastApiStore) {
      await this._lastApiStore;
      this._lastApiStore = null;
    }
  }

  private _lastApiStore: Promise<any> | null = null;

  // Store submission via API for patient portal access
  private async storeSubmissionViaAPI(submission: FormSubmission, template: FormTemplate): Promise<void> {
    try {
      const response = await fetch('/api/forms/submission', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          templateId: submission.templateId,
          template: template,
          patientId: submission.patientId,
          patientName: submission.patientName,
          patientEmail: submission.patientEmail || '',
          patientPhone: submission.patientPhone || '',
          accessToken: submission.accessToken,
          expiresAt: submission.expiresAt,
          verification: {
            required: submission.verificationSettings?.required || false,
            verified: false,
          },
          prefillData: submission.responses,
        }),
      });
      
      if (!response.ok) {
        throw new Error(`API returned ${response.status}`);
      }
      
      const result = await response.json();
      console.log('[FormSubmission] Stored via API:', result.submission?.submissionId);
    } catch (err) {
      console.error('[FormSubmission] API storage error:', err);
      throw err;
    }
  }

  // Access a form by token (patient portal)
  accessFormByToken(accessToken: string): FormAccessResult | null {
    const submission = this.getSubmissionByToken(accessToken);
    if (!submission) {
      return null;
    }

    // Check expiration
    if (submission.expiresAt && new Date() > new Date(submission.expiresAt)) {
      return null;
    }

    // Check if completed
    if (submission.status === 'completed') {
      return null;
    }

    const template = this.getTemplateById(submission.templateId);
    if (!template) {
      return null;
    }

    // Update view count and status
    submission.viewCount = (submission.viewCount || 0) + 1;
    submission.lastViewed = new Date();
    if (submission.status === 'sent') {
      submission.status = 'viewed';
    }
    submission.updatedAt = new Date();
    this.updateSubmission(submission);

    return { submission, template };
  }

  // Validate form token
  validateToken(accessToken: string): FormValidationResult {
    const submission = this.getSubmissionByToken(accessToken);
    
    if (!submission) {
      return { valid: false, error: 'Form not found' };
    }

    // Check expiration
    if (submission.expiresAt && new Date() > new Date(submission.expiresAt)) {
      return { valid: false, error: 'Form has expired', expired: true };
    }

    // Check if completed
    if (submission.status === 'completed') {
      return { valid: false, error: 'Form already completed', completed: true };
    }

    return {
      valid: true,
      formSubmission: {
        submissionId: submission.submissionId,
        formTitle: submission.formTitle,
        templateId: submission.templateId,
        status: submission.status,
        formType: submission.formType,
        documentType: submission.documentType,
        patientName: submission.patientName,
        expiresAt: submission.expiresAt,
        verification: {
          required: submission.verificationSettings?.required || false,
          verified: submission.verificationSettings?.verified || false,
          method: submission.verificationSettings?.method || 'none',
          attempts: submission.verificationSettings?.attempts || 0,
        },
      },
    };
  }

  // Update form responses (save progress)
  updateResponses(submissionId: string, responses: Record<string, any>): FormSubmission | null {
    const submission = this.getSubmissionById(submissionId);
    if (!submission) return null;

    submission.responses = { ...submission.responses, ...responses };
    if (submission.status === 'viewed') {
      submission.status = 'in_progress';
    }
    submission.updatedAt = new Date();
    
    return this.updateSubmission(submission);
  }

  // Add file attachment
  addFileAttachment(submissionId: string, attachment: FileAttachment): FormSubmission | null {
    const submission = this.getSubmissionById(submissionId);
    if (!submission) return null;

    submission.fileAttachments = submission.fileAttachments || [];
    submission.fileAttachments.push(attachment);
    submission.updatedAt = new Date();
    
    return this.updateSubmission(submission);
  }

  // Complete form submission
  completeSubmission(submissionId: string, finalResponses?: Record<string, any>): FormSubmission | null {
    const submission = this.getSubmissionById(submissionId);
    if (!submission) return null;

    if (finalResponses) {
      submission.responses = { ...submission.responses, ...finalResponses };
    }
    submission.status = 'completed';
    submission.completedAt = new Date();
    submission.updatedAt = new Date();
    
    return this.updateSubmission(submission);
  }

  // Verify patient identity
  verifyPatient(
    submissionId: string, 
    verificationData: { dob?: string; phone?: string; email?: string; zip?: string; lastName?: string }
  ): { success: boolean; error?: string; locked?: boolean } {
    const submission = this.getSubmissionById(submissionId);
    if (!submission || !submission.verificationSettings) {
      return { success: false, error: 'Submission not found' };
    }

    const settings = submission.verificationSettings;

    // Check if locked
    if (settings.lockedUntil && new Date() < new Date(settings.lockedUntil)) {
      const minutesLeft = Math.ceil((new Date(settings.lockedUntil).getTime() - Date.now()) / 60000);
      return { success: false, error: `Too many attempts. Please try again in ${minutesLeft} minutes.`, locked: true };
    }

    // Increment attempts
    settings.attempts = (settings.attempts || 0) + 1;
    settings.lastAttempt = new Date();

    // Lock after 3 failed attempts
    if (settings.attempts >= 3) {
      settings.lockedUntil = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes
    }

    // For demo, always verify successfully after checking format
    // In production, this would validate against actual patient data
    let verified = false;
    switch (settings.method) {
      case 'dob':
        verified = !!verificationData.dob && verificationData.dob.length >= 8;
        break;
      case 'phone':
        verified = !!verificationData.phone && verificationData.phone.length >= 10;
        break;
      case 'email':
        verified = !!verificationData.email && verificationData.email.includes('@');
        break;
      case 'zipLastName':
        verified = !!verificationData.zip && !!verificationData.lastName;
        break;
      case 'none':
        verified = true;
        break;
    }

    if (verified) {
      settings.verified = true;
      settings.attempts = 0;
      settings.lockedUntil = undefined;
    }

    submission.verificationSettings = settings;
    submission.updatedAt = new Date();
    this.updateSubmission(submission);

    if (verified) {
      return { success: true };
    } else {
      const attemptsLeft = 3 - settings.attempts;
      return { 
        success: false, 
        error: attemptsLeft > 0 
          ? `Verification failed. ${attemptsLeft} attempts remaining.`
          : 'Too many failed attempts. Please try again in 15 minutes.',
        locked: attemptsLeft <= 0
      };
    }
  }

  // Update a submission
  private updateSubmission(submission: FormSubmission): FormSubmission {
    const submissions = this.getAllSubmissions();
    const index = submissions.findIndex(s => s.submissionId === submission.submissionId);
    if (index !== -1) {
      submissions[index] = submission;
      this.saveSubmissions(submissions);
    }
    return submission;
  }

  // Send form to patient via real SMS/Email APIs
  async sendFormToPatient(
    submissionId: string,
    patientEmail?: string,
    patientPhone?: string
  ): Promise<FormDeliveryResult> {
    const submission = this.getSubmissionById(submissionId);
    if (!submission) {
      return { emailSent: false, smsSent: false };
    }

    const result: FormDeliveryResult = {
      emailSent: false,
      smsSent: false,
    };

    // Check demo mode and redirect if enabled
    const demoSettings = DemoModeService.getSettings();
    const targetEmail = demoSettings.enabled && demoSettings.demoEmail 
      ? demoSettings.demoEmail 
      : patientEmail;
    const targetPhone = demoSettings.enabled && demoSettings.demoPhone 
      ? demoSettings.demoPhone 
      : patientPhone;

    const formMessage = `Please complete your ${submission.formTitle}: ${submission.accessLink}`;

    // Send SMS via real API
    if (patientPhone && targetPhone) {
      if (demoSettings.enabled) {
        console.log(`[DEMO MODE] Form SMS redirected from ${patientPhone} to ${targetPhone}`);
      }
      try {
        const response = await fetch('/api/communications/send-sms', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: targetPhone,
            message: formMessage,
          }),
        });
        const smsResult = await response.json();
        result.smsSent = smsResult.success;
        result.smsResult = smsResult;
        console.log(`[FormSubmission] SMS sent to ${targetPhone}:`, smsResult.success);
      } catch (err) {
        console.error('[FormSubmission] SMS error:', err);
        result.smsResult = { success: false, error: String(err) };
      }
    }

    // Send Email via real API
    if (patientEmail && targetEmail) {
      if (demoSettings.enabled) {
        console.log(`[DEMO MODE] Form email redirected from ${patientEmail} to ${targetEmail}`);
      }
      try {
        const response = await fetch('/api/communications/send-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: targetEmail,
            subject: `Action Required: ${submission.formTitle}`,
            body: `Please complete the following form:\n\n${submission.formTitle}\n\nClick here to access: ${submission.accessLink}\n\nThis link will expire in 30 days.`,
          }),
        });
        const emailResult = await response.json();
        result.emailSent = emailResult.success;
        result.emailResult = emailResult;
        console.log(`[FormSubmission] Email sent to ${targetEmail}:`, emailResult.success);
      } catch (err) {
        console.error('[FormSubmission] Email error:', err);
        result.emailResult = { success: false, error: String(err) };
      }
    }

    return result;
  }

  // Resend form using stored patient contact info
  async resendForm(submissionId: string, patientEmail?: string, patientPhone?: string): Promise<FormDeliveryResult> {
    const submission = this.getSubmissionById(submissionId);
    if (!submission) {
      return { emailSent: false, smsSent: false };
    }

    // Reset status if needed
    if (submission.status === 'expired') {
      submission.status = 'sent';
      submission.expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
      this.updateSubmission(submission);
    }

    // Resend using the sendFormToPatient method
    return this.sendFormToPatient(submissionId, patientEmail, patientPhone);
  }

  // Delete a submission
  deleteSubmission(submissionId: string): boolean {
    const submissions = this.getAllSubmissions();
    const index = submissions.findIndex(s => s.submissionId === submissionId);
    if (index !== -1) {
      submissions.splice(index, 1);
      this.saveSubmissions(submissions);
      return true;
    }
    return false;
  }

  // Create a document upload request
  createDocumentRequest(
    patientId: string,
    patientName: string,
    documentType: string,
    description?: string,
    options?: {
      patientEmail?: string;
      patientPhone?: string;
      journeyId?: string;
      journeyStepId?: string;
    }
  ): FormSubmission {
    const submission = this.createSubmission({
      patientId,
      patientName,
      templateId: 'system-document-upload',
      formType: 'document-upload',
      documentType,
      documentDescription: description,
      journeyId: options?.journeyId,
      journeyStepId: options?.journeyStepId,
      verificationMethod: 'dob',
    });

    // Send notifications if contact info provided
    if (options?.patientEmail || options?.patientPhone) {
      this.sendFormToPatient(submission.submissionId, options.patientEmail, options.patientPhone);
    }

    return submission;
  }
}

export const FormSubmissionService = new FormSubmissionServiceClass();
