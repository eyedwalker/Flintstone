/**
 * Appointment Sync Service
 * Handles automated syncing of appointments from Eyefinity API
 */

import { appointmentAccessor } from '../accessors/AppointmentAccessor';
import { patientAccessor } from '../accessors/PatientAccessor';
import { companyAccessor } from '../accessors/CompanyAccessor';
import { officeAccessor } from '../accessors/OfficeAccessor';

interface EyefinityAppointment {
  AppointmentId: string;
  PatientId: string;
  ProviderId?: string;
  LocationId?: string;
  AppointmentDate: string;
  Duration: number;
  AppointmentType: string;
  Status: string;
  ReasonForVisit?: string;
  Notes?: string;
}

interface SyncResult {
  success: boolean;
  created: number;
  updated: number;
  failed: number;
  errors: string[];
}

export class AppointmentSyncService {
  /**
   * Sync appointments from Eyefinity for a date range
   */
  static async syncAppointments(
    companyId: string,
    startDate: string,
    endDate: string
  ): Promise<SyncResult> {
    const result: SyncResult = {
      success: true,
      created: 0,
      updated: 0,
      failed: 0,
      errors: [],
    };

    try {
      // Get company to ensure it exists
      const companyResult = await companyAccessor.getById(companyId);
      if (!companyResult.success) {
        throw new Error('Company not found');
      }

      // Fetch appointments from Eyefinity proxy
      const path = `appointments?fromDate=${startDate}&toDate=${endDate}&page=1&pageSize=1000`;
      const response = await fetch(`/api/eyefinity/${path}`, {
        headers: {
          'Accept': 'application/json',
          'X-Company-Id': companyId,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch appointments: ${response.statusText}`);
      }

      const appointments: EyefinityAppointment[] = await response.json();

      // Process each appointment
      for (const appt of appointments) {
        try {
          await this.processAppointment(companyId, appt, result);
        } catch (error: any) {
          result.failed++;
          result.errors.push(`Failed to process appointment ${appt.AppointmentId}: ${error.message}`);
        }
      }

      result.success = result.failed === 0;
      return result;
    } catch (error: any) {
      result.success = false;
      result.errors.push(`Sync failed: ${error.message}`);
      return result;
    }
  }

  /**
   * Process a single appointment - create or update
   */
  private static async processAppointment(
    companyId: string,
    appt: EyefinityAppointment,
    result: SyncResult
  ): Promise<void> {
    // Check if appointment already exists
    const existingResult = await appointmentAccessor.getByEyefinityId(appt.AppointmentId, companyId);

    // Ensure patient exists (sync if needed)
    const patientResult = await patientAccessor.getByEyefinityId(appt.PatientId, companyId);
    let patientId: string;

    if (!patientResult.success) {
      // Patient doesn't exist - would need to fetch and create
      // For now, skip this appointment
      throw new Error(`Patient ${appt.PatientId} not found - sync patients first`);
    }
    patientId = patientResult.data!.id;

    // Map office if provided
    let officeId: string | undefined;
    if (appt.LocationId) {
      const officeResult = await officeAccessor.getByEyefinityId(appt.LocationId);
      if (officeResult.success) {
        officeId = officeResult.data!.id;
      }
    }

    // If no office mapped, get first office for company
    if (!officeId) {
      const officesResult = await officeAccessor.getByCompany(companyId);
      if (officesResult.success && officesResult.data!.length > 0) {
        officeId = officesResult.data![0].id;
      } else {
        throw new Error('No office found for company');
      }
    }

    // Map status
    const statusMap: Record<string, any> = {
      'scheduled': 'scheduled',
      'confirmed': 'confirmed',
      'checked_in': 'checked_in',
      'in_progress': 'in_progress',
      'completed': 'completed',
      'cancelled': 'cancelled',
      'no_show': 'no_show',
    };
    const status = statusMap[appt.Status?.toLowerCase()] || 'scheduled';

    const appointmentData = {
      company_id: companyId,
      office_id: officeId,
      patient_id: patientId,
      provider_id: undefined, // Would need to map provider if available
      eyefinity_appointment_id: appt.AppointmentId,
      appointment_date: appt.AppointmentDate,
      duration_minutes: appt.Duration || 30,
      appointment_type: appt.AppointmentType || 'general',
      status,
      reason_for_visit: appt.ReasonForVisit,
      notes: appt.Notes,
      reminder_sent: false,
      settings: {},
    };

    if (existingResult.success) {
      // Update existing appointment
      await appointmentAccessor.update(existingResult.data!.id, appointmentData);
      result.updated++;
    } else {
      // Create new appointment
      await appointmentAccessor.create(appointmentData);
      result.created++;
    }
  }

  /**
   * Sync appointments for today and next 90 days
   */
  static async syncUpcoming(companyId: string): Promise<SyncResult> {
    const today = new Date().toISOString().split('T')[0];
    const future = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    return this.syncAppointments(companyId, today, future);
  }

  /**
   * Sync appointments for past 30 days (for historical data)
   */
  static async syncRecent(companyId: string): Promise<SyncResult> {
    const past = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const today = new Date().toISOString().split('T')[0];
    return this.syncAppointments(companyId, past, today);
  }
}
