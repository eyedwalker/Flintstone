/**
 * Patient Journey Service
 * Manages patient journey lifecycle including creation, updates, and phase transitions
 */

import { v4 as uuidv4 } from 'uuid';
import { 
  JourneyAction, 
  JourneyStep, 
  PatientJourney, 
  CreateJourneyData,
  JourneyPhase
} from '../types/patient-journey';
import { RecommendationEngine } from './recommendation-engine';
import { PatientContext, AppointmentContext } from '../types/journey-rules';
import { getJourneyRulesService } from './journey-rules-service';

// Lazy import to avoid circular dependency
let journeyTrigger: { onJourneyCreated: (j: PatientJourney) => Promise<any>; onPhaseChanged: (j: PatientJourney, prev: JourneyPhase, next: JourneyPhase) => Promise<any> } | null = null;
const getJourneyTrigger = async () => {
  if (!journeyTrigger) {
    const mod = await import('./journey-communication-trigger');
    journeyTrigger = mod.JourneyCommunicationTrigger;
  }
  return journeyTrigger;
};

// LocalStorage key for journeys
const JOURNEYS_STORAGE_KEY = 'patient_journeys';

export class PatientJourneyService {
  /**
   * Create a new patient journey with pre-visit, in-office, and post-visit phases
   */
  static createJourney(data: CreateJourneyData): PatientJourney {
    const startPhase = data.startPhase || 'pre-visit';
    let steps: JourneyStep[] = [];

    // Build context for rules evaluation
    const rulesContext: AppointmentContext = {
      patientId: data.patientId,
      appointmentId: data.appointmentId,
      appointmentType: data.appointmentContext?.appointmentType || data.reasonForVisit,
      providerId: data.providerId,
      officeId: data.appointmentContext?.officeId || '',
      isNewPatient: data.appointmentContext?.isNewPatient ?? false,
      hasInsurance: data.appointmentContext?.hasInsurance ?? true,
      previousVisitCount: data.appointmentContext?.isNewPatient ? 0 : 1,
      reasonForVisit: data.reasonForVisit,
    };

    // Try admin-configured rules first, fall back to hardcoded defaults
    let rulesService: ReturnType<typeof getJourneyRulesService> | null = null;
    try {
      rulesService = getJourneyRulesService();
    } catch (err) {
      console.error('Error loading rules service:', err);
    }

    // Add pre-visit steps if starting in pre-visit phase
    if (startPhase === 'pre-visit') {
      const rulesPreVisit = rulesService?.getPreVisitSteps(rulesContext) || [];
      steps = rulesPreVisit.length > 0 ? rulesPreVisit : [...this.getPreVisitJourneySteps()];
    }

    // Add in-office steps — rules first, then RecommendationEngine, then hardcoded
    let inOfficeSteps: JourneyStep[] = [];
    const rulesInOffice = rulesService?.getInOfficeSteps(rulesContext) || [];

    if (rulesInOffice.length > 0) {
      inOfficeSteps = rulesInOffice;
    } else if (data.taskId) {
      try {
        const context: PatientContext = {
          patient: { id: data.patientId, name: data.patientName },
          task: {
            _id: data.taskId,
            providerId: data.providerId,
            providerName: data.providerName,
            reasonForVisit: data.reasonForVisit
          }
        };

        const recommendations = RecommendationEngine.generateJourneyRecommendations(context);

        // Convert recommendations to journey steps
        inOfficeSteps = recommendations.map(rec => ({
          id: rec.id,
          title: rec.title,
          description: rec.description,
          status: 'pending' as const,
          staffRole: rec.staffRole,
          reasonCodes: rec.reasonCodes,
          duration: rec.estimatedDuration,
          stepType: 'in-office' as const,
          responseRequired: false
        }));
      } catch (error) {
        console.error('Error generating journey recommendations:', error);
        inOfficeSteps = this.getDefaultInOfficeJourneySteps();
      }
    } else {
      inOfficeSteps = this.getDefaultInOfficeJourneySteps();
    }

    // Add in-office steps to the journey
    steps = [...steps, ...inOfficeSteps];

    // Add post-visit steps — rules first, then hardcoded
    const rulesPostVisit = rulesService?.getPostVisitSteps(rulesContext) || [];
    steps = [...steps, ...(rulesPostVisit.length > 0 ? rulesPostVisit : this.getPostVisitJourneySteps())];

    // Set up currentStepId based on phase
    let currentStepId: string | undefined;
    if (steps.length > 0) {
      if (startPhase === 'pre-visit') {
        const firstPreVisitStep = steps.find(step => step.stepType === 'pre-visit');
        currentStepId = firstPreVisitStep?.id;
      } else {
        const firstInOfficeStep = steps.find(step => step.stepType === 'in-office');
        currentStepId = firstInOfficeStep?.id;
      }
    }
    
    const now = new Date();
    
    const journey: PatientJourney = {
      id: uuidv4(),
      patientId: data.patientId,
      patientName: data.patientName,
      taskId: data.taskId,
      appointmentId: data.appointmentId,
      providerId: data.providerId,
      providerName: data.providerName,
      reasonForVisit: data.reasonForVisit,
      priority: data.priority || 'normal',
      status: 'active',
      steps,
      currentStepId,
      checkInTime: now,
      createdAt: now,
      updatedAt: now,
      journeyPhase: startPhase,
      scheduledAppointmentDate: data.scheduledAppointmentDate,
      preVisitStartDate: startPhase === 'pre-visit' ? now : undefined,
      inOfficeStartDate: startPhase === 'in-office' ? now : undefined,
      legacyPatientId: data.legacyPatientId,
      legacyAppointmentId: data.legacyAppointmentId,
    };

    // Save to localStorage
    const journeys = this.getAllJourneys();
    journeys.push(journey);
    this.saveJourneys(journeys);
    
    // Trigger AI communication (async, don't await)
    getJourneyTrigger().then(trigger => {
      trigger?.onJourneyCreated(journey).catch(console.error);
    }).catch(console.error);
    
    return journey;
  }

  /**
   * Get all journeys from localStorage
   */
  static getAllJourneys(): PatientJourney[] {
    try {
      const stored = localStorage.getItem(JOURNEYS_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  /**
   * Save journeys to localStorage
   */
  private static saveJourneys(journeys: PatientJourney[]): void {
    localStorage.setItem(JOURNEYS_STORAGE_KEY, JSON.stringify(journeys));
  }

  /**
   * Get active patient journeys for the office view
   */
  static getActiveJourneys(): PatientJourney[] {
    const journeys = this.getAllJourneys().filter(j => j.status === 'active');
    const now = new Date();
    
    // Process journeys to add wait time and progress percentage
    return journeys.map(journey => {
      const journeyObj = { ...journey };
      
      // Calculate progress based on steps for the current phase only
      if (journeyObj.journeyPhase === 'pre-visit') {
        const preVisitSteps = journeyObj.steps.filter(step => step.stepType === 'pre-visit');
        if (preVisitSteps.length > 0) {
          const completedSteps = preVisitSteps.filter(step => 
            ['completed', 'skipped'].includes(step.status)
          ).length;
          journeyObj.progressPercentage = Math.floor((completedSteps / preVisitSteps.length) * 100);
        }
      } else if (journeyObj.journeyPhase === 'in-office') {
        const inOfficeSteps = journeyObj.steps.filter(step => step.stepType === 'in-office');
        if (inOfficeSteps.length > 0) {
          const completedSteps = inOfficeSteps.filter(step => 
            ['completed', 'skipped'].includes(step.status)
          ).length;
          journeyObj.progressPercentage = Math.floor((completedSteps / inOfficeSteps.length) * 100);
        }
      } else if (journeyObj.journeyPhase === 'post-visit') {
        const postVisitSteps = journeyObj.steps.filter(step => step.stepType === 'post-visit');
        if (postVisitSteps.length > 0) {
          const completedSteps = postVisitSteps.filter(step => 
            ['completed', 'skipped'].includes(step.status)
          ).length;
          journeyObj.progressPercentage = Math.floor((completedSteps / postVisitSteps.length) * 100);
        }
      }
      
      // Calculate wait time for current step
      if (journeyObj.currentStepId) {
        const currentStep = journeyObj.steps.find(step => step.id === journeyObj.currentStepId);
        
        if (currentStep && currentStep.status === 'in-progress' && currentStep.startTime) {
          const startTime = new Date(currentStep.startTime);
          journeyObj.waitTime = Math.floor((now.getTime() - startTime.getTime()) / (1000 * 60));
        }
      }
      
      return journeyObj;
    }).sort((a, b) => {
      // Sort by priority (vip > urgent > normal) then by check-in time
      const priorityOrder = { vip: 0, urgent: 1, normal: 2 };
      const priorityDiff = priorityOrder[a.priority] - priorityOrder[b.priority];
      if (priorityDiff !== 0) return priorityDiff;
      return new Date(a.checkInTime).getTime() - new Date(b.checkInTime).getTime();
    });
  }

  /**
   * Get a specific patient journey by ID
   */
  static getJourneyById(id: string): PatientJourney | null {
    const journeys = this.getAllJourneys();
    return journeys.find(j => j.id === id) || null;
  }

  /**
   * Get patient journey by task ID
   */
  static getJourneyByTaskId(taskId: string): PatientJourney | null {
    const journeys = this.getAllJourneys();
    return journeys.find(j => j.taskId === taskId) || null;
  }

  /**
   * Get patient journey by appointment ID
   */
  static getJourneyByAppointmentId(appointmentId: string): PatientJourney | null {
    const journeys = this.getAllJourneys();
    return journeys.find(j => j.appointmentId === appointmentId) || null;
  }

  /**
   * Get patient journey by patient ID
   */
  static getJourneyByPatientId(patientId: string): PatientJourney | null {
    const journeys = this.getAllJourneys();
    // Return the most recent active journey for this patient
    return journeys.find(j => j.patientId === patientId && j.status === 'active') || null;
  }

  /**
   * Start a journey step
   */
  static startStep(journeyId: string, stepId: string): PatientJourney {
    const journey = this.updateJourney({
      type: 'start-step',
      stepId,
      patientJourneyId: journeyId
    });
    if (!journey) throw new Error('Journey not found');
    return journey;
  }

  /**
   * Complete a journey step
   */
  static completeStep(journeyId: string, stepId: string, notes?: string): PatientJourney {
    const journey = this.updateJourney({
      type: 'complete-step',
      stepId,
      patientJourneyId: journeyId,
      data: notes ? { notes } : undefined
    });
    if (!journey) throw new Error('Journey not found');
    return journey;
  }

  /**
   * Skip a journey step
   */
  static skipStep(journeyId: string, stepId: string, reason?: string): PatientJourney {
    const journey = this.updateJourney({
      type: 'skip-step',
      stepId,
      patientJourneyId: journeyId,
      data: reason ? { notes: reason } : undefined
    });
    if (!journey) throw new Error('Journey not found');
    return journey;
  }

  /**
   * Transition journey to new phase
   */
  static transitionPhase(journeyId: string, newPhase: JourneyPhase): PatientJourney {
    const journey = this.transitionJourneyPhase(journeyId, newPhase);
    if (!journey) throw new Error('Journey not found');
    return journey;
  }

  /**
   * Cancel a patient journey
   */
  static cancelJourney(journeyId: string, _reason?: string): PatientJourney | null {
    const journeys = this.getAllJourneys();
    const journeyIndex = journeys.findIndex(j => j.id === journeyId);
    if (journeyIndex === -1) return null;
    
    const journey = journeys[journeyIndex];
    journey.status = 'cancelled';
    journey.updatedAt = new Date();
    
    journeys[journeyIndex] = journey;
    this.saveJourneys(journeys);
    
    return journey;
  }

  /**
   * Update a specific journey step
   */
  static updateJourneyStep(
    journeyId: string, 
    stepId: string, 
    updates: Partial<JourneyStep>
  ): PatientJourney | null {
    const journeys = this.getAllJourneys();
    const journeyIndex = journeys.findIndex(j => j.id === journeyId);
    if (journeyIndex === -1) return null;
    
    const journey = journeys[journeyIndex];
    const stepIndex = journey.steps.findIndex(step => step.id === stepId);
    if (stepIndex === -1) return null;
    
    // Apply updates to the step
    journey.steps[stepIndex] = { ...journey.steps[stepIndex], ...updates };
    journey.updatedAt = new Date();
    
    journeys[journeyIndex] = journey;
    this.saveJourneys(journeys);
    
    return journey;
  }
  
  /**
   * Transition a journey from one phase to another
   */
  static transitionJourneyPhase(
    journeyId: string,
    newPhase: JourneyPhase,
    performedBy?: string
  ): PatientJourney | null {
    const journeys = this.getAllJourneys();
    const journeyIndex = journeys.findIndex(j => j.id === journeyId);
    if (journeyIndex === -1) return null;
    
    const journey = journeys[journeyIndex];
    const now = new Date();
    
    journey.journeyPhase = newPhase;
    journey.updatedAt = now;
    
    if (newPhase === 'in-office' && !journey.inOfficeStartDate) {
      journey.inOfficeStartDate = now;
      if (!journey.checkInTime) {
        journey.checkInTime = now;
      }
      
      const firstInOfficeStep = journey.steps.find(step => 
        step.stepType === 'in-office' && step.status === 'pending'
      );
      if (firstInOfficeStep) {
        journey.currentStepId = firstInOfficeStep.id;
      }
    } else if (newPhase === 'post-visit' && !journey.postVisitStartDate) {
      journey.postVisitStartDate = now;
      journey.checkOutTime = now;
      
      const firstPostVisitStep = journey.steps.find(step => 
        step.stepType === 'post-visit' && step.status === 'pending'
      );
      if (firstPostVisitStep) {
        journey.currentStepId = firstPostVisitStep.id;
      }
    } else if (newPhase === 'completed') {
      journey.status = 'completed';
      if (!journey.checkOutTime) {
        journey.checkOutTime = now;
      }
      // Calculate total duration
      const checkInTime = new Date(journey.checkInTime);
      journey.totalDuration = Math.floor((now.getTime() - checkInTime.getTime()) / (1000 * 60));
    }
    
    journeys[journeyIndex] = journey;
    this.saveJourneys(journeys);
    
    // Trigger AI communication for phase change (async, don't await)
    const previousPhase = journey.journeyPhase;
    getJourneyTrigger().then(trigger => {
      trigger?.onPhaseChanged(journey, previousPhase, newPhase).catch(console.error);
    }).catch(console.error);
    
    return journey;
  }

  /**
   * Update a journey based on an action
   */
  static updateJourney(action: JourneyAction): PatientJourney | null {
    const { type, stepId, patientJourneyId, data, performedBy } = action;
    
    const journeys = this.getAllJourneys();
    const journeyIndex = journeys.findIndex(j => j.id === patientJourneyId);
    if (journeyIndex === -1) return null;
    
    const journey = journeys[journeyIndex];
    const stepIndex = journey.steps.findIndex(step => step.id === stepId);
    if (stepIndex === -1) return null;
    
    const now = new Date();
    
    // Handle phase transition
    if (type === 'transition-phase') {
      const phase = data?.phase as JourneyPhase;
      if (!phase) {
        throw new Error('Phase must be specified for transition-phase action');
      }
      return this.transitionJourneyPhase(patientJourneyId, phase, performedBy);
    }
    
    // Handle schedule step
    if (type === 'schedule-step') {
      const scheduledTime = data?.scheduledTime ? new Date(data.scheduledTime) : undefined;
      if (!scheduledTime) {
        throw new Error('Scheduled time must be specified for schedule-step action');
      }
      journey.steps[stepIndex].scheduledTime = scheduledTime;
      journey.updatedAt = now;
      journeys[journeyIndex] = journey;
      this.saveJourneys(journeys);
      return journey;
    }
    
    // Handle process response
    if (type === 'process-response') {
      journey.steps[stepIndex].responseReceived = true;
      journey.steps[stepIndex].responseData = data?.response;
      journey.updatedAt = now;
      journeys[journeyIndex] = journey;
      this.saveJourneys(journeys);
      return journey;
    }
    
    // Handle step lifecycle actions
    switch (type) {
      case 'start-step':
        journey.steps[stepIndex].status = 'in-progress';
        journey.steps[stepIndex].startTime = now;
        journey.currentStepId = stepId;
        
        if (data?.room) journey.steps[stepIndex].room = data.room;
        if (data?.staffId) journey.steps[stepIndex].staffId = data.staffId;
        if (data?.staffName) journey.steps[stepIndex].staffName = data.staffName;
        break;
        
      case 'complete-step':
        journey.steps[stepIndex].status = 'completed';
        journey.steps[stepIndex].endTime = now;
        
        // Calculate duration
        if (journey.steps[stepIndex].startTime) {
          const startTime = new Date(journey.steps[stepIndex].startTime!);
          journey.steps[stepIndex].duration = Math.floor((now.getTime() - startTime.getTime()) / (1000 * 60));
        }
        
        // Move to next step
        const nextStepIndex = journey.steps.findIndex(
          (step, index) => index > stepIndex && step.status === 'pending'
        );
        
        if (nextStepIndex !== -1) {
          journey.currentStepId = journey.steps[nextStepIndex].id;
        } else {
          // Check if all steps completed
          const allCompleted = journey.steps.every(
            step => ['completed', 'skipped', 'cancelled'].includes(step.status)
          );
          
          if (allCompleted) {
            journey.status = 'completed';
            journey.checkOutTime = now;
            const checkInTime = new Date(journey.checkInTime);
            journey.totalDuration = Math.floor((now.getTime() - checkInTime.getTime()) / (1000 * 60));
          }
        }
        break;
        
      case 'skip-step':
        journey.steps[stepIndex].status = 'skipped';
        if (data?.notes) journey.steps[stepIndex].notes = data.notes;
        
        // Move to next step
        const nextIdx = journey.steps.findIndex(
          (step, index) => index > stepIndex && step.status === 'pending'
        );
        if (nextIdx !== -1) {
          journey.currentStepId = journey.steps[nextIdx].id;
        }
        break;
        
      case 'cancel-step':
        journey.steps[stepIndex].status = 'cancelled';
        if (data?.notes) journey.steps[stepIndex].notes = data.notes;
        break;
        
      case 'add-note':
        if (data?.notes) journey.steps[stepIndex].notes = data.notes;
        break;
        
      case 'change-room':
        if (data?.room) journey.steps[stepIndex].room = data.room;
        break;
    }
    
    journey.updatedAt = now;
    journeys[journeyIndex] = journey;
    this.saveJourneys(journeys);
    
    return journey;
  }

  /**
   * Delete a journey
   */
  static deleteJourney(journeyId: string): boolean {
    const journeys = this.getAllJourneys();
    const filtered = journeys.filter(j => j.id !== journeyId);
    if (filtered.length === journeys.length) return false;
    this.saveJourneys(filtered);
    return true;
  }

  /**
   * Get default in-office journey steps
   */
  private static getDefaultInOfficeJourneySteps(): JourneyStep[] {
    return [
      {
        id: 'check-in',
        title: 'Check-in',
        description: 'Patient arrival and initial paperwork',
        status: 'pending',
        staffRole: 'Front Desk',
        reasonCodes: ['standard-procedure'],
        duration: 15,
        stepType: 'in-office',
        responseRequired: false
      },
      {
        id: 'pre-testing',
        title: 'Pre-Testing',
        description: 'Initial eye tests and measurements',
        status: 'pending',
        staffRole: 'Technician',
        reasonCodes: ['standard-procedure'],
        duration: 20,
        stepType: 'in-office',
        responseRequired: false
      },
      {
        id: 'doctor-exam',
        title: 'Doctor Examination',
        description: 'Comprehensive eye exam with doctor',
        status: 'pending',
        staffRole: 'Doctor',
        reasonCodes: ['standard-procedure'],
        duration: 30,
        stepType: 'in-office',
        responseRequired: false
      },
      {
        id: 'checkout',
        title: 'Checkout',
        description: 'Payment processing and scheduling follow-up',
        status: 'pending',
        staffRole: 'Front Desk',
        reasonCodes: ['standard-procedure'],
        duration: 10,
        stepType: 'in-office',
        responseRequired: false
      }
    ];
  }
  
  /**
   * Get pre-visit journey steps
   */
  private static getPreVisitJourneySteps(): JourneyStep[] {
    return [
      {
        id: 'confirm-appointment',
        title: 'Confirm Appointment',
        description: 'Confirm upcoming appointment with patient',
        status: 'pending',
        staffRole: 'Automated',
        reasonCodes: ['pre-visit'],
        stepType: 'pre-visit',
        communicationType: 'sms',
        responseRequired: true,
        templateId: 'appointment-confirmation'
      },
      {
        id: 'complete-forms',
        title: 'Complete Patient Forms',
        description: 'Patient completes necessary forms before visit',
        status: 'pending',
        staffRole: 'Automated',
        reasonCodes: ['pre-visit'],
        stepType: 'pre-visit',
        communicationType: 'email',
        responseRequired: true,
        templateId: 'patient-forms'
      },
      {
        id: 'insurance-info',
        title: 'Insurance Information',
        description: 'Collect or verify insurance information',
        status: 'pending',
        staffRole: 'Automated',
        reasonCodes: ['pre-visit'],
        stepType: 'pre-visit',
        communicationType: 'form',
        responseRequired: true,
        templateId: 'insurance-verification'
      }
    ];
  }
  
  /**
   * Get post-visit journey steps
   */
  private static getPostVisitJourneySteps(): JourneyStep[] {
    return [
      {
        id: 'satisfaction-survey',
        title: 'Patient Satisfaction Survey',
        description: 'Collect feedback on patient experience',
        status: 'pending',
        staffRole: 'Automated',
        reasonCodes: ['post-visit'],
        stepType: 'post-visit',
        communicationType: 'sms',
        responseRequired: true,
        templateId: 'satisfaction-survey'
      },
      {
        id: 'recall-reminder',
        title: 'Recall Reminder',
        description: 'Remind patient to schedule next appointment',
        status: 'pending',
        staffRole: 'Automated',
        reasonCodes: ['post-visit'],
        stepType: 'post-visit',
        communicationType: 'email',
        responseRequired: false,
        templateId: 'recall-reminder'
      }
    ];
  }
}
