/**
 * Recommendation Engine
 * Generates personalized journey step and form recommendations based on patient context
 */

import { 
  PatientContext, 
  JourneyStepRecommendation, 
  FormRecommendation,
  RecommendationResponse 
} from '../types/journey-rules';

export class RecommendationEngine {
  /**
   * Generate recommended journey steps based on patient context
   */
  static generateJourneyRecommendations(context: PatientContext): JourneyStepRecommendation[] {
    const { patient, task } = context;
    const recommendations: JourneyStepRecommendation[] = [];
    
    // Base recommendations that almost everyone gets
    recommendations.push({
      id: 'check-in',
      title: 'Check-in',
      description: 'Patient arrival and initial paperwork',
      estimatedDuration: 15,
      staffRole: 'Front Desk',
      reasonCodes: ['standard-procedure']
    });
    
    // Age-based recommendations
    const age = this.calculateAge(patient.Dob);
    if (age >= 60) {
      recommendations.push({
        id: 'glaucoma-screening',
        title: 'Glaucoma Screening',
        description: 'Additional screening for patients over 60',
        estimatedDuration: 10,
        staffRole: 'Technician',
        reasonCodes: ['age-based', 'preventive-care']
      });
    }
    
    // Reason for visit-based recommendations
    if (task?.reasonForVisit?.toLowerCase().includes('contact')) {
      recommendations.push({
        id: 'contact-lens-fitting',
        title: 'Contact Lens Fitting',
        description: 'Specialized fitting for contact lens users',
        estimatedDuration: 20,
        staffRole: 'Optician',
        reasonCodes: ['reason-for-visit', 'specialized-care']
      });
    }

    // Previous eyewear-based recommendations
    if (context.previousEyewear && context.previousEyewear.length > 0) {
      const lastEyewear = context.previousEyewear[0];
      
      if (lastEyewear.orderType?.toLowerCase().includes('progressive')) {
        recommendations.push({
          id: 'progressive-lens-consultation',
          title: 'Progressive Lens Consultation',
          description: 'Review previous progressive lens experience and discuss options',
          estimatedDuration: 15,
          staffRole: 'Optician',
          reasonCodes: ['previous-eyewear', 'continuity-of-care']
        });
      }
    }
    
    // Lifestyle-based recommendations
    if (context.lifestyleInfo) {
      const { screenTime, outdoorActivities, drivingFrequency } = context.lifestyleInfo;
      
      if (screenTime === 'high') {
        recommendations.push({
          id: 'blue-light-consultation',
          title: 'Blue Light Protection Consultation',
          description: 'Discuss options for reducing eye strain from screen time',
          estimatedDuration: 10,
          staffRole: 'Optician',
          reasonCodes: ['lifestyle', 'preventive-care']
        });
      }
      
      if (outdoorActivities) {
        recommendations.push({
          id: 'sun-protection-options',
          title: 'Sun Protection Options',
          description: 'Discuss sunglasses and UV protection options',
          estimatedDuration: 10,
          staffRole: 'Optician',
          reasonCodes: ['lifestyle', 'preventive-care']
        });
      }
      
      if (drivingFrequency === 'frequently') {
        recommendations.push({
          id: 'driving-vision-assessment',
          title: 'Driving Vision Assessment',
          description: 'Specialized assessment for optimal driving vision',
          estimatedDuration: 15,
          staffRole: 'Technician',
          reasonCodes: ['lifestyle', 'safety']
        });
      }
    }
    
    // Add insurance verification if there's insurance information
    if (task?.insuranceProvider) {
      recommendations.push({
        id: 'insurance-benefits-review',
        title: 'Insurance Benefits Review',
        description: 'Review available benefits and coverage options',
        estimatedDuration: 10,
        staffRole: 'Insurance Coordinator',
        reasonCodes: ['insurance', 'financial-planning']
      });
    }

    // Add standard journey steps that everyone needs
    recommendations.push({
      id: 'pre-testing',
      title: 'Pre-Testing',
      description: 'Initial eye tests and measurements',
      estimatedDuration: 15,
      staffRole: 'Technician',
      reasonCodes: ['standard-procedure']
    });
    
    recommendations.push({
      id: 'doctor-examination',
      title: 'Doctor Examination',
      description: 'Comprehensive eye examination with the doctor',
      estimatedDuration: 25,
      staffRole: 'Doctor',
      reasonCodes: ['standard-procedure']
    });
    
    recommendations.push({
      id: 'optical-consultation',
      title: 'Optical Consultation',
      description: 'Eyewear selection and fitting',
      estimatedDuration: 20,
      staffRole: 'Optician',
      reasonCodes: ['standard-procedure']
    });
    
    recommendations.push({
      id: 'checkout',
      title: 'Checkout',
      description: 'Payment processing and scheduling follow-up',
      estimatedDuration: 10,
      staffRole: 'Front Desk',
      reasonCodes: ['standard-procedure']
    });
    
    return recommendations;
  }
  
  /**
   * Generate recommended forms based on patient context
   */
  static generateFormRecommendations(context: PatientContext): FormRecommendation[] {
    const { patient, task } = context;
    const recommendations: FormRecommendation[] = [];
    
    // Standard forms everyone needs
    recommendations.push({
      id: 'medical-history',
      title: 'Medical History Form',
      description: 'Basic medical history and conditions',
      priority: 'required',
      reasonCode: 'standard-procedure'
    });
    
    recommendations.push({
      id: 'hipaa-acknowledgment',
      title: 'HIPAA Acknowledgment',
      description: 'Acknowledgment of privacy practices',
      priority: 'required',
      reasonCode: 'compliance-requirement'
    });
    
    // Insurance-based forms
    if (task?.insuranceProvider) {
      recommendations.push({
        id: 'insurance-verification',
        title: 'Insurance Verification Form',
        description: 'Information for verifying insurance coverage',
        priority: 'required',
        reasonCode: 'insurance-required'
      });
    }
    
    // Age-based forms
    const age = this.calculateAge(patient.Dob);
    if (age < 18) {
      recommendations.push({
        id: 'pediatric-history',
        title: 'Pediatric Vision History',
        description: 'Vision development history for minors',
        priority: 'required',
        reasonCode: 'age-based'
      });
      
      recommendations.push({
        id: 'parental-consent',
        title: 'Parental Consent Form',
        description: 'Consent for treatment of a minor',
        priority: 'required',
        reasonCode: 'legal-requirement'
      });
    }
    
    if (age >= 60) {
      recommendations.push({
        id: 'advanced-eye-disease-screening',
        title: 'Advanced Eye Disease Screening Form',
        description: 'Risk assessment for age-related conditions',
        priority: 'recommended',
        reasonCode: 'age-based'
      });
    }
    
    // Reason for visit-based forms
    if (task?.reasonForVisit?.toLowerCase().includes('contact')) {
      recommendations.push({
        id: 'contact-lens-agreement',
        title: 'Contact Lens Agreement',
        description: 'Terms for contact lens prescription',
        priority: 'required',
        reasonCode: 'reason-for-visit'
      });
    }
    
    if (task?.reasonForVisit?.toLowerCase().includes('lasik') || 
        task?.reasonForVisit?.toLowerCase().includes('surgery')) {
      recommendations.push({
        id: 'surgical-consultation',
        title: 'Surgical Consultation Form',
        description: 'Information for refractive surgery consideration',
        priority: 'required',
        reasonCode: 'reason-for-visit'
      });
    }
    
    // Lifestyle-based forms
    if (context.lifestyleInfo) {
      recommendations.push({
        id: 'lifestyle-questionnaire',
        title: 'Detailed Lifestyle Questionnaire',
        description: 'Comprehensive assessment of visual needs',
        priority: 'recommended',
        reasonCode: 'personalized-care'
      });
      
      if (context.lifestyleInfo.occupation) {
        recommendations.push({
          id: 'occupational-vision-assessment',
          title: 'Occupational Vision Assessment',
          description: 'Visual requirements for work environment',
          priority: 'recommended',
          reasonCode: 'lifestyle'
        });
      }
    }
    
    return recommendations;
  }
  
  /**
   * Generate all recommendations for a patient
   */
  static generateRecommendations(context: PatientContext): RecommendationResponse {
    const journeySteps = this.generateJourneyRecommendations(context);
    const forms = this.generateFormRecommendations(context);
    
    return {
      journeySteps,
      forms
    };
  }
  
  /**
   * Helper function to calculate age from date of birth
   */
  private static calculateAge(dateOfBirth?: string): number {
    if (!dateOfBirth) return 0;
    
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age;
  }
}
