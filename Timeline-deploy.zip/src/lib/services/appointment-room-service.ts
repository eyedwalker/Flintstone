/**
 * Appointment to Room Service
 * Handles quick patient check-in from appointments to rooms
 * Supports walk-ins and rapid room assignment
 */

import { AppointmentTaskService, Appointment } from '../database/appointment-task-service';
import { PatientJourneyService } from './patient-journey-service';
import { RoomWorkflowService } from './room-workflow-service';
import { OfficeRoomsService } from './office-rooms-service';
import { EyefinityService, Appointment as EyefinityAppointment } from '../../services/eyefinityService';

export interface CheckInReadyPatient {
  source: 'appointment' | 'journey';
  appointmentId?: string;
  journeyId?: string;
  patientId: string;
  patientName: string;
  patientPhone?: string;
  patientEmail?: string;
  providerId?: string;
  providerName?: string;
  appointmentTime?: string;
  appointmentType?: string;
  status: string;
  reasonForVisit?: string;
  hasActiveJourney: boolean;
  // Legacy IDs for external system integration (Encompass, etc.)
  patientLegacyId?: string | number;
  appointmentLegacyId?: string | number;
}

class AppointmentRoomServiceClass {
  /**
   * Search appointments by patient name or date range
   */
  async searchAppointments(
    searchTerm?: string,
    startDate?: string,
    endDate?: string
  ): Promise<Appointment[]> {
    // Get all appointments from storage
    const allAppointments = await this.getAllAppointments();
    
    let filtered = allAppointments;
    
    // Filter by date range
    if (startDate && endDate) {
      filtered = filtered.filter(apt => 
        apt.appointmentDate >= startDate && apt.appointmentDate <= endDate
      );
    } else if (startDate) {
      filtered = filtered.filter(apt => apt.appointmentDate >= startDate);
    } else if (endDate) {
      filtered = filtered.filter(apt => apt.appointmentDate <= endDate);
    }
    
    // Filter by search term (patient name)
    if (searchTerm && searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(apt => 
        apt.patientName.toLowerCase().includes(term) ||
        apt.patientPhone?.includes(term) ||
        apt.providerName?.toLowerCase().includes(term) ||
        apt.appointmentType?.toLowerCase().includes(term)
      );
    }
    
    // Sort by date and time
    filtered.sort((a, b) => {
      const dateCompare = a.appointmentDate.localeCompare(b.appointmentDate);
      if (dateCompare !== 0) return -dateCompare; // Most recent first
      return (b.appointmentTime || '').localeCompare(a.appointmentTime || '');
    });
    
    return filtered;
  }

  /**
   * Get all patients ready for check-in from appointments
   * Includes both scheduled appointments and walk-ins
   */
  async getPatientsReadyForCheckIn(date?: string): Promise<CheckInReadyPatient[]> {
    const targetDate = date || this.getTodayDate();
    
    // Get today's appointments
    const appointments = await AppointmentTaskService.getAppointmentsByDate(targetDate);
    
    // Get existing journeys
    const activeJourneys = PatientJourneyService.getActiveJourneys();
    const journeysByPatientId = new Map(
      activeJourneys.map(j => [j.patientId, j] as [string, any])
    );
    const journeysByAppointmentId = new Map(
      activeJourneys
        .filter(j => j.appointmentId)
        .map(j => [j.appointmentId!, j] as [string, any])
    );

    const checkInReady: CheckInReadyPatient[] = [];

    // Process appointments
    for (const apt of appointments) {
      // Skip completed, cancelled, or no-show appointments
      if (['completed', 'cancelled', 'no_show'].includes(apt.status)) {
        continue;
      }

      const hasJourney = journeysByAppointmentId.has(apt.appointmentId) || 
                        journeysByPatientId.has(apt.patientId);
      const journey = journeysByAppointmentId.get(apt.appointmentId) || 
                     journeysByPatientId.get(apt.patientId);

      // If already has a journey in a room, skip (already checked in)
      if (journey?.id && this.isPatientInRoom(journey.id)) {
        continue;
      }

      checkInReady.push({
        source: 'appointment',
        appointmentId: apt.appointmentId,
        journeyId: journey?.id,
        patientId: apt.patientId,
        patientName: apt.patientName,
        patientPhone: apt.patientPhone,
        patientEmail: apt.patientEmail,
        providerId: apt.providerId,
        providerName: apt.providerName,
        appointmentTime: apt.appointmentTime,
        appointmentType: apt.appointmentType,
        status: apt.status,
        reasonForVisit: apt.appointmentType,
        hasActiveJourney: hasJourney,
        patientLegacyId: apt.patientLegacyId,
        appointmentLegacyId: apt.appointmentId // appointmentId is already the external ID
      });
    }

    // Also include in-office journeys without appointments (direct adds)
    for (const journey of activeJourneys) {
      if (journey.journeyPhase === 'in-office' && 
          !this.isPatientInRoom(journey.id) &&
          !journeysByAppointmentId.has(journey.appointmentId || '')) {
        
        // Check if we already added this patient via appointment
        const alreadyAdded = checkInReady.some(p => p.journeyId === journey.id);
        if (!alreadyAdded) {
          checkInReady.push({
            source: 'journey',
            journeyId: journey.id,
            patientId: journey.patientId,
            patientName: journey.patientName,
            providerId: journey.providerId,
            providerName: journey.providerName,
            status: journey.status,
            reasonForVisit: journey.reasonForVisit,
            hasActiveJourney: true
          });
        }
      }
    }

    // Sort by appointment time
    checkInReady.sort((a, b) => {
      if (!a.appointmentTime && !b.appointmentTime) return 0;
      if (!a.appointmentTime) return 1;
      if (!b.appointmentTime) return -1;
      return a.appointmentTime.localeCompare(b.appointmentTime);
    });

    return checkInReady;
  }

  /**
   * Quick add patient from appointment to room
   * Creates journey if needed, transitions to in-office, assigns to room
   */
  async quickAddPatientToRoom(
    patient: CheckInReadyPatient,
    roomId: string,
    officeId: string = 'default-office'
  ): Promise<{ journey: any; room: any }> {
    let journey;

    // Create or get journey
    if (patient.hasActiveJourney && patient.journeyId) {
      const existingJourney = PatientJourneyService.getJourneyById(patient.journeyId);
      if (!existingJourney) {
        throw new Error('Journey not found');
      }
      journey = existingJourney;
    } else {
      // Resolve legacy patient ID for external system integration (Encompass, etc.)
      let legacyPatientId = patient.patientLegacyId;
      if (!legacyPatientId && patient.patientId) {
        try {
          const fullPatient = await EyefinityService.getPatientById(patient.patientId);
          if (fullPatient?.PatientLegacyId) {
            legacyPatientId = fullPatient.PatientLegacyId;
          }
        } catch (err) {
          console.log('[AppointmentRoomService] Could not look up legacy patient ID:', (err as Error).message);
        }
      }

      // Create new journey with legacy IDs
      const newJourney = PatientJourneyService.createJourney({
        patientId: patient.patientId,
        patientName: patient.patientName,
        appointmentId: patient.appointmentId,
        providerId: patient.providerId,
        providerName: patient.providerName,
        reasonForVisit: patient.reasonForVisit || patient.appointmentType,
        legacyPatientId: legacyPatientId ? String(legacyPatientId) : undefined,
        legacyAppointmentId: patient.appointmentLegacyId ? String(patient.appointmentLegacyId) : undefined,
      });

      if (!newJourney) {
        throw new Error('Failed to create journey');
      }
      journey = newJourney;
    }

    // Ensure journey is in in-office phase
    if (journey.journeyPhase !== 'in-office') {
      const transitioned = PatientJourneyService.transitionJourneyPhase(journey.id, 'in-office');
      if (!transitioned) {
        throw new Error('Failed to transition journey to in-office');
      }
      journey = transitioned;
    }

    // Update appointment status to checked_in
    if (patient.appointmentId) {
      await this.updateAppointmentStatus(patient.appointmentId, 'checked_in');
    }

    // Assign to room using proper occupancy tracking
    const currentStep = journey.steps?.find((s: any) => s.id === journey.currentStepId);

    const occupancy = OfficeRoomsService.assignPatientToRoom(
      officeId,
      roomId,
      journey.patientId,
      journey.patientName,
      journey.id,
      currentStep?.id || '',
      currentStep?.title || 'Check-in'
    );

    if (!occupancy) {
      throw new Error('Failed to assign patient to room');
    }

    // Re-read room after assignment
    const roomConfig = OfficeRoomsService.getOfficeConfig(officeId);
    const room = roomConfig?.rooms.find((r: any) => r.id === roomId);

    return { journey, room: room || { id: roomId } };
  }

  /**
   * Check if patient is currently in a room
   */
  private isPatientInRoom(journeyId: string, officeId: string = 'default-office'): boolean {
    const roomConfig = OfficeRoomsService.getOfficeConfig(officeId);
    if (!roomConfig) return false;
    return roomConfig.rooms.some(r => 
      r.status === 'occupied' && 
      (r.currentJourneyId === journeyId || r.currentPatientId === journeyId)
    );
  }

  /**
   * Update appointment status
   */
  private async updateAppointmentStatus(
    appointmentId: string, 
    status: Appointment['status']
  ): Promise<void> {
    const appointment = await AppointmentTaskService.getAppointment(appointmentId);
    if (appointment) {
      await AppointmentTaskService.syncAppointment({
        ...appointment,
        status
      });
    }
  }

  /**
   * Get all appointments from Eyefinity and localStorage
   */
  private async getAllAppointments(): Promise<Appointment[]> {
    const appointments: Appointment[] = [];
    
    // Try to fetch from Eyefinity first
    try {
      // Fetch last 6 months of appointments (covers old test data)
      const sixMonthsAgo = new Date();
      sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
      const fromDate = sixMonthsAgo.toISOString().split('T')[0];
      
      // Fetch next 3 months
      const threeMonthsForward = new Date();
      threeMonthsForward.setMonth(threeMonthsForward.getMonth() + 3);
      const toDate = threeMonthsForward.toISOString().split('T')[0];
      
      console.log('[AppointmentRoomService] Fetching Eyefinity appointments from', fromDate, 'to', toDate);
      
      const response = await EyefinityService.getAppointments({
        fromDate,
        toDate,
        pageSize: 500
      });
      
      // Convert Eyefinity appointments to Appointment format
      for (const eyeApt of response.items) {
        appointments.push({
          appointmentId: eyeApt.appointmentId || eyeApt.id,
          patientId: eyeApt.patientId,
          patientName: eyeApt.patientName,
          providerId: eyeApt.providerId,
          providerName: eyeApt.providerName || 
            (eyeApt.providerFirstName && eyeApt.providerLastName 
              ? `${eyeApt.providerFirstName} ${eyeApt.providerLastName}` 
              : undefined),
          officeId: eyeApt.officeId,
          appointmentDate: eyeApt.date,
          appointmentTime: eyeApt.startTime,
          appointmentType: eyeApt.appointmentType || eyeApt.reason,
          durationMinutes: this.calculateDuration(eyeApt.startTime, eyeApt.endTime),
          status: this.mapEyefinityStatus(eyeApt.status),
          notes: eyeApt.reason,
          externalData: eyeApt
        });
      }
      
      console.log('[AppointmentRoomService] Loaded', appointments.length, 'Eyefinity appointments');
    } catch (error) {
      console.warn('[AppointmentRoomService] Could not fetch from Eyefinity, falling back to localStorage:', error);
    }
    
    // Also include localStorage appointments (for any manual entries)
    if (typeof localStorage !== 'undefined') {
      const stored = localStorage.getItem('appointments');
      if (stored) {
        const localAppointments = JSON.parse(stored);
        // Only add if not already from Eyefinity
        for (const apt of localAppointments) {
          if (!appointments.find(a => a.appointmentId === apt.appointmentId)) {
            appointments.push(apt);
          }
        }
      }
    }
    
    return appointments;
  }
  
  /**
   * Calculate duration in minutes from start/end times
   */
  private calculateDuration(startTime: string, endTime: string): number | undefined {
    if (!startTime || !endTime) return undefined;
    try {
      const [startHour, startMin] = startTime.split(':').map(Number);
      const [endHour, endMin] = endTime.split(':').map(Number);
      const startMinutes = startHour * 60 + startMin;
      const endMinutes = endHour * 60 + endMin;
      return endMinutes - startMinutes;
    } catch {
      return undefined;
    }
  }
  
  /**
   * Map Eyefinity status to our status
   */
  private mapEyefinityStatus(status: string): Appointment['status'] {
    const statusLower = (status || '').toLowerCase();
    if (statusLower.includes('confirm')) return 'confirmed';
    if (statusLower.includes('check')) return 'checked_in';
    if (statusLower.includes('progress')) return 'in_progress';
    if (statusLower.includes('complete')) return 'completed';
    if (statusLower.includes('cancel')) return 'cancelled';
    if (statusLower.includes('no')) return 'no_show';
    return 'scheduled';
  }

  /**
   * Get today's date in YYYY-MM-DD format
   */
  private getTodayDate(): string {
    const today = new Date();
    return today.toISOString().split('T')[0];
  }
  
  /**
   * Convert appointments to CheckInReadyPatient format
   */
  async convertAppointmentsToCheckInReady(
    appointments: Appointment[]
  ): Promise<CheckInReadyPatient[]> {
    const activeJourneys = PatientJourneyService.getActiveJourneys();
    const journeysByPatientId = new Map(
      activeJourneys.map(j => [j.patientId, j] as [string, any])
    );
    const journeysByAppointmentId = new Map(
      activeJourneys
        .filter(j => j.appointmentId)
        .map(j => [j.appointmentId!, j] as [string, any])
    );

    const checkInReady: CheckInReadyPatient[] = [];

    for (const apt of appointments) {
      const hasJourney = journeysByAppointmentId.has(apt.appointmentId) || 
                        journeysByPatientId.has(apt.patientId);
      const journey = journeysByAppointmentId.get(apt.appointmentId) || 
                     journeysByPatientId.get(apt.patientId);

      // If already has a journey in a room, mark but still show
      const inRoom = journey?.id && this.isPatientInRoom(journey.id);

      checkInReady.push({
        source: 'appointment',
        appointmentId: apt.appointmentId,
        journeyId: journey?.id,
        patientId: apt.patientId,
        patientName: apt.patientName,
        patientPhone: apt.patientPhone,
        patientEmail: apt.patientEmail,
        providerId: apt.providerId,
        providerName: apt.providerName,
        appointmentTime: apt.appointmentTime,
        appointmentType: apt.appointmentType,
        status: inRoom ? 'in-room' : apt.status,
        reasonForVisit: apt.appointmentType,
        hasActiveJourney: hasJourney
      });
    }

    return checkInReady;
  }

  /**
   * Create sample appointments for testing
   */
  async createSampleAppointments(): Promise<void> {
    const today = this.getTodayDate();
    const sampleAppointments: Partial<Appointment>[] = [
      {
        appointmentId: `APT-${Date.now()}-1`,
        patientId: `PAT-${Date.now()}-1`,
        patientName: 'John Smith',
        patientPhone: '555-0101',
        patientEmail: 'john.smith@example.com',
        providerId: 'DR-001',
        providerName: 'Dr. Johnson',
        appointmentDate: today,
        appointmentTime: '09:00',
        appointmentType: 'Comprehensive Eye Exam',
        durationMinutes: 60,
        status: 'scheduled'
      },
      {
        appointmentId: `APT-${Date.now()}-2`,
        patientId: `PAT-${Date.now()}-2`,
        patientName: 'Sarah Williams',
        patientPhone: '555-0102',
        patientEmail: 'sarah.w@example.com',
        providerId: 'DR-001',
        providerName: 'Dr. Johnson',
        appointmentDate: today,
        appointmentTime: '09:30',
        appointmentType: 'Contact Lens Fitting',
        durationMinutes: 45,
        status: 'confirmed'
      },
      {
        appointmentId: `APT-${Date.now()}-3`,
        patientId: `PAT-${Date.now()}-3`,
        patientName: 'Michael Chen',
        patientPhone: '555-0103',
        patientEmail: 'mchen@example.com',
        providerId: 'DR-002',
        providerName: 'Dr. Martinez',
        appointmentDate: today,
        appointmentTime: '10:00',
        appointmentType: 'Follow-up Visit',
        durationMinutes: 30,
        status: 'scheduled'
      },
      {
        appointmentId: `APT-${Date.now()}-4`,
        patientId: `PAT-${Date.now()}-4`,
        patientName: 'Emily Rodriguez',
        patientPhone: '555-0104',
        patientEmail: 'emily.r@example.com',
        providerId: 'DR-001',
        providerName: 'Dr. Johnson',
        appointmentDate: today,
        appointmentTime: '10:30',
        appointmentType: 'Glasses Adjustment',
        durationMinutes: 15,
        status: 'confirmed'
      },
      {
        appointmentId: `APT-${Date.now()}-5`,
        patientId: `PAT-${Date.now()}-5`,
        patientName: 'David Thompson',
        patientPhone: '555-0105',
        patientEmail: 'dthompson@example.com',
        providerId: 'DR-002',
        providerName: 'Dr. Martinez',
        appointmentDate: today,
        appointmentTime: '11:00',
        appointmentType: 'Comprehensive Eye Exam',
        durationMinutes: 60,
        status: 'scheduled'
      }
    ];

    for (const apt of sampleAppointments) {
      await AppointmentTaskService.syncAppointment(apt);
    }

    console.log(`Created ${sampleAppointments.length} sample appointments for ${today}`);
  }
}

export const AppointmentRoomService = new AppointmentRoomServiceClass();
