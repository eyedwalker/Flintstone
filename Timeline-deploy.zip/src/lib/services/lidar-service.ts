/**
 * LiDAR Service
 * Detects iPhone LiDAR availability and provides WebXR depth sensing
 * Falls back gracefully when LiDAR is not available
 */

// WebXR type declarations (not all browsers have these)
declare global {
  interface Navigator {
    xr?: {
      isSessionSupported(mode: string): Promise<boolean>;
      requestSession(mode: string, options?: any): Promise<any>;
    };
  }
}

type XRSession = any;

export interface LiDARCapabilities {
  available: boolean;
  depthSensing: boolean;
  deviceModel: string;
  reason?: string;
}

export interface DepthData {
  width: number;
  height: number;
  depthAtPupilLeft: number;  // meters
  depthAtPupilRight: number; // meters
  depthAtNose: number;       // meters
  averageFaceDepth: number;  // meters
}

export class LiDARService {
  private static xrSession: XRSession | null = null;

  /**
   * Detect if device has LiDAR capability
   * iPhone 12 Pro, 13 Pro, 14 Pro, 15 Pro, 16 Pro and iPad Pro (2020+)
   */
  static async detectLiDAR(): Promise<LiDARCapabilities> {
    const ua = navigator.userAgent;
    const deviceModel = this.detectDeviceModel(ua);

    // Check if WebXR is supported
    if (!('xr' in navigator)) {
      return {
        available: false,
        depthSensing: false,
        deviceModel,
        reason: 'WebXR not supported in this browser'
      };
    }

    try {
      // Check for immersive-ar support (required for depth sensing)
      const arSupported = await navigator.xr?.isSessionSupported('immersive-ar');
      if (!arSupported) {
        return {
          available: false,
          depthSensing: false,
          deviceModel,
          reason: 'Immersive AR not supported'
        };
      }

      // Try to check depth sensing support
      // This is the most reliable way to detect LiDAR
      try {
        const testSession = await navigator.xr?.requestSession('immersive-ar', {
          requiredFeatures: ['depth-sensing'],
          depthSensing: {
            usagePreference: ['cpu-optimized'],
            dataFormatPreference: ['luminance-alpha']
          }
        } as any);

        if (testSession) {
          await testSession.end();
          return {
            available: true,
            depthSensing: true,
            deviceModel,
          };
        }
      } catch {
        // Depth sensing not available - likely no LiDAR
        return {
          available: false,
          depthSensing: false,
          deviceModel,
          reason: 'Depth sensing not available (no LiDAR sensor)'
        };
      }

      return {
        available: false,
        depthSensing: false,
        deviceModel,
        reason: 'Could not verify LiDAR capability'
      };

    } catch (error) {
      console.error('[LiDARService] Detection error:', error);
      return {
        available: false,
        depthSensing: false,
        deviceModel,
        reason: `Detection error: ${error}`
      };
    }
  }

  /**
   * Detect device model from user agent
   */
  private static detectDeviceModel(ua: string): string {
    if (/iPhone/.test(ua)) {
      // Can't reliably detect Pro models from UA alone
      return 'iPhone';
    }
    if (/iPad/.test(ua)) {
      return 'iPad';
    }
    if (/Android/.test(ua)) {
      return 'Android';
    }
    return 'Unknown';
  }

  /**
   * Start a WebXR AR session with depth sensing
   * Returns null if not available
   */
  static async startDepthSession(): Promise<XRSession | null> {
    if (!('xr' in navigator)) return null;

    try {
      const session = await navigator.xr?.requestSession('immersive-ar', {
        requiredFeatures: ['depth-sensing'],
        depthSensing: {
          usagePreference: ['cpu-optimized'],
          dataFormatPreference: ['luminance-alpha']
        }
      } as any);

      if (session) {
        this.xrSession = session;
        console.log('[LiDARService] Depth session started');
        return session;
      }

      return null;
    } catch (error) {
      console.error('[LiDARService] Failed to start depth session:', error);
      return null;
    }
  }

  /**
   * Stop the active depth session
   */
  static async stopDepthSession(): Promise<void> {
    if (this.xrSession) {
      try {
        await this.xrSession.end();
      } catch {
        // Session may already be ended
      }
      this.xrSession = null;
      console.log('[LiDARService] Depth session stopped');
    }
  }

  /**
   * Get depth at specific normalized coordinates
   * Uses the XRFrame depth information
   */
  static getDepthAtPoint(
    frame: any, // XRFrame
    referenceSpace: any, // XRReferenceSpace
    normalizedX: number,
    normalizedY: number
  ): number | null {
    try {
      const viewerPose = frame.getViewerPose(referenceSpace);
      if (!viewerPose) return null;

      for (const view of viewerPose.views) {
        const depthInfo = (frame as any).getDepthInformation?.(view);
        if (depthInfo) {
          return depthInfo.getDepthInMeters(normalizedX, normalizedY);
        }
      }

      return null;
    } catch {
      return null;
    }
  }

  /**
   * Calculate real-world distance between two points using depth data
   * This provides sub-millimeter accuracy with LiDAR
   */
  static calculateRealWorldDistance(
    point1: { x: number; y: number; depth: number },
    point2: { x: number; y: number; depth: number },
    fovHorizontal: number = 60, // degrees
    imageWidth: number = 1280
  ): number {
    // Convert pixel distance to angular distance
    const pixelDistance = Math.sqrt(
      Math.pow((point2.x - point1.x) * imageWidth, 2) +
      Math.pow((point2.y - point1.y) * imageWidth, 2)
    );

    // Average depth
    const avgDepth = (point1.depth + point2.depth) / 2;

    // Convert angular distance to real-world distance
    const fovRadians = (fovHorizontal * Math.PI) / 180;
    const pixelsPerRadian = imageWidth / fovRadians;
    const angularDistance = pixelDistance / pixelsPerRadian;

    // Real-world distance at the given depth
    const realWorldDistance = 2 * avgDepth * Math.tan(angularDistance / 2);

    // Return in millimeters
    return realWorldDistance * 1000;
  }

  /**
   * Get enhanced calibration factor using LiDAR depth
   * Much more accurate than iris-based calibration
   */
  static getLiDARCalibration(
    faceDepthMeters: number,
    imageWidth: number,
    fovHorizontal: number = 60
  ): { pixelsPerMm: number; confidence: number } {
    // At a given depth, calculate how many pixels per mm
    const fovRadians = (fovHorizontal * Math.PI) / 180;
    const realWorldWidthAtDepth = 2 * faceDepthMeters * Math.tan(fovRadians / 2);
    const realWorldWidthMm = realWorldWidthAtDepth * 1000;
    const pixelsPerMm = imageWidth / realWorldWidthMm;

    return {
      pixelsPerMm,
      confidence: 0.97 // LiDAR is very accurate
    };
  }
}
