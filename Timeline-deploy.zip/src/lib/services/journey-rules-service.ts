/**
 * Journey Rules Service
 * Manages and evaluates patient journey rules for customizing workflows
 */

import { v4 as uuidv4 } from 'uuid';
import { JourneyStep, JourneyPhase } from '../types/patient-journey';
import { 
  JourneyStepRule, 
  RuleCondition, 
  AppointmentContext 
} from '../types/journey-rules';

// LocalStorage key for rules
const RULES_STORAGE_KEY = 'journey_rules';
const TEMPLATES_STORAGE_KEY = 'journey_step_templates';
const RULES_VERSION_KEY = 'journey_rules_version';
const CURRENT_RULES_VERSION = 2;

/**
 * Normalize a string for case/format-insensitive comparison.
 * Converts "Comprehensive Eye Exam", "comprehensive-eye-exam",
 * and "contact-lens-fitting" all to a canonical kebab form.
 */
function normalizeForComparison(value: string): string {
  if (typeof value !== 'string') return String(value);
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

export class JourneyRulesService {
  private rules: JourneyStepRule[] = [];
  private stepTemplates: Map<string, JourneyStep> = new Map();

  constructor() {
    this.loadFromStorage();
    const storedVersion = parseInt(localStorage.getItem(RULES_VERSION_KEY) || '0', 10);
    if (this.rules.length === 0) {
      this.loadDefaultRules();
      this.loadDefaultStepTemplates();
      this.saveToStorage();
      localStorage.setItem(RULES_VERSION_KEY, String(CURRENT_RULES_VERSION));
    } else if (storedVersion < CURRENT_RULES_VERSION) {
      this.migrateDefaultRules();
      localStorage.setItem(RULES_VERSION_KEY, String(CURRENT_RULES_VERSION));
    }
  }

  private loadFromStorage(): void {
    try {
      const rulesJson = localStorage.getItem(RULES_STORAGE_KEY);
      const templatesJson = localStorage.getItem(TEMPLATES_STORAGE_KEY);
      
      if (rulesJson) {
        this.rules = JSON.parse(rulesJson);
      }
      
      if (templatesJson) {
        const templates = JSON.parse(templatesJson);
        this.stepTemplates = new Map(Object.entries(templates));
      }
    } catch (error) {
      console.error('Error loading journey rules from storage:', error);
    }
  }

  private saveToStorage(): void {
    try {
      localStorage.setItem(RULES_STORAGE_KEY, JSON.stringify(this.rules));
      localStorage.setItem(TEMPLATES_STORAGE_KEY, JSON.stringify(Object.fromEntries(this.stepTemplates)));
    } catch (error) {
      console.error('Error saving journey rules to storage:', error);
    }
  }

  /**
   * Evaluate all rules against a given context to determine applicable journey steps
   */
  evaluateRules(context: AppointmentContext): JourneyStep[] {
    const matchingRules = this.findMatchingRules(context);
    return this.getStepsFromRules(matchingRules);
  }

  /**
   * Find all rules that match the provided context
   */
  findMatchingRules(context: AppointmentContext): JourneyStepRule[] {
    return this.rules
      .filter(rule => rule.isActive)
      .filter(rule => this.matchesPhase(rule, context.phase))
      .filter(rule => this.evaluateConditions(rule.conditions, context))
      .sort((a, b) => b.priority - a.priority);
  }

  /**
   * Get pre-visit journey steps for a given context
   */
  getPreVisitSteps(context: AppointmentContext): JourneyStep[] {
    return this.evaluateRules({ ...context, phase: 'pre-visit' });
  }

  /**
   * Get in-office journey steps for a given context
   */
  getInOfficeSteps(context: AppointmentContext): JourneyStep[] {
    return this.evaluateRules({ ...context, phase: 'in-office' });
  }

  /**
   * Get post-visit journey steps for a given context
   */
  getPostVisitSteps(context: AppointmentContext): JourneyStep[] {
    return this.evaluateRules({ ...context, phase: 'post-visit' });
  }

  /**
   * Add a new rule
   */
  addRule(rule: Omit<JourneyStepRule, 'id' | 'createdAt' | 'updatedAt'>): JourneyStepRule {
    const newRule: JourneyStepRule = {
      ...rule,
      id: uuidv4(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.rules.push(newRule);
    this.saveToStorage();
    return newRule;
  }

  /**
   * Update an existing rule
   */
  updateRule(id: string, updates: Partial<JourneyStepRule>): JourneyStepRule {
    const ruleIndex = this.rules.findIndex(rule => rule.id === id);
    if (ruleIndex === -1) {
      throw new Error(`Rule with id ${id} not found`);
    }

    const updatedRule = {
      ...this.rules[ruleIndex],
      ...updates,
      updatedAt: new Date()
    };

    this.rules[ruleIndex] = updatedRule;
    this.saveToStorage();
    return updatedRule;
  }

  /**
   * Delete a rule
   */
  deleteRule(id: string): void {
    const ruleIndex = this.rules.findIndex(rule => rule.id === id);
    if (ruleIndex === -1) {
      throw new Error(`Rule with id ${id} not found`);
    }

    this.rules.splice(ruleIndex, 1);
    this.saveToStorage();
  }

  /**
   * Add a step template
   */
  addStepTemplate(step: JourneyStep): JourneyStep {
    this.stepTemplates.set(step.id, step);
    this.saveToStorage();
    return step;
  }

  /**
   * Delete a step template
   */
  deleteStepTemplate(id: string): void {
    if (!this.stepTemplates.has(id)) {
      throw new Error(`Step template with id ${id} not found`);
    }
    this.stepTemplates.delete(id);
    this.saveToStorage();
  }

  /**
   * Get all rules
   */
  getAllRules(): JourneyStepRule[] {
    return [...this.rules];
  }

  /**
   * Get all step templates
   */
  getAllStepTemplates(): JourneyStep[] {
    return Array.from(this.stepTemplates.values());
  }

  /**
   * Get step templates by phase
   */
  getStepTemplatesByPhase(phase: JourneyPhase | 'all'): JourneyStep[] {
    return Array.from(this.stepTemplates.values())
      .filter(step => step.stepType === phase || phase === 'all');
  }

  // Private helper methods

  private matchesPhase(rule: JourneyStepRule, phase?: JourneyPhase): boolean {
    if (!phase) return true;
    return rule.phase === phase || rule.phase === 'all';
  }

  private evaluateConditions(conditions: RuleCondition[], context: AppointmentContext): boolean {
    if (conditions.length === 0) return true;
    return conditions.every(condition => this.evaluateCondition(condition, context));
  }

  private evaluateCondition(condition: RuleCondition, context: AppointmentContext): boolean {
    const { field, operator, value } = condition;
    const contextValue = this.getFieldValue(field, context);

    // For appointmentType, normalize both sides so "Contact Lens Fitting" matches "contact-lens-fitting"
    const useNormalized = field === 'appointmentType' && typeof contextValue === 'string' && typeof value === 'string';

    switch (operator) {
      case 'equals':
        return useNormalized
          ? normalizeForComparison(contextValue) === normalizeForComparison(value)
          : contextValue === value;
      case 'notEquals':
        return useNormalized
          ? normalizeForComparison(contextValue) !== normalizeForComparison(value)
          : contextValue !== value;
      case 'contains':
        return Array.isArray(contextValue) && contextValue.includes(value);
      case 'greaterThan':
        return contextValue > value;
      case 'lessThan':
        return contextValue < value;
      case 'exists':
        return contextValue !== undefined && contextValue !== null;
      case 'notExists':
        return contextValue === undefined || contextValue === null;
      default:
        return false;
    }
  }

  private getFieldValue(field: string, context: AppointmentContext): any {
    const parts = field.split('.');
    let value: any = context;

    for (const part of parts) {
      if (value === undefined || value === null) return undefined;
      value = value[part];
    }

    return value;
  }

  private getStepsFromRules(rules: JourneyStepRule[]): JourneyStep[] {
    const stepIds = new Set<string>();
    const steps: JourneyStep[] = [];

    for (const rule of rules) {
      for (const stepId of rule.stepTemplateIds) {
        if (!stepIds.has(stepId) && this.stepTemplates.has(stepId)) {
          stepIds.add(stepId);
          steps.push(structuredClone(this.stepTemplates.get(stepId)!));
        }
      }
    }

    return steps;
  }

  private loadDefaultRules(): void {
    this.rules = [
      // Pre-visit rules
      {
        id: 'new-patient-exam',
        name: 'New Patient Comprehensive Exam',
        description: 'Steps for new patients requiring a comprehensive exam',
        conditions: [
          { field: 'isNewPatient', operator: 'equals', value: true },
          { field: 'appointmentType', operator: 'equals', value: 'Comprehensive Eye Exam' }
        ],
        stepTemplateIds: ['medical-history-form', 'insurance-verification', 'confirm-appointment'],
        priority: 100,
        isActive: true,
        phase: 'pre-visit',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 'returning-patient-exam',
        name: 'Returning Patient Exam',
        description: 'Steps for returning patients with standard exams',
        conditions: [
          { field: 'isNewPatient', operator: 'equals', value: false }
        ],
        stepTemplateIds: ['confirm-appointment', 'insurance-verification'],
        priority: 90,
        isActive: true,
        phase: 'pre-visit',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      
      // In-office rules
      {
        id: 'standard-eye-exam',
        name: 'Standard Eye Examination',
        description: 'Standard in-office steps for regular eye exams',
        conditions: [
          { field: 'appointmentType', operator: 'equals', value: 'Comprehensive Eye Exam' }
        ],
        stepTemplateIds: ['check-in', 'pre-testing', 'exam', 'checkout'],
        priority: 100,
        isActive: true,
        phase: 'in-office',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 'contact-lens-fitting',
        name: 'Contact Lens Fitting',
        description: 'Steps for contact lens fitting appointments',
        conditions: [
          { field: 'appointmentType', operator: 'equals', value: 'Contact Lens Fitting' }
        ],
        stepTemplateIds: ['check-in', 'pre-testing', 'contact-lens-evaluation', 'lens-training', 'checkout'],
        priority: 90,
        isActive: true,
        phase: 'in-office',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 'diabetic-exam',
        name: 'Diabetic Eye Exam',
        description: 'Steps for diabetic eye examinations',
        conditions: [
          { field: 'appointmentType', operator: 'equals', value: 'Diabetic Eye Exam' }
        ],
        stepTemplateIds: ['check-in', 'pre-testing', 'dilation', 'retinal-imaging', 'exam', 'checkout'],
        priority: 95,
        isActive: true,
        phase: 'in-office',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      
      // Post-visit rules
      {
        id: 'standard-followup',
        name: 'Standard Post-Visit Follow-up',
        description: 'Standard follow-up steps for all patients',
        conditions: [],
        stepTemplateIds: ['satisfaction-survey'],
        priority: 50,
        isActive: true,
        phase: 'post-visit',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 'glasses-ordered',
        name: 'Glasses Ordered Follow-up',
        description: 'Follow-up for patients who ordered glasses',
        conditions: [
          { field: 'orderedGlasses', operator: 'equals', value: true }
        ],
        stepTemplateIds: ['glasses-status-update', 'pickup-reminder'],
        priority: 80,
        isActive: true,
        phase: 'post-visit',
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];
  }

  /**
   * Migrate default rules to use real Eyefinity appointment type values.
   * Only updates rules that still have the original default IDs.
   * User-created rules (with UUID IDs) are left untouched.
   */
  private migrateDefaultRules(): void {
    const migrationMap: Record<string, string> = {
      'comprehensive-exam': 'Comprehensive Eye Exam',
      'eye-exam': 'Comprehensive Eye Exam',
      'contact-lens-fitting': 'Contact Lens Fitting',
      'diabetic-exam': 'Diabetic Eye Exam',
    };

    const defaultRuleIds = new Set([
      'new-patient-exam', 'returning-patient-exam', 'standard-eye-exam',
      'contact-lens-fitting', 'diabetic-exam', 'standard-followup', 'glasses-ordered'
    ]);

    let changed = false;
    for (const rule of this.rules) {
      if (!defaultRuleIds.has(rule.id)) continue;
      for (const condition of rule.conditions) {
        if (condition.field === 'appointmentType' && typeof condition.value === 'string') {
          const mapped = migrationMap[condition.value];
          if (mapped) {
            condition.value = mapped;
            changed = true;
          }
        }
      }
    }

    if (changed) {
      this.saveToStorage();
      console.log('[JourneyRules] Migrated default rule appointment type values to Eyefinity format');
    }
  }

  private loadDefaultStepTemplates(): void {
    const templates: JourneyStep[] = [
      // Pre-visit templates
      {
        id: 'confirm-appointment',
        title: 'Confirm Appointment',
        description: 'Confirm upcoming appointment with patient',
        status: 'pending',
        stepType: 'pre-visit',
        communicationType: 'sms',
        responseRequired: true,
        templateId: 'appointment-confirmation',
        staffRole: 'Automated',
        reasonCodes: ['pre-visit']
      },
      {
        id: 'medical-history-form',
        title: 'Complete Medical History',
        description: 'Patient completes medical history form',
        status: 'pending',
        stepType: 'pre-visit',
        communicationType: 'email',
        responseRequired: true,
        templateId: 'medical-history',
        staffRole: 'Automated',
        reasonCodes: ['pre-visit', 'new-patient']
      },
      {
        id: 'insurance-verification',
        title: 'Verify Insurance',
        description: 'Verify patient insurance information',
        status: 'pending',
        stepType: 'pre-visit',
        communicationType: 'email',
        responseRequired: true,
        templateId: 'insurance-verification',
        staffRole: 'Automated',
        reasonCodes: ['pre-visit']
      },
      
      // In-office templates
      {
        id: 'check-in',
        title: 'Check-in',
        description: 'Patient arrival and initial paperwork',
        status: 'pending',
        stepType: 'in-office',
        staffRole: 'Front Desk',
        reasonCodes: ['standard-procedure'],
        duration: 15,
        responseRequired: false
      },
      {
        id: 'pre-testing',
        title: 'Pre-Testing',
        description: 'Initial eye tests and measurements',
        status: 'pending',
        stepType: 'in-office',
        staffRole: 'Technician',
        reasonCodes: ['standard-procedure'],
        duration: 20,
        responseRequired: false
      },
      {
        id: 'dilation',
        title: 'Dilation',
        description: 'Pupil dilation for comprehensive exam',
        status: 'pending',
        stepType: 'in-office',
        staffRole: 'Technician',
        reasonCodes: ['diabetic-care'],
        duration: 20,
        responseRequired: false
      },
      {
        id: 'retinal-imaging',
        title: 'Retinal Imaging',
        description: 'Digital retinal photography',
        status: 'pending',
        stepType: 'in-office',
        staffRole: 'Technician',
        reasonCodes: ['diabetic-care'],
        duration: 15,
        responseRequired: false
      },
      {
        id: 'exam',
        title: 'Doctor Examination',
        description: 'Comprehensive eye examination by doctor',
        status: 'pending',
        stepType: 'in-office',
        staffRole: 'Doctor',
        reasonCodes: ['standard-procedure'],
        duration: 30,
        responseRequired: false
      },
      {
        id: 'contact-lens-evaluation',
        title: 'Contact Lens Evaluation',
        description: 'Evaluation for contact lens fitting',
        status: 'pending',
        stepType: 'in-office',
        staffRole: 'Doctor',
        reasonCodes: ['contact-lens'],
        duration: 20,
        responseRequired: false
      },
      {
        id: 'lens-training',
        title: 'Contact Lens Training',
        description: 'Training on insertion, removal, and care',
        status: 'pending',
        stepType: 'in-office',
        staffRole: 'Technician',
        reasonCodes: ['contact-lens'],
        duration: 25,
        responseRequired: false
      },
      {
        id: 'checkout',
        title: 'Checkout',
        description: 'Payment and scheduling follow-up',
        status: 'pending',
        stepType: 'in-office',
        staffRole: 'Front Desk',
        reasonCodes: ['standard-procedure'],
        duration: 10,
        responseRequired: false
      },
      
      // Post-visit templates
      {
        id: 'satisfaction-survey',
        title: 'Patient Satisfaction Survey',
        description: 'Collect feedback on patient experience',
        status: 'pending',
        stepType: 'post-visit',
        staffRole: 'Automated',
        reasonCodes: ['post-visit'],
        communicationType: 'sms',
        responseRequired: true,
        templateId: 'satisfaction-survey'
      },
      {
        id: 'glasses-status-update',
        title: 'Glasses Order Status',
        description: 'Update patient on glasses order status',
        status: 'pending',
        stepType: 'post-visit',
        staffRole: 'Automated',
        reasonCodes: ['post-visit', 'glasses-order'],
        communicationType: 'sms',
        responseRequired: false,
        templateId: 'glasses-status'
      },
      {
        id: 'pickup-reminder',
        title: 'Pickup Reminder',
        description: 'Remind patient to pick up glasses/contacts',
        status: 'pending',
        stepType: 'post-visit',
        staffRole: 'Automated',
        reasonCodes: ['post-visit', 'pickup'],
        communicationType: 'sms',
        responseRequired: false,
        templateId: 'pickup-reminder'
      }
    ];

    for (const template of templates) {
      this.stepTemplates.set(template.id, template);
    }
  }
}

// Singleton instance
let rulesServiceInstance: JourneyRulesService | null = null;

export function getJourneyRulesService(): JourneyRulesService {
  if (!rulesServiceInstance) {
    rulesServiceInstance = new JourneyRulesService();
  }
  return rulesServiceInstance;
}
