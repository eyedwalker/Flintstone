/**
 * Step Audit Service
 * Tracks all step transitions, timing, and events for comprehensive reporting
 */

import { v4 as uuidv4 } from 'uuid';
import {
  StepAuditLog,
  StepEventType,
  StepAuditSummary,
  AuditLogQuery,
  AuditLogQueryResult,
  ReportingMetrics,
  PhaseMetrics,
  StepTypeMetrics
} from '../types/step-audit-log';
import { PatientJourney, JourneyStep } from '../types/patient-journey';

class StepAuditService {
  private readonly STORAGE_KEY = 'step_audit_logs';
  private logs: StepAuditLog[] = [];

  constructor() {
    this.loadLogs();
  }

  /**
   * Load logs from localStorage
   */
  private loadLogs(): void {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        this.logs = parsed.map((log: any) => ({
          ...log,
          eventTimestamp: new Date(log.eventTimestamp),
          stepStartTime: log.stepStartTime ? new Date(log.stepStartTime) : undefined,
          stepEndTime: log.stepEndTime ? new Date(log.stepEndTime) : undefined,
          createdAt: new Date(log.createdAt)
        }));
      }
    } catch (error) {
      console.error('Error loading audit logs:', error);
      this.logs = [];
    }
  }

  /**
   * Save logs to localStorage
   */
  private saveLogs(): void {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.logs));
    } catch (error) {
      console.error('Error saving audit logs:', error);
    }
  }

  /**
   * Log a step event
   */
  logStepEvent(params: {
    journey: PatientJourney;
    step: JourneyStep;
    eventType: StepEventType;
    performedBy?: string;
    performedByName?: string;
    location?: string;
    roomId?: string;
    roomName?: string;
    roomType?: string;
    externalSystemAction?: string;
    externalSystemUrl?: string;
    outcome?: 'success' | 'failed' | 'skipped' | 'cancelled';
    errorMessage?: string;
    metadata?: Record<string, any>;
  }): StepAuditLog {
    const now = new Date();
    
    // Calculate timing if step is completing
    let stepDuration: number | undefined;
    let stepStartTime: Date | undefined;
    let stepEndTime: Date | undefined;
    let waitTime: number | undefined;
    
    if (params.eventType === 'step-completed' || params.eventType === 'step-failed') {
      // Find the start event for this step
      const startLog = this.logs.find(
        log => log.journeyId === params.journey.id && 
               log.stepId === params.step.id && 
               log.eventType === 'step-started'
      );
      
      if (startLog) {
        stepStartTime = startLog.eventTimestamp;
        stepEndTime = now;
        stepDuration = Math.round((now.getTime() - startLog.eventTimestamp.getTime()) / 60000);
        
        // Calculate wait time (time from journey phase start to step start)
        if (params.journey.journeyPhase === 'in-office' && params.journey.checkInTime) {
          waitTime = Math.round((startLog.eventTimestamp.getTime() - params.journey.checkInTime.getTime()) / 60000);
        }
      }
    }

    const log: StepAuditLog = {
      id: uuidv4(),
      journeyId: params.journey.id,
      stepId: params.step.id,
      stepTitle: params.step.title,
      patientId: params.journey.patientId,
      patientName: params.journey.patientName,
      
      eventType: params.eventType,
      eventTimestamp: now,
      
      performedBy: params.performedBy,
      performedByName: params.performedByName,
      location: params.location,
      
      stepStartTime,
      stepEndTime,
      stepDuration,
      waitTime,
      
      roomId: params.roomId,
      roomName: params.roomName,
      roomType: params.roomType,
      
      externalSystemAction: params.externalSystemAction,
      externalSystemUrl: params.externalSystemUrl,
      externalPatientId: params.journey.legacyPatientId,
      externalAppointmentId: params.journey.legacyAppointmentId,
      
      journeyPhase: params.journey.journeyPhase === 'completed' ? 'post-visit' : params.journey.journeyPhase,
      
      metadata: params.metadata,
      
      providerId: params.journey.providerId,
      providerName: params.journey.providerName,
      
      officeId: 'default-office', // TODO: Get from context
      officeName: 'Main Office',
      
      outcome: params.outcome,
      errorMessage: params.errorMessage,
      
      isOvertime: stepDuration ? stepDuration > (params.step.duration || 15) : undefined,
      expectedDuration: params.step.duration,
      
      createdAt: now
    };

    this.logs.push(log);
    this.saveLogs();

    // Fire-and-forget persist to Supabase for analytics dashboard
    this.persistToSupabase(log);

    console.log('Step event logged:', {
      eventType: params.eventType,
      patient: params.journey.patientName,
      step: params.step.title,
      duration: stepDuration
    });

    return log;
  }

  /**
   * Persist audit log to Supabase via analytics API (fire-and-forget)
   */
  private persistToSupabase(log: StepAuditLog): void {
    try {
      const companyId = localStorage.getItem('selected_company_id') || undefined;
      const officeId = localStorage.getItem('selected_office_id') || log.officeId;
      fetch('/api/analytics/logs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...log,
          companyId,
          officeId,
          eventTimestamp: log.eventTimestamp.toISOString(),
          stepStartTime: log.stepStartTime?.toISOString(),
          stepEndTime: log.stepEndTime?.toISOString(),
          createdAt: log.createdAt.toISOString(),
        }),
      }).catch(err => {
        console.warn('[StepAudit] Supabase sync failed:', err.message);
      });
    } catch (e) {
      console.warn('[StepAudit] Supabase sync error:', e);
    }
  }

  /**
   * Get logs for a specific journey
   */
  getJourneyLogs(journeyId: string): StepAuditLog[] {
    return this.logs
      .filter(log => log.journeyId === journeyId)
      .sort((a, b) => a.eventTimestamp.getTime() - b.eventTimestamp.getTime());
  }

  /**
   * Get journey summary with all logs and metrics
   */
  getJourneySummary(journeyId: string): StepAuditSummary | null {
    const logs = this.getJourneyLogs(journeyId);
    if (logs.length === 0) return null;

    const firstLog = logs[0];
    const completedLogs = logs.filter(l => l.eventType === 'step-completed');
    const skippedLogs = logs.filter(l => l.eventType === 'step-skipped');
    const failedLogs = logs.filter(l => l.eventType === 'step-failed');

    const totalDuration = completedLogs.reduce((sum, log) => sum + (log.stepDuration || 0), 0);
    const totalWaitTime = completedLogs.reduce((sum, log) => sum + (log.waitTime || 0), 0);

    return {
      journeyId,
      patientName: firstLog.patientName,
      totalSteps: new Set(logs.map(l => l.stepId)).size,
      completedSteps: completedLogs.length,
      skippedSteps: skippedLogs.length,
      failedSteps: failedLogs.length,
      
      totalDuration,
      totalWaitTime,
      averageStepDuration: completedLogs.length > 0 ? totalDuration / completedLogs.length : 0,
      averageWaitTime: completedLogs.length > 0 ? totalWaitTime / completedLogs.length : 0,
      
      journeyStartTime: logs[0].eventTimestamp,
      journeyEndTime: logs[logs.length - 1].eventType === 'step-completed' ? logs[logs.length - 1].eventTimestamp : undefined,
      
      stepsOvertime: logs.filter(l => l.isOvertime).length,
      encompassLaunches: logs.filter(l => l.eventType === 'encompass-launched').length,
      roomChanges: logs.filter(l => l.eventType === 'room-assigned').length,
      
      logs
    };
  }

  /**
   * Query logs with filters
   */
  queryLogs(query: AuditLogQuery): AuditLogQueryResult {
    let filtered = [...this.logs];

    // Apply filters
    if (query.journeyId) {
      filtered = filtered.filter(log => log.journeyId === query.journeyId);
    }
    if (query.patientId) {
      filtered = filtered.filter(log => log.patientId === query.patientId);
    }
    if (query.stepId) {
      filtered = filtered.filter(log => log.stepId === query.stepId);
    }
    if (query.eventType) {
      const types = Array.isArray(query.eventType) ? query.eventType : [query.eventType];
      filtered = filtered.filter(log => types.includes(log.eventType));
    }
    if (query.performedBy) {
      filtered = filtered.filter(log => log.performedBy === query.performedBy);
    }
    if (query.roomId) {
      filtered = filtered.filter(log => log.roomId === query.roomId);
    }
    if (query.providerId) {
      filtered = filtered.filter(log => log.providerId === query.providerId);
    }
    if (query.officeId) {
      filtered = filtered.filter(log => log.officeId === query.officeId);
    }
    if (query.startDate) {
      filtered = filtered.filter(log => log.eventTimestamp >= query.startDate!);
    }
    if (query.endDate) {
      filtered = filtered.filter(log => log.eventTimestamp <= query.endDate!);
    }

    // Sort
    const sortBy = query.sortBy || 'eventTimestamp';
    const sortOrder = query.sortOrder || 'desc';
    filtered.sort((a, b) => {
      let aVal: any, bVal: any;
      if (sortBy === 'eventTimestamp') {
        aVal = a.eventTimestamp.getTime();
        bVal = b.eventTimestamp.getTime();
      } else if (sortBy === 'stepDuration') {
        aVal = a.stepDuration || 0;
        bVal = b.stepDuration || 0;
      } else if (sortBy === 'waitTime') {
        aVal = a.waitTime || 0;
        bVal = b.waitTime || 0;
      }
      return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
    });

    // Paginate
    const page = query.page || 1;
    const limit = query.limit || 50;
    const startIdx = (page - 1) * limit;
    const endIdx = startIdx + limit;
    const paginated = filtered.slice(startIdx, endIdx);

    return {
      logs: paginated,
      total: filtered.length,
      page,
      limit,
      hasMore: endIdx < filtered.length
    };
  }

  /**
   * Generate reporting metrics for a date range
   */
  generateMetrics(startDate: Date, endDate: Date): ReportingMetrics {
    const logsInRange = this.logs.filter(
      log => log.eventTimestamp >= startDate && log.eventTimestamp <= endDate
    );

    const journeyIds = new Set(logsInRange.map(l => l.journeyId));
    const completedJourneys = new Set(
      logsInRange.filter(l => l.eventType === 'step-completed' && l.journeyPhase === 'post-visit').map(l => l.journeyId)
    );

    const completedSteps = logsInRange.filter(l => l.eventType === 'step-completed');
    const totalDuration = completedSteps.reduce((sum, log) => sum + (log.stepDuration || 0), 0);
    const totalWaitTime = completedSteps.reduce((sum, log) => sum + (log.waitTime || 0), 0);

    const stepsOnTime = completedSteps.filter(l => !l.isOvertime).length;
    const stepsOvertime = completedSteps.filter(l => l.isOvertime).length;

    // Calculate phase metrics
    const preVisitMetrics = this.calculatePhaseMetrics(logsInRange, 'pre-visit');
    const inOfficeMetrics = this.calculatePhaseMetrics(logsInRange, 'in-office');
    const postVisitMetrics = this.calculatePhaseMetrics(logsInRange, 'post-visit');

    // Calculate step type metrics
    const stepTypeMetrics: Record<string, StepTypeMetrics> = {};
    const stepTitles = new Set(completedSteps.map(l => l.stepTitle));
    stepTitles.forEach(title => {
      const stepLogs = completedSteps.filter(l => l.stepTitle === title);
      stepTypeMetrics[title] = {
        stepTitle: title,
        count: stepLogs.length,
        averageDuration: stepLogs.reduce((sum, l) => sum + (l.stepDuration || 0), 0) / stepLogs.length,
        averageWaitTime: stepLogs.reduce((sum, l) => sum + (l.waitTime || 0), 0) / stepLogs.length,
        completionRate: 100, // TODO: Calculate based on total steps vs completed
        overtimeRate: (stepLogs.filter(l => l.isOvertime).length / stepLogs.length) * 100,
        encompassLaunches: logsInRange.filter(l => l.eventType === 'encompass-launched' && l.stepTitle === title).length
      };
    });

    return {
      startDate,
      endDate,
      
      totalJourneys: journeyIds.size,
      totalSteps: completedSteps.length,
      completedJourneys: completedJourneys.size,
      
      averageJourneyDuration: totalDuration / journeyIds.size,
      averageWaitTime: totalWaitTime / completedSteps.length || 0,
      averageStepDuration: totalDuration / completedSteps.length || 0,
      
      stepsCompletedOnTime: stepsOnTime,
      stepsOvertime,
      overtimeRate: (stepsOvertime / (stepsOnTime + stepsOvertime)) * 100 || 0,
      
      roomUtilizationRate: 75, // TODO: Calculate from room logs
      averageRoomTurnoverTime: 3, // TODO: Calculate from room transitions
      
      preVisitMetrics,
      inOfficeMetrics,
      postVisitMetrics,
      
      stepTypeMetrics,
      
      providerMetrics: {} // TODO: Calculate provider metrics
    };
  }

  /**
   * Calculate metrics for a specific phase
   */
  private calculatePhaseMetrics(logs: StepAuditLog[], phase: 'pre-visit' | 'in-office' | 'post-visit'): PhaseMetrics {
    const phaseLogs = logs.filter(l => l.journeyPhase === phase && l.eventType === 'step-completed');
    
    if (phaseLogs.length === 0) {
      return {
        totalSteps: 0,
        averageDuration: 0,
        averageWaitTime: 0,
        completionRate: 0,
        overtimeRate: 0
      };
    }

    const totalDuration = phaseLogs.reduce((sum, log) => sum + (log.stepDuration || 0), 0);
    const totalWaitTime = phaseLogs.reduce((sum, log) => sum + (log.waitTime || 0), 0);
    const overtimeSteps = phaseLogs.filter(l => l.isOvertime).length;

    return {
      totalSteps: phaseLogs.length,
      averageDuration: totalDuration / phaseLogs.length,
      averageWaitTime: totalWaitTime / phaseLogs.length,
      completionRate: 100, // TODO: Calculate based on expected vs actual
      overtimeRate: (overtimeSteps / phaseLogs.length) * 100
    };
  }

  /**
   * Export logs as CSV
   */
  exportToCSV(query?: AuditLogQuery): string {
    const result = query ? this.queryLogs(query) : { logs: this.logs, total: this.logs.length };
    
    const headers = [
      'Event ID',
      'Journey ID',
      'Patient Name',
      'Step Title',
      'Event Type',
      'Event Timestamp',
      'Duration (min)',
      'Wait Time (min)',
      'Room',
      'Performed By',
      'Location',
      'Phase',
      'Outcome',
      'Is Overtime'
    ];

    const rows = result.logs.map(log => [
      log.id,
      log.journeyId,
      log.patientName,
      log.stepTitle,
      log.eventType,
      log.eventTimestamp.toISOString(),
      log.stepDuration || '',
      log.waitTime || '',
      log.roomName || '',
      log.performedByName || log.performedBy || '',
      log.location || '',
      log.journeyPhase,
      log.outcome || '',
      log.isOvertime ? 'Yes' : 'No'
    ]);

    return [headers, ...rows].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
  }

  /**
   * Clear all logs (use with caution)
   */
  clearAllLogs(): void {
    this.logs = [];
    this.saveLogs();
  }

  /**
   * Get all logs (for debugging)
   */
  getAllLogs(): StepAuditLog[] {
    return [...this.logs];
  }
}

// Export singleton instance
export const stepAuditService = new StepAuditService();
