/**
 * Recommendation Service
 * 
 * Manages recommendation rules, generated recommendations, and tracking
 */

import {
  RecommendationRule,
  Recommendation,
  RecommendationContext,
  DisplayLocation,
  RecommendationEvent,
  ExternalRecommendation,
  RecommendationStatus
} from '../types/recommendation';
import { ProductRecommendationEngine } from './product-recommendation-engine';

const RULES_STORAGE_KEY = 'recommendation_rules';
const RECOMMENDATIONS_STORAGE_KEY = 'patient_recommendations';
const EVENTS_STORAGE_KEY = 'recommendation_events';
const DISMISSED_STORAGE_KEY = 'dismissed_recommendations';

export class RecommendationService {
  /**
   * Get all recommendation rules
   */
  static getRules(): RecommendationRule[] {
    try {
      const stored = localStorage.getItem(RULES_STORAGE_KEY);
      if (!stored) return this.getDefaultRules();
      
      const rules = JSON.parse(stored);
      // Convert date strings back to Date objects
      return rules.map(this.deserializeRule);
    } catch (error) {
      console.error('Error loading recommendation rules:', error);
      return this.getDefaultRules();
    }
  }

  /**
   * Save recommendation rules
   */
  static saveRules(rules: RecommendationRule[]): void {
    try {
      localStorage.setItem(RULES_STORAGE_KEY, JSON.stringify(rules));
    } catch (error) {
      console.error('Error saving recommendation rules:', error);
    }
  }

  /**
   * Get a single rule by ID
   */
  static getRule(ruleId: string): RecommendationRule | null {
    const rules = this.getRules();
    return rules.find(r => r.id === ruleId) || null;
  }

  /**
   * Create a new rule
   */
  static createRule(rule: Omit<RecommendationRule, 'id' | 'createdAt' | 'updatedAt' | 'metrics'>): RecommendationRule {
    const newRule: RecommendationRule = {
      ...rule,
      id: `rule-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date(),
      updatedAt: new Date(),
      metrics: {
        impressions: 0,
        clicks: 0,
        conversions: 0,
        dismissals: 0,
        lastUpdated: new Date()
      }
    };

    const rules = this.getRules();
    rules.push(newRule);
    this.saveRules(rules);

    return newRule;
  }

  /**
   * Update an existing rule
   */
  static updateRule(ruleId: string, updates: Partial<RecommendationRule>): RecommendationRule | null {
    const rules = this.getRules();
    const index = rules.findIndex(r => r.id === ruleId);

    if (index === -1) return null;

    rules[index] = {
      ...rules[index],
      ...updates,
      id: ruleId, // Ensure ID doesn't change
      updatedAt: new Date()
    };

    this.saveRules(rules);
    return rules[index];
  }

  /**
   * Delete a rule
   */
  static deleteRule(ruleId: string): boolean {
    const rules = this.getRules();
    const filtered = rules.filter(r => r.id !== ruleId);

    if (filtered.length === rules.length) return false;

    this.saveRules(filtered);
    return true;
  }

  /**
   * Generate recommendations for a patient
   */
  static generateRecommendations(
    context: RecommendationContext,
    displayLocation?: DisplayLocation
  ): Recommendation[] {
    console.log('[RecommendationService] Generating recommendations', {
      patientId: context.patient.id,
      displayLocation,
      context
    });

    const rules = this.getRules();
    console.log('[RecommendationService] Total rules loaded:', rules.length);
    console.log('[RecommendationService] Rules:', rules.map(r => ({ 
      id: r.id, 
      name: r.name, 
      enabled: r.enabled,
      priority: r.priority,
      conditions: r.conditions.length,
      locations: r.displayConfig.locations
    })));

    const engine = ProductRecommendationEngine;
    
    // Get dismissed recommendations for this patient
    const dismissedKey = `${DISMISSED_STORAGE_KEY}_${context.patient.id}`;
    const dismissed = new Set(
      JSON.parse(localStorage.getItem(dismissedKey) || '[]')
    );
    
    console.log('[RecommendationService] Dismissed rule IDs:', Array.from(dismissed));
    
    // Filter out dismissed rules
    const activeRules = rules.filter(r => !dismissed.has(r.id));
    console.log('[RecommendationService] Active rules after dismissals:', activeRules.length);
    
    // Generate recommendations
    const recommendations = engine.evaluatePatient(activeRules, context, displayLocation);
    
    console.log('[RecommendationService] Final recommendations:', recommendations.length, recommendations);
    
    return recommendations;
  }

  /**
   * Get recommendations for a patient
   */
  static getRecommendations(patientId: string, displayLocation?: DisplayLocation): Recommendation[] {
    try {
      const stored = localStorage.getItem(RECOMMENDATIONS_STORAGE_KEY);
      if (!stored) return [];

      const allRecommendations: Record<string, Recommendation[]> = JSON.parse(stored);
      let recommendations = allRecommendations[patientId] || [];

      // Filter by display location
      if (displayLocation) {
        recommendations = recommendations.filter(r => 
          r.displayLocations.includes(displayLocation)
        );
      }

      // Filter out expired
      recommendations = recommendations.filter(r => {
        if (!r.expiresAt) return true;
        return new Date() < new Date(r.expiresAt);
      });

      // Convert date strings back to Date objects
      return recommendations.map(this.deserializeRecommendation);
    } catch (error) {
      console.error('Error loading recommendations:', error);
      return [];
    }
  }

  /**
   * Store recommendations for a patient
   */
  private static storeRecommendations(patientId: string, recommendations: Recommendation[]): void {
    try {
      const stored = localStorage.getItem(RECOMMENDATIONS_STORAGE_KEY);
      const allRecommendations: Record<string, Recommendation[]> = stored ? JSON.parse(stored) : {};

      allRecommendations[patientId] = recommendations;

      localStorage.setItem(RECOMMENDATIONS_STORAGE_KEY, JSON.stringify(allRecommendations));
    } catch (error) {
      console.error('Error storing recommendations:', error);
    }
  }

  /**
   * Track recommendation event
   */
  static trackEvent(
    recommendationId: string,
    patientId: string,
    eventType: 'impression' | 'click' | 'conversion' | 'dismissal',
    location: DisplayLocation,
    metadata?: Record<string, any>
  ): void {
    // Create event
    const event: RecommendationEvent = {
      id: `event-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      recommendationId,
      patientId,
      eventType,
      timestamp: new Date(),
      location,
      metadata
    };

    // Store event
    this.storeEvent(event);

    // Update recommendation status
    this.updateRecommendationStatus(recommendationId, patientId, eventType);

    // Update rule metrics
    const recommendation = this.getRecommendationById(recommendationId, patientId);
    if (recommendation) {
      this.updateRuleMetrics(recommendation.ruleId, eventType);
    }
  }

  /**
   * Store an event
   */
  private static storeEvent(event: RecommendationEvent): void {
    try {
      const stored = localStorage.getItem(EVENTS_STORAGE_KEY);
      const events: RecommendationEvent[] = stored ? JSON.parse(stored) : [];

      events.push(event);

      // Keep only last 1000 events
      if (events.length > 1000) {
        events.splice(0, events.length - 1000);
      }

      localStorage.setItem(EVENTS_STORAGE_KEY, JSON.stringify(events));
    } catch (error) {
      console.error('Error storing event:', error);
    }
  }

  /**
   * Update recommendation status
   */
  private static updateRecommendationStatus(
    recommendationId: string,
    patientId: string,
    eventType: 'impression' | 'click' | 'conversion' | 'dismissal'
  ): void {
    const recommendations = this.getRecommendations(patientId);
    const rec = recommendations.find(r => r.id === recommendationId);

    if (!rec) return;

    const statusMap: Record<string, RecommendationStatus> = {
      impression: 'displayed',
      click: 'clicked',
      conversion: 'converted',
      dismissal: 'dismissed'
    };

    rec.status = statusMap[eventType];

    if (eventType === 'impression') rec.displayedAt = new Date();
    if (eventType === 'click') rec.clickedAt = new Date();
    if (eventType === 'conversion') rec.convertedAt = new Date();
    if (eventType === 'dismissal') rec.dismissedAt = new Date();

    this.storeRecommendations(patientId, recommendations);
  }

  /**
   * Update rule metrics
   */
  private static updateRuleMetrics(
    ruleId: string,
    eventType: 'impression' | 'click' | 'conversion' | 'dismissal'
  ): void {
    const rule = this.getRule(ruleId);
    if (!rule) return;

    if (eventType === 'impression') rule.metrics.impressions++;
    if (eventType === 'click') rule.metrics.clicks++;
    if (eventType === 'conversion') rule.metrics.conversions++;
    if (eventType === 'dismissal') rule.metrics.dismissals++;

    // Calculate rates
    if (rule.metrics.impressions > 0) {
      rule.metrics.clickThroughRate = rule.metrics.clicks / rule.metrics.impressions;
      rule.metrics.conversionRate = rule.metrics.conversions / rule.metrics.impressions;
    }

    rule.metrics.lastUpdated = new Date();

    this.updateRule(ruleId, { metrics: rule.metrics });
  }

  /**
   * Get a recommendation by ID
   */
  private static getRecommendationById(recommendationId: string, patientId: string): Recommendation | null {
    const recommendations = this.getRecommendations(patientId);
    return recommendations.find(r => r.id === recommendationId) || null;
  }

  /**
   * Dismiss a recommendation
   */
  static dismissRecommendation(recommendationId: string, patientId: string, location: DisplayLocation): void {
    const recommendation = this.getRecommendationById(recommendationId, patientId);
    if (!recommendation) return;

    // Track dismissal event
    this.trackEvent(recommendationId, patientId, 'dismissal', location);

    // Add to dismissed list
    this.addToDismissed(patientId, recommendation.ruleId);
  }

  /**
   * Add a rule to dismissed list for patient
   */
  private static addToDismissed(patientId: string, ruleId: string): void {
    try {
      const stored = localStorage.getItem(DISMISSED_STORAGE_KEY);
      const dismissed: Record<string, string[]> = stored ? JSON.parse(stored) : {};

      if (!dismissed[patientId]) dismissed[patientId] = [];
      if (!dismissed[patientId].includes(ruleId)) {
        dismissed[patientId].push(ruleId);
      }

      localStorage.setItem(DISMISSED_STORAGE_KEY, JSON.stringify(dismissed));
    } catch (error) {
      console.error('Error storing dismissed recommendation:', error);
    }
  }

  /**
   * Get dismissed rules for a patient
   */
  private static getDismissedRules(patientId: string): string[] {
    try {
      const stored = localStorage.getItem(DISMISSED_STORAGE_KEY);
      if (!stored) return [];

      const dismissed: Record<string, string[]> = JSON.parse(stored);
      return dismissed[patientId] || [];
    } catch (error) {
      console.error('Error loading dismissed recommendations:', error);
      return [];
    }
  }

  /**
   * Add external recommendation from third-party system
   */
  static addExternalRecommendation(external: ExternalRecommendation): Recommendation {
    const recommendation: Recommendation = {
      id: `ext-${external.externalId}`,
      ruleId: `external-${external.source}`,
      patientId: external.patientId,
      title: external.title,
      description: external.description,
      mediaType: external.mediaType,
      mediaUrl: external.mediaUrl,
      ctaText: external.ctaText,
      ctaUrl: external.ctaUrl,
      displayLocations: external.displayLocations || ['patient-details-sidebar'],
      priority: external.priority || 50,
      status: 'pending',
      generatedAt: new Date(),
      expiresAt: external.expiresAt,
      metadata: {
        ...external.metadata,
        source: external.source,
        externalId: external.externalId
      }
    };

    // Store recommendation
    const existing = this.getRecommendations(external.patientId);
    existing.push(recommendation);
    this.storeRecommendations(external.patientId, existing);

    return recommendation;
  }

  /**
   * Get analytics for all recommendations
   */
  static getAnalytics(): {
    totalRules: number;
    activeRules: number;
    totalImpressions: number;
    totalClicks: number;
    totalConversions: number;
    avgCTR: number;
    avgConversionRate: number;
    topPerformingRules: Array<{ rule: RecommendationRule; ctr: number; conversionRate: number }>;
  } {
    const rules = this.getRules();
    const activeRules = rules.filter(r => r.enabled);

    const totalImpressions = rules.reduce((sum, r) => sum + r.metrics.impressions, 0);
    const totalClicks = rules.reduce((sum, r) => sum + r.metrics.clicks, 0);
    const totalConversions = rules.reduce((sum, r) => sum + r.metrics.conversions, 0);

    const avgCTR = totalImpressions > 0 ? totalClicks / totalImpressions : 0;
    const avgConversionRate = totalImpressions > 0 ? totalConversions / totalImpressions : 0;

    const topPerformingRules = rules
      .filter(r => r.metrics.impressions >= 10) // Min 10 impressions
      .map(r => ({
        rule: r,
        ctr: r.metrics.clickThroughRate || 0,
        conversionRate: r.metrics.conversionRate || 0
      }))
      .sort((a, b) => b.conversionRate - a.conversionRate)
      .slice(0, 10);

    return {
      totalRules: rules.length,
      activeRules: activeRules.length,
      totalImpressions,
      totalClicks,
      totalConversions,
      avgCTR,
      avgConversionRate,
      topPerformingRules
    };
  }

  /**
   * Deserialize a rule (convert date strings to Date objects)
   */
  private static deserializeRule(rule: any): RecommendationRule {
    return {
      ...rule,
      createdAt: new Date(rule.createdAt),
      updatedAt: new Date(rule.updatedAt),
      validFrom: rule.validFrom ? new Date(rule.validFrom) : undefined,
      validUntil: rule.validUntil ? new Date(rule.validUntil) : undefined,
      metrics: {
        ...rule.metrics,
        lastUpdated: new Date(rule.metrics.lastUpdated)
      }
    };
  }

  /**
   * Deserialize a recommendation
   */
  private static deserializeRecommendation(rec: any): Recommendation {
    return {
      ...rec,
      generatedAt: new Date(rec.generatedAt),
      expiresAt: rec.expiresAt ? new Date(rec.expiresAt) : undefined,
      displayedAt: rec.displayedAt ? new Date(rec.displayedAt) : undefined,
      clickedAt: rec.clickedAt ? new Date(rec.clickedAt) : undefined,
      convertedAt: rec.convertedAt ? new Date(rec.convertedAt) : undefined,
      dismissedAt: rec.dismissedAt ? new Date(rec.dismissedAt) : undefined
    };
  }

  /**
   * Get default recommendation rules
   */
  private static getDefaultRules(): RecommendationRule[] {
    return [];
  }
}
