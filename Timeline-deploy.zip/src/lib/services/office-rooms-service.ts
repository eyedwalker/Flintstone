/**
 * Office Rooms Service
 * Manages room configuration and patient room tracking for in-office journeys
 */

import {
  OfficeRoom,
  OfficeRoomConfig,
  RoomOccupancy,
  RoomAssignment,
  RoomStatus,
  DEFAULT_ROOM_CONFIGS,
} from '../types/office-rooms';

const ROOMS_STORAGE_KEY = 'timeline_office_rooms';
const OCCUPANCY_STORAGE_KEY = 'timeline_room_occupancy';

export class OfficeRoomsService {
  // Get room configuration for an office
  static getOfficeConfig(officeId: string): OfficeRoomConfig | null {
    const stored = localStorage.getItem(ROOMS_STORAGE_KEY);
    const configs: Record<string, OfficeRoomConfig> = stored ? JSON.parse(stored) : {};
    return configs[officeId] || null;
  }

  // Get all office configurations
  static getAllConfigs(): OfficeRoomConfig[] {
    const stored = localStorage.getItem(ROOMS_STORAGE_KEY);
    const configs: Record<string, OfficeRoomConfig> = stored ? JSON.parse(stored) : {};
    return Object.values(configs);
  }

  // Initialize office with default rooms
  static initializeOffice(officeId: string, officeName: string, size: 'small' | 'medium' | 'large' = 'medium'): OfficeRoomConfig {
    const defaultRooms = DEFAULT_ROOM_CONFIGS[size];
    
    const rooms: OfficeRoom[] = defaultRooms.map((room, index) => ({
      ...room,
      id: `room_${officeId}_${index + 1}`,
      officeId,
    }));

    const config: OfficeRoomConfig = {
      officeId,
      officeName,
      rooms,
      showWaitingArea: true,
      showCheckoutArea: true,
      alertThresholdMinutes: 30,
      defaultExamDuration: 20,
      defaultPreTestDuration: 15,
      defaultDilationWaitTime: 20,
      updatedAt: new Date(),
    };

    this.saveOfficeConfig(config);
    return config;
  }

  // Save office configuration
  static saveOfficeConfig(config: OfficeRoomConfig): void {
    const stored = localStorage.getItem(ROOMS_STORAGE_KEY);
    const configs: Record<string, OfficeRoomConfig> = stored ? JSON.parse(stored) : {};
    configs[config.officeId] = { ...config, updatedAt: new Date() };
    localStorage.setItem(ROOMS_STORAGE_KEY, JSON.stringify(configs));
  }

  // Get rooms for an office
  static getRooms(officeId: string): OfficeRoom[] {
    const config = this.getOfficeConfig(officeId);
    return config?.rooms || [];
  }

  // Get available rooms of a specific type
  static getAvailableRooms(officeId: string, roomType?: string): OfficeRoom[] {
    const rooms = this.getRooms(officeId);
    return rooms.filter(r => 
      r.isActive && 
      r.status === 'available' &&
      (!roomType || r.type === roomType)
    );
  }

  // Add a room to an office
  static addRoom(officeId: string, room: Omit<OfficeRoom, 'id' | 'officeId'>): OfficeRoom {
    const config = this.getOfficeConfig(officeId);
    if (!config) throw new Error('Office not configured');

    const newRoom: OfficeRoom = {
      ...room,
      id: `room_${officeId}_${Date.now()}`,
      officeId,
    };

    config.rooms.push(newRoom);
    this.saveOfficeConfig(config);
    return newRoom;
  }

  // Update a room
  static updateRoom(officeId: string, roomId: string, updates: Partial<OfficeRoom>): OfficeRoom | null {
    const config = this.getOfficeConfig(officeId);
    if (!config) return null;

    const index = config.rooms.findIndex(r => r.id === roomId);
    if (index === -1) return null;

    config.rooms[index] = { ...config.rooms[index], ...updates };
    this.saveOfficeConfig(config);
    return config.rooms[index];
  }

  // Delete a room
  static deleteRoom(officeId: string, roomId: string): boolean {
    const config = this.getOfficeConfig(officeId);
    if (!config) return false;

    const initialLength = config.rooms.length;
    config.rooms = config.rooms.filter(r => r.id !== roomId);
    
    if (config.rooms.length < initialLength) {
      this.saveOfficeConfig(config);
      return true;
    }
    return false;
  }

  // Assign patient to room
  static assignPatientToRoom(
    officeId: string,
    roomId: string,
    patientId: string,
    patientName: string,
    journeyId: string,
    stepId: string,
    stepTitle: string,
    staffId?: string,
    staffName?: string
  ): RoomOccupancy | null {
    const config = this.getOfficeConfig(officeId);
    if (!config) return null;

    const room = config.rooms.find(r => r.id === roomId);
    if (!room) return null;

    // Update room status
    room.status = 'occupied';
    room.currentPatientId = patientId;
    room.currentPatientName = patientName;
    room.currentJourneyId = journeyId;
    room.occupiedSince = new Date();
    if (room.defaultDurationMinutes) {
      room.expectedEndTime = new Date(Date.now() + room.defaultDurationMinutes * 60 * 1000);
    }
    this.saveOfficeConfig(config);

    // Create occupancy record
    const occupancy: RoomOccupancy = {
      id: `occ_${Date.now()}`,
      roomId,
      roomName: room.name,
      patientId,
      patientName,
      journeyId,
      stepId,
      stepTitle,
      startTime: new Date(),
      expectedDurationMinutes: room.defaultDurationMinutes,
      staffId,
      staffName,
    };

    this.saveOccupancy(occupancy);
    return occupancy;
  }

  // Release patient from room
  static releasePatientFromRoom(officeId: string, roomId: string): RoomOccupancy | null {
    const config = this.getOfficeConfig(officeId);
    if (!config) return null;

    const room = config.rooms.find(r => r.id === roomId);
    if (!room || !room.currentPatientId) return null;

    // Find active occupancy
    const occupancy = this.getActiveOccupancy(roomId);
    
    // Update room status
    room.status = 'available';
    const previousPatientId = room.currentPatientId;
    room.currentPatientId = undefined;
    room.currentPatientName = undefined;
    room.currentJourneyId = undefined;
    room.occupiedSince = undefined;
    room.expectedEndTime = undefined;
    this.saveOfficeConfig(config);

    // Update occupancy record
    if (occupancy) {
      occupancy.endTime = new Date();
      occupancy.durationMinutes = Math.round(
        (occupancy.endTime.getTime() - new Date(occupancy.startTime).getTime()) / 60000
      );
      occupancy.isOvertime = occupancy.expectedDurationMinutes 
        ? occupancy.durationMinutes > occupancy.expectedDurationMinutes 
        : false;
      this.saveOccupancy(occupancy);
      return occupancy;
    }

    return null;
  }

  // Set room status
  static setRoomStatus(officeId: string, roomId: string, status: RoomStatus): boolean {
    const config = this.getOfficeConfig(officeId);
    if (!config) return false;

    const room = config.rooms.find(r => r.id === roomId);
    if (!room) return false;

    // If marking as available, clear patient info
    if (status === 'available') {
      room.currentPatientId = undefined;
      room.currentPatientName = undefined;
      room.currentJourneyId = undefined;
      room.occupiedSince = undefined;
      room.expectedEndTime = undefined;
    }

    room.status = status;
    this.saveOfficeConfig(config);
    return true;
  }

  // Get current occupancy for a room
  static getActiveOccupancy(roomId: string): RoomOccupancy | null {
    const stored = localStorage.getItem(OCCUPANCY_STORAGE_KEY);
    const occupancies: RoomOccupancy[] = stored ? JSON.parse(stored) : [];
    return occupancies.find(o => o.roomId === roomId && !o.endTime) || null;
  }

  // Get occupancy history for a room
  static getRoomOccupancyHistory(roomId: string, limit: number = 20): RoomOccupancy[] {
    const stored = localStorage.getItem(OCCUPANCY_STORAGE_KEY);
    const occupancies: RoomOccupancy[] = stored ? JSON.parse(stored) : [];
    return occupancies
      .filter(o => o.roomId === roomId && o.endTime)
      .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime())
      .slice(0, limit);
  }

  // Get occupancy history for a patient
  static getPatientRoomHistory(patientId: string): RoomOccupancy[] {
    const stored = localStorage.getItem(OCCUPANCY_STORAGE_KEY);
    const occupancies: RoomOccupancy[] = stored ? JSON.parse(stored) : [];
    return occupancies
      .filter(o => o.patientId === patientId)
      .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());
  }

  // Save occupancy record
  private static saveOccupancy(occupancy: RoomOccupancy): void {
    const stored = localStorage.getItem(OCCUPANCY_STORAGE_KEY);
    let occupancies: RoomOccupancy[] = stored ? JSON.parse(stored) : [];
    
    const index = occupancies.findIndex(o => o.id === occupancy.id);
    if (index >= 0) {
      occupancies[index] = occupancy;
    } else {
      occupancies.push(occupancy);
    }

    // Keep only last 1000 records
    if (occupancies.length > 1000) {
      occupancies = occupancies.slice(-1000);
    }

    localStorage.setItem(OCCUPANCY_STORAGE_KEY, JSON.stringify(occupancies));
  }

  // Get room utilization stats
  static getRoomStats(officeId: string, date?: Date): {
    totalRooms: number;
    occupied: number;
    available: number;
    avgWaitTime: number;
    avgOccupancyTime: number;
  } {
    const rooms = this.getRooms(officeId);
    const occupied = rooms.filter(r => r.status === 'occupied').length;
    
    // Get today's occupancy records
    const targetDate = date || new Date();
    const startOfDay = new Date(targetDate);
    startOfDay.setHours(0, 0, 0, 0);
    
    const stored = localStorage.getItem(OCCUPANCY_STORAGE_KEY);
    const occupancies: RoomOccupancy[] = stored ? JSON.parse(stored) : [];
    const todayOccupancies = occupancies.filter(o => 
      new Date(o.startTime) >= startOfDay &&
      o.endTime
    );

    const avgOccupancy = todayOccupancies.length > 0
      ? todayOccupancies.reduce((sum, o) => sum + (o.durationMinutes || 0), 0) / todayOccupancies.length
      : 0;

    return {
      totalRooms: rooms.filter(r => r.isActive).length,
      occupied,
      available: rooms.filter(r => r.status === 'available' && r.isActive).length,
      avgWaitTime: 0, // Would need to track wait times separately
      avgOccupancyTime: Math.round(avgOccupancy),
    };
  }

  // Get rooms with overtime patients
  static getOvertimeRooms(officeId: string): OfficeRoom[] {
    const config = this.getOfficeConfig(officeId);
    if (!config) return [];

    const now = new Date();
    return config.rooms.filter(r => 
      r.status === 'occupied' &&
      r.expectedEndTime &&
      new Date(r.expectedEndTime) < now
    );
  }

  // Get room assignment for journey step
  static getRoomAssignmentForStep(journeyId: string, stepId: string): RoomAssignment | null {
    const stored = localStorage.getItem(OCCUPANCY_STORAGE_KEY);
    const occupancies: RoomOccupancy[] = stored ? JSON.parse(stored) : [];
    const occupancy = occupancies.find(o => 
      o.journeyId === journeyId && 
      o.stepId === stepId
    );

    if (!occupancy) return null;

    return {
      roomId: occupancy.roomId,
      roomName: occupancy.roomName,
      assignedAt: new Date(occupancy.startTime),
      expectedDuration: occupancy.expectedDurationMinutes,
    };
  }
}

export default OfficeRoomsService;
