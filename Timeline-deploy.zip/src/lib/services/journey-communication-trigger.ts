/**
 * Journey Communication Trigger Service
 * Automatically triggers AI communications based on patient journey events
 */

import { AICommunicationOrchestrator } from './ai-communication-orchestrator';
import { UnifiedCommunicationService } from './unified-communication-service';
import { PatientJourney, JourneyStep, JourneyPhase } from '../types/patient-journey';
import { AICommunicationTrigger } from '../types/communication-preferences';

export interface JourneyEvent {
  type: 'journey_started' | 'step_started' | 'step_completed' | 'phase_changed' | 'journey_completed';
  journey: PatientJourney;
  step?: JourneyStep;
  previousPhase?: JourneyPhase;
  newPhase?: JourneyPhase;
}

export interface TriggerResult {
  triggered: boolean;
  triggerId?: string;
  channel?: string;
  message?: string;
  error?: string;
}

const PENDING_TRIGGERS_KEY = 'pending_journey_triggers';

class JourneyCommunicationTriggerClass {
  private officeId = '936'; // Default office

  /**
   * Process a journey event and trigger appropriate communications
   */
  async processJourneyEvent(event: JourneyEvent): Promise<TriggerResult[]> {
    const results: TriggerResult[] = [];
    const settings = AICommunicationOrchestrator.getSettings(this.officeId);

    if (!settings.globalEnabled) {
      return [{ triggered: false, error: 'AI communications disabled' }];
    }

    // Map journey events to trigger types
    const triggerType = this.mapEventToTriggerType(event);
    if (!triggerType) {
      return [{ triggered: false, error: 'No trigger type for event' }];
    }

    // Find matching triggers
    const matchingTriggers = settings.triggers.filter(
      t => t.enabled && t.triggerType === triggerType
    );

    for (const trigger of matchingTriggers) {
      const result = await this.executeTrigger(trigger, event);
      results.push(result);
    }

    return results;
  }

  private mapEventToTriggerType(event: JourneyEvent): AICommunicationTrigger['triggerType'] | null {
    switch (event.type) {
      case 'journey_started':
        return 'journey_step_started';
      case 'step_started':
        return 'journey_step_started';
      case 'step_completed':
        return null; // Could add a specific trigger type
      case 'phase_changed':
        if (event.newPhase === 'post-visit') {
          return 'post_visit_followup';
        }
        return 'journey_step_started';
      case 'journey_completed':
        return 'post_visit_followup';
      default:
        return null;
    }
  }

  private async executeTrigger(
    trigger: AICommunicationTrigger,
    event: JourneyEvent
  ): Promise<TriggerResult> {
    const { journey, step } = event;

    // Check if we should delay
    if (trigger.timing.delayMinutes && trigger.timing.delayMinutes > 0) {
      this.scheduleTrigger(trigger, event, trigger.timing.delayMinutes);
      return {
        triggered: true,
        triggerId: trigger.id,
        message: `Scheduled for ${trigger.timing.delayMinutes} minutes`,
      };
    }

    // Select channel and dispatch
    const channelResult = AICommunicationOrchestrator.selectChannel(
      journey.patientId,
      trigger,
      AICommunicationOrchestrator.getSettings(this.officeId)
    );

    if (!channelResult.channel) {
      return {
        triggered: false,
        triggerId: trigger.id,
        error: channelResult.reason,
      };
    }

    // Generate message
    const message = this.generateMessage(trigger, event);

    // Dispatch
    try {
      switch (channelResult.channel) {
        case 'sms':
          await UnifiedCommunicationService.sendSMS({
            to: '+12142085261', // Demo phone
            message,
            patientId: journey.patientId,
            patientName: journey.patientName,
            sentBy: 'AI Assistant',
          });
          break;
        case 'email':
          await UnifiedCommunicationService.sendEmail({
            to: 'daviwa2@vsp.com', // Demo email
            subject: this.generateSubject(trigger, event),
            body: message,
            patientId: journey.patientId,
            patientName: journey.patientName,
            sentBy: 'AI Assistant',
          });
          break;
        case 'voice':
          await UnifiedCommunicationService.makeCall({
            to: '+12142085261',
            message,
            patientId: journey.patientId,
            patientName: journey.patientName,
            calledBy: 'AI Assistant',
            useAIVoice: true,
          });
          break;
      }

      // Log the communication
      AICommunicationOrchestrator.logCommunication({
        patientId: journey.patientId,
        patientName: journey.patientName,
        triggerId: trigger.id,
        triggerName: trigger.name,
        channel: channelResult.channel,
        status: 'sent',
        message,
        attemptNumber: 1,
      });

      return {
        triggered: true,
        triggerId: trigger.id,
        channel: channelResult.channel,
        message,
      };
    } catch (error: any) {
      return {
        triggered: false,
        triggerId: trigger.id,
        error: error.message,
      };
    }
  }

  private generateMessage(trigger: AICommunicationTrigger, event: JourneyEvent): string {
    const { journey, step } = event;

    // Use AI-generated or template
    if (trigger.messageConfig.useAIGenerated) {
      return this.generateAIMessage(trigger, event);
    }

    // Basic templated messages
    const templates: Record<string, string> = {
      journey_step_started: `Hi ${journey.patientName}! Your ${step?.title || 'next step'} is ready. Please check in with our staff.`,
      post_visit_followup: `Hi ${journey.patientName}! Thank you for visiting us today. How was your experience? Reply with any questions.`,
      appointment_reminder: `Hi ${journey.patientName}! This is a reminder about your upcoming appointment.`,
    };

    return templates[trigger.triggerType] || `Hi ${journey.patientName}! You have an update from your eye care provider.`;
  }

  private generateAIMessage(trigger: AICommunicationTrigger, event: JourneyEvent): string {
    const { journey, step } = event;
    
    // In production, this would call the AI service
    // For now, generate contextual messages based on the event
    switch (event.type) {
      case 'journey_started':
        return `Hi ${journey.patientName}! Welcome to your eye care journey. We've prepared everything for your visit. Your first step is: ${step?.title || 'Check-in'}. We're here if you have any questions!`;
      
      case 'step_started':
        return `Hi ${journey.patientName}! It's time for: ${step?.title}. ${step?.description || 'Our team is ready to assist you.'}`;
      
      case 'phase_changed':
        if (event.newPhase === 'in-office') {
          return `Hi ${journey.patientName}! Welcome to our office. Please check in at the front desk and we'll get you started right away.`;
        } else if (event.newPhase === 'post-visit') {
          return `Hi ${journey.patientName}! Thank you for your visit today. We hope everything went well! Please don't hesitate to reach out if you have any questions about your visit or prescriptions.`;
        }
        return `Hi ${journey.patientName}! Your journey has moved to the ${event.newPhase} phase.`;
      
      case 'journey_completed':
        return `Hi ${journey.patientName}! Your visit is complete. Thank you for choosing us for your eye care. We look forward to seeing you again! Please reply if you have any follow-up questions.`;
      
      default:
        return `Hi ${journey.patientName}! You have an update from your eye care provider.`;
    }
  }

  private generateSubject(trigger: AICommunicationTrigger, event: JourneyEvent): string {
    const { journey } = event;
    
    switch (event.type) {
      case 'journey_started':
        return `Welcome to Your Eye Care Journey - ${journey.patientName}`;
      case 'step_started':
        return `Action Required: ${event.step?.title || 'Next Step Ready'}`;
      case 'phase_changed':
        return `Your Visit Update - ${event.newPhase} Phase`;
      case 'journey_completed':
        return `Thank You for Your Visit - ${journey.patientName}`;
      default:
        return `Update from Your Eye Care Provider`;
    }
  }

  private scheduleTrigger(
    trigger: AICommunicationTrigger,
    event: JourneyEvent,
    delayMinutes: number
  ): void {
    const pendingTriggers = this.getPendingTriggers();
    pendingTriggers.push({
      triggerId: trigger.id,
      event,
      executeAt: new Date(Date.now() + delayMinutes * 60 * 1000).toISOString(),
    });
    localStorage.setItem(PENDING_TRIGGERS_KEY, JSON.stringify(pendingTriggers));
    
    console.log(`[JourneyTrigger] Scheduled trigger ${trigger.id} for ${delayMinutes} minutes`);
  }

  private getPendingTriggers(): Array<{
    triggerId: string;
    event: JourneyEvent;
    executeAt: string;
  }> {
    const stored = localStorage.getItem(PENDING_TRIGGERS_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  /**
   * Process any pending scheduled triggers
   * Call this periodically (e.g., every minute)
   */
  async processPendingTriggers(): Promise<void> {
    const pendingTriggers = this.getPendingTriggers();
    const now = new Date();
    const remaining: typeof pendingTriggers = [];

    for (const pending of pendingTriggers) {
      if (new Date(pending.executeAt) <= now) {
        const settings = AICommunicationOrchestrator.getSettings(this.officeId);
        const trigger = settings.triggers.find(t => t.id === pending.triggerId);
        if (trigger) {
          // Execute without delay this time
          const modifiedTrigger = { ...trigger, timing: { ...trigger.timing, delayMinutes: 0 } };
          await this.executeTrigger(modifiedTrigger, pending.event);
        }
      } else {
        remaining.push(pending);
      }
    }

    localStorage.setItem(PENDING_TRIGGERS_KEY, JSON.stringify(remaining));
  }

  /**
   * Hook to call when a journey is created
   */
  async onJourneyCreated(journey: PatientJourney): Promise<TriggerResult[]> {
    const currentStep = journey.steps.find(s => s.id === journey.currentStepId);
    return this.processJourneyEvent({
      type: 'journey_started',
      journey,
      step: currentStep,
    });
  }

  /**
   * Hook to call when a step is started
   */
  async onStepStarted(journey: PatientJourney, step: JourneyStep): Promise<TriggerResult[]> {
    return this.processJourneyEvent({
      type: 'step_started',
      journey,
      step,
    });
  }

  /**
   * Hook to call when a step is completed
   */
  async onStepCompleted(journey: PatientJourney, step: JourneyStep): Promise<TriggerResult[]> {
    return this.processJourneyEvent({
      type: 'step_completed',
      journey,
      step,
    });
  }

  /**
   * Hook to call when journey phase changes
   */
  async onPhaseChanged(
    journey: PatientJourney,
    previousPhase: JourneyPhase,
    newPhase: JourneyPhase
  ): Promise<TriggerResult[]> {
    return this.processJourneyEvent({
      type: 'phase_changed',
      journey,
      previousPhase,
      newPhase,
    });
  }

  /**
   * Hook to call when journey is completed
   */
  async onJourneyCompleted(journey: PatientJourney): Promise<TriggerResult[]> {
    return this.processJourneyEvent({
      type: 'journey_completed',
      journey,
    });
  }
}

export const JourneyCommunicationTrigger = new JourneyCommunicationTriggerClass();
