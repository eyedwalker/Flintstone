import { RoomWorkflowService } from './room-workflow-service';

export interface CheckoutEvent {
  type: 'room-transition' | 'step-completion' | 'manual-trigger';
  patientId: string;
  journeyId: string;
  patientName: string;
  triggeredBy: string;
  timestamp: Date;
  metadata?: Record<string, any>;
}

export class CheckoutDetectionService {
  private static instance: CheckoutDetectionService;
  private checkoutCallbacks: Array<(event: CheckoutEvent) => void> = [];

  static getInstance(): CheckoutDetectionService {
    if (!CheckoutDetectionService.instance) {
      CheckoutDetectionService.instance = new CheckoutDetectionService();
    }
    return CheckoutDetectionService.instance;
  }

  // Register callback for checkout events
  onCheckoutDetected(callback: (event: CheckoutEvent) => void): void {
    this.checkoutCallbacks.push(callback);
  }

  // Remove callback
  removeCheckoutCallback(callback: (event: CheckoutEvent) => void): void {
    this.checkoutCallbacks = this.checkoutCallbacks.filter(cb => cb !== callback);
  }

  // Emit checkout event to all listeners
  private emitCheckoutEvent(event: CheckoutEvent): void {
    console.log('Checkout detected:', event);
    this.checkoutCallbacks.forEach(callback => {
      try {
        callback(event);
      } catch (error) {
        console.error('Error in checkout callback:', error);
      }
    });
  }

  // Check if patient should proceed to checkout based on room workflow
  checkRoomBasedCheckout(
    currentRoomType: string, 
    patient: any, 
    rooms: any[]
  ): boolean {
    return RoomWorkflowService.shouldMoveToPostVisit(currentRoomType as any, patient);
  }

  // Check if step completion should trigger checkout
  checkStepBasedCheckout(step: any, journey: any): boolean {
    if (!step || !journey) return false;

    // Check for checkout-related step titles
    const checkoutKeywords = [
      'checkout', 'check-out', 'check out',
      'payment', 'billing', 'scheduling',
      'discharge', 'exit', 'complete'
    ];

    const stepTitle = step.title?.toLowerCase() || '';
    const isCheckoutStep = checkoutKeywords.some(keyword => 
      stepTitle.includes(keyword)
    );

    // Check if this is the final step in the journey
    const allSteps = journey.steps || [];
    const completedSteps = allSteps.filter((s: any) => s.status === 'completed').length;
    const totalSteps = allSteps.length;
    const isFinalStep = completedSteps >= totalSteps - 1;

    return isCheckoutStep || isFinalStep;
  }

  // Trigger checkout from room transition (Next Step button)
  triggerRoomCheckout(
    patient: any,
    currentRoomType: string,
    triggeredBy: string = 'room-workflow'
  ): void {
    if (this.checkRoomBasedCheckout(currentRoomType, patient, [])) {
      const event: CheckoutEvent = {
        type: 'room-transition',
        patientId: patient.id,
        journeyId: patient.id,
        patientName: patient.patientName || patient.name,
        triggeredBy,
        timestamp: new Date(),
        metadata: {
          roomType: currentRoomType,
          source: 'next-step-button'
        }
      };

      this.emitCheckoutEvent(event);
    }
  }

  // Trigger checkout from step completion
  triggerStepCheckout(
    step: any,
    journey: any,
    triggeredBy: string = 'step-completion'
  ): void {
    if (this.checkStepBasedCheckout(step, journey)) {
      const event: CheckoutEvent = {
        type: 'step-completion',
        patientId: journey.patientId || journey.id,
        journeyId: journey.id,
        patientName: journey.patientName || journey.name,
        triggeredBy,
        timestamp: new Date(),
        metadata: {
          stepId: step.id,
          stepTitle: step.title,
          source: 'manage-step'
        }
      };

      this.emitCheckoutEvent(event);
    }
  }

  // Manual checkout trigger (from UI)
  triggerManualCheckout(
    patient: any,
    triggeredBy: string = 'manual'
  ): void {
    const event: CheckoutEvent = {
      type: 'manual-trigger',
      patientId: patient.id,
      journeyId: patient.id,
      patientName: patient.patientName || patient.name,
      triggeredBy,
      timestamp: new Date(),
      metadata: {
        source: 'manual-trigger'
      }
    };

    this.emitCheckoutEvent(event);
  }

  // Get checkout detection status for a journey
  getCheckoutStatus(journey: any, currentRoomType?: string): {
    isReadyForCheckout: boolean;
    reason: string;
    source: string;
  } {
    // Check room-based checkout
    if (currentRoomType && this.checkRoomBasedCheckout(currentRoomType, journey, [])) {
      return {
        isReadyForCheckout: true,
        reason: 'Patient completed workflow and ready to move to post-visit',
        source: 'room-workflow'
      };
    }

    // Check step-based checkout
    const currentStep = journey.steps?.find((s: any) => s.id === journey.currentStepId);
    if (currentStep && this.checkStepBasedCheckout(currentStep, journey)) {
      return {
        isReadyForCheckout: true,
        reason: 'Checkout step completed or all steps finished',
        source: 'step-completion'
      };
    }

    // Check for completed checkout steps
    const checkoutSteps = journey.steps?.filter((step: any) => {
      const title = step.title?.toLowerCase() || '';
      return title.includes('checkout') && step.status === 'completed';
    }) || [];

    if (checkoutSteps.length > 0) {
      return {
        isReadyForCheckout: true,
        reason: 'Checkout step has been completed',
        source: 'completed-step'
      };
    }

    return {
      isReadyForCheckout: false,
      reason: 'Patient has not completed checkout requirements',
      source: 'none'
    };
  }
}

// Export singleton instance
export const checkoutDetection = CheckoutDetectionService.getInstance();
