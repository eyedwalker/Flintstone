/**
 * Form Customization Service
 * Allows offices/companies to customize form templates with their own branding,
 * field modifications, and custom sections
 */

import { FormTemplate, FormField, FormSection } from '../types/forms';

export interface OfficeCustomization {
  officeId: string;
  officeName: string;
  branding: {
    logoUrl?: string;
    primaryColor?: string;
    secondaryColor?: string;
    headerText?: string;
    footerText?: string;
  };
  formOverrides: Record<string, FormTemplateOverride>;
  createdAt: Date;
  updatedAt: Date;
}

export interface FormTemplateOverride {
  templateId: string;
  enabled: boolean;
  customTitle?: string;
  customDescription?: string;
  hiddenFields: string[];
  requiredFields: string[];
  optionalFields: string[];
  customFields: FormField[];
  customSections: FormSection[];
  fieldLabels: Record<string, string>;
  fieldPlaceholders: Record<string, string>;
  fieldDefaults: Record<string, any>;
  sectionOrder: string[];
}

const STORAGE_KEY = 'eyecare_form_customizations';

export class FormCustomizationService {
  private static instance: FormCustomizationService;

  private constructor() {}

  static getInstance(): FormCustomizationService {
    if (!FormCustomizationService.instance) {
      FormCustomizationService.instance = new FormCustomizationService();
    }
    return FormCustomizationService.instance;
  }

  // Get all customizations
  getAllCustomizations(): OfficeCustomization[] {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  // Save all customizations
  private saveCustomizations(customizations: OfficeCustomization[]): void {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(customizations));
  }

  // Get customization for a specific office
  getOfficeCustomization(officeId: string): OfficeCustomization | null {
    const all = this.getAllCustomizations();
    return all.find(c => c.officeId === officeId) || null;
  }

  // Create or update office customization
  saveOfficeCustomization(customization: OfficeCustomization): OfficeCustomization {
    const all = this.getAllCustomizations();
    const existingIndex = all.findIndex(c => c.officeId === customization.officeId);
    
    customization.updatedAt = new Date();
    
    if (existingIndex >= 0) {
      all[existingIndex] = customization;
    } else {
      customization.createdAt = new Date();
      all.push(customization);
    }
    
    this.saveCustomizations(all);
    return customization;
  }

  // Delete office customization
  deleteOfficeCustomization(officeId: string): boolean {
    const all = this.getAllCustomizations();
    const filtered = all.filter(c => c.officeId !== officeId);
    if (filtered.length !== all.length) {
      this.saveCustomizations(filtered);
      return true;
    }
    return false;
  }

  // Get form override for a specific template
  getFormOverride(officeId: string, templateId: string): FormTemplateOverride | null {
    const customization = this.getOfficeCustomization(officeId);
    return customization?.formOverrides?.[templateId] || null;
  }

  // Save form override
  saveFormOverride(officeId: string, override: FormTemplateOverride): void {
    let customization = this.getOfficeCustomization(officeId);
    
    if (!customization) {
      customization = {
        officeId,
        officeName: `Office ${officeId}`,
        branding: {},
        formOverrides: {},
        createdAt: new Date(),
        updatedAt: new Date(),
      };
    }
    
    customization.formOverrides[override.templateId] = override;
    this.saveOfficeCustomization(customization);
  }

  // Apply customizations to a base template
  applyCustomizations(baseTemplate: FormTemplate, officeId: string): FormTemplate {
    const override = this.getFormOverride(officeId, baseTemplate.id);
    const branding = this.getOfficeCustomization(officeId)?.branding;
    
    if (!override && !branding) {
      return baseTemplate;
    }

    // Deep clone the template
    const customized: FormTemplate = JSON.parse(JSON.stringify(baseTemplate));

    // Apply branding
    if (branding) {
      customized.branding = branding;
    }

    if (!override) {
      return customized;
    }

    // Apply title/description overrides
    if (override.customTitle) {
      customized.title = override.customTitle;
    }
    if (override.customDescription) {
      customized.description = override.customDescription;
    }

    // Process sections
    customized.sections = customized.sections.map(section => {
      // Filter out hidden fields
      section.fields = section.fields.filter(
        field => !override.hiddenFields.includes(field.id)
      );

      // Apply field modifications
      section.fields = section.fields.map(field => {
        // Override required status
        if (override.requiredFields.includes(field.id)) {
          field.required = true;
        }
        if (override.optionalFields.includes(field.id)) {
          field.required = false;
        }

        // Override labels
        if (override.fieldLabels[field.id]) {
          field.label = override.fieldLabels[field.id];
        }

        // Override placeholders
        if (override.fieldPlaceholders[field.id]) {
          field.placeholder = override.fieldPlaceholders[field.id];
        }

        // Apply default values
        if (override.fieldDefaults[field.id] !== undefined) {
          field.defaultValue = override.fieldDefaults[field.id];
        }

        return field;
      });

      return section;
    });

    // Add custom fields to appropriate sections or create new section
    if (override.customFields.length > 0) {
      const customFieldsSection: FormSection = {
        id: 'custom-fields',
        title: 'Additional Information',
        description: 'Office-specific questions',
        fields: override.customFields,
      };
      customized.sections.push(customFieldsSection);
    }

    // Add custom sections
    if (override.customSections.length > 0) {
      customized.sections.push(...override.customSections);
    }

    // Reorder sections if specified
    if (override.sectionOrder.length > 0) {
      const orderedSections: FormSection[] = [];
      override.sectionOrder.forEach(sectionId => {
        const section = customized.sections.find(s => s.id === sectionId);
        if (section) {
          orderedSections.push(section);
        }
      });
      // Add any remaining sections not in the order
      customized.sections.forEach(section => {
        if (!orderedSections.find(s => s.id === section.id)) {
          orderedSections.push(section);
        }
      });
      customized.sections = orderedSections;
    }

    return customized;
  }

  // Create a blank override for a template
  createBlankOverride(templateId: string): FormTemplateOverride {
    return {
      templateId,
      enabled: true,
      hiddenFields: [],
      requiredFields: [],
      optionalFields: [],
      customFields: [],
      customSections: [],
      fieldLabels: {},
      fieldPlaceholders: {},
      fieldDefaults: {},
      sectionOrder: [],
    };
  }

  // Export customization as JSON
  exportCustomization(officeId: string): string {
    const customization = this.getOfficeCustomization(officeId);
    return JSON.stringify(customization, null, 2);
  }

  // Import customization from JSON
  importCustomization(jsonString: string): OfficeCustomization {
    const customization = JSON.parse(jsonString) as OfficeCustomization;
    return this.saveOfficeCustomization(customization);
  }
}

export default FormCustomizationService.getInstance();
