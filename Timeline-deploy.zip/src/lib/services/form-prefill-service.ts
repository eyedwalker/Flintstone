/**
 * Form Prefill Service
 * Automatically prefills form fields with patient data
 * Supports auto-accept for acknowledgements and signature placeholders
 */

export interface PatientData {
  // Basic Info
  patientId?: string;
  firstName?: string;
  lastName?: string;
  middleName?: string;
  preferredName?: string;
  fullName?: string;
  dateOfBirth?: string;
  gender?: string;
  ssn?: string;
  
  // Contact Info
  address?: string;
  address2?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  homePhone?: string;
  mobilePhone?: string;
  workPhone?: string;
  email?: string;
  preferredContact?: string;
  
  // Emergency Contact
  emergencyName?: string;
  emergencyRelationship?: string;
  emergencyPhone?: string;
  
  // Insurance
  visionInsuranceCarrier?: string;
  visionMemberId?: string;
  visionGroupNumber?: string;
  medicalInsuranceCarrier?: string;
  medicalMemberId?: string;
  medicalGroupNumber?: string;
  
  // Appointment Info
  appointmentDate?: string;
  appointmentTime?: string;
  appointmentType?: string;
  providerName?: string;
  examDate?: string;
  
  // Additional
  occupation?: string;
  employerName?: string;
  primaryPhysician?: string;
  physicianPhone?: string;
}

export interface PrefillOptions {
  enabled: boolean;
  autoAcceptAcknowledgements: boolean;
  autoSignWithName: boolean;
  signatureText?: string;
  prefillDate: boolean;
}

// Default prefill options - prefill is ON by default
export const defaultPrefillOptions: PrefillOptions = {
  enabled: true,
  autoAcceptAcknowledgements: true,
  autoSignWithName: true,
  prefillDate: true,
};

// Field ID to patient data property mapping
const fieldMappings: Record<string, keyof PatientData> = {
  // Name fields
  'firstName': 'firstName',
  'lastName': 'lastName',
  'middleName': 'middleName',
  'preferredName': 'preferredName',
  'patientName': 'fullName',
  'childName': 'fullName',
  'responsiblePartyName': 'fullName',
  
  // Date fields
  'dateOfBirth': 'dateOfBirth',
  'patientDOB': 'dateOfBirth',
  'childDOB': 'dateOfBirth',
  'examDate': 'examDate',
  'appointmentDate': 'appointmentDate',
  'visitDate': 'appointmentDate',
  
  // Contact fields
  'address': 'address',
  'address2': 'address2',
  'city': 'city',
  'state': 'state',
  'zipCode': 'zipCode',
  'homePhone': 'homePhone',
  'mobilePhone': 'mobilePhone',
  'workPhone': 'workPhone',
  'phoneNumber': 'mobilePhone',
  'patientPhone': 'mobilePhone',
  'email': 'email',
  'preferredContact': 'preferredContact',
  
  // Emergency contact
  'emergencyName': 'emergencyName',
  'emergencyRelationship': 'emergencyRelationship',
  'emergencyPhone': 'emergencyPhone',
  
  // Insurance fields
  'visionInsuranceCarrier': 'visionInsuranceCarrier',
  'visionMemberId': 'visionMemberId',
  'visionGroupNumber': 'visionGroupNumber',
  'medicalInsuranceCarrier': 'medicalInsuranceCarrier',
  'medicalMemberId': 'medicalMemberId',
  'medicalGroupNumber': 'medicalGroupNumber',
  'insuranceId': 'visionMemberId',
  
  // Appointment fields
  'appointmentTime': 'appointmentTime',
  'appointmentType': 'appointmentType',
  'providerName': 'providerName',
  
  // Employment
  'occupation': 'occupation',
  'employerName': 'employerName',
  
  // Medical
  'primaryPhysician': 'primaryPhysician',
  'physicianPhone': 'physicianPhone',
};

// Fields that are acknowledgement checkboxes
const acknowledgementFields = [
  'acknowledgeReceipt',
  'understandRights',
  'acknowledgeHipaa',
  'agreeToPolicy',
  'authorizeInsurance',
  'authorizePayment',
  'authorizeRelease',
  'understandResponsibility',
  'understandEffects',
  'consentToDilation',
  'understandFee',
  'agreeToFollowUp',
  'agreeToCareProperly',
  'understandRisks',
  'understandNonRefundable',
  'agreeToDeposit',
  'releaseFromLiability',
  'verifiedOrder',
  'understandPolicies',
  'consentToTreatment',
  'understandAtropine',
  'receivedRx',
];

// Fields that are signature fields
const signatureFields = [
  'signature',
  'patientSignature',
  'parentSignature',
  'responsiblePartySignature',
  'guardianSignature',
];

// Fields that should be auto-filled with today's date
const autoDateFields = [
  'signatureDate',
  'agreementDate',
  'orderDate',
  'serviceDate',
];

class FormPrefillService {
  private static instance: FormPrefillService;

  private constructor() {}

  static getInstance(): FormPrefillService {
    if (!FormPrefillService.instance) {
      FormPrefillService.instance = new FormPrefillService();
    }
    return FormPrefillService.instance;
  }

  /**
   * Generate prefilled responses for a form based on patient data
   */
  generatePrefillData(
    patientData: PatientData,
    options: PrefillOptions = defaultPrefillOptions
  ): Record<string, any> {
    if (!options.enabled) {
      return {};
    }

    const prefilled: Record<string, any> = {};

    // Build full name if not provided
    if (!patientData.fullName && (patientData.firstName || patientData.lastName)) {
      patientData.fullName = [patientData.firstName, patientData.lastName]
        .filter(Boolean)
        .join(' ');
    }

    // Map patient data to field IDs
    for (const [fieldId, dataKey] of Object.entries(fieldMappings)) {
      const value = patientData[dataKey];
      if (value !== undefined && value !== null && value !== '') {
        prefilled[fieldId] = value;
      }
    }

    // Auto-accept acknowledgements
    if (options.autoAcceptAcknowledgements) {
      for (const fieldId of acknowledgementFields) {
        prefilled[fieldId] = [fieldId.replace('acknowledge', 'acknowledged')
          .replace('understand', 'understood')
          .replace('agree', 'agreed')
          .replace('authorize', 'authorized')
          .replace('consent', 'consented')
          .replace('verify', 'verified')
          .replace('receive', 'received')
          .replace('release', 'released')];
      }
    }

    // Auto-sign with patient name
    if (options.autoSignWithName && patientData.fullName) {
      const signatureValue = options.signatureText || `Electronically signed by ${patientData.fullName}`;
      for (const fieldId of signatureFields) {
        prefilled[fieldId] = signatureValue;
      }
    }

    // Auto-fill date fields with today's date
    if (options.prefillDate) {
      const today = new Date().toISOString().split('T')[0];
      for (const fieldId of autoDateFields) {
        prefilled[fieldId] = today;
      }
      // Also set examDate to today if not provided
      if (!prefilled['examDate']) {
        prefilled['examDate'] = today;
      }
    }

    return prefilled;
  }

  /**
   * Extract patient data from an existing patient record
   */
  extractPatientData(patient: any): PatientData {
    return {
      patientId: patient.id || patient.patientId,
      firstName: patient.firstName || patient.first_name,
      lastName: patient.lastName || patient.last_name,
      middleName: patient.middleName || patient.middle_name,
      preferredName: patient.preferredName || patient.preferred_name,
      fullName: patient.fullName || patient.name || 
        [patient.firstName || patient.first_name, patient.lastName || patient.last_name]
          .filter(Boolean).join(' '),
      dateOfBirth: patient.dateOfBirth || patient.dob || patient.date_of_birth,
      gender: patient.gender || patient.sex,
      
      address: patient.address || patient.street,
      address2: patient.address2 || patient.unit,
      city: patient.city,
      state: patient.state,
      zipCode: patient.zipCode || patient.zip || patient.postalCode,
      homePhone: patient.homePhone || patient.home_phone,
      mobilePhone: patient.mobilePhone || patient.mobile_phone || patient.phone || patient.cellPhone,
      workPhone: patient.workPhone || patient.work_phone,
      email: patient.email || patient.emailAddress,
      
      emergencyName: patient.emergencyContact?.name || patient.emergency_contact_name,
      emergencyRelationship: patient.emergencyContact?.relationship || patient.emergency_contact_relationship,
      emergencyPhone: patient.emergencyContact?.phone || patient.emergency_contact_phone,
      
      visionInsuranceCarrier: patient.visionInsurance?.carrier || patient.vision_insurance_carrier,
      visionMemberId: patient.visionInsurance?.memberId || patient.vision_member_id,
      visionGroupNumber: patient.visionInsurance?.groupNumber || patient.vision_group_number,
      medicalInsuranceCarrier: patient.medicalInsurance?.carrier || patient.medical_insurance_carrier,
      medicalMemberId: patient.medicalInsurance?.memberId || patient.medical_member_id,
      medicalGroupNumber: patient.medicalInsurance?.groupNumber || patient.medical_group_number,
      
      occupation: patient.occupation,
      employerName: patient.employer || patient.employerName,
      primaryPhysician: patient.primaryPhysician || patient.pcp,
      physicianPhone: patient.physicianPhone || patient.pcp_phone,
    };
  }

  /**
   * Merge prefilled data with any existing responses
   */
  mergeWithExisting(
    prefilled: Record<string, any>,
    existing: Record<string, any>
  ): Record<string, any> {
    // Existing responses take precedence over prefilled
    return { ...prefilled, ...existing };
  }

  /**
   * Check if a field should be prefilled
   */
  isPrefilledField(fieldId: string): boolean {
    return fieldId in fieldMappings || 
           acknowledgementFields.includes(fieldId) ||
           signatureFields.includes(fieldId) ||
           autoDateFields.includes(fieldId);
  }

  /**
   * Get the list of fields that will be auto-accepted
   */
  getAutoAcceptFields(): string[] {
    return [...acknowledgementFields];
  }

  /**
   * Get the list of signature fields
   */
  getSignatureFields(): string[] {
    return [...signatureFields];
  }
}

export default FormPrefillService.getInstance();
