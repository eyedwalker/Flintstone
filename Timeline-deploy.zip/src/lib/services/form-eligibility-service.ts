/**
 * Form Eligibility Service
 * Determines which forms a patient needs based on configured rules
 */

import {
  FormRule,
  FormCondition,
  FormRequirement,
  FormEligibilityContext,
  PatientFormStatus,
  DEFAULT_FORM_RULES,
  FormTrigger,
} from '../types/form-rules';

const STORAGE_KEY = 'timeline_form_rules';
const COMPLETION_STORAGE_KEY = 'timeline_form_completions';

export class FormEligibilityService {
  // Get all configured form rules
  static getRules(): FormRule[] {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
    
    // Initialize with default rules
    const rules = DEFAULT_FORM_RULES.map((rule, index) => ({
      ...rule,
      id: `rule_${index + 1}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    }));
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rules));
    return rules;
  }

  // Save rules
  static saveRules(rules: FormRule[]): void {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rules));
  }

  // Add a new rule
  static addRule(rule: Omit<FormRule, 'id' | 'createdAt' | 'updatedAt'>): FormRule {
    const rules = this.getRules();
    const newRule: FormRule = {
      ...rule,
      id: `rule_${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    rules.push(newRule);
    this.saveRules(rules);
    return newRule;
  }

  // Update a rule
  static updateRule(ruleId: string, updates: Partial<FormRule>): FormRule | null {
    const rules = this.getRules();
    const index = rules.findIndex(r => r.id === ruleId);
    if (index === -1) return null;
    
    rules[index] = {
      ...rules[index],
      ...updates,
      updatedAt: new Date(),
    };
    this.saveRules(rules);
    return rules[index];
  }

  // Delete a rule
  static deleteRule(ruleId: string): boolean {
    const rules = this.getRules();
    const filtered = rules.filter(r => r.id !== ruleId);
    if (filtered.length === rules.length) return false;
    this.saveRules(filtered);
    return true;
  }

  // Get patient form completion history
  static getPatientFormHistory(patientId: string): PatientFormStatus[] {
    const stored = localStorage.getItem(COMPLETION_STORAGE_KEY);
    const all: PatientFormStatus[] = stored ? JSON.parse(stored) : [];
    return all.filter(s => s.patientId === patientId);
  }

  // Record form completion
  static recordFormCompletion(patientId: string, templateId: string, submissionId?: string): void {
    const stored = localStorage.getItem(COMPLETION_STORAGE_KEY);
    const all: PatientFormStatus[] = stored ? JSON.parse(stored) : [];
    
    const existing = all.find(s => s.patientId === patientId && s.templateId === templateId);
    if (existing) {
      existing.lastCompletedAt = new Date();
      existing.completionCount = (existing.completionCount || 0) + 1;
      existing.pendingSubmissionId = undefined;
    } else {
      all.push({
        patientId,
        templateId,
        lastCompletedAt: new Date(),
        completionCount: 1,
      });
    }
    
    localStorage.setItem(COMPLETION_STORAGE_KEY, JSON.stringify(all));
  }

  // Record form sent (pending)
  static recordFormSent(patientId: string, templateId: string, submissionId: string): void {
    const stored = localStorage.getItem(COMPLETION_STORAGE_KEY);
    const all: PatientFormStatus[] = stored ? JSON.parse(stored) : [];
    
    const existing = all.find(s => s.patientId === patientId && s.templateId === templateId);
    if (existing) {
      existing.lastSentAt = new Date();
      existing.pendingSubmissionId = submissionId;
    } else {
      all.push({
        patientId,
        templateId,
        lastSentAt: new Date(),
        completionCount: 0,
        pendingSubmissionId: submissionId,
      });
    }
    
    localStorage.setItem(COMPLETION_STORAGE_KEY, JSON.stringify(all));
  }

  // Evaluate a single condition
  static evaluateCondition(condition: FormCondition, context: FormEligibilityContext): boolean {
    const { type, operator, value } = condition;
    
    let actualValue: any;
    
    switch (type) {
      case 'appointment-type':
        actualValue = context.appointmentType?.toLowerCase().replace(/\s+/g, '-');
        break;
      case 'patient-type':
        actualValue = context.isNewPatient ? 'new' : 'existing';
        break;
      case 'insurance-type':
        actualValue = context.insuranceType?.toLowerCase();
        break;
      case 'age-range':
        if (!context.dateOfBirth) return false;
        const age = Math.floor((Date.now() - new Date(context.dateOfBirth).getTime()) / (365.25 * 24 * 60 * 60 * 1000));
        actualValue = age;
        break;
      case 'has-insurance':
        actualValue = context.hasInsurance ? 'true' : 'false';
        break;
      case 'provider':
        actualValue = context.providerId;
        break;
      case 'office':
        actualValue = context.officeId;
        break;
      default:
        return false;
    }
    
    // Compare based on operator
    switch (operator) {
      case 'equals':
        return String(actualValue).toLowerCase() === String(value).toLowerCase();
      case 'not-equals':
        return String(actualValue).toLowerCase() !== String(value).toLowerCase();
      case 'contains':
        return String(actualValue).toLowerCase().includes(String(value).toLowerCase());
      case 'not-contains':
        return !String(actualValue).toLowerCase().includes(String(value).toLowerCase());
      case 'greater-than':
        return Number(actualValue) > Number(value);
      case 'less-than':
        return Number(actualValue) < Number(value);
      case 'in-list':
        const list = Array.isArray(value) ? value : [value];
        return list.some(v => String(actualValue).toLowerCase() === String(v).toLowerCase());
      case 'not-in-list':
        const excludeList = Array.isArray(value) ? value : [value];
        return !excludeList.some(v => String(actualValue).toLowerCase() === String(v).toLowerCase());
      default:
        return false;
    }
  }

  // Check if form was completed within required timeframe
  static isFormCurrentForFrequency(
    status: PatientFormStatus | undefined,
    frequency: string,
    appointmentDate?: Date
  ): boolean {
    if (!status?.lastCompletedAt) return false;
    
    const lastCompleted = new Date(status.lastCompletedAt);
    const now = appointmentDate ? new Date(appointmentDate) : new Date();
    const daysSinceCompletion = Math.floor((now.getTime() - lastCompleted.getTime()) / (24 * 60 * 60 * 1000));
    
    switch (frequency) {
      case 'once':
        return true; // If completed once, always current
      case 'annual':
        return daysSinceCompletion < 365;
      case 'per-visit':
        return false; // Always needed per visit
      case 'on-change':
        return daysSinceCompletion < 365; // Treat as annual unless change detected
      default:
        return false;
    }
  }

  // Get required forms for a patient/appointment context
  static getRequiredForms(
    context: FormEligibilityContext,
    trigger?: FormTrigger
  ): FormRequirement[] {
    const rules = this.getRules().filter(r => r.isActive);
    const patientHistory = this.getPatientFormHistory(context.patientId);
    const requirements: FormRequirement[] = [];
    
    // Import form templates to get titles
    const { FormSubmissionService } = require('./form-submission-service');
    const templates = FormSubmissionService.getTemplates();
    
    for (const rule of rules) {
      // Skip if trigger doesn't match (when specified)
      if (trigger && rule.trigger !== trigger) continue;
      
      // Skip "no forms needed" rules
      if (rule.templateId === 'none') continue;
      
      // Check all conditions (AND logic)
      const conditionsMet = rule.conditions.length === 0 || 
        rule.conditions.every(c => this.evaluateCondition(c, context));
      
      if (!conditionsMet) continue;
      
      // Check exclusions (if any true, skip this form)
      if (rule.exclusions?.some(c => this.evaluateCondition(c, context))) continue;
      
      // Check if form is already current based on frequency
      const status = patientHistory.find(h => h.templateId === rule.templateId);
      if (this.isFormCurrentForFrequency(status, rule.frequency, context.appointmentDate)) {
        continue;
      }
      
      // Check if form is already pending
      if (status?.pendingSubmissionId) {
        // Still add but mark as pending
      }
      
      // Get template info
      const template = templates.find((t: any) => t.id === rule.templateId);
      
      // Calculate due date
      let dueDate: Date | undefined;
      if (context.appointmentDate && rule.timing?.daysBeforeAppointment) {
        dueDate = new Date(context.appointmentDate);
        dueDate.setDate(dueDate.getDate() - rule.timing.daysBeforeAppointment);
      }
      
      const isOverdue = dueDate ? new Date() > dueDate : false;
      
      requirements.push({
        templateId: rule.templateId,
        templateTitle: template?.title || rule.name,
        ruleId: rule.id,
        ruleName: rule.name,
        reason: rule.description || rule.name,
        priority: rule.priority,
        trigger: rule.trigger,
        dueDate,
        isOverdue,
        lastCompleted: status?.lastCompletedAt ? new Date(status.lastCompletedAt) : undefined,
        status: rule.priority >= 80 ? 'required' : rule.priority >= 50 ? 'recommended' : 'optional',
      });
    }
    
    // Sort by priority (highest first)
    return requirements.sort((a, b) => b.priority - a.priority);
  }

  // Get all forms needed for pre-visit
  static getPreVisitForms(context: FormEligibilityContext): FormRequirement[] {
    return this.getRequiredForms(context, 'pre-visit');
  }

  // Get all forms needed for check-in
  static getCheckInForms(context: FormEligibilityContext): FormRequirement[] {
    return this.getRequiredForms(context, 'check-in');
  }

  // Get all forms needed for post-visit
  static getPostVisitForms(context: FormEligibilityContext): FormRequirement[] {
    return this.getRequiredForms(context, 'post-visit');
  }

  // Get summary of form status for a patient
  static getPatientFormSummary(context: FormEligibilityContext): {
    totalRequired: number;
    completed: number;
    pending: number;
    overdue: number;
    requirements: FormRequirement[];
  } {
    const requirements = this.getRequiredForms(context);
    const patientHistory = this.getPatientFormHistory(context.patientId);
    
    let completed = 0;
    let pending = 0;
    let overdue = 0;
    
    for (const req of requirements) {
      const status = patientHistory.find(h => h.templateId === req.templateId);
      if (status?.lastCompletedAt && this.isFormCurrentForFrequency(status, 'annual', context.appointmentDate)) {
        completed++;
      } else if (status?.pendingSubmissionId) {
        pending++;
      } else if (req.isOverdue) {
        overdue++;
      }
    }
    
    return {
      totalRequired: requirements.length,
      completed,
      pending,
      overdue,
      requirements,
    };
  }

  // Check if patient has all required forms completed
  static isPatientFormComplete(context: FormEligibilityContext): boolean {
    const summary = this.getPatientFormSummary(context);
    const requiredForms = summary.requirements.filter(r => r.status === 'required');
    return requiredForms.length === 0 || summary.completed >= requiredForms.length;
  }

  // Get forms that need reminders
  static getFormsNeedingReminders(): Array<{
    patientId: string;
    templateId: string;
    submissionId: string;
    daysSinceSent: number;
  }> {
    const stored = localStorage.getItem(COMPLETION_STORAGE_KEY);
    const all: PatientFormStatus[] = stored ? JSON.parse(stored) : [];
    
    const needsReminder: Array<{
      patientId: string;
      templateId: string;
      submissionId: string;
      daysSinceSent: number;
    }> = [];
    
    for (const status of all) {
      if (status.pendingSubmissionId && status.lastSentAt && !status.lastCompletedAt) {
        const daysSinceSent = Math.floor(
          (Date.now() - new Date(status.lastSentAt).getTime()) / (24 * 60 * 60 * 1000)
        );
        
        // Reminder at 3 days and 6 days
        if (daysSinceSent >= 3) {
          needsReminder.push({
            patientId: status.patientId,
            templateId: status.templateId,
            submissionId: status.pendingSubmissionId,
            daysSinceSent,
          });
        }
      }
    }
    
    return needsReminder;
  }
}

export default FormEligibilityService;
