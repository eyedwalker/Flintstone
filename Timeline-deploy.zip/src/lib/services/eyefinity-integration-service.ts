/**
 * Eyefinity Integration Service
 * Handles OAuth authentication and data sync with Eyefinity API
 */

import { companyAccessor } from '../accessors/CompanyAccessor';
import { officeAccessor } from '../accessors/OfficeAccessor';
import { staffAccessor } from '../accessors/StaffAccessor';

const EYEFINITY_BASE_URL = 'https://api-integration.eyefinity.com';
const OAUTH_HOST = 'https://login-uswest2.integration.eyefinity.com';

interface EyefinityOAuthResponse {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  token_type: string;
}

interface EyefinityProvider {
  ProviderId: string;
  ProviderLegacyId: number;
  FirstName: string;
  LastName: string;
  Credentials?: string;
  IsActive: boolean;
  CompanyLegacyId?: string;
  CompanyId?: string;
  EmployeeNum?: string;
}

interface EyefinityStaff {
  StaffId: string;
  StaffLegacyId: number;
  FirstName: string;
  LastName: string;
  Credentials?: string;
  IsActive: boolean;
  CompanyLegacyId?: string;
  CompanyId?: string;
  EmployeeNum?: string;
}

interface EyefinityOffice {
  OfficeNumber: string;
  Address1?: string;
  Address2?: string;
  City?: string;
  State?: string;
  ZipCode?: string;
  CompanyLegacyId?: string;
  Phone?: string;
  TimeZone?: string;
}

export class EyefinityIntegrationService {
  /**
   * Authenticate with Eyefinity OAuth (via backend API to avoid CORS)
   */
  static async authenticate(
    clientId: string,
    clientSecret: string,
    companyKey: string,
    oauthHost?: string
  ): Promise<EyefinityOAuthResponse> {
    try {
      // Call our backend API instead of Eyefinity directly to avoid CORS
      const response = await fetch('/api/eyefinity-auth', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          client_id: clientId,
          client_secret: clientSecret,
          grant_type: 'client_credentials',
          oauth_host: oauthHost || OAUTH_HOST,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`OAuth failed: ${errorData.error} - ${errorData.details || ''}`);
      }

      return await response.json();
    } catch (error: any) {
      throw new Error(`Eyefinity authentication failed: ${error.message}`);
    }
  }

  /**
   * Refresh OAuth token (via backend API to avoid CORS)
   */
  static async refreshToken(
    clientId: string,
    clientSecret: string,
    refreshToken: string,
    oauthHost?: string
  ): Promise<EyefinityOAuthResponse> {
    try {
      // Call our backend API instead of Eyefinity directly to avoid CORS
      const response = await fetch('/api/eyefinity-auth', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          client_id: clientId,
          client_secret: clientSecret,
          grant_type: 'refresh_token',
          refresh_token: refreshToken,
          oauth_host: oauthHost || OAUTH_HOST,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Token refresh failed: ${errorData.error} - ${errorData.details || ''}`);
      }

      return await response.json();
    } catch (error: any) {
      throw new Error(`Token refresh failed: ${error.message}`);
    }
  }

  /**
   * Get valid access token for a company (auto-refreshes if needed)
   */
  static async getValidToken(companyId: string): Promise<string> {
    const companyResult = await companyAccessor.getById(companyId);
    
    if (!companyResult.success || !companyResult.data) {
      throw new Error('Company not found');
    }

    const company = companyResult.data;

    if (!company.oauth_token) {
      throw new Error('No access token configured. Please set up Eyefinity authentication.');
    }

    // If there's no refresh token, this is a static token - just return it
    if (!company.oauth_refresh_token) {
      return company.oauth_token;
    }

    // OAuth flow: Check if token is expired
    const isExpired = !company.oauth_token_expires_at || 
      new Date(company.oauth_token_expires_at) <= new Date();

    if (isExpired) {
      // Refresh the token
      const tokenData = await this.refreshToken(
        company.eyefinity_api_key || '',
        company.eyefinity_api_secret || '',
        company.oauth_refresh_token,
        company.oauth_host
      );

      // Update company with new tokens
      await companyAccessor.update(companyId, {
        oauth_token: tokenData.access_token,
        oauth_refresh_token: tokenData.refresh_token,
        oauth_token_expires_at: new Date(
          Date.now() + tokenData.expires_in * 1000
        ).toISOString()
      });

      return tokenData.access_token;
    }

    return company.oauth_token;
  }

  /**
   * Import providers from Eyefinity (via existing proxy)
   */
  static async importProviders(companyId: string, officeId?: string): Promise<{
    imported: number;
    errors: string[];
  }> {
    try {
      const companyResult = await companyAccessor.getById(companyId);
      
      if (!companyResult.success) {
        throw new Error('Company not found');
      }

      const company = companyResult.data;
      
      if (!company) {
        throw new Error('Company data not available');
      }
      
      // Use existing Eyefinity proxy (handles OAuth, token caching, etc)
      // Eyefinity uses flat endpoint structure: v2providers
      const path = `v2providers?page=1&pageSize=100`;

      const response = await fetch(`/api/eyefinity/${path}`, {
        headers: {
          'Accept': 'application/json',
          'X-Company-Id': companyId, // Pass company ID so proxy can fetch credentials
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch providers: ${response.statusText}`);
      }

      const providers: EyefinityProvider[] = await response.json();
      const errors: string[] = [];
      let imported = 0;

      // Import each provider
      for (const provider of providers) {
        try {
          // Check if provider already exists
          const existingResult = await staffAccessor.getByEyefinityId(provider.ProviderId);
          
          if (existingResult.success) {
            // Update existing provider
            await staffAccessor.update(existingResult.data!.id, {
              name: `${provider.FirstName} ${provider.LastName}`,
              specialty: provider.Credentials,
            });
          } else {
            // Create new provider as staff member
            await staffAccessor.create({
              name: `${provider.FirstName} ${provider.LastName}`,
              role: 'doctor',
              eyefinity_provider_id: provider.ProviderId,
              specialty: provider.Credentials,
              active: provider.IsActive,
              settings: { 
                employeeNum: provider.EmployeeNum,
                legacyId: provider.ProviderLegacyId,
              },
            });
          }
          
          imported++;
        } catch (error: any) {
          errors.push(`Failed to import ${provider.FirstName} ${provider.LastName}: ${error.message}`);
        }
      }

      return { imported, errors };
    } catch (error: any) {
      throw new Error(`Provider import failed: ${error.message}`);
    }
  }

  /**
   * Import staff from Eyefinity
   */
  static async importStaff(companyId: string, officeId?: string): Promise<{
    imported: number;
    errors: string[];
  }> {
    try {
      const companyResult = await companyAccessor.getById(companyId);
      
      if (!companyResult.success) {
        throw new Error('Company not found');
      }

      const company = companyResult.data;
      
      if (!company) {
        throw new Error('Company data not available');
      }
      
      // Use existing Eyefinity proxy
      // Eyefinity uses flat endpoint structure: v2staff
      const path = `v2staff?page=1&pageSize=100`;

      const response = await fetch(`/api/eyefinity/${path}`, {
        headers: {
          'Accept': 'application/json',
          'X-Company-Id': companyId, // Pass company ID so proxy can fetch credentials
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch staff: ${response.statusText}`);
      }

      const staffList: EyefinityStaff[] = await response.json();
      const errors: string[] = [];
      let imported = 0;

      // Import each staff member
      for (const staff of staffList) {
        try {
          // Check if staff already exists
          const existingResult = await staffAccessor.getByEyefinityId(staff.StaffId);
          
          if (existingResult.success) {
            // Update existing staff
            await staffAccessor.update(existingResult.data!.id, {
              name: `${staff.FirstName} ${staff.LastName}`,
              specialty: staff.Credentials,
            });
          } else {
            // Create new staff member
            await staffAccessor.create({
              name: `${staff.FirstName} ${staff.LastName}`,
              role: 'other',
              eyefinity_staff_id: staff.StaffId,
              specialty: staff.Credentials,
              active: staff.IsActive,
              settings: {
                employeeNum: staff.EmployeeNum,
                legacyId: staff.StaffLegacyId,
              },
            });
          }
          
          imported++;
        } catch (error: any) {
          errors.push(`Failed to import ${staff.FirstName} ${staff.LastName}: ${error.message}`);
        }
      }

      return { imported, errors };
    } catch (error: any) {
      throw new Error(`Staff import failed: ${error.message}`);
    }
  }

  /**
   * Import offices from Eyefinity
   */
  static async importOffices(companyId: string): Promise<{
    imported: number;
    errors: string[];
  }> {
    try {
      const companyResult = await companyAccessor.getById(companyId);
      
      if (!companyResult.success) {
        throw new Error('Company not found');
      }

      const company = companyResult.data;
      
      if (!company) {
        throw new Error('Company data not available');
      }
      
      // Use existing Eyefinity proxy with correct endpoint
      // Eyefinity uses flat endpoint structure: v2offices (not v2/companies/{id}/offices)
      const path = `v2offices?page=1&pageSize=100`;
      const response = await fetch(`/api/eyefinity/${path}`, {
        headers: {
          'Accept': 'application/json',
          'X-Company-Id': companyId,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch offices: ${response.statusText}`);
      }

      const offices: EyefinityOffice[] = await response.json();
      const errors: string[] = [];
      let imported = 0;

      // Import each office
      for (const office of offices) {
        try {
          // Build address object from API fields
          const addressObj = {
            street: [office.Address1, office.Address2].filter(Boolean).join(', '),
            city: office.City,
            state: office.State,
            zip: office.ZipCode,
          };
          
          // Office name from OfficeNumber or CompanyLegacyId
          const officeName = office.OfficeNumber || office.CompanyLegacyId || 'Unnamed Office';
          
          // Check if office already exists
          const existingResult = await officeAccessor.getByEyefinityId(office.OfficeNumber);
          
          if (existingResult.success) {
            // Update existing office
            await officeAccessor.update(existingResult.data!.id, {
              name: officeName,
              address: addressObj,
              phone: office.Phone,
              timezone: office.TimeZone || 'America/Chicago',
            });
          } else {
            // Create new office
            await officeAccessor.create({
              company_id: companyId,
              name: officeName,
              eyefinity_location_id: office.OfficeNumber,
              address: addressObj,
              phone: office.Phone,
              timezone: office.TimeZone || 'America/Chicago',
              settings: {},
            });
          }
          
          imported++;
        } catch (error: any) {
          errors.push(`Failed to import ${office.OfficeNumber || 'office'}: ${error.message}`);
        }
      }

      return { imported, errors };
    } catch (error: any) {
      throw new Error(`Office import failed: ${error.message}`);
    }
  }

  /**
   * Full sync: Import all data from Eyefinity
   */
  static async fullSync(companyId: string): Promise<{
    offices: { imported: number; errors: string[] };
    providers: { imported: number; errors: string[] };
    staff: { imported: number; errors: string[] };
  }> {
    const offices = await this.importOffices(companyId);
    const providers = await this.importProviders(companyId);
    const staff = await this.importStaff(companyId);

    return { offices, providers, staff };
  }
}

export default EyefinityIntegrationService;
