/**
 * Product & Service Recommendation Engine
 * 
 * Intelligent rule-based recommendation system for personalized patient recommendations
 */

import {
  RecommendationRule,
  RecommendationContext,
  Recommendation,
  ScoredRecommendation,
  RuleCondition,
  ConditionOperator,
  DisplayLocation
} from '../types/recommendation';
import { MailMergeService } from './mail-merge-service';

export class ProductRecommendationEngine {
  /**
   * Evaluate all active rules against patient context
   */
  static evaluatePatient(
    rules: RecommendationRule[],
    context: RecommendationContext,
    displayLocation?: DisplayLocation
  ): Recommendation[] {
    console.log('[ProductRecommendationEngine] Starting evaluation', {
      totalRules: rules.length,
      displayLocation,
      patientAge: context.patient.age,
      patientId: context.patient.id
    });

    // Filter to enabled rules
    const activeRules = rules.filter(r => r.enabled);
    console.log('[ProductRecommendationEngine] Enabled rules:', activeRules.length);
    
    // Filter by display location if specified
    const relevantRules = displayLocation
      ? activeRules.filter(r => r.displayConfig.locations.includes(displayLocation))
      : activeRules;
    
    console.log('[ProductRecommendationEngine] Relevant rules for location:', relevantRules.length);
    console.log('[ProductRecommendationEngine] Relevant rules:', relevantRules.map(r => r.name));

    // Match rules against context
    const evaluationResults = relevantRules.map(rule => {
      const result = this.evaluateRule(rule, context);
      console.log(`[ProductRecommendationEngine] Rule "${rule.name}" evaluation:`, {
        matches: result.matches,
        hasRecommendation: !!result.recommendation,
        conditions: rule.conditions.length
      });
      return result;
    });

    const matches = evaluationResults.filter(result => result.matches && result.recommendation);
    console.log('[ProductRecommendationEngine] Total matches:', matches.length);

    // Score and prioritize
    const scored = matches.map(match => this.scoreRecommendation(match.recommendation!, match.rule, context));

    // Sort by score (highest first)
    scored.sort((a, b) => b.score - a.score);

    console.log('[ProductRecommendationEngine] Final scored recommendations:', scored.length);

    // Return top recommendations
    return scored.map(s => s.recommendation);
  }

  /**
   * Evaluate a single rule against context
   */
  private static evaluateRule(
    rule: RecommendationRule,
    context: RecommendationContext
  ): { matches: boolean; recommendation?: Recommendation; rule: RecommendationRule } {
    console.log(`[ProductRecommendationEngine] Evaluating rule: "${rule.name}"`);
    console.log(`[ProductRecommendationEngine] Conditions:`, rule.conditions);
    
    let matches = true;
    let lastLogicalOperator: 'AND' | 'OR' | undefined = undefined;

    for (let i = 0; i < rule.conditions.length; i++) {
      const condition = rule.conditions[i];
      const conditionMet = this.evaluateCondition(condition, context);
      
      console.log(`[ProductRecommendationEngine] Condition ${i + 1}:`, {
        field: condition.field,
        operator: condition.operator,
        value: condition.value,
        conditionMet,
        logicalOperator: condition.logicalOperator
      });
      
      if (lastLogicalOperator === 'OR') {
        matches = matches || conditionMet;
      } else {
        matches = matches && conditionMet;
      }
      
      lastLogicalOperator = condition.logicalOperator;
    }
    
    console.log(`[ProductRecommendationEngine] Rule "${rule.name}" final result: ${matches}`);

    if (!matches) {
      return { matches: false, rule };
    }

    // Generate recommendation
    const recommendation = this.generateRecommendation(rule, context);

    return { matches: true, rule, recommendation };
  }

  /**
   * Evaluate all conditions for a rule
   */
  private static evaluateConditions(
    conditions: RuleCondition[],
    context: RecommendationContext
  ): boolean {
    if (conditions.length === 0) return true;

    let result = true;
    let currentOperator: 'AND' | 'OR' = 'AND';

    for (let i = 0; i < conditions.length; i++) {
      const condition = conditions[i];
      const conditionResult = this.evaluateCondition(condition, context);

      if (i === 0) {
        result = conditionResult;
      } else {
        if (currentOperator === 'AND') {
          result = result && conditionResult;
        } else {
          result = result || conditionResult;
        }
      }

      // Set operator for next iteration
      currentOperator = condition.logicalOperator || 'AND';
    }

    return result;
  }

  /**
   * Evaluate a single condition
   */
  private static evaluateCondition(
    condition: RuleCondition,
    context: RecommendationContext
  ): boolean {
    const fieldValue = this.resolveField(condition.field, context);
    const expectedValue = condition.value;

    return this.applyOperator(fieldValue, condition.operator, expectedValue);
  }

  /**
   * Resolve a field path to its value in the context
   */
  private static resolveField(field: string, context: RecommendationContext): any {
    const parts = field.split('.');
    let current: any = context;

    for (const part of parts) {
      if (current === undefined || current === null) {
        return undefined;
      }

      // Handle array indexing
      const arrayMatch = part.match(/^(\w+)\[(\d+)\]$/);
      if (arrayMatch) {
        const [, arrayName, index] = arrayMatch;
        current = current[arrayName];
        if (Array.isArray(current)) {
          current = current[parseInt(index, 10)];
        } else {
          return undefined;
        }
      } else {
        current = current[part];
      }
    }

    return current;
  }

  /**
   * Apply a condition operator
   */
  private static applyOperator(fieldValue: any, operator: ConditionOperator, expectedValue: any): boolean {
    switch (operator) {
      case '==':
        return fieldValue == expectedValue; // Loose equality
      
      case '!=':
        return fieldValue != expectedValue;
      
      case '>':
        return Number(fieldValue) > Number(expectedValue);
      
      case '<':
        return Number(fieldValue) < Number(expectedValue);
      
      case '>=':
        return Number(fieldValue) >= Number(expectedValue);
      
      case '<=':
        return Number(fieldValue) <= Number(expectedValue);
      
      case 'contains':
        if (typeof fieldValue === 'string') {
          return fieldValue.toLowerCase().includes(String(expectedValue).toLowerCase());
        }
        if (Array.isArray(fieldValue)) {
          return fieldValue.some(item => 
            String(item).toLowerCase().includes(String(expectedValue).toLowerCase())
          );
        }
        return false;
      
      case 'not-contains':
        if (typeof fieldValue === 'string') {
          return !fieldValue.toLowerCase().includes(String(expectedValue).toLowerCase());
        }
        if (Array.isArray(fieldValue)) {
          return !fieldValue.some(item => 
            String(item).toLowerCase().includes(String(expectedValue).toLowerCase())
          );
        }
        return true;
      
      case 'in':
        if (Array.isArray(expectedValue)) {
          return expectedValue.includes(fieldValue);
        }
        return false;
      
      case 'not-in':
        if (Array.isArray(expectedValue)) {
          return !expectedValue.includes(fieldValue);
        }
        return true;
      
      case 'regex':
        try {
          const regex = new RegExp(String(expectedValue), 'i');
          return regex.test(String(fieldValue));
        } catch {
          return false;
        }
      
      case 'exists':
        return fieldValue !== undefined && fieldValue !== null;
      
      case 'not-exists':
        return fieldValue === undefined || fieldValue === null;
      
      default:
        console.warn(`Unknown operator: ${operator}`);
        return false;
    }
  }

  /**
   * Generate a recommendation from a rule
   */
  private static generateRecommendation(
    rule: RecommendationRule,
    context: RecommendationContext
  ): Recommendation {
    const { recommendation, displayConfig, priority } = rule;

    // Apply mail merge to content
    const title = MailMergeService.merge(recommendation.title, context);
    const description = MailMergeService.merge(recommendation.description, context);
    const mediaUrl = recommendation.mediaContent 
      ? MailMergeService.merge(recommendation.mediaContent, context)
      : undefined;
    const ctaText = recommendation.ctaText
      ? MailMergeService.merge(recommendation.ctaText, context)
      : undefined;
    const ctaUrl = recommendation.ctaUrl
      ? MailMergeService.merge(recommendation.ctaUrl, context)
      : undefined;

    return {
      id: `rec-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      ruleId: rule.id,
      patientId: context.patient.id,
      journeyId: context.journey?.id,
      title,
      description,
      mediaType: recommendation.mediaType,
      mediaUrl,
      ctaText,
      ctaUrl,
      displayLocations: displayConfig.locations,
      priority,
      status: 'pending',
      generatedAt: new Date(),
      expiresAt: displayConfig.cooldownPeriod 
        ? new Date(Date.now() + displayConfig.cooldownPeriod * 60 * 60 * 1000)
        : undefined,
      metadata: recommendation.metadata,
      ruleMetadata: {
        ruleName: rule.name,
        ruleDescription: rule.description,
        category: rule.category,
        tags: rule.tags
      }
    };
  }

  /**
   * Score a recommendation based on multiple factors
   */
  private static scoreRecommendation(
    recommendation: Recommendation,
    rule: RecommendationRule,
    context: RecommendationContext
  ): ScoredRecommendation {
    const priorityScore = rule.priority; // 1-100
    const recencyScore = this.calculateRecencyScore(context);
    const performanceScore = this.calculatePerformanceScore(rule);
    const contextScore = this.calculateContextScore(rule, context);

    // Weighted average
    const score = (
      priorityScore * 0.4 +
      recencyScore * 0.2 +
      performanceScore * 0.2 +
      contextScore * 0.2
    );

    return {
      recommendation,
      score,
      matchedConditions: rule.conditions.length,
      totalConditions: rule.conditions.length,
      relevanceFactors: {
        priorityScore,
        recencyScore,
        performanceScore,
        contextScore
      }
    };
  }

  /**
   * Calculate recency score (newer appointments = higher score)
   */
  private static calculateRecencyScore(context: RecommendationContext): number {
    if (!context.appointment?.date) return 50;

    const appointmentDate = new Date(context.appointment.date);
    const now = new Date();
    const daysDiff = Math.abs((now.getTime() - appointmentDate.getTime()) / (1000 * 60 * 60 * 24));

    if (daysDiff === 0) return 100; // Same day
    if (daysDiff <= 7) return 80;   // Within a week
    if (daysDiff <= 30) return 60;  // Within a month
    if (daysDiff <= 90) return 40;  // Within 3 months
    return 20; // Older
  }

  /**
   * Calculate performance score based on historical metrics
   */
  private static calculatePerformanceScore(rule: RecommendationRule): number {
    const { metrics } = rule;

    if (metrics.impressions === 0) return 50; // No data yet

    const ctr = metrics.clicks / metrics.impressions;
    const conversionRate = metrics.conversions / metrics.impressions;

    // Weight conversion rate more heavily
    const score = (ctr * 30) + (conversionRate * 70);

    return Math.min(100, score * 100);
  }

  /**
   * Calculate context score based on journey step and timing
   */
  private static calculateContextScore(rule: RecommendationRule, context: RecommendationContext): number {
    let score = 50;

    // Boost if journey step matches
    if (context.journey?.currentStep && rule.displayConfig.journeySteps) {
      if (rule.displayConfig.journeySteps.includes(context.journey.currentStep)) {
        score += 30;
      }
    }

    // Boost if timing is immediate
    if (rule.displayConfig.timing === 'immediate') {
      score += 20;
    }

    return Math.min(100, score);
  }

  /**
   * Filter recommendations based on business rules
   */
  static filterRecommendations(
    recommendations: Recommendation[],
    maxPerLocation: number = 3,
    excludeDismissed: string[] = []
  ): Recommendation[] {
    // Remove dismissed recommendations
    let filtered = recommendations.filter(r => !excludeDismissed.includes(r.ruleId));

    // Remove expired
    filtered = filtered.filter(r => {
      if (!r.expiresAt) return true;
      return new Date() < r.expiresAt;
    });

    // Limit per location
    const byLocation: Record<string, Recommendation[]> = {};
    filtered.forEach(rec => {
      rec.displayLocations.forEach(loc => {
        if (!byLocation[loc]) byLocation[loc] = [];
        byLocation[loc].push(rec);
      });
    });

    // Take top N per location
    const limited = Object.values(byLocation)
      .flatMap(recs => recs.slice(0, maxPerLocation));

    // Deduplicate
    const seen = new Set();
    return limited.filter(rec => {
      if (seen.has(rec.id)) return false;
      seen.add(rec.id);
      return true;
    });
  }
}
