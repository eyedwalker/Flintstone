/**
 * Mail Merge Service
 * 
 * Dynamic token replacement for personalized recommendations
 * Supports deep object access and array indexing
 */

import { RecommendationContext, MailMergeToken } from '../types/recommendation';

export class MailMergeService {
  private static readonly TOKEN_REGEX = /\{\{([^}]+)\}\}/g;

  /**
   * Replace all mail merge tokens in a string with actual values
   */
  static merge(template: string, context: RecommendationContext): string {
    if (!template) return template;

    return template.replace(this.TOKEN_REGEX, (match, field) => {
      const value = this.resolveField(field.trim(), context);
      return value !== undefined && value !== null ? String(value) : match;
    });
  }

  /**
   * Extract all tokens from a template string
   */
  static extractTokens(template: string): string[] {
    if (!template) return [];
    
    const tokens: string[] = [];
    let match;
    
    while ((match = this.TOKEN_REGEX.exec(template)) !== null) {
      tokens.push(match[1].trim());
    }
    
    return tokens;
  }

  /**
   * Validate that all tokens in template can be resolved
   */
  static validateTemplate(template: string, context: RecommendationContext): {
    valid: boolean;
    unresolvedTokens: string[];
  } {
    const tokens = this.extractTokens(template);
    const unresolvedTokens = tokens.filter(token => {
      const value = this.resolveField(token, context);
      return value === undefined || value === null;
    });

    return {
      valid: unresolvedTokens.length === 0,
      unresolvedTokens
    };
  }

  /**
   * Get detailed token information for debugging
   */
  static analyzeTokens(template: string, context: RecommendationContext): MailMergeToken[] {
    const tokens = this.extractTokens(template);
    
    return tokens.map(token => {
      const value = this.resolveField(token, context);
      return {
        token: `{{${token}}}`,
        field: token,
        value,
        resolved: value !== undefined && value !== null
      };
    });
  }

  /**
   * Resolve a field path to its value in the context
   * Supports:
   * - Deep object access: patient.firstName
   * - Array indexing: purchaseHistory[0].productName
   * - Array property access: lifestyle.hobbies[0]
   */
  private static resolveField(field: string, context: RecommendationContext): any {
    try {
      // Handle special date formatters
      if (field.includes('|')) {
        const [path, formatter] = field.split('|').map(s => s.trim());
        const value = this.resolveFieldPath(path, context);
        return this.applyFormatter(value, formatter);
      }

      return this.resolveFieldPath(field, context);
    } catch (error) {
      console.warn(`Failed to resolve field: ${field}`, error);
      return undefined;
    }
  }

  /**
   * Resolve a field path (supports dots and array indices)
   */
  private static resolveFieldPath(path: string, context: RecommendationContext): any {
    const parts = path.split('.');
    let current: any = context;

    for (const part of parts) {
      if (current === undefined || current === null) {
        return undefined;
      }

      // Handle array indexing: purchaseHistory[0] or hobbies[0]
      const arrayMatch = part.match(/^(\w+)\[(\d+)\]$/);
      if (arrayMatch) {
        const [, arrayName, index] = arrayMatch;
        current = current[arrayName];
        if (Array.isArray(current)) {
          current = current[parseInt(index, 10)];
        } else {
          return undefined;
        }
      } else {
        current = current[part];
      }
    }

    return current;
  }

  /**
   * Apply formatter to a value (e.g., date formatting)
   */
  private static applyFormatter(value: any, formatter: string): any {
    if (value === undefined || value === null) return value;

    switch (formatter.toLowerCase()) {
      case 'date':
        return this.formatDate(value);
      case 'shortdate':
        return this.formatShortDate(value);
      case 'currency':
        return this.formatCurrency(value);
      case 'uppercase':
        return String(value).toUpperCase();
      case 'lowercase':
        return String(value).toLowerCase();
      case 'capitalize':
        return this.capitalize(String(value));
      default:
        return value;
    }
  }

  /**
   * Format date as MM/DD/YYYY
   */
  private static formatDate(value: any): string {
    const date = value instanceof Date ? value : new Date(value);
    if (isNaN(date.getTime())) return String(value);
    
    return date.toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric'
    });
  }

  /**
   * Format date as MMM DD, YYYY
   */
  private static formatShortDate(value: any): string {
    const date = value instanceof Date ? value : new Date(value);
    if (isNaN(date.getTime())) return String(value);
    
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  }

  /**
   * Format number as currency
   */
  private static formatCurrency(value: any): string {
    const num = parseFloat(value);
    if (isNaN(num)) return String(value);
    
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(num);
  }

  /**
   * Capitalize first letter of each word
   */
  private static capitalize(value: string): string {
    return value.replace(/\b\w/g, char => char.toUpperCase());
  }

  /**
   * Merge multiple strings with the same context
   */
  static mergeMultiple(templates: string[], context: RecommendationContext): string[] {
    return templates.map(template => this.merge(template, context));
  }

  /**
   * Check if a string contains any mail merge tokens
   */
  static hasTokens(template: string): boolean {
    return this.TOKEN_REGEX.test(template);
  }

  /**
   * Preview merge result with sample context
   */
  static preview(template: string, context: RecommendationContext): {
    original: string;
    merged: string;
    tokens: MailMergeToken[];
  } {
    return {
      original: template,
      merged: this.merge(template, context),
      tokens: this.analyzeTokens(template, context)
    };
  }
}
