import { v4 as uuidv4 } from 'uuid';

// Task types and categories
export enum TaskType {
  FOLLOWUP_APPOINTMENT = 'followup-appointment',
  SPECIALIST_REFERRAL = 'specialist-referral', 
  INSURANCE_CLAIM = 'insurance-claim',
  PREAUTHORIZATION = 'preauthorization',
  FRAME_ADJUSTMENT = 'frame-adjustment',
  LENS_REMAKE = 'lens-remake',
  CONTACT_TRAINING = 'contact-training',
  PRESCRIPTION_UPDATE = 'prescription-update',
  RECALL_REMINDER = 'recall-reminder',
  SATISFACTION_SURVEY = 'satisfaction-survey',
  PAYMENT_PLAN = 'payment-plan',
  CHART_COMPLETION = 'chart-completion',
  CUSTOM = 'custom'
}

export enum TaskCategory {
  MEDICAL = 'medical',
  INSURANCE = 'insurance', 
  PRODUCT = 'product',
  COMMUNICATION = 'communication',
  ADMINISTRATIVE = 'administrative'
}

export enum TaskPriority {
  HIGH = 'high',
  MEDIUM = 'medium',
  LOW = 'low'
}

export enum TaskStatus {
  PENDING = 'pending',
  IN_PROGRESS = 'in-progress',
  COMPLETED = 'completed',
  CANCELLED = 'cancelled',
  OVERDUE = 'overdue'
}

export interface Task {
  id: string;
  patientId: string;
  patientName: string;
  journeyId: string;
  type: TaskType;
  category: TaskCategory;
  title: string;
  description?: string;
  priority: TaskPriority;
  status: TaskStatus;
  dueDate?: Date;
  createdDate: Date;
  completedDate?: Date;
  assignedTo?: string;
  notes?: string;
  aiCompletable?: boolean;
  aiPrompt?: string;
  aiCompletedBy?: string;
  aiCompletedAt?: Date;
  metadata?: Record<string, any>;
}

export interface TaskTemplate {
  id: string;
  type: TaskType;
  category: TaskCategory;
  title: string;
  description?: string;
  defaultPriority: TaskPriority;
  defaultDueDays?: number;
  isActive: boolean;
  aiCompletable?: boolean;
  aiPrompt?: string;
  metadata?: Record<string, any>;
}

export interface TaskSummary {
  total: number;
  pending: number;
  inProgress: number;
  completed: number;
  overdue: number;
  byCategory: Record<TaskCategory, number>;
  byPriority: Record<TaskPriority, number>;
}

// Default task templates
const DEFAULT_TASK_TEMPLATES: TaskTemplate[] = [
  {
    id: 'followup-1week',
    type: TaskType.FOLLOWUP_APPOINTMENT,
    category: TaskCategory.MEDICAL,
    title: '1-Week Follow-up Appointment',
    description: 'Schedule follow-up appointment in 1 week',
    defaultPriority: TaskPriority.MEDIUM,
    defaultDueDays: 7,
    isActive: true,
    aiCompletable: true,
    aiPrompt: 'Schedule a follow-up appointment for the patient in 1 week. Check availability and send appointment confirmation.'
  },
  {
    id: 'followup-1month',
    type: TaskType.FOLLOWUP_APPOINTMENT,
    category: TaskCategory.MEDICAL,
    title: '1-Month Follow-up Appointment',
    description: 'Schedule follow-up appointment in 1 month',
    defaultPriority: TaskPriority.MEDIUM,
    defaultDueDays: 30,
    isActive: true,
    aiCompletable: true,
    aiPrompt: 'Schedule a follow-up appointment for the patient in 1 month. Check availability and send appointment confirmation.'
  },
  {
    id: 'specialist-referral',
    type: TaskType.SPECIALIST_REFERRAL,
    category: TaskCategory.MEDICAL,
    title: 'Specialist Referral',
    description: 'Process referral to specialist',
    defaultPriority: TaskPriority.HIGH,
    defaultDueDays: 3,
    isActive: true,
    aiCompletable: false
  },
  {
    id: 'insurance-preauth',
    type: TaskType.PREAUTHORIZATION,
    category: TaskCategory.INSURANCE,
    title: 'Insurance Pre-authorization',
    description: 'Submit insurance pre-authorization request',
    defaultPriority: TaskPriority.HIGH,
    defaultDueDays: 2,
    isActive: true,
    aiCompletable: true,
    aiPrompt: 'Submit insurance pre-authorization request for the patient. Include all necessary medical documentation and follow up with insurance provider.'
  },
  {
    id: 'frame-adjustment',
    type: TaskType.FRAME_ADJUSTMENT,
    category: TaskCategory.PRODUCT,
    title: 'Frame Adjustment',
    description: 'Schedule frame adjustment appointment',
    defaultPriority: TaskPriority.LOW,
    defaultDueDays: 14,
    isActive: true,
    aiCompletable: true,
    aiPrompt: 'Schedule a frame adjustment appointment for the patient. Contact patient to arrange convenient time.'
  },
  {
    id: 'contact-training',
    type: TaskType.CONTACT_TRAINING,
    category: TaskCategory.PRODUCT,
    title: 'Contact Lens Training',
    description: 'Schedule contact lens insertion/removal training',
    defaultPriority: TaskPriority.MEDIUM,
    defaultDueDays: 7,
    isActive: true,
    aiCompletable: false
  },
  {
    id: 'recall-6month',
    type: TaskType.RECALL_REMINDER,
    category: TaskCategory.COMMUNICATION,
    title: '6-Month Recall Reminder',
    description: 'Send 6-month recall reminder',
    defaultPriority: TaskPriority.LOW,
    defaultDueDays: 180,
    isActive: true,
    aiCompletable: true,
    aiPrompt: 'Send a 6-month recall reminder to the patient via their preferred communication method. Include scheduling options.'
  },
  {
    id: 'satisfaction-survey',
    type: TaskType.SATISFACTION_SURVEY,
    category: TaskCategory.COMMUNICATION,
    title: 'Patient Satisfaction Survey',
    description: 'Send patient satisfaction survey',
    defaultPriority: TaskPriority.LOW,
    defaultDueDays: 3,
    isActive: true,
    aiCompletable: true,
    aiPrompt: 'Send patient satisfaction survey via email or SMS. Follow up if no response received within 2 days.'
  }
];

// Task configuration by category
export const TASK_CATEGORY_CONFIG = {
  [TaskCategory.MEDICAL]: {
    label: 'Medical Follow-ups',
    color: 'text-red-700',
    bgColor: 'bg-red-50',
    borderColor: 'border-red-200',
    icon: '🏥'
  },
  [TaskCategory.INSURANCE]: {
    label: 'Insurance & Billing',
    color: 'text-blue-700', 
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200',
    icon: '💰'
  },
  [TaskCategory.PRODUCT]: {
    label: 'Product Follow-ups',
    color: 'text-purple-700',
    bgColor: 'bg-purple-50', 
    borderColor: 'border-purple-200',
    icon: '👓'
  },
  [TaskCategory.COMMUNICATION]: {
    label: 'Communications',
    color: 'text-green-700',
    bgColor: 'bg-green-50',
    borderColor: 'border-green-200', 
    icon: '📞'
  },
  [TaskCategory.ADMINISTRATIVE]: {
    label: 'Administrative',
    color: 'text-gray-700',
    bgColor: 'bg-gray-50',
    borderColor: 'border-gray-200',
    icon: '📄'
  }
};

export const TASK_PRIORITY_CONFIG = {
  [TaskPriority.HIGH]: {
    label: 'High',
    color: 'text-red-700',
    bgColor: 'bg-red-100',
    borderColor: 'border-red-300'
  },
  [TaskPriority.MEDIUM]: {
    label: 'Medium', 
    color: 'text-yellow-700',
    bgColor: 'bg-yellow-100',
    borderColor: 'border-yellow-300'
  },
  [TaskPriority.LOW]: {
    label: 'Low',
    color: 'text-green-700', 
    bgColor: 'bg-green-100',
    borderColor: 'border-green-300'
  }
};

class TaskManagementService {
  private tasks: Task[] = [];
  private templates: TaskTemplate[] = [...DEFAULT_TASK_TEMPLATES];
  private readonly STORAGE_KEY = 'patient-tasks';

  constructor() {
    // Load tasks from localStorage on initialization
    this.loadTasksFromStorage();
  }

  // Load tasks from localStorage
  private loadTasksFromStorage(): void {
    try {
      const storedTasks = localStorage.getItem(this.STORAGE_KEY);
      if (storedTasks) {
        const parsed = JSON.parse(storedTasks);
        // Convert date strings back to Date objects
        this.tasks = parsed.map((task: any) => ({
          ...task,
          createdDate: new Date(task.createdDate),
          dueDate: task.dueDate ? new Date(task.dueDate) : undefined,
          completedDate: task.completedDate ? new Date(task.completedDate) : undefined
        }));
        console.log('Loaded tasks from storage:', this.tasks.length);
      }
    } catch (error) {
      console.error('Error loading tasks from storage:', error);
      this.tasks = [];
    }
  }

  // Save tasks to localStorage
  private saveTasksToStorage(): void {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.tasks));
      console.log('Saved tasks to storage:', this.tasks.length);
    } catch (error) {
      console.error('Error saving tasks to storage:', error);
    }
  }

  // Debug methods to inspect current state
  debugTasks() {
    console.log('All tasks:', this.tasks);
    console.log('Tasks by patient:', this.tasks.reduce((acc: Record<string, number>, task) => {
      acc[task.patientId] = (acc[task.patientId] || 0) + 1;
      return acc;
    }, {}));
  }

  // Clear all tasks (for debugging)
  clearAllTasks() {
    console.log('Clearing all tasks');
    this.tasks = [];
    this.saveTasksToStorage();
  }

  // Remove tasks with empty or invalid titles
  removeUntitledTasks(): number {
    const before = this.tasks.length;
    this.tasks = this.tasks.filter(t => t.title && t.title.trim().length >= 3);
    this.saveTasksToStorage();
    const removed = before - this.tasks.length;
    console.log(`Removed ${removed} untitled tasks`);
    return removed;
  }

  // Remove tasks for journeys that no longer exist
  cleanupOrphanedTasks(validJourneyIds: string[]): number {
    const before = this.tasks.length;
    this.tasks = this.tasks.filter(t => validJourneyIds.includes(t.journeyId));
    this.saveTasksToStorage();
    const removed = before - this.tasks.length;
    console.log(`Removed ${removed} orphaned tasks`);
    return removed;
  }

  // Remove completed tasks older than specified days
  cleanupOldTasks(daysOld: number = 30): number {
    const before = this.tasks.length;
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysOld);
    
    this.tasks = this.tasks.filter(t => {
      if (t.status !== TaskStatus.COMPLETED && t.status !== TaskStatus.CANCELLED) {
        return true; // Keep active tasks
      }
      const completedDate = t.completedDate || t.createdDate;
      return completedDate > cutoffDate;
    });
    
    this.saveTasksToStorage();
    const removed = before - this.tasks.length;
    console.log(`Removed ${removed} old completed tasks (older than ${daysOld} days)`);
    return removed;
  }

  // Comprehensive cleanup - run all cleanup operations
  cleanupAll(validJourneyIds?: string[]): { untitled: number; orphaned: number; old: number } {
    const untitled = this.removeUntitledTasks();
    const orphaned = validJourneyIds ? this.cleanupOrphanedTasks(validJourneyIds) : 0;
    const old = this.cleanupOldTasks(30);
    
    console.log(`Task cleanup complete: ${untitled} untitled, ${orphaned} orphaned, ${old} old tasks removed`);
    return { untitled, orphaned, old };
  }

  // Task CRUD operations
  createTask(taskData: Partial<Task>): Task {
    const task: Task = {
      id: uuidv4(),
      patientId: taskData.patientId!,
      patientName: taskData.patientName!,
      journeyId: taskData.journeyId!,
      type: taskData.type!,
      category: taskData.category!,
      title: taskData.title!,
      description: taskData.description,
      priority: taskData.priority || TaskPriority.MEDIUM,
      status: TaskStatus.PENDING,
      createdDate: new Date(),
      dueDate: taskData.dueDate,
      assignedTo: taskData.assignedTo,
      notes: taskData.notes,
      aiCompletable: taskData.aiCompletable || false,
      aiPrompt: taskData.aiPrompt,
      metadata: taskData.metadata
    };

    this.tasks.push(task);
    this.saveTasksToStorage();
    return task;
  }

  createTaskFromTemplate(
    templateId: string, 
    patientId: string,
    patientName: string,
    journeyId: string,
    overrides?: Partial<Task>
  ): Task | null {
    const template = this.templates.find(t => t.id === templateId && t.isActive);
    if (!template) return null;

    const dueDate = template.defaultDueDays 
      ? new Date(Date.now() + template.defaultDueDays * 24 * 60 * 60 * 1000)
      : undefined;

    return this.createTask({
      patientId,
      patientName, 
      journeyId,
      type: template.type,
      category: template.category,
      title: template.title,
      description: template.description,
      priority: template.defaultPriority,
      dueDate,
      aiCompletable: template.aiCompletable,
      aiPrompt: template.aiPrompt,
      ...overrides
    });
  }

  updateTask(taskId: string, updates: Partial<Task>): Task | null {
    const taskIndex = this.tasks.findIndex(t => t.id === taskId);
    if (taskIndex === -1) return null;

    this.tasks[taskIndex] = { ...this.tasks[taskIndex], ...updates };
    
    // Set completion date if status changed to completed
    if (updates.status === TaskStatus.COMPLETED && !this.tasks[taskIndex].completedDate) {
      this.tasks[taskIndex].completedDate = new Date();
    }

    this.saveTasksToStorage();
    return this.tasks[taskIndex];
  }

  completeTask(taskId: string, notes?: string): Task | null {
    return this.updateTask(taskId, {
      status: TaskStatus.COMPLETED,
      completedDate: new Date(),
      notes: notes || undefined
    });
  }

  // AI Completion Methods
  completeTaskByAI(taskId: string, aiSystem: string, notes?: string): Task | null {
    return this.updateTask(taskId, {
      status: TaskStatus.COMPLETED,
      completedDate: new Date(),
      aiCompletedBy: aiSystem,
      aiCompletedAt: new Date(),
      notes: notes || undefined
    });
  }

  getAICompletableTasks(): Task[] {
    return this.tasks.filter(t => 
      t.aiCompletable && 
      t.status !== TaskStatus.COMPLETED && 
      t.status !== TaskStatus.CANCELLED
    );
  }

  async processAITask(taskId: string): Promise<{ success: boolean; message: string }> {
    const task = this.getTask(taskId);
    if (!task) {
      return { success: false, message: 'Task not found' };
    }

    if (!task.aiCompletable || !task.aiPrompt) {
      return { success: false, message: 'Task is not AI completable' };
    }

    try {
      // Simulate AI processing (replace with actual AI service call)
      console.log(`AI Processing task: ${task.title}`);
      console.log(`AI Prompt: ${task.aiPrompt}`);
      
      // Update task status to in-progress during AI processing
      this.updateTask(taskId, { status: TaskStatus.IN_PROGRESS });
      
      // Simulate AI processing time
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Complete the task via AI
      this.completeTaskByAI(taskId, 'Timeline-AI', `AI completed: ${task.aiPrompt}`);
      
      return { success: true, message: `Task "${task.title}" completed successfully by AI` };
    } catch (error) {
      // Reset task status if AI processing fails
      this.updateTask(taskId, { status: TaskStatus.PENDING });
      return { success: false, message: `AI processing failed: ${error}` };
    }
  }

  deleteTask(taskId: string): boolean {
    const initialLength = this.tasks.length;
    this.tasks = this.tasks.filter(t => t.id !== taskId);
    return this.tasks.length < initialLength;
  }

  // Task retrieval
  getTask(taskId: string): Task | null {
    return this.tasks.find(t => t.id === taskId) || null;
  }

  getTasksForPatient(patientId: string): Task[] {
    return this.tasks.filter(t => t.patientId === patientId);
  }

  getTasksForJourney(journeyId: string): Task[] {
    return this.tasks.filter(t => t.journeyId === journeyId);
  }

  getAllTasks(): Task[] {
    return [...this.tasks];
  }

  getTasksByStatus(status: TaskStatus): Task[] {
    return this.tasks.filter(t => t.status === status);
  }

  getTasksByCategory(category: TaskCategory): Task[] {
    return this.tasks.filter(t => t.category === category);
  }

  getOverdueTasks(): Task[] {
    const now = new Date();
    return this.tasks.filter(t => 
      t.status !== TaskStatus.COMPLETED && 
      t.status !== TaskStatus.CANCELLED &&
      t.dueDate && 
      t.dueDate < now
    );
  }

  // Task analytics
  getTaskSummary(): TaskSummary {
    const summary: TaskSummary = {
      total: this.tasks.length,
      pending: 0,
      inProgress: 0, 
      completed: 0,
      overdue: 0,
      byCategory: {
        [TaskCategory.MEDICAL]: 0,
        [TaskCategory.INSURANCE]: 0,
        [TaskCategory.PRODUCT]: 0,
        [TaskCategory.COMMUNICATION]: 0,
        [TaskCategory.ADMINISTRATIVE]: 0
      },
      byPriority: {
        [TaskPriority.HIGH]: 0,
        [TaskPriority.MEDIUM]: 0,
        [TaskPriority.LOW]: 0
      }
    };

    const now = new Date();

    this.tasks.forEach(task => {
      // Count by status
      switch (task.status) {
        case TaskStatus.PENDING:
          summary.pending++;
          break;
        case TaskStatus.IN_PROGRESS:
          summary.inProgress++;
          break;
        case TaskStatus.COMPLETED:
          summary.completed++;
          break;
      }

      // Check if overdue
      if (task.status !== TaskStatus.COMPLETED && 
          task.status !== TaskStatus.CANCELLED &&
          task.dueDate && task.dueDate < now) {
        summary.overdue++;
      }

      // Count by category
      summary.byCategory[task.category]++;

      // Count by priority  
      summary.byPriority[task.priority]++;
    });

    return summary;
  }

  // Template management
  getTaskTemplates(): TaskTemplate[] {
    return this.templates.filter(t => t.isActive);
  }

  getTaskTemplate(templateId: string): TaskTemplate | null {
    return this.templates.find(t => t.id === templateId) || null;
  }

  createTemplate(templateData: Omit<TaskTemplate, 'id'>): TaskTemplate {
    const template: TaskTemplate = {
      id: uuidv4(),
      ...templateData
    };
    this.templates.push(template);
    return template;
  }

  updateTemplate(templateId: string, updates: Partial<TaskTemplate>): TaskTemplate | null {
    const templateIndex = this.templates.findIndex(t => t.id === templateId);
    if (templateIndex === -1) return null;

    this.templates[templateIndex] = { ...this.templates[templateIndex], ...updates };
    return this.templates[templateIndex];
  }

  // Batch operations
  createTasksFromTemplates(
    templateIds: string[],
    patientId: string,
    patientName: string,
    journeyId: string
  ): Task[] {
    const tasks: Task[] = [];
    
    templateIds.forEach(templateId => {
      const task = this.createTaskFromTemplate(templateId, patientId, patientName, journeyId);
      if (task) tasks.push(task);
    });

    return tasks;
  }

  // Utility methods
  isTaskOverdue(task: Task): boolean {
    if (!task.dueDate) return false;
    if (task.status === TaskStatus.COMPLETED || task.status === TaskStatus.CANCELLED) return false;
    return task.dueDate < new Date();
  }

  getDaysUntilDue(task: Task): number | null {
    if (!task.dueDate) return null;
    const now = new Date();
    const diffTime = task.dueDate.getTime() - now.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  getTasksByDueDate(ascending = true): Task[] {
    return [...this.tasks]
      .filter(t => t.dueDate)
      .sort((a, b) => {
        const aTime = a.dueDate!.getTime();
        const bTime = b.dueDate!.getTime();
        return ascending ? aTime - bTime : bTime - aTime;
      });
  }
}

// Export singleton instance
export const taskManager = new TaskManagementService();
export default TaskManagementService;
