/**
 * Room Workflow Service
 * Manages intelligent room assignment and patient flow logic
 */

import { RoomType } from '../types/office-rooms';

export interface RoomWorkflowRule {
  fromRoom: RoomType;
  toRooms: RoomType[];
  condition?: (patient: any) => boolean;
  priority: number;
}

export interface PatientStepMapping {
  stepId: string;
  preferredRoomTypes: RoomType[];
  requiredRoomTypes?: RoomType[];
}

// Standard eye care workflow patterns
export const ROOM_WORKFLOW_RULES: RoomWorkflowRule[] = [
  // From waiting area
  {
    fromRoom: 'waiting',
    toRooms: ['pre-testing'],
    priority: 1
  },
  
  // From pre-testing
  {
    fromRoom: 'pre-testing',
    toRooms: ['exam-room', 'dilation'],
    priority: 1
  },
  
  // From exam room
  {
    fromRoom: 'exam-room',
    toRooms: ['dilation', 'optical', 'contact-lens', 'checkout'],
    priority: 1
  },
  
  // From dilation
  {
    fromRoom: 'dilation',
    toRooms: ['doctor-office', 'optical', 'checkout'],
    priority: 1
  },
  
  // From doctor office
  {
    fromRoom: 'doctor-office',
    toRooms: ['optical', 'contact-lens', 'dispensary', 'checkout'],
    priority: 1
  },
  
  // From optical
  {
    fromRoom: 'optical',
    toRooms: ['dispensary', 'checkout'],
    priority: 1
  },
  
  // From contact lens
  {
    fromRoom: 'contact-lens',
    toRooms: ['dispensary', 'checkout'],
    priority: 1
  },
  
  // From dispensary
  {
    fromRoom: 'dispensary',
    toRooms: ['checkout'],
    priority: 1
  },
  
  // From checkout - moves to post-visit
  {
    fromRoom: 'checkout',
    toRooms: [],
    priority: 1
  }
];

// Map patient journey steps to preferred room types
export const STEP_ROOM_MAPPING: PatientStepMapping[] = [
  {
    stepId: 'forms',
    preferredRoomTypes: ['waiting']
  },
  {
    stepId: 'pre-testing',
    preferredRoomTypes: ['pre-testing']
  },
  {
    stepId: 'exam',
    preferredRoomTypes: ['exam-room']
  },
  {
    stepId: 'dilation',
    preferredRoomTypes: ['dilation']
  },
  {
    stepId: 'optical',
    preferredRoomTypes: ['optical']
  },
  {
    stepId: 'contact-lens',
    preferredRoomTypes: ['contact-lens']
  },
  {
    stepId: 'doctor-consultation',
    preferredRoomTypes: ['doctor-office']
  },
  {
    stepId: 'dispensary',
    preferredRoomTypes: ['dispensary']
  },
  {
    stepId: 'checkout',
    preferredRoomTypes: ['checkout']
  }
];

export class RoomWorkflowService {
  /**
   * Get suggested next room types based on current room
   */
  static getNextRoomSuggestions(currentRoomType: RoomType, patient?: any): RoomType[] {
    const rule = ROOM_WORKFLOW_RULES.find(r => r.fromRoom === currentRoomType);
    
    if (!rule) {
      return [];
    }
    
    let suggestions = rule.toRooms;
    
    // Apply conditions if present
    if (rule.condition && patient) {
      if (!rule.condition(patient)) {
        return [];
      }
    }
    
    return suggestions;
  }
  
  /**
   * Get preferred room type for a specific patient step
   */
  static getPreferredRoomForStep(stepId: string): RoomType[] {
    const mapping = STEP_ROOM_MAPPING.find(m => m.stepId === stepId);
    return mapping?.preferredRoomTypes || [];
  }
  
  /**
   * Find the best available room for a patient's next step
   */
  static findBestNextRoom(
    currentRoomType: RoomType,
    availableRooms: any[],
    patient?: any
  ): any | null {
    const suggestions = this.getNextRoomSuggestions(currentRoomType, patient);
    
    if (suggestions.length === 0) {
      return null;
    }
    
    // If patient has a current step, prefer rooms matching that step
    if (patient?.currentStepId) {
      const stepPreferences = this.getPreferredRoomForStep(patient.currentStepId);
      
      for (const preferredType of stepPreferences) {
        if (suggestions.includes(preferredType)) {
          const room = availableRooms.find(r => 
            r.type === preferredType && 
            r.status === 'available' && 
            r.isActive
          );
          if (room) return room;
        }
      }
    }
    
    // Fallback to any available room in suggestions
    for (const roomType of suggestions) {
      const room = availableRooms.find(r => 
        r.type === roomType && 
        r.status === 'available' && 
        r.isActive
      );
      if (room) return room;
    }
    
    return null;
  }
  
  /**
   * Check if a room transition is valid according to workflow rules
   */
  static isValidTransition(fromRoomType: RoomType, toRoomType: RoomType): boolean {
    const rule = ROOM_WORKFLOW_RULES.find(r => r.fromRoom === fromRoomType);
    
    if (!rule) {
      // Allow transitions if no rule exists
      return true;
    }
    
    return rule.toRooms.includes(toRoomType);
  }
  
  /**
   * Get all possible room types that can follow the current room
   */
  static getPossibleNextRooms(currentRoomType: RoomType): RoomType[] {
    const rule = ROOM_WORKFLOW_RULES.find(r => r.fromRoom === currentRoomType);
    return rule ? rule.toRooms : [];
  }
  
  /**
   * Check if a patient should move to post-visit phase
   */
  static shouldMoveToPostVisit(currentRoomType: RoomType, patient?: any): boolean {
    return currentRoomType === 'checkout';
  }
  
  /**
   * Get workflow description for a room type
   */
  static getWorkflowDescription(roomType: RoomType): string {
    const descriptions: Record<RoomType, string> = {
      'waiting': 'First stop - complete forms and wait for pre-testing',
      'pre-testing': 'Visual acuity and preliminary tests before exam',
      'exam-room': 'Primary examination with technician or assistant',
      'dilation': 'Eye dilation and extended testing if required',
      'optical': 'Frame selection and lens consultation',
      'contact-lens': 'Contact lens fitting and education',
      'doctor-office': 'Final consultation with doctor',
      'dispensary': 'Lens dispensing and prescription pickup',
      'checkout': 'Final billing and scheduling follow-ups',
      'other': 'General purpose room for various needs'
    };
    
    return descriptions[roomType] || 'General purpose room';
  }
}
