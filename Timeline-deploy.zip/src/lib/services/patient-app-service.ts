/**
 * Patient App Service
 * Core service for patient-facing mobile/web app
 * Handles authentication, session management, and app-specific logic
 */

import { PatientJourneyService } from './patient-journey-service';
import { EyefinityService } from '../../services/eyefinityService';
import { RecommendationService } from './recommendation-service';

export interface PatientSession {
  patientId: string;
  appointmentId: string;
  patientName: string;
  patientEmail?: string;
  patientPhone?: string;
  sessionToken: string;
  expiresAt: Date;
  journeyId?: string;
}

export interface PatientInvoice {
  id: string;
  patientId: string;
  invoiceNumber: string;
  invoiceDate: Date;
  dueDate: Date;
  totalAmount: number;
  amountPaid: number;
  amountDue: number;
  status: 'pending' | 'partial' | 'paid' | 'overdue';
  items: InvoiceItem[];
  payments: Payment[];
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  category: 'exam' | 'frames' | 'lenses' | 'contacts' | 'other';
  insuranceCovered: boolean;
  insuranceAmount?: number;
}

export interface Payment {
  id: string;
  paymentDate: Date;
  amount: number;
  method: 'cash' | 'check' | 'credit_card' | 'apple_pay' | 'google_pay' | 'insurance';
  lastFour?: string;
  transactionId?: string;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
}

export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  clientSecret: string;
  status: string;
}

const SESSION_STORAGE_KEY = 'patient_app_session';
const SESSIONS_STORAGE_KEY = 'patient_app_sessions';

export class PatientAppService {
  /**
   * Authenticate patient with appointment ID and DOB
   */
  static async authenticatePatient(
    appointmentId: string,
    dateOfBirth: string
  ): Promise<PatientSession> {
    try {
      // Find the journey for this appointment
      const journeys = PatientJourneyService.getAllJourneys();
      const journey = journeys.find((j: any) => 
        j.appointmentId === appointmentId || j.id === appointmentId
      );

      if (!journey) {
        throw new Error('Appointment not found');
      }

      // Fetch patient demographics to verify DOB
      const demographics = await EyefinityService.getPatientById(journey.patientId);
      
      // Verify DOB matches (simple string comparison - could be enhanced)
      const patientDob = demographics.dob?.split(' ')[0]; // "2001-06-21 00:00:00" → "2001-06-21"
      if (patientDob !== dateOfBirth) {
        throw new Error('Date of birth does not match');
      }

      // Create session
      const session: PatientSession = {
        patientId: journey.patientId,
        appointmentId: appointmentId,
        patientName: demographics.fullName || journey.patientName,
        patientEmail: demographics.email,
        patientPhone: demographics.phone,
        sessionToken: this.generateSessionToken(),
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
        journeyId: journey.id
      };

      // Store session
      this.storeSession(session);

      return session;
    } catch (error) {
      console.error('Patient authentication failed:', error);
      throw error;
    }
  }

  /**
   * Authenticate patient with magic link token
   */
  static authenticateWithToken(token: string): PatientSession | null {
    const sessions = this.getAllSessions();
    const session = sessions.find(s => s.sessionToken === token);
    
    if (!session) {
      return null;
    }

    // Check if expired
    if (new Date(session.expiresAt) < new Date()) {
      this.clearSession(session.sessionToken);
      return null;
    }

    // Store as current session
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
    
    return session;
  }

  /**
   * Get current patient session
   */
  static getCurrentSession(): PatientSession | null {
    try {
      const stored = localStorage.getItem(SESSION_STORAGE_KEY);
      if (!stored) return null;

      const session = JSON.parse(stored) as PatientSession;

      // Check if expired
      if (new Date(session.expiresAt) < new Date()) {
        this.logout();
        return null;
      }

      return session;
    } catch (error) {
      console.error('Error getting session:', error);
      return null;
    }
  }

  /**
   * Logout and clear session
   */
  static logout(): void {
    localStorage.removeItem(SESSION_STORAGE_KEY);
  }

  /**
   * Get patient's current journey status
   */
  static getJourneyStatus(session: PatientSession) {
    if (!session.journeyId) return null;
    
    const journey = PatientJourneyService.getJourneyById(session.journeyId);
    
    if (!journey) return null;

    const currentStep = journey.steps?.find(s => s.id === journey.currentStepId);
    
    return {
      journey,
      currentStep,
      phase: journey.journeyPhase,
      progress: this.calculateProgress(journey),
      estimatedTimeRemaining: this.estimateTimeRemaining(journey)
    };
  }

  /**
   * Get wait time information
   */
  static getWaitTimeInfo(session: PatientSession) {
    const status = this.getJourneyStatus(session);
    if (!status) return null;

    // Simple wait time calculation based on phase and step
    const { journey, currentStep } = status;
    
    let waitMinutes = 0;
    let queuePosition = 0;

    if (journey.journeyPhase === 'in-office' && currentStep) {
      // Count patients ahead in same phase
      const allJourneys = PatientJourneyService.getAllJourneys();
      const inOfficeJourneys = allJourneys.filter((j: any) => 
        j.journeyPhase === 'in-office' && 
        j.id !== journey.id
      );
      
      queuePosition = inOfficeJourneys.length;
      waitMinutes = queuePosition * 5; // Rough estimate: 5 min per patient
    }

    return {
      estimatedMinutes: waitMinutes,
      queuePosition: queuePosition + 1,
      status: currentStep?.status || 'waiting',
      message: this.getWaitTimeMessage(waitMinutes, queuePosition)
    };
  }

  /**
   * Get patient's invoices
   */
  static async getInvoices(patientId: string): Promise<PatientInvoice[]> {
    try {
      // Fetch patient orders from Eyefinity
      const ordersResponse = await EyefinityService.getPatientOrders(patientId);
      const orders = ordersResponse.items || [];
      
      // Convert orders to invoices
      const invoices: PatientInvoice[] = orders.map((order: any) => {
        const totalAmount = parseFloat(order.total || '0');
        const amountPaid = parseFloat(order.amountPaid || '0');
        
        return {
          id: order.orderId,
          patientId: patientId,
          invoiceNumber: order.orderNumber || order.orderId,
          invoiceDate: new Date(order.orderDate),
          dueDate: new Date(order.orderDate), // Could calculate based on payment terms
          totalAmount,
          amountPaid,
          amountDue: totalAmount - amountPaid,
          status: this.getInvoiceStatus(totalAmount, amountPaid),
          items: this.parseOrderItems(order),
          payments: [] // Would need separate payment history API
        };
      });

      return invoices.sort((a, b) => b.invoiceDate.getTime() - a.invoiceDate.getTime());
    } catch (error) {
      console.error('Error fetching invoices:', error);
      return [];
    }
  }

  /**
   * Get single invoice details
   */
  static async getInvoiceById(invoiceId: string, patientId: string): Promise<PatientInvoice | null> {
    const invoices = await this.getInvoices(patientId);
    return invoices.find(inv => inv.id === invoiceId) || null;
  }

  /**
   * Create payment intent for Stripe
   */
  static async createPaymentIntent(
    invoiceId: string,
    amount: number,
    patientId: string
  ): Promise<PaymentIntent> {
    // In production, this would call your backend API which calls Stripe
    // For now, return mock data
    
    console.log('Creating payment intent:', { invoiceId, amount, patientId });

    // This would be: const response = await fetch('/api/payments/create-intent', {...})
    return {
      id: `pi_${Date.now()}`,
      amount: amount * 100, // Stripe uses cents
      currency: 'usd',
      clientSecret: `pi_${Date.now()}_secret_demo`,
      status: 'requires_payment_method'
    };
  }

  /**
   * Record a payment
   */
  static async recordPayment(
    invoiceId: string,
    patientId: string,
    payment: Omit<Payment, 'id'>
  ): Promise<Payment> {
    // In production, this would call your backend to record payment
    const newPayment: Payment = {
      id: `pay_${Date.now()}`,
      ...payment
    };

    console.log('Recording payment:', newPayment);

    // Update local storage for demo purposes
    const key = `patient_payments_${invoiceId}`;
    const stored = localStorage.getItem(key);
    const payments: Payment[] = stored ? JSON.parse(stored) : [];
    payments.push(newPayment);
    localStorage.setItem(key, JSON.stringify(payments));

    return newPayment;
  }

  /**
   * Generate receipt PDF
   */
  static generateReceipt(invoice: PatientInvoice, payment: Payment): string {
    // In production, would call backend to generate PDF
    // For now, return a data URL for demo
    const receiptHtml = this.buildReceiptHtml(invoice, payment);
    return `data:text/html;charset=utf-8,${encodeURIComponent(receiptHtml)}`;
  }

  // Private helper methods

  private static generateSessionToken(): string {
    return `tok_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private static storeSession(session: PatientSession): void {
    // Store current session
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
    
    // Store in all sessions list
    const sessions = this.getAllSessions();
    const existing = sessions.findIndex(s => s.sessionToken === session.sessionToken);
    if (existing >= 0) {
      sessions[existing] = session;
    } else {
      sessions.push(session);
    }
    localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(sessions));
  }

  private static getAllSessions(): PatientSession[] {
    try {
      const stored = localStorage.getItem(SESSIONS_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  private static clearSession(token: string): void {
    const sessions = this.getAllSessions();
    const filtered = sessions.filter(s => s.sessionToken !== token);
    localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(filtered));
  }

  private static calculateProgress(journey: any): number {
    if (!journey.steps || journey.steps.length === 0) return 0;
    
    const completed = journey.steps.filter((s: any) => s.status === 'completed').length;
    return Math.round((completed / journey.steps.length) * 100);
  }

  private static estimateTimeRemaining(journey: any): number {
    const remaining = journey.steps?.filter((s: any) => s.status !== 'completed').length || 0;
    return remaining * 10; // Rough estimate: 10 min per step
  }

  private static getWaitTimeMessage(minutes: number, position: number): string {
    if (minutes === 0) return "You're next! Please wait nearby.";
    if (minutes <= 5) return "Almost ready! Just a few more minutes.";
    if (minutes <= 15) return `About ${minutes} minutes until we're ready for you.`;
    return `You're #${position + 1} in line. Feel free to browse frames while you wait!`;
  }

  private static getInvoiceStatus(total: number, paid: number): PatientInvoice['status'] {
    if (paid === 0) return 'pending';
    if (paid >= total) return 'paid';
    return 'partial';
  }

  private static parseOrderItems(order: any): InvoiceItem[] {
    // Parse order details into line items
    const items: InvoiceItem[] = [];
    
    if (order.items && Array.isArray(order.items)) {
      order.items.forEach((item: any, index: number) => {
        items.push({
          id: `item_${index}`,
          description: item.description || item.name || 'Item',
          quantity: item.quantity || 1,
          unitPrice: parseFloat(item.price || '0'),
          totalPrice: parseFloat(item.total || item.price || '0'),
          category: this.categorizeItem(item.description || item.name || ''),
          insuranceCovered: false
        });
      });
    }

    return items;
  }

  private static categorizeItem(description: string): InvoiceItem['category'] {
    const desc = description.toLowerCase();
    if (desc.includes('exam') || desc.includes('test')) return 'exam';
    if (desc.includes('frame')) return 'frames';
    if (desc.includes('lens')) return 'lenses';
    if (desc.includes('contact')) return 'contacts';
    return 'other';
  }

  private static buildReceiptHtml(invoice: PatientInvoice, payment: Payment): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Receipt - ${invoice.invoiceNumber}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; }
          .header { text-align: center; margin-bottom: 30px; }
          .receipt-details { margin-bottom: 20px; }
          table { width: 100%; border-collapse: collapse; }
          th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
          .total { font-weight: bold; font-size: 18px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Payment Receipt</h1>
          <p>Invoice #${invoice.invoiceNumber}</p>
        </div>
        <div class="receipt-details">
          <p><strong>Payment Date:</strong> ${payment.paymentDate.toLocaleDateString()}</p>
          <p><strong>Payment Method:</strong> ${payment.method.replace('_', ' ').toUpperCase()}</p>
          <p><strong>Amount Paid:</strong> $${payment.amount.toFixed(2)}</p>
          <p><strong>Transaction ID:</strong> ${payment.transactionId || 'N/A'}</p>
        </div>
        <h3>Invoice Items</h3>
        <table>
          <thead>
            <tr>
              <th>Description</th>
              <th>Qty</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            ${invoice.items.map(item => `
              <tr>
                <td>${item.description}</td>
                <td>${item.quantity}</td>
                <td>$${item.totalPrice.toFixed(2)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        <p class="total">Total: $${invoice.totalAmount.toFixed(2)}</p>
        <p class="total">Amount Paid: $${payment.amount.toFixed(2)}</p>
        <p class="total">Remaining Balance: $${(invoice.amountDue - payment.amount).toFixed(2)}</p>
      </body>
      </html>
    `;
  }
}
