/**
 * Frame Scanner Service
 * Handles UPC scanning, frame lookup, and favorites management
 */

import { frameCatalogAccessor, FrameCatalog } from '../accessors/FrameCatalogAccessor';
import { patientFavoriteFramesAccessor, PatientFavoriteFrame } from '../accessors/PatientFavoriteFramesAccessor';
import jwt from 'jsonwebtoken';

export interface ScanResult {
  success: boolean;
  frame?: FrameCatalog;
  favorite?: PatientFavoriteFrame;
  message?: string;
}

export class FrameScannerService {
  /**
   * Generate a patient access token for scanner link
   */
  static generatePatientToken(patientId: string, companyId: string, expiresIn: string = '7d'): string {
    const secret = process.env.PATIENT_TOKEN_SECRET || 'default-secret-change-in-production';
    
    return jwt.sign(
      {
        patientId,
        companyId,
        type: 'frame-scanner',
        timestamp: Date.now()
      },
      secret,
      { expiresIn }
    );
  }

  /**
   * Verify and decode patient token
   */
  static verifyPatientToken(token: string): { patientId: string; companyId: string } | null {
    try {
      const secret = process.env.PATIENT_TOKEN_SECRET || 'default-secret-change-in-production';
      const decoded = jwt.verify(token, secret) as any;
      
      if (decoded.type !== 'frame-scanner') {
        return null;
      }
      
      return {
        patientId: decoded.patientId,
        companyId: decoded.companyId
      };
    } catch (error) {
      console.error('[FrameScannerService] Token verification failed:', error);
      return null;
    }
  }

  /**
   * Look up frame by UPC code
   */
  static async lookupFrame(upcCode: string): Promise<FrameCatalog | null> {
    const result = await frameCatalogAccessor.getByUPC(upcCode);
    
    if (!result.success || !result.data) {
      console.log('[FrameScannerService] Frame not found in catalog:', upcCode);
      return null;
    }
    
    return result.data;
  }

  /**
   * Scan and save a favorite frame
   */
  static async scanFrame(
    upcCode: string,
    patientId: string,
    companyId: string,
    notes?: string
  ): Promise<ScanResult> {
    // Look up frame in catalog
    const frame = await this.lookupFrame(upcCode);
    
    if (!frame) {
      // Save anyway with just UPC - staff can fill in details later
      const favoriteResult = await patientFavoriteFramesAccessor.addFavorite({
        patient_id: patientId,
        company_id: companyId,
        upc_code: upcCode,
        notes: notes || 'Frame not in catalog - needs manual entry',
        is_purchased: false
      });
      
      if (!favoriteResult.success) {
        return {
          success: false,
          message: 'Failed to save frame: ' + favoriteResult.error
        };
      }
      
      return {
        success: true,
        favorite: favoriteResult.data,
        message: 'Frame saved! Not found in catalog - staff will add details.'
      };
    }
    
    // Save to favorites with full frame info
    const favoriteResult = await patientFavoriteFramesAccessor.addFavorite({
      patient_id: patientId,
      company_id: companyId,
      upc_code: upcCode,
      frame_name: `${frame.brand} ${frame.model_name}`,
      frame_manufacturer: frame.manufacturer,
      frame_model: frame.model_name,
      frame_color: frame.color_name,
      frame_size: frame.lens_width ? `${frame.lens_width}-${frame.bridge_width}-${frame.temple_length}` : undefined,
      image_url: frame.image_url,
      notes,
      is_purchased: false
    });
    
    if (!favoriteResult.success) {
      return {
        success: false,
        message: 'Failed to save frame: ' + favoriteResult.error
      };
    }
    
    return {
      success: true,
      frame,
      favorite: favoriteResult.data,
      message: 'Frame added to favorites!'
    };
  }

  /**
   * Get patient's favorite frames
   */
  static async getFavorites(patientId: string, companyId: string): Promise<PatientFavoriteFrame[]> {
    const result = await patientFavoriteFramesAccessor.getByPatient(patientId, companyId);
    return result.success ? result.data || [] : [];
  }

  /**
   * Remove a favorite frame
   */
  static async removeFavorite(favoriteId: string): Promise<boolean> {
    const result = await patientFavoriteFramesAccessor.delete(favoriteId);
    return result.success;
  }

  /**
   * Mark frame as purchased
   */
  static async markPurchased(favoriteId: string): Promise<boolean> {
    const result = await patientFavoriteFramesAccessor.markPurchased(favoriteId);
    return result.success;
  }
}
