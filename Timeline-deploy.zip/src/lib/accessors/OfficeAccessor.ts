/**
 * Office Accessor
 * Manages office locations within companies
 */

import { BaseAccessor, AccessorResult } from './BaseAccessor';
import { getSupabase, setTenantContext } from '../db/connection';

export interface Office {
  id: string;
  company_id: string;
  name: string;
  eyefinity_location_id?: string;
  address: {
    street?: string;
    city?: string;
    state?: string;
    zip?: string;
    country?: string;
  };
  timezone: string;
  phone?: string;
  email?: string;
  created_at: string;
  updated_at: string;
  settings: Record<string, any>;
}

export interface OfficeWithRelations extends Office {
  company?: any;
  staff?: any[];
}

export class OfficeAccessor extends BaseAccessor<Office> {
  protected tableName = 'offices';

  /**
   * Create a new office
   */
  async create(data: Omit<Office, 'id' | 'created_at' | 'updated_at'>): Promise<AccessorResult<Office>> {
    try {
      const db = getSupabase();
      const { data: office, error } = await db
        .from(this.tableName)
        .insert({
          company_id: data.company_id,
          name: data.name,
          eyefinity_location_id: data.eyefinity_location_id,
          address: data.address || {},
          timezone: data.timezone || 'America/Chicago',
          phone: data.phone,
          email: data.email,
          settings: data.settings || {}
        })
        .select()
        .single();
      
      if (error) throw error;
      
      return { success: true, data: office };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get office by ID
   */
  async getById(id: string): Promise<AccessorResult<Office>> {
    try {
      const db = getSupabase();
      
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('id', id)
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      if (!data) return { success: false, error: 'Office not found' };
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get all offices for a company
   */
  async getByCompany(companyId: string): Promise<AccessorResult<Office[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('company_id', companyId)
        .order('name');
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get office by Eyefinity location ID
   */
  async getByEyefinityId(eyefinityLocationId: string): Promise<AccessorResult<Office>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('eyefinity_location_id', eyefinityLocationId)
        .maybeSingle(); // Use maybeSingle() instead of single() to avoid errors when not found
      
      // If no data found, return success: false but not an error
      if (!data) {
        return { success: false, error: 'Office not found' };
      }
      
      // Only throw if there's an actual error (not just "not found")
      if (error) {
        console.error('[OfficeAccessor] Error getting office by Eyefinity ID:', error);
        throw error;
      }
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Update office
   */
  async update(id: string, updates: Partial<Omit<Office, 'id' | 'created_at' | 'updated_at'>>): Promise<AccessorResult<Office>> {
    try {
      const db = getSupabase();
      
      const { data, error } = await db
        .from(this.tableName)
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      if (!data) return { success: false, error: 'Office not found' };
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Delete office
   */
  async delete(id: string): Promise<AccessorResult<boolean>> {
    try {
      const db = getSupabase();
      
      const { error } = await db
        .from(this.tableName)
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      
      return { success: true, data: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get office with company and staff
   */
  async getWithRelations(officeId: string): Promise<AccessorResult<OfficeWithRelations>> {
    try {
      const db = getSupabase();
      
      const { data, error } = await db
        .from(this.tableName)
        .select(`
          *,
          company:companies(*),
          staff_offices(
            staff(*)
          )
        `)
        .eq('id', officeId)
        .single();
      
      if (error) throw error;
      
      // Flatten staff data
      const office = {
        ...data,
        staff: data.staff_offices?.map((so: any) => so.staff) || []
      };
      delete office.staff_offices;
      
      return { success: true, data: office };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Search offices by name
   */
  async searchByName(searchTerm: string, companyId?: string): Promise<AccessorResult<Office[]>> {
    try {
      const db = getSupabase();
      let query = db
        .from(this.tableName)
        .select('*')
        .ilike('name', `%${searchTerm}%`);
      
      if (companyId) {
        query = query.eq('company_id', companyId);
      }
      
      const { data, error } = await query.order('name');
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get offices by timezone
   */
  async getByTimezone(timezone: string): Promise<AccessorResult<Office[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('timezone', timezone)
        .order('name');
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
}

export const officeAccessor = new OfficeAccessor();
export default officeAccessor;
