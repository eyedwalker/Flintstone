/**
 * Company Accessor
 * Manages company records with API credentials
 */

import { BaseAccessor, AccessorResult } from './BaseAccessor';
import { getSupabase } from '../db/connection';

export interface Company {
  id: string;
  account_id: string;
  name: string;
  eyefinity_company_id?: string;
  eyefinity_api_key?: string;
  eyefinity_api_secret?: string;
  eyefinity_base_url?: string;
  tenant_uid?: string;
  oauth_host?: string;
  api_base_url?: string;
  oauth_token?: string;
  oauth_refresh_token?: string;
  oauth_token_expires_at?: string;
  twilio_account_sid?: string;
  twilio_auth_token?: string;
  twilio_phone_number?: string;
  settings: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export class CompanyAccessor extends BaseAccessor<Company> {
  protected tableName = 'companies';

  /**
   * Get company by Eyefinity company ID
   */
  async getByEyefinityId(eyefinityCompanyId: string): Promise<AccessorResult<Company>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('eyefinity_company_id', eyefinityCompanyId)
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      if (!data) return { success: false, error: 'Not found' };
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get all companies for an account
   */
  async getByAccount(accountId: string): Promise<AccessorResult<Company[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('account_id', accountId)
        .order('name');
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get company with its offices
   */
  async getWithOffices(companyId: string): Promise<AccessorResult<Company & { offices: any[] }>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select(`
          *,
          offices (*)
        `)
        .eq('id', companyId)
        .single();
      
      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
}

export const companyAccessor = new CompanyAccessor();
export default companyAccessor;
