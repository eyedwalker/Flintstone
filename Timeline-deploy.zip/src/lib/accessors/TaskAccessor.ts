/**
 * Task Accessor
 * Manages patient care tasks
 */

import { BaseAccessor, AccessorResult } from './BaseAccessor';
import { getSupabase } from '../db/connection';

export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'cancelled' | 'blocked';
export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';
export type TaskCategory = 'clinical' | 'administrative' | 'follow_up' | 'insurance' | 'referral' | 'other';

export interface Task {
  id: string;
  company_id: string;
  office_id: string;
  title: string;
  description?: string;
  category: TaskCategory;
  priority: TaskPriority;
  status: TaskStatus;
  patient_id?: string;
  journey_id?: string;
  assigned_to?: string;
  due_date?: string;
  due_time?: string;
  completed_at?: string;
  notes?: string;
  tags?: string[];
  settings: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface TaskWithRelations extends Task {
  patient?: any;
  journey?: any;
  assigned_staff?: any;
}

export class TaskAccessor extends BaseAccessor<Task> {
  protected tableName = 'tasks';

  async create(data: Omit<Task, 'id' | 'created_at' | 'updated_at'>): Promise<AccessorResult<Task>> {
    try {
      const db = getSupabase();
      const { data: task, error } = await db
        .from(this.tableName)
        .insert({
          company_id: data.company_id,
          office_id: data.office_id,
          title: data.title,
          description: data.description,
          category: data.category,
          priority: data.priority || 'medium',
          status: data.status || 'pending',
          patient_id: data.patient_id,
          journey_id: data.journey_id,
          assigned_to: data.assigned_to,
          due_date: data.due_date,
          due_time: data.due_time,
          completed_at: data.completed_at,
          notes: data.notes,
          tags: data.tags || [],
          settings: data.settings || {},
        })
        .select()
        .single();

      if (error) throw error;
      return { success: true, data: task };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async getByOffice(officeId: string, status?: TaskStatus): Promise<AccessorResult<Task[]>> {
    try {
      const db = getSupabase();
      let query = db
        .from(this.tableName)
        .select('*')
        .eq('office_id', officeId)
        .order('due_date', { ascending: true, nullsFirst: false })
        .order('priority', { ascending: false });

      if (status) {
        query = query.eq('status', status);
      }

      const { data, error } = await query;

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async getByPatient(patientId: string, companyId: string): Promise<AccessorResult<Task[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('patient_id', patientId)
        .eq('company_id', companyId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async getByJourney(journeyId: string, companyId: string): Promise<AccessorResult<Task[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('journey_id', journeyId)
        .eq('company_id', companyId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async getByAssignedStaff(staffId: string, companyId: string): Promise<AccessorResult<Task[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('assigned_to', staffId)
        .eq('company_id', companyId)
        .order('due_date', { ascending: true, nullsFirst: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async updateStatus(id: string, status: TaskStatus): Promise<AccessorResult<Task>> {
    try {
      const db = getSupabase();
      const updates: any = { status };
      
      if (status === 'completed') {
        updates.completed_at = new Date().toISOString();
      }

      const { data, error } = await db
        .from(this.tableName)
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async update(id: string, updates: Partial<Task>): Promise<AccessorResult<Task>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async delete(id: string): Promise<AccessorResult<boolean>> {
    try {
      const db = getSupabase();
      const { error } = await db
        .from(this.tableName)
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { success: true, data: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
}

export const taskAccessor = new TaskAccessor();
