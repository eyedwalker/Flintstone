/**
 * Base Accessor - Foundation for all data access
 * Following VBD Architecture: Pure data access, no business logic
 */

import { getSupabase, query, queryOne, insert, upsert, update, deleteRows } from '../db/connection';

export interface QueryOptions {
  select?: string;
  filter?: Record<string, any>;
  order?: { column: string; ascending?: boolean };
  limit?: number;
  offset?: number;
}

export interface AccessorResult<T> {
  success: boolean;
  data?: T;
  error?: string;
}

export abstract class BaseAccessor<T> {
  protected abstract tableName: string;

  /**
   * Get all rows with optional filtering
   */
  async getAll(options?: QueryOptions): Promise<AccessorResult<T[]>> {
    try {
      const data = await query<T>(this.tableName, options);
      return { success: true, data };
    } catch (error: any) {
      console.error(`[${this.tableName}] getAll error:`, error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Get single row by ID
   */
  async getById(id: string): Promise<AccessorResult<T>> {
    try {
      const data = await queryOne<T>(this.tableName, id);
      if (!data) {
        return { success: false, error: 'Not found' };
      }
      return { success: true, data };
    } catch (error: any) {
      console.error(`[${this.tableName}] getById error:`, error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Get rows by filter
   */
  async getByFilter(filter: Record<string, any>): Promise<AccessorResult<T[]>> {
    try {
      const data = await query<T>(this.tableName, { filter });
      return { success: true, data };
    } catch (error: any) {
      console.error(`[${this.tableName}] getByFilter error:`, error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Create a new row
   */
  async create(data: Partial<T>): Promise<AccessorResult<T>> {
    try {
      const result = await insert<T>(this.tableName, data as Record<string, any>);
      return { success: true, data: result };
    } catch (error: any) {
      console.error(`[${this.tableName}] create error:`, error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Update existing row
   */
  async update(id: string, data: Partial<T>): Promise<AccessorResult<T>> {
    try {
      const results = await update<T>(this.tableName, data as Record<string, any>, { id });
      if (results.length === 0) {
        return { success: false, error: 'Not found' };
      }
      return { success: true, data: results[0] };
    } catch (error: any) {
      console.error(`[${this.tableName}] update error:`, error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Upsert (insert or update)
   */
  async upsert(data: Partial<T>, conflictColumn: string): Promise<AccessorResult<T>> {
    try {
      const result = await upsert<T>(this.tableName, data as Record<string, any>, conflictColumn);
      return { success: true, data: result };
    } catch (error: any) {
      console.error(`[${this.tableName}] upsert error:`, error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Delete row by ID
   */
  async delete(id: string): Promise<AccessorResult<boolean>> {
    try {
      await deleteRows(this.tableName, { id });
      return { success: true, data: true };
    } catch (error: any) {
      console.error(`[${this.tableName}] delete error:`, error.message);
      return { success: false, error: error.message };
    }
  }
}

export default BaseAccessor;
