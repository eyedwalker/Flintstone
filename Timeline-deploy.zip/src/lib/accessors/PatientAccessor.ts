/**
 * Patient Accessor
 * Manages patient data with Eyefinity integration
 */

import { BaseAccessor, AccessorResult } from './BaseAccessor';
import { getSupabase } from '../db/connection';

export interface Patient {
  id: string;
  company_id: string;
  eyefinity_patient_id?: string;
  first_name: string;
  last_name: string;
  date_of_birth?: string;
  gender?: 'male' | 'female' | 'other' | 'unknown';
  email?: string;
  phone?: string;
  mobile_phone?: string;
  address?: {
    street?: string;
    city?: string;
    state?: string;
    zip?: string;
    country?: string;
  };
  emergency_contact?: {
    name?: string;
    relationship?: string;
    phone?: string;
  };
  preferred_language?: string;
  status: 'active' | 'inactive' | 'deceased';
  notes?: string;
  settings: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export class PatientAccessor extends BaseAccessor<Patient> {
  protected tableName = 'patients';

  async create(data: Omit<Patient, 'id' | 'created_at' | 'updated_at'>): Promise<AccessorResult<Patient>> {
    try {
      const db = getSupabase();
      const { data: patient, error } = await db
        .from(this.tableName)
        .insert({
          company_id: data.company_id,
          eyefinity_patient_id: data.eyefinity_patient_id,
          first_name: data.first_name,
          last_name: data.last_name,
          date_of_birth: data.date_of_birth,
          gender: data.gender,
          email: data.email,
          phone: data.phone,
          mobile_phone: data.mobile_phone,
          address: data.address || {},
          emergency_contact: data.emergency_contact || {},
          preferred_language: data.preferred_language || 'en',
          status: data.status || 'active',
          notes: data.notes,
          settings: data.settings || {},
        })
        .select()
        .single();

      if (error) throw error;
      return { success: true, data: patient };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async getByCompany(companyId: string): Promise<AccessorResult<Patient[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('company_id', companyId)
        .order('last_name', { ascending: true });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async getByEyefinityId(eyefinityPatientId: string, companyId: string): Promise<AccessorResult<Patient>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('eyefinity_patient_id', eyefinityPatientId)
        .eq('company_id', companyId)
        .maybeSingle();

      if (!data) {
        return { success: false, error: 'Patient not found' };
      }

      if (error) {
        console.error('[PatientAccessor] Error getting patient by Eyefinity ID:', error);
        throw error;
      }

      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async searchByName(companyId: string, query: string): Promise<AccessorResult<Patient[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('company_id', companyId)
        .or(`first_name.ilike.%${query}%,last_name.ilike.%${query}%`)
        .order('last_name', { ascending: true })
        .limit(50);

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async update(id: string, updates: Partial<Patient>): Promise<AccessorResult<Patient>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
}

export const patientAccessor = new PatientAccessor();
