/**
 * Call Enrichment Accessor
 * Manages call sentiment, ratings, and metadata stored in our DB
 * Linked to Twilio calls via call_sid (globally unique)
 */

import { BaseAccessor, AccessorResult } from './BaseAccessor';
import { getSupabase } from '../db/connection';

export interface CallEnrichment {
  id: string;
  company_id: string;
  office_id?: string;
  call_sid: string;
  from_phone?: string;
  to_phone?: string;
  direction?: string;
  duration_seconds?: number;
  sentiment_score?: number;
  emotion?: string;
  emotion_confidence?: number;
  escalation_needed?: boolean;
  escalation_reason?: string;
  ai_performance_score?: number;
  staff_rating?: string;
  staff_notes?: string;
  reviewed_by?: string;
  reviewed_at?: string;
  transcript?: string;
  recording_url?: string;
  call_started_at?: string;
  created_at: string;
  updated_at: string;
}

export class CallEnrichmentAccessor extends BaseAccessor<CallEnrichment> {
  protected tableName = 'call_enrichments';

  /**
   * Get enrichment by Twilio call_sid
   */
  async getByCallSid(callSid: string): Promise<AccessorResult<CallEnrichment>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('call_sid', callSid)
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      if (!data) return { success: false, error: 'Not found' };
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get all enrichments for a company
   */
  async getByCompany(
    companyId: string,
    options?: { limit?: number; offset?: number }
  ): Promise<AccessorResult<CallEnrichment[]>> {
    try {
      const db = getSupabase();
      let query = db
        .from(this.tableName)
        .select('*')
        .eq('company_id', companyId)
        .order('created_at', { ascending: false });
      
      if (options?.limit) query = query.limit(options.limit);
      if (options?.offset) query = query.range(options.offset, options.offset + (options.limit || 50) - 1);
      
      const { data, error } = await query;
      if (error) throw error;
      
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get enrichments for multiple call_sids (batch)
   */
  async getByCallSids(callSids: string[]): Promise<AccessorResult<CallEnrichment[]>> {
    try {
      if (callSids.length === 0) {
        return { success: true, data: [] };
      }
      
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .in('call_sid', callSids);
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Upsert enrichment by call_sid
   */
  async upsertByCallSid(data: Partial<CallEnrichment>): Promise<AccessorResult<CallEnrichment>> {
    try {
      if (!data.call_sid) {
        return { success: false, error: 'call_sid is required' };
      }
      
      const db = getSupabase();
      const { data: result, error } = await db
        .from(this.tableName)
        .upsert(data, { onConflict: 'call_sid' })
        .select()
        .single();
      
      if (error) throw error;
      return { success: true, data: result };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Update staff rating for a call
   */
  async setStaffRating(
    callSid: string,
    rating: 'thumbs_up' | 'thumbs_down',
    reviewedBy: string,
    notes?: string
  ): Promise<AccessorResult<CallEnrichment>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .update({
          staff_rating: rating,
          staff_notes: notes,
          reviewed_by: reviewedBy,
          reviewed_at: new Date().toISOString(),
        })
        .eq('call_sid', callSid)
        .select()
        .single();
      
      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get calls needing escalation
   */
  async getEscalationNeeded(companyId: string): Promise<AccessorResult<CallEnrichment[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('company_id', companyId)
        .eq('escalation_needed', true)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get calls with low sentiment score
   */
  async getLowSentiment(
    companyId: string,
    threshold: number = 2.5
  ): Promise<AccessorResult<CallEnrichment[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('company_id', companyId)
        .lt('sentiment_score', threshold)
        .order('sentiment_score', { ascending: true });
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
}

export const callEnrichmentAccessor = new CallEnrichmentAccessor();
export default callEnrichmentAccessor;
