/**
 * Escalation Accessor
 * Manages escalation records for calls/SMS that need human review
 */

import { BaseAccessor, AccessorResult } from './BaseAccessor';
import { getSupabase } from '../db/connection';

export interface Escalation {
  id: string;
  company_id: string;
  office_id?: string;
  eyefinity_patient_id?: string;
  patient_name?: string;
  patient_phone?: string;
  source: 'ai' | 'staff' | 'system';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  reason: string;
  ai_suggested_action?: string;
  related_call_sid?: string;
  related_message_sid?: string;
  status: 'pending' | 'acknowledged' | 'in_progress' | 'resolved';
  assigned_to?: string;
  acknowledged_at?: string;
  resolved_by?: string;
  resolved_at?: string;
  resolution_notes?: string;
  created_at: string;
  updated_at: string;
}

export class EscalationAccessor extends BaseAccessor<Escalation> {
  protected tableName = 'escalations';

  /**
   * Get pending escalations for a company
   */
  async getPending(companyId: string): Promise<AccessorResult<Escalation[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('company_id', companyId)
        .in('status', ['pending', 'acknowledged', 'in_progress'])
        .order('priority', { ascending: false })
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get escalations by office
   */
  async getByOffice(officeId: string): Promise<AccessorResult<Escalation[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('office_id', officeId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Create AI-generated escalation
   */
  async createFromAI(data: {
    company_id: string;
    office_id?: string;
    patient_name?: string;
    patient_phone?: string;
    reason: string;
    ai_suggested_action?: string;
    related_call_sid?: string;
    related_message_sid?: string;
    priority?: 'low' | 'medium' | 'high' | 'urgent';
  }): Promise<AccessorResult<Escalation>> {
    return this.create({
      ...data,
      source: 'ai',
      priority: data.priority || 'medium',
      status: 'pending',
    });
  }

  /**
   * Acknowledge an escalation
   */
  async acknowledge(
    escalationId: string,
    userId: string
  ): Promise<AccessorResult<Escalation>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .update({
          status: 'acknowledged',
          assigned_to: userId,
          acknowledged_at: new Date().toISOString(),
        })
        .eq('id', escalationId)
        .select()
        .single();
      
      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Resolve an escalation
   */
  async resolve(
    escalationId: string,
    userId: string,
    notes?: string
  ): Promise<AccessorResult<Escalation>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .update({
          status: 'resolved',
          resolved_by: userId,
          resolved_at: new Date().toISOString(),
          resolution_notes: notes,
        })
        .eq('id', escalationId)
        .select()
        .single();
      
      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get escalation statistics for a company
   */
  async getStats(companyId: string): Promise<AccessorResult<{
    pending: number;
    resolved_today: number;
    avg_resolution_time_hours: number;
  }>> {
    try {
      const db = getSupabase();
      
      // Get pending count
      const { count: pendingCount } = await db
        .from(this.tableName)
        .select('*', { count: 'exact', head: true })
        .eq('company_id', companyId)
        .in('status', ['pending', 'acknowledged', 'in_progress']);
      
      // Get resolved today
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const { count: resolvedToday } = await db
        .from(this.tableName)
        .select('*', { count: 'exact', head: true })
        .eq('company_id', companyId)
        .eq('status', 'resolved')
        .gte('resolved_at', today.toISOString());
      
      return {
        success: true,
        data: {
          pending: pendingCount || 0,
          resolved_today: resolvedToday || 0,
          avg_resolution_time_hours: 0, // Would need more complex query
        },
      };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
}

export const escalationAccessor = new EscalationAccessor();
export default escalationAccessor;
