import { BaseAccessor } from './BaseAccessor';

export interface FrameCatalog {
  id: string;
  upc_code: string;
  manufacturer?: string;
  brand?: string;
  model_name?: string;
  model_number?: string;
  color_name?: string;
  color_code?: string;
  lens_width?: number;
  bridge_width?: number;
  temple_length?: number;
  frame_width?: number;
  material?: string;
  frame_type?: string;
  shape?: string;
  wholesale_price?: number;
  retail_price?: number;
  image_url?: string;
  additional_images?: string[];
  created_at?: string;
  updated_at?: string;
}

export class FrameCatalogAccessor extends BaseAccessor<FrameCatalog> {
  protected tableName = 'frame_catalog';

  async getByUPC(upcCode: string) {
    try {
      const supabase = await import('../db/connection').then(m => m.getSupabase());
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('upc_code', upcCode)
        .single();

      if (error) {
        console.error(`[FrameCatalogAccessor] Error fetching by UPC:`, error);
        return { success: false, error: error.message };
      }

      return { success: true, data };
    } catch (error: any) {
      console.error(`[FrameCatalogAccessor] Exception:`, error);
      return { success: false, error: error.message };
    }
  }

  async searchFrames(query: {
    brand?: string;
    manufacturer?: string;
    shape?: string;
    priceMin?: number;
    priceMax?: number;
  }) {
    try {
      const supabase = await import('../db/connection').then(m => m.getSupabase());
      let queryBuilder = supabase
        .from(this.tableName)
        .select('*');

      if (query.brand) {
        queryBuilder = queryBuilder.ilike('brand', `%${query.brand}%`);
      }
      if (query.manufacturer) {
        queryBuilder = queryBuilder.ilike('manufacturer', `%${query.manufacturer}%`);
      }
      if (query.shape) {
        queryBuilder = queryBuilder.eq('shape', query.shape);
      }
      if (query.priceMin !== undefined) {
        queryBuilder = queryBuilder.gte('retail_price', query.priceMin);
      }
      if (query.priceMax !== undefined) {
        queryBuilder = queryBuilder.lte('retail_price', query.priceMax);
      }

      const { data, error } = await queryBuilder.order('brand', { ascending: true });

      if (error) {
        console.error(`[FrameCatalogAccessor] Error searching:`, error);
        return { success: false, error: error.message };
      }

      return { success: true, data: data || [] };
    } catch (error: any) {
      console.error(`[FrameCatalogAccessor] Exception:`, error);
      return { success: false, error: error.message };
    }
  }
}

export const frameCatalogAccessor = new FrameCatalogAccessor();
