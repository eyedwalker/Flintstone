/**
 * Staff Accessor
 * Manages staff members including doctors, providers, technicians, etc.
 */

import { BaseAccessor, AccessorResult } from './BaseAccessor';
import { getSupabase } from '../db/connection';

export type StaffRole = 'doctor' | 'technician' | 'optician' | 'front_desk' | 'manager' | 'other';

export interface Staff {
  id: string;
  user_id?: string;
  name: string;
  email?: string;
  phone?: string;
  role: StaffRole;
  eyefinity_staff_id?: string;
  eyefinity_provider_id?: string;
  specialty?: string;
  active: boolean;
  created_at: string;
  updated_at: string;
  settings: Record<string, any>;
}

export interface StaffWithOffices extends Staff {
  offices?: any[];
}

export class StaffAccessor extends BaseAccessor<Staff> {
  protected tableName = 'staff';

  /**
   * Create a new staff member
   */
  async create(data: Omit<Staff, 'id' | 'created_at' | 'updated_at'>): Promise<AccessorResult<Staff>> {
    try {
      const db = getSupabase();
      const { data: staff, error } = await db
        .from(this.tableName)
        .insert({
          user_id: data.user_id,
          name: data.name,
          email: data.email,
          phone: data.phone,
          role: data.role,
          eyefinity_provider_id: data.eyefinity_provider_id,
          specialty: data.specialty,
          active: data.active ?? true,
          settings: data.settings || {}
        })
        .select()
        .single();
      
      if (error) throw error;
      
      return { success: true, data: staff };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get staff by ID
   */
  async getById(id: string): Promise<AccessorResult<Staff>> {
    try {
      const db = getSupabase();
      
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('id', id)
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      if (!data) return { success: false, error: 'Staff member not found' };
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get staff by Eyefinity provider ID
   */
  async getByEyefinityId(eyefinityProviderId: string): Promise<AccessorResult<Staff>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('eyefinity_provider_id', eyefinityProviderId)
        .maybeSingle(); // Use maybeSingle() to avoid errors when not found
      
      if (!data) {
        return { success: false, error: 'Staff member not found' };
      }
      
      if (error) {
        console.error('[StaffAccessor] Error getting staff by Eyefinity ID:', error);
        throw error;
      }
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get all active staff
   */
  async getActive(): Promise<AccessorResult<Staff[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('active', true)
        .order('name');
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get staff by role
   */
  async getByRole(role: StaffRole): Promise<AccessorResult<Staff[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('role', role)
        .eq('active', true)
        .order('name');
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get staff for a specific office
   */
  async getByOffice(officeId: string): Promise<AccessorResult<Staff[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from('staff_offices')
        .select(`
          staff (*)
        `)
        .eq('office_id', officeId);
      
      if (error) throw error;
      
      const staff = data?.map((item: any) => item.staff) || [];
      return { success: true, data: staff };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get all staff for a company (through offices)
   */
  async getByCompany(companyId: string): Promise<AccessorResult<Staff[]>> {
    try {
      const db = getSupabase();
      
      // Get all staff linked to offices belonging to this company
      const { data, error } = await db
        .from('staff')
        .select(`
          *,
          staff_offices!inner (
            office:offices!inner (
              company_id
            )
          )
        `)
        .eq('staff_offices.office.company_id', companyId)
        .eq('active', true)
        .order('name');
      
      if (error) throw error;
      
      // Deduplicate staff (same staff can be at multiple offices)
      const uniqueStaff = Array.from(
        new Map(data?.map(staff => [staff.id, staff])).values()
      );
      
      return { success: true, data: uniqueStaff || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Update staff member
   */
  async update(id: string, updates: Partial<Omit<Staff, 'id' | 'created_at' | 'updated_at'>>): Promise<AccessorResult<Staff>> {
    try {
      const db = getSupabase();
      
      const { data, error } = await db
        .from(this.tableName)
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      if (!data) return { success: false, error: 'Staff member not found' };
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Delete staff member (soft delete by setting inactive)
   */
  async delete(id: string): Promise<AccessorResult<boolean>> {
    try {
      const db = getSupabase();
      
      const { error } = await db
        .from(this.tableName)
        .update({ 
          active: false,
          updated_at: new Date().toISOString()
        })
        .eq('id', id);
      
      if (error) throw error;
      
      return { success: true, data: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Assign staff to office
   */
  async assignToOffice(staffId: string, officeId: string, isPrimary: boolean = false): Promise<AccessorResult<boolean>> {
    try {
      const db = getSupabase();
      
      const { error } = await db
        .from('staff_offices')
        .insert({
          staff_id: staffId,
          office_id: officeId,
          is_primary: isPrimary
        });
      
      if (error) throw error;
      
      return { success: true, data: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Remove staff from office
   */
  async removeFromOffice(staffId: string, officeId: string): Promise<AccessorResult<boolean>> {
    try {
      const db = getSupabase();
      
      const { error } = await db
        .from('staff_offices')
        .delete()
        .eq('staff_id', staffId)
        .eq('office_id', officeId);
      
      if (error) throw error;
      
      return { success: true, data: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get staff with their assigned offices
   */
  async getWithOffices(staffId: string): Promise<AccessorResult<StaffWithOffices>> {
    try {
      const db = getSupabase();
      
      const { data, error } = await db
        .from(this.tableName)
        .select(`
          *,
          staff_offices(
            office:offices(*)
          )
        `)
        .eq('id', staffId)
        .single();
      
      if (error) throw error;
      
      // Flatten office data
      const staff = {
        ...data,
        offices: data.staff_offices?.map((so: any) => so.office) || []
      };
      delete staff.staff_offices;
      
      return { success: true, data: staff };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Search staff by name
   */
  async searchByName(searchTerm: string): Promise<AccessorResult<Staff[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .ilike('name', `%${searchTerm}%`)
        .eq('active', true)
        .order('name');
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Bulk create staff members (useful for Eyefinity import)
   */
  async bulkCreate(staffList: Omit<Staff, 'id' | 'created_at' | 'updated_at'>[]): Promise<AccessorResult<Staff[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .insert(staffList.map(staff => ({
          user_id: staff.user_id,
          name: staff.name,
          email: staff.email,
          phone: staff.phone,
          role: staff.role,
          eyefinity_provider_id: staff.eyefinity_provider_id,
          specialty: staff.specialty,
          active: staff.active ?? true,
          settings: staff.settings || {}
        })))
        .select();
      
      if (error) throw error;
      
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
}

export const staffAccessor = new StaffAccessor();
export default staffAccessor;
