/**
 * Appointment Accessor
 * Manages appointment scheduling with Eyefinity sync
 */

import { BaseAccessor, AccessorResult } from './BaseAccessor';
import { getSupabase } from '../db/connection';

export type AppointmentStatus = 'scheduled' | 'confirmed' | 'checked_in' | 'in_progress' | 'completed' | 'cancelled' | 'no_show';

export interface Appointment {
  id: string;
  company_id: string;
  office_id: string;
  patient_id: string;
  provider_id?: string;
  eyefinity_appointment_id?: string;
  appointment_date: string;
  duration_minutes: number;
  appointment_type: string;
  status: AppointmentStatus;
  reason_for_visit?: string;
  notes?: string;
  reminder_sent: boolean;
  reminder_sent_at?: string;
  checked_in_at?: string;
  checked_out_at?: string;
  settings: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface AppointmentWithRelations extends Appointment {
  patient?: any;
  provider?: any;
  office?: any;
}

export class AppointmentAccessor extends BaseAccessor<Appointment> {
  protected tableName = 'appointments';

  async create(data: Omit<Appointment, 'id' | 'created_at' | 'updated_at'>): Promise<AccessorResult<Appointment>> {
    try {
      const db = getSupabase();
      const { data: appointment, error } = await db
        .from(this.tableName)
        .insert({
          company_id: data.company_id,
          office_id: data.office_id,
          patient_id: data.patient_id,
          provider_id: data.provider_id,
          eyefinity_appointment_id: data.eyefinity_appointment_id,
          appointment_date: data.appointment_date,
          duration_minutes: data.duration_minutes || 30,
          appointment_type: data.appointment_type,
          status: data.status || 'scheduled',
          reason_for_visit: data.reason_for_visit,
          notes: data.notes,
          reminder_sent: data.reminder_sent || false,
          reminder_sent_at: data.reminder_sent_at,
          checked_in_at: data.checked_in_at,
          checked_out_at: data.checked_out_at,
          settings: data.settings || {},
        })
        .select()
        .single();

      if (error) throw error;
      return { success: true, data: appointment };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async getByDateRange(officeId: string, startDate: string, endDate: string): Promise<AccessorResult<AppointmentWithRelations[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select(`
          *,
          patient:patients(id, first_name, last_name, phone),
          provider:staff(id, name),
          office:offices(id, name)
        `)
        .eq('office_id', officeId)
        .gte('appointment_date', startDate)
        .lte('appointment_date', endDate)
        .order('appointment_date', { ascending: true });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async getByPatient(patientId: string, companyId: string): Promise<AccessorResult<Appointment[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('patient_id', patientId)
        .eq('company_id', companyId)
        .order('appointment_date', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async getByEyefinityId(eyefinityAppointmentId: string, companyId: string): Promise<AccessorResult<Appointment>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('eyefinity_appointment_id', eyefinityAppointmentId)
        .eq('company_id', companyId)
        .maybeSingle();

      if (!data) {
        return { success: false, error: 'Appointment not found' };
      }

      if (error) {
        console.error('[AppointmentAccessor] Error getting appointment by Eyefinity ID:', error);
        throw error;
      }

      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async updateStatus(id: string, status: AppointmentStatus): Promise<AccessorResult<Appointment>> {
    try {
      const db = getSupabase();
      const updates: any = { status };
      
      if (status === 'checked_in') {
        updates.checked_in_at = new Date().toISOString();
      } else if (status === 'completed') {
        updates.checked_out_at = new Date().toISOString();
      }

      const { data, error } = await db
        .from(this.tableName)
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async update(id: string, updates: Partial<Appointment>): Promise<AccessorResult<Appointment>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
}

export const appointmentAccessor = new AppointmentAccessor();
