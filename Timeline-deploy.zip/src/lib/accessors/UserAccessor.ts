/**
 * User Accessor
 * Manages system users and their office assignments
 */

import { BaseAccessor, AccessorResult } from './BaseAccessor';
import { getSupabase } from '../db/connection';

export interface User {
  id: string;
  account_id: string;
  email: string;
  name?: string;
  password_hash?: string;
  role: 'super_admin' | 'admin' | 'staff' | 'viewer';
  settings: Record<string, any>;
  last_active_at?: string;
  created_at: string;
  updated_at: string;
}

export interface UserOffice {
  user_id: string;
  office_id: string;
  role: string;
  created_at: string;
}

export interface UserWithOffices extends User {
  offices: Array<{
    id: string;
    name: string;
    company_id: string;
    role: string;
  }>;
}

export class UserAccessor extends BaseAccessor<User> {
  protected tableName = 'users';

  /**
   * Get user by email
   */
  async getByEmail(email: string, accountId: string): Promise<AccessorResult<User>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('email', email.toLowerCase())
        .eq('account_id', accountId)
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      if (!data) return { success: false, error: 'Not found' };
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get user with their office assignments
   */
  async getWithOffices(userId: string): Promise<AccessorResult<UserWithOffices>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select(`
          *,
          user_offices (
            role,
            office:offices (
              id,
              name,
              company_id
            )
          )
        `)
        .eq('id', userId)
        .single();
      
      if (error) throw error;
      
      // Transform the nested structure
      const user: UserWithOffices = {
        ...data,
        offices: (data.user_offices || []).map((uo: any) => ({
          id: uo.office.id,
          name: uo.office.name,
          company_id: uo.office.company_id,
          role: uo.role,
        })),
      };
      delete (user as any).user_offices;
      
      return { success: true, data: user };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Assign user to office
   */
  async assignToOffice(
    userId: string,
    officeId: string,
    role: string = 'staff'
  ): Promise<AccessorResult<UserOffice>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from('user_offices')
        .upsert({
          user_id: userId,
          office_id: officeId,
          role,
        })
        .select()
        .single();
      
      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Remove user from office
   */
  async removeFromOffice(userId: string, officeId: string): Promise<AccessorResult<boolean>> {
    try {
      const db = getSupabase();
      const { error } = await db
        .from('user_offices')
        .delete()
        .eq('user_id', userId)
        .eq('office_id', officeId);
      
      if (error) throw error;
      return { success: true, data: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get all users for an account
   */
  async getByAccount(accountId: string): Promise<AccessorResult<User[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('account_id', accountId)
        .order('name');
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Update last active timestamp
   */
  async updateLastActive(userId: string): Promise<void> {
    try {
      const db = getSupabase();
      await db
        .from(this.tableName)
        .update({ last_active_at: new Date().toISOString() })
        .eq('id', userId);
    } catch (error) {
      console.error('[UserAccessor] updateLastActive error:', error);
    }
  }
}

export const userAccessor = new UserAccessor();
export default userAccessor;
