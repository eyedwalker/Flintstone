import { BaseAccessor } from './BaseAccessor';

export interface PatientFavoriteFrame {
  id: string;
  patient_id: string;
  company_id: string;
  upc_code: string;
  frame_name?: string;
  frame_manufacturer?: string;
  frame_model?: string;
  frame_color?: string;
  frame_size?: string;
  scanned_at: string;
  image_url?: string;
  notes?: string;
  is_purchased: boolean;
  purchased_at?: string;
}

export class PatientFavoriteFramesAccessor extends BaseAccessor<PatientFavoriteFrame> {
  protected tableName = 'patient_favorite_frames';

  async getByPatient(patientId: string, companyId: string) {
    try {
      const supabase = await import('../db/connection').then(m => m.getSupabase());
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('patient_id', patientId)
        .eq('company_id', companyId)
        .order('scanned_at', { ascending: false });

      if (error) {
        console.error(`[PatientFavoriteFramesAccessor] Error fetching by patient:`, error);
        return { success: false, error: error.message };
      }

      return { success: true, data: data || [] };
    } catch (error: any) {
      console.error(`[PatientFavoriteFramesAccessor] Exception:`, error);
      return { success: false, error: error.message };
    }
  }

  async addFavorite(favorite: Omit<PatientFavoriteFrame, 'id' | 'scanned_at'>) {
    try {
      const supabase = await import('../db/connection').then(m => m.getSupabase());
      const { data, error } = await supabase
        .from(this.tableName)
        .insert(favorite)
        .select()
        .single();

      if (error) {
        console.error(`[PatientFavoriteFramesAccessor] Error adding favorite:`, error);
        return { success: false, error: error.message };
      }

      return { success: true, data };
    } catch (error: any) {
      console.error(`[PatientFavoriteFramesAccessor] Exception:`, error);
      return { success: false, error: error.message };
    }
  }

  async markPurchased(id: string) {
    try {
      const supabase = await import('../db/connection').then(m => m.getSupabase());
      const { data, error } = await supabase
        .from(this.tableName)
        .update({ is_purchased: true, purchased_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error(`[PatientFavoriteFramesAccessor] Error marking purchased:`, error);
        return { success: false, error: error.message };
      }

      return { success: true, data };
    } catch (error: any) {
      console.error(`[PatientFavoriteFramesAccessor] Exception:`, error);
      return { success: false, error: error.message };
    }
  }
}

export const patientFavoriteFramesAccessor = new PatientFavoriteFramesAccessor();
