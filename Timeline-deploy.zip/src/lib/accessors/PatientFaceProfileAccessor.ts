import { BaseAccessor } from './BaseAccessor';

export interface PatientFaceProfile {
  id: string;
  patient_id: string;
  company_id: string;
  created_at: string;
  updated_at: string;
  face_width?: number;
  face_height?: number;
  jaw_width?: number;
  cheekbone_width?: number;
  forehead_width?: number;
  face_shape?: string;
  face_shape_confidence?: number;
  pd_total?: number;
  pd_right?: number;
  pd_left?: number;
  outline_points?: any;
  face_svg?: string;
  measurement_id?: string;
  recommended_frame_widths?: any;
  recommended_bridge_widths?: any;
  recommended_temple_lengths?: any;
  is_active: boolean;
  source?: string;
  notes?: string;
  // New 3D data fields
  depth_enhanced_geometry?: any;
  movement_quality_score?: number;
  reference_frame_id?: string;
}

export class PatientFaceProfileAccessor extends BaseAccessor<PatientFaceProfile> {
  protected tableName = 'patient_face_profiles';

  async getByPatient(patientId: string, companyId: string) {
    try {
      const supabase = await import('../db/connection').then(m => m.getSupabase());
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('patient_id', patientId)
        .eq('company_id', companyId)
        .eq('is_active', true)
        .order('updated_at', { ascending: false })
        .limit(1)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          return { success: true, data: null };
        }
        console.error(`[PatientFaceProfileAccessor] Error:`, error);
        return { success: false, error: error.message };
      }

      return { success: true, data };
    } catch (error: any) {
      console.error(`[PatientFaceProfileAccessor] Exception:`, error);
      return { success: false, error: error.message };
    }
  }

  async upsertProfile(profile: Omit<PatientFaceProfile, 'id' | 'created_at' | 'updated_at'>) {
    try {
      const supabase = await import('../db/connection').then(m => m.getSupabase());
      const { data, error } = await supabase
        .from(this.tableName)
        .upsert(
          { ...profile, updated_at: new Date().toISOString() },
          { onConflict: 'patient_id,company_id' }
        )
        .select()
        .single();

      if (error) {
        console.error(`[PatientFaceProfileAccessor] Upsert error:`, error);
        return { success: false, error: error.message };
      }

      return { success: true, data };
    } catch (error: any) {
      console.error(`[PatientFaceProfileAccessor] Exception:`, error);
      return { success: false, error: error.message };
    }
  }

  async getFrameRecommendations(patientId: string, companyId: string) {
    try {
      const supabase = await import('../db/connection').then(m => m.getSupabase());
      const { data, error } = await supabase
        .from(this.tableName)
        .select('face_shape, face_width, pd_total, recommended_frame_widths, recommended_bridge_widths, recommended_temple_lengths')
        .eq('patient_id', patientId)
        .eq('company_id', companyId)
        .eq('is_active', true)
        .single();

      if (error) {
        return { success: false, error: error.message };
      }

      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
}

export const patientFaceProfileAccessor = new PatientFaceProfileAccessor();
