/**
 * Accessors Index
 * Central export for all data accessors
 */

export * from './BaseAccessor';
export * from './CallEnrichmentAccessor';
export * from './EscalationAccessor';
export * from './CompanyAccessor';
export * from './UserAccessor';

// Default exports for convenience
export { default as callEnrichmentAccessor } from './CallEnrichmentAccessor';
export { default as escalationAccessor } from './EscalationAccessor';
export { default as companyAccessor } from './CompanyAccessor';
export { default as userAccessor } from './UserAccessor';
