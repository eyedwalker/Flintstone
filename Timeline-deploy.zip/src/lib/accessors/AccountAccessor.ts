/**
 * Account Accessor
 * Manages top-level tenant accounts with full CRUD operations
 */

import { BaseAccessor, AccessorResult } from './BaseAccessor';
import { getSupabase, setTenantContext } from '../db/connection';

export interface Account {
  id: string;
  name: string;
  created_at: string;
  updated_at: string;
  settings: Record<string, any>;
  status: 'active' | 'suspended' | 'cancelled';
}

export interface AccountWithRelations extends Account {
  companies?: any[];
}

export class AccountAccessor extends BaseAccessor<Account> {
  protected tableName = 'accounts';

  /**
   * Create a new account
   */
  async create(data: Omit<Account, 'id' | 'created_at' | 'updated_at'>): Promise<AccessorResult<Account>> {
    try {
      const db = getSupabase();
      const { data: account, error } = await db
        .from(this.tableName)
        .insert({
          name: data.name,
          settings: data.settings || {},
          status: data.status || 'active'
        })
        .select()
        .single();
      
      if (error) throw error;
      
      return { success: true, data: account };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get account by ID
   */
  async getById(id: string): Promise<AccessorResult<Account>> {
    try {
      const db = getSupabase();
      
      // Set tenant context for row-level security
      await setTenantContext(id);
      
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('id', id)
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      if (!data) return { success: false, error: 'Account not found' };
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get all accounts (super admin only)
   */
  async getAll(): Promise<AccessorResult<Account[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .order('name');
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Update account
   */
  async update(id: string, updates: Partial<Omit<Account, 'id' | 'created_at' | 'updated_at'>>): Promise<AccessorResult<Account>> {
    try {
      const db = getSupabase();
      
      // Set tenant context
      await setTenantContext(id);
      
      const { data, error } = await db
        .from(this.tableName)
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      if (!data) return { success: false, error: 'Account not found' };
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Delete account (soft delete by status)
   */
  async delete(id: string): Promise<AccessorResult<boolean>> {
    try {
      const db = getSupabase();
      
      // Set tenant context
      await setTenantContext(id);
      
      // Soft delete by setting status to 'cancelled'
      const { error } = await db
        .from(this.tableName)
        .update({ 
          status: 'cancelled',
          updated_at: new Date().toISOString()
        })
        .eq('id', id);
      
      if (error) throw error;
      
      return { success: true, data: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get account with its companies
   */
  async getWithCompanies(accountId: string): Promise<AccessorResult<AccountWithRelations>> {
    try {
      const db = getSupabase();
      
      // Set tenant context
      await setTenantContext(accountId);
      
      const { data, error } = await db
        .from(this.tableName)
        .select(`
          *,
          companies (*)
        `)
        .eq('id', accountId)
        .single();
      
      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Search accounts by name
   */
  async searchByName(searchTerm: string): Promise<AccessorResult<Account[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .ilike('name', `%${searchTerm}%`)
        .order('name');
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get accounts by status
   */
  async getByStatus(status: Account['status']): Promise<AccessorResult<Account[]>> {
    try {
      const db = getSupabase();
      const { data, error } = await db
        .from(this.tableName)
        .select('*')
        .eq('status', status)
        .order('name');
      
      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Update account settings
   */
  async updateSettings(accountId: string, settings: Record<string, any>): Promise<AccessorResult<Account>> {
    try {
      const db = getSupabase();
      
      // Set tenant context
      await setTenantContext(accountId);
      
      const { data, error } = await db
        .from(this.tableName)
        .update({ 
          settings,
          updated_at: new Date().toISOString()
        })
        .eq('id', accountId)
        .select()
        .single();
      
      if (error) throw error;
      if (!data) return { success: false, error: 'Account not found' };
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
}

export const accountAccessor = new AccountAccessor();
export default accountAccessor;
