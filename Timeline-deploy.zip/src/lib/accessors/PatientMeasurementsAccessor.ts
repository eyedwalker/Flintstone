import { BaseAccessor } from './BaseAccessor';

export interface PatientMeasurement {
  id: string;
  patient_id: string;
  company_id: string;
  measured_at: string;
  pd_right?: number;
  pd_left?: number;
  pd_total?: number;
  seg_height_right?: number;
  seg_height_left?: number;
  oc_height_right?: number;
  oc_height_left?: number;
  frame_id?: string;
  measurement_method: string;
  calibration_factor?: number;
  confidence_score?: number;
  device_type?: string;
  device_model?: string;
  has_lidar: boolean;
  browser_info?: string;
  face_landmarks?: any;
  frame_markers?: any;
  calibration_data?: any;
  image_url?: string;
  verified_by_staff?: string;
  verified_at?: string;
  is_approved: boolean;
  staff_notes?: string;
  notes?: string;
  // New 3D data fields
  movement_sequence?: any;
  depth_map?: any;
  has_3d_data?: boolean;
  movement_quality_score?: number;
  reference_frame_id?: string;
}

export class PatientMeasurementsAccessor extends BaseAccessor<PatientMeasurement> {
  protected tableName = 'patient_measurements';

  async getByPatient(patientId: string, companyId: string) {
    try {
      const supabase = await import('../db/connection').then(m => m.getSupabase());
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('patient_id', patientId)
        .eq('company_id', companyId)
        .order('measured_at', { ascending: false });

      if (error) {
        console.error(`[PatientMeasurementsAccessor] Error fetching by patient:`, error);
        return { success: false, error: error.message };
      }

      return { success: true, data: data || [] };
    } catch (error: any) {
      console.error(`[PatientMeasurementsAccessor] Exception:`, error);
      return { success: false, error: error.message };
    }
  }

  async getLatestByPatient(patientId: string, companyId: string) {
    try {
      const supabase = await import('../db/connection').then(m => m.getSupabase());
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('patient_id', patientId)
        .eq('company_id', companyId)
        .order('measured_at', { ascending: false })
        .limit(1)
        .single();

      if (error) {
        console.error(`[PatientMeasurementsAccessor] Error fetching latest:`, error);
        return { success: false, error: error.message };
      }

      return { success: true, data };
    } catch (error: any) {
      console.error(`[PatientMeasurementsAccessor] Exception:`, error);
      return { success: false, error: error.message };
    }
  }

  async saveMeasurement(measurement: Omit<PatientMeasurement, 'id' | 'measured_at'>) {
    try {
      const supabase = await import('../db/connection').then(m => m.getSupabase());
      const { data, error } = await supabase
        .from(this.tableName)
        .insert(measurement)
        .select()
        .single();

      if (error) {
        console.error(`[PatientMeasurementsAccessor] Error saving measurement:`, error);
        return { success: false, error: error.message };
      }

      return { success: true, data };
    } catch (error: any) {
      console.error(`[PatientMeasurementsAccessor] Exception:`, error);
      return { success: false, error: error.message };
    }
  }

  async approveMeasurement(id: string, staffId: string, notes?: string) {
    try {
      const supabase = await import('../db/connection').then(m => m.getSupabase());
      const { data, error } = await supabase
        .from(this.tableName)
        .update({
          is_approved: true,
          verified_by_staff: staffId,
          verified_at: new Date().toISOString(),
          staff_notes: notes
        })
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error(`[PatientMeasurementsAccessor] Error approving measurement:`, error);
        return { success: false, error: error.message };
      }

      return { success: true, data };
    } catch (error: any) {
      console.error(`[PatientMeasurementsAccessor] Exception:`, error);
      return { success: false, error: error.message };
    }
  }

  async getPendingApprovals(companyId: string) {
    try {
      const supabase = await import('../db/connection').then(m => m.getSupabase());
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('company_id', companyId)
        .eq('is_approved', false)
        .order('measured_at', { ascending: false });

      if (error) {
        console.error(`[PatientMeasurementsAccessor] Error fetching pending:`, error);
        return { success: false, error: error.message };
      }

      return { success: true, data: data || [] };
    } catch (error: any) {
      console.error(`[PatientMeasurementsAccessor] Exception:`, error);
      return { success: false, error: error.message };
    }
  }
}

export const patientMeasurementsAccessor = new PatientMeasurementsAccessor();
