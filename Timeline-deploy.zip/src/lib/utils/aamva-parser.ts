/**
 * AAMVA Barcode Parser
 * Parses PDF417 barcode data from US driver's licenses (AAMVA standard)
 * into form-compatible field values for patient intake forms.
 */

export interface ParsedLicenseData {
  firstName?: string;
  lastName?: string;
  dateOfBirth?: string;  // YYYY-MM-DD
  gender?: string;       // 'male' | 'female' | 'other'
  address?: string;
  city?: string;
  state?: string;        // 2-letter state code
  zipCode?: string;      // 5 digits
}

function titleCase(str: string): string {
  return str
    .toLowerCase()
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ')
    .trim();
}

/**
 * Parse raw AAMVA barcode string into structured form fields.
 *
 * AAMVA barcodes use 3-letter field codes followed by the value.
 * Lines are separated by \n, \r\n, or DL/IDEN record separators.
 * Common codes: DCS=last name, DAC/DCT=first name, DBB=DOB,
 * DBC=gender, DAG=street, DAI=city, DAJ=state, DAK=zip.
 */
export function parseAAMVABarcode(rawData: string): ParsedLicenseData {
  const result: ParsedLicenseData = {};

  // Split on common line separators (newline, carriage return, or record separator \x1e)
  const lines = rawData.split(/[\n\r\x1e]+/);

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.length < 4) continue;

    const code = trimmed.substring(0, 3);
    const value = trimmed.substring(3).trim();

    if (!value) continue;

    switch (code) {
      case 'DCS': // Last name
        result.lastName = titleCase(value);
        break;

      case 'DAC': // First name (standard)
      case 'DCT': // First name (compact encoding, some states)
        if (!result.firstName) {
          // DCT may contain full name with spaces/commas — take first part
          const firstName = value.split(/[,\s]/)[0];
          result.firstName = titleCase(firstName);
        }
        break;

      case 'DBB': // Date of birth — MMDDYYYY
        if (value.length >= 8) {
          const mm = value.substring(0, 2);
          const dd = value.substring(2, 4);
          const yyyy = value.substring(4, 8);
          // Validate it looks like a date
          if (!isNaN(Number(mm)) && !isNaN(Number(dd)) && !isNaN(Number(yyyy))) {
            result.dateOfBirth = `${yyyy}-${mm}-${dd}`;
          }
        }
        break;

      case 'DBC': // Gender — 1=Male, 2=Female, 9=Not specified
        if (value === '1') result.gender = 'male';
        else if (value === '2') result.gender = 'female';
        else result.gender = 'other';
        break;

      case 'DAG': // Street address
        result.address = titleCase(value);
        break;

      case 'DAI': // City
        result.city = titleCase(value);
        break;

      case 'DAJ': // State — 2-letter code
        result.state = value.toUpperCase().substring(0, 2);
        break;

      case 'DAK': // ZIP code — may be 5 or 9 digits (sometimes with trailing spaces)
        result.zipCode = value.replace(/\s/g, '').substring(0, 5);
        break;
    }
  }

  return result;
}
