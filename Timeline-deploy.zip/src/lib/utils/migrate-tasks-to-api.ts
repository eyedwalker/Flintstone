/**
 * Task Migration Utility
 * Migrates tasks from localStorage (task-management-service) to API (TaskService)
 * 
 * Run this once to migrate existing localStorage tasks to the API backend
 */

import { taskManager } from '../services/task-management-service';
import { TaskService } from '../../services/taskService';

export interface MigrationResult {
  success: boolean;
  migrated: number;
  failed: number;
  errors: Array<{ taskId: string; error: string }>;
  localStorageBefore: number;
  localStorageAfter: number;
}

/**
 * Map localStorage task to API task format
 */
function mapLocalStorageTaskToApi(localTask: any) {
  return {
    title: localTask.title,
    description: localTask.description,
    status: mapStatus(localTask.status),
    priority: mapPriority(localTask.priority),
    category: localTask.category || 'general',
    channel: 'internal',
    assignee: localTask.assignedTo,
    dueAt: localTask.dueDate?.toISOString(),
    metadata: {
      ...localTask.metadata,
      patientId: localTask.patientId,
      patientName: localTask.patientName,
      journeyId: localTask.journeyId,
      migratedFrom: 'localStorage',
      migratedAt: new Date().toISOString(),
      originalId: localTask.id,
      aiCompletable: localTask.aiCompletable,
      aiPrompt: localTask.aiPrompt,
      aiCompletedBy: localTask.aiCompletedBy,
      aiCompletedAt: localTask.aiCompletedAt?.toISOString(),
      completedDate: localTask.completedDate?.toISOString(),
      notes: localTask.notes
    },
    source: {
      type: 'localStorage_migration',
      originalId: localTask.id,
      journeyId: localTask.journeyId,
      patientId: localTask.patientId
    }
  };
}

/**
 * Map localStorage status to API status
 */
function mapStatus(status: string): 'pending' | 'in_progress' | 'completed' | 'blocked' {
  switch (status) {
    case 'pending':
      return 'pending';
    case 'in-progress':
      return 'in_progress';
    case 'completed':
      return 'completed';
    case 'cancelled':
    case 'overdue':
      return 'blocked';
    default:
      return 'pending';
  }
}

/**
 * Map localStorage priority to API priority
 */
function mapPriority(priority: string): 'low' | 'normal' | 'high' | 'urgent' {
  switch (priority) {
    case 'low':
      return 'low';
    case 'medium':
      return 'normal';
    case 'high':
      return 'high';
    default:
      return 'normal';
  }
}

/**
 * Migrate all tasks from localStorage to API
 */
export async function migrateTasksToApi(): Promise<MigrationResult> {
  console.log('🔄 Starting task migration from localStorage to API...\n');
  
  const result: MigrationResult = {
    success: false,
    migrated: 0,
    failed: 0,
    errors: [],
    localStorageBefore: 0,
    localStorageAfter: 0
  };
  
  try {
    // Get all tasks from localStorage
    const localTasks = taskManager.getAllTasks();
    result.localStorageBefore = localTasks.length;
    
    console.log(`Found ${localTasks.length} tasks in localStorage`);
    
    if (localTasks.length === 0) {
      console.log('No tasks to migrate');
      result.success = true;
      return result;
    }
    
    // Migrate each task
    for (const localTask of localTasks) {
      try {
        const apiTask = mapLocalStorageTaskToApi(localTask);
        
        // Create task via API
        await TaskService.createTask(apiTask);
        
        result.migrated++;
        console.log(`✓ Migrated: ${localTask.title} (${localTask.id})`);
      } catch (error: any) {
        result.failed++;
        result.errors.push({
          taskId: localTask.id,
          error: error.message || String(error)
        });
        console.error(`✗ Failed to migrate: ${localTask.title} (${localTask.id})`, error.message);
      }
    }
    
    result.localStorageAfter = taskManager.getAllTasks().length;
    result.success = result.failed === 0;
    
    console.log('\n📊 Migration Summary:');
    console.log(`   Total tasks: ${result.localStorageBefore}`);
    console.log(`   Migrated: ${result.migrated}`);
    console.log(`   Failed: ${result.failed}`);
    
    if (result.errors.length > 0) {
      console.log('\n❌ Errors:');
      result.errors.forEach(e => {
        console.log(`   ${e.taskId}: ${e.error}`);
      });
    }
    
    if (result.success) {
      console.log('\n✅ Migration completed successfully!');
      console.log('⚠️  localStorage tasks are still present. Run clearLocalStorageTasks() to remove them after verifying API tasks.');
    } else {
      console.log('\n⚠️  Migration completed with errors. Review errors above.');
    }
    
    return result;
  } catch (error: any) {
    console.error('Migration failed:', error);
    result.success = false;
    return result;
  }
}

/**
 * Clear localStorage tasks after successful migration
 * Only call this after verifying API tasks are correct!
 */
export function clearLocalStorageTasks(): void {
  const confirmed = window.confirm(
    'Are you sure you want to clear localStorage tasks?\n\n' +
    'Make sure you have verified that all tasks were migrated to the API successfully!\n\n' +
    'This action cannot be undone!'
  );
  
  if (confirmed) {
    const count = taskManager.getAllTasks().length;
    taskManager.clearAllTasks();
    console.log(`🗑️  Cleared ${count} tasks from localStorage`);
    console.log('✅ Migration complete! All tasks now use the API backend.');
  } else {
    console.log('❌ Cancelled');
  }
}

/**
 * Preview migration without actually migrating
 */
export function previewMigration(): void {
  const localTasks = taskManager.getAllTasks();
  
  console.log('🔍 Migration Preview\n');
  console.log(`Tasks to migrate: ${localTasks.length}\n`);
  
  if (localTasks.length === 0) {
    console.log('No tasks to migrate');
    return;
  }
  
  console.log('Tasks by status:');
  const byStatus = localTasks.reduce((acc: any, task) => {
    acc[task.status] = (acc[task.status] || 0) + 1;
    return acc;
  }, {});
  Object.entries(byStatus).forEach(([status, count]) => {
    console.log(`   ${status}: ${count}`);
  });
  
  console.log('\nTasks by category:');
  const byCategory = localTasks.reduce((acc: any, task) => {
    acc[task.category] = (acc[task.category] || 0) + 1;
    return acc;
  }, {});
  Object.entries(byCategory).forEach(([category, count]) => {
    console.log(`   ${category}: ${count}`);
  });
  
  console.log('\nSample tasks:');
  localTasks.slice(0, 5).forEach(task => {
    console.log(`   - ${task.title} (${task.status}, ${task.priority})`);
  });
  
  if (localTasks.length > 5) {
    console.log(`   ... and ${localTasks.length - 5} more`);
  }
  
  console.log('\n💡 Run taskMigration.migrate() to start migration');
}

/**
 * Export migration functions to window for console access
 */
if (typeof window !== 'undefined') {
  (window as any).taskMigration = {
    preview: previewMigration,
    migrate: migrateTasksToApi,
    clear: clearLocalStorageTasks
  };
  
  console.log(
    '💡 Task migration utilities loaded!\n' +
    '   Use: taskMigration.preview()  - Preview what will be migrated\n' +
    '   Use: taskMigration.migrate()  - Migrate localStorage tasks to API\n' +
    '   Use: taskMigration.clear()    - Clear localStorage after migration\n'
  );
}
