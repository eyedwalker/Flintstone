/**
 * Task Cleanup Utility
 * Run this from browser console to clean up corrupted/orphaned tasks
 * 
 * Usage in console:
 * import { cleanupTasksNow } from './lib/utils/task-cleanup-utility';
 * cleanupTasksNow();
 */

import { taskManager } from '../services/task-management-service';
import { PatientJourneyService } from '../services/patient-journey-service';

export interface CleanupReport {
  untitled: number;
  orphaned: number;
  old: number;
  total: number;
  before: number;
  after: number;
}

/**
 * Run comprehensive cleanup of task data
 * Removes untitled, orphaned, and old completed tasks
 */
export function cleanupTasksNow(): CleanupReport {
  console.log('🧹 Starting task cleanup...\n');
  
  const beforeCount = taskManager.getAllTasks().length;
  console.log(`Tasks before cleanup: ${beforeCount}`);
  
  // Get valid journey IDs
  const validJourneyIds = PatientJourneyService.getAllJourneys().map(j => j.id);
  console.log(`Valid journeys: ${validJourneyIds.length}`);
  
  // Run cleanup
  const results = taskManager.cleanupAll(validJourneyIds);
  
  const afterCount = taskManager.getAllTasks().length;
  
  const report: CleanupReport = {
    ...results,
    total: results.untitled + results.orphaned + results.old,
    before: beforeCount,
    after: afterCount
  };
  
  console.log('\n✅ Cleanup complete!');
  console.log(`   Untitled tasks removed: ${report.untitled}`);
  console.log(`   Orphaned tasks removed: ${report.orphaned}`);
  console.log(`   Old completed tasks removed: ${report.old}`);
  console.log(`   Total removed: ${report.total}`);
  console.log(`   Tasks remaining: ${report.after}\n`);
  
  return report;
}

/**
 * Preview what would be cleaned without actually removing
 */
export function previewCleanup(): CleanupReport {
  console.log('🔍 Previewing cleanup (no changes will be made)...\n');
  
  const allTasks = taskManager.getAllTasks();
  const beforeCount = allTasks.length;
  
  // Count untitled
  const untitled = allTasks.filter(t => !t.title || t.title.trim().length < 3).length;
  
  // Count orphaned
  const validJourneyIds = PatientJourneyService.getAllJourneys().map(j => j.id);
  const orphaned = allTasks.filter(t => !validJourneyIds.includes(t.journeyId)).length;
  
  // Count old completed
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - 30);
  const old = allTasks.filter(t => {
    if (t.status !== 'completed' && t.status !== 'cancelled') return false;
    const completedDate = t.completedDate || t.createdDate;
    return completedDate < cutoffDate;
  }).length;
  
  const total = untitled + orphaned + old;
  const after = beforeCount - total;
  
  const report: CleanupReport = {
    untitled,
    orphaned,
    old,
    total,
    before: beforeCount,
    after
  };
  
  console.log('Preview Results:');
  console.log(`   Current tasks: ${report.before}`);
  console.log(`   Would remove ${report.untitled} untitled tasks`);
  console.log(`   Would remove ${report.orphaned} orphaned tasks`);
  console.log(`   Would remove ${report.old} old completed tasks`);
  console.log(`   Total to remove: ${report.total}`);
  console.log(`   Tasks after cleanup: ${report.after}\n`);
  
  return report;
}

/**
 * Clear ALL tasks (use with caution!)
 */
export function clearAllTasksConfirm(): void {
  const confirmed = window.confirm(
    'Are you sure you want to DELETE ALL TASKS?\n\n' +
    'This action cannot be undone!'
  );
  
  if (confirmed) {
    const count = taskManager.getAllTasks().length;
    taskManager.clearAllTasks();
    console.log(`🗑️ Deleted all ${count} tasks`);
  } else {
    console.log('❌ Cancelled');
  }
}

/**
 * Export cleanup functions to window for easy console access
 */
if (typeof window !== 'undefined') {
  (window as any).taskCleanup = {
    preview: previewCleanup,
    cleanup: cleanupTasksNow,
    clearAll: clearAllTasksConfirm,
    debug: () => taskManager.debugTasks()
  };
  
  console.log(
    '💡 Task cleanup utilities loaded!\n' +
    '   Use: taskCleanup.preview()  - Preview what would be cleaned\n' +
    '   Use: taskCleanup.cleanup()  - Run cleanup now\n' +
    '   Use: taskCleanup.clearAll() - Delete all tasks (caution!)\n' +
    '   Use: taskCleanup.debug()    - Show debug info\n'
  );
}
