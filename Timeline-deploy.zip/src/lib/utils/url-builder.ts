/**
 * URL Builder Utility
 * Handles mail merge for building URLs with patient and appointment data
 */

export interface MailMergeContext {
  patientId?: string;
  legacyPatientId?: string;
  patientName?: string;
  appointmentId?: string;
  legacyAppointmentId?: string;
  providerId?: string;
  providerName?: string;
  reasonForVisit?: string;
  journeyId?: string;
  stepId?: string;
  [key: string]: string | undefined;
}

/**
 * Build a URL from a template using mail merge
 * Replaces placeholders like {patientId} with actual values
 */
export function buildUrlFromTemplate(
  template: string,
  context: MailMergeContext
): string {
  if (!template) return '';

  let url = template;

  // Replace all placeholders with actual values
  Object.keys(context).forEach(key => {
    const value = context[key];
    if (value !== undefined && value !== null) {
      const placeholder = `{${key}}`;
      // Use encodeURIComponent for proper URL encoding
      url = url.replace(new RegExp(placeholder.replace(/[{}]/g, '\\$&'), 'g'), encodeURIComponent(value));
    }
  });

  // Remove any remaining unreplaced placeholders
  url = url.replace(/\{[^}]+\}/g, '');

  return url;
}

/**
 * Extract mail merge context from a journey object
 * Uses legacy IDs for external system integration (Encompass, etc.)
 */
export function extractContextFromJourney(journey: any): MailMergeContext {
  return {
    patientId: journey?.patientId || '',
    legacyPatientId: journey?.legacyPatientId || '',
    patientName: journey?.patientName || '',
    appointmentId: journey?.appointmentId || '',
    legacyAppointmentId: journey?.legacyAppointmentId || '',
    providerId: journey?.providerId || '',
    providerName: journey?.providerName || '',
    reasonForVisit: journey?.reasonForVisit || '',
    journeyId: journey?.id || '',
    stepId: journey?.currentStepId || ''
  };
}

/**
 * Validate if a URL template has valid placeholders
 */
export function validateUrlTemplate(template: string): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (!template) {
    return { valid: true, errors: [] }; // Empty template is valid
  }

  // Check for malformed placeholders
  const malformedPlaceholders = template.match(/\{[^}]*$/g) || template.match(/[^{]*\}/g);
  if (malformedPlaceholders) {
    errors.push('Template contains malformed placeholders');
  }

  // Check if URL is valid
  try {
    // Replace placeholders with dummy values for validation
    const testUrl = template.replace(/\{[^}]+\}/g, 'test');
    new URL(testUrl);
  } catch (e) {
    errors.push('Template does not form a valid URL');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}
