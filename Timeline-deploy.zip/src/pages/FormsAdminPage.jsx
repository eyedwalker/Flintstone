/**
 * Forms Admin Page
 * Staff interface to manage form templates and view submissions
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FormSubmissionService } from '../lib/services/form-submission-service';
import FormManager from '../components/forms/FormManager';
import FormCustomizer from '../components/forms/FormCustomizer';
import { 
  FileText, 
  Plus, 
  ArrowLeft,
  Layers,
  Send,
  Clock,
  CheckCircle,
  Eye,
  AlertCircle,
  Copy,
  ExternalLink,
  Search,
  Filter,
  Edit,
  Trash2,
  MoreVertical,
  Users,
  BarChart3,
  Settings
} from 'lucide-react';

// Status badge configuration
const STATUS_CONFIG = {
  sent: { label: 'Sent', bg: 'bg-blue-100', text: 'text-blue-700', icon: Send },
  viewed: { label: 'Viewed', bg: 'bg-yellow-100', text: 'text-yellow-700', icon: Eye },
  in_progress: { label: 'In Progress', bg: 'bg-purple-100', text: 'text-purple-700', icon: Clock },
  completed: { label: 'Completed', bg: 'bg-green-100', text: 'text-green-700', icon: CheckCircle },
  expired: { label: 'Expired', bg: 'bg-gray-100', text: 'text-gray-700', icon: AlertCircle },
};

export default function FormsAdminPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('templates');
  const [templates, setTemplates] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showSendModal, setShowSendModal] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [sendFormData, setSendFormData] = useState({
    patientName: '',
    patientEmail: '',
    patientPhone: '',
  });
  const [prefillOptions, setPrefillOptions] = useState({
    enabled: true,
    autoAcceptAcknowledgements: true,
    autoSignWithName: true,
    prefillDate: true,
  });
  const [copiedLink, setCopiedLink] = useState(null);
  const [customizingTemplate, setCustomizingTemplate] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const allTemplates = FormSubmissionService.getTemplates();
    setTemplates(allTemplates);

    const allSubmissions = await FormSubmissionService.fetchAllSubmissions();
    setSubmissions(allSubmissions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
  };

  const handleCopyLink = (accessLink) => {
    navigator.clipboard.writeText(accessLink);
    setCopiedLink(accessLink);
    setTimeout(() => setCopiedLink(null), 2000);
  };

  const handleSendForm = async () => {
    if (!selectedTemplate || !sendFormData.patientName) return;

    const submission = FormSubmissionService.createSubmission({
      patientId: `patient_${Date.now()}`,
      patientName: sendFormData.patientName,
      patientEmail: sendFormData.patientEmail,
      patientPhone: sendFormData.patientPhone,
      templateId: selectedTemplate.id,
      prefillOptions: prefillOptions,
    });

    await FormSubmissionService.sendFormToPatient(
      submission.submissionId,
      sendFormData.patientEmail,
      sendFormData.patientPhone
    );

    setShowSendModal(false);
    setSelectedTemplate(null);
    setSendFormData({ patientName: '', patientEmail: '', patientPhone: '' });
    setPrefillOptions({ enabled: true, autoAcceptAcknowledgements: true, autoSignWithName: true, prefillDate: true });
    loadData();
  };

  // Filter submissions
  const filteredSubmissions = submissions.filter(s => {
    if (statusFilter !== 'all' && s.status !== statusFilter) return false;
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        s.formTitle.toLowerCase().includes(query) ||
        s.patientName?.toLowerCase().includes(query)
      );
    }
    return true;
  });

  // Stats
  const stats = {
    total: submissions.length,
    completed: submissions.filter(s => s.status === 'completed').length,
    pending: submissions.filter(s => ['sent', 'viewed', 'in_progress'].includes(s.status)).length,
    templates: templates.filter(t => t.isPublished && !t.isArchived).length,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/prc')}
                className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Forms Management</h1>
                <p className="text-sm text-gray-500">Create, send, and manage patient forms</p>
              </div>
            </div>
            <button
              onClick={() => setShowSendModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
            >
              <Send className="w-4 h-4" />
              Send Form
            </button>
          </div>
        </div>
      </header>

      {/* Stats */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-xl p-4 border border-gray-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <Layers className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{stats.templates}</p>
                <p className="text-sm text-gray-500">Templates</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl p-4 border border-gray-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Send className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
                <p className="text-sm text-gray-500">Total Sent</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl p-4 border border-gray-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Clock className="w-5 h-5 text-yellow-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{stats.pending}</p>
                <p className="text-sm text-gray-500">Pending</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl p-4 border border-gray-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{stats.completed}</p>
                <p className="text-sm text-gray-500">Completed</p>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-gray-100 p-1 rounded-lg w-fit">
          <button
            onClick={() => setActiveTab('templates')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'templates'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Layers className="w-4 h-4 inline mr-2" />
            Templates
          </button>
          <button
            onClick={() => setActiveTab('submissions')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'submissions'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <FileText className="w-4 h-4 inline mr-2" />
            Submissions
          </button>
        </div>

        {/* Templates Tab */}
        {activeTab === 'templates' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Form Templates</h2>
              <button
                onClick={() => alert('Form Builder coming soon! For now, templates are defined in code.')}
                className="flex items-center gap-2 px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                <Plus className="w-4 h-4" />
                Create Template
              </button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {templates.map(template => (
                <div
                  key={template.id}
                  className="bg-white rounded-xl border border-gray-200 p-5 hover:border-purple-300 transition-colors"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <FileText className="w-5 h-5 text-purple-600" />
                    </div>
                    <div className="flex items-center gap-1">
                      {template.isSystem && (
                        <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded">System</span>
                      )}
                      {template.isPublished && (
                        <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded">Published</span>
                      )}
                    </div>
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-1">{template.title}</h3>
                  {template.description && (
                    <p className="text-sm text-gray-500 mb-3 line-clamp-2">{template.description}</p>
                  )}
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">{template.sections?.length || 0} sections</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setCustomizingTemplate(template)}
                        className="flex items-center gap-1 text-gray-500 hover:text-gray-700"
                        title="Customize form"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          setSelectedTemplate(template);
                          setShowSendModal(true);
                        }}
                        className="flex items-center gap-1 text-purple-600 hover:text-purple-700"
                      >
                        <Send className="w-4 h-4" />
                        Send
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Submissions Tab */}
        {activeTab === 'submissions' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Form Submissions</h2>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm w-64"
                  />
                </div>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg text-sm"
                >
                  <option value="all">All Status</option>
                  <option value="sent">Sent</option>
                  <option value="viewed">Viewed</option>
                  <option value="in_progress">In Progress</option>
                  <option value="completed">Completed</option>
                  <option value="expired">Expired</option>
                </select>
              </div>
            </div>

            {filteredSubmissions.length === 0 ? (
              <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
                <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No submissions found</p>
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Form</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Patient</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sent</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Views</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {filteredSubmissions.map(submission => {
                      const status = STATUS_CONFIG[submission.status] || STATUS_CONFIG.sent;
                      const StatusIcon = status.icon;
                      
                      return (
                        <tr key={submission.submissionId} className="hover:bg-gray-50">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-3">
                              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${status.bg}`}>
                                <StatusIcon className={`w-4 h-4 ${status.text}`} />
                              </div>
                              <span className="font-medium text-gray-900">{submission.formTitle}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-600">
                            {submission.patientName || 'Unknown'}
                          </td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 rounded text-xs font-medium ${status.bg} ${status.text}`}>
                              {status.label}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-500">
                            {new Date(submission.createdAt).toLocaleDateString()}
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-500">
                            {submission.viewCount || 0}
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center justify-end gap-1">
                              <button
                                onClick={() => handleCopyLink(submission.accessLink)}
                                className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded"
                                title="Copy link"
                              >
                                {copiedLink === submission.accessLink ? (
                                  <CheckCircle className="w-4 h-4 text-green-600" />
                                ) : (
                                  <Copy className="w-4 h-4" />
                                )}
                              </button>
                              <button
                                onClick={() => window.open(submission.accessLink, '_blank')}
                                className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded"
                                title="Open form"
                              >
                                <ExternalLink className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Send Form Modal */}
      {showSendModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Send Form</h3>

              {!selectedTemplate ? (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  <p className="text-sm text-gray-600 mb-2">Select a form template:</p>
                  {templates.filter(t => t.isPublished).map(template => (
                    <button
                      key={template.id}
                      onClick={() => setSelectedTemplate(template)}
                      className="w-full p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 text-left"
                    >
                      <h4 className="font-medium text-gray-900">{template.title}</h4>
                      {template.description && (
                        <p className="text-sm text-gray-500 mt-1">{template.description}</p>
                      )}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="p-3 bg-purple-50 rounded-lg">
                    <p className="font-medium text-purple-900">{selectedTemplate.title}</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Patient Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={sendFormData.patientName}
                      onChange={(e) => setSendFormData(prev => ({ ...prev, patientName: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                      placeholder="Enter patient name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input
                      type="email"
                      value={sendFormData.patientEmail}
                      onChange={(e) => setSendFormData(prev => ({ ...prev, patientEmail: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                      placeholder="patient@email.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                    <input
                      type="tel"
                      value={sendFormData.patientPhone}
                      onChange={(e) => setSendFormData(prev => ({ ...prev, patientPhone: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                      placeholder="(555) 123-4567"
                    />
                  </div>

                  {/* Prefill Options */}
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <p className="text-sm font-medium text-gray-700 mb-3">Prefill Options</p>
                    <div className="space-y-2">
                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={prefillOptions.enabled}
                          onChange={(e) => setPrefillOptions(prev => ({ ...prev, enabled: e.target.checked }))}
                          className="w-4 h-4 text-purple-600 rounded"
                        />
                        <span className="text-sm text-gray-700">Prefill with patient info</span>
                      </label>
                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={prefillOptions.autoAcceptAcknowledgements}
                          onChange={(e) => setPrefillOptions(prev => ({ ...prev, autoAcceptAcknowledgements: e.target.checked }))}
                          className="w-4 h-4 text-purple-600 rounded"
                        />
                        <span className="text-sm text-gray-700">Auto-accept acknowledgements</span>
                      </label>
                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={prefillOptions.autoSignWithName}
                          onChange={(e) => setPrefillOptions(prev => ({ ...prev, autoSignWithName: e.target.checked }))}
                          className="w-4 h-4 text-purple-600 rounded"
                        />
                        <span className="text-sm text-gray-700">Auto-sign with patient name</span>
                      </label>
                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={prefillOptions.prefillDate}
                          onChange={(e) => setPrefillOptions(prev => ({ ...prev, prefillDate: e.target.checked }))}
                          className="w-4 h-4 text-purple-600 rounded"
                        />
                        <span className="text-sm text-gray-700">Auto-fill dates with today</span>
                      </label>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => {
                    setShowSendModal(false);
                    setSelectedTemplate(null);
                  }}
                  className="flex-1 py-2 px-4 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                {selectedTemplate && (
                  <button
                    onClick={handleSendForm}
                    disabled={!sendFormData.patientName}
                    className="flex-1 py-2 px-4 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    Send Form
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Form Customizer Modal */}
      {customizingTemplate && (
        <FormCustomizer
          templateId={customizingTemplate.id}
          officeId="default"
          onClose={() => setCustomizingTemplate(null)}
          onSave={() => {
            loadData();
            setCustomizingTemplate(null);
          }}
        />
      )}
    </div>
  );
}
