import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Save, Key, Building, Lock, AlertCircle, CheckCircle, TestTube, ArrowLeft, FileText } from 'lucide-react';

function AdminConfig() {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [config, setConfig] = useState({
    apiBaseUrl: '',
    accessToken: '',
    tenantId: '',
    officeId: ''
  });
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    if (!isAdmin) {
      navigate('/prc');
      return;
    }

    const savedConfig = localStorage.getItem('eyefinityConfig');
    if (savedConfig) {
      setConfig(JSON.parse(savedConfig));
    } else {
      // Pre-populate from environment variables
      const envToken = import.meta.env.VITE_EYEFINITY_ACCESS_TOKEN || '';
      const envOfficeId = import.meta.env.VITE_DEFAULT_OFFICE_ID || '936';
      
      const defaultConfig = {
        apiBaseUrl: 'https://pm-ci.eyefinity.com/al-pe',
        accessToken: envToken,
        tenantId: 'al-pe',
        officeId: envOfficeId
      };
      
      setConfig(defaultConfig);
      
      // Auto-save if env token exists
      if (envToken) {
        localStorage.setItem('eyefinityConfig', JSON.stringify(defaultConfig));
        console.log('[AdminConfig] Auto-configured from environment variables');
      }
    }
  }, [isAdmin, navigate]);

  const handleSave = (e) => {
    e.preventDefault();
    setError('');
    
    if (!config.apiBaseUrl || !config.accessToken) {
      setError('API Base URL and Access Token are required');
      return;
    }

    localStorage.setItem('eyefinityConfig', JSON.stringify(config));
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleTestConnection = async (useDirect = false) => {
    setTesting(true);
    setTestResult(null);
    setError('');

    if (!config.apiBaseUrl || !config.accessToken) {
      setError('Please fill in API Base URL and Access Token before testing');
      setTesting(false);
      return;
    }

    const testUrl = useDirect 
      ? `${config.apiBaseUrl}/v2offices?page=1&pageSize=5`
      : `/api/eyefinity/v2offices?page=1&pageSize=5`;

    console.log('[Test] Using config:', {
      method: useDirect ? 'DIRECT' : 'PROXY',
      url: testUrl,
      apiBaseUrl: config.apiBaseUrl,
      tokenLength: config.accessToken.length,
      tokenStart: config.accessToken.substring(0, 20) + '...'
    });

    try {
      const headers = useDirect
        ? {
            'Authorization': `Bearer ${config.accessToken}`,
            'Content-Type': 'application/json',
          }
        : {
            'X-Auth-Token': config.accessToken,
            'Content-Type': 'application/json',
          };

      const response = await fetch(testUrl, { headers });
      
      console.log('[Test] Response status:', response.status);

      if (response.ok) {
        const data = await response.json();
        setTestResult({
          success: true,
          message: `${useDirect ? 'Direct' : 'Proxy'} connection successful! Found ${data.items?.length || 0} offices.`
        });
      } else {
        const errorText = await response.text();
        setTestResult({
          success: false,
          message: `${useDirect ? 'Direct' : 'Proxy'} connection failed: ${response.status} - ${errorText || response.statusText}`
        });
      }
    } catch (err) {
      setTestResult({
        success: false,
        message: `${useDirect ? 'Direct' : 'Proxy'} connection error: ${err.message}`
      });
    } finally {
      setTesting(false);
    }
  };

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-[#023046] text-white px-6 py-4">
        <h1 className="text-2xl font-bold">Admin Configuration</h1>
        <p className="text-sm text-gray-300">Eyefinity API Settings</p>
      </div>

      <div className="max-w-3xl mx-auto p-6">
        <button
          onClick={() => navigate('/prc')}
          className="mb-4 flex items-center gap-2 text-sm text-gray-600 hover:text-gray-800"
        >
          <ArrowLeft size={16} />
          Back to Patient Readiness Center
        </button>

        {saved && (
          <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
            <CheckCircle size={20} />
            <span>Configuration saved successfully!</span>
          </div>
        )}

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
            <AlertCircle size={20} />
            <span>{error}</span>
          </div>
        )}

        {testResult && (
          <div className={`mb-4 p-4 rounded-lg flex items-center gap-2 ${
            testResult.success 
              ? 'bg-green-50 border border-green-200 text-green-700'
              : 'bg-red-50 border border-red-200 text-red-700'
          }`}>
            {testResult.success ? <CheckCircle size={20} /> : <AlertCircle size={20} />}
            <span>{testResult.message}</span>
          </div>
        )}

        <form onSubmit={handleSave} className="bg-white rounded-lg shadow-md p-6 space-y-6">
          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
              <Building size={16} />
              API Base URL
            </label>
            <input
              type="url"
              value={config.apiBaseUrl}
              onChange={(e) => setConfig({ ...config, apiBaseUrl: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="https://pm-ci.eyefinity.com/al-pe"
              required
            />
            <p className="mt-1 text-xs text-gray-500">The base URL for Eyefinity Practice Management API</p>
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
              <Key size={16} />
              Access Token
            </label>
            <textarea
              value={config.accessToken}
              onChange={(e) => setConfig({ ...config, accessToken: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono text-xs"
              placeholder="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9..."
              rows={4}
              required
            />
            <p className="mt-1 text-xs text-gray-500">Bearer token for API authentication</p>
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
              <Lock size={16} />
              Tenant ID
            </label>
            <input
              type="text"
              value={config.tenantId}
              onChange={(e) => setConfig({ ...config, tenantId: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="your-tenant-id"
            />
            <p className="mt-1 text-xs text-gray-500">Optional: Default tenant ID for API calls</p>
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
              <Building size={16} />
              Default Office ID
            </label>
            <input
              type="text"
              value={config.officeId}
              onChange={(e) => setConfig({ ...config, officeId: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="10128"
            />
            <p className="mt-1 text-xs text-gray-500">Optional: Default office ID for filtering appointments</p>
          </div>

          <div className="flex gap-3">
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Save size={18} />
              Save Configuration
            </button>
            <button
              type="button"
              onClick={() => handleTestConnection(true)}
              disabled={testing}
              className="flex items-center gap-2 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              <TestTube size={18} />
              {testing ? 'Testing...' : 'Test Direct'}
            </button>
            <button
              type="button"
              onClick={() => handleTestConnection(false)}
              disabled={testing}
              className="flex items-center gap-2 px-6 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              <TestTube size={18} />
              {testing ? 'Testing...' : 'Test Proxy'}
            </button>
            <button
              type="button"
              onClick={() => navigate('/api-test')}
              className="flex items-center gap-2 px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              <TestTube size={18} />
              Advanced Tests
            </button>
            <button
              type="button"
              onClick={() => navigate('/prc')}
              className="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>

        {/* Quick Links */}
        <div className="mt-6 bg-white rounded-lg shadow-md p-6">
          <h3 className="text-sm font-semibold text-gray-900 mb-4">Admin Quick Links</h3>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => navigate('/admin')}
              className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-colors text-left"
            >
              <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                <Lock size={20} className="text-indigo-600" />
              </div>
              <div>
                <div className="font-medium text-gray-900">Super Admin Settings</div>
                <div className="text-xs text-gray-500">Company, OAuth, users & offices</div>
              </div>
            </button>
            <button
              onClick={() => navigate('/forms-admin')}
              className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-colors text-left"
            >
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <FileText size={20} className="text-purple-600" />
              </div>
              <div>
                <div className="font-medium text-gray-900">Forms Management</div>
                <div className="text-xs text-gray-500">Send and manage patient forms</div>
              </div>
            </button>
            <button
              onClick={() => navigate('/journey-admin')}
              className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors text-left"
            >
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <TestTube size={20} className="text-blue-600" />
              </div>
              <div>
                <div className="font-medium text-gray-900">Journey Settings</div>
                <div className="text-xs text-gray-500">Configure patient journeys</div>
              </div>
            </button>
          </div>
        </div>

        <div className="mt-6 bg-blue-50 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-blue-900 mb-2">Configuration Guide</h3>
          <ul className="text-xs text-blue-800 space-y-1">
            <li>• API Base URL: The Eyefinity Practice Management API endpoint</li>
            <li>• Access Token: Obtain from Eyefinity OAuth 2.0 authentication</li>
            <li>• Tenant ID: Your organization's tenant identifier</li>
            <li>• Office ID: Specific office location for filtering appointments</li>
          </ul>
          <p className="mt-3 text-xs text-blue-700">
            <strong>Note:</strong> Configuration is stored locally in your browser. Ensure tokens are kept secure.
          </p>
        </div>
      </div>
    </div>
  );
}

export default AdminConfig;
