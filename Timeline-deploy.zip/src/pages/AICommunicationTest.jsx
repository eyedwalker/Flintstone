import React, { useState, useEffect, useRef } from 'react';
import { 
  ElevenLabsService, 
  DeepgramService,
  UnifiedAIResponseService,
  getPersonas,
  getOrCreateDefaultPersona,
  updatePersona,
  createDefaultPersona,
  savePersonas
} from '../services/ai';

const AICommunicationTest = () => {
  const [activeTab, setActiveTab] = useState('voice');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);
  
  // Voice TTS state
  const [ttsText, setTtsText] = useState("Hello! Thank you for calling our office. How may I help you today?");
  const [voices, setVoices] = useState([]);
  const [selectedVoice, setSelectedVoice] = useState('EXAVITQu4vr4xnSDxMaL');
  const audioRef = useRef(null);
  
  // AI Response state
  const [testMessage, setTestMessage] = useState("I'd like to confirm my appointment");
  const [channel, setChannel] = useState('sms');
  const [patientName, setPatientName] = useState('John Smith');
  const [officeName, setOfficeName] = useState('Vision Care Center');
  
  // Persona state
  const [personas, setPersonasState] = useState([]);
  const [editingPersona, setEditingPersona] = useState(null);
  
  // Transcription state
  const [audioUrl, setAudioUrl] = useState('');
  const [transcription, setTranscription] = useState(null);
  
  useEffect(() => {
    loadVoices();
    loadPersonas();
  }, []);
  
  const loadVoices = async () => {
    try {
      const voiceList = await ElevenLabsService.getVoices();
      setVoices(voiceList);
    } catch (err) {
      console.error('Failed to load voices:', err);
    }
  };
  
  const loadPersonas = () => {
    const stored = getPersonas();
    setPersonasState(stored);
  };
  
  const handleGenerateTTS = async () => {
    setLoading(true);
    setError(null);
    try {
      const audioBuffer = await ElevenLabsService.generateSpeech({
        voiceId: selectedVoice,
        text: ttsText,
        modelId: 'eleven_turbo_v2'
      });
      
      const blob = new Blob([audioBuffer], { type: 'audio/mpeg' });
      const url = URL.createObjectURL(blob);
      
      if (audioRef.current) {
        audioRef.current.src = url;
        audioRef.current.play();
      }
      
      setResult({ type: 'audio', url, size: audioBuffer.byteLength });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  
  const handleTestAIResponse = async () => {
    setLoading(true);
    setError(null);
    try {
      const [firstName, ...lastParts] = patientName.split(' ');
      const lastName = lastParts.join(' ') || 'Doe';
      
      const response = await UnifiedAIResponseService.generateResponse(
        testMessage,
        {
          firstName,
          lastName,
          officeName,
          appointmentDateTime: new Date(Date.now() + 86400000).toISOString()
        },
        'test-office-001',
        {
          channel,
          generateAudio: channel === 'voice',
          includePersonaName: true
        }
      );
      
      if (response.audio && audioRef.current) {
        const blob = new Blob([response.audio], { type: 'audio/mpeg' });
        audioRef.current.src = URL.createObjectURL(blob);
      }
      
      setResult({
        type: 'ai_response',
        text: response.text,
        intent: response.intent,
        sentiment: response.sentiment,
        processingTimeMs: response.processingTimeMs,
        persona: response.persona,
        hasAudio: !!response.audio
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  
  const handleTranscribe = async () => {
    if (!audioUrl) return;
    setLoading(true);
    setError(null);
    try {
      const result = await DeepgramService.transcribeUrl(audioUrl, {
        model: 'nova-2',
        punctuate: true,
        smartFormat: true
      });
      setTranscription(result);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  
  const handleCreateDefaultPersona = () => {
    const persona = getOrCreateDefaultPersona('test-office-001', officeName);
    loadPersonas();
    setEditingPersona(persona);
  };
  
  const handleSavePersona = () => {
    if (!editingPersona) return;
    updatePersona(editingPersona.id, editingPersona);
    loadPersonas();
    setEditingPersona(null);
  };

  const tabs = [
    { id: 'voice', label: 'Voice TTS' },
    { id: 'response', label: 'AI Response' },
    { id: 'persona', label: 'Persona Config' },
    { id: 'transcribe', label: 'Transcription' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">AI Communication Test</h1>
        
        {/* Tab Navigation */}
        <div className="flex space-x-1 mb-6 bg-gray-100 rounded-lg p-1">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
                activeTab === tab.id 
                  ? 'bg-white text-blue-600 shadow' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        
        {/* Hidden audio player */}
        <audio ref={audioRef} className="hidden" controls />
        
        {/* Error Display */}
        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        )}
        
        {/* Voice TTS Tab */}
        {activeTab === 'voice' && (
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4">ElevenLabs Text-to-Speech</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Voice</label>
                <select 
                  value={selectedVoice}
                  onChange={(e) => setSelectedVoice(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                  {Object.entries(ElevenLabsService.RECOMMENDED_VOICES).map(([key, voice]) => (
                    <option key={key} value={voice.voiceId}>
                      {voice.name} - {voice.description}
                    </option>
                  ))}
                  <optgroup label="All Voices">
                    {voices.map(voice => (
                      <option key={voice.voice_id} value={voice.voice_id}>
                        {voice.name} ({voice.category})
                      </option>
                    ))}
                  </optgroup>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Text</label>
                <textarea 
                  value={ttsText}
                  onChange={(e) => setTtsText(e.target.value)}
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <button
                onClick={handleGenerateTTS}
                disabled={loading || !ttsText}
                className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400"
              >
                {loading ? 'Generating...' : 'Generate & Play'}
              </button>
              
              {result?.type === 'audio' && (
                <div className="mt-4 p-4 bg-green-50 rounded-lg">
                  <p className="text-green-700">Audio generated! Size: {(result.size / 1024).toFixed(1)} KB</p>
                  <button
                    onClick={() => audioRef.current?.play()}
                    className="mt-2 text-sm text-blue-600 hover:underline"
                  >
                    Play Again
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* AI Response Tab */}
        {activeTab === 'response' && (
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4">AI Response Simulation</h2>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Patient Name</label>
                  <input 
                    type="text"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Office Name</label>
                  <input 
                    type="text"
                    value={officeName}
                    onChange={(e) => setOfficeName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Channel</label>
                <div className="flex space-x-4">
                  {['sms', 'voice', 'email'].map(ch => (
                    <label key={ch} className="flex items-center">
                      <input 
                        type="radio" 
                        value={ch} 
                        checked={channel === ch}
                        onChange={(e) => setChannel(e.target.value)}
                        className="mr-2"
                      />
                      {ch.toUpperCase()}
                    </label>
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Patient Message</label>
                <textarea 
                  value={testMessage}
                  onChange={(e) => setTestMessage(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <button
                onClick={handleTestAIResponse}
                disabled={loading || !testMessage}
                className="w-full py-2 px-4 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:bg-gray-400"
              >
                {loading ? 'Processing...' : 'Send Test Message'}
              </button>
              
              {result?.type === 'ai_response' && (
                <div className="mt-4 p-4 bg-gray-50 rounded-lg space-y-3">
                  <div>
                    <span className="text-sm font-medium text-gray-500">Response from {result.persona.name}:</span>
                    <p className="mt-1 text-gray-900">{result.text}</p>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="font-medium text-gray-500">Intent:</span>
                      <p>{result.intent.primary} ({(result.intent.confidence * 100).toFixed(0)}%)</p>
                    </div>
                    <div>
                      <span className="font-medium text-gray-500">Sentiment:</span>
                      <p className={`capitalize ${
                        result.sentiment === 'positive' ? 'text-green-600' :
                        result.sentiment === 'negative' ? 'text-red-600' :
                        result.sentiment === 'urgent' ? 'text-orange-600' : 'text-gray-600'
                      }`}>{result.sentiment}</p>
                    </div>
                    <div>
                      <span className="font-medium text-gray-500">Time:</span>
                      <p>{result.processingTimeMs}ms</p>
                    </div>
                  </div>
                  {result.hasAudio && (
                    <button
                      onClick={() => audioRef.current?.play()}
                      className="text-sm text-blue-600 hover:underline"
                    >
                      Play Audio Response
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Persona Config Tab */}
        {activeTab === 'persona' && (
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4">AI Persona Configuration</h2>
            
            <div className="space-y-4">
              {personas.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-500 mb-4">No personas configured yet.</p>
                  <button
                    onClick={handleCreateDefaultPersona}
                    className="py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    Create Default Persona
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {personas.map(persona => (
                    <div key={persona.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold">{persona.name}</h3>
                          <p className="text-sm text-gray-500">{persona.role}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          {persona.isDefault && (
                            <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">Default</span>
                          )}
                          <button
                            onClick={() => setEditingPersona({...persona})}
                            className="text-sm text-blue-600 hover:underline"
                          >
                            Edit
                          </button>
                        </div>
                      </div>
                      <div className="mt-2 grid grid-cols-3 gap-2 text-sm text-gray-600">
                        <div>Voice: {persona.voice.voiceName || 'Default'}</div>
                        <div>Tone: {persona.personality.tone}</div>
                        <div>Model: {persona.llmConfig.model}</div>
                      </div>
                      <div className="mt-2 text-xs text-gray-400">
                        Channels: {Object.entries(persona.channels)
                          .filter(([, cfg]) => cfg.enabled)
                          .map(([ch]) => ch.toUpperCase())
                          .join(', ')}
                      </div>
                    </div>
                  ))}
                  
                  <button
                    onClick={handleCreateDefaultPersona}
                    className="text-sm text-blue-600 hover:underline"
                  >
                    + Add New Persona
                  </button>
                </div>
              )}
              
              {editingPersona && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                  <div className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
                    <h3 className="text-lg font-semibold mb-4">Edit Persona</h3>
                    
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700">Name</label>
                          <input 
                            type="text"
                            value={editingPersona.name}
                            onChange={(e) => setEditingPersona({...editingPersona, name: e.target.value})}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700">Role</label>
                          <input 
                            type="text"
                            value={editingPersona.role}
                            onChange={(e) => setEditingPersona({...editingPersona, role: e.target.value})}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Tone</label>
                        <select 
                          value={editingPersona.personality.tone}
                          onChange={(e) => setEditingPersona({
                            ...editingPersona, 
                            personality: {...editingPersona.personality, tone: e.target.value}
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                        >
                          <option value="professional">Professional</option>
                          <option value="friendly">Friendly</option>
                          <option value="warm">Warm</option>
                          <option value="casual">Casual</option>
                          <option value="formal">Formal</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Voice</label>
                        <select 
                          value={editingPersona.voice.voiceId}
                          onChange={(e) => {
                            const voice = Object.values(ElevenLabsService.RECOMMENDED_VOICES)
                              .find(v => v.voiceId === e.target.value);
                            setEditingPersona({
                              ...editingPersona, 
                              voice: {
                                ...editingPersona.voice, 
                                voiceId: e.target.value,
                                voiceName: voice?.name || ''
                              }
                            });
                          }}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                        >
                          {Object.entries(ElevenLabsService.RECOMMENDED_VOICES).map(([key, voice]) => (
                            <option key={key} value={voice.voiceId}>
                              {voice.name} - {voice.description}
                            </option>
                          ))}
                        </select>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700">Office Hours</label>
                          <input 
                            type="text"
                            value={editingPersona.knowledge.officeHours}
                            onChange={(e) => setEditingPersona({
                              ...editingPersona, 
                              knowledge: {...editingPersona.knowledge, officeHours: e.target.value}
                            })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700">Office Phone</label>
                          <input 
                            type="text"
                            value={editingPersona.knowledge.officePhone}
                            onChange={(e) => setEditingPersona({
                              ...editingPersona, 
                              knowledge: {...editingPersona.knowledge, officePhone: e.target.value}
                            })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          />
                        </div>
                      </div>
                      
                      <div className="flex justify-end space-x-3 mt-6">
                        <button
                          onClick={() => setEditingPersona(null)}
                          className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={handleSavePersona}
                          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                        >
                          Save Changes
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Transcription Tab */}
        {activeTab === 'transcribe' && (
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4">Deepgram Transcription</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Audio URL</label>
                <input 
                  type="text"
                  value={audioUrl}
                  onChange={(e) => setAudioUrl(e.target.value)}
                  placeholder="https://example.com/audio.wav"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <button
                onClick={handleTranscribe}
                disabled={loading || !audioUrl}
                className="w-full py-2 px-4 bg-purple-600 text-white rounded-md hover:bg-purple-700 disabled:bg-gray-400"
              >
                {loading ? 'Transcribing...' : 'Transcribe Audio'}
              </button>
              
              {transcription && (
                <div className="mt-4 p-4 bg-purple-50 rounded-lg">
                  <h3 className="font-medium text-purple-900 mb-2">Transcript:</h3>
                  <p className="text-gray-800">{transcription.transcript}</p>
                  <div className="mt-2 text-sm text-gray-500">
                    Confidence: {(transcription.confidence * 100).toFixed(1)}%
                    {transcription.duration && ` | Duration: ${transcription.duration.toFixed(1)}s`}
                  </div>
                </div>
              )}
              
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <h3 className="font-medium text-gray-700 mb-2">Deepgram Features</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>Model: Nova-2 (most accurate)</li>
                  <li>Smart formatting enabled</li>
                  <li>Punctuation enabled</li>
                  <li>Real-time streaming supported</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AICommunicationTest;
