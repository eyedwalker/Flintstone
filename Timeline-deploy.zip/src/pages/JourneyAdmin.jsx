/**
 * Journey Admin Page
 * Manage journey rules, step templates, and settings
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Plus, 
  Edit2, 
  Trash2, 
  Save,
  X,
  ChevronDown,
  ChevronRight,
  ChevronUp,
  Settings,
  FileText,
  Filter,
  Clock,
  Building2,
  UserCheck,
  CheckCircle
} from 'lucide-react';
import { getJourneyRulesService } from '../lib/services/journey-rules-service';
import { EyefinityService } from '../services/eyefinityService';

const PHASE_OPTIONS = [
  { value: 'pre-visit', label: 'Pre-Visit', icon: Clock },
  { value: 'in-office', label: 'In-Office', icon: Building2 },
  { value: 'post-visit', label: 'Post-Visit', icon: UserCheck },
  { value: 'all', label: 'All Phases', icon: CheckCircle }
];

const OPERATOR_OPTIONS = [
  { value: 'equals', label: 'Equals' },
  { value: 'notEquals', label: 'Not Equals' },
  { value: 'contains', label: 'Contains' },
  { value: 'greaterThan', label: 'Greater Than' },
  { value: 'lessThan', label: 'Less Than' },
  { value: 'exists', label: 'Exists' },
  { value: 'notExists', label: 'Does Not Exist' }
];

const COMMON_FIELDS = [
  { value: 'appointmentType', label: 'Appointment Type' },
  { value: 'isNewPatient', label: 'Is New Patient' },
  { value: 'hasInsurance', label: 'Has Insurance' },
  { value: 'insuranceProvider', label: 'Insurance Provider' },
  { value: 'age', label: 'Patient Age' },
  { value: 'providerId', label: 'Provider ID' },
  { value: 'officeId', label: 'Office ID' },
  { value: 'previousVisitCount', label: 'Previous Visit Count' }
];

export default function JourneyAdmin() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('rules');
  const [rules, setRules] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [editingRule, setEditingRule] = useState(null);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [expandedRule, setExpandedRule] = useState(null);
  const [appointmentTypes, setAppointmentTypes] = useState([]);

  const rulesService = getJourneyRulesService();

  useEffect(() => {
    loadData();
    loadAppointmentTypes();
  }, []);

  const loadAppointmentTypes = async () => {
    try {
      // Try to get the selected office from localStorage config
      const config = JSON.parse(localStorage.getItem('eyefinityConfig') || '{}');
      const officeId = config.officeId || config.selectedOffice;
      if (!officeId) {
        // Fetch offices and use the first one
        const offices = await EyefinityService.getOffices(1, 10);
        if (offices?.items?.length > 0) {
          const types = await EyefinityService.getAppointmentTypes(offices.items[0].guid || offices.items[0].id);
          setAppointmentTypes(types.filter(t => t.isActive !== false));
        }
      } else {
        const types = await EyefinityService.getAppointmentTypes(officeId);
        setAppointmentTypes(types.filter(t => t.isActive !== false));
      }
    } catch (err) {
      console.warn('[JourneyAdmin] Could not load appointment types from Eyefinity:', err.message);
    }
  };

  const loadData = () => {
    setRules(rulesService.getAllRules());
    setTemplates(rulesService.getAllStepTemplates());
  };

  const handleSaveRule = () => {
    if (!editingRule) return;
    
    if (editingRule.id) {
      rulesService.updateRule(editingRule.id, editingRule);
    } else {
      rulesService.addRule(editingRule);
    }
    
    setEditingRule(null);
    loadData();
  };

  const handleDeleteRule = (id) => {
    if (confirm('Are you sure you want to delete this rule?')) {
      rulesService.deleteRule(id);
      loadData();
    }
  };

  const handleAddCondition = () => {
    if (!editingRule) return;
    setEditingRule({
      ...editingRule,
      conditions: [...(editingRule.conditions || []), { field: '', operator: 'equals', value: '' }]
    });
  };

  const handleRemoveCondition = (index) => {
    if (!editingRule) return;
    const conditions = [...editingRule.conditions];
    conditions.splice(index, 1);
    setEditingRule({ ...editingRule, conditions });
  };

  const handleUpdateCondition = (index, field, value) => {
    if (!editingRule) return;
    const conditions = [...editingRule.conditions];
    conditions[index] = { ...conditions[index], [field]: value };
    setEditingRule({ ...editingRule, conditions });
  };

  const handleSaveTemplate = () => {
    if (!editingTemplate) return;
    rulesService.addStepTemplate(editingTemplate);
    setEditingTemplate(null);
    loadData();
  };

  const handleDeleteTemplate = (id) => {
    if (confirm('Are you sure you want to delete this step template?')) {
      rulesService.deleteStepTemplate(id);
      loadData();
    }
  };

  const handleToggleRuleStep = (stepId) => {
    if (!editingRule) return;
    const existing = Array.isArray(editingRule.stepTemplateIds) ? editingRule.stepTemplateIds : [];
    const next = existing.includes(stepId)
      ? existing.filter((id) => id !== stepId)
      : [...existing, stepId];
    setEditingRule({ ...editingRule, stepTemplateIds: next });
  };

  const handleMoveStepUp = (index) => {
    if (!editingRule || index === 0) return;
    const steps = [...(editingRule.stepTemplateIds || [])];
    [steps[index - 1], steps[index]] = [steps[index], steps[index - 1]];
    setEditingRule({ ...editingRule, stepTemplateIds: steps });
  };

  const handleMoveStepDown = (index) => {
    if (!editingRule || index === (editingRule.stepTemplateIds || []).length - 1) return;
    const steps = [...(editingRule.stepTemplateIds || [])];
    [steps[index], steps[index + 1]] = [steps[index + 1], steps[index]];
    setEditingRule({ ...editingRule, stepTemplateIds: steps });
  };

  const handleRemoveStep = (stepId) => {
    if (!editingRule) return;
    const steps = (editingRule.stepTemplateIds || []).filter(id => id !== stepId);
    setEditingRule({ ...editingRule, stepTemplateIds: steps });
  };

  const getStepTemplateLabel = (id) => {
    const template = templates.find((t) => t.id === id);
    return template?.title || id;
  };

  const renderRulesTab = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Journey Rules</h2>
        <button
          onClick={() => setEditingRule({
            name: '',
            description: '',
            conditions: [],
            stepTemplateIds: [],
            priority: 50,
            isActive: true,
            phase: 'in-office'
          })}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus size={16} />
          Add Rule
        </button>
      </div>

      <div className="space-y-3">
        {rules.map(rule => {
          const PhaseIcon = PHASE_OPTIONS.find(p => p.value === rule.phase)?.icon || Filter;
          const isExpanded = expandedRule === rule.id;

          return (
            <div key={rule.id} className="border rounded-lg bg-white">
              <div 
                className="p-4 flex items-center justify-between cursor-pointer"
                onClick={() => setExpandedRule(isExpanded ? null : rule.id)}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    rule.isActive ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'
                  }`}>
                    <PhaseIcon size={20} />
                  </div>
                  <div>
                    <h3 className="font-medium">{rule.name}</h3>
                    <p className="text-sm text-gray-500">{rule.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className={`px-2 py-1 rounded text-xs ${
                    rule.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
                  }`}>
                    {rule.isActive ? 'Active' : 'Inactive'}
                  </span>
                  <span className="text-xs text-gray-500">Priority: {rule.priority}</span>
                  {isExpanded ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
                </div>
              </div>

              {isExpanded && (
                <div className="px-4 pb-4 border-t bg-gray-50">
                  <div className="pt-4 space-y-4">
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 mb-2">Conditions ({rule.conditions.length})</h4>
                      {rule.conditions.length === 0 ? (
                        <p className="text-sm text-gray-500 italic">No conditions - applies to all</p>
                      ) : (
                        <div className="space-y-1">
                          {rule.conditions.map((cond, idx) => (
                            <div key={idx} className="text-sm bg-white p-2 rounded border">
                              <code className="text-blue-600">{cond.field}</code>
                              <span className="text-gray-500 mx-2">{cond.operator}</span>
                              <code className="text-green-600">{JSON.stringify(cond.value)}</code>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-700 mb-2">Steps ({rule.stepTemplateIds.length})</h4>
                      <div className="flex flex-wrap gap-2">
                        {rule.stepTemplateIds.map(stepId => (
                          <span key={stepId} className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">
                            {stepId}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <button
                        onClick={(e) => { e.stopPropagation(); setEditingRule(rule); }}
                        className="flex items-center gap-1 px-3 py-1.5 border border-gray-300 rounded text-sm hover:bg-gray-50"
                      >
                        <Edit2 size={14} />
                        Edit
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDeleteRule(rule.id); }}
                        className="flex items-center gap-1 px-3 py-1.5 border border-red-300 text-red-600 rounded text-sm hover:bg-red-50"
                      >
                        <Trash2 size={14} />
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );

  const renderEditTemplateModal = () => {
    if (!editingTemplate) return null;

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
          <div className="p-4 border-b flex items-center justify-between">
            <h2 className="text-lg font-semibold">
              {templates.some((t) => t.id === editingTemplate.id) ? 'Edit Template' : 'Create Template'}
            </h2>
            <button onClick={() => setEditingTemplate(null)} className="p-2 hover:bg-gray-100 rounded">
              <X size={20} />
            </button>
          </div>

          <div className="p-4 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Template ID</label>
              <input
                type="text"
                value={editingTemplate.id}
                onChange={(e) => setEditingTemplate({ ...editingTemplate, id: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input
                  type="text"
                  value={editingTemplate.title}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, title: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phase</label>
                <select
                  value={editingTemplate.stepType}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, stepType: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg"
                >
                  {PHASE_OPTIONS.filter((opt) => opt.value !== 'all').map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <textarea
                value={editingTemplate.description}
                onChange={(e) => setEditingTemplate({ ...editingTemplate, description: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg"
                rows={2}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Staff Role</label>
                <input
                  type="text"
                  value={editingTemplate.staffRole || ''}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, staffRole: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg"
                  placeholder="Front Desk / Technician / Doctor"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Duration (minutes)</label>
                <input
                  type="number"
                  min="0"
                  value={editingTemplate.duration ?? 0}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, duration: parseInt(e.target.value) || 0 })}
                  className="w-full px-3 py-2 border rounded-lg"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Encompass URL Template
                <span className="text-xs text-gray-500 ml-2">(Optional - supports mail merge)</span>
              </label>
              <input
                type="text"
                value={editingTemplate.url || ''}
                onChange={(e) => setEditingTemplate({ ...editingTemplate, url: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg font-mono text-sm"
                placeholder="https://encompass.com/patient?id={legacyPatientId}&appt={appointmentId}"
              />
              <p className="text-xs text-gray-500 mt-1">
                Available fields: {'{patientId}'} (GUID), {'{legacyPatientId}'} (numeric), {'{patientName}'}, {'{appointmentId}'}, {'{legacyAppointmentId}'}, {'{providerId}'}, {'{providerName}'}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={!!editingTemplate.responseRequired}
                onChange={(e) => setEditingTemplate({ ...editingTemplate, responseRequired: e.target.checked })}
                className="rounded"
              />
              <span className="text-sm text-gray-700">Response Required</span>
            </div>
          </div>

          <div className="p-4 border-t flex justify-end gap-3">
            <button
              onClick={() => setEditingTemplate(null)}
              className="px-4 py-2 border rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveTemplate}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
            >
              <Save size={16} />
              Save Template
            </button>
          </div>
        </div>
      </div>
    );
  };

  const renderTemplatesTab = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Step Templates</h2>
        <button
          onClick={() => setEditingTemplate({
            id: `step-${Date.now()}`,
            title: '',
            description: '',
            status: 'pending',
            stepType: 'in-office',
            staffRole: '',
            reasonCodes: [],
            duration: 15,
            responseRequired: false
          })}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus size={16} />
          Add Template
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {templates.map(template => {
          const PhaseIcon = PHASE_OPTIONS.find(p => p.value === template.stepType)?.icon || FileText;
          
          return (
            <div key={template.id} className="border rounded-lg bg-white p-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
                  <PhaseIcon size={20} />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium truncate">{template.title}</h3>
                  <p className="text-sm text-gray-500 truncate">{template.description}</p>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setEditingTemplate(template)}
                    className="p-2 hover:bg-gray-50 rounded text-gray-600"
                    title="Edit"
                  >
                    <Edit2 size={16} />
                  </button>
                  <button
                    onClick={() => handleDeleteTemplate(template.id)}
                    className="p-2 hover:bg-red-50 rounded text-red-600"
                    title="Delete"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-xs">
                  {template.stepType}
                </span>
                {template.staffRole && (
                  <span className="px-2 py-0.5 bg-purple-100 text-purple-600 rounded text-xs">
                    {template.staffRole}
                  </span>
                )}
                {template.duration && (
                  <span className="px-2 py-0.5 bg-blue-100 text-blue-600 rounded text-xs">
                    {template.duration}m
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  const renderEditRuleModal = () => {
    if (!editingRule) return null;

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
          <div className="p-4 border-b flex items-center justify-between">
            <h2 className="text-lg font-semibold">
              {editingRule.id ? 'Edit Rule' : 'Create Rule'}
            </h2>
            <button onClick={() => setEditingRule(null)} className="p-2 hover:bg-gray-100 rounded">
              <X size={20} />
            </button>
          </div>

          <div className="p-4 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Rule Name</label>
                <input
                  type="text"
                  value={editingRule.name}
                  onChange={(e) => setEditingRule({ ...editingRule, name: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg"
                  placeholder="Contact Lens Fitting"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phase</label>
                <select
                  value={editingRule.phase}
                  onChange={(e) => setEditingRule({ ...editingRule, phase: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg"
                >
                  {PHASE_OPTIONS.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <textarea
                value={editingRule.description}
                onChange={(e) => setEditingRule({ ...editingRule, description: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg"
                rows={2}
                placeholder="Steps for contact lens fitting appointments"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Priority (1-100)</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={editingRule.priority}
                  onChange={(e) => setEditingRule({ ...editingRule, priority: parseInt(e.target.value) || 50 })}
                  className="w-full px-3 py-2 border rounded-lg"
                />
              </div>
              <div className="flex items-end">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={editingRule.isActive}
                    onChange={(e) => setEditingRule({ ...editingRule, isActive: e.target.checked })}
                    className="rounded"
                  />
                  <span className="text-sm font-medium text-gray-700">Active</span>
                </label>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-medium text-gray-700">Conditions</label>
                <button
                  onClick={handleAddCondition}
                  className="text-sm text-blue-600 hover:text-blue-800"
                >
                  + Add Condition
                </button>
              </div>
              {editingRule.conditions.length === 0 ? (
                <p className="text-sm text-gray-500 italic p-3 bg-gray-50 rounded">
                  No conditions - rule applies to all appointments in this phase
                </p>
              ) : (
                <div className="space-y-2">
                  {editingRule.conditions.map((cond, idx) => (
                    <div key={idx} className="flex gap-2 items-center">
                      <select
                        value={cond.field}
                        onChange={(e) => handleUpdateCondition(idx, 'field', e.target.value)}
                        className="flex-1 px-3 py-2 border rounded-lg text-sm"
                      >
                        <option value="">Select Field</option>
                        {COMMON_FIELDS.map(f => (
                          <option key={f.value} value={f.value}>{f.label}</option>
                        ))}
                      </select>
                      <select
                        value={cond.operator}
                        onChange={(e) => handleUpdateCondition(idx, 'operator', e.target.value)}
                        className="w-32 px-3 py-2 border rounded-lg text-sm"
                      >
                        {OPERATOR_OPTIONS.map(o => (
                          <option key={o.value} value={o.value}>{o.label}</option>
                        ))}
                      </select>
                      {cond.field === 'appointmentType' && appointmentTypes.length > 0 ? (
                        <select
                          value={cond.value ?? ''}
                          onChange={(e) => handleUpdateCondition(idx, 'value', e.target.value)}
                          className="flex-1 px-3 py-2 border rounded-lg text-sm"
                        >
                          <option value="">Select Appointment Type</option>
                          {appointmentTypes.map(type => (
                            <option key={type.appointmentTypeId} value={type.description}>
                              {type.companyServiceName || type.description}
                            </option>
                          ))}
                        </select>
                      ) : (cond.field === 'isNewPatient' || cond.field === 'hasInsurance') ? (
                        <select
                          value={String(cond.value ?? '')}
                          onChange={(e) => handleUpdateCondition(idx, 'value', e.target.value === 'true')}
                          className="flex-1 px-3 py-2 border rounded-lg text-sm"
                        >
                          <option value="">Select Value</option>
                          <option value="true">True</option>
                          <option value="false">False</option>
                        </select>
                      ) : (
                        <input
                          type="text"
                          value={cond.value ?? ''}
                          onChange={(e) => handleUpdateCondition(idx, 'value', e.target.value)}
                          className="flex-1 px-3 py-2 border rounded-lg text-sm"
                          placeholder="Value"
                        />
                      )}
                      <button
                        onClick={() => handleRemoveCondition(idx)}
                        className="p-2 text-red-500 hover:bg-red-50 rounded"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-medium text-gray-700">
                  Step Templates (Ordered)
                </label>
                {(editingRule.stepTemplateIds || []).length > 0 && (
                  <span className="text-xs text-gray-500">
                    {(editingRule.stepTemplateIds || []).length} steps
                  </span>
                )}
              </div>
              
              {/* Ordered Steps List */}
              {(editingRule.stepTemplateIds || []).length > 0 ? (
                <div className="border rounded-lg p-3 bg-white space-y-2 mb-3">
                  {(editingRule.stepTemplateIds || []).map((stepId, index) => (
                    <div
                      key={stepId}
                      className="flex items-center gap-2 p-2 bg-gray-50 rounded border border-gray-200"
                    >
                      <span className="text-xs font-semibold text-gray-400 w-6">
                        {index + 1}.
                      </span>
                      <span className="flex-1 text-sm font-medium text-gray-900">
                        {getStepTemplateLabel(stepId)}
                      </span>
                      <div className="flex gap-1">
                        <button
                          onClick={() => handleMoveStepUp(index)}
                          disabled={index === 0}
                          className={`p-1 rounded ${
                            index === 0
                              ? 'text-gray-300 cursor-not-allowed'
                              : 'text-gray-600 hover:bg-gray-200'
                          }`}
                          title="Move up"
                        >
                          <ChevronUp size={16} />
                        </button>
                        <button
                          onClick={() => handleMoveStepDown(index)}
                          disabled={index === (editingRule.stepTemplateIds || []).length - 1}
                          className={`p-1 rounded ${
                            index === (editingRule.stepTemplateIds || []).length - 1
                              ? 'text-gray-300 cursor-not-allowed'
                              : 'text-gray-600 hover:bg-gray-200'
                          }`}
                          title="Move down"
                        >
                          <ChevronDown size={16} />
                        </button>
                        <button
                          onClick={() => handleRemoveStep(stepId)}
                          className="p-1 text-red-500 hover:bg-red-50 rounded"
                          title="Remove"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="border rounded-lg p-4 bg-gray-50 mb-3">
                  <p className="text-sm text-gray-500 text-center">
                    No steps selected. Choose from available templates below.
                  </p>
                </div>
              )}

              {/* Available Templates */}
              <div className="border rounded-lg p-3 bg-white">
                <label className="block text-xs font-medium text-gray-600 mb-2">
                  Available Templates (click to add)
                </label>
                <div className="max-h-40 overflow-y-auto space-y-2">
                  {templates.length === 0 ? (
                    <div className="text-sm text-gray-500">No step templates available.</div>
                  ) : (
                    templates.map((t) => (
                      <label key={t.id} className="flex items-center gap-2 text-sm text-gray-700">
                        <input
                          type="checkbox"
                          checked={(editingRule.stepTemplateIds || []).includes(t.id)}
                          onChange={() => handleToggleRuleStep(t.id)}
                          className="rounded"
                        />
                        <span className="font-medium">{t.title}</span>
                        <span className="text-xs text-gray-500">({t.id})</span>
                      </label>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 border-t flex justify-end gap-3">
            <button
              onClick={() => setEditingRule(null)}
              className="px-4 py-2 border rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveRule}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
            >
              <Save size={16} />
              Save Rule
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-6 py-4">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/prc')}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-xl font-semibold">Journey Settings</h1>
            <p className="text-sm text-gray-500">Manage rules and step templates</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b px-6">
        <div className="flex gap-6">
          <button
            onClick={() => setActiveTab('rules')}
            className={`py-3 px-1 border-b-2 text-sm font-medium ${
              activeTab === 'rules' 
                ? 'border-blue-600 text-blue-600' 
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Filter size={16} className="inline mr-2" />
            Rules
          </button>
          <button
            onClick={() => setActiveTab('templates')}
            className={`py-3 px-1 border-b-2 text-sm font-medium ${
              activeTab === 'templates' 
                ? 'border-blue-600 text-blue-600' 
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <FileText size={16} className="inline mr-2" />
            Step Templates
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`py-3 px-1 border-b-2 text-sm font-medium ${
              activeTab === 'settings' 
                ? 'border-blue-600 text-blue-600' 
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Settings size={16} className="inline mr-2" />
            Settings
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 max-w-6xl mx-auto">
        {activeTab === 'rules' && renderRulesTab()}
        {activeTab === 'templates' && renderTemplatesTab()}
        {activeTab === 'settings' && (
          <div className="bg-white rounded-lg border p-6">
            <h2 className="text-lg font-semibold mb-4">General Settings</h2>
            <div className="space-y-4">
              <label className="flex items-center gap-3">
                <input type="checkbox" defaultChecked className="rounded" />
                <span>Auto-create journey when appointment is created</span>
              </label>
              <label className="flex items-center gap-3">
                <input type="checkbox" defaultChecked className="rounded" />
                <span>Send pre-visit communications automatically</span>
              </label>
              <label className="flex items-center gap-3">
                <input type="checkbox" defaultChecked className="rounded" />
                <span>Send post-visit surveys automatically</span>
              </label>
              <label className="flex items-center gap-3">
                <input type="checkbox" className="rounded" />
                <span>Require manager approval for cancellations</span>
              </label>
            </div>
          </div>
        )}
      </div>

      {renderEditRuleModal()}
      {renderEditTemplateModal()}
    </div>
  );
}
