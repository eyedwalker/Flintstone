/**
 * Patient Form Page
 * Patient-facing page for completing forms via secure access token
 */

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FormSubmissionService } from '../lib/services/form-submission-service';
import FormRenderer from '../components/forms/FormRenderer';
import PatientVerification from '../components/verification/PatientVerification';
import { 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  FileText,
  Shield,
  Loader2
} from 'lucide-react';

export default function PatientFormPage() {
  const { token } = useParams();
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState(null);
  const [needsVerification, setNeedsVerification] = useState(false);
  const [isVerified, setIsVerified] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [submissionId, setSubmissionId] = useState(null);

  useEffect(() => {
    loadForm();
  }, [token]);

  const loadForm = async () => {
    if (!token) {
      setError('No access token provided');
      setLoading(false);
      return;
    }

    try {
      // Fetch form from API (server-side storage)
      const response = await fetch(`/api/forms/submission?token=${encodeURIComponent(token)}`);
      const result = await response.json();

      if (!response.ok) {
        if (response.status === 404) {
          // Try localStorage fallback for backwards compatibility
          const localResult = FormSubmissionService.accessFormByToken(token);
          if (localResult) {
            setFormData(localResult);
            setSubmissionId(localResult.submission.submissionId);
            setIsVerified(true);
            setLoading(false);
            return;
          }
          setError(result.message || 'Form not found. Please contact your healthcare provider for a new link.');
        } else if (response.status === 410) {
          setError(result.message || 'This form link has expired.');
        } else {
          setError(result.message || result.error || 'Unable to load form');
        }
        setLoading(false);
        return;
      }

      // Check if already completed — still load form data for read-only viewing
      if (result.completed) {
        if (result.submission && result.template) {
          setFormData({ submission: result.submission, template: result.template });
          setSubmissionId(result.submission.submissionId);
          setIsVerified(true);
        }
        setIsCompleted(true);
        setLoading(false);
        return;
      }

      // Check if verification is needed
      if (result.submission?.verification?.required && 
          !result.submission?.verification?.verified) {
        setNeedsVerification(true);
        setSubmissionId(result.submission.submissionId);
        setLoading(false);
        return;
      }

      // Set form data
      setFormData({
        submission: result.submission,
        template: result.template,
      });
      setSubmissionId(result.submission.submissionId);
      setIsVerified(true);
      setLoading(false);
    } catch (err) {
      console.error('Error loading form:', err);
      setError('An error occurred while loading the form. Please try again.');
      setLoading(false);
    }
  };

  const handleVerificationSuccess = () => {
    setNeedsVerification(false);
    setIsVerified(true);
    // Reload form after verification
    setLoading(true);
    loadForm();
  };

  const handleSaveProgress = async (responses) => {
    if (submissionId) {
      FormSubmissionService.updateResponses(submissionId, responses);
      // Sync progress to database
      try {
        await fetch(`/api/forms/submission?token=${encodeURIComponent(token)}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ responses }),
        });
      } catch (err) { /* best-effort */ }
      console.log('[PatientForm] Progress saved');
    }
  };

  const handleSubmit = async (responses) => {
    if (!submissionId) return;

    try {
      // Handle file uploads
      const fileFields = Object.entries(responses).filter(([_, value]) => 
        value && typeof value === 'object' && value.dataUrl
      );

      for (const [fieldId, fileData] of fileFields) {
        FormSubmissionService.addFileAttachment(submissionId, {
          fieldId,
          fileName: fileData.name,
          fileSize: fileData.size,
          fileType: fileData.type,
          filePath: `local/${fieldId}`,
          dataUrl: fileData.dataUrl,
          uploadedAt: new Date(),
        });
      }

      // Complete the submission locally
      FormSubmissionService.completeSubmission(submissionId, responses);

      // Also update via API so database reflects completion
      try {
        await fetch(`/api/forms/submission?token=${encodeURIComponent(token)}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ responses, status: 'completed' }),
        });
      } catch (apiErr) {
        console.error('[PatientForm] API update failed:', apiErr);
      }

      setIsCompleted(true);
    } catch (err) {
      console.error('Error submitting form:', err);
      throw err;
    }
  };

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading your form...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8 text-center">
          {isCompleted ? (
            <>
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-8 h-8 text-green-600" />
              </div>
              <h1 className="text-xl font-bold text-gray-900 mb-2">Form Already Completed</h1>
              <p className="text-gray-600">{error}</p>
            </>
          ) : (
            <>
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="w-8 h-8 text-red-600" />
              </div>
              <h1 className="text-xl font-bold text-gray-900 mb-2">Unable to Load Form</h1>
              <p className="text-gray-600">{error}</p>
            </>
          )}
        </div>
      </div>
    );
  }

  // Verification required state
  if (needsVerification && !isVerified) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 py-4">
          <div className="max-w-2xl mx-auto px-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <h1 className="font-semibold text-gray-900">Identity Verification</h1>
                <p className="text-sm text-gray-500">Please verify your identity to continue</p>
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-md mx-auto px-4 py-8">
          <PatientVerification
            submissionId={submissionId}
            token={token}
            onSuccess={handleVerificationSuccess}
          />
        </main>
      </div>
    );
  }

  // Completed state — show responses if available, otherwise just the success message
  if (isCompleted && !formData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Form Submitted!</h1>
          <p className="text-gray-600 mb-6">
            Thank you for completing your form. Your healthcare provider will review your submission.
          </p>
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-500">
              You may close this page. A confirmation has been sent to your email.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Completed with form data — show read-only view of responses
  if (isCompleted && formData) {
    const { submission: completedSub, template: completedTpl } = formData;
    const sections = completedTpl?.sections || [];
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white border-b border-gray-200 py-4 sticky top-0 z-10">
          <div className="max-w-2xl mx-auto px-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h1 className="font-bold text-gray-900">{completedTpl?.title || 'Form'}</h1>
                <p className="text-sm text-green-600">Completed {completedSub.completedAt ? new Date(completedSub.completedAt).toLocaleDateString() : ''}</p>
              </div>
            </div>
          </div>
        </header>
        <main className="max-w-2xl mx-auto px-4 py-6">
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <p className="text-green-800 font-medium">This form has been completed by {completedSub.patientName || 'the patient'}.</p>
          </div>
          {sections.map((section, si) => (
            <div key={si} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">{section.title}</h2>
              {(section.fields || []).map((field, fi) => {
                const value = completedSub.responses?.[field.id];
                if (value === undefined || value === null || value === '') return null;

                // Render value based on field type
                const renderValue = () => {
                  // Signature — render as image
                  if (field.type === 'signature' && typeof value === 'string' && value.startsWith('data:image')) {
                    return <img src={value} alt="Signature" className="border border-gray-200 rounded bg-white max-h-24 mt-1" />;
                  }

                  // File/document with preview
                  if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
                    if (value.dataUrl && value.dataUrl.startsWith('data:image')) {
                      return (
                        <div className="mt-1">
                          <img src={value.dataUrl} alt={value.name || 'Uploaded file'} className="max-h-40 rounded border border-gray-200" />
                          {value.name && <p className="text-xs text-gray-500 mt-1">{value.name}</p>}
                        </div>
                      );
                    }
                    return <p className="text-gray-900 mt-0.5">{value.name || '(File attached)'}</p>;
                  }

                  // Checkbox/radio — map values to labels
                  if (Array.isArray(value) && field.options) {
                    const labels = value.map(v => {
                      const opt = field.options.find(o => o.value === v);
                      return opt ? opt.label : v;
                    });
                    return <p className="text-gray-900 mt-0.5">{labels.join(', ')}</p>;
                  }

                  // Select/radio single value — map to label
                  if (field.options && typeof value === 'string') {
                    const opt = field.options.find(o => o.value === value);
                    return <p className="text-gray-900 mt-0.5">{opt ? opt.label : value}</p>;
                  }

                  // Date formatting
                  if (field.type === 'date' && typeof value === 'string') {
                    const d = new Date(value + 'T00:00:00');
                    return <p className="text-gray-900 mt-0.5">{isNaN(d.getTime()) ? value : d.toLocaleDateString()}</p>;
                  }

                  // Boolean
                  if (typeof value === 'boolean') {
                    return <p className="text-gray-900 mt-0.5">{value ? 'Yes' : 'No'}</p>;
                  }

                  // Default text
                  return <p className="text-gray-900 mt-0.5">{String(value)}</p>;
                };

                return (
                  <div key={fi} className="mb-3">
                    <label className="text-sm font-medium text-gray-500">{field.label}</label>
                    {renderValue()}
                  </div>
                );
              })}
            </div>
          ))}
        </main>
      </div>
    );
  }

  // Form display
  if (!formData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">No form data available</p>
        </div>
      </div>
    );
  }

  const { submission, template } = formData;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 py-4 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-purple-600" />
            </div>
            <div className="flex-1">
              <h1 className="font-semibold text-gray-900">{template.title}</h1>
              {template.description && (
                <p className="text-sm text-gray-500">{template.description}</p>
              )}
            </div>
            {submission.expiresAt && (
              <div className="flex items-center gap-1 text-sm text-gray-500">
                <Clock className="w-4 h-4" />
                <span>
                  Expires {new Date(submission.expiresAt).toLocaleDateString()}
                </span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Form Content */}
      <main className="max-w-2xl mx-auto px-4 py-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 md:p-8">
          <FormRenderer
            template={template}
            initialResponses={submission.responses || {}}
            onSubmit={handleSubmit}
            onSaveProgress={handleSaveProgress}
          />
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>Your information is secure and encrypted.</p>
          <p className="mt-1">
            Having trouble? Contact your healthcare provider for assistance.
          </p>
        </div>
      </main>
    </div>
  );
}
