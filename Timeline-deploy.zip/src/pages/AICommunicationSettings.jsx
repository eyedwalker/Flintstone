import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Phone, 
  Mail, 
  MessageSquare, 
  Settings, 
  Bell, 
  Clock, 
  Shield, 
  Zap,
  Plus,
  Trash2,
  Edit2,
  Save,
  X,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Volume2,
  ToggleLeft,
  ToggleRight,
  GripVertical,
  ArrowLeft
} from 'lucide-react';
import { AICommunicationOrchestrator } from '../lib/services/ai-communication-orchestrator';
import { DEFAULT_TRIGGERS } from '../lib/types/communication-preferences';

const OFFICE_ID = '936'; // Default office

const TRIGGER_TYPES = [
  { value: 'appointment_reminder', label: 'Appointment Reminder' },
  { value: 'forms_incomplete', label: 'Forms Incomplete' },
  { value: 'insurance_verification', label: 'Insurance Verification' },
  { value: 'journey_step_started', label: 'Journey Step Started' },
  { value: 'journey_step_overdue', label: 'Journey Step Overdue' },
  { value: 'post_visit_followup', label: 'Post-Visit Follow-up' },
  { value: 'recall_reminder', label: 'Recall Reminder' },
  { value: 'custom', label: 'Custom' },
];

const CHANNEL_ICONS = {
  voice: Phone,
  sms: MessageSquare,
  email: Mail,
};

export default function AICommunicationSettings() {
  const navigate = useNavigate();
  const [settings, setSettings] = useState(null);
  const [activeTab, setActiveTab] = useState('triggers');
  const [editingTrigger, setEditingTrigger] = useState(null);
  const [expandedTrigger, setExpandedTrigger] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = () => {
    const loaded = AICommunicationOrchestrator.getSettings(OFFICE_ID);
    setSettings(loaded);
  };

  const handleSaveSettings = () => {
    setSaving(true);
    AICommunicationOrchestrator.saveSettings(settings);
    setTimeout(() => setSaving(false), 500);
  };

  const handleToggleGlobal = () => {
    setSettings(prev => ({ ...prev, globalEnabled: !prev.globalEnabled }));
  };

  const handleToggleTrigger = (triggerId) => {
    setSettings(prev => ({
      ...prev,
      triggers: prev.triggers.map(t => 
        t.id === triggerId ? { ...t, enabled: !t.enabled } : t
      )
    }));
  };

  const handleDeleteTrigger = (triggerId) => {
    if (confirm('Are you sure you want to delete this trigger?')) {
      setSettings(prev => ({
        ...prev,
        triggers: prev.triggers.filter(t => t.id !== triggerId)
      }));
    }
  };

  const handleAddTrigger = () => {
    const newTrigger = {
      id: `trigger_${Date.now()}`,
      name: 'New Trigger',
      description: 'Configure this trigger',
      enabled: false,
      triggerType: 'custom',
      timing: {
        maxAttempts: 1,
      },
      channelRules: [
        { id: 'r1', priority: 1, condition: 'patient_preference', useChannel: 'sms', respectOptOut: true },
      ],
      messageConfig: {
        useAIGenerated: true,
        includeCallToAction: true,
      },
    };
    setSettings(prev => ({
      ...prev,
      triggers: [...prev.triggers, newTrigger]
    }));
    setEditingTrigger(newTrigger.id);
    setExpandedTrigger(newTrigger.id);
  };

  const handleUpdateTrigger = (triggerId, updates) => {
    setSettings(prev => ({
      ...prev,
      triggers: prev.triggers.map(t => 
        t.id === triggerId ? { ...t, ...updates } : t
      )
    }));
  };

  const handleResetToDefaults = () => {
    if (confirm('Reset all triggers to defaults? This will remove any custom triggers.')) {
      setSettings(prev => ({
        ...prev,
        triggers: DEFAULT_TRIGGERS
      }));
    }
  };

  if (!settings) {
    return <div className="p-6">Loading...</div>;
  }

  const tabs = [
    { id: 'triggers', label: 'AI Triggers', icon: Zap },
    { id: 'channels', label: 'Channel Settings', icon: MessageSquare },
    { id: 'timing', label: 'Timing & Quiet Hours', icon: Clock },
    { id: 'escalation', label: 'Escalation Rules', icon: AlertTriangle },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <button
          onClick={() => navigate('/prc')}
          className="mb-3 flex items-center gap-2 text-sm text-gray-600 hover:text-gray-800"
        >
          <ArrowLeft size={16} />
          Back to Patient Readiness Center
        </button>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <Settings className="text-[#006FB4]" />
              AI Communication Settings
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              Configure when and how AI initiates patient communications
            </p>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={handleToggleGlobal}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                settings.globalEnabled 
                  ? 'bg-green-100 text-green-700 hover:bg-green-200' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {settings.globalEnabled ? (
                <>
                  <ToggleRight size={20} />
                  AI Enabled
                </>
              ) : (
                <>
                  <ToggleLeft size={20} />
                  AI Disabled
                </>
              )}
            </button>
            <button
              onClick={handleSaveSettings}
              disabled={saving}
              className="flex items-center gap-2 px-4 py-2 bg-[#006FB4] text-white rounded-lg hover:bg-[#005a94] disabled:opacity-50"
            >
              <Save size={16} />
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mt-4">
          {tabs.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-t-lg font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'bg-gray-50 text-[#006FB4] border-t border-x border-gray-200'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <Icon size={16} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {activeTab === 'triggers' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold text-gray-900">Communication Triggers</h2>
              <div className="flex gap-2">
                <button
                  onClick={handleResetToDefaults}
                  className="px-3 py-1.5 text-sm text-gray-600 hover:text-gray-900 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Reset to Defaults
                </button>
                <button
                  onClick={handleAddTrigger}
                  className="flex items-center gap-1 px-3 py-1.5 text-sm bg-[#006FB4] text-white rounded-lg hover:bg-[#005a94]"
                >
                  <Plus size={14} />
                  Add Trigger
                </button>
              </div>
            </div>

            <div className="bg-white rounded-lg border border-gray-200 divide-y divide-gray-200">
              {settings.triggers.map(trigger => (
                <TriggerCard
                  key={trigger.id}
                  trigger={trigger}
                  expanded={expandedTrigger === trigger.id}
                  editing={editingTrigger === trigger.id}
                  onToggle={() => handleToggleTrigger(trigger.id)}
                  onExpand={() => setExpandedTrigger(expandedTrigger === trigger.id ? null : trigger.id)}
                  onEdit={() => setEditingTrigger(editingTrigger === trigger.id ? null : trigger.id)}
                  onDelete={() => handleDeleteTrigger(trigger.id)}
                  onUpdate={(updates) => handleUpdateTrigger(trigger.id, updates)}
                />
              ))}
              {settings.triggers.length === 0 && (
                <div className="p-8 text-center text-gray-500">
                  No triggers configured. Click "Add Trigger" to create one.
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'channels' && (
          <ChannelSettings 
            settings={settings} 
            onChange={(updates) => setSettings(prev => ({ ...prev, ...updates }))} 
          />
        )}

        {activeTab === 'timing' && (
          <TimingSettings 
            settings={settings} 
            onChange={(updates) => setSettings(prev => ({ ...prev, ...updates }))} 
          />
        )}

        {activeTab === 'escalation' && (
          <EscalationSettings 
            settings={settings} 
            onChange={(updates) => setSettings(prev => ({ ...prev, ...updates }))} 
          />
        )}
      </div>
    </div>
  );
}

function TriggerCard({ trigger, expanded, editing, onToggle, onExpand, onEdit, onDelete, onUpdate }) {
  const [localTrigger, setLocalTrigger] = useState(trigger);

  useEffect(() => {
    setLocalTrigger(trigger);
  }, [trigger]);

  const handleSave = () => {
    onUpdate(localTrigger);
    onEdit();
  };

  const triggerTypeLabel = TRIGGER_TYPES.find(t => t.value === trigger.triggerType)?.label || trigger.triggerType;

  return (
    <div className={`${!trigger.enabled ? 'opacity-60' : ''}`}>
      <div className="p-4 flex items-center gap-4">
        <button className="text-gray-400 cursor-grab">
          <GripVertical size={16} />
        </button>
        
        <button
          onClick={onToggle}
          className={`w-10 h-6 rounded-full transition-colors ${
            trigger.enabled ? 'bg-green-500' : 'bg-gray-300'
          }`}
        >
          <div className={`w-4 h-4 bg-white rounded-full shadow transform transition-transform ${
            trigger.enabled ? 'translate-x-5' : 'translate-x-1'
          }`} />
        </button>

        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="font-medium text-gray-900">{trigger.name}</span>
            <span className="text-xs px-2 py-0.5 bg-gray-100 text-gray-600 rounded">
              {triggerTypeLabel}
            </span>
          </div>
          <p className="text-sm text-gray-500">{trigger.description}</p>
        </div>

        <div className="flex items-center gap-2">
          {trigger.channelRules.map(rule => {
            const Icon = CHANNEL_ICONS[rule.useChannel];
            return (
              <div 
                key={rule.id}
                className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center"
                title={`${rule.useChannel} (${rule.condition})`}
              >
                <Icon size={14} className="text-gray-600" />
              </div>
            );
          })}
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={onEdit}
            className="p-2 text-gray-400 hover:text-[#006FB4] hover:bg-blue-50 rounded"
          >
            <Edit2 size={16} />
          </button>
          <button
            onClick={onDelete}
            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded"
          >
            <Trash2 size={16} />
          </button>
          <button
            onClick={onExpand}
            className="p-2 text-gray-400 hover:text-gray-600"
          >
            {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </button>
        </div>
      </div>

      {(expanded || editing) && (
        <div className="px-4 pb-4 border-t border-gray-100 bg-gray-50">
          {editing ? (
            <div className="pt-4 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Trigger Name</label>
                  <input
                    type="text"
                    value={localTrigger.name}
                    onChange={(e) => setLocalTrigger(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Trigger Type</label>
                  <select
                    value={localTrigger.triggerType}
                    onChange={(e) => setLocalTrigger(prev => ({ ...prev, triggerType: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  >
                    {TRIGGER_TYPES.map(type => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <input
                  type="text"
                  value={localTrigger.description}
                  onChange={(e) => setLocalTrigger(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Days Before Appt</label>
                  <input
                    type="number"
                    value={localTrigger.timing.daysBeforeAppointment || ''}
                    onChange={(e) => setLocalTrigger(prev => ({ 
                      ...prev, 
                      timing: { ...prev.timing, daysBeforeAppointment: parseInt(e.target.value) || undefined }
                    }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    placeholder="e.g., 3"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Hours Before Appt</label>
                  <input
                    type="number"
                    value={localTrigger.timing.hoursBeforeAppointment || ''}
                    onChange={(e) => setLocalTrigger(prev => ({ 
                      ...prev, 
                      timing: { ...prev.timing, hoursBeforeAppointment: parseInt(e.target.value) || undefined }
                    }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    placeholder="e.g., 24"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Max Attempts</label>
                  <input
                    type="number"
                    value={localTrigger.timing.maxAttempts}
                    onChange={(e) => setLocalTrigger(prev => ({ 
                      ...prev, 
                      timing: { ...prev.timing, maxAttempts: parseInt(e.target.value) || 1 }
                    }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    min="1"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Channel Priority</label>
                <div className="space-y-2">
                  {localTrigger.channelRules.map((rule, idx) => (
                    <div key={rule.id} className="flex items-center gap-2 p-2 bg-white rounded border border-gray-200">
                      <span className="text-xs text-gray-500 w-6">{idx + 1}.</span>
                      <select
                        value={rule.condition}
                        onChange={(e) => {
                          const newRules = [...localTrigger.channelRules];
                          newRules[idx] = { ...rule, condition: e.target.value };
                          setLocalTrigger(prev => ({ ...prev, channelRules: newRules }));
                        }}
                        className="px-2 py-1 border border-gray-300 rounded text-sm"
                      >
                        <option value="patient_preference">Patient Preference</option>
                        <option value="time_of_day">Time of Day</option>
                        <option value="urgency">Urgency Level</option>
                        <option value="fallback">Fallback</option>
                      </select>
                      <span className="text-gray-500">→</span>
                      <select
                        value={rule.useChannel}
                        onChange={(e) => {
                          const newRules = [...localTrigger.channelRules];
                          newRules[idx] = { ...rule, useChannel: e.target.value };
                          setLocalTrigger(prev => ({ ...prev, channelRules: newRules }));
                        }}
                        className="px-2 py-1 border border-gray-300 rounded text-sm"
                      >
                        <option value="sms">SMS</option>
                        <option value="voice">Voice</option>
                        <option value="email">Email</option>
                      </select>
                      <label className="flex items-center gap-1 text-xs text-gray-600 ml-2">
                        <input
                          type="checkbox"
                          checked={rule.respectOptOut}
                          onChange={(e) => {
                            const newRules = [...localTrigger.channelRules];
                            newRules[idx] = { ...rule, respectOptOut: e.target.checked };
                            setLocalTrigger(prev => ({ ...prev, channelRules: newRules }));
                          }}
                        />
                        Respect Opt-out
                      </label>
                      <button
                        onClick={() => {
                          const newRules = localTrigger.channelRules.filter((_, i) => i !== idx);
                          setLocalTrigger(prev => ({ ...prev, channelRules: newRules }));
                        }}
                        className="ml-auto p-1 text-gray-400 hover:text-red-600"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                  <button
                    onClick={() => {
                      const newRule = {
                        id: `r${Date.now()}`,
                        priority: localTrigger.channelRules.length + 1,
                        condition: 'fallback',
                        useChannel: 'email',
                        respectOptOut: true,
                      };
                      setLocalTrigger(prev => ({ 
                        ...prev, 
                        channelRules: [...prev.channelRules, newRule] 
                      }));
                    }}
                    className="text-sm text-[#006FB4] hover:underline"
                  >
                    + Add Channel Rule
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-4 pt-2">
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={localTrigger.messageConfig.useAIGenerated}
                    onChange={(e) => setLocalTrigger(prev => ({ 
                      ...prev, 
                      messageConfig: { ...prev.messageConfig, useAIGenerated: e.target.checked }
                    }))}
                  />
                  Use AI-Generated Messages
                </label>
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={localTrigger.messageConfig.includeCallToAction}
                    onChange={(e) => setLocalTrigger(prev => ({ 
                      ...prev, 
                      messageConfig: { ...prev.messageConfig, includeCallToAction: e.target.checked }
                    }))}
                  />
                  Include Call-to-Action
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={onEdit}
                  className="px-4 py-2 text-sm text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="px-4 py-2 text-sm bg-[#006FB4] text-white rounded-lg hover:bg-[#005a94]"
                >
                  Save Trigger
                </button>
              </div>
            </div>
          ) : (
            <div className="pt-4 grid grid-cols-3 gap-4 text-sm">
              <div>
                <span className="text-gray-500">Timing:</span>
                <div className="text-gray-900">
                  {trigger.timing.daysBeforeAppointment && `${trigger.timing.daysBeforeAppointment} days before`}
                  {trigger.timing.hoursBeforeAppointment && `${trigger.timing.hoursBeforeAppointment} hours before`}
                  {trigger.timing.delayMinutes && `${trigger.timing.delayMinutes} min delay`}
                  {!trigger.timing.daysBeforeAppointment && !trigger.timing.hoursBeforeAppointment && !trigger.timing.delayMinutes && 'Immediate'}
                </div>
              </div>
              <div>
                <span className="text-gray-500">Max Attempts:</span>
                <div className="text-gray-900">{trigger.timing.maxAttempts}</div>
              </div>
              <div>
                <span className="text-gray-500">Message:</span>
                <div className="text-gray-900">
                  {trigger.messageConfig.useAIGenerated ? 'AI Generated' : 'Template'}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ChannelSettings({ settings, onChange }) {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-gray-900">Channel Configuration</h2>
      
      {/* Default Channel Order */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
          <Settings size={16} />
          Default Channel Priority
        </h3>
        <p className="text-sm text-gray-500 mb-3">
          When patient has no preference, channels are tried in this order
        </p>
        <div className="flex gap-2">
          {settings.defaultChannelOrder.map((channel, idx) => {
            const Icon = CHANNEL_ICONS[channel];
            return (
              <div key={channel} className="flex items-center gap-2 px-3 py-2 bg-gray-100 rounded-lg">
                <span className="text-xs text-gray-500">{idx + 1}.</span>
                <Icon size={16} className="text-gray-600" />
                <span className="text-sm font-medium capitalize">{channel}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Voice Settings */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
          <Phone size={16} className="text-green-600" />
          Voice Settings
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={settings.voiceSettings?.aiConversationMode ?? true}
              onChange={(e) => onChange({ 
                voiceSettings: { ...settings.voiceSettings, aiConversationMode: e.target.checked }
              })}
            />
            <span className="text-sm">AI Conversation Mode</span>
            <span className="text-xs text-gray-400">(vs IVR menu)</span>
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={settings.voiceSettings.callRecording}
              onChange={(e) => onChange({ 
                voiceSettings: { ...settings.voiceSettings, callRecording: e.target.checked }
              })}
            />
            <span className="text-sm">Record Calls</span>
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={settings.voiceSettings.useAIVoice}
              onChange={(e) => onChange({ 
                voiceSettings: { ...settings.voiceSettings, useAIVoice: e.target.checked }
              })}
            />
            <span className="text-sm">Use AI Voice (ElevenLabs)</span>
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={settings.voiceSettings.enableVoicemail}
              onChange={(e) => onChange({ 
                voiceSettings: { ...settings.voiceSettings, enableVoicemail: e.target.checked }
              })}
            />
            <span className="text-sm">Enable Voicemail</span>
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={settings.voiceSettings.voicemailTranscription}
              onChange={(e) => onChange({ 
                voiceSettings: { ...settings.voiceSettings, voicemailTranscription: e.target.checked }
              })}
            />
            <span className="text-sm">Transcribe Voicemails</span>
          </label>
          <div>
            <label className="block text-sm text-gray-600 mb-1">AI Voice (ElevenLabs)</label>
            <select
              value={settings.voiceSettings?.elevenLabsVoice || 'sarah'}
              onChange={(e) => onChange({ 
                voiceSettings: { ...settings.voiceSettings, elevenLabsVoice: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
            >
              <option value="sarah">Sarah - Warm, Friendly (Recommended)</option>
              <option value="rachel">Rachel - Clear, Professional</option>
              <option value="emily">Emily - Soft, Empathetic</option>
              <option value="josh">Josh - Friendly Male</option>
              <option value="adam">Adam - Deep, Calm Male</option>
            </select>
            <p className="text-xs text-gray-400 mt-1">High-quality neural voice for natural conversations</p>
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Background Ambiance</label>
            <select
              value={settings.voiceSettings?.ambientSound || 'medical-office'}
              onChange={(e) => onChange({ 
                voiceSettings: { ...settings.voiceSettings, ambientSound: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
            >
              <option value="none">None</option>
              <option value="medical-office">Medical Office (Subtle)</option>
              <option value="busy-office">Busy Office</option>
              <option value="quiet-office">Quiet Office</option>
              <option value="reception">Reception Area</option>
            </select>
            <p className="text-xs text-gray-400 mt-1">Adds realism - sounds like a real office</p>
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Office Transfer Number</label>
            <input
              type="tel"
              value={settings.voiceSettings?.officeTransferNumber || ''}
              onChange={(e) => onChange({ 
                voiceSettings: { ...settings.voiceSettings, officeTransferNumber: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              placeholder="+1234567890"
            />
            <p className="text-xs text-gray-400 mt-1">Where calls transfer when patient asks for staff</p>
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Max Conversation Turns</label>
            <input
              type="number"
              value={settings.voiceSettings?.maxConversationTurns || 10}
              onChange={(e) => onChange({ 
                voiceSettings: { ...settings.voiceSettings, maxConversationTurns: parseInt(e.target.value) }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              min="1"
              max="20"
            />
            <p className="text-xs text-gray-400 mt-1">Auto-transfer after this many exchanges</p>
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Max Call Duration (seconds)</label>
            <input
              type="number"
              value={settings.voiceSettings.maxCallDurationSeconds}
              onChange={(e) => onChange({ 
                voiceSettings: { ...settings.voiceSettings, maxCallDurationSeconds: parseInt(e.target.value) }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
            />
          </div>
        </div>
      </div>

      {/* SMS Settings */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
          <MessageSquare size={16} className="text-blue-600" />
          SMS Settings
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={settings.smsSettings.useAIReplies}
              onChange={(e) => onChange({ 
                smsSettings: { ...settings.smsSettings, useAIReplies: e.target.checked }
              })}
            />
            <span className="text-sm">Use AI Auto-Replies</span>
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={settings.smsSettings.includeOptOutInstructions}
              onChange={(e) => onChange({ 
                smsSettings: { ...settings.smsSettings, includeOptOutInstructions: e.target.checked }
              })}
            />
            <span className="text-sm">Include Opt-out Instructions</span>
          </label>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Max Message Length</label>
            <input
              type="number"
              value={settings.smsSettings.maxMessageLength}
              onChange={(e) => onChange({ 
                smsSettings: { ...settings.smsSettings, maxMessageLength: parseInt(e.target.value) }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Opt-out Keywords</label>
            <input
              type="text"
              value={settings.smsSettings.optOutKeywords.join(', ')}
              onChange={(e) => onChange({ 
                smsSettings: { ...settings.smsSettings, optOutKeywords: e.target.value.split(',').map(s => s.trim()) }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              placeholder="STOP, UNSUBSCRIBE"
            />
          </div>
        </div>
      </div>

      {/* Email Settings */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
          <Mail size={16} className="text-purple-600" />
          Email Settings
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-gray-600 mb-1">From Name</label>
            <input
              type="text"
              value={settings.emailSettings.fromName}
              onChange={(e) => onChange({ 
                emailSettings: { ...settings.emailSettings, fromName: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">From Email</label>
            <input
              type="email"
              value={settings.emailSettings.fromEmail}
              onChange={(e) => onChange({ 
                emailSettings: { ...settings.emailSettings, fromEmail: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Reply-To Email</label>
            <input
              type="email"
              value={settings.emailSettings.replyToEmail}
              onChange={(e) => onChange({ 
                emailSettings: { ...settings.emailSettings, replyToEmail: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
            />
          </div>
          <div className="space-y-2">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings.emailSettings.useAIReplies}
                onChange={(e) => onChange({ 
                  emailSettings: { ...settings.emailSettings, useAIReplies: e.target.checked }
                })}
              />
              <span className="text-sm">Use AI Auto-Replies</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings.emailSettings.includeUnsubscribeLink}
                onChange={(e) => onChange({ 
                  emailSettings: { ...settings.emailSettings, includeUnsubscribeLink: e.target.checked }
                })}
              />
              <span className="text-sm">Include Unsubscribe Link</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings.emailSettings.trackOpens}
                onChange={(e) => onChange({ 
                  emailSettings: { ...settings.emailSettings, trackOpens: e.target.checked }
                })}
              />
              <span className="text-sm">Track Opens</span>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}

function TimingSettings({ settings, onChange }) {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-gray-900">Timing & Quiet Hours</h2>
      
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium text-gray-900 flex items-center gap-2">
            <Clock size={16} />
            Quiet Hours
          </h3>
          <button
            onClick={() => onChange({ 
              quietHours: { ...settings.quietHours, enabled: !settings.quietHours.enabled }
            })}
            className={`w-10 h-6 rounded-full transition-colors ${
              settings.quietHours.enabled ? 'bg-green-500' : 'bg-gray-300'
            }`}
          >
            <div className={`w-4 h-4 bg-white rounded-full shadow transform transition-transform ${
              settings.quietHours.enabled ? 'translate-x-5' : 'translate-x-1'
            }`} />
          </button>
        </div>
        <p className="text-sm text-gray-500 mb-4">
          No automated communications will be sent during quiet hours
        </p>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm text-gray-600 mb-1">Start Time</label>
            <input
              type="time"
              value={settings.quietHours.start}
              onChange={(e) => onChange({ 
                quietHours: { ...settings.quietHours, start: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              disabled={!settings.quietHours.enabled}
            />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">End Time</label>
            <input
              type="time"
              value={settings.quietHours.end}
              onChange={(e) => onChange({ 
                quietHours: { ...settings.quietHours, end: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              disabled={!settings.quietHours.enabled}
            />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Timezone</label>
            <select
              value={settings.quietHours.timezone}
              onChange={(e) => onChange({ 
                quietHours: { ...settings.quietHours, timezone: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              disabled={!settings.quietHours.enabled}
            >
              <option value="America/New_York">Eastern Time</option>
              <option value="America/Chicago">Central Time</option>
              <option value="America/Denver">Mountain Time</option>
              <option value="America/Los_Angeles">Pacific Time</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
          <Shield size={16} />
          Approval Settings
        </h3>
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={settings.requireApprovalForOutbound}
            onChange={(e) => onChange({ requireApprovalForOutbound: e.target.checked })}
          />
          <span className="text-sm">Require staff approval before sending AI-generated messages</span>
        </label>
      </div>
    </div>
  );
}

function EscalationSettings({ settings, onChange }) {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-gray-900">Escalation Rules</h2>
      
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="font-medium text-gray-900 mb-4 flex items-center gap-2">
          <AlertTriangle size={16} className="text-orange-500" />
          Auto-Escalation Triggers
        </h3>
        
        <div className="space-y-4">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={settings.escalation.escalateOnNoResponse}
              onChange={(e) => onChange({ 
                escalation: { ...settings.escalation, escalateOnNoResponse: e.target.checked }
              })}
            />
            <span className="text-sm">Escalate when patient doesn't respond</span>
          </label>
          
          {settings.escalation.escalateOnNoResponse && (
            <div className="ml-6">
              <label className="block text-sm text-gray-600 mb-1">Hours without response</label>
              <input
                type="number"
                value={settings.escalation.noResponseHours}
                onChange={(e) => onChange({ 
                  escalation: { ...settings.escalation, noResponseHours: parseInt(e.target.value) }
                })}
                className="w-32 px-3 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>
          )}

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={settings.escalation.escalateOnNegativeSentiment}
              onChange={(e) => onChange({ 
                escalation: { ...settings.escalation, escalateOnNegativeSentiment: e.target.checked }
              })}
            />
            <span className="text-sm">Escalate on negative sentiment</span>
          </label>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="font-medium text-gray-900 mb-3">Escalation Keywords</h3>
        <p className="text-sm text-gray-500 mb-3">
          Messages containing these keywords will be automatically escalated
        </p>
        <textarea
          value={settings.escalation.escalateKeywords.join(', ')}
          onChange={(e) => onChange({ 
            escalation: { 
              ...settings.escalation, 
              escalateKeywords: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
            }
          })}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm h-24"
          placeholder="urgent, emergency, pain, bleeding..."
        />
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
          <Bell size={16} />
          Staff Notifications
        </h3>
        <p className="text-sm text-gray-500 mb-3">
          How should staff be notified of escalations?
        </p>
        <div className="flex gap-4">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={settings.escalation.notifyStaffVia.includes('in_app')}
              onChange={(e) => {
                const methods = e.target.checked 
                  ? [...settings.escalation.notifyStaffVia, 'in_app']
                  : settings.escalation.notifyStaffVia.filter(m => m !== 'in_app');
                onChange({ escalation: { ...settings.escalation, notifyStaffVia: methods }});
              }}
            />
            <span className="text-sm">In-App Alert</span>
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={settings.escalation.notifyStaffVia.includes('email')}
              onChange={(e) => {
                const methods = e.target.checked 
                  ? [...settings.escalation.notifyStaffVia, 'email']
                  : settings.escalation.notifyStaffVia.filter(m => m !== 'email');
                onChange({ escalation: { ...settings.escalation, notifyStaffVia: methods }});
              }}
            />
            <span className="text-sm">Email</span>
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={settings.escalation.notifyStaffVia.includes('sms')}
              onChange={(e) => {
                const methods = e.target.checked 
                  ? [...settings.escalation.notifyStaffVia, 'sms']
                  : settings.escalation.notifyStaffVia.filter(m => m !== 'sms');
                onChange({ escalation: { ...settings.escalation, notifyStaffVia: methods }});
              }}
            />
            <span className="text-sm">SMS</span>
          </label>
        </div>
      </div>

      {/* Alert Recipients */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium text-gray-900 flex items-center gap-2">
            <Phone size={16} className="text-blue-500" />
            Alert Recipients
          </h3>
          <button
            onClick={() => {
              const newRecipient = {
                id: `recipient_${Date.now()}`,
                name: '',
                phone: '',
                email: '',
                role: 'staff',
                notifyVia: ['sms'],
                priorityThreshold: 'medium',
              };
              onChange({
                escalation: {
                  ...settings.escalation,
                  alertRecipients: [...(settings.escalation.alertRecipients || []), newRecipient]
                }
              });
            }}
            className="flex items-center gap-1 px-3 py-1.5 text-sm bg-[#006FB4] text-white rounded-lg hover:bg-[#005a94]"
          >
            <Plus size={14} />
            Add Recipient
          </button>
        </div>
        <p className="text-sm text-gray-500 mb-4">
          These people will receive real-time Twilio alerts (SMS/Voice) when escalations occur
        </p>
        
        {(settings.escalation.alertRecipients || []).length === 0 ? (
          <div className="text-center py-6 text-gray-400 text-sm border border-dashed border-gray-200 rounded-lg">
            No alert recipients configured. Add someone to receive escalation alerts.
          </div>
        ) : (
          <div className="space-y-3">
            {(settings.escalation.alertRecipients || []).map((recipient, idx) => (
              <div key={recipient.id} className="border border-gray-200 rounded-lg p-3 bg-gray-50">
                <div className="grid grid-cols-4 gap-3 mb-3">
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Name</label>
                    <input
                      type="text"
                      value={recipient.name}
                      onChange={(e) => {
                        const updated = [...settings.escalation.alertRecipients];
                        updated[idx] = { ...recipient, name: e.target.value };
                        onChange({ escalation: { ...settings.escalation, alertRecipients: updated }});
                      }}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded text-sm"
                      placeholder="John Smith"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Phone</label>
                    <input
                      type="tel"
                      value={recipient.phone}
                      onChange={(e) => {
                        const updated = [...settings.escalation.alertRecipients];
                        updated[idx] = { ...recipient, phone: e.target.value };
                        onChange({ escalation: { ...settings.escalation, alertRecipients: updated }});
                      }}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded text-sm"
                      placeholder="+1234567890"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Role</label>
                    <select
                      value={recipient.role}
                      onChange={(e) => {
                        const updated = [...settings.escalation.alertRecipients];
                        updated[idx] = { ...recipient, role: e.target.value };
                        onChange({ escalation: { ...settings.escalation, alertRecipients: updated }});
                      }}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded text-sm"
                    >
                      <option value="staff">Staff</option>
                      <option value="supervisor">Supervisor</option>
                      <option value="manager">Manager</option>
                      <option value="on-call">On-Call</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Priority Threshold</label>
                    <select
                      value={recipient.priorityThreshold}
                      onChange={(e) => {
                        const updated = [...settings.escalation.alertRecipients];
                        updated[idx] = { ...recipient, priorityThreshold: e.target.value };
                        onChange({ escalation: { ...settings.escalation, alertRecipients: updated }});
                      }}
                      className="w-full px-2 py-1.5 border border-gray-300 rounded text-sm"
                    >
                      <option value="low">Low & above</option>
                      <option value="medium">Medium & above</option>
                      <option value="high">High & above</option>
                      <option value="urgent">Urgent only</option>
                    </select>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <span className="text-xs text-gray-500">Notify via:</span>
                    <label className="flex items-center gap-1 text-sm">
                      <input
                        type="checkbox"
                        checked={recipient.notifyVia.includes('sms')}
                        onChange={(e) => {
                          const updated = [...settings.escalation.alertRecipients];
                          const methods = e.target.checked 
                            ? [...recipient.notifyVia, 'sms']
                            : recipient.notifyVia.filter(m => m !== 'sms');
                          updated[idx] = { ...recipient, notifyVia: methods };
                          onChange({ escalation: { ...settings.escalation, alertRecipients: updated }});
                        }}
                      />
                      SMS
                    </label>
                    <label className="flex items-center gap-1 text-sm">
                      <input
                        type="checkbox"
                        checked={recipient.notifyVia.includes('voice')}
                        onChange={(e) => {
                          const updated = [...settings.escalation.alertRecipients];
                          const methods = e.target.checked 
                            ? [...recipient.notifyVia, 'voice']
                            : recipient.notifyVia.filter(m => m !== 'voice');
                          updated[idx] = { ...recipient, notifyVia: methods };
                          onChange({ escalation: { ...settings.escalation, alertRecipients: updated }});
                        }}
                      />
                      Voice Call
                    </label>
                    <label className="flex items-center gap-1 text-sm">
                      <input
                        type="checkbox"
                        checked={recipient.notifyVia.includes('email')}
                        onChange={(e) => {
                          const updated = [...settings.escalation.alertRecipients];
                          const methods = e.target.checked 
                            ? [...recipient.notifyVia, 'email']
                            : recipient.notifyVia.filter(m => m !== 'email');
                          updated[idx] = { ...recipient, notifyVia: methods };
                          onChange({ escalation: { ...settings.escalation, alertRecipients: updated }});
                        }}
                      />
                      Email
                    </label>
                  </div>
                  <button
                    onClick={() => {
                      const updated = settings.escalation.alertRecipients.filter((_, i) => i !== idx);
                      onChange({ escalation: { ...settings.escalation, alertRecipients: updated }});
                    }}
                    className="p-1 text-gray-400 hover:text-red-600"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Auto-escalation timing */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
          <Clock size={16} />
          Auto-Escalation Timing
        </h3>
        <div>
          <label className="block text-sm text-gray-600 mb-1">Re-alert after (minutes)</label>
          <input
            type="number"
            value={settings.escalation.autoEscalateAfterMinutes || 15}
            onChange={(e) => onChange({ 
              escalation: { ...settings.escalation, autoEscalateAfterMinutes: parseInt(e.target.value) }
            })}
            className="w-32 px-3 py-2 border border-gray-300 rounded-lg text-sm"
            min="5"
          />
          <p className="text-xs text-gray-400 mt-1">
            If escalation not acknowledged, re-send alerts with upgraded priority
          </p>
        </div>
      </div>
    </div>
  );
}
