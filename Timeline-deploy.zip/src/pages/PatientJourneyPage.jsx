/**
 * Patient Journey Page
 * Main page for managing patient journeys with the Kanban board
 */

import React, { useState } from 'react';
import { PatientJourneyProvider } from '../contexts/PatientJourneyContext';
import { PatientJourneyBoard } from '../components/patient-journey';
import { PatientJourneyService } from '../lib/services/patient-journey-service';
import { X, Plus, User, Calendar, FileText, AlertCircle } from 'lucide-react';

function CreateJourneyModal({ isOpen, onClose, onCreated }) {
  const [formData, setFormData] = useState({
    patientName: '',
    patientId: '',
    reasonForVisit: '',
    providerName: '',
    priority: 'normal',
    startPhase: 'pre-visit'
  });
  const [error, setError] = useState(null);

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    setError(null);

    if (!formData.patientName.trim()) {
      setError('Patient name is required');
      return;
    }

    try {
      const journey = PatientJourneyService.createJourney({
        patientId: formData.patientId || `patient-${Date.now()}`,
        patientName: formData.patientName.trim(),
        reasonForVisit: formData.reasonForVisit,
        providerName: formData.providerName,
        priority: formData.priority,
        startPhase: formData.startPhase,
        scheduledAppointmentDate: new Date()
      });

      onCreated(journey);
      onClose();
      setFormData({
        patientName: '',
        patientId: '',
        reasonForVisit: '',
        providerName: '',
        priority: 'normal',
        startPhase: 'pre-visit'
      });
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md mx-4">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold">Create Patient Journey</h2>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 text-red-700 rounded-lg flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Patient Name *
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={formData.patientName}
                onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="John Smith"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Reason for Visit
            </label>
            <div className="relative">
              <FileText className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={formData.reasonForVisit}
                onChange={(e) => setFormData({ ...formData, reasonForVisit: e.target.value })}
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="Annual eye exam"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Provider
            </label>
            <input
              type="text"
              value={formData.providerName}
              onChange={(e) => setFormData({ ...formData, providerName: e.target.value })}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="Dr. Johnson"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Priority
              </label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="normal">Normal</option>
                <option value="urgent">Urgent</option>
                <option value="vip">VIP</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Start Phase
              </label>
              <select
                value={formData.startPhase}
                onChange={(e) => setFormData({ ...formData, startPhase: e.target.value })}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="pre-visit">Pre-Visit</option>
                <option value="in-office">In-Office</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Create Journey
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function PatientJourneyPageContent() {
  const [showCreateModal, setShowCreateModal] = useState(false);

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      <PatientJourneyBoard 
        onCreateJourney={() => setShowCreateModal(true)}
      />
      
      <CreateJourneyModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onCreated={(journey) => {
          console.log('Journey created:', journey);
        }}
      />
    </div>
  );
}

export default function PatientJourneyPage() {
  return (
    <PatientJourneyProvider>
      <PatientJourneyPageContent />
    </PatientJourneyProvider>
  );
}
