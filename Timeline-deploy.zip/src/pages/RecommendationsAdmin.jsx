/**
 * Recommendations Admin Page
 * 
 * Manage recommendation rules, view analytics, and test recommendations
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  Power, 
  PowerOff, 
  TrendingUp,
  Eye,
  MousePointerClick,
  CheckCircle,
  XCircle,
  Copy,
  Sparkles,
  BarChart3,
  Settings,
  Search,
  Filter,
  ChevronDown,
  ChevronUp,
  ArrowLeft
} from 'lucide-react';
import { RecommendationService } from '../lib/services/recommendation-service';
import RuleBuilderModal from '../components/recommendations/RuleBuilderModal';

const RecommendationsAdmin = () => {
  const navigate = useNavigate();
  const [rules, setRules] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [activeTab, setActiveTab] = useState('rules');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [showRuleBuilder, setShowRuleBuilder] = useState(false);
  const [editingRule, setEditingRule] = useState(null);
  const [expandedRules, setExpandedRules] = useState(new Set());

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const allRules = RecommendationService.getRules();
    setRules(allRules);
    
    const stats = RecommendationService.getAnalytics();
    setAnalytics(stats);
  };

  const handleToggleRule = (ruleId) => {
    const rule = rules.find(r => r.id === ruleId);
    if (rule) {
      RecommendationService.updateRule(ruleId, { enabled: !rule.enabled });
      loadData();
    }
  };

  const handleDeleteRule = (ruleId) => {
    if (confirm('Are you sure you want to delete this rule?')) {
      RecommendationService.deleteRule(ruleId);
      loadData();
    }
  };

  const handleDuplicateRule = (rule) => {
    const newRule = {
      ...rule,
      name: `${rule.name} (Copy)`,
      enabled: false,
      metrics: {
        impressions: 0,
        clicks: 0,
        conversions: 0,
        dismissals: 0,
        lastUpdated: new Date()
      }
    };
    delete newRule.id;
    delete newRule.createdAt;
    delete newRule.updatedAt;
    
    RecommendationService.createRule(newRule);
    loadData();
  };

  const handleEditRule = (rule) => {
    setEditingRule(rule);
    setShowRuleBuilder(true);
  };

  const handleCreateRule = () => {
    setEditingRule(null);
    setShowRuleBuilder(true);
  };

  const toggleRuleExpansion = (ruleId) => {
    const newExpanded = new Set(expandedRules);
    if (newExpanded.has(ruleId)) {
      newExpanded.delete(ruleId);
    } else {
      newExpanded.add(ruleId);
    }
    setExpandedRules(newExpanded);
  };

  // Filter rules
  const filteredRules = rules.filter(rule => {
    const matchesSearch = rule.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         rule.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === 'all' || rule.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  // Get unique categories
  const categories = ['all', ...new Set(rules.map(r => r.category).filter(Boolean))];

  const formatNumber = (num) => {
    return new Intl.NumberFormat('en-US').format(num);
  };

  const formatPercent = (num) => {
    return `${(num * 100).toFixed(1)}%`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="bg-white border-b shadow-sm px-6 py-4">
          <button
            onClick={() => navigate('/prc')}
            className="mb-3 flex items-center gap-2 text-sm text-gray-600 hover:text-gray-800"
          >
            <ArrowLeft size={16} />
            Back to Patient Readiness Center
          </button>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Recommendations</h1>
                <p className="text-sm text-gray-500">Manage rules and view analytics</p>
              </div>
            </div>
            <button
              onClick={handleCreateRule}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2 font-medium"
            >
              <Plus className="w-4 h-4" />
              Create Rule
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 mt-6">
            <button
              onClick={() => setActiveTab('rules')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'rules'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              Rules ({rules.length})
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'analytics'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              Analytics
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-6 py-6">
        {activeTab === 'rules' && (
          <>
            {/* Stats Bar */}
            <div className="grid grid-cols-4 gap-4 mb-6">
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Total Rules</p>
                    <p className="text-2xl font-bold text-gray-900">{rules.length}</p>
                  </div>
                  <Settings className="w-8 h-8 text-gray-400" />
                </div>
              </div>
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Active Rules</p>
                    <p className="text-2xl font-bold text-green-600">
                      {rules.filter(r => r.enabled).length}
                    </p>
                  </div>
                  <Power className="w-8 h-8 text-green-500" />
                </div>
              </div>
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Avg CTR</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {analytics ? formatPercent(analytics.avgCTR) : '0%'}
                    </p>
                  </div>
                  <MousePointerClick className="w-8 h-8 text-blue-500" />
                </div>
              </div>
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Conversion Rate</p>
                    <p className="text-2xl font-bold text-purple-600">
                      {analytics ? formatPercent(analytics.avgConversionRate) : '0%'}
                    </p>
                  </div>
                  <CheckCircle className="w-8 h-8 text-purple-500" />
                </div>
              </div>
            </div>

            {/* Filters */}
            <div className="bg-white rounded-lg border border-gray-200 p-4 mb-4">
              <div className="flex gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search rules..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div className="relative">
                  <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <select
                    value={filterCategory}
                    onChange={(e) => setFilterCategory(e.target.value)}
                    className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 appearance-none bg-white"
                  >
                    {categories.map(cat => (
                      <option key={cat} value={cat}>
                        {cat === 'all' ? 'All Categories' : cat.replace(/-/g, ' ')}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Rules List */}
            <div className="space-y-3">
              {filteredRules.length === 0 ? (
                <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
                  <Sparkles className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No rules found</h3>
                  <p className="text-gray-500 mb-4">
                    {searchTerm || filterCategory !== 'all'
                      ? 'Try adjusting your filters'
                      : 'Create your first recommendation rule to get started'}
                  </p>
                  <button
                    onClick={handleCreateRule}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 inline-flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Create Rule
                  </button>
                </div>
              ) : (
                filteredRules.map(rule => (
                  <RuleCard
                    key={rule.id}
                    rule={rule}
                    expanded={expandedRules.has(rule.id)}
                    onToggleExpand={() => toggleRuleExpansion(rule.id)}
                    onToggle={() => handleToggleRule(rule.id)}
                    onEdit={() => handleEditRule(rule)}
                    onDuplicate={() => handleDuplicateRule(rule)}
                    onDelete={() => handleDeleteRule(rule.id)}
                  />
                ))
              )}
            </div>
          </>
        )}

        {activeTab === 'analytics' && analytics && (
          <AnalyticsDashboard analytics={analytics} />
        )}
      </div>

      {/* Rule Builder Modal */}
      {showRuleBuilder && (
        <RuleBuilderModal
          rule={editingRule}
          onClose={() => {
            setShowRuleBuilder(false);
            setEditingRule(null);
          }}
          onSave={() => {
            loadData();
            setShowRuleBuilder(false);
            setEditingRule(null);
          }}
        />
      )}
    </div>
  );
};

// Rule Card Component
const RuleCard = ({ rule, expanded, onToggleExpand, onToggle, onEdit, onDuplicate, onDelete }) => {
  const ctr = rule.metrics.impressions > 0 
    ? (rule.metrics.clicks / rule.metrics.impressions * 100).toFixed(1)
    : '0.0';
  const convRate = rule.metrics.impressions > 0
    ? (rule.metrics.conversions / rule.metrics.impressions * 100).toFixed(1)
    : '0.0';

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="p-4">
        <div className="flex items-start gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h3 className="text-lg font-semibold text-gray-900">{rule.name}</h3>
              {rule.enabled ? (
                <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded-full font-medium">
                  Active
                </span>
              ) : (
                <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded-full font-medium">
                  Inactive
                </span>
              )}
              <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded-full font-medium">
                Priority: {rule.priority}
              </span>
              {rule.category && (
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded-full font-medium capitalize">
                  {rule.category.replace(/-/g, ' ')}
                </span>
              )}
            </div>
            <p className="text-sm text-gray-600 mb-3">{rule.description}</p>

            {/* Quick Stats */}
            <div className="flex items-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-gray-400" />
                <span className="text-gray-600">{rule.metrics.impressions} impressions</span>
              </div>
              <div className="flex items-center gap-2">
                <MousePointerClick className="w-4 h-4 text-blue-500" />
                <span className="text-gray-600">{rule.metrics.clicks} clicks</span>
                <span className="text-blue-600 font-medium">({ctr}%)</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-gray-600">{rule.metrics.conversions} conversions</span>
                <span className="text-green-600 font-medium">({convRate}%)</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={onToggle}
              className={`p-2 rounded-lg transition-colors ${
                rule.enabled
                  ? 'text-green-600 hover:bg-green-50'
                  : 'text-gray-400 hover:bg-gray-50'
              }`}
              title={rule.enabled ? 'Disable' : 'Enable'}
            >
              {rule.enabled ? <Power className="w-5 h-5" /> : <PowerOff className="w-5 h-5" />}
            </button>
            <button
              onClick={onEdit}
              className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              title="Edit"
            >
              <Edit2 className="w-5 h-5" />
            </button>
            <button
              onClick={onDuplicate}
              className="p-2 text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
              title="Duplicate"
            >
              <Copy className="w-5 h-5" />
            </button>
            <button
              onClick={onDelete}
              className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              title="Delete"
            >
              <Trash2 className="w-5 h-5" />
            </button>
            <button
              onClick={onToggleExpand}
              className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
              title={expanded ? 'Collapse' : 'Expand'}
            >
              {expanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Expanded Details */}
      {expanded && (
        <div className="border-t border-gray-200 bg-gray-50 p-4">
          <div className="grid grid-cols-2 gap-6">
            {/* Conditions */}
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-2">Conditions ({rule.conditions.length})</h4>
              <div className="space-y-1">
                {rule.conditions.map((cond, idx) => (
                  <div key={idx} className="text-sm text-gray-600 font-mono bg-white rounded px-2 py-1">
                    {cond.field} {cond.operator} {JSON.stringify(cond.value)}
                    {cond.logicalOperator && (
                      <span className="ml-2 text-purple-600 font-semibold">{cond.logicalOperator}</span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Recommendation Content */}
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-2">Recommendation</h4>
              <div className="bg-white rounded-lg p-3 text-sm">
                <p className="font-medium text-gray-900 mb-1">{rule.recommendation.title}</p>
                <p className="text-gray-600 mb-2">{rule.recommendation.description}</p>
                {rule.recommendation.ctaText && (
                  <div className="text-blue-600">
                    CTA: {rule.recommendation.ctaText}
                  </div>
                )}
              </div>
            </div>

            {/* Display Locations */}
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-2">Display Locations</h4>
              <div className="flex flex-wrap gap-1">
                {rule.displayConfig.locations.map(loc => (
                  <span key={loc} className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded">
                    {loc}
                  </span>
                ))}
              </div>
            </div>

            {/* Tags */}
            {rule.tags && rule.tags.length > 0 && (
              <div>
                <h4 className="text-sm font-semibold text-gray-900 mb-2">Tags</h4>
                <div className="flex flex-wrap gap-1">
                  {rule.tags.map(tag => (
                    <span key={tag} className="px-2 py-1 bg-gray-200 text-gray-700 text-xs rounded">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

// Analytics Dashboard Component
const AnalyticsDashboard = ({ analytics }) => {
  return (
    <div className="space-y-6">
      {/* Overview Stats */}
      <div className="grid grid-cols-4 gap-6">
        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-500">Total Impressions</h3>
            <Eye className="w-5 h-5 text-gray-400" />
          </div>
          <p className="text-3xl font-bold text-gray-900">
            {new Intl.NumberFormat('en-US').format(analytics.totalImpressions)}
          </p>
        </div>
        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-500">Total Clicks</h3>
            <MousePointerClick className="w-5 h-5 text-blue-500" />
          </div>
          <p className="text-3xl font-bold text-blue-600">
            {new Intl.NumberFormat('en-US').format(analytics.totalClicks)}
          </p>
          <p className="text-sm text-gray-500 mt-1">
            {(analytics.avgCTR * 100).toFixed(1)}% CTR
          </p>
        </div>
        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-500">Conversions</h3>
            <CheckCircle className="w-5 h-5 text-green-500" />
          </div>
          <p className="text-3xl font-bold text-green-600">
            {new Intl.NumberFormat('en-US').format(analytics.totalConversions)}
          </p>
          <p className="text-sm text-gray-500 mt-1">
            {(analytics.avgConversionRate * 100).toFixed(1)}% conversion
          </p>
        </div>
        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-500">Active Rules</h3>
            <Power className="w-5 h-5 text-green-500" />
          </div>
          <p className="text-3xl font-bold text-gray-900">{analytics.activeRules}</p>
          <p className="text-sm text-gray-500 mt-1">
            of {analytics.totalRules} total
          </p>
        </div>
      </div>

      {/* Top Performing Rules */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-5 h-5 text-purple-600" />
          <h3 className="text-lg font-semibold text-gray-900">Top Performing Rules</h3>
        </div>
        
        {analytics.topPerformingRules.length === 0 ? (
          <p className="text-gray-500 text-center py-8">
            Not enough data yet. Rules need at least 10 impressions to appear here.
          </p>
        ) : (
          <div className="space-y-3">
            {analytics.topPerformingRules.map((item, idx) => (
              <div key={item.rule.id} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-purple-700">#{idx + 1}</span>
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{item.rule.name}</p>
                  <p className="text-sm text-gray-500">{item.rule.category || 'Uncategorized'}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-blue-600">
                    {(item.ctr * 100).toFixed(1)}% CTR
                  </p>
                  <p className="text-sm text-green-600">
                    {(item.conversionRate * 100).toFixed(1)}% conversion
                  </p>
                </div>
                <div className="text-right text-sm text-gray-500">
                  {item.rule.metrics.impressions} impressions
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default RecommendationsAdmin;
