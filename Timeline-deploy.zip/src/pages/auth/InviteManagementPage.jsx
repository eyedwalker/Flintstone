import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  UserPlus, Mail, Clock, CheckCircle, XCircle, RefreshCw, 
  Trash2, Send, Copy, AlertCircle, Loader2, ArrowLeft,
  Shield, Users, MoreVertical
} from 'lucide-react';
import { AuthApiService } from '../../services/authApiService';

const InviteManagementPage = ({ currentUser }) => {
  const navigate = useNavigate();
  const [invites, setInvites] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [activeTab, setActiveTab] = useState('invites');

  // New invite form
  const [newInvite, setNewInvite] = useState({
    email: '',
    role: 'associate',
    expirationDays: 7,
  });
  const [createError, setCreateError] = useState('');
  const [createLoading, setCreateLoading] = useState(false);
  const [createdInvite, setCreatedInvite] = useState(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [invitesResult, usersResult] = await Promise.all([
        AuthApiService.listInvites(),
        AuthApiService.listUsers()
      ]);
      setInvites(invitesResult.invites || []);
      setUsers(usersResult.users || []);
    } catch (error) {
      console.error('Failed to load data:', error);
    }
    setLoading(false);
  };

  const handleCreateInvite = async (e) => {
    e.preventDefault();
    setCreateError('');
    setCreateLoading(true);

    try {
      const result = await AuthApiService.createInvite(
        newInvite.email,
        newInvite.role,
        newInvite.expirationDays
      );

      if (!result.success) {
        setCreateError(result.error || 'Failed to create invite');
        setCreateLoading(false);
        return;
      }

      setCreatedInvite(result.invite);
      loadData();
    } catch (err) {
      setCreateError('An unexpected error occurred');
    } finally {
      setCreateLoading(false);
    }
  };

  const handleCopyInviteUrl = (invite) => {
    const productionUrl = import.meta.env.VITE_APP_URL;
    const baseUrl = productionUrl || window.location.origin;
    const url = invite.inviteUrl || `${baseUrl}/register?invite=${invite.token}`;
    navigator.clipboard.writeText(url);
    setCopied(invite.id);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleResendInvite = async (invite) => {
    // Resend not yet implemented in API - would need new endpoint
    alert('Invite resend will be available soon. Please copy and share the invite URL.');
    handleCopyInviteUrl(invite);
  };

  const handleRevokeInvite = async (invite) => {
    if (window.confirm(`Are you sure you want to revoke the invite for ${invite.email}?`)) {
      await AuthApiService.revokeInvite(invite.token);
      loadData();
    }
  };

  const handleDeleteInvite = async (invite) => {
    if (window.confirm(`Are you sure you want to delete this invite?`)) {
      // Delete is same as revoke in the API
      await AuthApiService.revokeInvite(invite.token);
      loadData();
    }
  };

  const handleDeleteUser = async (user) => {
    if (user.id === currentUser?.id) {
      alert("You cannot delete your own account.");
      return;
    }
    if (window.confirm(`Are you sure you want to delete the user ${user.email}? This action cannot be undone.`)) {
      await AuthApiService.deleteUser(user.email);
      loadData();
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'pending':
        return <span className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded-full">Pending</span>;
      case 'used':
        return <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">Used</span>;
      case 'expired':
        return <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">Expired</span>;
      case 'revoked':
        return <span className="px-2 py-1 bg-red-100 text-red-700 text-xs rounded-full">Revoked</span>;
      default:
        return null;
    }
  };

  const getRoleBadge = (role) => {
    switch (role) {
      case 'admin':
        return <span className="px-2 py-1 bg-purple-100 text-purple-700 text-xs rounded-full">Admin</span>;
      case 'manager':
        return <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">Manager</span>;
      case 'associate':
        return <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">Associate</span>;
      default:
        return null;
    }
  };

  const formatDate = (dateStr) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const resetCreateForm = () => {
    setNewInvite({ email: '', role: 'associate', expirationDays: 7 });
    setCreateError('');
    setCreatedInvite(null);
    setShowCreateModal(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate(-1)}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">User Management</h1>
                <p className="text-sm text-gray-600">Manage invitations and users</p>
              </div>
            </div>
            <button
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <UserPlus className="w-4 h-4" />
              Invite User
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="max-w-7xl mx-auto px-4 mt-6">
        <div className="flex gap-1 bg-gray-100 p-1 rounded-lg w-fit">
          <button
            onClick={() => setActiveTab('invites')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition ${
              activeTab === 'invites' 
                ? 'bg-white shadow text-gray-900' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Mail className="w-4 h-4 inline mr-2" />
            Invitations ({invites.length})
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition ${
              activeTab === 'users' 
                ? 'bg-white shadow text-gray-900' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Users className="w-4 h-4 inline mr-2" />
            Users ({users.length})
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : activeTab === 'invites' ? (
          /* Invites Table */
          <div className="bg-white rounded-xl shadow overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Email</th>
                  <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Role</th>
                  <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Invited By</th>
                  <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Expires</th>
                  <th className="text-right px-6 py-3 text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {invites.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                      <Mail className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      No invitations yet. Click "Invite User" to send one.
                    </td>
                  </tr>
                ) : (
                  invites.map((invite) => (
                    <tr key={invite.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="font-medium text-gray-900">{invite.email}</div>
                      </td>
                      <td className="px-6 py-4">{getRoleBadge(invite.role)}</td>
                      <td className="px-6 py-4">{getStatusBadge(invite.status)}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{invite.invitedByName}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {invite.status === 'pending' ? formatDate(invite.expiresAt) : '—'}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {invite.status === 'pending' && (
                            <>
                              <button
                                onClick={() => handleCopyInviteUrl(invite)}
                                className="p-1.5 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded"
                                title="Copy invite URL"
                              >
                                {copied === invite.id ? <CheckCircle className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                              </button>
                              <button
                                onClick={() => handleResendInvite(invite)}
                                className="p-1.5 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded"
                                title="Resend invite"
                              >
                                <RefreshCw className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleRevokeInvite(invite)}
                                className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 rounded"
                                title="Revoke invite"
                              >
                                <XCircle className="w-4 h-4" />
                              </button>
                            </>
                          )}
                          {(invite.status === 'expired' || invite.status === 'revoked' || invite.status === 'used') && (
                            <button
                              onClick={() => handleDeleteInvite(invite)}
                              className="p-1.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded"
                              title="Delete invite"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        ) : (
          /* Users Table */
          <div className="bg-white rounded-xl shadow overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">User</th>
                  <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Role</th>
                  <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">MFA</th>
                  <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Last Login</th>
                  <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Created</th>
                  <th className="text-right px-6 py-3 text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {users.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                      <Users className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      No users yet.
                    </td>
                  </tr>
                ) : (
                  users.map((user) => (
                    <tr key={user.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="font-medium text-gray-900">{user.firstName} {user.lastName}</div>
                        <div className="text-sm text-gray-500">{user.email}</div>
                      </td>
                      <td className="px-6 py-4">{getRoleBadge(user.role)}</td>
                      <td className="px-6 py-4">
                        {user.mfaEnabled ? (
                          <span className="flex items-center gap-1 text-green-600 text-sm">
                            <Shield className="w-4 h-4" /> Enabled
                          </span>
                        ) : (
                          <span className="text-gray-400 text-sm">Disabled</span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {user.lastLogin ? formatDate(user.lastLogin) : 'Never'}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {formatDate(user.createdAt)}
                      </td>
                      <td className="px-6 py-4 text-right">
                        {user.id !== currentUser?.id && (
                          <button
                            onClick={() => handleDeleteUser(user)}
                            className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 rounded"
                            title="Delete user"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                        {user.id === currentUser?.id && (
                          <span className="text-xs text-gray-400">You</span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create Invite Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md">
            {createdInvite ? (
              /* Success View */
              <div className="p-6">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  </div>
                  <h2 className="text-xl font-bold text-gray-900">Invitation Sent!</h2>
                  <p className="text-gray-600 mt-2">
                    An invitation has been created for <strong>{createdInvite.email}</strong>
                  </p>
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Invite Link</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={createdInvite.inviteUrl || `${import.meta.env.VITE_APP_URL || window.location.origin}/register?invite=${createdInvite.token}`}
                      readOnly
                      className="flex-1 px-3 py-2 border rounded-lg bg-gray-50 text-sm"
                    />
                    <button
                      onClick={() => handleCopyInviteUrl(createdInvite)}
                      className="px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg"
                    >
                      {copied === createdInvite.id ? <CheckCircle className="w-5 h-5 text-green-500" /> : <Copy className="w-5 h-5" />}
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Share this link with the user. It expires on {formatDate(createdInvite.expiresAt)}.
                  </p>
                </div>

                <button
                  onClick={resetCreateForm}
                  className="w-full py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700"
                >
                  Done
                </button>
              </div>
            ) : (
              /* Form View */
              <form onSubmit={handleCreateInvite}>
                <div className="p-6 border-b">
                  <h2 className="text-xl font-bold text-gray-900">Invite New User</h2>
                  <p className="text-gray-600 text-sm mt-1">Send an invitation to join VisionCare Timeline</p>
                </div>

                <div className="p-6 space-y-4">
                  {createError && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
                      <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
                      <p className="text-red-700 text-sm">{createError}</p>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                    <input
                      type="email"
                      value={newInvite.email}
                      onChange={(e) => setNewInvite(prev => ({ ...prev, email: e.target.value }))}
                      placeholder="user@example.com"
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Role</label>
                    <select
                      value={newInvite.role}
                      onChange={(e) => setNewInvite(prev => ({ ...prev, role: e.target.value }))}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="associate">Associate</option>
                      <option value="manager">Manager</option>
                      <option value="admin">Admin</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Expires In</label>
                    <select
                      value={newInvite.expirationDays}
                      onChange={(e) => setNewInvite(prev => ({ ...prev, expirationDays: parseInt(e.target.value) }))}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    >
                      <option value={1}>1 day</option>
                      <option value={3}>3 days</option>
                      <option value={7}>7 days</option>
                      <option value={14}>14 days</option>
                      <option value={30}>30 days</option>
                    </select>
                  </div>
                </div>

                <div className="p-6 border-t bg-gray-50 flex gap-3">
                  <button
                    type="button"
                    onClick={resetCreateForm}
                    className="flex-1 py-2.5 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-100"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={createLoading}
                    className="flex-1 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {createLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        Send Invitation
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default InviteManagementPage;
