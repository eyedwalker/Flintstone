import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Smartphone, Copy, CheckCircle, AlertCircle, Loader2, ArrowLeft } from 'lucide-react';
import { MFAService } from '../../services/mfaService';
import { SecureAuthService } from '../../services/secureAuthService';

const MFASetupPage = ({ user, onMfaEnabled }) => {
  const navigate = useNavigate();
  const [step, setStep] = useState('intro'); // intro, setup, verify, complete
  const [secret, setSecret] = useState('');
  const [qrUrl, setQrUrl] = useState('');
  const [otpauthUrl, setOtpauthUrl] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [backupCodes, setBackupCodes] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  // Generate MFA secret when entering setup
  useEffect(() => {
    if (step === 'setup' && !secret) {
      const newSecret = MFAService.generateSecret();
      setSecret(newSecret);
      setQrUrl(MFAService.generateQRCodeURL(newSecret, user?.email || 'user@example.com'));
      setOtpauthUrl(MFAService.generateOtpauthURL(newSecret, user?.email || 'user@example.com'));
    }
  }, [step, secret, user]);

  const handleCopySecret = () => {
    navigator.clipboard.writeText(secret);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleVerify = async () => {
    setError('');
    setLoading(true);

    try {
      // Verify the code
      const isValid = MFAService.verifyTOTP(secret, verificationCode);
      
      if (!isValid) {
        setError('Invalid verification code. Please try again.');
        setLoading(false);
        return;
      }

      // Enable MFA for user
      const result = SecureAuthService.enableMfa(user.id, secret, verificationCode);
      
      if (!result.success) {
        setError(result.error || 'Failed to enable MFA');
        setLoading(false);
        return;
      }

      // Generate backup codes
      const codes = MFAService.generateBackupCodes(10);
      setBackupCodes(codes);

      // Store backup codes (in production, these should be hashed)
      localStorage.setItem(`mfa_backup_${user.id}`, JSON.stringify(codes));

      setStep('complete');
      
      if (onMfaEnabled) {
        onMfaEnabled();
      }
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleCopyBackupCodes = () => {
    navigator.clipboard.writeText(backupCodes.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Intro Screen
  if (step === 'intro') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="w-full max-w-lg">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-10 h-10 text-blue-600" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">Enable Two-Factor Authentication</h1>
              <p className="text-gray-600 mt-2">
                Add an extra layer of security to your account
              </p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-600 font-bold">1</span>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">Download an Authenticator App</h3>
                  <p className="text-sm text-gray-600">
                    Install Google Authenticator, Microsoft Authenticator, Authy, or any TOTP-compatible app
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-600 font-bold">2</span>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">Scan QR Code</h3>
                  <p className="text-sm text-gray-600">
                    Use your authenticator app to scan the QR code we'll show you
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-600 font-bold">3</span>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">Enter Verification Code</h3>
                  <p className="text-sm text-gray-600">
                    Enter the 6-digit code from your app to verify setup
                  </p>
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <button
                onClick={() => navigate(-1)}
                className="flex-1 py-3 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => setStep('setup')}
                className="flex-1 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700"
              >
                Get Started
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Setup Screen
  if (step === 'setup') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="w-full max-w-lg">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <button
              onClick={() => setStep('intro')}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-6"
            >
              <ArrowLeft className="w-4 h-4" /> Back
            </button>

            <div className="text-center mb-6">
              <h1 className="text-2xl font-bold text-gray-900">Scan QR Code</h1>
              <p className="text-gray-600 mt-2">
                Open your authenticator app and scan this QR code
              </p>
            </div>

            {/* QR Code */}
            <div className="flex justify-center mb-6">
              <div className="p-4 bg-white border-2 border-gray-200 rounded-xl">
                <img 
                  src={qrUrl} 
                  alt="MFA QR Code" 
                  className="w-48 h-48"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.nextSibling.style.display = 'flex';
                  }}
                />
                <div className="w-48 h-48 hidden items-center justify-center bg-gray-100 rounded text-center p-4">
                  <div>
                    <Smartphone className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-xs text-gray-500">QR code unavailable. Use manual entry below.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Manual Entry */}
            <div className="mb-6">
              <p className="text-sm text-gray-600 text-center mb-2">
                Can't scan? Enter this code manually:
              </p>
              <div className="flex items-center gap-2 p-3 bg-gray-100 rounded-lg">
                <code className="flex-1 text-sm font-mono text-center break-all">
                  {MFAService.formatSecretForDisplay(secret)}
                </code>
                <button
                  onClick={handleCopySecret}
                  className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-200 rounded"
                  title="Copy secret"
                >
                  {copied ? <CheckCircle className="w-5 h-5 text-green-500" /> : <Copy className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button
              onClick={() => setStep('verify')}
              className="w-full py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700"
            >
              I've Added the Code
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Verify Screen
  if (step === 'verify') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <button
              onClick={() => setStep('setup')}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-6"
            >
              <ArrowLeft className="w-4 h-4" /> Back
            </button>

            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-blue-600" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">Verify Setup</h1>
              <p className="text-gray-600 mt-2">
                Enter the 6-digit code from your authenticator app
              </p>
            </div>

            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                <p className="text-red-700 text-sm">{error}</p>
              </div>
            )}

            <div className="mb-6">
              <input
                type="text"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="000000"
                className="w-full px-4 py-4 text-center text-3xl tracking-[0.5em] font-mono border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                autoFocus
              />
            </div>

            <button
              onClick={handleVerify}
              disabled={loading || verificationCode.length !== 6}
              className="w-full py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Verifying...
                </>
              ) : (
                'Verify & Enable MFA'
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Complete Screen
  if (step === 'complete') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="w-full max-w-lg">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">MFA Enabled!</h1>
              <p className="text-gray-600 mt-2">
                Your account is now protected with two-factor authentication
              </p>
            </div>

            {/* Backup Codes */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-semibold text-gray-900">Backup Codes</h2>
                <button
                  onClick={handleCopyBackupCodes}
                  className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-700"
                >
                  {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copied!' : 'Copy all'}
                </button>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-3">
                  Save these codes in a secure location. Each code can only be used once.
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {backupCodes.map((code, index) => (
                    <code key={index} className="text-sm font-mono bg-white px-3 py-2 rounded border text-center">
                      {code}
                    </code>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg mb-6">
              <p className="text-sm text-amber-800">
                <strong>Important:</strong> Store these backup codes securely. If you lose access to your 
                authenticator app, you can use these codes to sign in.
              </p>
            </div>

            <button
              onClick={() => navigate('/settings')}
              className="w-full py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
};

export default MFASetupPage;
