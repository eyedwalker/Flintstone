/**
 * Analytics Dashboard Page
 * AI-enabled reporting dashboard for patient journey metrics
 *
 * Tabs: Overview | Performance | AI Insights | Export
 * Data source: Supabase audit_logs via /api/analytics/* endpoints
 */

import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  BarChart3,
  TrendingUp,
  Clock,
  Users,
  AlertTriangle,
  CheckCircle,
  Activity,
  Brain,
  Download,
  RefreshCw,
  Send,
  Loader2,
  ChevronDown,
  Calendar,
  Building2,
  Sparkles,
  Info,
  AlertCircle,
  XCircle,
} from 'lucide-react';
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend,
} from 'recharts';

const CHART_COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'];

const DATE_RANGES = [
  { label: 'Today', value: 'today' },
  { label: '7 Days', value: '7d' },
  { label: '30 Days', value: '30d' },
  { label: '90 Days', value: '90d' },
];

function getDateRange(range) {
  const end = new Date();
  const start = new Date();
  switch (range) {
    case 'today': start.setHours(0, 0, 0, 0); break;
    case '7d': start.setDate(start.getDate() - 7); break;
    case '30d': start.setDate(start.getDate() - 30); break;
    case '90d': start.setDate(start.getDate() - 90); break;
    default: start.setDate(start.getDate() - 7);
  }
  return { startDate: start.toISOString(), endDate: end.toISOString() };
}

// --- KPI Card ---
function KpiCard({ title, value, subtitle, icon: Icon, color = 'blue', trend }) {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600 border-blue-200',
    green: 'bg-green-50 text-green-600 border-green-200',
    amber: 'bg-amber-50 text-amber-600 border-amber-200',
    red: 'bg-red-50 text-red-600 border-red-200',
    purple: 'bg-purple-50 text-purple-600 border-purple-200',
  };

  return (
    <div className={`rounded-lg border p-4 ${colorClasses[color] || colorClasses.blue}`}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium opacity-80">{title}</span>
        <Icon size={18} />
      </div>
      <div className="text-2xl font-bold">{value}</div>
      {subtitle && <div className="text-xs mt-1 opacity-70">{subtitle}</div>}
      {trend && (
        <div className={`text-xs mt-1 flex items-center gap-1 ${trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
          <TrendingUp size={12} className={trend < 0 ? 'rotate-180' : ''} />
          {Math.abs(trend)}% vs prior period
        </div>
      )}
    </div>
  );
}

// --- Insight Card ---
function InsightCard({ insight }) {
  const severityConfig = {
    info: { icon: Info, bg: 'bg-blue-50', border: 'border-blue-200', text: 'text-blue-700', badge: 'bg-blue-100 text-blue-700' },
    warning: { icon: AlertCircle, bg: 'bg-amber-50', border: 'border-amber-200', text: 'text-amber-700', badge: 'bg-amber-100 text-amber-700' },
    critical: { icon: XCircle, bg: 'bg-red-50', border: 'border-red-200', text: 'text-red-700', badge: 'bg-red-100 text-red-700' },
  };
  const config = severityConfig[insight.severity] || severityConfig.info;
  const SeverityIcon = config.icon;

  return (
    <div className={`rounded-lg border ${config.border} ${config.bg} p-4`}>
      <div className="flex items-start gap-3">
        <SeverityIcon size={18} className={config.text} />
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className={`font-semibold ${config.text}`}>{insight.title}</span>
            <span className={`text-xs px-2 py-0.5 rounded-full ${config.badge}`}>{insight.severity}</span>
            {insight.category && (
              <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">{insight.category}</span>
            )}
          </div>
          <p className="text-sm text-gray-700 mb-2">{insight.description}</p>
          {insight.recommendation && (
            <div className="text-sm bg-white/60 rounded p-2 border border-gray-200">
              <span className="font-medium text-gray-600">Recommendation: </span>
              {insight.recommendation}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// --- Main Dashboard ---
export default function AnalyticsDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [dateRange, setDateRange] = useState('7d');
  const [loading, setLoading] = useState(false);
  const [metrics, setMetrics] = useState(null);
  const [error, setError] = useState(null);

  // AI Insights state
  const [insights, setInsights] = useState(null);
  const [insightsLoading, setInsightsLoading] = useState(false);
  const [aiQuestion, setAiQuestion] = useState('');
  const [aiAnswer, setAiAnswer] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);

  // Export state
  const [exportLoading, setExportLoading] = useState(false);

  const officeId = localStorage.getItem('selected_office_id') || '';
  const companyId = localStorage.getItem('selected_company_id') || '';

  const fetchMetrics = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { startDate, endDate } = getDateRange(dateRange);
      const params = new URLSearchParams({ startDate, endDate });
      if (officeId) params.append('officeId', officeId);
      if (companyId) params.append('companyId', companyId);

      const res = await fetch(`/api/analytics/metrics?${params}`);
      const data = await res.json();
      if (data.success) {
        setMetrics(data.metrics);
      } else {
        setError(data.error || 'Failed to load metrics');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [dateRange, officeId, companyId]);

  const fetchInsights = useCallback(async (metricsData) => {
    if (!metricsData) return;
    setInsightsLoading(true);
    try {
      const res = await fetch('/api/analytics/insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ metrics: metricsData }),
      });
      const data = await res.json();
      if (data.success) {
        setInsights(data.analysis);
      }
    } catch (err) {
      console.warn('[Analytics] Insights fetch failed:', err.message);
    } finally {
      setInsightsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMetrics();
  }, [fetchMetrics]);

  // Auto-fetch insights when metrics load and AI tab is active
  useEffect(() => {
    if (metrics && activeTab === 'insights' && !insights && !insightsLoading) {
      fetchInsights(metrics);
    }
  }, [metrics, activeTab, insights, insightsLoading, fetchInsights]);

  const handleAskQuestion = async () => {
    if (!aiQuestion.trim() || !metrics) return;
    setAiLoading(true);
    setAiAnswer(null);
    try {
      const res = await fetch('/api/analytics/insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ metrics, question: aiQuestion }),
      });
      const data = await res.json();
      if (data.success) {
        setAiAnswer(data.analysis);
      }
    } catch (err) {
      setAiAnswer({ summary: `Error: ${err.message}`, insights: [] });
    } finally {
      setAiLoading(false);
    }
  };

  const handleExportCSV = async () => {
    setExportLoading(true);
    try {
      const { startDate, endDate } = getDateRange(dateRange);
      const params = new URLSearchParams({ startDate, endDate, limit: '10000', offset: '0' });
      if (officeId) params.append('officeId', officeId);
      if (companyId) params.append('companyId', companyId);

      const res = await fetch(`/api/analytics/logs?${params}`);
      const data = await res.json();
      if (!data.success || !data.logs.length) {
        alert('No data to export for the selected date range.');
        return;
      }

      // Build CSV
      const headers = [
        'Event ID', 'Journey ID', 'Patient Name', 'Step Title', 'Event Type',
        'Event Timestamp', 'Duration (min)', 'Wait Time (min)', 'Room',
        'Performed By', 'Phase', 'Outcome', 'Is Overtime', 'Provider', 'Office',
      ];
      const rows = data.logs.map(log => [
        log.id, log.journey_id, log.patient_name, log.step_title, log.event_type,
        log.event_timestamp, log.step_duration || '', log.wait_time || '', log.room_name || '',
        log.performed_by_name || '', log.journey_phase, log.outcome || '',
        log.is_overtime ? 'Yes' : 'No', log.provider_name || '', log.office_name || '',
      ]);

      const csv = [headers, ...rows].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `analytics-export-${dateRange}-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      alert(`Export failed: ${err.message}`);
    } finally {
      setExportLoading(false);
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'performance', label: 'Performance', icon: Activity },
    { id: 'insights', label: 'AI Insights', icon: Brain },
    { id: 'export', label: 'Export', icon: Download },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate('/prc')} className="text-gray-500 hover:text-gray-700">
              <ArrowLeft size={20} />
            </button>
            <div>
              <h1 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                <BarChart3 size={22} className="text-blue-600" />
                Analytics Dashboard
              </h1>
              <p className="text-sm text-gray-500">Patient journey metrics & AI insights</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Date Range Picker */}
            <div className="flex items-center gap-1 bg-gray-100 rounded-lg p-1">
              {DATE_RANGES.map(r => (
                <button
                  key={r.value}
                  onClick={() => setDateRange(r.value)}
                  className={`px-3 py-1.5 text-sm rounded-md transition-colors ${
                    dateRange === r.value
                      ? 'bg-white text-blue-600 shadow-sm font-medium'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
            <button
              onClick={fetchMetrics}
              disabled={loading}
              className="flex items-center gap-1 px-3 py-1.5 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
              Refresh
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mt-4">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 text-sm rounded-lg transition-colors ${
                activeTab === tab.id
                  ? 'bg-blue-50 text-blue-700 font-medium'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <tab.icon size={16} />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6 max-w-7xl mx-auto">
        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
            {error}
          </div>
        )}

        {loading && !metrics && (
          <div className="flex items-center justify-center py-20">
            <Loader2 size={32} className="animate-spin text-blue-500" />
            <span className="ml-3 text-gray-500">Loading metrics...</span>
          </div>
        )}

        {/* Overview Tab */}
        {activeTab === 'overview' && metrics && (
          <div className="space-y-6">
            {/* KPI Row */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <KpiCard
                title="Total Journeys"
                value={metrics.totalJourneys}
                subtitle={`${metrics.completedJourneys} completed`}
                icon={Users}
                color="blue"
              />
              <KpiCard
                title="Avg Wait Time"
                value={`${metrics.averageWaitTime?.toFixed(1) || 0} min`}
                subtitle="Time to first step"
                icon={Clock}
                color={metrics.averageWaitTime > 15 ? 'red' : 'green'}
              />
              <KpiCard
                title="Avg Step Duration"
                value={`${metrics.averageStepDuration?.toFixed(1) || 0} min`}
                subtitle="Per completed step"
                icon={Activity}
                color="purple"
              />
              <KpiCard
                title="Overtime Rate"
                value={`${metrics.overtimeRate?.toFixed(1) || 0}%`}
                subtitle={`${metrics.overtimeSteps} steps over time`}
                icon={AlertTriangle}
                color={metrics.overtimeRate > 10 ? 'red' : metrics.overtimeRate > 5 ? 'amber' : 'green'}
              />
              <KpiCard
                title="Total Events"
                value={metrics.totalEvents}
                subtitle={`${metrics.totalSteps} steps completed`}
                icon={CheckCircle}
                color="green"
              />
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Daily Volume Chart */}
              <div className="bg-white rounded-lg border p-4">
                <h3 className="text-sm font-semibold text-gray-700 mb-4">Daily Journey Volume</h3>
                {metrics.dailyData?.length > 0 ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={metrics.dailyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={d => d.slice(5)} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Line type="monotone" dataKey="journeys" stroke="#3B82F6" strokeWidth={2} dot={{ r: 3 }} name="Journeys" />
                      <Line type="monotone" dataKey="events" stroke="#10B981" strokeWidth={1.5} dot={false} name="Events" />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-[250px] flex items-center justify-center text-gray-400 text-sm">
                    No data for selected period
                  </div>
                )}
              </div>

              {/* Step Type Duration Chart */}
              <div className="bg-white rounded-lg border p-4">
                <h3 className="text-sm font-semibold text-gray-700 mb-4">Avg Duration by Step Type</h3>
                {metrics.stepTypeMetrics?.length > 0 ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={metrics.stepTypeMetrics} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis type="number" tick={{ fontSize: 11 }} unit=" min" />
                      <YAxis
                        type="category"
                        dataKey="stepTitle"
                        tick={{ fontSize: 11 }}
                        width={120}
                        tickFormatter={v => v.length > 16 ? v.slice(0, 16) + '...' : v}
                      />
                      <Tooltip />
                      <Bar dataKey="averageDuration" fill="#3B82F6" radius={[0, 4, 4, 0]} name="Avg Duration (min)" />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-[250px] flex items-center justify-center text-gray-400 text-sm">
                    No step data available
                  </div>
                )}
              </div>
            </div>

            {/* Hourly Distribution */}
            <div className="bg-white rounded-lg border p-4">
              <h3 className="text-sm font-semibold text-gray-700 mb-4">Hourly Activity Distribution</h3>
              {metrics.hourlyData?.some(d => d.count > 0) ? (
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={metrics.hourlyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="hour" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#8B5CF6" radius={[4, 4, 0, 0]} name="Events" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[200px] flex items-center justify-center text-gray-400 text-sm">
                  No hourly data available
                </div>
              )}
            </div>
          </div>
        )}

        {/* Performance Tab */}
        {activeTab === 'performance' && metrics && (
          <div className="space-y-6">
            {/* Phase Comparison */}
            <div className="bg-white rounded-lg border p-4">
              <h3 className="text-sm font-semibold text-gray-700 mb-4">Phase Performance Comparison</h3>
              {metrics.phaseMetrics ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={[
                      {
                        phase: 'Pre-Visit',
                        avgDuration: metrics.phaseMetrics['pre-visit']?.averageDuration?.toFixed(1) || 0,
                        avgWait: metrics.phaseMetrics['pre-visit']?.averageWaitTime?.toFixed(1) || 0,
                        overtimeRate: metrics.phaseMetrics['pre-visit']?.overtimeRate?.toFixed(1) || 0,
                      },
                      {
                        phase: 'In-Office',
                        avgDuration: metrics.phaseMetrics['in-office']?.averageDuration?.toFixed(1) || 0,
                        avgWait: metrics.phaseMetrics['in-office']?.averageWaitTime?.toFixed(1) || 0,
                        overtimeRate: metrics.phaseMetrics['in-office']?.overtimeRate?.toFixed(1) || 0,
                      },
                      {
                        phase: 'Post-Visit',
                        avgDuration: metrics.phaseMetrics['post-visit']?.averageDuration?.toFixed(1) || 0,
                        avgWait: metrics.phaseMetrics['post-visit']?.averageWaitTime?.toFixed(1) || 0,
                        overtimeRate: metrics.phaseMetrics['post-visit']?.overtimeRate?.toFixed(1) || 0,
                      },
                    ]}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="phase" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="avgDuration" fill="#3B82F6" name="Avg Duration (min)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="avgWait" fill="#F59E0B" name="Avg Wait (min)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-gray-400 text-sm">
                  No phase data available
                </div>
              )}
            </div>

            {/* Step Type Breakdown Table */}
            <div className="bg-white rounded-lg border">
              <div className="px-4 py-3 border-b">
                <h3 className="text-sm font-semibold text-gray-700">Step Type Breakdown</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left px-4 py-2 font-medium text-gray-600">Step</th>
                      <th className="text-right px-4 py-2 font-medium text-gray-600">Count</th>
                      <th className="text-right px-4 py-2 font-medium text-gray-600">Avg Duration</th>
                      <th className="text-right px-4 py-2 font-medium text-gray-600">Avg Wait</th>
                      <th className="text-right px-4 py-2 font-medium text-gray-600">Overtime %</th>
                    </tr>
                  </thead>
                  <tbody>
                    {metrics.stepTypeMetrics?.length > 0 ? (
                      metrics.stepTypeMetrics.map((step, i) => (
                        <tr key={i} className="border-t hover:bg-gray-50">
                          <td className="px-4 py-2 font-medium">{step.stepTitle}</td>
                          <td className="px-4 py-2 text-right">{step.count}</td>
                          <td className="px-4 py-2 text-right">{step.averageDuration?.toFixed(1)} min</td>
                          <td className="px-4 py-2 text-right">{step.averageWaitTime?.toFixed(1)} min</td>
                          <td className="px-4 py-2 text-right">
                            <span className={`px-2 py-0.5 rounded-full text-xs ${
                              step.overtimeRate > 10 ? 'bg-red-100 text-red-700' :
                              step.overtimeRate > 5 ? 'bg-amber-100 text-amber-700' :
                              'bg-green-100 text-green-700'
                            }`}>
                              {step.overtimeRate?.toFixed(1)}%
                            </span>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="px-4 py-8 text-center text-gray-400">No step data available</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Provider Comparison */}
            {metrics.providerMetrics?.length > 0 && (
              <div className="bg-white rounded-lg border p-4">
                <h3 className="text-sm font-semibold text-gray-700 mb-4">Provider Comparison</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={metrics.providerMetrics} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis type="number" tick={{ fontSize: 11 }} unit=" min" />
                    <YAxis type="category" dataKey="providerName" tick={{ fontSize: 11 }} width={120} />
                    <Tooltip />
                    <Bar dataKey="averageStepDuration" fill="#10B981" radius={[0, 4, 4, 0]} name="Avg Step Duration" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        )}

        {/* AI Insights Tab */}
        {activeTab === 'insights' && (
          <div className="space-y-6">
            {/* Auto-generated insights */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                  <Sparkles size={16} className="text-purple-500" />
                  AI-Generated Insights
                </h3>
                <button
                  onClick={() => { setInsights(null); fetchInsights(metrics); }}
                  disabled={insightsLoading}
                  className="flex items-center gap-1 px-3 py-1.5 text-xs bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 disabled:opacity-50"
                >
                  <RefreshCw size={12} className={insightsLoading ? 'animate-spin' : ''} />
                  Regenerate
                </button>
              </div>

              {insightsLoading && (
                <div className="flex items-center justify-center py-10 bg-white rounded-lg border">
                  <Loader2 size={24} className="animate-spin text-purple-500" />
                  <span className="ml-3 text-gray-500 text-sm">Claude is analyzing your metrics...</span>
                </div>
              )}

              {insights && !insightsLoading && (
                <div className="space-y-3">
                  {/* Summary */}
                  {insights.summary && (
                    <div className="bg-white rounded-lg border p-4">
                      <div className="text-sm font-medium text-gray-600 mb-1">Executive Summary</div>
                      <p className="text-sm text-gray-800">{insights.summary}</p>
                    </div>
                  )}

                  {/* Highlights */}
                  {insights.highlights && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {insights.highlights.bestPerforming && (
                        <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                          <div className="text-xs font-medium text-green-700 mb-1">Best Performing</div>
                          <p className="text-sm text-green-800">{insights.highlights.bestPerforming}</p>
                        </div>
                      )}
                      {insights.highlights.needsAttention && (
                        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                          <div className="text-xs font-medium text-amber-700 mb-1">Needs Attention</div>
                          <p className="text-sm text-amber-800">{insights.highlights.needsAttention}</p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Insight Cards */}
                  {insights.insights?.map((insight, i) => (
                    <InsightCard key={i} insight={insight} />
                  ))}
                </div>
              )}

              {!insights && !insightsLoading && (
                <div className="bg-white rounded-lg border p-8 text-center text-gray-400 text-sm">
                  {metrics ? 'Click "Regenerate" to generate AI insights' : 'Load metrics first to get AI insights'}
                </div>
              )}
            </div>

            {/* Ask a Question */}
            <div className="bg-white rounded-lg border p-4">
              <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                <Brain size={16} className="text-blue-500" />
                Ask a Question
              </h3>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={aiQuestion}
                  onChange={e => setAiQuestion(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleAskQuestion()}
                  placeholder="e.g., Why are pre-testing steps running long?"
                  className="flex-1 px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-300"
                  disabled={aiLoading || !metrics}
                />
                <button
                  onClick={handleAskQuestion}
                  disabled={aiLoading || !aiQuestion.trim() || !metrics}
                  className="flex items-center gap-1 px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {aiLoading ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                  Ask
                </button>
              </div>

              <div className="mt-2 flex flex-wrap gap-2">
                {['What are the slowest steps?', 'Which provider is most efficient?', 'When are peak hours?', 'How can we reduce wait times?'].map(q => (
                  <button
                    key={q}
                    onClick={() => { setAiQuestion(q); }}
                    className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded hover:bg-gray-200"
                  >
                    {q}
                  </button>
                ))}
              </div>

              {aiAnswer && (
                <div className="mt-4 space-y-3">
                  {aiAnswer.summary && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                      <p className="text-sm text-blue-800">{aiAnswer.summary}</p>
                    </div>
                  )}
                  {aiAnswer.insights?.map((insight, i) => (
                    <InsightCard key={i} insight={insight} />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Export Tab */}
        {activeTab === 'export' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg border p-6">
              <h3 className="text-lg font-semibold text-gray-700 mb-2">Export Audit Data</h3>
              <p className="text-sm text-gray-500 mb-6">
                Download audit log data as CSV for the selected date range ({dateRange}).
                {metrics && (
                  <span className="ml-1 font-medium">{metrics.totalEvents} events available.</span>
                )}
              </p>

              <div className="flex items-center gap-4">
                <button
                  onClick={handleExportCSV}
                  disabled={exportLoading}
                  className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {exportLoading ? <Loader2 size={18} className="animate-spin" /> : <Download size={18} />}
                  Export as CSV
                </button>
              </div>

              <div className="mt-6 text-xs text-gray-400">
                <p>Exported fields: Event ID, Journey ID, Patient Name, Step Title, Event Type, Timestamp, Duration, Wait Time, Room, Staff, Phase, Outcome, Overtime, Provider, Office</p>
              </div>
            </div>

            {/* Data Summary */}
            {metrics && (
              <div className="bg-white rounded-lg border p-4">
                <h3 className="text-sm font-semibold text-gray-700 mb-3">Data Summary</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <div className="text-gray-500">Date Range</div>
                    <div className="font-medium">{dateRange}</div>
                  </div>
                  <div>
                    <div className="text-gray-500">Total Events</div>
                    <div className="font-medium">{metrics.totalEvents}</div>
                  </div>
                  <div>
                    <div className="text-gray-500">Unique Journeys</div>
                    <div className="font-medium">{metrics.totalJourneys}</div>
                  </div>
                  <div>
                    <div className="text-gray-500">Step Types</div>
                    <div className="font-medium">{metrics.stepTypeMetrics?.length || 0}</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Empty state when no metrics */}
        {!loading && !metrics && !error && (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <BarChart3 size={48} className="mb-4 opacity-50" />
            <p className="text-lg">No analytics data yet</p>
            <p className="text-sm mt-1">Complete patient journeys to start seeing metrics here.</p>
          </div>
        )}
      </div>
    </div>
  );
}
