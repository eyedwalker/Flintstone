import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Shield,
  Settings,
  ArrowLeft,
  Save,
  Plus,
  Trash2,
  Edit2,
  X,
  ChevronDown,
  ChevronUp,
  GripVertical,
  Eye,
  EyeOff,
  CheckCircle,
  XCircle,
  Clock,
  AlertTriangle,
  Activity,
  Globe,
  MousePointer,
  Type,
  Timer,
  Search,
  Camera,
  Lock,
  RefreshCw,
  Building2,
  ExternalLink,
  Play,
  Loader2
} from 'lucide-react';
import { useCompany } from '../contexts/CompanyContext';
import { officeAccessor } from '../lib/accessors/OfficeAccessor';

const API_BASE = '/api/insurance-verification';

const DEFAULT_PAYER_TYPES = [
  { value: 'vsp', label: 'VSP', color: 'bg-blue-100 text-blue-800', url: 'https://www.vsp.com/providers', builtin: true },
  { value: 'eyemed', label: 'EyeMed', color: 'bg-purple-100 text-purple-800', url: 'https://provider.eyemed.com', builtin: true },
  { value: 'davis-vision', label: 'Davis Vision', color: 'bg-green-100 text-green-800', url: 'https://www.davisvision.com/providers', builtin: true },
  { value: 'spectera', label: 'Spectera', color: 'bg-orange-100 text-orange-800', url: 'https://www.spectera.com', builtin: true },
  { value: 'superior-vision', label: 'Superior Vision', color: 'bg-red-100 text-red-800', url: 'https://www.superiorvision.com', builtin: true },
];

const PAYER_COLORS = [
  { value: 'bg-blue-100 text-blue-800', label: 'Blue', dot: 'bg-blue-500' },
  { value: 'bg-purple-100 text-purple-800', label: 'Purple', dot: 'bg-purple-500' },
  { value: 'bg-green-100 text-green-800', label: 'Green', dot: 'bg-green-500' },
  { value: 'bg-orange-100 text-orange-800', label: 'Orange', dot: 'bg-orange-500' },
  { value: 'bg-red-100 text-red-800', label: 'Red', dot: 'bg-red-500' },
  { value: 'bg-teal-100 text-teal-800', label: 'Teal', dot: 'bg-teal-500' },
  { value: 'bg-pink-100 text-pink-800', label: 'Pink', dot: 'bg-pink-500' },
  { value: 'bg-indigo-100 text-indigo-800', label: 'Indigo', dot: 'bg-indigo-500' },
  { value: 'bg-amber-100 text-amber-800', label: 'Amber', dot: 'bg-amber-500' },
  { value: 'bg-cyan-100 text-cyan-800', label: 'Cyan', dot: 'bg-cyan-500' },
];

function getCustomPayers(companyId) {
  try {
    const stored = localStorage.getItem(`insurance-custom-payers-${companyId}`);
    return stored ? JSON.parse(stored) : [];
  } catch { return []; }
}

function saveCustomPayers(companyId, payers) {
  localStorage.setItem(`insurance-custom-payers-${companyId}`, JSON.stringify(payers));
}

function slugify(text) {
  return text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

const MFA_METHODS = [
  { value: 'none', label: 'None' },
  { value: 'email', label: 'Email' },
  { value: 'sms', label: 'SMS' },
  { value: 'totp', label: 'TOTP/Authenticator' },
];

const STEP_TYPES = [
  { value: 'navigate', label: 'Navigate', icon: Globe, description: 'Go to URL' },
  { value: 'fill', label: 'Fill Input', icon: Type, description: 'Fill an input field' },
  { value: 'click', label: 'Click', icon: MousePointer, description: 'Click an element' },
  { value: 'wait', label: 'Wait', icon: Timer, description: 'Wait for element' },
  { value: 'check_mfa', label: 'Check MFA', icon: Lock, description: 'Check for MFA prompt' },
  { value: 'extract', label: 'Extract', icon: Search, description: 'Extract page content' },
  { value: 'screenshot', label: 'Screenshot', icon: Camera, description: 'Take debug screenshot' },
];

const TEMPLATE_VARIABLES = ['{{username}}', '{{password}}', '{{member_id}}', '{{subscriber_dob}}'];

const DEFAULT_FLOW_TEMPLATES = {
  vsp: [
    { type: 'navigate', url: 'https://www.vsp.com/providers' },
    { type: 'fill', selector: '#username', value: '{{username}}' },
    { type: 'fill', selector: '#password', value: '{{password}}' },
    { type: 'click', selector: '#loginButton' },
    { type: 'wait', selector: '.dashboard', timeout: 10000 },
    { type: 'check_mfa', selectors: ['.mfa-form', '#verificationCode', 'text=verification code'] },
    { type: 'click', selector: 'text=Eligibility & Benefits' },
    { type: 'fill', selector: '#memberId', value: '{{member_id}}' },
    { type: 'fill', selector: '#memberDob', value: '{{subscriber_dob}}' },
    { type: 'click', selector: '#searchButton' },
    { type: 'wait', selector: '.benefits-table', timeout: 15000 },
    { type: 'extract', selector: 'body' },
  ],
  eyemed: [
    { type: 'navigate', url: 'https://provider.eyemed.com' },
    { type: 'fill', selector: '#username', value: '{{username}}' },
    { type: 'fill', selector: '#password', value: '{{password}}' },
    { type: 'click', selector: 'button[type=submit]' },
    { type: 'wait', selector: '.provider-dashboard', timeout: 10000 },
    { type: 'check_mfa', selectors: ['.mfa-challenge', '#otpInput'] },
    { type: 'click', selector: 'text=Member Eligibility' },
    { type: 'fill', selector: '#memberId', value: '{{member_id}}' },
    { type: 'fill', selector: '#dob', value: '{{subscriber_dob}}' },
    { type: 'click', selector: '#eligibilitySearch' },
    { type: 'wait', selector: '.eligibility-results', timeout: 15000 },
    { type: 'extract', selector: 'body' },
  ],
  'davis-vision': [
    { type: 'navigate', url: 'https://www.davisvision.com/providers/login' },
    { type: 'fill', selector: '#userName', value: '{{username}}' },
    { type: 'fill', selector: '#userPassword', value: '{{password}}' },
    { type: 'click', selector: '.login-btn' },
    { type: 'wait', selector: '.main-nav', timeout: 10000 },
    { type: 'check_mfa', selectors: ['#mfaCode', '.verification-step'] },
    { type: 'click', selector: 'text=Check Eligibility' },
    { type: 'fill', selector: '#member-id', value: '{{member_id}}' },
    { type: 'fill', selector: '#date-of-birth', value: '{{subscriber_dob}}' },
    { type: 'click', selector: '#search-member' },
    { type: 'wait', selector: '.benefit-details', timeout: 15000 },
    { type: 'extract', selector: '.benefit-details' },
  ],
  spectera: [
    { type: 'navigate', url: 'https://www.spectera.com/providers' },
    { type: 'fill', selector: '#login-user', value: '{{username}}' },
    { type: 'fill', selector: '#login-pass', value: '{{password}}' },
    { type: 'click', selector: '#sign-in' },
    { type: 'wait', selector: '.dashboard-home', timeout: 10000 },
    { type: 'click', selector: 'text=Eligibility' },
    { type: 'fill', selector: '#memberId', value: '{{member_id}}' },
    { type: 'fill', selector: '#memberDob', value: '{{subscriber_dob}}' },
    { type: 'click', selector: '#checkEligibility' },
    { type: 'wait', selector: '.results-container', timeout: 15000 },
    { type: 'extract', selector: '.results-container' },
  ],
  'superior-vision': [
    { type: 'navigate', url: 'https://www.superiorvision.com/provider-portal' },
    { type: 'fill', selector: '#email', value: '{{username}}' },
    { type: 'fill', selector: '#password', value: '{{password}}' },
    { type: 'click', selector: 'button.login' },
    { type: 'wait', selector: '.portal-nav', timeout: 10000 },
    { type: 'click', selector: 'text=Benefits Lookup' },
    { type: 'fill', selector: '#subscriber-id', value: '{{member_id}}' },
    { type: 'fill', selector: '#subscriber-dob', value: '{{subscriber_dob}}' },
    { type: 'click', selector: '#lookup-btn' },
    { type: 'wait', selector: '.benefits-summary', timeout: 15000 },
    { type: 'extract', selector: '.benefits-summary' },
  ],
};


// ============================================================
// Sub-Components
// ============================================================

function FlowStep({ step, index, onUpdate, onDelete }) {
  const stepType = STEP_TYPES.find(s => s.value === step.type);
  const Icon = stepType?.icon || Globe;

  return (
    <div className="flex items-start gap-2 p-3 bg-white border border-gray-200 rounded-lg group">
      <div className="flex items-center gap-2 mt-1 text-gray-400">
        <GripVertical size={14} className="cursor-grab" />
        <span className="text-xs font-mono w-5 text-center">{index + 1}</span>
      </div>

      <div className="flex-1 space-y-2">
        <div className="flex items-center gap-2">
          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium ${
            step.type === 'navigate' ? 'bg-blue-100 text-blue-700' :
            step.type === 'fill' ? 'bg-green-100 text-green-700' :
            step.type === 'click' ? 'bg-yellow-100 text-yellow-700' :
            step.type === 'wait' ? 'bg-purple-100 text-purple-700' :
            step.type === 'check_mfa' ? 'bg-red-100 text-red-700' :
            step.type === 'extract' ? 'bg-cyan-100 text-cyan-700' :
            'bg-gray-100 text-gray-700'
          }`}>
            <Icon size={12} />
            {stepType?.label || step.type}
          </span>

          <select
            value={step.type}
            onChange={e => onUpdate({ ...step, type: e.target.value })}
            className="text-xs border border-gray-300 rounded px-1 py-0.5 bg-white"
          >
            {STEP_TYPES.map(t => (
              <option key={t.value} value={t.value}>{t.label}</option>
            ))}
          </select>
        </div>

        {/* Type-specific fields */}
        {step.type === 'navigate' && (
          <input
            type="text"
            placeholder="URL (e.g. https://portal.example.com)"
            value={step.url || ''}
            onChange={e => onUpdate({ ...step, url: e.target.value })}
            className="w-full text-sm border border-gray-300 rounded px-2 py-1"
          />
        )}

        {step.type === 'fill' && (
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Selector (e.g. #username)"
              value={step.selector || ''}
              onChange={e => onUpdate({ ...step, selector: e.target.value })}
              className="flex-1 text-sm border border-gray-300 rounded px-2 py-1"
            />
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="Value (e.g. {{username}})"
                value={step.value || ''}
                onChange={e => onUpdate({ ...step, value: e.target.value })}
                className="w-full text-sm border border-gray-300 rounded px-2 py-1"
              />
              <div className="flex gap-1 mt-1 flex-wrap">
                {TEMPLATE_VARIABLES.map(v => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => onUpdate({ ...step, value: (step.value || '') + v })}
                    className="text-[10px] px-1.5 py-0.5 bg-blue-50 text-blue-600 rounded hover:bg-blue-100"
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {step.type === 'click' && (
          <input
            type="text"
            placeholder="Selector (e.g. #loginButton, text=Sign In)"
            value={step.selector || ''}
            onChange={e => onUpdate({ ...step, selector: e.target.value })}
            className="w-full text-sm border border-gray-300 rounded px-2 py-1"
          />
        )}

        {step.type === 'wait' && (
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Selector (e.g. .dashboard)"
              value={step.selector || ''}
              onChange={e => onUpdate({ ...step, selector: e.target.value })}
              className="flex-1 text-sm border border-gray-300 rounded px-2 py-1"
            />
            <input
              type="number"
              placeholder="Timeout (ms)"
              value={step.timeout || 10000}
              onChange={e => onUpdate({ ...step, timeout: parseInt(e.target.value) || 10000 })}
              className="w-28 text-sm border border-gray-300 rounded px-2 py-1"
            />
          </div>
        )}

        {step.type === 'check_mfa' && (
          <div className="space-y-1">
            {(step.selectors || ['']).map((sel, si) => (
              <div key={si} className="flex gap-2">
                <input
                  type="text"
                  placeholder="MFA selector"
                  value={sel}
                  onChange={e => {
                    const sels = [...(step.selectors || [''])];
                    sels[si] = e.target.value;
                    onUpdate({ ...step, selectors: sels });
                  }}
                  className="flex-1 text-sm border border-gray-300 rounded px-2 py-1"
                />
                <button
                  type="button"
                  onClick={() => {
                    const sels = (step.selectors || ['']).filter((_, i) => i !== si);
                    onUpdate({ ...step, selectors: sels.length ? sels : [''] });
                  }}
                  className="text-red-400 hover:text-red-600"
                >
                  <X size={14} />
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={() => onUpdate({ ...step, selectors: [...(step.selectors || []), ''] })}
              className="text-xs text-blue-600 hover:text-blue-800"
            >
              + Add selector
            </button>
          </div>
        )}

        {step.type === 'extract' && (
          <input
            type="text"
            placeholder="Selector (e.g. body, .benefits-table)"
            value={step.selector || ''}
            onChange={e => onUpdate({ ...step, selector: e.target.value })}
            className="w-full text-sm border border-gray-300 rounded px-2 py-1"
          />
        )}

        {step.type === 'screenshot' && (
          <input
            type="text"
            placeholder="Screenshot name (e.g. after-login)"
            value={step.name || ''}
            onChange={e => onUpdate({ ...step, name: e.target.value })}
            className="w-full text-sm border border-gray-300 rounded px-2 py-1"
          />
        )}
      </div>

      <button
        onClick={onDelete}
        className="text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity mt-1"
      >
        <Trash2 size={14} />
      </button>
    </div>
  );
}


function PayerCard({ payerType, credentials, flowSteps, onSaveFlow, expanded, onToggle, payerTypes, onDeletePayer }) {
  const payer = payerTypes.find(p => p.value === payerType) || { label: payerType, color: 'bg-gray-100 text-gray-800' };
  const [steps, setSteps] = useState(flowSteps || []);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [scanUrl, setScanUrl] = useState(payer.url || '');
  const [scanError, setScanError] = useState(null);

  useEffect(() => {
    setSteps(flowSteps || []);
    setDirty(false);
  }, [flowSteps]);

  useEffect(() => {
    setScanUrl(payer.url || '');
  }, [payer.url]);

  const officeCount = new Set(credentials.filter(c => c.office_id).map(c => c.office_id)).size;

  const handleUpdateStep = (index, updatedStep) => {
    const newSteps = [...steps];
    newSteps[index] = updatedStep;
    setSteps(newSteps);
    setDirty(true);
  };

  const handleDeleteStep = (index) => {
    setSteps(steps.filter((_, i) => i !== index));
    setDirty(true);
  };

  const handleAddStep = (type = 'click') => {
    const newStep = { type };
    if (type === 'navigate') newStep.url = '';
    if (type === 'fill') { newStep.selector = ''; newStep.value = ''; }
    if (type === 'click' || type === 'wait' || type === 'extract') newStep.selector = '';
    if (type === 'wait') newStep.timeout = 10000;
    if (type === 'check_mfa') newStep.selectors = [''];
    if (type === 'screenshot') newStep.name = '';
    setSteps([...steps, newStep]);
    setDirty(true);
  };

  const handleLoadTemplate = () => {
    const template = DEFAULT_FLOW_TEMPLATES[payerType];
    if (template) {
      setSteps([...template]);
      setDirty(true);
    }
  };

  const handleScanWithAI = async () => {
    if (!scanUrl.trim()) {
      setScanError('Enter a portal URL to scan');
      return;
    }
    setScanning(true);
    setScanError(null);
    try {
      const res = await fetch(`${API_BASE}/scan-portal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: scanUrl.trim(), payerName: payer.label }),
      });
      const data = await res.json();
      if (data.success && data.steps?.length > 0) {
        setSteps(data.steps);
        setDirty(true);
        if (data.fetchError) {
          setScanError(`Note: Could not fetch page HTML (${data.fetchError}). Steps are based on common patterns — please verify.`);
        }
      } else {
        setScanError(data.error || 'AI could not generate steps. Try a different URL or build manually.');
      }
    } catch (err) {
      setScanError('Failed to scan portal: ' + err.message);
    }
    setScanning(false);
  };

  const handleSave = async () => {
    setSaving(true);
    await onSaveFlow(payerType, steps);
    setDirty(false);
    setSaving(false);
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${payer.color}`}>
            {payer.label}
          </span>
          <span className="text-sm text-gray-500">
            {steps.length} steps &middot; {officeCount} office{officeCount !== 1 ? 's' : ''} configured
          </span>
        </div>
        <div className="flex items-center gap-2">
          {!payer.builtin && onDeletePayer && (
            <button
              onClick={(e) => { e.stopPropagation(); onDeletePayer(payerType); }}
              className="text-xs px-2 py-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded"
              title="Delete custom payer"
            >
              <Trash2 size={14} />
            </button>
          )}
          {expanded ? <ChevronUp size={16} className="text-gray-400" /> : <ChevronDown size={16} className="text-gray-400" />}
        </div>
      </button>

      {expanded && (
        <div className="border-t border-gray-100 p-4 bg-gray-50 space-y-3">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-sm font-semibold text-gray-700">Portal Automation Flow</h4>
            <div className="flex items-center gap-2">
              {DEFAULT_FLOW_TEMPLATES[payerType] && (
                <button
                  onClick={handleLoadTemplate}
                  className="text-xs px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-50 text-gray-600"
                >
                  Load Default Template
                </button>
              )}
              {dirty && (
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="text-xs px-3 py-1 bg-[#006FB4] text-white rounded hover:bg-[#005a94] disabled:opacity-50 flex items-center gap-1"
                >
                  {saving ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />}
                  Save Flow
                </button>
              )}
            </div>
          </div>

          {/* AI Portal Scanner */}
          <div className="bg-white border border-gray-200 rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <Search size={14} className="text-purple-600" />
              <span className="text-xs font-semibold text-gray-700">Scan Portal with AI</span>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={scanUrl}
                onChange={e => setScanUrl(e.target.value)}
                placeholder="https://portal.example.com/login"
                className="flex-1 text-sm border border-gray-300 rounded px-2 py-1.5"
              />
              <button
                onClick={handleScanWithAI}
                disabled={scanning}
                className="text-xs px-3 py-1.5 bg-purple-600 text-white rounded hover:bg-purple-700 disabled:opacity-50 flex items-center gap-1 whitespace-nowrap"
              >
                {scanning ? <Loader2 size={12} className="animate-spin" /> : <Search size={12} />}
                {scanning ? 'Scanning...' : 'Scan & Generate'}
              </button>
            </div>
            {scanError && (
              <p className={`text-xs mt-1.5 ${scanError.startsWith('Note:') ? 'text-amber-600' : 'text-red-500'}`}>
                {scanError}
              </p>
            )}
            <p className="text-[10px] text-gray-400 mt-1">
              AI will analyze the portal page and auto-generate login + eligibility flow steps
            </p>
          </div>

          <div className="space-y-2">
            {steps.map((step, idx) => (
              <FlowStep
                key={idx}
                step={step}
                index={idx}
                onUpdate={(updated) => handleUpdateStep(idx, updated)}
                onDelete={() => handleDeleteStep(idx)}
              />
            ))}
          </div>

          {steps.length === 0 && (
            <div className="text-center py-6 text-gray-400 text-sm">
              No flow steps configured. Use "Scan & Generate" above, load a template, or add steps manually.
            </div>
          )}

          <div className="flex items-center gap-2 pt-2">
            <select
              id={`add-step-${payerType}`}
              defaultValue="click"
              className="text-xs border border-gray-300 rounded px-2 py-1 bg-white"
            >
              {STEP_TYPES.map(t => (
                <option key={t.value} value={t.value}>{t.label} — {t.description}</option>
              ))}
            </select>
            <button
              onClick={() => {
                const sel = document.getElementById(`add-step-${payerType}`);
                handleAddStep(sel?.value || 'click');
              }}
              className="text-xs px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-50 text-gray-600 flex items-center gap-1"
            >
              <Plus size={12} />
              Add Step
            </button>
          </div>
        </div>
      )}
    </div>
  );
}


function CredentialCard({ credential, onEdit, onDelete, onToggle, onTest, payerTypes }) {
  const [expanded, setExpanded] = useState(false);
  const payer = payerTypes.find(p => p.value === credential.payer_type) || { label: credential.payer_type, color: 'bg-gray-100 text-gray-800' };

  const statusDot = credential.last_login_status === 'success'
    ? 'bg-green-500'
    : credential.last_login_status === 'failed'
    ? 'bg-red-500'
    : 'bg-gray-400';

  return (
    <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
      <div
        className="flex items-center justify-between px-4 py-3 cursor-pointer hover:bg-gray-50"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-3">
          <span className={`w-2 h-2 rounded-full ${statusDot}`} title={credential.last_login_status || 'Never tested'} />
          <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${payer.color}`}>
            {payer.label}
          </span>
          <span className="text-sm text-gray-700">{credential.portal_username}</span>
          {credential.mfa_method !== 'none' && (
            <span className="px-2 py-0.5 rounded text-[10px] bg-amber-100 text-amber-700 font-medium">
              MFA: {credential.mfa_method}
            </span>
          )}
        </div>
        <div className="flex items-center gap-3">
          {credential.last_login_at && (
            <span className="text-xs text-gray-400">
              Last: {new Date(credential.last_login_at).toLocaleDateString()}
            </span>
          )}
          <button
            onClick={(e) => { e.stopPropagation(); onToggle(credential); }}
            className={`px-2 py-0.5 rounded text-xs font-medium ${
              credential.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
            }`}
          >
            {credential.is_active ? 'Active' : 'Inactive'}
          </button>
          {expanded ? <ChevronUp size={14} className="text-gray-400" /> : <ChevronDown size={14} className="text-gray-400" />}
        </div>
      </div>

      {expanded && (
        <div className="border-t border-gray-100 px-4 py-3 bg-gray-50 space-y-3">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-500 block text-xs">Portal URL</span>
              <span className="text-gray-700">{credential.portal_url || 'Default'}</span>
            </div>
            <div>
              <span className="text-gray-500 block text-xs">MFA Method</span>
              <span className="text-gray-700">{MFA_METHODS.find(m => m.value === credential.mfa_method)?.label || credential.mfa_method}</span>
            </div>
            <div>
              <span className="text-gray-500 block text-xs">Created</span>
              <span className="text-gray-700">{new Date(credential.created_at).toLocaleDateString()}</span>
            </div>
            <div>
              <span className="text-gray-500 block text-xs">Last Login Status</span>
              <span className={`font-medium ${
                credential.last_login_status === 'success' ? 'text-green-600' :
                credential.last_login_status === 'failed' ? 'text-red-600' : 'text-gray-400'
              }`}>
                {credential.last_login_status || 'Never tested'}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2 pt-2 border-t border-gray-200">
            <button
              onClick={() => onTest(credential)}
              className="text-xs px-3 py-1.5 bg-[#006FB4] text-white rounded hover:bg-[#005a94] flex items-center gap-1"
            >
              <Play size={12} />
              Test Connection
            </button>
            <button
              onClick={() => onEdit(credential)}
              className="text-xs px-3 py-1.5 bg-white border border-gray-300 rounded hover:bg-gray-50 text-gray-600 flex items-center gap-1"
            >
              <Edit2 size={12} />
              Edit
            </button>
            <button
              onClick={() => onDelete(credential)}
              className="text-xs px-3 py-1.5 bg-white border border-red-300 rounded hover:bg-red-50 text-red-600 flex items-center gap-1"
            >
              <Trash2 size={12} />
              Delete
            </button>
          </div>
        </div>
      )}
    </div>
  );
}


function CredentialForm({ onSave, onCancel, initialData, payerTypes }) {
  const [form, setForm] = useState(initialData || {
    payerType: '',
    portalUsername: '',
    portalPassword: '',
    mfaMethod: 'none',
    portalUrl: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [saving, setSaving] = useState(false);

  const isEdit = !!initialData?.credentialId;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.payerType || !form.portalUsername || (!isEdit && !form.portalPassword)) return;
    setSaving(true);
    await onSave(form);
    setSaving(false);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white border border-blue-200 rounded-lg p-4 space-y-3">
      <h4 className="text-sm font-semibold text-gray-700">{isEdit ? 'Edit Credential' : 'Add Credential'}</h4>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-xs text-gray-500 mb-1">Payer Type</label>
          <select
            value={form.payerType}
            onChange={e => {
              const pt = e.target.value;
              const payer = payerTypes.find(p => p.value === pt);
              setForm({ ...form, payerType: pt, portalUrl: payer?.url || form.portalUrl });
            }}
            className="w-full text-sm border border-gray-300 rounded px-2 py-1.5"
            disabled={isEdit}
          >
            <option value="">Select payer...</option>
            {payerTypes.map(p => (
              <option key={p.value} value={p.value}>{p.label}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-gray-500 mb-1">MFA Method</label>
          <select
            value={form.mfaMethod}
            onChange={e => setForm({ ...form, mfaMethod: e.target.value })}
            className="w-full text-sm border border-gray-300 rounded px-2 py-1.5"
          >
            {MFA_METHODS.map(m => (
              <option key={m.value} value={m.value}>{m.label}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-gray-500 mb-1">Portal Username</label>
          <input
            type="text"
            value={form.portalUsername}
            onChange={e => setForm({ ...form, portalUsername: e.target.value })}
            className="w-full text-sm border border-gray-300 rounded px-2 py-1.5"
            placeholder="username@office.com"
          />
        </div>
        <div>
          <label className="block text-xs text-gray-500 mb-1">Portal Password {isEdit && '(leave blank to keep)'}</label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              value={form.portalPassword}
              onChange={e => setForm({ ...form, portalPassword: e.target.value })}
              className="w-full text-sm border border-gray-300 rounded px-2 py-1.5 pr-8"
              placeholder={isEdit ? '••••••••' : 'Enter password'}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
            </button>
          </div>
        </div>
        <div className="col-span-2">
          <label className="block text-xs text-gray-500 mb-1">Portal URL (override)</label>
          <input
            type="text"
            value={form.portalUrl}
            onChange={e => setForm({ ...form, portalUrl: e.target.value })}
            className="w-full text-sm border border-gray-300 rounded px-2 py-1.5"
            placeholder="https://portal.example.com (auto-filled from payer)"
          />
        </div>
      </div>

      <div className="flex justify-end gap-2 pt-2">
        <button
          type="button"
          onClick={onCancel}
          className="text-xs px-3 py-1.5 bg-white border border-gray-300 rounded hover:bg-gray-50 text-gray-600"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={saving || !form.payerType || !form.portalUsername}
          className="text-xs px-3 py-1.5 bg-[#006FB4] text-white rounded hover:bg-[#005a94] disabled:opacity-50 flex items-center gap-1"
        >
          {saving ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />}
          {isEdit ? 'Update' : 'Add Credential'}
        </button>
      </div>
    </form>
  );
}


// ============================================================
// Tab Components
// ============================================================

function PayerFlowsTab({ credentials, companyId, onRefresh, payerTypes, onAddPayer, onDeletePayer }) {
  const [expandedPayer, setExpandedPayer] = useState(null);
  const [flowsByPayer, setFlowsByPayer] = useState({});
  const [showAddForm, setShowAddForm] = useState(false);
  const [newPayer, setNewPayer] = useState({ label: '', value: '', url: '', color: PAYER_COLORS[0].value });

  useEffect(() => {
    // Group credentials by payer_type and extract flow_steps from company-wide credentials
    const flows = {};
    for (const payer of payerTypes) {
      const companyCred = credentials.find(c => c.payer_type === payer.value && !c.office_id);
      flows[payer.value] = companyCred?.settings?.flow_steps || [];
    }
    setFlowsByPayer(flows);
  }, [credentials, payerTypes]);

  const handleSaveFlow = async (payerType, steps) => {
    // Find or create a company-wide credential row to store the flow
    const companyCred = credentials.find(c => c.payer_type === payerType && !c.office_id);

    if (companyCred) {
      // Update existing
      await fetch(`${API_BASE}/credentials`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'X-Company-Id': companyId },
        body: JSON.stringify({
          credentialId: companyCred.id,
          settings: { ...(companyCred.settings || {}), flow_steps: steps },
        }),
      });
    } else {
      // Create a company-wide credential with flow steps and placeholder credentials
      await fetch(`${API_BASE}/credentials`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Company-Id': companyId },
        body: JSON.stringify({
          payerType,
          portalUsername: 'flow-config-placeholder',
          portalPassword: 'placeholder',
          portalUrl: payerTypes.find(p => p.value === payerType)?.url || '',
          settings: { flow_steps: steps },
        }),
      });
    }
    onRefresh();
  };

  const handleAddPayer = () => {
    if (!newPayer.label.trim()) return;
    const slug = newPayer.value.trim() || slugify(newPayer.label);
    if (payerTypes.some(p => p.value === slug)) {
      alert('A payer with this identifier already exists.');
      return;
    }
    onAddPayer({
      value: slug,
      label: newPayer.label.trim(),
      color: newPayer.color,
      url: newPayer.url.trim(),
      builtin: false,
    });
    setNewPayer({ label: '', value: '', url: '', color: PAYER_COLORS[0].value });
    setShowAddForm(false);
  };

  const handleDeletePayer = (payerValue) => {
    const payer = payerTypes.find(p => p.value === payerValue);
    if (payer?.builtin) return;
    if (!confirm(`Delete payer "${payer?.label || payerValue}"? This will not remove existing credentials.`)) return;
    onDeletePayer(payerValue);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between mb-2">
        <div>
          <h3 className="text-sm font-semibold text-gray-700">Payer Portal Flows</h3>
          <p className="text-xs text-gray-500">Configure the step-by-step browser automation for each payer portal.</p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="text-xs px-3 py-1.5 bg-[#006FB4] text-white rounded hover:bg-[#005a94] flex items-center gap-1"
        >
          <Plus size={12} />
          Add Payer
        </button>
      </div>

      {showAddForm && (
        <div className="bg-white border border-blue-200 rounded-lg p-4 space-y-3">
          <h4 className="text-sm font-semibold text-gray-700">Add Custom Payer</h4>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-gray-500 mb-1">Payer Name *</label>
              <input
                type="text"
                value={newPayer.label}
                onChange={e => setNewPayer({ ...newPayer, label: e.target.value, value: slugify(e.target.value) })}
                className="w-full text-sm border border-gray-300 rounded px-2 py-1.5"
                placeholder="e.g. Humana Vision"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-500 mb-1">Identifier (slug)</label>
              <input
                type="text"
                value={newPayer.value}
                onChange={e => setNewPayer({ ...newPayer, value: e.target.value })}
                className="w-full text-sm border border-gray-300 rounded px-2 py-1.5 text-gray-500"
                placeholder="auto-generated"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-500 mb-1">Portal URL</label>
              <input
                type="text"
                value={newPayer.url}
                onChange={e => setNewPayer({ ...newPayer, url: e.target.value })}
                className="w-full text-sm border border-gray-300 rounded px-2 py-1.5"
                placeholder="https://portal.example.com"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-500 mb-1">Badge Color</label>
              <div className="flex gap-1.5 flex-wrap">
                {PAYER_COLORS.map(c => (
                  <button
                    key={c.value}
                    type="button"
                    onClick={() => setNewPayer({ ...newPayer, color: c.value })}
                    className={`w-6 h-6 rounded-full ${c.dot} ${newPayer.color === c.value ? 'ring-2 ring-offset-1 ring-blue-500' : 'opacity-60 hover:opacity-100'}`}
                    title={c.label}
                  />
                ))}
              </div>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => { setShowAddForm(false); setNewPayer({ label: '', value: '', url: '', color: PAYER_COLORS[0].value }); }}
              className="text-xs px-3 py-1.5 bg-white border border-gray-300 rounded hover:bg-gray-50 text-gray-600"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleAddPayer}
              disabled={!newPayer.label.trim()}
              className="text-xs px-3 py-1.5 bg-[#006FB4] text-white rounded hover:bg-[#005a94] disabled:opacity-50 flex items-center gap-1"
            >
              <Plus size={12} />
              Add Payer
            </button>
          </div>
        </div>
      )}

      {payerTypes.map(payer => (
        <PayerCard
          key={payer.value}
          payerType={payer.value}
          credentials={credentials.filter(c => c.payer_type === payer.value)}
          flowSteps={flowsByPayer[payer.value] || []}
          onSaveFlow={handleSaveFlow}
          expanded={expandedPayer === payer.value}
          onToggle={() => setExpandedPayer(expandedPayer === payer.value ? null : payer.value)}
          payerTypes={payerTypes}
          onDeletePayer={handleDeletePayer}
        />
      ))}

      {payerTypes.length === 0 && (
        <div className="text-center py-8 text-gray-400">
          <Shield size={32} className="mx-auto mb-2 opacity-50" />
          <p className="text-sm">No payers configured.</p>
          <p className="text-xs mt-1">Click "Add Payer" to get started.</p>
        </div>
      )}
    </div>
  );
}


function OfficeCredentialsTab({ credentials, offices, companyId, onRefresh, payerTypes }) {
  const [selectedOffice, setSelectedOffice] = useState('all');
  const [showForm, setShowForm] = useState(false);
  const [editingCredential, setEditingCredential] = useState(null);

  const filteredCredentials = credentials.filter(c => {
    if (selectedOffice === 'all') return true;
    if (selectedOffice === 'company') return !c.office_id;
    return c.office_id === selectedOffice;
  });

  const handleSave = async (formData) => {
    const isEdit = !!formData.credentialId;
    const method = isEdit ? 'PUT' : 'POST';

    const body = isEdit
      ? {
          credentialId: formData.credentialId,
          portalUsername: formData.portalUsername,
          portalPassword: formData.portalPassword || undefined,
          mfaMethod: formData.mfaMethod,
          portalUrl: formData.portalUrl || undefined,
        }
      : {
          officeId: selectedOffice === 'company' || selectedOffice === 'all' ? undefined : selectedOffice,
          payerType: formData.payerType,
          portalUsername: formData.portalUsername,
          portalPassword: formData.portalPassword,
          mfaMethod: formData.mfaMethod,
          portalUrl: formData.portalUrl || undefined,
        };

    await fetch(`${API_BASE}/credentials`, {
      method,
      headers: { 'Content-Type': 'application/json', 'X-Company-Id': companyId },
      body: JSON.stringify(body),
    });

    setShowForm(false);
    setEditingCredential(null);
    onRefresh();
  };

  const handleDelete = async (credential) => {
    if (!confirm(`Delete ${credential.payer_type} credential for ${credential.portal_username}?`)) return;
    await fetch(`${API_BASE}/credentials?credentialId=${credential.id}`, {
      method: 'DELETE',
      headers: { 'X-Company-Id': companyId },
    });
    onRefresh();
  };

  const handleToggle = async (credential) => {
    await fetch(`${API_BASE}/credentials`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', 'X-Company-Id': companyId },
      body: JSON.stringify({
        credentialId: credential.id,
        isActive: !credential.is_active,
      }),
    });
    onRefresh();
  };

  const handleTest = async (credential) => {
    // Create a test verification job
    alert(`Test connection for ${credential.payer_type} will be implemented with the worker test endpoint.`);
  };

  const handleEdit = (credential) => {
    setEditingCredential({
      credentialId: credential.id,
      payerType: credential.payer_type,
      portalUsername: credential.portal_username,
      portalPassword: '',
      mfaMethod: credential.mfa_method,
      portalUrl: credential.portal_url || '',
    });
    setShowForm(true);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Building2 size={16} className="text-gray-500" />
          <select
            value={selectedOffice}
            onChange={e => setSelectedOffice(e.target.value)}
            className="text-sm border border-gray-300 rounded px-3 py-1.5 bg-white"
          >
            <option value="all">All Offices</option>
            <option value="company">Company-Wide</option>
            {offices.map(office => (
              <option key={office.id} value={office.id}>{office.name}</option>
            ))}
          </select>
        </div>
        <button
          onClick={() => { setEditingCredential(null); setShowForm(true); }}
          className="text-xs px-3 py-1.5 bg-[#006FB4] text-white rounded hover:bg-[#005a94] flex items-center gap-1"
        >
          <Plus size={12} />
          Add Credential
        </button>
      </div>

      {showForm && (
        <CredentialForm
          onSave={handleSave}
          onCancel={() => { setShowForm(false); setEditingCredential(null); }}
          initialData={editingCredential}
          payerTypes={payerTypes}
        />
      )}

      <div className="space-y-2">
        {filteredCredentials.map(cred => (
          <CredentialCard
            key={cred.id}
            credential={cred}
            onEdit={handleEdit}
            onDelete={handleDelete}
            onToggle={handleToggle}
            onTest={handleTest}
            payerTypes={payerTypes}
          />
        ))}
      </div>

      {filteredCredentials.length === 0 && !showForm && (
        <div className="text-center py-8 text-gray-400">
          <Shield size={32} className="mx-auto mb-2 opacity-50" />
          <p className="text-sm">No credentials configured for this {selectedOffice === 'company' ? 'company' : 'office'}.</p>
          <p className="text-xs mt-1">Click "Add Credential" to set up portal access.</p>
        </div>
      )}
    </div>
  );
}


function DashboardTab({ companyId, payerTypes }) {
  const [stats, setStats] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboard();
  }, [companyId]);

  const loadDashboard = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/dashboard`, {
        headers: { 'X-Company-Id': companyId },
      });
      if (res.ok) {
        const data = await res.json();
        setStats(data.stats);
        setJobs(data.recent_jobs || []);
      }
    } catch (err) {
      console.error('Dashboard load error:', err);
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 size={24} className="animate-spin text-gray-400" />
      </div>
    );
  }

  const statCards = [
    {
      label: 'Verifications (7d)',
      value: stats?.total_7d ?? 0,
      icon: Activity,
      color: 'text-blue-600 bg-blue-50',
    },
    {
      label: 'Success Rate',
      value: stats?.success_rate != null ? `${Math.round(stats.success_rate)}%` : '—',
      icon: CheckCircle,
      color: 'text-green-600 bg-green-50',
    },
    {
      label: 'Avg Time',
      value: stats?.avg_time_seconds != null ? `${Math.round(stats.avg_time_seconds)}s` : '—',
      icon: Clock,
      color: 'text-purple-600 bg-purple-50',
    },
    {
      label: 'Pending Jobs',
      value: stats?.pending ?? 0,
      icon: RefreshCw,
      color: 'text-orange-600 bg-orange-50',
    },
  ];

  const statusBadge = (status) => {
    const map = {
      completed: 'bg-green-100 text-green-700',
      failed: 'bg-red-100 text-red-700',
      in_progress: 'bg-blue-100 text-blue-700',
      queued: 'bg-gray-100 text-gray-700',
      mfa_waiting: 'bg-amber-100 text-amber-700',
    };
    return map[status] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="space-y-6">
      {/* Stat Cards */}
      <div className="grid grid-cols-4 gap-4">
        {statCards.map(card => {
          const Icon = card.icon;
          return (
            <div key={card.label} className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-500">{card.label}</span>
                <div className={`p-1.5 rounded ${card.color}`}>
                  <Icon size={14} />
                </div>
              </div>
              <span className="text-2xl font-bold text-gray-900">{card.value}</span>
            </div>
          );
        })}
      </div>

      {/* Recent Jobs Table */}
      <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-gray-700">Recent Verification Jobs</h3>
          <button
            onClick={loadDashboard}
            className="text-xs text-gray-500 hover:text-gray-700 flex items-center gap-1"
          >
            <RefreshCw size={12} />
            Refresh
          </button>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-xs text-gray-500">
            <tr>
              <th className="text-left px-4 py-2">Payer</th>
              <th className="text-left px-4 py-2">Status</th>
              <th className="text-left px-4 py-2">Started</th>
              <th className="text-left px-4 py-2">Completed</th>
              <th className="text-left px-4 py-2">Error</th>
              <th className="text-left px-4 py-2">Triggered By</th>
            </tr>
          </thead>
          <tbody>
            {jobs.map(job => {
              const payer = payerTypes.find(p => p.value === job.payer_type);
              return (
                <tr key={job.id} className="border-t border-gray-100 hover:bg-gray-50">
                  <td className="px-4 py-2">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${payer?.color || 'bg-gray-100 text-gray-800'}`}>
                      {payer?.label || job.payer_type}
                    </span>
                  </td>
                  <td className="px-4 py-2">
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${statusBadge(job.status)}`}>
                      {job.status}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-gray-500 text-xs">
                    {job.started_at ? new Date(job.started_at).toLocaleString() : '—'}
                  </td>
                  <td className="px-4 py-2 text-gray-500 text-xs">
                    {job.completed_at ? new Date(job.completed_at).toLocaleString() : '—'}
                  </td>
                  <td className="px-4 py-2 text-red-500 text-xs max-w-[200px] truncate" title={job.last_error}>
                    {job.last_error || '—'}
                  </td>
                  <td className="px-4 py-2 text-gray-500 text-xs">{job.triggered_by || 'manual'}</td>
                </tr>
              );
            })}
            {jobs.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-gray-400 text-sm">
                  No verification jobs found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Payer Health */}
      {stats?.payer_health && stats.payer_health.length > 0 && (
        <div className="bg-white border border-gray-200 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Payer Health (7-day)</h3>
          <div className="space-y-3">
            {stats.payer_health.map(ph => {
              const payer = payerTypes.find(p => p.value === ph.payer_type);
              const rate = ph.total > 0 ? (ph.success / ph.total) * 100 : 0;
              return (
                <div key={ph.payer_type} className="flex items-center gap-3">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium w-28 text-center ${payer?.color || 'bg-gray-100 text-gray-800'}`}>
                    {payer?.label || ph.payer_type}
                  </span>
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${rate >= 80 ? 'bg-green-500' : rate >= 50 ? 'bg-yellow-500' : 'bg-red-500'}`}
                      style={{ width: `${rate}%` }}
                    />
                  </div>
                  <span className="text-xs text-gray-500 w-20 text-right">
                    {ph.success}/{ph.total} ({Math.round(rate)}%)
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}


// ============================================================
// Main Component
// ============================================================

export default function InsuranceVerificationSettings() {
  const navigate = useNavigate();
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.id;

  const [activeTab, setActiveTab] = useState('credentials');
  const [credentials, setCredentials] = useState([]);
  const [offices, setOffices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [customPayers, setCustomPayers] = useState([]);

  const allPayerTypes = [...DEFAULT_PAYER_TYPES, ...customPayers];

  // Load custom payers from localStorage when company changes
  useEffect(() => {
    if (companyId) {
      setCustomPayers(getCustomPayers(companyId));
    }
  }, [companyId]);

  const handleAddPayer = (payer) => {
    const updated = [...customPayers, payer];
    setCustomPayers(updated);
    saveCustomPayers(companyId, updated);
  };

  const handleDeletePayer = (payerValue) => {
    const updated = customPayers.filter(p => p.value !== payerValue);
    setCustomPayers(updated);
    saveCustomPayers(companyId, updated);
  };

  const loadCredentials = useCallback(async () => {
    if (!companyId) return;
    try {
      const res = await fetch(`${API_BASE}/credentials`, {
        headers: { 'X-Company-Id': companyId },
      });
      if (res.ok) {
        const data = await res.json();
        setCredentials(data.credentials || []);
      }
    } catch (err) {
      console.error('Failed to load credentials:', err);
    }
  }, [companyId]);

  const loadOffices = useCallback(async () => {
    if (!companyId) return;
    try {
      const result = await officeAccessor.getByCompany(companyId);
      if (result.success) {
        setOffices(result.data || []);
      }
    } catch (err) {
      console.error('Failed to load offices:', err);
    }
  }, [companyId]);

  useEffect(() => {
    const init = async () => {
      setLoading(true);
      await Promise.all([loadCredentials(), loadOffices()]);
      setLoading(false);
    };
    init();
  }, [loadCredentials, loadOffices]);

  const tabs = [
    { id: 'credentials', label: 'Office Credentials', icon: Shield },
    { id: 'flows', label: 'Payers & Flows', icon: Settings },
    { id: 'dashboard', label: 'Dashboard', icon: Activity },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 size={32} className="animate-spin text-gray-400" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <button
          onClick={() => navigate('/prc')}
          className="mb-3 flex items-center gap-2 text-sm text-gray-600 hover:text-gray-800"
        >
          <ArrowLeft size={16} />
          Back to Patient Readiness Center
        </button>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <Shield className="text-[#006FB4]" />
              Insurance Verification Settings
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              Configure payer portal credentials, automation flows, and monitor verification health.
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mt-4">
          {tabs.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-t-lg font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'bg-gray-50 text-[#006FB4] border-t border-x border-gray-200'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <Icon size={16} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-6 py-6">
        {activeTab === 'credentials' && (
          <OfficeCredentialsTab
            credentials={credentials}
            offices={offices}
            companyId={companyId}
            onRefresh={loadCredentials}
            payerTypes={allPayerTypes}
          />
        )}
        {activeTab === 'flows' && (
          <PayerFlowsTab
            credentials={credentials}
            companyId={companyId}
            onRefresh={loadCredentials}
            payerTypes={allPayerTypes}
            onAddPayer={handleAddPayer}
            onDeletePayer={handleDeletePayer}
          />
        )}
        {activeTab === 'dashboard' && (
          <DashboardTab companyId={companyId} payerTypes={allPayerTypes} />
        )}
      </div>
    </div>
  );
}
