import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Building2, MapPin, Users, Shield, DollarSign, HelpCircle, FileText, 
  Plus, Edit, Trash2, Save, X, ChevronDown, ChevronRight, Search,
  Clock, Phone, Mail, Globe, ArrowLeft, RefreshCw, Brain, Sparkles
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import AIKnowledgeBaseService from '../services/aiKnowledgeBaseService';

const TABS = [
  { id: 'practice', label: 'Practice Info', icon: Building2 },
  { id: 'locations', label: 'Locations', icon: MapPin },
  { id: 'providers', label: 'Providers', icon: Users },
  { id: 'insurance', label: 'Insurance', icon: Shield },
  { id: 'pricing', label: 'Pricing', icon: DollarSign },
  { id: 'faqs', label: 'FAQs', icon: HelpCircle },
  { id: 'custom', label: 'Custom Knowledge', icon: FileText },
  { id: 'preview', label: 'AI Context Preview', icon: Brain },
];

const FAQ_CATEGORIES = [
  { value: 'appointments', label: 'Appointments' },
  { value: 'insurance', label: 'Insurance' },
  { value: 'services', label: 'Services' },
  { value: 'billing', label: 'Billing' },
  { value: 'general', label: 'General' },
  { value: 'emergency', label: 'Emergency' },
  { value: 'products', label: 'Products' },
  { value: 'custom', label: 'Custom' },
];

function AIKnowledgeBase() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('practice');
  const [knowledgeBase, setKnowledgeBase] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadKnowledgeBase();
  }, []);

  const loadKnowledgeBase = () => {
    const kb = AIKnowledgeBaseService.getKnowledgeBase();
    setKnowledgeBase(kb);
  };

  const handleSave = () => {
    if (knowledgeBase) {
      AIKnowledgeBaseService.saveKnowledgeBase(knowledgeBase);
      setEditMode(false);
    }
  };

  const handleReset = () => {
    if (confirm('Reset all knowledge base data to defaults? This cannot be undone.')) {
      AIKnowledgeBaseService.resetToDefaults();
      loadKnowledgeBase();
    }
  };

  if (!knowledgeBase) {
    return <div className="p-8 text-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white border-b shadow-sm">
        <div className="p-6">
          <button
            onClick={() => navigate('/prc')}
            className="mb-3 flex items-center gap-2 text-sm text-gray-600 hover:text-gray-800"
          >
            <ArrowLeft size={16} />
            Back to Patient Readiness Center
          </button>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                  <Brain className="text-purple-600" size={24} />
                  AI Knowledge Base
                </h1>
                <p className="text-sm text-gray-500">Educate the AI with practice information</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleReset}
                className="px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-100 rounded flex items-center gap-1"
              >
                <RefreshCw size={14} /> Reset to Defaults
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-1.5 bg-purple-600 text-white rounded text-sm hover:bg-purple-700 flex items-center gap-1"
              >
                <Save size={14} /> Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <div className="w-56 bg-white border-r min-h-[calc(100vh-73px)]">
          <nav className="p-4 space-y-1">
            {TABS.map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded text-sm ${
                    activeTab === tab.id
                      ? 'bg-purple-100 text-purple-700 font-medium'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <Icon size={16} />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6">
          {/* Practice Info Tab */}
          {activeTab === 'practice' && (
            <PracticeInfoTab 
              practice={knowledgeBase.practice} 
              onChange={(updates) => setKnowledgeBase({...knowledgeBase, practice: {...knowledgeBase.practice, ...updates}})}
            />
          )}

          {/* Locations Tab */}
          {activeTab === 'locations' && (
            <LocationsTab 
              locations={knowledgeBase.locations}
              onChange={(locations) => setKnowledgeBase({...knowledgeBase, locations})}
            />
          )}

          {/* Providers Tab */}
          {activeTab === 'providers' && (
            <ProvidersTab 
              providers={knowledgeBase.providers}
              onChange={(providers) => setKnowledgeBase({...knowledgeBase, providers})}
            />
          )}

          {/* Insurance Tab */}
          {activeTab === 'insurance' && (
            <InsuranceTab 
              insurances={knowledgeBase.insurances}
              onChange={(insurances) => setKnowledgeBase({...knowledgeBase, insurances})}
            />
          )}

          {/* Pricing Tab */}
          {activeTab === 'pricing' && (
            <PricingTab 
              pricing={knowledgeBase.pricing}
              onChange={(pricing) => setKnowledgeBase({...knowledgeBase, pricing})}
            />
          )}

          {/* FAQs Tab */}
          {activeTab === 'faqs' && (
            <FAQsTab 
              faqs={knowledgeBase.faqs}
              onChange={(faqs) => setKnowledgeBase({...knowledgeBase, faqs})}
            />
          )}

          {/* Custom Knowledge Tab */}
          {activeTab === 'custom' && (
            <CustomKnowledgeTab 
              customKnowledge={knowledgeBase.customKnowledge}
              onChange={(customKnowledge) => setKnowledgeBase({...knowledgeBase, customKnowledge})}
            />
          )}

          {/* AI Context Preview Tab */}
          {activeTab === 'preview' && (
            <AIContextPreviewTab />
          )}
        </div>
      </div>
    </div>
  );
}

// Practice Info Tab Component
function PracticeInfoTab({ practice, onChange }) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <Building2 size={20} className="text-purple-600" />
        Practice Information
      </h2>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Practice Name</label>
          <input
            type="text"
            value={practice.name || ''}
            onChange={(e) => onChange({ name: e.target.value })}
            className="w-full border rounded px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Tagline</label>
          <input
            type="text"
            value={practice.tagline || ''}
            onChange={(e) => onChange({ tagline: e.target.value })}
            className="w-full border rounded px-3 py-2 text-sm"
          />
        </div>
        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
          <textarea
            value={practice.description || ''}
            onChange={(e) => onChange({ description: e.target.value })}
            className="w-full border rounded px-3 py-2 text-sm h-20"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Specialties (comma-separated)</label>
          <input
            type="text"
            value={practice.specialties?.join(', ') || ''}
            onChange={(e) => onChange({ specialties: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
            className="w-full border rounded px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Services (comma-separated)</label>
          <input
            type="text"
            value={practice.services?.join(', ') || ''}
            onChange={(e) => onChange({ services: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
            className="w-full border rounded px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Languages (comma-separated)</label>
          <input
            type="text"
            value={practice.languages?.join(', ') || ''}
            onChange={(e) => onChange({ languages: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
            className="w-full border rounded px-3 py-2 text-sm"
          />
        </div>
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={practice.acceptingNewPatients || false}
            onChange={(e) => onChange({ acceptingNewPatients: e.target.checked })}
            className="rounded"
          />
          <label className="text-sm text-gray-700">Accepting New Patients</label>
        </div>
      </div>
    </div>
  );
}

// Locations Tab Component
function LocationsTab({ locations, onChange }) {
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState(null);

  const handleAdd = () => {
    const newLoc = {
      id: `loc_${Date.now()}`,
      name: 'New Location',
      address: '',
      city: '',
      state: '',
      zip: '',
      phone: '',
      hours: {},
    };
    onChange([...locations, newLoc]);
    setEditingId(newLoc.id);
    setEditForm(newLoc);
  };

  const handleSave = () => {
    if (editForm) {
      onChange(locations.map(l => l.id === editForm.id ? editForm : l));
      setEditingId(null);
      setEditForm(null);
    }
  };

  const handleDelete = (id) => {
    if (confirm('Delete this location?')) {
      onChange(locations.filter(l => l.id !== id));
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <MapPin size={20} className="text-purple-600" />
          Locations
        </h2>
        <button onClick={handleAdd} className="flex items-center gap-1 px-3 py-1.5 bg-purple-600 text-white rounded text-sm">
          <Plus size={14} /> Add Location
        </button>
      </div>
      
      <div className="space-y-4">
        {locations.map(loc => (
          <div key={loc.id} className="border rounded-lg p-4">
            {editingId === loc.id ? (
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Location Name"
                    value={editForm?.name || ''}
                    onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                    className="border rounded px-2 py-1 text-sm"
                  />
                  <input
                    type="text"
                    placeholder="Phone"
                    value={editForm?.phone || ''}
                    onChange={(e) => setEditForm({...editForm, phone: e.target.value})}
                    className="border rounded px-2 py-1 text-sm"
                  />
                </div>
                <input
                  type="text"
                  placeholder="Address"
                  value={editForm?.address || ''}
                  onChange={(e) => setEditForm({...editForm, address: e.target.value})}
                  className="w-full border rounded px-2 py-1 text-sm"
                />
                <div className="grid grid-cols-3 gap-3">
                  <input
                    type="text"
                    placeholder="City"
                    value={editForm?.city || ''}
                    onChange={(e) => setEditForm({...editForm, city: e.target.value})}
                    className="border rounded px-2 py-1 text-sm"
                  />
                  <input
                    type="text"
                    placeholder="State"
                    value={editForm?.state || ''}
                    onChange={(e) => setEditForm({...editForm, state: e.target.value})}
                    className="border rounded px-2 py-1 text-sm"
                  />
                  <input
                    type="text"
                    placeholder="ZIP"
                    value={editForm?.zip || ''}
                    onChange={(e) => setEditForm({...editForm, zip: e.target.value})}
                    className="border rounded px-2 py-1 text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].map(day => (
                    <div key={day} className="flex items-center gap-2">
                      <span className="text-xs w-20 capitalize">{day}:</span>
                      <input
                        type="text"
                        placeholder="e.g., 8am-5pm"
                        value={editForm?.hours?.[day] || ''}
                        onChange={(e) => setEditForm({...editForm, hours: {...editForm.hours, [day]: e.target.value}})}
                        className="flex-1 border rounded px-2 py-1 text-xs"
                      />
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <button onClick={handleSave} className="px-3 py-1 bg-green-600 text-white rounded text-sm">Save</button>
                  <button onClick={() => {setEditingId(null); setEditForm(null);}} className="px-3 py-1 bg-gray-200 rounded text-sm">Cancel</button>
                </div>
              </div>
            ) : (
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-medium">{loc.name} {loc.isMainLocation && <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded">Main</span>}</h3>
                  <p className="text-sm text-gray-600">{loc.address}, {loc.city}, {loc.state} {loc.zip}</p>
                  <p className="text-sm text-gray-500">{loc.phone}</p>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => {setEditingId(loc.id); setEditForm(loc);}} className="p-1 hover:bg-gray-100 rounded">
                    <Edit size={14} className="text-gray-500" />
                  </button>
                  <button onClick={() => handleDelete(loc.id)} className="p-1 hover:bg-gray-100 rounded">
                    <Trash2 size={14} className="text-red-500" />
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// Providers Tab Component  
function ProvidersTab({ providers, onChange }) {
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState(null);

  const handleAdd = () => {
    const newProv = {
      id: `prov_${Date.now()}`,
      name: '',
      title: 'OD',
      acceptingNewPatients: true,
    };
    onChange([...providers, newProv]);
    setEditingId(newProv.id);
    setEditForm(newProv);
  };

  const handleSave = () => {
    if (editForm) {
      onChange(providers.map(p => p.id === editForm.id ? editForm : p));
      setEditingId(null);
      setEditForm(null);
    }
  };

  const handleDelete = (id) => {
    if (confirm('Delete this provider?')) {
      onChange(providers.filter(p => p.id !== id));
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Users size={20} className="text-purple-600" />
          Providers
        </h2>
        <button onClick={handleAdd} className="flex items-center gap-1 px-3 py-1.5 bg-purple-600 text-white rounded text-sm">
          <Plus size={14} /> Add Provider
        </button>
      </div>
      
      <div className="space-y-4">
        {providers.map(prov => (
          <div key={prov.id} className="border rounded-lg p-4">
            {editingId === prov.id ? (
              <div className="space-y-3">
                <div className="grid grid-cols-3 gap-3">
                  <input
                    type="text"
                    placeholder="Full Name (e.g., Dr. Sarah Johnson)"
                    value={editForm?.name || ''}
                    onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                    className="col-span-2 border rounded px-2 py-1 text-sm"
                  />
                  <input
                    type="text"
                    placeholder="Title (e.g., OD, MD)"
                    value={editForm?.title || ''}
                    onChange={(e) => setEditForm({...editForm, title: e.target.value})}
                    className="border rounded px-2 py-1 text-sm"
                  />
                </div>
                <input
                  type="text"
                  placeholder="Specialty"
                  value={editForm?.specialty || ''}
                  onChange={(e) => setEditForm({...editForm, specialty: e.target.value})}
                  className="w-full border rounded px-2 py-1 text-sm"
                />
                <textarea
                  placeholder="Bio"
                  value={editForm?.bio || ''}
                  onChange={(e) => setEditForm({...editForm, bio: e.target.value})}
                  className="w-full border rounded px-2 py-1 text-sm h-16"
                />
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={editForm?.acceptingNewPatients || false}
                    onChange={(e) => setEditForm({...editForm, acceptingNewPatients: e.target.checked})}
                  />
                  <span className="text-sm">Accepting New Patients</span>
                </div>
                <div className="flex gap-2">
                  <button onClick={handleSave} className="px-3 py-1 bg-green-600 text-white rounded text-sm">Save</button>
                  <button onClick={() => {setEditingId(null); setEditForm(null);}} className="px-3 py-1 bg-gray-200 rounded text-sm">Cancel</button>
                </div>
              </div>
            ) : (
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-medium">{prov.name}, {prov.title}</h3>
                  {prov.specialty && <p className="text-sm text-gray-600">{prov.specialty}</p>}
                  {prov.bio && <p className="text-sm text-gray-500 mt-1">{prov.bio}</p>}
                  <span className={`text-xs px-2 py-0.5 rounded mt-2 inline-block ${prov.acceptingNewPatients ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {prov.acceptingNewPatients ? 'Accepting New Patients' : 'Not Accepting'}
                  </span>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => {setEditingId(prov.id); setEditForm(prov);}} className="p-1 hover:bg-gray-100 rounded">
                    <Edit size={14} className="text-gray-500" />
                  </button>
                  <button onClick={() => handleDelete(prov.id)} className="p-1 hover:bg-gray-100 rounded">
                    <Trash2 size={14} className="text-red-500" />
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// Insurance Tab Component
function InsuranceTab({ insurances, onChange }) {
  const [newInsurance, setNewInsurance] = useState('');

  const handleAdd = () => {
    if (newInsurance.trim()) {
      onChange([...insurances, {
        id: `ins_${Date.now()}`,
        name: newInsurance.trim(),
        isAccepted: true,
      }]);
      setNewInsurance('');
    }
  };

  const handleToggle = (id) => {
    onChange(insurances.map(i => i.id === id ? {...i, isAccepted: !i.isAccepted} : i));
  };

  const handleDelete = (id) => {
    onChange(insurances.filter(i => i.id !== id));
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <Shield size={20} className="text-purple-600" />
        Accepted Insurance Plans
      </h2>
      
      <div className="flex gap-2 mb-4">
        <input
          type="text"
          placeholder="Add insurance plan..."
          value={newInsurance}
          onChange={(e) => setNewInsurance(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleAdd()}
          className="flex-1 border rounded px-3 py-2 text-sm"
        />
        <button onClick={handleAdd} className="px-4 py-2 bg-purple-600 text-white rounded text-sm">Add</button>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {insurances.map(ins => (
          <div key={ins.id} className={`flex items-center justify-between p-2 rounded border ${ins.isAccepted ? 'bg-green-50 border-green-200' : 'bg-gray-50'}`}>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={ins.isAccepted}
                onChange={() => handleToggle(ins.id)}
                className="rounded"
              />
              <span className={`text-sm ${ins.isAccepted ? 'text-green-700' : 'text-gray-500 line-through'}`}>{ins.name}</span>
            </div>
            <button onClick={() => handleDelete(ins.id)} className="p-1 hover:bg-gray-200 rounded">
              <X size={12} className="text-gray-400" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// Pricing Tab Component
function PricingTab({ pricing, onChange }) {
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState(null);

  const handleAdd = () => {
    const newPrice = {
      id: `price_${Date.now()}`,
      service: '',
      priceRange: '',
    };
    onChange([...pricing, newPrice]);
    setEditingId(newPrice.id);
    setEditForm(newPrice);
  };

  const handleSave = () => {
    if (editForm) {
      onChange(pricing.map(p => p.id === editForm.id ? editForm : p));
      setEditingId(null);
      setEditForm(null);
    }
  };

  const handleDelete = (id) => {
    onChange(pricing.filter(p => p.id !== id));
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <DollarSign size={20} className="text-purple-600" />
          Pricing Information
        </h2>
        <button onClick={handleAdd} className="flex items-center gap-1 px-3 py-1.5 bg-purple-600 text-white rounded text-sm">
          <Plus size={14} /> Add Service
        </button>
      </div>
      
      <div className="space-y-3">
        {pricing.map(price => (
          <div key={price.id} className="border rounded-lg p-3">
            {editingId === price.id ? (
              <div className="space-y-2">
                <input
                  type="text"
                  placeholder="Service Name"
                  value={editForm?.service || ''}
                  onChange={(e) => setEditForm({...editForm, service: e.target.value})}
                  className="w-full border rounded px-2 py-1 text-sm"
                />
                <input
                  type="text"
                  placeholder="Description"
                  value={editForm?.description || ''}
                  onChange={(e) => setEditForm({...editForm, description: e.target.value})}
                  className="w-full border rounded px-2 py-1 text-sm"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="Price Range (e.g., $99 - $149)"
                    value={editForm?.priceRange || ''}
                    onChange={(e) => setEditForm({...editForm, priceRange: e.target.value})}
                    className="border rounded px-2 py-1 text-sm"
                  />
                  <input
                    type="text"
                    placeholder="Insurance Coverage Notes"
                    value={editForm?.insuranceCoverage || ''}
                    onChange={(e) => setEditForm({...editForm, insuranceCoverage: e.target.value})}
                    className="border rounded px-2 py-1 text-sm"
                  />
                </div>
                <div className="flex gap-2">
                  <button onClick={handleSave} className="px-3 py-1 bg-green-600 text-white rounded text-sm">Save</button>
                  <button onClick={() => {setEditingId(null); setEditForm(null);}} className="px-3 py-1 bg-gray-200 rounded text-sm">Cancel</button>
                </div>
              </div>
            ) : (
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-medium">{price.service}</h3>
                  {price.description && <p className="text-sm text-gray-600">{price.description}</p>}
                  {price.priceRange && <p className="text-sm text-green-600 font-medium">{price.priceRange}</p>}
                  {price.insuranceCoverage && <p className="text-xs text-gray-500">{price.insuranceCoverage}</p>}
                </div>
                <div className="flex gap-1">
                  <button onClick={() => {setEditingId(price.id); setEditForm(price);}} className="p-1 hover:bg-gray-100 rounded">
                    <Edit size={14} className="text-gray-500" />
                  </button>
                  <button onClick={() => handleDelete(price.id)} className="p-1 hover:bg-gray-100 rounded">
                    <Trash2 size={14} className="text-red-500" />
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// FAQs Tab Component
function FAQsTab({ faqs, onChange }) {
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState(null);
  const [filterCategory, setFilterCategory] = useState('all');

  const filteredFaqs = filterCategory === 'all' ? faqs : faqs.filter(f => f.category === filterCategory);

  const handleAdd = () => {
    const newFaq = {
      id: `faq_${Date.now()}`,
      question: '',
      answer: '',
      category: 'general',
      keywords: [],
    };
    onChange([...faqs, newFaq]);
    setEditingId(newFaq.id);
    setEditForm(newFaq);
  };

  const handleSave = () => {
    if (editForm) {
      onChange(faqs.map(f => f.id === editForm.id ? editForm : f));
      setEditingId(null);
      setEditForm(null);
    }
  };

  const handleDelete = (id) => {
    if (confirm('Delete this FAQ?')) {
      onChange(faqs.filter(f => f.id !== id));
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <HelpCircle size={20} className="text-purple-600" />
          Frequently Asked Questions
        </h2>
        <div className="flex gap-2">
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="border rounded px-2 py-1 text-sm"
          >
            <option value="all">All Categories</option>
            {FAQ_CATEGORIES.map(cat => (
              <option key={cat.value} value={cat.value}>{cat.label}</option>
            ))}
          </select>
          <button onClick={handleAdd} className="flex items-center gap-1 px-3 py-1.5 bg-purple-600 text-white rounded text-sm">
            <Plus size={14} /> Add FAQ
          </button>
        </div>
      </div>
      
      <div className="space-y-3">
        {filteredFaqs.map(faq => (
          <div key={faq.id} className="border rounded-lg p-4">
            {editingId === faq.id ? (
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Question"
                  value={editForm?.question || ''}
                  onChange={(e) => setEditForm({...editForm, question: e.target.value})}
                  className="w-full border rounded px-3 py-2 text-sm font-medium"
                />
                <textarea
                  placeholder="Answer"
                  value={editForm?.answer || ''}
                  onChange={(e) => setEditForm({...editForm, answer: e.target.value})}
                  className="w-full border rounded px-3 py-2 text-sm h-24"
                />
                <div className="grid grid-cols-2 gap-3">
                  <select
                    value={editForm?.category || 'general'}
                    onChange={(e) => setEditForm({...editForm, category: e.target.value})}
                    className="border rounded px-2 py-1 text-sm"
                  >
                    {FAQ_CATEGORIES.map(cat => (
                      <option key={cat.value} value={cat.value}>{cat.label}</option>
                    ))}
                  </select>
                  <input
                    type="text"
                    placeholder="Keywords (comma-separated)"
                    value={editForm?.keywords?.join(', ') || ''}
                    onChange={(e) => setEditForm({...editForm, keywords: e.target.value.split(',').map(k => k.trim()).filter(Boolean)})}
                    className="border rounded px-2 py-1 text-sm"
                  />
                </div>
                <div className="flex gap-2">
                  <button onClick={handleSave} className="px-3 py-1 bg-green-600 text-white rounded text-sm">Save</button>
                  <button onClick={() => {setEditingId(null); setEditForm(null);}} className="px-3 py-1 bg-gray-200 rounded text-sm">Cancel</button>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs px-2 py-0.5 bg-purple-100 text-purple-700 rounded capitalize">{faq.category}</span>
                    </div>
                    <h3 className="font-medium text-gray-900">Q: {faq.question}</h3>
                    <p className="text-sm text-gray-600 mt-1">A: {faq.answer}</p>
                    {faq.keywords?.length > 0 && (
                      <div className="flex gap-1 mt-2">
                        {faq.keywords.map((kw, i) => (
                          <span key={i} className="text-xs px-1.5 py-0.5 bg-gray-100 text-gray-600 rounded">{kw}</span>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-1 ml-2">
                    <button onClick={() => {setEditingId(faq.id); setEditForm(faq);}} className="p-1 hover:bg-gray-100 rounded">
                      <Edit size={14} className="text-gray-500" />
                    </button>
                    <button onClick={() => handleDelete(faq.id)} className="p-1 hover:bg-gray-100 rounded">
                      <Trash2 size={14} className="text-red-500" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// Custom Knowledge Tab Component
function CustomKnowledgeTab({ customKnowledge, onChange }) {
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState(null);

  const handleAdd = () => {
    const newKnowledge = {
      id: `custom_${Date.now()}`,
      title: '',
      content: '',
      category: 'general',
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    onChange([...customKnowledge, newKnowledge]);
    setEditingId(newKnowledge.id);
    setEditForm(newKnowledge);
  };

  const handleSave = () => {
    if (editForm) {
      onChange(customKnowledge.map(k => k.id === editForm.id ? {...editForm, updatedAt: new Date().toISOString()} : k));
      setEditingId(null);
      setEditForm(null);
    }
  };

  const handleDelete = (id) => {
    if (confirm('Delete this knowledge entry?')) {
      onChange(customKnowledge.filter(k => k.id !== id));
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <FileText size={20} className="text-purple-600" />
            Custom Knowledge
          </h2>
          <p className="text-sm text-gray-500">Add any additional information the AI should know</p>
        </div>
        <button onClick={handleAdd} className="flex items-center gap-1 px-3 py-1.5 bg-purple-600 text-white rounded text-sm">
          <Plus size={14} /> Add Entry
        </button>
      </div>
      
      <div className="space-y-3">
        {customKnowledge.map(knowledge => (
          <div key={knowledge.id} className={`border rounded-lg p-4 ${!knowledge.isActive ? 'opacity-50' : ''}`}>
            {editingId === knowledge.id ? (
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Title"
                  value={editForm?.title || ''}
                  onChange={(e) => setEditForm({...editForm, title: e.target.value})}
                  className="w-full border rounded px-3 py-2 text-sm font-medium"
                />
                <textarea
                  placeholder="Content - Add detailed information here..."
                  value={editForm?.content || ''}
                  onChange={(e) => setEditForm({...editForm, content: e.target.value})}
                  className="w-full border rounded px-3 py-2 text-sm h-32"
                />
                <div className="flex items-center gap-4">
                  <input
                    type="text"
                    placeholder="Category"
                    value={editForm?.category || ''}
                    onChange={(e) => setEditForm({...editForm, category: e.target.value})}
                    className="border rounded px-2 py-1 text-sm"
                  />
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={editForm?.isActive ?? true}
                      onChange={(e) => setEditForm({...editForm, isActive: e.target.checked})}
                    />
                    <span className="text-sm">Active</span>
                  </label>
                </div>
                <div className="flex gap-2">
                  <button onClick={handleSave} className="px-3 py-1 bg-green-600 text-white rounded text-sm">Save</button>
                  <button onClick={() => {setEditingId(null); setEditForm(null);}} className="px-3 py-1 bg-gray-200 rounded text-sm">Cancel</button>
                </div>
              </div>
            ) : (
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs px-2 py-0.5 bg-gray-100 text-gray-600 rounded">{knowledge.category}</span>
                    {!knowledge.isActive && <span className="text-xs text-red-500">Inactive</span>}
                  </div>
                  <h3 className="font-medium">{knowledge.title}</h3>
                  <p className="text-sm text-gray-600 mt-1 whitespace-pre-wrap">{knowledge.content}</p>
                </div>
                <div className="flex gap-1 ml-2">
                  <button onClick={() => {setEditingId(knowledge.id); setEditForm(knowledge);}} className="p-1 hover:bg-gray-100 rounded">
                    <Edit size={14} className="text-gray-500" />
                  </button>
                  <button onClick={() => handleDelete(knowledge.id)} className="p-1 hover:bg-gray-100 rounded">
                    <Trash2 size={14} className="text-red-500" />
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
        {customKnowledge.length === 0 && (
          <p className="text-gray-500 text-sm text-center py-4">No custom knowledge entries yet. Add information the AI should know!</p>
        )}
      </div>
    </div>
  );
}

// AI Context Preview Tab
function AIContextPreviewTab() {
  const [context, setContext] = useState('');

  useEffect(() => {
    const generatedContext = AIKnowledgeBaseService.generateAIContext();
    setContext(generatedContext);
  }, []);

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Sparkles size={20} className="text-purple-600" />
            AI Context Preview
          </h2>
          <p className="text-sm text-gray-500">This is what gets passed to the AI when handling patient queries</p>
        </div>
        <button 
          onClick={() => setContext(AIKnowledgeBaseService.generateAIContext())}
          className="px-3 py-1.5 bg-gray-100 rounded text-sm flex items-center gap-1"
        >
          <RefreshCw size={14} /> Refresh
        </button>
      </div>
      
      <div className="bg-gray-900 text-green-400 rounded-lg p-4 font-mono text-xs overflow-auto max-h-[600px] whitespace-pre-wrap">
        {context}
      </div>
    </div>
  );
}

export default AIKnowledgeBase;
