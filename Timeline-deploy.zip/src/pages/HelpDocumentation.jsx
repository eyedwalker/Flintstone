import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BookOpen, ArrowLeft, Search, ChevronRight, ChevronDown,
  Monitor, Users, Server, Rocket, ExternalLink
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

// Import markdown docs as raw strings
import adminHelpMd from '../../docs/ADMIN_HELP_AND_TRAINING.md?raw';
import patientHelpMd from '../../docs/PATIENT_PORTAL_HELP.md?raw';
import systemArchMd from '../../docs/SYSTEM_ARCHITECTURE_AND_DEVELOPER_GUIDE.md?raw';
import deploymentMd from '../../docs/DEPLOYMENT_AND_CONFIGURATION.md?raw';

const DOCS = [
  { id: 'admin', label: 'Admin Help & Training', icon: Monitor, content: adminHelpMd, description: 'Staff training guide for the Patient Readiness Center' },
  { id: 'patient', label: 'Patient Portal Help', icon: Users, content: patientHelpMd, description: 'Help guide for the patient-facing portal' },
  { id: 'architecture', label: 'System Architecture', icon: Server, content: systemArchMd, description: 'Developer guide and system architecture', adminOnly: true },
  { id: 'deployment', label: 'Deployment Guide', icon: Rocket, content: deploymentMd, description: 'Deployment, configuration, and operations', adminOnly: true },
];

// Extract sections from markdown (## headings)
function extractSections(markdown) {
  const lines = markdown.split('\n');
  const sections = [];
  let currentSection = null;
  let currentContent = [];

  for (const line of lines) {
    const h2Match = line.match(/^## (.+)/);
    if (h2Match) {
      if (currentSection) {
        currentSection.content = currentContent.join('\n');
        sections.push(currentSection);
      }
      currentSection = { title: h2Match[1].replace(/^[\d]+\.\s*/, ''), content: '' };
      currentContent = [];
    } else if (currentSection) {
      currentContent.push(line);
    }
  }
  if (currentSection) {
    currentSection.content = currentContent.join('\n');
    sections.push(currentSection);
  }

  return sections;
}

// Simple markdown to React renderer
function MarkdownRenderer({ content }) {
  const elements = useMemo(() => {
    if (!content) return [];
    const lines = content.split('\n');
    const result = [];
    let i = 0;
    let listItems = [];
    let listType = null; // 'ul' or 'ol'
    let inCodeBlock = false;
    let codeLines = [];
    let tableRows = [];
    let inTable = false;

    const flushList = () => {
      if (listItems.length > 0) {
        const Tag = listType === 'ol' ? 'ol' : 'ul';
        const className = listType === 'ol'
          ? 'list-decimal list-inside space-y-1 my-2 ml-4 text-gray-700'
          : 'list-disc list-inside space-y-1 my-2 ml-4 text-gray-700';
        result.push(
          <Tag key={`list-${result.length}`} className={className}>
            {listItems.map((item, idx) => (
              <li key={idx} className="text-sm leading-relaxed">
                <InlineMarkdown text={item} />
              </li>
            ))}
          </Tag>
        );
        listItems = [];
        listType = null;
      }
    };

    const flushTable = () => {
      if (tableRows.length > 0) {
        const headers = tableRows[0];
        const dataRows = tableRows.slice(2); // skip separator row
        result.push(
          <div key={`table-${result.length}`} className="overflow-x-auto my-4">
            <table className="min-w-full border border-gray-200 rounded-lg text-sm">
              <thead>
                <tr className="bg-gray-50">
                  {headers.map((h, idx) => (
                    <th key={idx} className="px-4 py-2 text-left font-semibold text-gray-700 border-b">{h.trim()}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {dataRows.map((row, rIdx) => (
                  <tr key={rIdx} className={rIdx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    {row.map((cell, cIdx) => (
                      <td key={cIdx} className="px-4 py-2 text-gray-600 border-b border-gray-100">{cell.trim()}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
        tableRows = [];
        inTable = false;
      }
    };

    while (i < lines.length) {
      const line = lines[i];

      // Code block
      if (line.startsWith('```')) {
        if (inCodeBlock) {
          flushList();
          result.push(
            <pre key={`code-${result.length}`} className="bg-gray-900 text-green-400 rounded-lg p-4 my-3 overflow-x-auto text-xs font-mono">
              {codeLines.join('\n')}
            </pre>
          );
          codeLines = [];
          inCodeBlock = false;
        } else {
          flushList();
          flushTable();
          inCodeBlock = true;
        }
        i++;
        continue;
      }

      if (inCodeBlock) {
        codeLines.push(line);
        i++;
        continue;
      }

      // Table row
      if (line.includes('|') && line.trim().startsWith('|')) {
        flushList();
        const cells = line.split('|').filter((_, idx, arr) => idx > 0 && idx < arr.length - 1);
        if (!inTable) inTable = true;
        tableRows.push(cells);
        i++;
        continue;
      } else if (inTable) {
        flushTable();
      }

      // H3
      const h3Match = line.match(/^### (.+)/);
      if (h3Match) {
        flushList();
        result.push(
          <h3 key={`h3-${result.length}`} className="text-lg font-semibold text-gray-800 mt-6 mb-2 flex items-center gap-2">
            <ChevronRight size={16} className="text-purple-500" />
            {h3Match[1]}
          </h3>
        );
        i++;
        continue;
      }

      // H4
      const h4Match = line.match(/^#### (.+)/);
      if (h4Match) {
        flushList();
        result.push(
          <h4 key={`h4-${result.length}`} className="text-base font-medium text-gray-700 mt-4 mb-1">{h4Match[1]}</h4>
        );
        i++;
        continue;
      }

      // Blockquote
      if (line.startsWith('> ')) {
        flushList();
        result.push(
          <blockquote key={`bq-${result.length}`} className="border-l-4 border-purple-300 bg-purple-50 pl-4 py-2 pr-3 my-3 text-sm text-purple-800 rounded-r">
            <InlineMarkdown text={line.slice(2)} />
          </blockquote>
        );
        i++;
        continue;
      }

      // Ordered list
      const olMatch = line.match(/^(\d+)\.\s+(.+)/);
      if (olMatch) {
        if (listType !== 'ol') {
          flushList();
          listType = 'ol';
        }
        listItems.push(olMatch[2]);
        i++;
        continue;
      }

      // Unordered list
      const ulMatch = line.match(/^[-*]\s+(.+)/);
      if (ulMatch) {
        if (listType !== 'ul') {
          flushList();
          listType = 'ul';
        }
        listItems.push(ulMatch[1]);
        i++;
        continue;
      }

      // Indented list items (  - item)
      const indentUlMatch = line.match(/^\s{2,}[-*]\s+(.+)/);
      if (indentUlMatch) {
        listItems.push('  ' + indentUlMatch[1]);
        i++;
        continue;
      }

      // Horizontal rule
      if (line.match(/^---+$/)) {
        flushList();
        result.push(<hr key={`hr-${result.length}`} className="my-6 border-gray-200" />);
        i++;
        continue;
      }

      // Empty line
      if (line.trim() === '') {
        flushList();
        i++;
        continue;
      }

      // Regular paragraph
      flushList();
      result.push(
        <p key={`p-${result.length}`} className="text-sm text-gray-700 leading-relaxed my-1.5">
          <InlineMarkdown text={line} />
        </p>
      );
      i++;
    }

    flushList();
    flushTable();

    return result;
  }, [content]);

  return <div>{elements}</div>;
}

// Inline markdown (bold, italic, code, links)
function InlineMarkdown({ text }) {
  if (!text) return null;

  const parts = [];
  let remaining = text;
  let key = 0;

  while (remaining.length > 0) {
    // Bold
    const boldMatch = remaining.match(/\*\*(.+?)\*\*/);
    // Inline code
    const codeMatch = remaining.match(/`(.+?)`/);
    // Link
    const linkMatch = remaining.match(/\[(.+?)\]\((.+?)\)/);

    // Find earliest match
    let earliest = null;
    let earliestIdx = remaining.length;

    if (boldMatch && boldMatch.index < earliestIdx) {
      earliest = { type: 'bold', match: boldMatch };
      earliestIdx = boldMatch.index;
    }
    if (codeMatch && codeMatch.index < earliestIdx) {
      earliest = { type: 'code', match: codeMatch };
      earliestIdx = codeMatch.index;
    }
    if (linkMatch && linkMatch.index < earliestIdx) {
      earliest = { type: 'link', match: linkMatch };
      earliestIdx = linkMatch.index;
    }

    if (!earliest) {
      parts.push(<span key={key++}>{remaining}</span>);
      break;
    }

    // Text before match
    if (earliestIdx > 0) {
      parts.push(<span key={key++}>{remaining.slice(0, earliestIdx)}</span>);
    }

    const m = earliest.match;
    switch (earliest.type) {
      case 'bold':
        parts.push(<strong key={key++} className="font-semibold text-gray-900">{m[1]}</strong>);
        remaining = remaining.slice(earliestIdx + m[0].length);
        break;
      case 'code':
        parts.push(<code key={key++} className="bg-gray-100 text-purple-700 px-1.5 py-0.5 rounded text-xs font-mono">{m[1]}</code>);
        remaining = remaining.slice(earliestIdx + m[0].length);
        break;
      case 'link':
        parts.push(
          <a key={key++} href={m[2]} className="text-purple-600 hover:underline inline-flex items-center gap-0.5">
            {m[1]}<ExternalLink size={10} />
          </a>
        );
        remaining = remaining.slice(earliestIdx + m[0].length);
        break;
    }
  }

  return <>{parts}</>;
}

function HelpDocumentation() {
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const [activeDoc, setActiveDoc] = useState('admin');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSection, setActiveSection] = useState(null);
  const [expandedSections, setExpandedSections] = useState({});

  const visibleDocs = DOCS.filter(d => !d.adminOnly || isAdmin);

  const currentDoc = DOCS.find(d => d.id === activeDoc);
  const sections = useMemo(() => {
    if (!currentDoc) return [];
    return extractSections(currentDoc.content);
  }, [activeDoc, currentDoc]);

  // Filter sections by search
  const filteredSections = useMemo(() => {
    if (!searchQuery.trim()) return sections;
    const q = searchQuery.toLowerCase();
    return sections.filter(s =>
      s.title.toLowerCase().includes(q) ||
      s.content.toLowerCase().includes(q)
    );
  }, [sections, searchQuery]);

  // Search across all docs
  const crossDocResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase();
    const results = [];
    for (const doc of visibleDocs) {
      if (doc.id === activeDoc) continue;
      const docSections = extractSections(doc.content);
      const matches = docSections.filter(s =>
        s.title.toLowerCase().includes(q) ||
        s.content.toLowerCase().includes(q)
      );
      if (matches.length > 0) {
        results.push({ doc, matchCount: matches.length });
      }
    }
    return results;
  }, [searchQuery, activeDoc, visibleDocs]);

  const toggleSection = (idx) => {
    setExpandedSections(prev => ({ ...prev, [idx]: !prev[idx] }));
  };

  // Expand first section by default when switching docs
  useEffect(() => {
    if (filteredSections.length > 0) {
      setExpandedSections({ 0: true });
    }
  }, [activeDoc]);

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white border-b shadow-sm">
        <div className="p-6">
          <button
            onClick={() => navigate('/prc')}
            className="mb-3 flex items-center gap-2 text-sm text-gray-600 hover:text-gray-800"
          >
            <ArrowLeft size={16} />
            Back to Patient Readiness Center
          </button>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <BookOpen className="text-purple-600" size={24} />
                Help & Documentation
              </h1>
              <p className="text-sm text-gray-500 mt-1">Training guides, help documentation, and system reference</p>
            </div>

            {/* Search */}
            <div className="relative w-80">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search documentation..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  &times;
                </button>
              )}
            </div>
          </div>

          {/* Doc tabs */}
          <div className="flex gap-2 mt-4">
            {visibleDocs.map(doc => {
              const Icon = doc.icon;
              return (
                <button
                  key={doc.id}
                  onClick={() => { setActiveDoc(doc.id); setSearchQuery(''); }}
                  className={`px-4 py-2 rounded-lg text-sm flex items-center gap-2 transition-colors ${
                    activeDoc === doc.id
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <Icon size={16} />
                  {doc.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Section Sidebar */}
        <div className="w-72 bg-white border-r min-h-[calc(100vh-180px)] overflow-y-auto">
          <div className="p-4">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Sections</h3>
            <nav className="space-y-0.5">
              {filteredSections.map((section, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setExpandedSections(prev => ({ ...prev, [idx]: true }));
                    setActiveSection(idx);
                    const el = document.getElementById(`section-${idx}`);
                    el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }}
                  className={`w-full text-left px-3 py-2 rounded text-sm transition-colors ${
                    activeSection === idx
                      ? 'bg-purple-100 text-purple-700 font-medium'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {section.title}
                </button>
              ))}
            </nav>

            {/* Cross-doc search results */}
            {crossDocResults.length > 0 && (
              <div className="mt-6 pt-4 border-t">
                <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Also found in</h3>
                {crossDocResults.map(({ doc, matchCount }) => (
                  <button
                    key={doc.id}
                    onClick={() => setActiveDoc(doc.id)}
                    className="w-full text-left px-3 py-2 rounded text-sm text-blue-600 hover:bg-blue-50 flex items-center justify-between"
                  >
                    <span>{doc.label}</span>
                    <span className="text-xs bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded">{matchCount}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6 overflow-y-auto max-h-[calc(100vh-180px)]">
          {/* Doc description */}
          <div className="mb-6 bg-purple-50 border border-purple-200 rounded-lg p-4">
            <p className="text-sm text-purple-700">{currentDoc?.description}</p>
          </div>

          {searchQuery && (
            <div className="mb-4 text-sm text-gray-500">
              Showing {filteredSections.length} of {sections.length} sections matching "{searchQuery}"
            </div>
          )}

          {/* Sections */}
          <div className="space-y-4">
            {filteredSections.map((section, idx) => (
              <div
                key={idx}
                id={`section-${idx}`}
                className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden"
              >
                <button
                  onClick={() => toggleSection(idx)}
                  className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-gray-50 transition-colors"
                >
                  <h2 className="text-lg font-semibold text-gray-900">{section.title}</h2>
                  {expandedSections[idx] ? (
                    <ChevronDown size={20} className="text-gray-400" />
                  ) : (
                    <ChevronRight size={20} className="text-gray-400" />
                  )}
                </button>
                {expandedSections[idx] && (
                  <div className="px-6 pb-6 border-t border-gray-100 pt-4">
                    <MarkdownRenderer content={section.content} />
                  </div>
                )}
              </div>
            ))}
          </div>

          {filteredSections.length === 0 && searchQuery && (
            <div className="text-center py-12 text-gray-500">
              <Search size={40} className="mx-auto mb-3 text-gray-300" />
              <p className="text-lg">No results found for "{searchQuery}"</p>
              <p className="text-sm mt-1">Try a different search term or check other documentation tabs</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default HelpDocumentation;
