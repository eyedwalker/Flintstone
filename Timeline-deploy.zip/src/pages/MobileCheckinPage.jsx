/**
 * Mobile Patient Check-in Page
 * Allows patients to check in from their phone when arriving at the office
 */

import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { 
  MapPin, 
  Phone, 
  Calendar, 
  Clock, 
  User, 
  CheckCircle, 
  AlertCircle,
  Loader2,
  Navigation
} from 'lucide-react';

export default function MobileCheckinPage() {
  const [searchParams] = useSearchParams();
  const appointmentId = searchParams.get('appointmentId');
  const patientPhone = searchParams.get('phone');

  const [step, setStep] = useState('verify'); // 'verify' | 'location' | 'confirm' | 'success' | 'error'
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [patientInfo, setPatientInfo] = useState(null);
  const [appointmentInfo, setAppointmentInfo] = useState(null);
  const [location, setLocation] = useState(null);
  const [verificationData, setVerificationData] = useState({
    phone: patientPhone || '',
    dateOfBirth: '',
    lastName: ''
  });

  // Get user's location
  const requestLocation = () => {
    if (!navigator.geolocation) {
      setError('Location services not supported by your device');
      return;
    }

    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy
        });
        setLoading(false);
        setStep('confirm');
      },
      (error) => {
        console.error('Location error:', error);
        setLoading(false);
        // Continue without location verification
        setStep('confirm');
      },
      { 
        enableHighAccuracy: true, 
        timeout: 10000, 
        maximumAge: 300000 
      }
    );
  };

  // Verify patient identity
  const handleVerifyPatient = async () => {
    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/checkin/verify-patient', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(verificationData)
      });

      const result = await response.json();

      if (result.success) {
        setPatientInfo(result.patient);
        setAppointmentInfo(result.appointment);
        setStep('location');
      } else {
        setError(result.message || 'Unable to verify patient information');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    }

    setLoading(false);
  };

  // Complete check-in process
  const handleCompleteCheckin = async () => {
    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/checkin/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientId: patientInfo.id,
          appointmentId: appointmentInfo?.id,
          location,
          verificationData
        })
      });

      const result = await response.json();

      if (result.success) {
        setStep('success');
      } else {
        setError(result.message || 'Check-in failed. Please see front desk staff.');
      }
    } catch (err) {
      setError('Network error. Please try again or see front desk staff.');
    }

    setLoading(false);
  };

  // Format date for display
  const formatDate = (dateStr) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Format time for display
  const formatTime = (timeStr) => {
    return new Date(`1970-01-01T${timeStr}`).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  // Render verification step
  const renderVerifyStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <User className="w-16 h-16 text-blue-600 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Welcome!</h2>
        <p className="text-gray-600">Please verify your information to check in</p>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Phone Number
          </label>
          <input
            type="tel"
            value={verificationData.phone}
            onChange={(e) => setVerificationData(prev => ({ ...prev, phone: e.target.value }))}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="(555) 123-4567"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Date of Birth
          </label>
          <input
            type="date"
            value={verificationData.dateOfBirth}
            onChange={(e) => setVerificationData(prev => ({ ...prev, dateOfBirth: e.target.value }))}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Last Name
          </label>
          <input
            type="text"
            value={verificationData.lastName}
            onChange={(e) => setVerificationData(prev => ({ ...prev, lastName: e.target.value }))}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg text-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="Smith"
          />
        </div>
      </div>

      <button
        onClick={handleVerifyPatient}
        disabled={loading || !verificationData.phone || !verificationData.dateOfBirth || !verificationData.lastName}
        className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg text-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
      >
        {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : null}
        Verify Information
      </button>
    </div>
  );

  // Render location step
  const renderLocationStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <MapPin className="w-16 h-16 text-green-600 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Almost There!</h2>
        <p className="text-gray-600">We'd like to confirm you're at our office</p>
      </div>

      <div className="bg-blue-50 rounded-lg p-4">
        <h3 className="font-semibold text-gray-900 mb-2">Patient Verified:</h3>
        <p className="text-gray-700">{patientInfo?.name}</p>
        {appointmentInfo && (
          <div className="mt-3 text-sm text-gray-600">
            <p>📅 {formatDate(appointmentInfo.date)}</p>
            <p>🕐 {formatTime(appointmentInfo.time)}</p>
            <p>👨‍⚕️ Dr. {appointmentInfo.provider}</p>
          </div>
        )}
      </div>

      <button
        onClick={requestLocation}
        disabled={loading}
        className="w-full bg-green-600 text-white py-3 px-4 rounded-lg text-lg font-medium hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
      >
        {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Navigation className="w-5 h-5" />}
        {loading ? 'Getting Location...' : 'Share Location & Continue'}
      </button>

      <button
        onClick={() => setStep('confirm')}
        className="w-full bg-gray-200 text-gray-800 py-3 px-4 rounded-lg text-lg font-medium hover:bg-gray-300"
      >
        Skip Location Check
      </button>
    </div>
  );

  // Render confirmation step
  const renderConfirmStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <CheckCircle className="w-16 h-16 text-blue-600 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Ready to Check In</h2>
        <p className="text-gray-600">Please confirm your appointment details</p>
      </div>

      <div className="bg-gray-50 rounded-lg p-4 space-y-3">
        <div className="flex items-center gap-3">
          <User className="w-5 h-5 text-gray-500" />
          <span className="font-medium">{patientInfo?.name}</span>
        </div>
        
        {appointmentInfo && (
          <>
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-gray-500" />
              <span>{formatDate(appointmentInfo.date)}</span>
            </div>
            
            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-gray-500" />
              <span>{formatTime(appointmentInfo.time)}</span>
            </div>
            
            <div className="flex items-center gap-3">
              <User className="w-5 h-5 text-gray-500" />
              <span>Dr. {appointmentInfo.provider}</span>
            </div>
          </>
        )}

        {location && (
          <div className="flex items-center gap-3 text-green-600">
            <MapPin className="w-5 h-5" />
            <span className="text-sm">Location confirmed</span>
          </div>
        )}
      </div>

      <button
        onClick={handleCompleteCheckin}
        disabled={loading}
        className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg text-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
      >
        {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle className="w-5 h-5" />}
        {loading ? 'Checking In...' : 'Complete Check-In'}
      </button>
    </div>
  );

  // Render success step
  const renderSuccessStep = () => (
    <div className="text-center space-y-6">
      <CheckCircle className="w-20 h-20 text-green-600 mx-auto" />
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Check-In Complete!</h2>
        <p className="text-gray-600 mb-4">Thank you for checking in. Our staff will be with you shortly.</p>
        
        <div className="bg-green-50 rounded-lg p-4 text-left">
          <h3 className="font-semibold text-green-900 mb-2">What's Next:</h3>
          <ul className="text-green-800 space-y-1">
            <li>• Please have a seat in the waiting area</li>
            <li>• A staff member will call you when ready</li>
            <li>• Your estimated wait time is 10-15 minutes</li>
          </ul>
        </div>
      </div>
    </div>
  );

  // Render error step
  const renderErrorStep = () => (
    <div className="text-center space-y-6">
      <AlertCircle className="w-16 h-16 text-red-600 mx-auto" />
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Check-In Error</h2>
        <p className="text-gray-600 mb-4">{error}</p>
        
        <div className="bg-yellow-50 rounded-lg p-4 text-left">
          <h3 className="font-semibold text-yellow-900 mb-2">Please:</h3>
          <ul className="text-yellow-800 space-y-1">
            <li>• Visit the front desk for assistance</li>
            <li>• Call us at (555) 123-4567</li>
            <li>• Try again in a few minutes</li>
          </ul>
        </div>
      </div>
      
      <button
        onClick={() => {
          setStep('verify');
          setError('');
        }}
        className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg text-lg font-medium hover:bg-blue-700"
      >
        Try Again
      </button>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-md mx-auto px-4 py-4">
          <div className="flex items-center justify-center">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
              <CheckCircle className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-gray-900">Mobile Check-In</h1>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto px-4 py-8">
        {error && step !== 'error' && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <p className="text-red-800">{error}</p>
            </div>
          </div>
        )}

        {step === 'verify' && renderVerifyStep()}
        {step === 'location' && renderLocationStep()}
        {step === 'confirm' && renderConfirmStep()}
        {step === 'success' && renderSuccessStep()}
        {step === 'error' && renderErrorStep()}
      </div>
    </div>
  );
}
