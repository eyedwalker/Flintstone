import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Camera, Ruler, CheckCircle, AlertCircle, Loader, CreditCard, Eye, RotateCcw, Save, ChevronRight, Zap, RotateCw, ArrowLeft, ArrowRight, ArrowUp, ArrowDown } from 'lucide-react';
import { MeasurementService } from '../../lib/services/measurement-service';
import { LiDARService } from '../../lib/services/lidar-service';
import { HeadMovementService } from '../../lib/services/head-movement-service';
import { HeadMovementGuide } from '../../components/HeadMovementGuide';
import { FaceDepthViewer } from '../../components/FaceDepthViewer';
import { LensCalibrationGuide } from '../../components/LensCalibrationGuide';

const STEPS = {
  INTRO: 'intro',
  CALIBRATION: 'calibration',
  HEAD_MOVEMENT: 'head_movement',  // New step for head movement tracking
  FACE_CAPTURE: 'face_capture',
  FRAME_ON: 'frame_on',
  RESULTS: 'results',
};

export default function Measurements() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');

  const [step, setStep] = useState(STEPS.INTRO);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [cameraReady, setCameraReady] = useState(false);

  // MediaPipe
  const [faceMeshLoaded, setFaceMeshLoaded] = useState(false);
  const [landmarks, setLandmarks] = useState(null);

  // Calibration
  const [calibration, setCalibration] = useState(null);
  const [cardMarkers, setCardMarkers] = useState({ left: null, right: null });

  // Measurements
  const [pdResult, setPdResult] = useState(null);
  const [segResult, setSegResult] = useState(null);
  const [faceGeometry, setFaceGeometry] = useState(null);
  const [faceSVG, setFaceSVG] = useState('');

  // Frame markers for seg height
  const [frameBottom, setFrameBottom] = useState(null);

  // Drag state for markers
  const [dragging, setDragging] = useState(null); // 'left', 'right', or 'frameBottom'

  // Results view tabs
  const [resultsTab, setResultsTab] = useState('measurements');
  const [depthColorScale, setDepthColorScale] = useState('rainbow');
  const [lensCalibrationStep, setLensCalibrationStep] = useState(0);
  const [lensCalibrationData, setLensCalibrationData] = useState(null);
  
  // Head alignment
  const [headAlignment, setHeadAlignment] = useState({
    isAligned: false,
    yaw: 0, // left/right rotation (-1 to 1)
    pitch: 0, // up/down tilt (-1 to 1)
    roll: 0, // head tilt (-1 to 1)
    message: 'Align your face to the camera'
  });
  
  // Head movement calibration
  const [movementSequence, setMovementSequence] = useState({
    frames: [],
    currentMovement: null,
    movementProgress: 0,
    isRecording: false,
    isComplete: false,
    referenceFrame: null
  });
  
  // Movement types for guided calibration
  const MOVEMENT_TYPES = {
    NEUTRAL: 'neutral',       // Look straight ahead
    TURN_LEFT: 'turn_left',   // Slowly turn head left
    TURN_RIGHT: 'turn_right', // Slowly turn head right
    TILT_UP: 'tilt_up',       // Tilt head up
    TILT_DOWN: 'tilt_down',   // Tilt head down
    ROLL_LEFT: 'roll_left',   // Roll head left (ear to shoulder)
    ROLL_RIGHT: 'roll_right', // Roll head right (ear to shoulder)
    NEUTRAL_FINAL: 'neutral_final' // Final neutral position
  };
  
  // LiDAR
  const [lidarAvailable, setLidarAvailable] = useState(false);
  const [lidarChecked, setLidarChecked] = useState(false);
  const [usingLidar, setUsingLidar] = useState(false);

  // Refs
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const faceMeshRef = useRef(null);
  const animationRef = useRef(null);
  const containerRefs = useRef({});

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, []);

  // Initialize MediaPipe Face Mesh
  const initFaceMesh = useCallback(async () => {
    try {
      setLoading(true);
      const { FaceMesh } = await import('@mediapipe/face_mesh');

      const faceMesh = new FaceMesh({
        locateFile: (file) => `https://unpkg.com/@mediapipe/face_mesh@0.4.1633559619/${file}`
      });

      faceMesh.setOptions({
        maxNumFaces: 1,
        refineLandmarks: true, // enables iris landmarks (468-477)
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5
      });

      faceMesh.onResults((results) => {
        faceMeshRef.current.onResults(({ multiFaceLandmarks }) => {
          if (multiFaceLandmarks?.length) {
            const lm = multiFaceLandmarks[0];
            drawLandmarks(lm);
            setLandmarks(lm);
          } else {
            // No face detected
            setHeadAlignment(prev => ({
              ...prev, 
              isAligned: false, 
              message: 'Face not detected'
            }));
          }
        });
      });

      faceMeshRef.current = faceMesh;
      setFaceMeshLoaded(true);
      setLoading(false);
      console.log('[Measurements] MediaPipe Face Mesh loaded');
    } catch (err) {
      console.error('[Measurements] Failed to load MediaPipe:', err);
      setError('Failed to load face detection. Please try again.');
      setLoading(false);
    }
  }, []);

  // Whether camera should be active (any step that needs it)
  const isCameraStep = [STEPS.CALIBRATION, STEPS.HEAD_MOVEMENT, STEPS.FACE_CAPTURE, STEPS.FRAME_ON].includes(step);

  const startCamera = async () => {
    console.log('[Measurements] startCamera called, videoRef:', !!videoRef.current);
    try {
      // Stop any existing stream first
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
        streamRef.current = null;
      }

      // Try front camera first; fall back to any camera
      let stream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } }
        });
      } catch {
        console.log('[Measurements] Front camera failed, trying any camera');
        stream = await navigator.mediaDevices.getUserMedia({ video: true });
      }

      streamRef.current = stream;
      console.log('[Measurements] Got stream, tracks:', stream.getVideoTracks().length);

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        // iOS Safari requires explicit play()
        try { await videoRef.current.play(); } catch (playErr) {
          console.warn('[Measurements] play() warning (may be fine):', playErr.message);
        }
        setCameraReady(true);
        console.log('[Measurements] Camera ready, video dimensions:', videoRef.current.videoWidth, 'x', videoRef.current.videoHeight);
      } else {
        console.error('[Measurements] videoRef.current is null after getting stream');
        setError('Camera initialized but video element not ready. Please try again.');
      }
    } catch (err) {
      console.error('[Measurements] Camera error:', err);
      if (err.name === 'NotAllowedError') {
        setError('Camera access denied. Please allow camera access in your browser settings and reload.');
      } else if (err.name === 'NotFoundError') {
        setError('No camera found on this device.');
      } else if (err.name === 'NotReadableError') {
        setError('Camera is in use by another app. Please close other apps using the camera.');
      } else {
        setError(`Camera error: ${err.message}. Make sure you're using HTTPS.`);
      }
    }
  };

  const stopCamera = () => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
      animationRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setCameraReady(false);
  };

  // Start camera when entering a camera step (video element must be mounted first)
  useEffect(() => {
    if (isCameraStep) {
      // Check if stream is alive (not null AND has active tracks)
      const streamAlive = streamRef.current && 
        streamRef.current.getVideoTracks().some(t => t.readyState === 'live');
      
      if (!streamAlive) {
        // Small delay to ensure video element is in DOM after render
        const timer = setTimeout(() => {
          console.log('[Measurements] useEffect: starting camera for step:', step);
          startCamera();
        }, 150);
        return () => clearTimeout(timer);
      }
    }
    if (!isCameraStep && streamRef.current) {
      stopCamera();
    }
  }, [step, isCameraStep]);

  // Attach stream to video element when it becomes available (handles ref changes)
  const handleVideoRef = useCallback((el) => {
    videoRef.current = el;
    if (el && streamRef.current) {
      // Always re-attach stream to new video element
      const streamAlive = streamRef.current.getVideoTracks().some(t => t.readyState === 'live');
      if (streamAlive) {
        console.log('[Measurements] Re-attaching stream to video element');
        el.srcObject = streamRef.current;
        el.play().then(() => setCameraReady(true)).catch(() => {});
      } else {
        console.log('[Measurements] Stream dead, will restart via useEffect');
        streamRef.current = null;
      }
    }
  }, []);

  const startFaceDetection = async () => {
    if (!faceMeshRef.current || !videoRef.current) {
      console.log('[Measurements] startFaceDetection: missing refs', { faceMesh: !!faceMeshRef.current, video: !!videoRef.current });
      return;
    }

    // Cancel any existing detection loop
    if (animationRef.current) cancelAnimationFrame(animationRef.current);

    const detect = async () => {
      if (videoRef.current && videoRef.current.readyState >= 2 && faceMeshRef.current) {
        try {
          await faceMeshRef.current.send({ image: videoRef.current });
        } catch (e) {
          // Silently handle frame processing errors
        }
      }
      animationRef.current = requestAnimationFrame(detect);
    };

    detect();
  };

  // Analyze head alignment based on face landmarks
  const analyzeHeadAlignment = (landmarks) => {
    if (!landmarks || landmarks.length < 468) return;
    
    // Key landmark indices
    const nose = landmarks[1]; // Nose tip
    const leftEye = landmarks[33]; // Left eye outer corner
    const rightEye = landmarks[263]; // Right eye outer corner
    const leftCheek = landmarks[50]; // Left cheek
    const rightCheek = landmarks[280]; // Right cheek
    const topHead = landmarks[10]; // Forehead
    const chin = landmarks[152]; // Chin bottom
    
    // Calculate alignment metrics with SIGNED values
    // 1. Yaw (left-right rotation) - SIGNED: negative = left, positive = right
    const leftDist = leftEye.x - nose.x;
    const rightDist = nose.x - rightEye.x;
    const yawRaw = (leftDist - rightDist) / (leftEye.x - rightEye.x);
    const yaw = Math.max(-1, Math.min(1, yawRaw * 2)); // Clamp to [-1, 1]
    
    // 2. Pitch (up-down tilt) - SIGNED: negative = down, positive = up
    const eyesY = (leftEye.y + rightEye.y) / 2;
    const eyeNoseRatio = (nose.y - eyesY) / (chin.y - topHead.y);
    const pitch = Math.max(-1, Math.min(1, (eyeNoseRatio - 0.28) * 5));
    
    // 3. Roll (head tilt) - SIGNED: negative = right ear down, positive = left ear down
    const rollRaw = (leftEye.y - rightEye.y) / (leftEye.x - rightEye.x);
    const roll = Math.max(-1, Math.min(1, rollRaw * 2));
    
    // Combined score for alignment check
    const threshold = 0.15;
    const isAligned = Math.abs(yaw) < threshold && Math.abs(pitch) < threshold && Math.abs(roll) < threshold;
    
    // Generate guidance message
    let message = 'Perfect! Hold still';
    if (!isAligned) {
      if (Math.abs(yaw) >= threshold) message = yaw < 0 ? 'Turn slightly right' : 'Turn slightly left';
      else if (Math.abs(pitch) >= threshold) message = pitch > 0 ? 'Tilt your head down' : 'Tilt your head up';
      else if (Math.abs(roll) >= threshold) message = roll > 0 ? 'Level your head (tilt right)' : 'Level your head (tilt left)';
    }
    
    setHeadAlignment({
      isAligned,
      yaw,
      pitch,
      roll,
      message
    });
  };

  const drawLandmarks = (lm) => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video) return;

    const ctx = canvas.getContext('2d');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Analyze head alignment
    analyzeHeadAlignment(lm);

    // Draw face mesh (light wireframe)
    ctx.strokeStyle = 'rgba(74, 144, 217, 0.3)';
    ctx.lineWidth = 0.5;

    // Draw face oval
    const faceOval = [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109];
    ctx.beginPath();
    ctx.strokeStyle = 'rgba(74, 144, 217, 0.6)';
    ctx.lineWidth = 2;
    faceOval.forEach((idx, i) => {
      const x = lm[idx].x * canvas.width;
      const y = lm[idx].y * canvas.height;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.closePath();
    ctx.stroke();

    // Draw iris circles if available
    if (lm.length > 468) {
      // Left iris
      const leftIris = lm[468];
      ctx.beginPath();
      ctx.arc(leftIris.x * canvas.width, leftIris.y * canvas.height, 8, 0, 2 * Math.PI);
      ctx.strokeStyle = '#e74c3c';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(leftIris.x * canvas.width, leftIris.y * canvas.height, 2, 0, 2 * Math.PI);
      ctx.fillStyle = '#e74c3c';
      ctx.fill();

      // Right iris
      const rightIris = lm[473];
      ctx.beginPath();
      ctx.arc(rightIris.x * canvas.width, rightIris.y * canvas.height, 8, 0, 2 * Math.PI);
      ctx.strokeStyle = '#e74c3c';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(rightIris.x * canvas.width, rightIris.y * canvas.height, 2, 0, 2 * Math.PI);
      ctx.fillStyle = '#e74c3c';
      ctx.fill();

      // PD line
      ctx.beginPath();
      ctx.moveTo(leftIris.x * canvas.width, leftIris.y * canvas.height);
      ctx.lineTo(rightIris.x * canvas.width, rightIris.y * canvas.height);
      ctx.strokeStyle = 'rgba(231, 76, 60, 0.5)';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Draw nose bridge
    const nose = lm[6];
    ctx.beginPath();
    ctx.arc(nose.x * canvas.width, nose.y * canvas.height, 3, 0, 2 * Math.PI);
    ctx.fillStyle = '#2ecc71';
    ctx.fill();

    // Draw frame bottom marker if set
    if (frameBottom !== null) {
      ctx.beginPath();
      ctx.moveTo(0, frameBottom * canvas.height);
      ctx.lineTo(canvas.width, frameBottom * canvas.height);
      ctx.strokeStyle = '#f39c12';
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  };

  // Handle canvas click for frame bottom marker (tap to place)
  const handleCanvasClick = (e) => {
    if (step !== STEPS.FRAME_ON) return;
    if (dragging) return; // Don't place on drag end

    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const y = (e.clientY - rect.top) / rect.height;
    setFrameBottom(y);
  };

  // Handle calibration card marker placement (tap to place)
  const handleCalibrationClick = (e) => {
    if (step !== STEPS.CALIBRATION) return;
    if (dragging) return; // Don't place on drag end

    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;

    if (!cardMarkers.left) {
      setCardMarkers({ left: x, right: null });
    } else if (!cardMarkers.right) {
      const newMarkers = { ...cardMarkers, right: x };
      setCardMarkers(newMarkers);
      recalibrate(newMarkers);
    }
  };

  // Recalibrate after marker move
  const recalibrate = (markers) => {
    if (!markers.left || !markers.right) return;
    const video = videoRef.current;
    if (!video) return;
    const cal = MeasurementService.calibrateWithCreditCard(
      (1 - markers.left) * video.videoWidth,
      (1 - markers.right) * video.videoWidth,
      video.videoWidth
    );
    setCalibration(cal);
  };

  // --- Drag helpers for marker lines (touch + mouse) ---
  const getClientPos = (e) => {
    if (e.touches && e.touches.length > 0) {
      return { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
    return { x: e.clientX, y: e.clientY };
  };

  const startMovementRecording = () => {
    setMovementSequence(prev => ({
      ...prev,
      isRecording: true,
      currentMovement: MOVEMENT_TYPES.NEUTRAL,
      frames: []
    }));
    console.log('[Measurements] Started head movement recording');
  };

  const handleMovementComplete = (movementType) => {
    // Get the next movement in sequence
    let nextMovement = null;
    
    switch(movementType) {
      case MOVEMENT_TYPES.NEUTRAL:
        nextMovement = MOVEMENT_TYPES.TURN_LEFT;
        break;
      case MOVEMENT_TYPES.TURN_LEFT:
        nextMovement = MOVEMENT_TYPES.NEUTRAL;
        setTimeout(() => {
          setMovementSequence(prev => ({ ...prev, currentMovement: MOVEMENT_TYPES.TURN_RIGHT }));
        }, 1000);
        break;
      case MOVEMENT_TYPES.TURN_RIGHT:
        nextMovement = MOVEMENT_TYPES.NEUTRAL;
        setTimeout(() => {
          setMovementSequence(prev => ({ ...prev, currentMovement: MOVEMENT_TYPES.TILT_UP }));
        }, 1000);
        break;
      case MOVEMENT_TYPES.TILT_UP:
        nextMovement = MOVEMENT_TYPES.NEUTRAL;
        setTimeout(() => {
          setMovementSequence(prev => ({ ...prev, currentMovement: MOVEMENT_TYPES.TILT_DOWN }));
        }, 1000);
        break;
      case MOVEMENT_TYPES.TILT_DOWN:
        nextMovement = MOVEMENT_TYPES.NEUTRAL;
        setTimeout(() => {
          setMovementSequence(prev => ({ ...prev, currentMovement: MOVEMENT_TYPES.ROLL_LEFT }));
        }, 1000);
        break;
      case MOVEMENT_TYPES.ROLL_LEFT:
        nextMovement = MOVEMENT_TYPES.NEUTRAL;
        setTimeout(() => {
          setMovementSequence(prev => ({ ...prev, currentMovement: MOVEMENT_TYPES.ROLL_RIGHT }));
        }, 1000);
        break;
      case MOVEMENT_TYPES.ROLL_RIGHT:
        nextMovement = MOVEMENT_TYPES.NEUTRAL_FINAL;
        break;
      case MOVEMENT_TYPES.NEUTRAL_FINAL:
        // Final movement completed
        nextMovement = null;
        finishMovementRecording();
        break;
      default:
        nextMovement = MOVEMENT_TYPES.NEUTRAL;
    }
    
    setMovementSequence(prev => ({ ...prev, currentMovement: nextMovement }));
  };

  const finishMovementRecording = () => {
    setMovementSequence(prev => {
      // Process the collected frames to extract depth data
      const depthData = HeadMovementService.calculateDepthMap(prev);
      
      return {
        ...prev,
        isRecording: false,
        isComplete: true,
        depthMap: depthData?.depthMap || null,
        referenceFrame: depthData?.referenceFrame || null
      };
    });
    
    // Proceed to next step
    setStep(STEPS.FACE_CAPTURE);
  };
  
  // Record frame in sequence if recording is active
  useEffect(() => {
    if (step !== STEPS.HEAD_MOVEMENT || !landmarks || !movementSequence.isRecording) return;
    
    // Record at most 5 frames per second to avoid excessive data
    const now = Date.now();
    const lastFrame = movementSequence.frames[movementSequence.frames.length - 1];
    if (lastFrame && now - lastFrame.timestamp < 200) return; // 5 FPS max
    
    // Record the current frame with movement type
    const updatedSequence = HeadMovementService.recordFrame(
      landmarks,
      movementSequence,
      movementSequence.currentMovement
    );
    
    setMovementSequence(updatedSequence);
  }, [landmarks, step, movementSequence]);

  const handleMarkerDragStart = (markerType) => (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragging(markerType);

    const onMove = (moveEvt) => {
      moveEvt.preventDefault();
      const pos = getClientPos(moveEvt);
      const container = containerRefs.current[step];
      if (!container) return;
      const rect = container.getBoundingClientRect();

      if (markerType === 'left' || markerType === 'right') {
        const x = Math.max(0, Math.min(1, (pos.x - rect.left) / rect.width));
        setCardMarkers(prev => ({ ...prev, [markerType]: x }));
      } else if (markerType === 'frameBottom') {
        const y = Math.max(0, Math.min(1, (pos.y - rect.top) / rect.height));
        setFrameBottom(y);
      }
    };

    const onEnd = () => {
      setDragging(null);
      // Recalibrate after drag ends
      if (markerType === 'left' || markerType === 'right') {
        // Use a small timeout to get latest state
        setTimeout(() => {
          setCardMarkers(current => {
            if (current.left && current.right) recalibrate(current);
            return current;
          });
        }, 50);
      }
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onEnd);
      document.removeEventListener('touchmove', onMove, { passive: false });
      document.removeEventListener('touchend', onEnd);
    };

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onEnd);
    document.addEventListener('touchmove', onMove, { passive: false });
    document.addEventListener('touchend', onEnd);
  };

  // Calculate PD with optional 3D enhancement
  const calculatePD = () => {
    if (!landmarks || !calibration) return;

    const video = videoRef.current;
    if (!video) return;

    const w = video.videoWidth;
    const h = video.videoHeight;

    // Check if we have 3D depth data from head movement
    if (movementSequence?.has3dData && movementSequence.depthMap) {
      // Use enhanced PD calculation with depth data
      const enhancedPD = HeadMovementService.calculateEnhancedPD(
        landmarks,
        movementSequence.depthMap,
        calibration.pixelsPerMm
      );
      if (enhancedPD) {
        setPdResult(enhancedPD);
        
        // Also calculate face geometry
        const geo = MeasurementService.extractFaceGeometry(landmarks, calibration, w, h);
        setFaceGeometry(geo);
        
        // Generate SVG
        const svg = MeasurementService.generateFaceSVG(geo);
        setFaceSVG(svg);
        
        return;
      }
    }

    // Fallback to standard PD calculation
    const pd = MeasurementService.calculatePD(landmarks, calibration, w, h);
    setPdResult(pd);

    // Calculate face geometry
    const geo = MeasurementService.extractFaceGeometry(landmarks, calibration, w, h);
    setFaceGeometry(geo);

    // Generate SVG
    const svg = MeasurementService.generateFaceSVG(geo);
    setFaceSVG(svg);
  };

  // Calculate all measurements
  const calculateMeasurements = () => {
    if (!landmarks || !calibration) return;

    const video = videoRef.current;
    if (!video) return;

    const w = video.videoWidth;
    const h = video.videoHeight;

    // Calculate PD
    const pd = MeasurementService.calculatePD(landmarks, calibration, w, h);
    setPdResult(pd);

    // Calculate face geometry
    const geo = MeasurementService.extractFaceGeometry(landmarks, calibration, w, h);
    setFaceGeometry(geo);

    // Generate SVG
    const svg = MeasurementService.generateFaceSVG(geo);
    setFaceSVG(svg);

    // Calculate seg height if frame markers set
    if (frameBottom !== null) {
      const seg = MeasurementService.calculateSegHeight(landmarks, frameBottom, calibration, w, h);
      setSegResult(seg);
    }
  };

  // Auto-calibrate with iris (no credit card needed)
  const autoCalibrate = () => {
    if (!landmarks) return;
    const video = videoRef.current;
    if (!video) return;

    const cal = MeasurementService.calibrateWithIris(landmarks, video.videoWidth);
    setCalibration(cal);
    setStep(STEPS.HEAD_MOVEMENT);
  };

  // Save measurements to server
  const handleLensCalibrationComplete = (data) => {
    setLensCalibrationData(data);
    setLensCalibrationStep(0); // Reset step to hide camera
    setCameraReady(false); // Turn off camera
    
    // Show success notification
    setToastMessage('Lens calibration completed successfully');
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  const saveMeasurements = async () => {
    if (saving) return;
    setSaving(true);

    try {
      const response = await fetch('/api/patient/measurements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          pd_total: pdResult.pdTotal,
          pd_right: pdResult.pdRight,
          pd_left: pdResult.pdLeft,
          seg_height_right: segResult?.segHeightRight,
          seg_height_left: segResult?.segHeightLeft,
          oc_height_right: segResult?.ocHeightRight,
          oc_height_left: segResult?.ocHeightLeft,
          measurement_method: pdResult.method,
          confidence_score: pdResult.confidence,
          face_geometry: faceGeometry,
          face_svg: faceSVG,
          calibration_factor: calibration?.pixelsPerMm,
          has_lidar: usingLidar,
          device_type: navigator.userAgent,
          face_landmarks: landmarks ? {
            leftIris: landmarks[468],
            rightIris: landmarks[473],
            noseBridge: landmarks[6],
            faceOvalSample: [landmarks[10], landmarks[152], landmarks[234], landmarks[454]]
          } : null,
          movement_sequence: movementSequence?.has3dData ? {
            depthMap: movementSequence.depthMap,
            referenceFrame: movementSequence.referenceFrame,
            has3dData: movementSequence.has3dData,
            frameCount: movementSequence.frames?.length || 0
          } : null
        })
      });

      const data = await response.json();
      if (data.success) {
        setStep(STEPS.RESULTS);
      } else {
        setError(data.error || 'Failed to save measurements');
      }
    } catch (err) {
      setError('Network error - please try again');
    } finally {
      setLoading(false);
    }
  };

  // Token validation
  if (!token) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-lg p-8 max-w-md text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Invalid Link</h1>
          <p className="text-gray-600">
            This link is invalid or has expired. Please request a new link from your eye care provider.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-indigo-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Ruler size={28} />
            Lens Measurements
          </h1>
          <p className="text-indigo-100 text-sm mt-1">
            Take accurate measurements for your new glasses
          </p>
        </div>
      </div>

      {/* Progress bar */}
      {/* Toast notification */}
      {showToast && (
        <div className="fixed top-4 right-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg shadow-lg z-50 flex items-center gap-2 animate-fadeIn">
          <CheckCircle size={18} />
          {toastMessage}
        </div>
      )}
      
      <div className="max-w-4xl mx-auto px-4 pt-4">
        <div className="flex items-center gap-2 mb-6">
          {[STEPS.INTRO, STEPS.CALIBRATION, STEPS.HEAD_MOVEMENT, STEPS.FACE_CAPTURE, STEPS.FRAME_ON, STEPS.RESULTS].map((s, i) => (
            <React.Fragment key={s}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                step === s ? 'bg-indigo-600 text-white' :
                Object.values(STEPS).indexOf(step) > i ? 'bg-green-500 text-white' :
                'bg-gray-200 text-gray-500'
              }`}>
                {Object.values(STEPS).indexOf(step) > i ? <CheckCircle size={16} /> : i + 1}
              </div>
              {i < 5 && <div className={`flex-1 h-1 ${
                Object.values(STEPS).indexOf(step) > i ? 'bg-green-500' : 'bg-gray-200'
              }`} />}
            </React.Fragment>
          ))}
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4">
        {error && (
          <div className="mb-4 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-red-800 text-sm">{error}</p>
            <button onClick={() => setError('')} className="ml-auto text-red-600 hover:text-red-800">&times;</button>
          </div>
        )}

        {/* Step 1: Intro */}
        {step === STEPS.INTRO && (
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <Eye className="w-20 h-20 text-indigo-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Let's Take Your Measurements
            </h2>
            <div className="text-left max-w-md mx-auto mb-8">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-indigo-600 font-bold text-sm">1</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Calibration</h3>
                    <p className="text-gray-600 text-sm">Hold a credit card next to your face for scale, or use auto-calibrate</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-indigo-600 font-bold text-sm">2</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Head Movement</h3>
                    <p className="text-gray-600 text-sm">Follow the guided movements to help build a 3D model of your face</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-indigo-600 font-bold text-sm">3</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Face Scan</h3>
                    <p className="text-gray-600 text-sm">We'll detect your facial landmarks and measure your pupil distance</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-indigo-600 font-bold text-sm">4</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Frame Measurements</h3>
                    <p className="text-gray-600 text-sm">Put on your frames and we'll measure seg height and OC height</p>
                  </div>
                </div>
              </div>
            </div>
            <p className="text-gray-500 text-xs mb-6">
              We create a geometric representation of your face shape - no photos are stored.
            </p>

            {/* LiDAR detection badge */}
            {lidarChecked && (
              <div className={`mb-4 inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium ${
                lidarAvailable ? 'bg-green-100 text-green-800 border border-green-300' : 'bg-gray-100 text-gray-600 border border-gray-200'
              }`}>
                <Zap size={16} className={lidarAvailable ? 'text-green-600' : 'text-gray-400'} />
                {lidarAvailable ? 'LiDAR Enhanced Mode Available' : 'Standard Camera Mode'}
              </div>
            )}

            <button
              onClick={async () => {
                // Check for LiDAR first
                if (!lidarChecked) {
                  try {
                    const capabilities = await LiDARService.detectLiDAR();
                    setLidarAvailable(capabilities.available);
                    setLidarChecked(true);
                    if (capabilities.available) {
                      setUsingLidar(true);
                      console.log('[Measurements] LiDAR detected:', capabilities.deviceModel);
                    }
                  } catch {
                    setLidarChecked(true);
                  }
                }
                await initFaceMesh();
                // Camera starts via useEffect when step changes to CALIBRATION
                setStep(STEPS.CALIBRATION);
              }}
              disabled={loading}
              className="px-8 py-3 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center gap-2 mx-auto"
            >
              {loading ? <Loader className="animate-spin" size={20} /> : <Camera size={20} />}
              {loading ? 'Loading...' : 'Start Measurements'}
            </button>
          </div>
        )}

        {/* Step 2: Calibration */}
        {step === STEPS.CALIBRATION && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <CreditCard size={24} />
              Calibration
            </h2>

            <div className="relative mb-4" ref={el => { containerRefs.current[STEPS.CALIBRATION] = el; }}>
              <video
                ref={handleVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full rounded-lg bg-black min-h-[240px]"
                style={{ transform: 'scaleX(-1)' }}
                onLoadedData={() => startFaceDetection()}
                onPlay={() => { setCameraReady(true); console.log('[Measurements] Video playing'); }}
              />
              <canvas
                ref={canvasRef}
                className="absolute top-0 left-0 w-full h-full"
                style={{ transform: 'scaleX(-1)' }}
                onClick={handleCalibrationClick}
              />
              
              {/* Head alignment indicator */}
              {landmarks && (
                <div className="absolute top-4 right-4 flex items-center gap-2 px-3 py-2 rounded-lg bg-black bg-opacity-70">
                  <div 
                    className={`w-3 h-3 rounded-full flex-shrink-0 ${headAlignment.isAligned ? 'bg-green-500' : 'bg-red-500'}`} 
                  />
                  <span className="text-white text-sm">{headAlignment.message}</span>
                </div>
              )}
              
              {!cameraReady && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-900 rounded-lg">
                  <div className="text-center text-white">
                    <Loader className="animate-spin mx-auto mb-2" size={32} />
                    <p className="text-sm">Starting camera...</p>
                    <p className="text-xs text-gray-400 mt-1">Allow camera access if prompted</p>
                  </div>
                </div>
              )}

              {/* Draggable calibration markers */}
              {cardMarkers.left != null && (
                <div
                  className="absolute top-0 bottom-0"
                  style={{ left: `${cardMarkers.left * 100}%`, width: '2px' }}
                >
                  <div className="absolute inset-0 bg-green-500" />
                  <div
                    className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 bg-green-500 bg-opacity-80 rounded-full border-2 border-white shadow-lg cursor-grab active:cursor-grabbing flex items-center justify-center touch-none"
                    onMouseDown={handleMarkerDragStart('left')}
                    onTouchStart={handleMarkerDragStart('left')}
                  >
                    <span className="text-white text-xs font-bold">L</span>
                  </div>
                </div>
              )}
              {cardMarkers.right != null && (
                <div
                  className="absolute top-0 bottom-0"
                  style={{ left: `${cardMarkers.right * 100}%`, width: '2px' }}
                >
                  <div className="absolute inset-0 bg-green-500" />
                  <div
                    className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 bg-green-500 bg-opacity-80 rounded-full border-2 border-white shadow-lg cursor-grab active:cursor-grabbing flex items-center justify-center touch-none"
                    onMouseDown={handleMarkerDragStart('right')}
                    onTouchStart={handleMarkerDragStart('right')}
                  >
                    <span className="text-white text-xs font-bold">R</span>
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold text-blue-900 mb-2">Option A: Credit Card Calibration</h3>
                <p className="text-blue-800 text-sm mb-2">
                  Hold a credit card next to your face at eye level. Tap the left edge, then the right edge of the card.
                </p>
                {cardMarkers.left && !cardMarkers.right && (
                  <p className="text-blue-600 text-sm font-semibold">Left edge marked. Now tap the right edge.</p>
                )}
                {calibration && (
                  <p className="text-green-600 text-sm font-semibold flex items-center gap-1">
                    <CheckCircle size={16} /> Calibrated: {calibration.pixelsPerMm.toFixed(1)} px/mm
                  </p>
                )}
                {(cardMarkers.left || cardMarkers.right) && (
                  <button
                    onClick={() => { setCardMarkers({ left: null, right: null }); setCalibration(null); }}
                    className="mt-2 text-sm text-blue-600 hover:underline flex items-center gap-1"
                  >
                    <RotateCcw size={14} /> Reset markers
                  </button>
                )}
              </div>

              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <h3 className="font-semibold text-purple-900 mb-2">Option B: Auto-Calibrate</h3>
                <p className="text-purple-800 text-sm mb-2">
                  Uses your iris diameter for calibration. Less accurate but no reference object needed.
                </p>
                <button
                  onClick={autoCalibrate}
                  disabled={!landmarks}
                  className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm hover:bg-purple-700 disabled:opacity-50"
                >
                  {landmarks ? 'Auto-Calibrate with Iris' : 'Waiting for face detection...'}
                </button>
              </div>

              {calibration && (
                <button
                  onClick={() => setStep(STEPS.HEAD_MOVEMENT)}
                  className="w-full px-6 py-3 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 flex items-center justify-center gap-2"
                >
                  Next: Head Movement <RotateCcw size={20} className="ml-1" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Step 3: Head Movement Calibration */}
        {step === STEPS.HEAD_MOVEMENT && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <RotateCcw size={24} />
              Head Movement Calibration
            </h2>
            <p className="text-gray-600 mb-4">
              Follow the instructions to help us build a 3D model of your face shape.
              Move your head slowly as guided to improve measurement accuracy.
            </p>

            <div className="relative mb-4" ref={el => { containerRefs.current[STEPS.HEAD_MOVEMENT] = el; }}>
              <video
                ref={handleVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full rounded-lg bg-black min-h-[240px]"
                style={{ transform: 'scaleX(-1)' }}
                onLoadedData={() => startFaceDetection()}
                onPlay={() => setCameraReady(true)}
              />
              <canvas
                ref={canvasRef}
                className="absolute top-0 left-0 w-full h-full"
                style={{ transform: 'scaleX(-1)' }}
              />
              
              {/* Head alignment indicator */}
              {landmarks && (
                <div className="absolute top-4 right-4 flex items-center gap-2 px-3 py-2 rounded-lg bg-black bg-opacity-70">
                  <div 
                    className={`w-3 h-3 rounded-full flex-shrink-0 ${headAlignment.isAligned ? 'bg-green-500' : 'bg-red-500'}`} 
                  />
                  <span className="text-white text-sm">{headAlignment.message}</span>
                </div>
              )}
              
              {!cameraReady && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-900 rounded-lg">
                  <div className="text-center text-white">
                    <Loader className="animate-spin mx-auto mb-2" size={32} />
                    <p className="text-sm">Starting camera...</p>
                  </div>
                </div>
              )}
            </div>

            {/* Head movement guide */}
            {cameraReady && (
              <div className="mb-4">
                <HeadMovementGuide 
                  currentMovement={movementSequence.currentMovement}
                  headPose={headAlignment}
                  targetPose={
                    movementSequence.currentMovement ? 
                      { 
                        yaw: movementSequence.currentMovement.includes('left') ? 0.3 : 
                             movementSequence.currentMovement.includes('right') ? -0.3 : 0,
                        pitch: movementSequence.currentMovement.includes('up') ? -0.2 :
                               movementSequence.currentMovement.includes('down') ? 0.2 : 0,
                        roll: movementSequence.currentMovement.includes('roll_left') ? 0.15 :
                              movementSequence.currentMovement.includes('roll_right') ? -0.15 : 0
                      } : { yaw: 0, pitch: 0, roll: 0 }
                  }
                  onMovementComplete={handleMovementComplete}
                  isRecording={movementSequence.isRecording}
                />
              </div>
            )}

            <div className="flex justify-between">
              <button
                onClick={() => setStep(STEPS.CALIBRATION)}
                className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg font-medium hover:bg-gray-300 transition-colors"
              >
                <ChevronRight className="rotate-180 mr-1 inline" size={18} /> Back
              </button>
              
              <button
                onClick={() => {
                  if (movementSequence.isRecording) {
                    // Stop recording
                    setMovementSequence(prev => ({ ...prev, isRecording: false }));
                  } else if (movementSequence.isComplete) {
                    // Skip to next step
                    setStep(STEPS.FACE_CAPTURE);
                  } else {
                    // Start recording
                    startMovementRecording();
                  }
                }}
                className={`px-6 py-2 rounded-lg font-medium transition-colors flex items-center gap-2 ${
                  movementSequence.isRecording ? 
                    'bg-red-500 hover:bg-red-600 text-white' : 
                    movementSequence.isComplete ?
                      'bg-green-500 hover:bg-green-600 text-white' :
                      'bg-blue-600 hover:bg-blue-700 text-white'
                }`}
              >
                {movementSequence.isRecording ? (
                  <>
                    <Loader className="animate-spin" size={18} />
                    Recording...
                  </>
                ) : movementSequence.isComplete ? (
                  <>
                    <ChevronRight size={18} />
                    Continue
                  </>
                ) : (
                  <>
                    <RotateCcw size={18} />
                    Start Head Calibration
                  </>
                )}
              </button>

              {segResult && (
                <div className="absolute top-4 left-4 bg-black bg-opacity-70 text-white px-4 py-2 rounded-lg">
                  <p className="text-sm font-bold">Seg Height</p>
                  <p className="text-xs">R: {segResult.segHeightRight}mm / L: {segResult.segHeightLeft}mm</p>
                  <p className="text-sm font-bold mt-1">OC Height</p>
                  <p className="text-xs">R: {segResult.ocHeightRight}mm / L: {segResult.ocHeightLeft}mm</p>
                </div>
              )}
            </div>

            <div className="flex gap-3">
              {frameBottom !== null && (
                <button
                  onClick={() => {
                    calculateMeasurements();
                  }}
                  className="flex-1 px-6 py-3 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 flex items-center justify-center gap-2"
                >
                  <Ruler size={20} /> Calculate
                </button>
              )}

              <button
                onClick={() => { setFrameBottom(null); setSegResult(null); }}
                className="px-4 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 flex items-center gap-2"
              >
                <RotateCcw size={18} /> Reset
              </button>

              <button
                onClick={() => {
                  saveMeasurements();
                }}
                disabled={!pdResult || loading}
                className="flex-1 px-6 py-3 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-700 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? <Loader className="animate-spin" size={20} /> : <Save size={20} />}
                Save & View Results
              </button>
            </div>

            <p className="text-gray-400 text-xs mt-3 text-center">
              You can skip frame measurements and save just PD.
            </p>
          </div>
        )}

        {/* Step 4: Face Capture - Measure PD */}
        {step === STEPS.FACE_CAPTURE && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Eye size={24} />
              Face Scan - Measure PD
            </h2>
            <p className="text-gray-600 mb-4">
              Look directly at the camera. We'll measure your pupil distance (PD) and capture your face geometry.
            </p>

            <div className="relative mb-4" ref={el => { containerRefs.current[STEPS.FACE_CAPTURE] = el; }}>
              <video
                ref={handleVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full rounded-lg bg-black min-h-[240px]"
                style={{ transform: 'scaleX(-1)' }}
                onLoadedData={() => startFaceDetection()}
                onPlay={() => setCameraReady(true)}
              />
              <canvas
                ref={canvasRef}
                className="absolute top-0 left-0 w-full h-full"
                style={{ transform: 'scaleX(-1)' }}
              />
              
              {landmarks && (
                <div className="absolute top-4 right-4 flex items-center gap-2 px-3 py-2 rounded-lg bg-black bg-opacity-70">
                  <div 
                    className={`w-3 h-3 rounded-full flex-shrink-0 ${headAlignment.isAligned ? 'bg-green-500' : 'bg-red-500'}`} 
                  />
                  <span className="text-white text-sm">{headAlignment.message}</span>
                </div>
              )}
              
              {!cameraReady && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-900 rounded-lg">
                  <div className="text-center text-white">
                    <Loader className="animate-spin mx-auto mb-2" size={32} />
                    <p className="text-sm">Starting camera...</p>
                  </div>
                </div>
              )}

              {pdResult && (
                <div className="absolute top-4 left-4 bg-green-500 bg-opacity-90 text-white px-4 py-2 rounded-lg">
                  <p className="text-sm font-bold">PD Captured!</p>
                  <p className="text-xs">Total: {pdResult.pdTotal}mm</p>
                  <p className="text-xs">R: {pdResult.pdRight}mm / L: {pdResult.pdLeft}mm</p>
                  <p className="text-xs mt-1">{(pdResult.confidence * 100).toFixed(0)}% confidence</p>
                </div>
              )}
            </div>

            <div className="flex justify-between">
              <button
                onClick={() => setStep(STEPS.HEAD_MOVEMENT)}
                className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg font-medium hover:bg-gray-300 transition-colors"
              >
                <ChevronRight className="rotate-180 mr-1 inline" size={18} /> Back
              </button>
              
              {!pdResult && (
                <button
                  onClick={() => {
                    if (landmarks && calibration) {
                      calculatePD();
                    }
                  }}
                  disabled={!landmarks || !calibration || !headAlignment.isAligned}
                  className="px-6 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-2"
                >
                  <Eye size={18} />
                  Capture PD
                </button>
              )}

              {pdResult && (
                <button
                  onClick={() => setStep(STEPS.FRAME_ON)}
                  className="px-6 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 flex items-center gap-2"
                >
                  Next: Frame Measurements
                  <ChevronRight size={18} />
                </button>
              )}
            </div>

            <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h3 className="font-semibold text-blue-900 mb-2">Tips for Best Results</h3>
              <ul className="text-blue-800 text-sm space-y-1">
                <li>• Look directly at the camera</li>
                <li>• Keep your head centered and aligned</li>
                <li>• Ensure good lighting on your face</li>
                <li>• Remove glasses for this measurement</li>
              </ul>
            </div>
          </div>
        )}

        {/* Step 5: Frame On */}
        {step === STEPS.FRAME_ON && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Ruler size={24} />
              Frame Measurements
            </h2>
            <p className="text-gray-600 mb-4">
              Put on your glasses/frames. Tap the screen at the bottom edge of the frame to mark the seg height.
            </p>

            <div className="relative mb-4" ref={el => { containerRefs.current[STEPS.FRAME_ON] = el; }}>
              <video
                ref={handleVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full rounded-lg bg-black min-h-[240px]"
                style={{ transform: 'scaleX(-1)' }}
                onLoadedData={() => startFaceDetection()}
                onPlay={() => setCameraReady(true)}
              />
              <canvas
                ref={canvasRef}
                className="absolute top-0 left-0 w-full h-full"
                style={{ transform: 'scaleX(-1)' }}
                onClick={handleCanvasClick}
              />
              
              {landmarks && (
                <div className="absolute top-4 right-4 flex items-center gap-2 px-3 py-2 rounded-lg bg-black bg-opacity-70">
                  <div 
                    className={`w-3 h-3 rounded-full flex-shrink-0 ${headAlignment.isAligned ? 'bg-green-500' : 'bg-red-500'}`} 
                  />
                  <span className="text-white text-sm">{headAlignment.message}</span>
                </div>
              )}
              
              {!cameraReady && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-900 rounded-lg">
                  <div className="text-center text-white">
                    <Loader className="animate-spin mx-auto mb-2" size={32} />
                    <p className="text-sm">Starting camera...</p>
                  </div>
                </div>
              )}

              {frameBottom !== null && (
                <div
                  className="absolute left-0 right-0"
                  style={{ top: `${frameBottom * 100}%`, height: '2px' }}
                >
                  <div className="absolute inset-0 bg-orange-500" />
                  <div
                    className="absolute left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-orange-500 bg-opacity-80 rounded-full border-2 border-white shadow-lg cursor-grab active:cursor-grabbing flex items-center justify-center touch-none"
                    onMouseDown={handleMarkerDragStart('frameBottom')}
                    onTouchStart={handleMarkerDragStart('frameBottom')}
                  >
                    <span className="text-white text-xs font-bold">B</span>
                  </div>
                </div>
              )}

              {segResult && (
                <div className="absolute top-4 left-4 bg-black bg-opacity-70 text-white px-4 py-2 rounded-lg">
                  <p className="text-sm font-bold">Seg Height</p>
                  <p className="text-xs">R: {segResult.segHeightRight}mm / L: {segResult.segHeightLeft}mm</p>
                  <p className="text-sm font-bold mt-1">OC Height</p>
                  <p className="text-xs">R: {segResult.ocHeightRight}mm / L: {segResult.ocHeightLeft}mm</p>
                </div>
              )}
            </div>

            <div className="flex gap-3">
              {frameBottom !== null && (
                <button
                  onClick={() => {
                    calculateMeasurements();
                  }}
                  className="flex-1 px-6 py-3 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 flex items-center justify-center gap-2"
                >
                  <Ruler size={20} /> Calculate
                </button>
              )}

              <button
                onClick={() => { setFrameBottom(null); setSegResult(null); }}
                className="px-4 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 flex items-center gap-2"
              >
                <RotateCcw size={18} /> Reset
              </button>

              <button
                onClick={() => {
                  saveMeasurements();
                }}
                disabled={!pdResult || loading}
                className="flex-1 px-6 py-3 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-700 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? <Loader className="animate-spin" size={20} /> : <Save size={20} />}
                Save & View Results
              </button>
            </div>

            <p className="text-gray-400 text-xs mt-3 text-center">
              You can skip frame measurements and save just PD.
            </p>
          </div>
        )}

        {/* Step 6: Results */}
        {step === STEPS.RESULTS && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="text-center mb-6">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-3" />
              <h2 className="text-2xl font-bold text-gray-900">Measurements Complete!</h2>
              <p className="text-gray-600">Your measurements have been sent to your eye care provider.</p>
            </div>

            {/* Face geometry SVG */}
            {faceSVG && (
              <div className="flex justify-center mb-6">
                <div
                  className="border border-gray-200 rounded-lg p-4 bg-gray-50"
                  dangerouslySetInnerHTML={{ __html: faceSVG }}
                  style={{ width: 220, height: 300 }}
                />
              </div>
            )}

            {/* Measurement cards */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              {pdResult && (
                <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
                  <h3 className="font-bold text-indigo-900 mb-2">Pupil Distance</h3>
                  <p className="text-3xl font-bold text-indigo-600">{pdResult.pdTotal}mm</p>
                  <p className="text-sm text-indigo-700">R: {pdResult.pdRight}mm / L: {pdResult.pdLeft}mm</p>
                  <div className="mt-2 flex items-center gap-1">
                    <div className={`w-2 h-2 rounded-full ${pdResult.confidence > 0.8 ? 'bg-green-500' : pdResult.confidence > 0.6 ? 'bg-yellow-500' : 'bg-red-500'}`} />
                    <span className="text-xs text-gray-600">
                      {(pdResult.confidence * 100).toFixed(0)}% confidence
                    </span>
                  </div>
                </div>
              )}

              {segResult && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h3 className="font-bold text-green-900 mb-2">Seg Height</h3>
                  <p className="text-xl font-bold text-green-600">
                    R: {segResult.segHeightRight}mm
                  </p>
                  <p className="text-xl font-bold text-green-600">
                    L: {segResult.segHeightLeft}mm
                  </p>
                  <h3 className="font-bold text-green-900 mt-2 mb-1">OC Height</h3>
                  <p className="text-sm text-green-700">
                    R: {segResult.ocHeightRight}mm / L: {segResult.ocHeightLeft}mm
                  </p>
                </div>
              )}

              {faceGeometry && (
                <>
                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                    <h3 className="font-bold text-purple-900 mb-2">Face Shape</h3>
                    <p className="text-2xl font-bold text-purple-600 capitalize">{faceGeometry.faceShape}</p>
                    <p className="text-sm text-purple-700">
                      {faceGeometry.faceWidth}mm wide x {faceGeometry.faceHeight}mm tall
                    </p>
                  </div>

                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                    <h3 className="font-bold text-orange-900 mb-2">Face Dimensions</h3>
                    <div className="text-sm text-orange-800 space-y-1">
                      <p>Cheekbones: {faceGeometry.cheekboneWidth}mm</p>
                      <p>Jaw: {faceGeometry.jawWidth}mm</p>
                      <p>Forehead: {faceGeometry.foreheadWidth}mm</p>
                    </div>
                  </div>
                </>
              )}
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
              <h3 className="font-bold text-blue-900 mb-2">What Happens Next?</h3>
              <p className="text-blue-800 text-sm">
                Your eye care provider will review these measurements. They may contact you
                to confirm or request a retake. Once approved, they'll be used for your new glasses.
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setPdResult(null);
                  setSegResult(null);
                  setFaceGeometry(null);
                  setFaceSVG('');
                  setCalibration(null);
                  setFrameBottom(null);
                  setCardMarkers({ left: null, right: null });
                  setStep(STEPS.INTRO);
                }}
                className="flex-1 px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 flex items-center justify-center gap-2"
              >
                <RotateCcw size={18} /> Retake Measurements
              </button>

              <a
                href={"/patient/frame-scanner?token=" + token}
                className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 flex items-center justify-center gap-2 text-center"
              >
                <Camera size={18} /> Scan Frames
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
