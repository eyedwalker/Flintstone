import React, { useState } from 'react';
import { CheckCircle, Eye, Ruler, Save, RotateCcw } from 'lucide-react';
import { FaceDepthViewer } from '../components/FaceDepthViewer';
import { LensCalibrationGuide } from '../components/LensCalibrationGuide';

/**
 * Results component for the Measurements page
 * Displays measurement data, 3D visualization, and lens calibration options
 */
export function Results({ 
  pdResult, 
  segResult, 
  faceShape, 
  finalSnapshot, 
  movementSequence,
  landmarks,
  headAlignment,
  onSave,
  saving,
  onStartOver,
  onLensCalibrationComplete
}) {
  const [activeTab, setActiveTab] = useState('measurements');
  const [colorScale, setColorScale] = useState('rainbow');
  const [lensCalibrationStep, setLensCalibrationStep] = useState(0);
  
  // Compute final values
  const finalPd = pdResult?.pdTotal;
  const segHeightLeft = segResult?.segHeightLeft;
  const segHeightRight = segResult?.segHeightRight;
  const ocHeightLeft = segResult?.ocHeightLeft;
  const ocHeightRight = segResult?.ocHeightRight;
  
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
        <CheckCircle size={24} />
        Measurements Complete
      </h2>

      {/* Tabs for different result views */}
      <div className="mb-6 border-b border-gray-200">
        <div className="flex gap-4">
          <button 
            onClick={() => setActiveTab('measurements')}
            className={`pb-2 px-1 ${activeTab === 'measurements' 
              ? 'border-b-2 border-indigo-600 text-indigo-600 font-semibold' 
              : 'text-gray-500'}`}
          >
            Measurements
          </button>
          <button 
            onClick={() => setActiveTab('3d-model')}
            className={`pb-2 px-1 ${activeTab === '3d-model' 
              ? 'border-b-2 border-indigo-600 text-indigo-600 font-semibold' 
              : 'text-gray-500'}`}
          >
            3D Model
          </button>
          <button 
            onClick={() => setActiveTab('lens-calibration')}
            className={`pb-2 px-1 ${activeTab === 'lens-calibration' 
              ? 'border-b-2 border-indigo-600 text-indigo-600 font-semibold' 
              : 'text-gray-500'}`}
          >
            Lens Calibration
          </button>
        </div>
      </div>

      {/* Measurements Tab */}
      {activeTab === 'measurements' && (
        <div className="grid md:grid-cols-2 gap-6">
          {/* Left column: Measurements */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Pupil Distance</h3>
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Total PD</div>
                <div className="text-2xl font-bold text-gray-900">{finalPd?.toFixed(1) || '-'}<span className="text-sm ml-1">mm</span></div>
                {movementSequence?.has3dData && (
                  <div className="mt-1 text-xs text-green-600 flex items-center">
                    <CheckCircle size={12} className="inline mr-1" /> 3D enhanced
                  </div>
                )}
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Right PD</div>
                <div className="text-2xl font-bold text-gray-900">{(finalPd ? finalPd/2 : null)?.toFixed(1) || '-'}<span className="text-sm ml-1">mm</span></div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Left PD</div>
                <div className="text-2xl font-bold text-gray-900">{(finalPd ? finalPd/2 : null)?.toFixed(1) || '-'}<span className="text-sm ml-1">mm</span></div>
              </div>
            </div>

            <h3 className="text-lg font-semibold mb-4">Segment Height</h3>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Right Eye</div>
                <div className="text-2xl font-bold text-gray-900">{segHeightRight?.toFixed(1) || '-'}<span className="text-sm ml-1">mm</span></div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Left Eye</div>
                <div className="text-2xl font-bold text-gray-900">{segHeightLeft?.toFixed(1) || '-'}<span className="text-sm ml-1">mm</span></div>
              </div>
            </div>

            <h3 className="text-lg font-semibold mb-4">Optical Center Height</h3>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Right Eye</div>
                <div className="text-2xl font-bold text-gray-900">{ocHeightRight?.toFixed(1) || '-'}<span className="text-sm ml-1">mm</span></div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Left Eye</div>
                <div className="text-2xl font-bold text-gray-900">{ocHeightLeft?.toFixed(1) || '-'}<span className="text-sm ml-1">mm</span></div>
              </div>
            </div>
          </div>
          
          {/* Right column: Face shape summary */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Face Profile</h3>
            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <div className="flex justify-center">
                {finalSnapshot ? (
                  <img 
                    src={finalSnapshot} 
                    alt="Face measurement" 
                    className="w-48 h-48 object-cover rounded-lg"
                  />
                ) : (
                  <div className="w-48 h-48 bg-gray-200 rounded-lg flex items-center justify-center text-gray-400">
                    No image
                  </div>
                )}
              </div>
            </div>

            <h3 className="text-lg font-semibold mb-4">Face Shape</h3>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Shape Type</div>
                <div className="text-xl font-bold text-gray-900 capitalize">{faceShape?.faceShape || 'Unknown'}</div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Confidence</div>
                <div className="text-xl font-bold text-gray-900">
                  {faceShape?.faceShapeConfidence ? 
                    `${(faceShape.faceShapeConfidence * 100).toFixed(0)}%` : 
                    '-'}
                </div>
              </div>
            </div>

            {/* Face dimensions */}
            <h3 className="text-lg font-semibold mb-4">Face Dimensions</h3>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Face Width</div>
                <div className="text-xl font-bold text-gray-900">
                  {faceShape?.faceWidth ? `${faceShape.faceWidth.toFixed(1)}mm` : '-'}
                </div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Face Height</div>
                <div className="text-xl font-bold text-gray-900">
                  {faceShape?.faceHeight ? `${faceShape.faceHeight.toFixed(1)}mm` : '-'}
                </div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Jaw Width</div>
                <div className="text-xl font-bold text-gray-900">
                  {faceShape?.jawWidth ? `${faceShape.jawWidth.toFixed(1)}mm` : '-'}
                </div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">Cheekbone Width</div>
                <div className="text-xl font-bold text-gray-900">
                  {faceShape?.cheekboneWidth ? `${faceShape.cheekboneWidth.toFixed(1)}mm` : '-'}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3D Model Tab */}
      {activeTab === '3d-model' && (
        <div className="pb-6">
          <div className="bg-gray-50 p-4 rounded-lg mb-4">
            {movementSequence?.depthMap && movementSequence?.has3dData ? (
              <div>
                <FaceDepthViewer 
                  depthMap={movementSequence.depthMap} 
                  landmarks={movementSequence.referenceFrame}
                  width={400} 
                  height={350}
                  colorScale={colorScale}
                />
                
                <div className="mt-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Color Scale</label>
                  <select 
                    value={colorScale}
                    onChange={(e) => setColorScale(e.target.value)}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  >
                    <option value="rainbow">Rainbow</option>
                    <option value="grayscale">Grayscale</option>
                    <option value="skin">Skin Tones</option>
                  </select>
                </div>
                
                <div className="mt-4 text-sm text-gray-500">
                  <h4 className="font-medium mb-2">About 3D Depth Model</h4>
                  <p>This visualization shows the depth map calculated from your head movement sequence.
                  The colors represent distance from the camera - closer parts are shown in red/yellow,
                  while parts further away are shown in blue/green.</p>
                  <p className="mt-2">This data helps us improve measurement accuracy and fit recommendations.</p>
                </div>
              </div>
            ) : (
              <div className="py-8 text-center">
                <div className="text-gray-400 mb-2">No 3D data available</div>
                <p className="text-sm text-gray-500">Head movement data wasn't captured or was insufficient for 3D modeling.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Lens Calibration Tab */}
      {activeTab === 'lens-calibration' && (
        <div>
          {lensCalibrationStep === 0 && (
            <div className="bg-white p-4 rounded-lg mb-4 text-center">
              <h3 className="text-lg font-semibold mb-2">Lens-Specific Calibration</h3>
              <p className="text-gray-600 mb-6">This calibration helps optimize your lens measurements for progressives, bifocals, and single vision lenses.</p>
              
              <button
                onClick={() => setLensCalibrationStep(1)}
                className="px-6 py-3 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 transition-colors"
              >
                Start Lens Calibration
              </button>
            </div>
          )}
          
          {lensCalibrationStep > 0 && (
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <LensCalibrationGuide 
                  headAlignment={headAlignment}
                  landmarks={landmarks}
                  currentStep={lensCalibrationStep - 1}
                  setCurrentStep={(step) => setLensCalibrationStep(step + 1)}
                  onCalibrationComplete={onLensCalibrationComplete}
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Save and start over buttons - always visible */}
      <div className="mt-8 flex flex-col gap-3">
        <button
          onClick={onSave}
          disabled={saving}
          className="w-full px-6 py-3 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {saving ? <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"/> : <Save size={18} />}
          {saving ? 'Saving...' : 'Save Measurements'}
        </button>
        
        <button 
          onClick={onStartOver}
          className="w-full px-6 py-3 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300 transition-colors flex items-center justify-center gap-2"
        >
          <RotateCcw size={18} />
          Start Over
        </button>
      </div>
    </div>
  );
}

export default Results;
