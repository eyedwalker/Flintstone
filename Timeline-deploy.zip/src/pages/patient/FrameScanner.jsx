import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Camera, Heart, CheckCircle, AlertCircle, Loader, Keyboard, Search } from 'lucide-react';
import Quagga from 'quagga';

export default function FrameScanner() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  
  const [scanning, setScanning] = useState(false);
  const [favorites, setFavorites] = useState([]);
  const [lastScan, setLastScan] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [manualUpc, setManualUpc] = useState('');
  const [showManualEntry, setShowManualEntry] = useState(false);

  useEffect(() => {
    if (token) {
      loadFavorites();
    }
  }, [token]);

  useEffect(() => {
    return () => {
      if (scanning) {
        Quagga.stop();
      }
    };
  }, [scanning]);

  const loadFavorites = async () => {
    try {
      const response = await fetch(`/api/patient/favorites?token=${token}`);
      const data = await response.json();
      if (data.success) {
        setFavorites(data.favorites || []);
      }
    } catch (err) {
      console.error('Failed to load favorites:', err);
    }
  };

  const initQuagga = (facingMode) => {
    return new Promise((resolve, reject) => {
      Quagga.init({
        inputStream: {
          type: "LiveStream",
          target: document.querySelector('#scanner-container'),
          constraints: {
            facingMode,
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        },
        decoder: {
          readers: ["upc_reader", "upc_e_reader", "ean_reader"]
        },
        locate: true,
        locator: {
          patchSize: "medium",
          halfSample: true
        }
      }, (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  };

  const startScanning = async () => {
    setError('');
    setScanning(true);

    // Wait a tick for #scanner-container to mount
    await new Promise(r => setTimeout(r, 100));

    try {
      // Try rear camera first (phones), fall back to front camera (laptops)
      try {
        await initQuagga('environment');
      } catch (envErr) {
        console.log('[FrameScanner] Environment camera failed, trying user:', envErr);
        try {
          await initQuagga('user');
        } catch (userErr) {
          console.log('[FrameScanner] User camera failed, trying any:', userErr);
          await initQuagga(undefined);
        }
      }
      Quagga.start();
      Quagga.onDetected(handleDetected);
      console.log('[FrameScanner] Camera started successfully');
    } catch (err) {
      console.error('[FrameScanner] All camera attempts failed:', err);
      setError('Camera not available. Use manual entry below to type the UPC code.');
      setScanning(false);
      setShowManualEntry(true);
    }
  };

  const stopScanning = () => {
    Quagga.stop();
    Quagga.offDetected(handleDetected);
    setScanning(false);
  };

  const handleDetected = async (result) => {
    const code = result.codeResult.code;
    
    // Avoid duplicate scans
    if (lastScan === code) return;
    setLastScan(code);

    // Beep or vibrate
    if (navigator.vibrate) {
      navigator.vibrate(200);
    }

    // Save frame
    setLoading(true);
    try {
      const response = await fetch('/api/patient/frame-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          upc_code: code
        })
      });

      const data = await response.json();
      
      if (data.success) {
        await loadFavorites();
        setError('');
        // Show success briefly
        setTimeout(() => setLastScan(null), 3000);
      } else {
        setError(data.error || 'Failed to save frame');
      }
    } catch (err) {
      setError('Network error - please try again');
    } finally {
      setLoading(false);
    }
  };

  const handleManualSubmit = async (e) => {
    e.preventDefault();
    const code = manualUpc.trim();
    if (!code) return;

    setLoading(true);
    setError('');
    try {
      const response = await fetch('/api/patient/frame-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, upc_code: code })
      });

      const data = await response.json();
      if (data.success) {
        await loadFavorites();
        setManualUpc('');
        setLastScan(code);
        setTimeout(() => setLastScan(null), 3000);
      } else {
        setError(data.error || 'Failed to save frame');
      }
    } catch (err) {
      setError('Network error - please try again');
    } finally {
      setLoading(false);
    }
  };

  const removeFavorite = async (id) => {
    try {
      const response = await fetch(`/api/patient/favorites?token=${token}&id=${id}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      if (data.success) {
        await loadFavorites();
      }
    } catch (err) {
      console.error('Failed to remove favorite:', err);
    }
  };

  if (!token) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-lg p-8 max-w-md text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Invalid Link</h1>
          <p className="text-gray-600">
            This link is invalid or has expired. Please request a new link from your eye care provider.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-blue-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Camera size={28} />
            Frame Finder
          </h1>
          <p className="text-blue-100 text-sm mt-1">
            Scan frames you like and save them to your favorites
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4">
        {/* Scanner Section */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          {!scanning ? (
            <div className="text-center">
              <Camera className="w-20 h-20 text-blue-600 mx-auto mb-4" />
              <h2 className="text-xl font-bold text-gray-900 mb-2">
                Ready to Scan
              </h2>
              <p className="text-gray-600 mb-6">
                Point your camera at the barcode on the frame arm to add it to your favorites
              </p>
              <button
                onClick={startScanning}
                className="px-8 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Start Scanning
              </button>
            </div>
          ) : (
            <div>
              <div id="scanner-container" className="relative w-full h-64 bg-black rounded-lg overflow-hidden mb-4">
                {loading && (
                  <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                    <Loader className="w-8 h-8 text-white animate-spin" />
                  </div>
                )}
                {lastScan && (
                  <div className="absolute top-4 left-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg flex items-center gap-2">
                    <CheckCircle size={20} />
                    <span>Frame saved! UPC: {lastScan}</span>
                  </div>
                )}
              </div>
              
              <div className="text-center">
                <p className="text-gray-600 mb-4">
                  Position the barcode within the frame
                </p>
                <button
                  onClick={stopScanning}
                  className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  Stop Scanning
                </button>
              </div>
            </div>
          )}

          {error && (
            <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-2">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-red-800 text-sm">{error}</p>
            </div>
          )}

          {/* Manual UPC/SKU Entry */}
          <div className="mt-4 border-t border-gray-200 pt-4">
            <button
              onClick={() => setShowManualEntry(!showManualEntry)}
              className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 transition-colors"
            >
              <Keyboard size={16} />
              {showManualEntry ? 'Hide manual entry' : 'Enter UPC/SKU manually'}
            </button>

            {showManualEntry && (
              <form onSubmit={handleManualSubmit} className="mt-3 flex gap-2">
                <input
                  type="text"
                  value={manualUpc}
                  onChange={(e) => setManualUpc(e.target.value)}
                  placeholder="Enter UPC or SKU code..."
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  autoFocus
                />
                <button
                  type="submit"
                  disabled={loading || !manualUpc.trim()}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center gap-1.5 text-sm font-medium"
                >
                  {loading ? <Loader size={16} className="animate-spin" /> : <Search size={16} />}
                  Add
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Favorites List */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Heart className="text-red-500" size={24} />
            My Favorites ({favorites.length})
          </h2>

          {favorites.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Heart className="w-16 h-16 mx-auto mb-3 text-gray-300" />
              <p>No frames scanned yet</p>
              <p className="text-sm">Start scanning to build your favorites list</p>
            </div>
          ) : (
            <div className="space-y-4">
              {favorites.map((frame) => (
                <div
                  key={frame.id}
                  className="border border-gray-200 rounded-lg p-4 flex items-center gap-4 hover:shadow-md transition-shadow"
                >
                  {frame.image_url ? (
                    <img
                      src={frame.image_url}
                      alt={frame.frame_name || 'Frame'}
                      className="w-20 h-20 object-cover rounded"
                    />
                  ) : (
                    <div className="w-20 h-20 bg-gray-200 rounded flex items-center justify-center">
                      <Camera className="text-gray-400" size={32} />
                    </div>
                  )}
                  
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">
                      {frame.frame_name || 'Unknown Frame'}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {frame.frame_manufacturer || 'Manufacturer not found'}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      UPC: {frame.upc_code}
                    </p>
                    {frame.frame_size && (
                      <p className="text-xs text-gray-500">
                        Size: {frame.frame_size}
                      </p>
                    )}
                  </div>

                  <button
                    onClick={() => removeFavorite(frame.id)}
                    className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Next Steps */}
        {favorites.length > 0 && (
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="font-bold text-blue-900 mb-2">What's Next?</h3>
            <p className="text-blue-800 text-sm">
              Your eye care provider will review your favorite frames and help you choose the perfect pair.
              They'll contact you to schedule a fitting appointment.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
