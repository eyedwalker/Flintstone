import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

function ApiTest() {
  const navigate = useNavigate();
  const [results, setResults] = useState([]);
  const [testing, setTesting] = useState(false);

  const addResult = (test, success, message, data = null) => {
    setResults(prev => [...prev, { test, success, message, data, timestamp: new Date().toISOString() }]);
  };

  const runTests = async () => {
    setResults([]);
    setTesting(true);

    // Test 1: Check if config exists
    const config = localStorage.getItem('eyefinityConfig');
    if (!config) {
      addResult('Config Check', false, 'No Eyefinity config found in localStorage');
      setTesting(false);
      return;
    }

    const parsedConfig = JSON.parse(config);
    addResult('Config Check', true, 'Configuration found', {
      hasToken: !!parsedConfig.accessToken,
      tokenLength: parsedConfig.accessToken?.length || 0,
      apiBaseUrl: parsedConfig.apiBaseUrl,
      officeId: parsedConfig.officeId
    });

    // Test 2: Direct API call with full token in header
    try {
      addResult('Direct API Test', null, 'Testing /api/eyefinity/v2offices endpoint...');
      
      const response = await fetch('/api/eyefinity/v2offices?page=1&pageSize=5', {
        method: 'GET',
        headers: {
          'X-Auth-Token': parsedConfig.accessToken,
          'Content-Type': 'application/json',
        },
      });

      console.log('Response status:', response.status);
      console.log('Response headers:', Object.fromEntries(response.headers.entries()));

      if (response.ok) {
        const data = await response.json();
        addResult('Direct API Test', true, `Success! Got ${data.items?.length || 0} offices`, {
          status: response.status,
          itemCount: data.items?.length,
          firstOffice: data.items?.[0]
        });
      } else {
        const text = await response.text();
        addResult('Direct API Test', false, `Failed: ${response.status} ${response.statusText}`, {
          status: response.status,
          responseText: text.substring(0, 500)
        });
      }
    } catch (err) {
      addResult('Direct API Test', false, `Error: ${err.message}`, { error: err.toString() });
    }

    // Test 3: Test with different endpoint
    try {
      addResult('Appointments Test', null, 'Testing /api/eyefinity/appointments endpoint with officeId query param...');
      
      const fromDate = '2024-01-01';
      const toDate = '2026-12-31';
      const officeId = parsedConfig.officeId || '936';
      
      const response = await fetch(`/api/eyefinity/appointments/?fromDate=${fromDate}&toDate=${toDate}&officeId=${officeId}&page=1&pageSize=10`, {
        method: 'GET',
        headers: {
          'X-Auth-Token': parsedConfig.accessToken,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        addResult('Appointments Test', true, `Success! Got ${data.items?.length || 0} appointments`, {
          status: response.status,
          itemCount: data.items?.length,
          dateRange: `${fromDate} to ${toDate}`
        });
      } else {
        const text = await response.text();
        addResult('Appointments Test', false, `Failed: ${response.status} ${response.statusText}`, {
          status: response.status,
          responseText: text.substring(0, 500)
        });
      }
    } catch (err) {
      addResult('Appointments Test', false, `Error: ${err.message}`, { error: err.toString() });
    }

    setTesting(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-[#023046] text-white px-6 py-4">
        <h1 className="text-2xl font-bold">API Test Utility</h1>
        <p className="text-sm text-gray-300">Debug Eyefinity API Integration</p>
      </div>

      <div className="max-w-4xl mx-auto p-6">
        <button
          onClick={() => navigate('/admin')}
          className="mb-4 flex items-center gap-2 text-sm text-gray-600 hover:text-gray-800"
        >
          <ArrowLeft size={16} />
          Back to Admin Config
        </button>

        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">Run API Tests</h2>
          <p className="text-sm text-gray-600 mb-4">
            This will test your Eyefinity API configuration and verify the proxy is working correctly.
            Check the browser console and terminal for detailed logs.
          </p>
          <button
            onClick={runTests}
            disabled={testing}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
          >
            {testing ? 'Running Tests...' : 'Run Tests'}
          </button>
        </div>

        {results.length > 0 && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold mb-4">Test Results</h2>
            <div className="space-y-4">
              {results.map((result, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border ${
                    result.success === null
                      ? 'bg-blue-50 border-blue-200'
                      : result.success
                      ? 'bg-green-50 border-green-200'
                      : 'bg-red-50 border-red-200'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-sm">{result.test}</h3>
                    <span className="text-xs text-gray-500">
                      {new Date(result.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-sm mb-2">{result.message}</p>
                  {result.data && (
                    <details className="text-xs">
                      <summary className="cursor-pointer text-gray-600 hover:text-gray-800">
                        View Details
                      </summary>
                      <pre className="mt-2 p-2 bg-gray-100 rounded overflow-x-auto">
                        {JSON.stringify(result.data, null, 2)}
                      </pre>
                    </details>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-yellow-900 mb-2">Debug Checklist</h3>
          <ul className="text-xs text-yellow-800 space-y-1">
            <li>• Check browser console (F12) for client-side errors</li>
            <li>• Check terminal where `npm run dev` is running for proxy logs</li>
            <li>• Verify your Access Token is correct in Admin Config</li>
            <li>• Ensure dev server was restarted after updating vite.config.js</li>
            <li>• Look for [Proxy] log messages in terminal showing token status</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default ApiTest;
