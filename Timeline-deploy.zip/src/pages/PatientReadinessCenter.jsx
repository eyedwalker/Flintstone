import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Phone, MessageSquare, MoreVertical, ChevronDown, ChevronRight, RefreshCw, Filter, Plus, Search, Settings, Bot, Send, AlertTriangle, Mail, CheckCircle, Clock, X, FileText, Printer, Edit, Route, PlayCircle, PhoneCall, PhoneOff, Mic, MicOff, Pause, Play, Building2, ExternalLink, Copy, BarChart3, ListChecks, Camera, Ruler } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCompany } from '../contexts/CompanyContext';
import { EyefinityService, getAppointmentStatus, setAppointmentStatus, getAppointmentReadiness, setAppointmentReadiness, isPatientReady, getReadinessFilter, getAppointmentPaymentMethod, setAppointmentPaymentMethod } from '../services/eyefinityService';
import FtcComplianceService from '../services/ftcComplianceService';
import HipaaComplianceService from '../services/hipaaComplianceService';
import { RxConsentForm, RxAcknowledgementForm, FtcComplianceWarning, FtcComplianceStatus } from '../components/ftc';
import { HipaaSignatureForm, HipaaComplianceWarning, HipaaSignatureStatus } from '../components/hipaa';
import { CommunicationService, COMMUNICATION_TEMPLATES } from '../services/communicationService';
import { AICommandChat } from '../components/ai-chat';
import { PatientJourneyService } from '../lib/services/patient-journey-service';
import { OfficeRoomsService } from '../lib/services/office-rooms-service';
import InlineJourneyPanel from '../components/patient-journey/InlineJourneyPanel';
import { VoiceCallService } from '../lib/services/voice-call-service';
import { AdminSettingsService, getAvailableEnvironments } from '../services/adminSettingsService';
import { FormSubmissionService } from '../lib/services/form-submission-service';
import { EscalationQueuePopup, AIPerformanceMonitor, CommunicationTemplateSelector, UnifiedCommunicationsPanel } from '../components/communication';
import { AppHeader } from '../components/layout';
import { TaskService } from '../services/taskService';
import FullResponseDisplay from '../components/FullResponseDisplay';

const buildTaskFormState = (overrides = {}) => ({
  title: '',
  description: '',
  priority: 'normal',
  status: 'pending',
  assignee: '',
  assignedToOffice: '',
  channel: 'internal',
  dueDate: '',
  dueTime: '',
  reminderMinutes: '',
  appointmentId: null,
  patientId: null,
  patientName: '',
  officeId: '',
  providerName: '',
  metadata: {},
  ...overrides,
});

function PatientReadinessCenter() {
  const { currentUser, logout, isAdmin } = useAuth();
  const { activeCompany } = useCompany();
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState([]);
  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [offices, setOffices] = useState([]);
  const [selectedOffice, setSelectedOffice] = useState('');
  const [daysFilter, setDaysFilter] = useState(0);
  const [statusFilter, setStatusFilter] = useState('All');
  const [insuranceCarrierFilter, setInsuranceCarrierFilter] = useState('All');
  const [patientInsuranceCache, setPatientInsuranceCache] = useState({});
  const [activeTab, setActiveTab] = useState('Demographics');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAiChat, setShowAiChat] = useState(false);
  const [showSearchOptions, setShowSearchOptions] = useState(false);
  const [showStatusDropdown, setShowStatusDropdown] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  
  // Patient detail states
  const [patientDetails, setPatientDetails] = useState(null);
  const [patientInsurance, setPatientInsurance] = useState(null);
  const [patientRx, setPatientRx] = useState([]);
  const [patientAppointments, setPatientAppointments] = useState([]);
  const [loadingPatientData, setLoadingPatientData] = useState(false);
  
  // Full API response data for display
  const [fullPatientResponse, setFullPatientResponse] = useState(null);
  const [fullRxResponse, setFullRxResponse] = useState(null);
  const [fullOrdersResponse, setFullOrdersResponse] = useState(null);
  const [fullAppointmentsResponse, setFullAppointmentsResponse] = useState(null);
  const [apiLoadingStates, setApiLoadingStates] = useState({
    patient: false,
    rx: false, 
    orders: false,
    appointments: false
  });
  const [apiErrors, setApiErrors] = useState({});

  // Communication states
  const [communications, setCommunications] = useState([]);
  const [escalations, setEscalations] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [messageType, setMessageType] = useState('sms');
  const [sendingMessage, setSendingMessage] = useState(false);
  const [commChannel, setCommChannel] = useState('sms'); // 'voice' | 'sms' | 'email'
  const [activeCall, setActiveCall] = useState(null);
  const [callDuration, setCallDuration] = useState(0);
  const [callHistory, setCallHistory] = useState([]);
  
  // Patient Journey states
  const [patientJourneys, setPatientJourneys] = useState({});
  const [journeyLoading, setJourneyLoading] = useState({});
  const [tasks, setTasks] = useState([]);
  const [tasksLoading, setTasksLoading] = useState(false);
  const [taskStatusFilter, setTaskStatusFilter] = useState('all');
  const [untitledTaskFilter, setUntitledTaskFilter] = useState('all');
  const [worklistFilter, setWorklistFilter] = useState('appointments');
  const [queueStats, setQueueStats] = useState(null);
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [editingTaskId, setEditingTaskId] = useState(null);
  const [taskForm, setTaskForm] = useState(() => buildTaskFormState());
  const [taskSubmitting, setTaskSubmitting] = useState(false);
  const [taskError, setTaskError] = useState('');
  
  // Patient Forms states
  const [patientForms, setPatientForms] = useState([]);
  const [formTemplates, setFormTemplates] = useState([]);
  const [showSendFormModal, setShowSendFormModal] = useState(false);
  const [selectedFormTemplate, setSelectedFormTemplate] = useState(null);
  const [sendingForm, setSendingForm] = useState(false);
  const [copiedFormLink, setCopiedFormLink] = useState(null);
  
  // FTC Rx Compliance states
  const [showRxConsentForm, setShowRxConsentForm] = useState(false);
  const [showRxAcknowledgementForm, setShowRxAcknowledgementForm] = useState(false);
  const [ftcComplianceRefresh, setFtcComplianceRefresh] = useState(0);
  
  // HIPAA Compliance states
  const [showHipaaSignatureForm, setShowHipaaSignatureForm] = useState(false);
  const [hipaaComplianceRefresh, setHipaaComplianceRefresh] = useState(0);
  
  // Escalation Queue state
  const [showEscalationQueue, setShowEscalationQueue] = useState(false);
  const [showAIPerformanceMonitor, setShowAIPerformanceMonitor] = useState(false);

  // Inline Journey Panel states
  const [showInlineJourney, setShowInlineJourney] = useState(true);
  const [prcRooms, setPrcRooms] = useState([]);

  // Insurance Verification states
  const [verificationResult, setVerificationResult] = useState(null);
  const [verificationLoading, setVerificationLoading] = useState(false);
  const [verificationJobId, setVerificationJobId] = useState(null);
  const [mfaRequired, setMfaRequired] = useState(null);
  const [mfaCode, setMfaCode] = useState('');
  
  // Demo contact info
  const demoContact = CommunicationService.getDemoContact();

  useEffect(() => {
    if (activeCompany?.id) {
      loadOffices();
    }
  }, [activeCompany]);

  useEffect(() => {
    setCurrentPage(1);
  }, [worklistFilter, taskStatusFilter, statusFilter, daysFilter, selectedOffice, insuranceCarrierFilter]);

  const handleWorklistFilterChange = useCallback((nextFilter) => {
    setWorklistFilter(nextFilter);
    if (nextFilter === 'appointments') {
      setTaskStatusFilter('all');
      setUntitledTaskFilter('all');
    }
    setCurrentPage(1);
  }, []);

  const isUntitledTask = useCallback((task) => {
    const title = task?.title;
    return !title || String(title).trim().length === 0;
  }, []);

  useEffect(() => {
    if (selectedOffice) {
      loadAppointments();
    }
  }, [selectedOffice, daysFilter]);

  // Fetch patient details when appointment is selected
  useEffect(() => {
    if (selectedAppointment?.patientId) {
      loadPatientDetails(selectedAppointment.patientId);
      loadCommunications(selectedAppointment.patientId);
      loadPatientForms(selectedAppointment.patientId);
    }
  }, [selectedAppointment?.patientId]);

  // Poll for new inbound SMS every 15 seconds
  useEffect(() => {
    if (!selectedAppointment?.patientId) return;
    const interval = setInterval(() => {
      loadCommunications(selectedAppointment.patientId);
    }, 15000);
    return () => clearInterval(interval);
  }, [selectedAppointment?.patientId, patientDetails?.mobilePhone, patientDetails?.phone]);

  const isMountedRef = useRef(true);
  useEffect(() => () => {
    isMountedRef.current = false;
  }, []);

  const refreshTasks = useCallback(async () => {
    setTasksLoading(true);
    try {
      const data = await TaskService.fetchTasks(taskStatusFilter);
      if (!isMountedRef.current) return;
      setTasks(data.tasks || []);
      setQueueStats(data.queue || null);
    } catch (err) {
      if (isMountedRef.current) {
        console.error('[PRC] Failed to load tasks', err);
      }
    } finally {
      if (isMountedRef.current) {
        setTasksLoading(false);
      }
    }
  }, [taskStatusFilter]);

  useEffect(() => {
    let cancel = false;
    const load = async () => {
      if (cancel) return;
      await refreshTasks();
    };
    load();
    const interval = setInterval(load, 60000);
    return () => {
      cancel = true;
      clearInterval(interval);
    };
  }, [refreshTasks]);

  // Load form templates on mount
  useEffect(() => {
    const templates = FormSubmissionService.getTemplates();
    setFormTemplates(templates.filter(t => t.isPublished && !t.isArchived));
  }, []);

  // Load escalations on mount and periodically
  useEffect(() => {
    loadEscalations();
    const interval = setInterval(loadEscalations, 30000); // Check every 30 seconds
    return () => clearInterval(interval);
  }, []);

  // Subscribe to voice call state changes
  useEffect(() => {
    const unsubscribe = VoiceCallService.subscribe((call) => {
      setActiveCall(call);
      if (call && selectedAppointment?.patientId) {
        setCallHistory(VoiceCallService.getPatientCallHistory(selectedAppointment.patientId));
      }
    });
    return () => unsubscribe();
  }, [selectedAppointment?.patientId]);

  // Call duration timer
  useEffect(() => {
    let interval;
    if (activeCall && activeCall.status === 'in-progress') {
      interval = setInterval(() => {
        setCallDuration(Math.round((Date.now() - new Date(activeCall.startTime).getTime()) / 1000));
      }, 1000);
    } else {
      setCallDuration(0);
    }
    return () => clearInterval(interval);
  }, [activeCall?.status]);

  // Load call history when patient selected
  useEffect(() => {
    if (selectedAppointment?.patientId) {
      setCallHistory(VoiceCallService.getPatientCallHistory(selectedAppointment.patientId));
    }
  }, [selectedAppointment?.patientId]);

  const loadCommunications = async (patientId) => {
    // Get locally stored communications
    const localComms = CommunicationService.getPatientCommunications(patientId);

    // Also fetch from Twilio API to get inbound replies
    const phone = patientDetails?.mobilePhone || patientDetails?.phone;
    if (phone) {
      try {
        const res = await fetch(`/api/data/twilio-sms?phone=${encodeURIComponent(phone)}&limit=20`);
        if (res.ok) {
          const data = await res.json();
          if (data.messages?.length) {
            // Convert Twilio messages to CommunicationMessage format and merge
            const twilioComms = data.messages.map(msg => ({
              id: msg.id,
              patientId,
              type: 'sms',
              direction: msg.direction,
              content: msg.content,
              status: msg.status === 'delivered' ? 'delivered' : msg.status === 'read' ? 'read' : 'sent',
              timestamp: msg.timestamp,
              sentBy: msg.direction === 'inbound' ? 'Patient' : msg.sentBy || 'Staff',
            }));
            // Merge: deduplicate by content+timestamp similarity, prefer Twilio data
            const localIds = new Set(localComms.map(c => c.id));
            const newFromTwilio = twilioComms.filter(tc =>
              !localIds.has(tc.id) &&
              !localComms.some(lc =>
                lc.type === 'sms' &&
                lc.content === tc.content &&
                Math.abs(new Date(lc.timestamp) - new Date(tc.timestamp)) < 60000
              )
            );
            const merged = [...localComms, ...newFromTwilio]
              .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
            setCommunications(merged);
            return;
          }
        }
      } catch (err) {
        console.log('[PRC] Twilio SMS fetch failed, using local only:', err.message);
      }
    }

    setCommunications(localComms);
  };

  const loadPatientForms = async (patientId) => {
    const forms = await FormSubmissionService.fetchSubmissionsByPatientId(patientId);
    setPatientForms(forms.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
  };

  // Auto-sync forms readiness status based on actual form completions
  useEffect(() => {
    if (selectedAppointment?.id && patientForms.length > 0) {
      const completedCount = patientForms.filter(f => f.status === 'completed').length;
      const totalCount = patientForms.length;
      const currentReadiness = getAppointmentReadiness(selectedAppointment.id);
      
      // Update readiness if all forms are completed
      if (completedCount === totalCount && currentReadiness.forms !== 'complete') {
        setAppointmentReadiness(selectedAppointment.id, { forms: 'complete' });
        setSelectedAppointment(prev => ({ ...prev, _readinessUpdated: Date.now() }));
      } else if (completedCount < totalCount && currentReadiness.forms === 'complete') {
        // Reset if not all forms are completed but marked as complete
        setAppointmentReadiness(selectedAppointment.id, { forms: 'incomplete' });
        setSelectedAppointment(prev => ({ ...prev, _readinessUpdated: Date.now() }));
      }
    }
  }, [patientForms, selectedAppointment?.id]);

  const handleSendForm = async () => {
    if (!selectedFormTemplate || !selectedAppointment) return;
    
    setSendingForm(true);
    try {
      const submission = FormSubmissionService.createSubmission({
        patientId: selectedAppointment.patientId,
        patientName: selectedAppointment.patientName || 'Patient',
        patientEmail: patientDetails?.email || '',
        patientPhone: patientDetails?.mobilePhone || patientDetails?.homePhone || '',
        templateId: selectedFormTemplate.id,
      });

      // Wait for API storage to complete before refreshing the list
      await FormSubmissionService.waitForApiStorage();

      await FormSubmissionService.sendFormToPatient(
        submission.submissionId,
        patientDetails?.email,
        patientDetails?.mobilePhone || patientDetails?.homePhone
      );

      setShowSendFormModal(false);
      setSelectedFormTemplate(null);
      await loadPatientForms(selectedAppointment.patientId);
    } catch (error) {
      console.error('Error sending form:', error);
    } finally {
      setSendingForm(false);
    }
  };

  const handleCopyFormLink = (accessLink) => {
    navigator.clipboard.writeText(accessLink);
    setCopiedFormLink(accessLink);
    setTimeout(() => setCopiedFormLink(null), 2000);
  };

  const loadEscalations = async () => {
    // Show all non-resolved escalations from localStorage
    const all = CommunicationService.getEscalations();
    const nonResolved = all.filter(e => e.status !== 'resolved');

    // Fetch voice + SMS escalations from Supabase call_enrichments
    try {
      const res = await fetch('/api/data/escalations');
      if (res.ok) {
        const data = await res.json();
        const dbEscalations = (data.escalations || [])
          .filter(esc => !nonResolved.some(e => e.id === esc.id))
          .map(esc => ({
            id: esc.id,
            patientId: esc.phone || 'unknown',
            patientName: esc.phone || (esc.type === 'sms' ? 'SMS Patient' : 'Voice Caller'),
            appointmentId: '',
            reason: esc.reason,
            priority: 'high',
            status: 'active',
            source: 'ai',
            createdAt: esc.createdAt || new Date().toISOString(),
            transcript: esc.transcript || null,
          }));
        nonResolved.push(...dbEscalations);
      }
    } catch (err) {
      console.log('[PRC] Could not fetch escalations:', err.message);
    }

    setEscalations(nonResolved);
  };

  // Load journeys for all appointments
  const loadJourneysForAppointments = (appts) => {
    const journeyMap = {};
    appts.forEach(apt => {
      const journey = PatientJourneyService.getJourneyByPatientId(apt.patientId);
      if (journey) {
        journeyMap[apt.patientId] = journey;
      }
    });
    setPatientJourneys(journeyMap);
  };

  // Start a patient journey
  const handleStartJourney = (apt, e) => {
    e?.stopPropagation();
    setJourneyLoading(prev => ({ ...prev, [apt.patientId]: true }));
    
    try {
      const journey = PatientJourneyService.createJourney({
        patientId: apt.patientId,
        patientName: apt.patientName || 'Unknown Patient',
        reasonForVisit: apt.appointmentType || apt.reason || 'Eye Exam',
        providerName: apt.providerName,
        priority: apt.isUrgent ? 'urgent' : 'normal',
        startPhase: 'pre-visit',
        scheduledAppointmentDate: new Date(apt.date),
        legacyPatientId: String(apt.patientLegacyId || patientDetails?.PatientLegacyId || ''),
        appointmentContext: {
          appointmentType: apt.appointmentType || apt.reason,
          isNewPatient: !apt.hasVisitHistory,
          officeId: selectedOffice,
          providerId: apt.providerId
        }
      });
      
      setPatientJourneys(prev => ({ ...prev, [apt.patientId]: journey }));
    } catch (err) {
      console.error('Failed to start journey:', err);
    } finally {
      setJourneyLoading(prev => ({ ...prev, [apt.patientId]: false }));
    }
  };

  // Get journey status display
  const getJourneyStatusDisplay = (journey) => {
    if (!journey) return null;
    
    const phaseLabels = {
      'pre-visit': 'Pre-Visit',
      'in-office': 'In Office',
      'post-visit': 'Post-Visit',
      'completed': 'Complete'
    };
    
    const phaseColors = {
      'pre-visit': 'bg-blue-100 text-blue-700',
      'in-office': 'bg-green-100 text-green-700',
      'post-visit': 'bg-purple-100 text-purple-700',
      'completed': 'bg-gray-100 text-gray-700'
    };
    
    const currentStep = journey.steps.find(s => s.id === journey.currentStepId);
    
    return {
      phase: phaseLabels[journey.journeyPhase] || journey.journeyPhase,
      phaseColor: phaseColors[journey.journeyPhase] || 'bg-gray-100 text-gray-600',
      currentStep: currentStep?.title || 'No active step',
      progress: journey.progressPercentage || 0
    };
  };

  // Load rooms for current office (for inline journey panel)
  useEffect(() => {
    if (!selectedOffice) return;
    let config = OfficeRoomsService.getOfficeConfig(selectedOffice);
    if (!config) {
      config = OfficeRoomsService.initializeOffice(selectedOffice, 'Office', 'medium');
    }
    setPrcRooms(config.rooms || []);
  }, [selectedOffice]);

  // Periodically refresh rooms
  useEffect(() => {
    if (!selectedOffice) return;
    const interval = setInterval(() => {
      const config = OfficeRoomsService.getOfficeConfig(selectedOffice);
      if (config) setPrcRooms(config.rooms || []);
    }, 5000);
    return () => clearInterval(interval);
  }, [selectedOffice]);

  // Inline journey panel handlers
  const handlePrcStepAction = (journeyId, stepId, action) => {
    try {
      if (action === 'start') {
        PatientJourneyService.startStep(journeyId, stepId);
      } else if (action === 'complete') {
        PatientJourneyService.completeStep(journeyId, stepId);
      } else if (action === 'skip') {
        PatientJourneyService.skipStep(journeyId, stepId);
      }
      // Refresh journey state
      if (selectedAppointment?.patientId) {
        const updated = PatientJourneyService.getJourneyByPatientId(selectedAppointment.patientId);
        if (updated) {
          setPatientJourneys(prev => ({ ...prev, [selectedAppointment.patientId]: updated }));
        }
      }
      // Refresh rooms
      const config = OfficeRoomsService.getOfficeConfig(selectedOffice);
      if (config) setPrcRooms(config.rooms || []);
    } catch (err) {
      console.error('Step action failed:', err);
    }
  };

  const handlePrcAssignRoom = (journeyId, roomId) => {
    const journey = patientJourneys[selectedAppointment?.patientId];
    if (!journey) return;

    // Release from current room if any
    const currentRoom = prcRooms.find(r => r.currentJourneyId === journeyId);
    if (currentRoom) {
      OfficeRoomsService.releasePatientFromRoom(selectedOffice, currentRoom.id);
    }

    const currentStep = journey.steps?.find(s => s.id === journey.currentStepId);
    OfficeRoomsService.assignPatientToRoom(
      selectedOffice, roomId, journey.patientId, journey.patientName,
      journey.id, currentStep?.id || '', currentStep?.title || ''
    );

    // Start step if pending
    if (currentStep && currentStep.status === 'pending') {
      PatientJourneyService.startStep(journey.id, currentStep.id);
    }

    // Refresh rooms and journey
    const config = OfficeRoomsService.getOfficeConfig(selectedOffice);
    if (config) setPrcRooms(config.rooms || []);
    const updated = PatientJourneyService.getJourneyByPatientId(selectedAppointment.patientId);
    if (updated) {
      setPatientJourneys(prev => ({ ...prev, [selectedAppointment.patientId]: updated }));
    }
  };

  const handlePrcPhaseTransition = (journeyId, newPhase) => {
    PatientJourneyService.transitionJourneyPhase(journeyId, newPhase);

    // Auto-release room when leaving in-office
    if (newPhase === 'post-visit' || newPhase === 'completed') {
      const configs = OfficeRoomsService.getAllConfigs();
      for (const config of configs) {
        const room = (config.rooms || []).find(
          r => r.status === 'occupied' && r.currentJourneyId === journeyId
        );
        if (room) {
          OfficeRoomsService.releasePatientFromRoom(config.officeId, room.id);
        }
      }
    }

    // Refresh
    if (selectedAppointment?.patientId) {
      const updated = PatientJourneyService.getJourneyByPatientId(selectedAppointment.patientId);
      if (updated) {
        setPatientJourneys(prev => ({ ...prev, [selectedAppointment.patientId]: updated }));
      }
    }
    const config = OfficeRoomsService.getOfficeConfig(selectedOffice);
    if (config) setPrcRooms(config.rooms || []);
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedAppointment?.patientId) return;
    
    setSendingMessage(true);
    try {
      if (messageType === 'sms') {
        await CommunicationService.sendSMS(
          selectedAppointment.patientId,
          newMessage,
          currentUser?.name || 'Staff'
        );
      } else {
        await CommunicationService.sendEmail(
          selectedAppointment.patientId,
          'Message from your eye care provider',
          newMessage,
          currentUser?.name || 'Staff'
        );
      }
      setNewMessage('');
      loadCommunications(selectedAppointment.patientId);
    } catch (err) {
      console.error('Failed to send message:', err);
    } finally {
      setSendingMessage(false);
    }
  };

  const handleSendTemplate = async (templateId) => {
    if (!selectedAppointment?.patientId) return;
    
    setSendingMessage(true);
    try {
      const variables = {
        patientName: selectedAppointment.patientName || 'Patient',
        appointmentDate: selectedAppointment.date || '',
        appointmentTime: selectedAppointment.startTime || '',
        providerName: selectedAppointment.providerName || 'Your Provider',
        officeName: offices.find(o => o.id === selectedOffice)?.officeName || 'Our Office',
        officePhone: '(555) 123-4567',
        formsLink: 'https://forms.example.com/intake',
      };
      
      await CommunicationService.sendFromTemplate(
        selectedAppointment.patientId,
        templateId,
        variables,
        currentUser?.name || 'Staff'
      );
      setSelectedTemplate('');
      loadCommunications(selectedAppointment.patientId);
    } catch (err) {
      console.error('Failed to send template:', err);
    } finally {
      setSendingMessage(false);
    }
  };

  const handleEscalate = (reason) => {
    if (!selectedAppointment) return;
    
    CommunicationService.createEscalation(
      selectedAppointment.patientId,
      selectedAppointment.patientName || 'Unknown Patient',
      selectedAppointment.id,
      reason,
      'high'
    );
    loadEscalations();
  };

  const handleAcknowledgeEscalation = (escalationId) => {
    CommunicationService.acknowledgeEscalation(escalationId);
    loadEscalations();
  };

  const handleResolveEscalation = (escalationId) => {
    CommunicationService.resolveEscalation(escalationId);
    loadEscalations();
  };

  // Voice call handlers
  const handleCallPatient = async () => {
    if (!selectedAppointment?.patientId || activeCall) return;
    try {
      await VoiceCallService.callPatient(
        selectedAppointment.patientId,
        selectedAppointment.patientName || 'Patient',
        demoContact.phone,
        currentUser?.name || 'Staff'
      );
    } catch (err) {
      console.error('Failed to start call:', err);
    }
  };

  const handleCallOffice = async () => {
    if (activeCall) return;
    try {
      await VoiceCallService.callOffice(currentUser?.name || 'Staff');
    } catch (err) {
      console.error('Failed to call office:', err);
    }
  };

  const handleEndCall = () => {
    VoiceCallService.endCall();
  };

  const handleToggleMute = () => {
    VoiceCallService.toggleMute();
  };

  const handleToggleHold = () => {
    VoiceCallService.toggleHold();
  };

  const handleStartCall = async (script = '', templateId = null) => {
    if (!selectedAppointment?.patientId || activeCall) return;
    
    const phone = patientDetails?.mobilePhone || patientDetails?.phone;
    if (!phone) {
      console.error('No phone number available for patient');
      return;
    }

    try {
      // Use AI outbound call API with optional script
      const response = await fetch('/api/voice/ai-outbound-call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: phone,
          patientFirstName: patientDetails?.firstName || selectedAppointment?.patientName?.split(' ')[0] || 'there',
          patientId: selectedAppointment.patientId,
          callType: templateId || 'appointment_confirmation',
          appointmentDate: selectedAppointment?.date,
          appointmentTime: selectedAppointment?.startTime,
          providerName: selectedAppointment?.providerName,
          script: script || null, // Custom script from template
        }),
      });

      const result = await response.json();
      if (result.success) {
        console.log('[Call] AI outbound call initiated:', result.callSid);
        setActiveCall({
          callSid: result.callSid,
          status: 'initiated',
          startTime: new Date().toISOString(),
        });

        // Save voice call to communication history so it appears in the History tab
        CommunicationService.saveCommunication({
          patientId: selectedAppointment.patientId,
          type: 'voice',
          direction: 'outbound',
          content: script || `AI outbound call - ${templateId || 'appointment_confirmation'}`,
          templateId: templateId || undefined,
          status: 'sent',
          sentBy: 'AI Voice',
          callStatus: 'initiated',
        });

        // Auto-clear the banner after 5 seconds - AI handles the call
        setTimeout(() => setActiveCall(null), 5000);
      } else {
        console.error('[Call] Failed to start call:', result.error);
      }
    } catch (err) {
      console.error('[Call] Error starting call:', err);
    }
  };

  const formatCallDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Simulate incoming message (for demo)
  const simulateIncomingMessage = () => {
    if (!selectedAppointment?.patientId) return;
    const responses = [
      'CONFIRM - I will be there!',
      'Can I reschedule to next week?',
      'What documents do I need to bring?',
      'Is my insurance accepted?',
    ];
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    CommunicationService.simulateIncomingMessage(selectedAppointment.patientId, randomResponse);
    loadCommunications(selectedAppointment.patientId);
  };

  const loadOffices = async () => {
    try {
      const config = JSON.parse(localStorage.getItem('eyefinityConfig') || '{}');
      
      const data = await EyefinityService.fetchOffices(activeCompany?.id);
      if (data && data.items && data.items.length > 0) {
        setOffices(data.items);
        
        // Use configured office ID if exists and valid, otherwise use first office
        if (config.officeId && data.items.find(o => o.id === config.officeId)) {
          setSelectedOffice(config.officeId);
        } else {
          setSelectedOffice(data.items[0].id);
        }
      } else {
        setError('No offices found. Please check your API configuration.');
      }
    } catch (err) {
      console.error('Failed to load offices:', err);
      setError(`Failed to load offices: ${err.message}`);
    }
  };

  const loadAppointments = async () => {
    setLoading(true);
    setError('');
    
    try {
      const fromDate = new Date();
      fromDate.setFullYear(fromDate.getFullYear() - 1); // 1 year back for demo
      const toDate = new Date();
      toDate.setDate(toDate.getDate() + daysFilter);
      
      console.log('[PRC] Fetching appointments:', { fromDate: fromDate.toISOString().split('T')[0], toDate: toDate.toISOString().split('T')[0], officeId: selectedOffice });

      const data = await EyefinityService.fetchAppointments({
        fromDate: fromDate.toISOString().split('T')[0],
        toDate: toDate.toISOString().split('T')[0],
        officeId: selectedOffice,
        companyId: activeCompany?.id
      });

      if (data && data.items) {
        const appointmentsWithStatus = data.items.map(apt => ({
          ...apt,
          readinessStatus: getAppointmentStatus(apt.id)
        }));
        setAppointments(appointmentsWithStatus);
        loadJourneysForAppointments(appointmentsWithStatus);
        if (appointmentsWithStatus.length > 0) {
          setSelectedAppointment(appointmentsWithStatus[0]);
        }

        // Pre-fetch insurance data for all unique patients (for carrier filter)
        const uniquePatientIds = [...new Set(appointmentsWithStatus.map(a => a.patientId).filter(Boolean))];
        const insuranceMap = {};
        await Promise.allSettled(
          uniquePatientIds.map(async (pid) => {
            try {
              const patientData = await EyefinityService.getPatientById(pid, activeCompany?.id);
              if (patientData?.insurances?.length > 0) {
                const primary = patientData.insurances.find(i => i.isPrimary) || patientData.insurances[0];
                insuranceMap[pid] = primary.companyName || 'Unknown';
              } else {
                insuranceMap[pid] = 'None';
              }
            } catch { insuranceMap[pid] = 'Unknown'; }
          })
        );
        setPatientInsuranceCache(prev => ({ ...prev, ...insuranceMap }));
      }
    } catch (err) {
      setError(err.message || 'Failed to load appointments');
      console.error('Error loading appointments:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadPatientDetails = async (patientId) => {
    setLoadingPatientData(true);
    console.log('[PRC] Loading patient details for:', patientId);
    
    // Reset patient data
    setPatientDetails(null);
    setPatientInsurance(null);
    setPatientRx([]);
    setPatientAppointments([]);
    setFullPatientResponse(null);
    setFullRxResponse(null);
    setFullOrdersResponse(null);
    setFullAppointmentsResponse(null);
    setApiErrors({});

    // Set all loading states
    setApiLoadingStates({
      patient: true,
      rx: true,
      orders: true,
      appointments: true
    });

    try {
      // Fetch all patient data in parallel
      // Note: Insurance data is included in patient demographics (insurances array)
      const [demographics, rx, orders, appointments] = await Promise.allSettled([
        EyefinityService.getPatientById(patientId, activeCompany?.id),
        EyefinityService.getPatientRx(patientId, 1, 100, activeCompany?.id),
        EyefinityService.getPatientOrders(patientId, { companyId: activeCompany?.id }),
        EyefinityService.getAppointments({ patientId, pageSize: 50, companyId: activeCompany?.id })
      ]);

      // Update loading states and handle responses
      setApiLoadingStates(prev => ({ ...prev, patient: false }));
      if (demographics.status === 'fulfilled') {
        console.log('[PRC] Patient demographics:', demographics.value);
        setFullPatientResponse(demographics.value);
        setPatientDetails(demographics.value);
        // Insurance is included in patient data
        if (demographics.value?.insurances) {
          console.log('[PRC] Patient insurance from demographics:', demographics.value.insurances);
          setPatientInsurance(demographics.value.insurances);
        }
      } else {
        console.warn('[PRC] Failed to load demographics:', demographics.reason);
        setApiErrors(prev => ({ ...prev, patient: demographics.reason }));
      }

      setApiLoadingStates(prev => ({ ...prev, rx: false }));
      if (rx.status === 'fulfilled') {
        const rxItems = rx.value?.items || rx.value || [];
        console.log('[PRC] Patient Rx:', rxItems);
        setFullRxResponse(rx.value);
        setPatientRx(Array.isArray(rxItems) ? rxItems : []);
      } else {
        console.warn('[PRC] Failed to load Rx:', rx.reason);
        setApiErrors(prev => ({ ...prev, rx: rx.reason }));
      }

      setApiLoadingStates(prev => ({ ...prev, orders: false }));
      if (orders.status === 'fulfilled') {
        console.log('[PRC] Patient Orders:', orders.value);
        setFullOrdersResponse(orders.value);
      } else {
        console.warn('[PRC] Failed to load Orders:', orders.reason);
        setApiErrors(prev => ({ ...prev, orders: orders.reason }));
      }

      setApiLoadingStates(prev => ({ ...prev, appointments: false }));
      if (appointments.status === 'fulfilled') {
        const appointmentItems = appointments.value?.items || appointments.value || [];
        console.log('[PRC] Patient appointments:', appointmentItems);
        setFullAppointmentsResponse(appointments.value);
        setPatientAppointments(Array.isArray(appointmentItems) ? appointmentItems : []);
      } else {
        console.warn('[PRC] Failed to load appointments:', appointments.reason);
        setApiErrors(prev => ({ ...prev, appointments: appointments.reason }));
      }
    } catch (err) {
      console.error('[PRC] Error loading patient details:', err);
    } finally {
      setLoadingPatientData(false);
    }
  };

  const handleStatusChange = (appointmentId, newStatus) => {
    setAppointmentStatus(appointmentId, newStatus);
    setAppointments(prev => prev.map(apt => 
      apt.id === appointmentId 
        ? { ...apt, readinessStatus: newStatus }
        : apt
    ));
    if (selectedAppointment?.id === appointmentId) {
      setSelectedAppointment(prev => ({ ...prev, readinessStatus: newStatus }));
    }
  };

  // Compute unique insurance carriers for the filter dropdown
  const availableCarriers = useMemo(() => {
    const carriers = new Set();
    Object.values(patientInsuranceCache).forEach(carrier => {
      if (carrier && carrier !== 'Unknown') carriers.add(carrier);
    });
    return [...carriers].sort();
  }, [patientInsuranceCache]);

  const filteredAppointments = useMemo(() => {
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const cutoff = daysFilter > 0 ? new Date(now) : null;
    if (cutoff) cutoff.setDate(cutoff.getDate() + daysFilter);

    return appointments.filter(apt => {
      // Date filter — 0 means show all, otherwise only today through +N days
      if (cutoff && apt.date) {
        const aptDate = new Date(apt.date);
        aptDate.setHours(0, 0, 0, 0);
        if (aptDate < now || aptDate > cutoff) return false;
      }

      // Status filter
      if (statusFilter !== 'All') {
        const readiness = getAppointmentReadiness(apt.id);
        if (statusFilter === 'Complete' && !isPatientReady(apt.id)) return false;
        if (statusFilter === 'Insurance: Incomplete' && readiness.insurance !== 'incomplete') return false;
        if (statusFilter === 'Appointment: Incomplete' && readiness.appointment !== 'incomplete') return false;
        if (statusFilter === 'Forms: Incomplete' && readiness.forms !== 'incomplete') return false;
        if (statusFilter === 'Demographics: Incomplete' && readiness.demographics !== 'incomplete') return false;
      }

      // Insurance carrier filter
      if (insuranceCarrierFilter !== 'All' && apt.patientId) {
        const carrier = patientInsuranceCache[apt.patientId] || 'Unknown';
        if (insuranceCarrierFilter === 'None') {
          if (carrier !== 'None') return false;
        } else {
          if (!carrier.toLowerCase().includes(insuranceCarrierFilter.toLowerCase())) return false;
        }
      }

      // Text search
      if (searchTerm) {
        const name = (apt.patientName || apt.patient?.name || '').toLowerCase();
        if (!name.includes(searchTerm.toLowerCase())) return false;
      }

      return true;
    });
  }, [appointments, daysFilter, statusFilter, insuranceCarrierFilter, patientInsuranceCache, searchTerm]);

  const filteredTasks = useMemo(() => {
    if (!Array.isArray(tasks)) return [];
    let next = tasks;
    if (taskStatusFilter && taskStatusFilter !== 'all') {
      next = next.filter((task) => task.status === taskStatusFilter);
    }
    if (untitledTaskFilter === 'hide') {
      next = next.filter((task) => !isUntitledTask(task));
    }
    if (untitledTaskFilter === 'only') {
      next = next.filter((task) => isUntitledTask(task));
    }
    return next;
  }, [tasks, taskStatusFilter, untitledTaskFilter, isUntitledTask]);

  const untitledTaskCount = useMemo(() => {
    if (!Array.isArray(tasks)) return 0;
    return tasks.filter((t) => isUntitledTask(t)).length;
  }, [tasks, isUntitledTask]);

  const tableRows = useMemo(() => {
    const getTaskAppointmentId = (task) => {
      if (!task) return null;
      if (task.appointmentId) return String(task.appointmentId);
      if (task.metadata && task.metadata.appointmentId) return String(task.metadata.appointmentId);
      return null;
    };

    const getTaskSortDate = (task) => {
      const dateValue = task?.dueAt || task?.createdAt;
      const date = dateValue ? new Date(dateValue) : new Date(0);
      return Number.isNaN(date.getTime()) ? new Date(0) : date;
    };

    const getAppointmentSortDate = (apt) => {
      const datePart = apt?.date || '';
      const timePart = apt?.startTime || '00:00';
      const date = new Date(`${datePart}T${timePart}`);
      return Number.isNaN(date.getTime()) ? new Date(0) : date;
    };

    const tasksByAppointmentId = new Map();
    const unlinked = [];

    for (const task of filteredTasks) {
      const appointmentId = getTaskAppointmentId(task);
      if (appointmentId) {
        const existing = tasksByAppointmentId.get(appointmentId) || [];
        existing.push(task);
        tasksByAppointmentId.set(appointmentId, existing);
      } else {
        unlinked.push(task);
      }
    }

    for (const [key, bucket] of tasksByAppointmentId.entries()) {
      bucket.sort((a, b) => getTaskSortDate(a) - getTaskSortDate(b));
      tasksByAppointmentId.set(key, bucket);
    }
    unlinked.sort((a, b) => getTaskSortDate(a) - getTaskSortDate(b));

    const rows = [];

    if (worklistFilter === 'appointments') {
      const sortedAppointments = [...filteredAppointments].sort(
        (a, b) => getAppointmentSortDate(a) - getAppointmentSortDate(b)
      );
      for (const apt of sortedAppointments) {
        rows.push({ rowType: 'appointment', appointment: apt, sortDate: getAppointmentSortDate(apt), dim: false });
      }
      return rows;
    }

    if (worklistFilter === 'tasks') {
      const taskRows = [];
      for (const task of unlinked) {
        taskRows.push({ rowType: 'task', task, parentAppointmentId: null, sortDate: getTaskSortDate(task) });
      }
      for (const [appointmentId, bucket] of tasksByAppointmentId.entries()) {
        for (const task of bucket) {
          taskRows.push({ rowType: 'task', task, parentAppointmentId: appointmentId, sortDate: getTaskSortDate(task) });
        }
      }
      taskRows.sort((a, b) => a.sortDate - b.sortDate);
      return taskRows;
    }

    const topLevel = [];
    for (const apt of filteredAppointments) {
      topLevel.push({ type: 'appointment', sortDate: getAppointmentSortDate(apt), appointment: apt });
    }
    for (const task of unlinked) {
      topLevel.push({ type: 'task_unlinked', sortDate: getTaskSortDate(task), task });
    }
    topLevel.sort((a, b) => a.sortDate - b.sortDate);

    for (const item of topLevel) {
      if (item.type === 'appointment') {
        const appointmentId = String(item.appointment?.id);
        const linkedTasks = tasksByAppointmentId.get(appointmentId) || [];
        rows.push({ rowType: 'appointment', appointment: item.appointment, sortDate: item.sortDate, dim: false });
        for (const task of linkedTasks) {
          rows.push({ rowType: 'task', task, parentAppointmentId: appointmentId, sortDate: getTaskSortDate(task) });
        }
      } else {
        rows.push({ rowType: 'task', task: item.task, parentAppointmentId: null, sortDate: item.sortDate });
      }
    }

    return rows;
  }, [filteredAppointments, filteredTasks, worklistFilter]);

  const totalPages = Math.ceil(tableRows.length / rowsPerPage);
  const paginatedTableRows = tableRows.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);

  const worklistItems = useMemo(() => {
    const items = [];
    if (worklistFilter === 'appointments' || worklistFilter === 'all') {
      filteredAppointments.forEach((apt) => {
        items.push({
          id: apt.id,
          itemType: 'appointment',
          title: apt.patientName || 'Unknown Patient',
          subtitle: apt.appointmentType || apt.reason || 'General Visit',
          status: getAppointmentReadiness(apt.id),
          confirmed: apt.confirmedIndicator,
          isUrgent: apt.isUrgent,
          appointment: apt,
          sortDate: new Date(`${apt.date}T${apt.startTime || '00:00'}`),
        });
      });
    }
    if (worklistFilter === 'tasks' || worklistFilter === 'all') {
      tasks.forEach((task) => {
        items.push({
          id: task.id,
          itemType: 'task',
          title: task.title,
          subtitle: task.description || task.category || 'Manual Task',
          status: task.status,
          priority: task.priority,
          task,
          sortDate: task.dueAt ? new Date(task.dueAt) : new Date(task.createdAt),
        });
      });
    }
    return items.sort((a, b) => a.sortDate - b.sortDate);
  }, [filteredAppointments, tasks, worklistFilter]);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const openTaskModal = useCallback((defaults = {}) => {
    setEditingTaskId(null);
    setTaskForm(buildTaskFormState(defaults));
    setTaskError('');
    setShowTaskModal(true);
  }, []);

  const openTaskModalForTask = useCallback((task) => {
    if (!task) return;

    const due = task.dueAt ? new Date(task.dueAt) : null;
    const dueDate = due && !Number.isNaN(due.getTime()) ? due.toISOString().slice(0, 10) : '';
    const dueTime = due && !Number.isNaN(due.getTime()) ? due.toISOString().slice(11, 16) : '';

    setEditingTaskId(task.id);
    setTaskForm(buildTaskFormState({
      title: task.title || '',
      description: task.description || '',
      priority: task.priority || 'normal',
      status: task.status || 'pending',
      assignee: task.assignee || '',
      assignedToOffice: task.assignedToOffice || '',
      channel: task.channel || 'internal',
      category: task.category || '',
      dueDate,
      dueTime,
      appointmentId: task.appointmentId || task.metadata?.appointmentId || null,
      patientId: task.patientId || task.metadata?.patientId || null,
      patientName: task.patientName || task.metadata?.patientName || '',
      officeId: task.officeId || task.metadata?.officeId || '',
      providerName: task.providerName || task.metadata?.providerName || '',
      metadata: task.metadata || {},
      source: task.source,
    }));
    setTaskError('');
    setShowTaskModal(true);
  }, []);

  const closeTaskModal = useCallback(() => {
    setShowTaskModal(false);
    setEditingTaskId(null);
    setTaskForm(buildTaskFormState());
    setTaskError('');
  }, []);

  const buildAppointmentTaskDefaults = useCallback((apt) => {
    if (!apt) return {};
    return {
      title: `${apt.patientName || 'Patient'} - ${apt.appointmentType || 'Manual Task'}`,
      description: apt.reason || apt.notes?.[0]?.detail || '',
      priority: apt.isUrgent ? 'high' : 'normal',
      appointmentId: apt.id,
      patientId: apt.patientId,
      patientName: apt.patientName || '',
      officeId: selectedOffice,
      providerName: apt.providerName,
      dueDate: apt.date || '',
      dueTime: apt.startTime || '',
      metadata: {
        appointmentId: apt.id,
        appointmentDate: apt.date,
        appointmentType: apt.appointmentType,
        officeId: selectedOffice,
        providerId: apt.providerId,
      },
      channel: 'appointment_followup',
      category: 'appointment_followup',
      source: {
        type: 'appointment',
        appointmentId: apt.id,
        patientId: apt.patientId,
      },
    };
  }, [selectedOffice]);

  const handleTaskFieldChange = useCallback((field, value) => {
    setTaskForm((prev) => ({ ...prev, [field]: value }));
  }, []);

  const handleCreateTask = useCallback(async () => {
    if (!taskForm.title || !taskForm.title.trim()) {
      setTaskError('Task title is required');
      return;
    }
    
    if (taskForm.title.trim().length < 3) {
      setTaskError('Task title must be at least 3 characters');
      return;
    }

    const dueAt = taskForm.dueDate
      ? new Date(`${taskForm.dueDate}T${taskForm.dueTime || '09:00'}`).toISOString()
      : undefined;
    const reminderSeconds = taskForm.reminderMinutes
      ? Number(taskForm.reminderMinutes) * 60
      : undefined;

    const metadata = {
      ...taskForm.metadata,
      appointmentId: taskForm.appointmentId,
      patientId: taskForm.patientId,
      patientName: taskForm.patientName,
      officeId: taskForm.officeId || selectedOffice,
      providerName: taskForm.providerName,
    };

    const payload = {
      title: taskForm.title.trim(),
      description: taskForm.description,
      priority: taskForm.priority,
      status: taskForm.status,
      assignee: taskForm.assignee || undefined,
      assignedToOffice: taskForm.assignedToOffice || selectedOffice || undefined,
      createdBy: currentUser?.id || currentUser?.email,
      createdByName: currentUser?.name || currentUser?.email || 'Unknown User',
      channel: taskForm.channel,
      category: taskForm.category || (taskForm.appointmentId ? 'appointment_followup' : 'manual'),
      metadata,
      source: taskForm.source || {
        type: taskForm.appointmentId ? 'appointment' : 'manual',
        appointmentId: taskForm.appointmentId,
        patientId: taskForm.patientId,
      },
      ...(dueAt ? { dueAt } : {}),
    };

    setTaskSubmitting(true);
    setTaskError('');
    try {
      if (editingTaskId) {
        const updates = {
          title: payload.title,
          description: payload.description,
          priority: payload.priority,
          status: payload.status,
          assignee: payload.assignee,
          assignedToOffice: payload.assignedToOffice,
          channel: payload.channel,
          category: payload.category,
          metadata: payload.metadata,
          ...(dueAt ? { dueAt } : {}),
        };
        await TaskService.updateTask(editingTaskId, updates);
      } else {
        await TaskService.createTask(payload, reminderSeconds ? { reminderInSeconds: reminderSeconds } : undefined);
      }
      closeTaskModal();
      await refreshTasks();
    } catch (err) {
      console.error('[PRC] Failed to create task', err);
      setTaskError(err.message || 'Failed to create task');
    } finally {
      setTaskSubmitting(false);
    }
  }, [taskForm, selectedOffice, closeTaskModal, refreshTasks, editingTaskId]);

  const handleCompleteTask = useCallback(async (taskId) => {
    if (!taskId) return;
    try {
      await TaskService.updateTask(taskId, { status: 'completed' });
      await refreshTasks();
    } catch (err) {
      console.error('[PRC] Failed to complete task', err);
    }
  }, [refreshTasks]);

  // Get unread message count for a patient
  const getUnreadCount = (patientId) => {
    const comms = CommunicationService.getPatientCommunications(patientId);
    return comms.filter(m => m.direction === 'inbound' && !m.read).length;
  };

  // Get readiness status for an appointment
  const getReadinessStatus = (apt) => {
    const readiness = getAppointmentReadiness(apt.id);
    return {
      ...readiness,
      isComplete: isPatientReady(apt.id),
      filterCategory: getReadinessFilter(apt.id),
    };
  };

  // Toggle a readiness item and refresh state
  const toggleReadinessItem = (appointmentId, item) => {
    const current = getAppointmentReadiness(appointmentId);
    const newValue = current[item] === 'complete' ? 'incomplete' : 'complete';
    setAppointmentReadiness(appointmentId, { [item]: newValue });
    // Force re-render
    setAppointments(prev => [...prev]);
    if (selectedAppointment?.id === appointmentId) {
      setSelectedAppointment(prev => ({ ...prev, _readinessUpdated: Date.now() }));
    }
  };

  // Mark a readiness item as complete
  const markAsComplete = (appointmentId, item) => {
    setAppointmentReadiness(appointmentId, { [item]: 'complete' });
    setAppointments(prev => [...prev]);
    if (selectedAppointment?.id === appointmentId) {
      setSelectedAppointment(prev => ({ ...prev, _readinessUpdated: Date.now() }));
    }
  };

  // Open EPM popup windows
  const openEpmPopup = (page, patientId, appointmentId) => {
    // Debug patient ID values
    console.log('[EPM Popup] DEBUG - Patient ID values:', {
      passedPatientId: patientId,
      selectedAppointmentPatientId: selectedAppointment?.patientId,
      patientDetailsLegacyId: patientDetails?.PatientLegacyId,
      patientDetailsPatientId: patientDetails?.PatientId,
      patientDetailsId: patientDetails?.id
    });
    
    // Use company's eyefinity_base_url from DB, fall back to environment lookup
    let baseUrl;
    const companyBaseUrl = activeCompany?.eyefinity_base_url;
    if (companyBaseUrl) {
      // DB value already includes /EPM if needed (e.g. "https://pm-sb.eyefinity.com/EPM")
      baseUrl = `${companyBaseUrl.replace(/\/+$/, '')}/Patient`;
    } else {
      const settings = AdminSettingsService.getSettings();
      const env = settings?.company?.apiEnvironment || 'integration';
      const environments = getAvailableEnvironments();
      const uiBaseUrl = environments?.[env]?.uiBaseUrl || 'https://pm-ci.eyefinity.com';
      baseUrl = env === 'sandbox' ? `${uiBaseUrl}/Patient` : `${uiBaseUrl}/EPM/Patient`;
    }
    const urls = {
      appointment: `${baseUrl}/Appointments?id=${patientId}&appointmentId=${appointmentId}`,
      insurance: `${baseUrl}/Insurance?id=${patientId}`,
      demographics: `${baseUrl}/overview?id=${patientId}`,
      forms: `${baseUrl}/Documents?id=${patientId}`,
    };
    const url = urls[page];
    if (url) {
      console.log('[EPM Popup] Opening', { page, baseUrl, patientId, appointmentId, url, source: companyBaseUrl ? 'company_db' : 'env_lookup' });
      window.open(url, `epm_${page}`, 'width=1200,height=800,scrollbars=yes,resizable=yes');
    }
  };

  // Insurance Benefit Verification
  const handleVerifyBenefits = async (appointment, patient) => {
    if (!appointment || !patient) return;

    const insurance = patient.insurances?.find(i => i.isPrimary && i.isActive) || patient.insurances?.[0];
    if (!insurance) {
      alert('No active insurance found for this patient. Select insurance first.');
      return;
    }

    // Map carrier name to payer type
    const carrierMap = {
      'vsp': 'vsp', 'vision service plan': 'vsp',
      'eyemed': 'eyemed', 'davis vision': 'davis-vision',
      'spectera': 'spectera', 'superior vision': 'superior-vision',
    };
    const carrierLower = (insurance.companyName || '').toLowerCase();
    const payerType = Object.entries(carrierMap).find(([key]) => carrierLower.includes(key))?.[1];

    if (!payerType) {
      alert(`Automated verification not yet supported for "${insurance.companyName}". Supported: VSP, EyeMed, Davis Vision, Spectera, Superior Vision.`);
      return;
    }

    setVerificationLoading(true);
    setVerificationResult(null);

    try {
      const baseUrl = import.meta.env.VITE_APP_URL || '';
      const response = await fetch(`${baseUrl}/api/insurance-verification/queue-job`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientId: patient.id || patient.PatientId,
          appointmentId: appointment.id,
          payerType,
          memberId: insurance.insuranceIdentificationNumber || insurance.policyNumber || '',
          subscriberDob: patient.dateOfBirth || patient.DateOfBirth,
          patientDob: patient.dateOfBirth || patient.DateOfBirth,
          triggeredBy: 'manual',
        }),
      });

      const data = await response.json();

      if (data.status === 'cached') {
        setVerificationResult(data.result);
        setVerificationLoading(false);
      } else if (data.jobId) {
        setVerificationJobId(data.jobId);
        pollVerificationStatus(data.jobId);
      } else {
        throw new Error(data.error || 'Failed to queue verification');
      }
    } catch (err) {
      console.error('[Verification] Error:', err);
      alert(`Verification failed: ${err.message}`);
      setVerificationLoading(false);
    }
  };

  const pollVerificationStatus = async (jobId) => {
    const baseUrl = import.meta.env.VITE_APP_URL || '';
    const maxPolls = 60; // 5 minutes at 5s intervals

    for (let i = 0; i < maxPolls; i++) {
      await new Promise(r => setTimeout(r, 5000));

      try {
        const res = await fetch(`${baseUrl}/api/insurance-verification/job-status?jobId=${jobId}`);
        const data = await res.json();

        if (data.job?.status === 'completed' && data.result) {
          setVerificationResult(data.result);
          setVerificationLoading(false);
          setMfaRequired(null);
          return;
        }

        if (data.job?.status === 'mfa_waiting') {
          setMfaRequired({ jobId, payerType: data.job.payerType });
          continue;
        }

        if (data.job?.status === 'failed') {
          throw new Error(data.job.lastError || 'Verification failed');
        }
      } catch (err) {
        console.error('[Verification] Poll error:', err);
        alert(`Verification failed: ${err.message}`);
        setVerificationLoading(false);
        return;
      }
    }

    setVerificationLoading(false);
    alert('Verification timed out. The worker may still be processing - check back later.');
  };

  const submitMfaCode = async () => {
    if (!mfaRequired?.jobId || !mfaCode) return;

    try {
      const baseUrl = import.meta.env.VITE_APP_URL || '';
      await fetch(`${baseUrl}/api/insurance-verification/mfa-relay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobId: mfaRequired.jobId, mfaCode }),
      });
      setMfaCode('');
      // Keep polling - the worker will resume
    } catch (err) {
      console.error('[MFA] Submit error:', err);
    }
  };

  // Load verification results when patient changes
  useEffect(() => {
    if (!selectedAppointment?.id) {
      setVerificationResult(null);
      return;
    }
    const loadVerification = async () => {
      try {
        const baseUrl = import.meta.env.VITE_APP_URL || '';
        const res = await fetch(`${baseUrl}/api/insurance-verification/results?appointmentId=${selectedAppointment.id}`);
        const data = await res.json();
        if (data.results?.length > 0) {
          setVerificationResult(data.results[0]);
        } else {
          setVerificationResult(null);
        }
      } catch {
        // Silent fail - verification results are optional
      }
    };
    loadVerification();
  }, [selectedAppointment?.id]);

  // Format date for display
  const formatDate = (dateStr) => {
    if (!dateStr) return 'N/A';
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString('en-US', { month: 'numeric', day: 'numeric', year: 'numeric' });
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="h-screen overflow-hidden bg-[#F7F7F7]">
      {/* Consolidated App Header */}
      <AppHeader 
        escalations={escalations}
        onAIMonitor={() => setShowAIPerformanceMonitor(true)}
        onManageQueue={() => setShowEscalationQueue(true)}
        onAcknowledgeEscalation={handleAcknowledgeEscalation}
        onResolveEscalation={handleResolveEscalation}
      />

      {/* Main Content */}
      <div className="flex-1 overflow-auto px-3 py-4">

        {/* Toolbar — all filters on one line */}
        <div className="bg-[#F7F7F7] border border-[#CCCCCC] rounded-t-[3px] px-3 py-2 mb-0">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-4 flex-wrap">
              {/* Office */}
              <div className="flex items-center gap-1.5">
                <Building2 size={12} className="text-gray-400 shrink-0" />
                <select
                  value={selectedOffice}
                  onChange={(e) => setSelectedOffice(e.target.value)}
                  className="h-[28px] px-2 text-xs border border-[#CED4DA] rounded-[3px] bg-white min-w-[140px]"
                >
                  <option value="">Select Office</option>
                  {offices.map(office => (
                    <option key={office.id} value={office.id}>
                      {office.officeName || office.name || `Office ${office.officeId}`}
                    </option>
                  ))}
                </select>
              </div>

              <div className="w-px h-5 bg-[#CED4DA]" />

              {/* Display Days */}
              <select
                value={daysFilter}
                onChange={(e) => setDaysFilter(Number(e.target.value))}
                className="h-[28px] px-2 text-xs border border-[#CED4DA] rounded-[3px] bg-white"
              >
                <option value={0}>Show All</option>
                <option value={2}>Next 2 Days</option>
                <option value={7}>Next 7 Days</option>
                <option value={14}>Next 14 Days</option>
                <option value={30}>Next 30 Days</option>
                <option value={90}>Next 90 Days</option>
              </select>

              {/* Status */}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="h-[28px] px-2 text-xs border border-[#CED4DA] rounded-[3px] bg-white"
              >
                <option value="All">Status: All</option>
                <option value="Complete">Complete</option>
                <option value="Insurance: Incomplete">Insurance: Incomplete</option>
                <option value="Appointment: Incomplete">Appointment: Incomplete</option>
                <option value="Forms: Incomplete">Forms: Incomplete</option>
                <option value="Demographics: Incomplete">Demographics: Incomplete</option>
              </select>

              {/* Insurance Carrier */}
              <select
                value={insuranceCarrierFilter}
                onChange={(e) => setInsuranceCarrierFilter(e.target.value)}
                className="h-[28px] px-2 text-xs border border-[#CED4DA] rounded-[3px] bg-white"
              >
                <option value="All">Carrier: All</option>
                <option value="None">No Insurance</option>
                {availableCarriers.map(carrier => (
                  <option key={carrier} value={carrier}>{carrier}</option>
                ))}
              </select>

              {/* Clear Filters */}
              {(statusFilter !== 'All' || insuranceCarrierFilter !== 'All' || daysFilter !== 0) && (
                <button
                  onClick={() => { setStatusFilter('All'); setInsuranceCarrierFilter('All'); setDaysFilter(0); }}
                  className="h-[28px] px-2 text-xs text-[#006FB4] hover:bg-[#E6F2FC] rounded flex items-center gap-1"
                >
                  <X size={12} /> Clear
                </button>
              )}

              {/* Count */}
              {selectedOffice && (
                <span className="text-[10px] text-gray-400">
                  {filteredAppointments.length}/{appointments.length}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => openTaskModal()}
                className="px-3 py-1.5 bg-[#277FC1] text-white text-xs rounded flex items-center gap-1 shadow-sm hover:bg-[#1c6aa5]"
              >
                <Plus size={12} /> New Task
              </button>
              {selectedAppointment && (
                <button
                  onClick={() => openTaskModal(buildAppointmentTaskDefaults(selectedAppointment))}
                  className="px-3 py-1.5 border border-[#277FC1] text-[#277FC1] text-xs rounded flex items-center gap-1 hover:bg-[#E6F2FC]"
                >
                  <ListChecks size={12} /> From Appt
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Main Grid Layout */}
        <div className="flex gap-0 h-[calc(100vh-205px)] overflow-hidden">
          {/* Left Side - Table */}
          <div className="w-[40%] min-w-0 flex flex-col overflow-hidden">
            <div className="flex items-center justify-between border border-[#CCCCCC] border-t-0 px-3 py-2" style={{ background: 'linear-gradient(180deg, #FAFAFA 0%, #E7E7E7 100%)' }}>
              <div className="flex items-center gap-2">
                {['all', 'appointments', 'tasks'].map((filter) => (
                  <button
                    key={filter}
                    onClick={() => handleWorklistFilterChange(filter)}
                    className={`px-3 py-1 rounded-full text-xs font-medium border ${
                      worklistFilter === filter
                        ? 'bg-[#277FC1] text-white border-[#277FC1]'
                        : 'bg-white text-gray-600 border-gray-200'
                    }`}
                  >
                    {filter === 'all' ? 'All' : filter.charAt(0).toUpperCase() + filter.slice(1)}
                  </button>
                ))}
                <select
                  value={taskStatusFilter}
                  onChange={(e) => { setTaskStatusFilter(e.target.value); setCurrentPage(1); }}
                  disabled={worklistFilter === 'appointments'}
                  className={`h-[26px] px-2 text-xs border border-[#CED4DA] rounded-[3px] bg-white ${worklistFilter === 'appointments' ? 'opacity-60 cursor-not-allowed' : ''}`}
                >
                  <option value="all">Tasks: All</option>
                  <option value="pending">Tasks: Pending</option>
                  <option value="in_progress">Tasks: In Progress</option>
                  <option value="completed">Tasks: Completed</option>
                  <option value="blocked">Tasks: Blocked</option>
                </select>

                <select
                  value={untitledTaskFilter}
                  onChange={(e) => { setUntitledTaskFilter(e.target.value); setCurrentPage(1); }}
                  disabled={worklistFilter === 'appointments'}
                  className={`h-[26px] px-2 text-xs border border-[#CED4DA] rounded-[3px] bg-white ${worklistFilter === 'appointments' ? 'opacity-60 cursor-not-allowed' : ''}`}
                >
                  <option value="all">Untitled: All</option>
                  <option value="hide">Untitled: Hide</option>
                  <option value="only">Untitled: Only</option>
                </select>

                {untitledTaskCount > 0 && worklistFilter !== 'appointments' && (
                  <button
                    onClick={() => {
                      handleWorklistFilterChange('tasks');
                      setTaskStatusFilter('all');
                      setUntitledTaskFilter('only');
                    }}
                    className="h-[26px] px-3 text-xs rounded-[3px] border border-purple-200 bg-purple-50 text-purple-700 hover:bg-purple-100"
                    title="Show only tasks missing a title"
                  >
                    Review Untitled ({untitledTaskCount})
                  </button>
                )}
                {tasksLoading && worklistFilter !== 'appointments' && (
                  <span className="text-[10px] text-gray-500 flex items-center gap-1">
                    <RefreshCw size={12} className="animate-spin" /> Loading tasks...
                  </span>
                )}
              </div>
              <div className="text-xs text-gray-500 flex items-center gap-3">
                <span className="flex items-center gap-1"><ListChecks size={12} /> {tableRows.length} item(s)</span>
                {queueStats && (
                  <span className="text-gray-500">Queue: <span className="font-medium text-gray-800">{queueStats.queueLength ?? 0}</span> | Scheduled: <span className="font-medium text-gray-800">{queueStats.scheduledLength ?? 0}</span></span>
                )}
              </div>
            </div>
            {/* Table Header */}
            <div className="flex border border-[#CCCCCC] border-t-0" style={{ background: 'linear-gradient(180deg, #FAFAFA 0%, #E7E7E7 100%)' }}>
              <div className="w-[16%] p-2 border-r border-[#CCCCCC]">
                <span className="text-xs font-bold text-black">Patient</span>
                <ChevronDown size={10} className="inline ml-1" />
              </div>
              <div className="w-[14%] p-2 border-r border-[#CCCCCC]">
                <span className="text-xs font-bold text-black">Appt Time</span>
                <ChevronDown size={10} className="inline ml-1" />
              </div>
              <div className="w-[10%] p-2 border-r border-[#CCCCCC]">
                <span className="text-xs font-bold text-black">Confirmed</span>
              </div>
              <div className="w-[12%] p-2 border-r border-[#CCCCCC]">
                <span className="text-xs font-bold text-black">Readiness</span>
              </div>
              <div className="w-[18%] p-2 border-r border-[#CCCCCC]">
                <span className="text-xs font-bold text-black">Journey</span>
                <Route size={10} className="inline ml-1" />
              </div>
              <div className="w-[16%] p-2 border-r border-[#CCCCCC]">
                <span className="text-xs font-bold text-black">Service</span>
              </div>
              <div className="w-[14%] p-2">
                <span className="text-xs font-bold text-black">Provider</span>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto">
              {/* Table Body */}
              {loading ? (
                <div className="p-8 text-center text-gray-500 border border-[#CCCCCC] border-t-0">
                  <RefreshCw size={24} className="animate-spin mx-auto mb-2" />
                  Loading appointments...
                </div>
              ) : paginatedTableRows.length === 0 ? (
                <div className="p-8 text-center text-gray-500 border border-[#CCCCCC] border-t-0">
                  No appointments found. Select an office to load appointments.
                </div>
              ) : (
                paginatedTableRows.map((row) => {
                if (row.rowType === 'task') {
                  if (worklistFilter === 'appointments') return null;
                  const task = row.task;
                  const dueText = task?.dueAt ? new Date(task.dueAt).toLocaleString() : '';
                  const createdText = task?.createdAt ? new Date(task.createdAt).toLocaleString() : '';
                  const taskWhen = dueText || createdText || '—';
                  const title = task?.title || 'Untitled Task';
                  const subtitle = task?.category || task?.channel || '';
                  const patientName = task?.metadata?.patientName || task?.patientName || '';
                  const canComplete = task?.status && task.status !== 'completed';

                  return (
                    <div
                      key={`task_${task?.id}`}
                      onClick={() => openTaskModalForTask(task)}
                      className={`flex border border-[#CCCCCC] border-t-0 cursor-pointer ${row.parentAppointmentId ? 'bg-[#FAFBFF]' : 'bg-white'} hover:bg-[#F7FBFF]`}
                    >
                      <div className="w-[16%] p-2 border-r border-[#CCCCCC]">
                        <div className={`text-xs font-semibold text-[#5B21B6] ${row.parentAppointmentId ? 'pl-4' : ''}`}>{title}</div>
                        {patientName && <div className="text-[10px] text-gray-500 truncate">{patientName}</div>}
                      </div>
                      <div className="w-[14%] p-2 border-r border-[#CCCCCC] text-xs text-gray-700">
                        {taskWhen}
                      </div>
                      <div className="w-[10%] p-2 border-r border-[#CCCCCC]">
                        <span className="text-[10px] px-2 py-0.5 rounded bg-gray-100 text-gray-700">{task?.priority || 'normal'}</span>
                      </div>
                      <div className="w-[12%] p-2 border-r border-[#CCCCCC]">
                        <span className="text-[10px] px-2 py-0.5 rounded bg-purple-100 text-purple-700">{task?.status || 'pending'}</span>
                      </div>
                      <div className="w-[18%] p-2 border-r border-[#CCCCCC]">
                        <div className="flex items-center justify-between gap-2">
                          {subtitle ? <div className="text-xs text-gray-700 truncate">{subtitle}</div> : <div className="text-xs text-gray-400">—</div>}
                          {canComplete && (
                            <button
                              onClick={(e) => { e.stopPropagation(); handleCompleteTask(task?.id); }}
                              className="text-[10px] px-2 py-0.5 rounded bg-green-100 text-green-700 hover:bg-green-200"
                              title="Mark complete"
                            >
                              Complete
                            </button>
                          )}
                        </div>
                      </div>
                      <div className="w-[16%] p-2 border-r border-[#CCCCCC]">
                        <div className="text-xs text-gray-700 truncate">{task?.channel || task?.category || '—'}</div>
                      </div>
                      <div className="w-[14%] p-2">
                        <div className="text-xs text-gray-700 truncate">{task?.assignee || 'Unassigned'}</div>
                      </div>
                    </div>
                  );
                }

                const apt = row.appointment;
                const isSelected = selectedAppointment?.id === apt.id;
                const readiness = getReadinessStatus(apt);
                const journey = patientJourneys[apt.patientId];
                const journeyStatus = getJourneyStatusDisplay(journey);
                const isJourneyLoading = journeyLoading[apt.patientId];
                
                return (
                  <div 
                    key={apt.id}
                    onClick={() => setSelectedAppointment(apt)}
                    className={`flex border border-[#CCCCCC] border-t-0 cursor-pointer hover:bg-[#E6F2FC] ${isSelected ? 'bg-[#E6F2FC]' : 'bg-white'} ${row.dim ? 'opacity-60' : ''}`}
                  >
                    <div className="w-[16%] p-2 border-r border-[#CCCCCC] text-xs truncate">
                      <div className="font-medium flex items-center gap-1">
                        {apt.patientName || 'Unknown'}
                        {getUnreadCount(apt.patientId) > 0 && (
                          <span className="flex items-center gap-0.5 text-red-500" title={`${getUnreadCount(apt.patientId)} unread message(s)`}>
                            <MessageSquare size={10} className="fill-red-500" />
                            <span className="text-[8px] font-bold">{getUnreadCount(apt.patientId)}</span>
                          </span>
                        )}
                      </div>
                      {apt.isUrgent && <span className="text-red-500 text-[9px]">⚠️ URGENT</span>}
                    </div>
                    <div className="w-[14%] p-2 border-r border-[#CCCCCC] text-xs">
                      <div>{formatDate(apt.date)}</div>
                      <div className="text-gray-600">{apt.startTime}</div>
                    </div>
                    <div className="w-[10%] p-2 border-r border-[#CCCCCC] text-xs">
                      <span className={`text-[9px] px-1.5 py-0.5 rounded ${
                        apt.confirmedIndicator === 'Confirmed' ? 'bg-green-100 text-green-700' :
                        apt.confirmedIndicator === 'LeftMessage' ? 'bg-yellow-100 text-yellow-700' :
                        apt.confirmedIndicator === 'Cancelled' ? 'bg-red-100 text-red-700' :
                        'bg-gray-100 text-gray-600'
                      }`}>
                        {apt.confirmedIndicator || 'None'}
                      </span>
                    </div>
                    <div className="w-[12%] p-2 border-r border-[#CCCCCC] text-xs relative">
                      {readiness.isComplete ? (
                        <span className="bg-[#22653B] text-white text-[9px] px-2 py-0.5 rounded-[3px] uppercase">
                          Ready
                        </span>
                      ) : (
                        <div className="text-[9px] leading-[12px] text-[#222222]">
                          {readiness.insurance === 'incomplete' && <div className="text-orange-600">• Ins</div>}
                          {readiness.demographics === 'incomplete' && <div className="text-orange-600">• Demo</div>}
                          {readiness.forms === 'incomplete' && <div className="text-orange-600">• Forms</div>}
                        </div>
                      )}
                      {/* Payment Method Indicator */}
                      {(() => {
                        const pm = getAppointmentPaymentMethod(apt.id);
                        if (pm?.type === 'private_pay') {
                          return <div className="text-orange-600 text-[8px] font-bold mt-0.5">💵 PRIVATE</div>;
                        }
                        if (pm?.type === 'other') {
                          return <div className="text-purple-600 text-[8px] font-bold mt-0.5">📋 OTHER</div>;
                        }
                        if (pm?.type === 'insurance') {
                          return <div className="text-blue-600 text-[8px] mt-0.5 truncate" title={pm.insuranceName}>{pm.insuranceName}</div>;
                        }
                        return null;
                      })()}
                    </div>
                    <div className="w-[18%] p-2 border-r border-[#CCCCCC] text-xs">
                      {journeyStatus ? (
                        <div
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedAppointment(apt);
                            setShowInlineJourney(true);
                            setTimeout(() => {
                              document.getElementById('prc-inline-journey')?.scrollIntoView({ behavior: 'smooth' });
                            }, 100);
                          }}
                          className="cursor-pointer"
                        >
                          <span className={`text-[9px] px-1.5 py-0.5 rounded ${journeyStatus.phaseColor}`}>
                            {journeyStatus.phase}
                          </span>
                          <div className="text-[9px] text-gray-500 mt-0.5 truncate" title={journeyStatus.currentStep}>
                            {journeyStatus.currentStep}
                          </div>
                          <div className="h-1 bg-gray-200 rounded mt-1">
                            <div className="h-full bg-blue-500 rounded" style={{ width: `${journeyStatus.progress}%` }} />
                          </div>
                        </div>
                      ) : (
                        <button
                          onClick={(e) => handleStartJourney(apt, e)}
                          disabled={isJourneyLoading}
                          className="flex items-center gap-1 text-[9px] px-2 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
                        >
                          {isJourneyLoading ? (
                            <RefreshCw size={10} className="animate-spin" />
                          ) : (
                            <PlayCircle size={10} />
                          )}
                          Start Journey
                        </button>
                      )}
                    </div>
                    <div className="w-[16%] p-2 border-r border-[#CCCCCC] text-xs truncate" title={apt.appointmentType || apt.reason}>
                      {apt.appointmentType || apt.reason || '—'}
                    </div>
                    <div className="w-[14%] p-2 text-xs truncate" title={apt.providerName}>
                      {apt.providerName || '—'}
                    </div>
                  </div>
                );
                })
              )}
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between py-3 text-xs bg-white border border-[#CCCCCC] border-t-0">
              <div className="flex items-center gap-2">
                <span>
                  Showing {tableRows.length === 0 ? 0 : (currentPage - 1) * rowsPerPage + 1} to {Math.min(currentPage * rowsPerPage, tableRows.length)} of {tableRows.length} entries
                </span>
                <span>Show</span>
                <select 
                  value={rowsPerPage}
                  onChange={(e) => { setRowsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                  className="border border-[#CCCCCC] rounded px-2 py-1"
                >
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>
              <div className="flex items-center">
                <button 
                  onClick={() => setCurrentPage(1)}
                  disabled={currentPage === 1}
                  className="px-3 py-1 border border-[#CCCCCC] rounded-l bg-white text-gray-400 disabled:text-gray-300"
                >
                  First
                </button>
                <button 
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="px-3 py-1 border border-[#CCCCCC] border-l-0 bg-white text-gray-400 disabled:text-gray-300"
                >
                  Previous
                </button>
                <span className="px-3 py-1 border border-[#277FC1] bg-[#277FC1] text-white">
                  {currentPage}
                </span>
                {totalPages > 1 && currentPage < totalPages && (
                  <span className="px-3 py-1 border border-[#CCCCCC] bg-white">
                    {currentPage + 1}
                  </span>
                )}
                <button 
                  onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages || totalPages === 0}
                  className="px-3 py-1 border border-[#CCCCCC] border-l-0 bg-white"
                >
                  Next
                </button>
                <button 
                  onClick={() => setCurrentPage(totalPages)}
                  disabled={currentPage === totalPages || totalPages === 0}
                  className="px-3 py-1 border border-[#CCCCCC] border-l-0 rounded-r bg-white"
                >
                  Last
                </button>
              </div>
            </div>
          </div>

          {/* Right Side - Patient Details Panel */}
          <div className="w-[60%] border border-[#CCCCCC] border-l-0 ml-0 overflow-y-auto">
            {selectedAppointment ? (
              <>
                {/* Patient Info Header - Single Row, No Wrap */}
                <div className="bg-[#F7F7F7] p-3 border-b border-[#CCCCCC] overflow-x-auto">
                  <div className="flex gap-4 flex-nowrap">
                    {/* Column 1: Patient Identity */}
                    <div className="text-sm min-w-[200px]">
                      <div className="font-bold text-[#222222] text-base mb-2 flex items-center gap-2">
                        {patientDetails?.title && <span className="text-gray-500">{patientDetails.title}</span>}
                        {patientDetails?.fullName || selectedAppointment.patientName || 'Patient Name'}
                        {patientDetails?.preferredName && <span className="text-gray-500 text-xs">("{patientDetails.preferredName}")</span>}
                      </div>
                      <div><span className="font-bold">Age:</span> {patientDetails?.age || '—'} <span className="text-gray-500">({formatDate(patientDetails?.dob)})</span></div>
                      <div><span className="font-bold">Gender:</span> {patientDetails?.gender === 'M' ? 'Male' : patientDetails?.gender === 'F' ? 'Female' : patientDetails?.gender || '—'}</div>
                      <div><span className="font-bold">Patient ID:</span> {patientDetails?.patientId || selectedAppointment.patientId}</div>
                      <div><span className="font-bold">Language:</span> {patientDetails?.preferredLanguage || 'English'}</div>
                    </div>
                    
                    {/* Column 2: Contact Info */}
                    <div className="text-xs min-w-[180px]">
                      <div className="font-bold text-[#222222] mb-1">Contact</div>
                      <div><span className="font-bold">Mobile:</span> {patientDetails?.mobilePhone || patientDetails?.phone || demoContact.phone}</div>
                      <div><span className="font-bold">Home:</span> {patientDetails?.homePhone || '—'}</div>
                      <div><span className="font-bold">Email:</span> {patientDetails?.email || '—'} {patientDetails?.isBadEmail && <span className="text-red-500 text-[9px]">(Bad)</span>}</div>
                      <div><span className="font-bold">Pref:</span> {patientDetails?.communicationPreference || 'Phone'}</div>
                      {patientDetails?.addresses?.[0] && (
                        <div className="mt-1 text-gray-600">
                          {patientDetails.addresses[0].address}, {patientDetails.addresses[0].city}, {patientDetails.addresses[0].state} {patientDetails.addresses[0].zipCode}
                        </div>
                      )}
                    </div>
                    
                    {/* Column 3: Appointment Details */}
                    <div className="text-xs min-w-[180px]">
                      <div className="font-bold text-[#222222] mb-1">Appointment</div>
                      <div><span className="font-bold">Date:</span> {formatDate(selectedAppointment.date)}</div>
                      <div><span className="font-bold">Time:</span> {selectedAppointment.startTime} - {selectedAppointment.endTime}</div>
                      <div><span className="font-bold">Provider:</span> {selectedAppointment.providerName || '—'}</div>
                      <div><span className="font-bold">Type:</span> {selectedAppointment.appointmentType || selectedAppointment.reason || '—'}</div>
                      <div><span className="font-bold">Status:</span> 
                        <span className={`ml-1 ${selectedAppointment.confirmedIndicator === 'Confirmed' ? 'text-green-600' : 'text-orange-500'}`}>
                          {selectedAppointment.confirmedIndicator || 'None'}
                        </span>
                      </div>
                      {selectedAppointment.isUrgent && <div className="text-red-600 font-bold">⚠️ URGENT</div>}
                    </div>
                    
                    {/* Column 4: Insurance & History */}
                    <div className="text-xs min-w-[200px]">
                      <div className="font-bold text-[#222222] mb-1">Insurance & History</div>
                      {patientDetails?.insurances?.[0] ? (
                        <>
                          <div><span className="font-bold">Plan:</span> {patientDetails.insurances[0].companyName}</div>
                          <div className="text-gray-600 truncate">{patientDetails.insurances[0].planName}</div>
                          <div><span className="font-bold">ID:</span> {patientDetails.insurances[0].insuranceIdentificationNumber}</div>
                        </>
                      ) : (
                        <div className="text-orange-500">No insurance on file</div>
                      )}
                      <div className="mt-1"><span className="font-bold">First Visit:</span> {formatDate(patientDetails?.firstVisit)}</div>
                      <div><span className="font-bold">Last Visit:</span> {formatDate(patientDetails?.lastVisit)}</div>
                      <div><span className="font-bold">Last Exam:</span> {formatDate(patientDetails?.lastExamDate)}</div>
                    </div>
                    
                    {/* Column 5: HIPAA & Notes */}
                    <div className="text-xs flex-1">
                      <div className="font-bold text-[#222222] mb-1">Compliance & Notes</div>
                      <div>
                        <span className="font-bold">HIPAA:</span> 
                        {patientDetails?.hipaaSignatureIsOnFile ? (
                          <span className="text-green-600 ml-1">✓ On File ({formatDate(patientDetails.hipaaSignatureDate)})</span>
                        ) : (
                          <span className="text-red-500 ml-1">Not on file</span>
                        )}
                      </div>
                      <div><span className="font-bold">Recall:</span> {patientDetails?.nextRecallDate ? formatDate(patientDetails.nextRecallDate) : 'None scheduled'}</div>
                      {selectedAppointment.notes?.length > 0 && (
                        <div className="mt-2">
                          <div className="font-bold">Appointment Notes:</div>
                          <div className="text-gray-600 text-[10px] max-h-[60px] overflow-y-auto">
                            {selectedAppointment.notes.map((note, idx) => (
                              <div key={idx} className={`${note.isUrgent ? 'text-red-600' : ''}`}>
                                • {note.detail} <span className="text-gray-400">({formatDate(note.date)})</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Additional Patient Flags Row */}
                  <div className="flex gap-2 mt-3 flex-wrap">
                    {patientDetails?.isInactive && <span className="bg-gray-500 text-white text-[9px] px-2 py-0.5 rounded">INACTIVE</span>}
                    {patientDetails?.isDeceased && <span className="bg-black text-white text-[9px] px-2 py-0.5 rounded">DECEASED</span>}
                    {patientDetails?.sendApptNotificationsViaText && <span className="bg-blue-100 text-blue-700 text-[9px] px-2 py-0.5 rounded">SMS Notifications</span>}
                    {patientDetails?.sendApptNotificationsViaEmail && <span className="bg-blue-100 text-blue-700 text-[9px] px-2 py-0.5 rounded">Email Notifications</span>}
                    {patientDetails?.emailRecall && <span className="bg-green-100 text-green-700 text-[9px] px-2 py-0.5 rounded">Email Recall OK</span>}
                    {selectedAppointment.showStatus && selectedAppointment.showStatus !== 'None' && (
                      <span className={`text-[9px] px-2 py-0.5 rounded ${
                        selectedAppointment.showStatus === 'Show' ? 'bg-green-500 text-white' :
                        selectedAppointment.showStatus === 'NoShow' ? 'bg-red-500 text-white' :
                        selectedAppointment.showStatus === 'CheckedOut' ? 'bg-blue-500 text-white' :
                        'bg-gray-200'
                      }`}>
                        {selectedAppointment.showStatus}
                      </span>
                    )}
                  </div>
                </div>

                {/* Patient Readiness Status - Two Column Layout */}
                <div className="px-4 py-3">
                  {(() => {
                    const readiness = getAppointmentReadiness(selectedAppointment.id);
                    const allComplete = isPatientReady(selectedAppointment.id);
                    
                    return (
                      <>
                        <div className="flex items-center justify-between mb-2">
                          <div className="font-bold text-sm text-[#222222] flex items-center gap-2">
                            Patient Readiness Status
                            {allComplete && <span className="bg-[#22653B] text-white text-[9px] px-2 py-0.5 rounded-[3px] uppercase">Ready</span>}
                          </div>
                          <div className="flex items-center gap-3">
                            <button
                              onClick={() => {
                                const patientId = selectedAppointment.patientId;
                                const companyId = activeCompany?.id;
                                if (!companyId) { alert('No company selected'); return; }
                                const payload = btoa(JSON.stringify({ patientId, companyId, type: 'frame-scanner', exp: Date.now() + 7 * 24 * 60 * 60 * 1000 }));
                                const link = `${window.location.origin}/patient/frame-scanner?token=${payload}`;
                                navigator.clipboard.writeText(link);
                                CommunicationService.sendSMS(
                                  patientId,
                                  `Hi! Try our Frame Finder to scan and save your favorite frames: ${link}`,
                                  currentUser?.name || 'Staff'
                                );
                                alert('Frame Scanner link sent and copied to clipboard!');
                              }}
                              className="text-xs text-purple-600 hover:underline flex items-center gap-1"
                              title="Send frame scanner link to patient"
                            >
                              <Camera size={10} /> Frames
                            </button>
                            <button
                              onClick={() => {
                                const patientId = selectedAppointment.patientId;
                                const companyId = activeCompany?.id;
                                if (!companyId) { alert('No company selected'); return; }
                                const payload = btoa(JSON.stringify({ patientId, companyId, type: 'frame-scanner', exp: Date.now() + 7 * 24 * 60 * 60 * 1000 }));
                                const link = `${window.location.origin}/patient/measurements?token=${payload}`;
                                navigator.clipboard.writeText(link);
                                CommunicationService.sendSMS(
                                  patientId,
                                  `Hi! Take your lens measurements from home: ${link}`,
                                  currentUser?.name || 'Staff'
                                );
                                alert('Measurement link sent and copied to clipboard!');
                              }}
                              className="text-xs text-indigo-600 hover:underline flex items-center gap-1"
                              title="Send measurement link to patient"
                            >
                              <Ruler size={10} /> Measure
                            </button>
                            <button
                              onClick={() => setShowSendFormModal(true)}
                              className="text-xs text-[#006FB4] hover:underline flex items-center gap-1"
                            >
                              <Send size={10} /> Send Form
                            </button>
                            <button
                              onClick={() => {
                                const apt = selectedAppointment;
                                const existingJourney = patientJourneys[apt.patientId];
                                let journey = existingJourney;

                                if (!journey) {
                                  // Create journey starting at in-office (check-in)
                                  journey = PatientJourneyService.createJourney({
                                    patientId: apt.patientId,
                                    patientName: apt.patientName || 'Unknown Patient',
                                    reasonForVisit: apt.appointmentType || apt.reason || 'Eye Exam',
                                    providerName: apt.providerName,
                                    priority: apt.isUrgent ? 'urgent' : 'normal',
                                    startPhase: 'in-office',
                                    scheduledAppointmentDate: new Date(apt.date),
                                    appointmentContext: {
                                      appointmentType: apt.appointmentType || apt.reason,
                                      isNewPatient: !apt.hasVisitHistory,
                                      officeId: selectedOffice,
                                      providerId: apt.providerId
                                    }
                                  });
                                  setPatientJourneys(prev => ({ ...prev, [apt.patientId]: journey }));
                                } else if (journey.journeyPhase === 'pre-visit') {
                                  // Transition existing pre-visit journey to in-office
                                  journey = PatientJourneyService.transitionPhase(journey.id, 'in-office');
                                  setPatientJourneys(prev => ({ ...prev, [apt.patientId]: journey }));
                                }

                                // Stay on PRC and show inline journey panel
                                setShowInlineJourney(true);
                                setTimeout(() => {
                                  document.getElementById('prc-inline-journey')?.scrollIntoView({ behavior: 'smooth' });
                                }, 100);
                              }}
                              className="text-xs text-green-700 hover:underline flex items-center gap-1 font-medium"
                              title="Check in patient and manage journey inline"
                            >
                              <PlayCircle size={10} /> Check In
                            </button>
                          </div>
                        </div>

                        {/* Two Column Grid: Left=Readiness, Right=Forms */}
                        <div className="flex gap-6">
                          {/* Left Column: Readiness Items */}
                          <div className="flex-1 space-y-1 text-xs">
                            {/* Appointment */}
                            <div className="flex items-center gap-2">
                              {readiness.appointment === 'complete' ? (
                                <CheckCircle size={12} className="text-[#62A420] flex-shrink-0" />
                              ) : (
                                <X size={12} className="text-red-500 flex-shrink-0" />
                              )}
                              <button 
                                onClick={() => openEpmPopup('appointment', patientDetails?.PatientLegacyId || selectedAppointment.patientId || patientDetails?.PatientId, selectedAppointment.id)}
                                className="font-bold text-[#006FB4] hover:underline"
                              >
                                Appointment:
                              </button>
                              <span className="truncate">
                                {readiness.appointment === 'complete' 
                                  ? `Confirmed ${formatDate(selectedAppointment.date)} | ${selectedAppointment.providerName || 'Provider'}`
                                  : 'Not confirmed'}
                              </span>
                              <button onClick={() => readiness.appointment === 'complete' ? toggleReadinessItem(selectedAppointment.id, 'appointment') : markAsComplete(selectedAppointment.id, 'appointment')} className="text-[#006FB4] ml-1">
                                {readiness.appointment === 'complete' ? 'Edit' : 'Confirm'}
                              </button>
                            </div>

                            {/* Insurance / Payment Method */}
                            <div className="flex items-center gap-2 flex-wrap">
                              {readiness.insurance === 'complete' ? (
                                <CheckCircle size={12} className="text-[#62A420] flex-shrink-0" />
                              ) : (
                                <X size={12} className="text-red-500 flex-shrink-0" />
                              )}
                              <button 
                                onClick={() => openEpmPopup('insurance', patientDetails?.PatientLegacyId || selectedAppointment.patientId || patientDetails?.PatientId)}
                                className="font-bold text-[#006FB4] hover:underline"
                              >
                                Insurance:
                              </button>
                              <select
                                value={(() => {
                                  const pm = getAppointmentPaymentMethod(selectedAppointment.id);
                                  if (!pm) return '';
                                  if (pm.type === 'private_pay') return 'private_pay';
                                  if (pm.type === 'other') return 'other';
                                  return `ins_${pm.insuranceIdx ?? pm.insuranceId ?? 0}`;
                                })()}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  if (val === 'private_pay') {
                                    setAppointmentPaymentMethod(selectedAppointment.id, { type: 'private_pay' });
                                    markAsComplete(selectedAppointment.id, 'insurance');
                                  } else if (val === 'other') {
                                    setAppointmentPaymentMethod(selectedAppointment.id, { type: 'other', otherDescription: 'Other payment' });
                                    markAsComplete(selectedAppointment.id, 'insurance');
                                  } else if (val.startsWith('ins_')) {
                                    const insIdx = parseInt(val.replace('ins_', ''));
                                    const ins = patientDetails?.insurances?.[insIdx];
                                    if (ins) {
                                      setAppointmentPaymentMethod(selectedAppointment.id, {
                                        type: 'insurance',
                                        insuranceIdx: insIdx,
                                        insuranceId: ins.insuranceId,
                                        insuranceName: ins.companyName,
                                        planName: ins.planName
                                      });
                                      markAsComplete(selectedAppointment.id, 'insurance');
                                    }
                                  }
                                  // Force re-render
                                  setSelectedAppointment(prev => ({ ...prev, _paymentUpdated: Date.now() }));
                                }}
                                className={`text-xs border rounded px-2 py-0.5 ${
                                  getAppointmentPaymentMethod(selectedAppointment.id)
                                    ? 'border-green-400 bg-green-50'
                                    : 'border-orange-300 bg-orange-50'
                                }`}
                              >
                                <option value="">-- Select Payment --</option>
                                {patientDetails?.insurances?.map((ins, idx) => (
                                  <option key={idx} value={`ins_${idx}`}>
                                    {ins.companyName} {ins.isPrimary ? '(Primary)' : ''} - {ins.planName}
                                  </option>
                                ))}
                                <option value="private_pay">Private Pay (Self-Pay)</option>
                                <option value="other">Other</option>
                              </select>
                              {(() => {
                                const pm = getAppointmentPaymentMethod(selectedAppointment.id);
                                if (pm?.type === 'private_pay') {
                                  return <span className="text-orange-600 text-[10px] font-bold bg-orange-100 px-1.5 py-0.5 rounded">PRIVATE PAY</span>;
                                }
                                if (pm?.type === 'other') {
                                  return <span className="text-purple-600 text-[10px] font-bold bg-purple-100 px-1.5 py-0.5 rounded">OTHER</span>;
                                }
                                return null;
                              })()}
                              <button
                                onClick={() => openEpmPopup('insurance', patientDetails?.PatientLegacyId || selectedAppointment.patientId || patientDetails?.PatientId)}
                                className="text-[#006FB4] ml-1 text-[10px]"
                              >
                                View All
                              </button>
                              <button
                                onClick={() => handleVerifyBenefits(selectedAppointment, patientDetails)}
                                className="text-white bg-[#006FB4] px-2 py-0.5 rounded text-[10px] font-bold ml-1 hover:bg-[#005a94] disabled:opacity-50"
                                disabled={verificationLoading}
                              >
                                {verificationLoading ? 'Verifying...' : 'Verify Benefits'}
                              </button>
                            </div>

                            {/* Benefit Verification Results */}
                            {verificationResult && (
                              <div className="ml-6 mt-1 p-2 bg-blue-50 rounded text-xs border border-blue-200">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className={verificationResult.isEligible ? 'text-green-600 font-bold' : 'text-red-600 font-bold'}>
                                    {verificationResult.isEligible ? 'ELIGIBLE' : 'NOT ELIGIBLE'}
                                  </span>
                                  <span className="text-gray-500">{(verificationResult.payerType || '').toUpperCase()}</span>
                                  <span className="text-gray-400 text-[10px]">
                                    {verificationResult.createdAt ? new Date(verificationResult.createdAt).toLocaleString() : ''}
                                  </span>
                                  {verificationResult.confidenceScore && (
                                    <span className={`text-[10px] px-1 rounded ${verificationResult.confidenceScore > 0.7 ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                      {Math.round(verificationResult.confidenceScore * 100)}% confidence
                                    </span>
                                  )}
                                </div>
                                <div className="grid grid-cols-2 gap-x-4 gap-y-0.5 text-gray-700">
                                  {verificationResult.benefits?.examCopay != null && <div>Exam Copay: <b>${verificationResult.benefits.examCopay}</b></div>}
                                  {verificationResult.benefits?.framesAllowance != null && <div>Frames Allowance: <b>${verificationResult.benefits.framesAllowance}</b></div>}
                                  {verificationResult.benefits?.framesCopay != null && <div>Frames Copay: <b>${verificationResult.benefits.framesCopay}</b></div>}
                                  {verificationResult.benefits?.lensesCopay != null && <div>Lenses Copay: <b>${verificationResult.benefits.lensesCopay}</b></div>}
                                  {verificationResult.benefits?.contactsAllowance != null && <div>Contacts Allowance: <b>${verificationResult.benefits.contactsAllowance}</b></div>}
                                  {verificationResult.benefits?.contactsCopay != null && <div>Contacts Copay: <b>${verificationResult.benefits.contactsCopay}</b></div>}
                                </div>
                                {verificationResult.planName && (
                                  <div className="mt-1 text-gray-400 text-[10px]">
                                    Plan: {verificationResult.planName}
                                    {verificationResult.eligibleDates?.exam && ` | Next Exam: ${verificationResult.eligibleDates.exam}`}
                                  </div>
                                )}
                              </div>
                            )}

                            {/* Demographics */}
                            <div className="flex items-center gap-2">
                              {readiness.demographics === 'complete' ? (
                                <CheckCircle size={12} className="text-[#62A420] flex-shrink-0" />
                              ) : (
                                <X size={12} className="text-red-500 flex-shrink-0" />
                              )}
                              <button 
                                onClick={() => openEpmPopup('demographics', patientDetails?.PatientLegacyId || selectedAppointment.patientId || patientDetails?.PatientId)}
                                className="font-bold text-[#006FB4] hover:underline"
                              >
                                Demographics:
                              </button>
                              <span>{readiness.demographics === 'complete' ? 'Review Complete' : 'Review needed'}</span>
                              <button onClick={() => readiness.demographics === 'complete' ? toggleReadinessItem(selectedAppointment.id, 'demographics') : markAsComplete(selectedAppointment.id, 'demographics')} className="text-[#006FB4] ml-1">
                                {readiness.demographics === 'complete' ? 'Edit' : 'Review'}
                              </button>
                            </div>

                            {/* Online Forms */}
                            <div className="flex items-center gap-2">
                              {readiness.forms === 'complete' ? (
                                <CheckCircle size={12} className="text-[#62A420] flex-shrink-0" />
                              ) : (
                                <X size={12} className="text-red-500 flex-shrink-0" />
                              )}
                              <button 
                                onClick={() => openEpmPopup('forms', patientDetails?.PatientLegacyId || selectedAppointment.patientId || patientDetails?.PatientId)}
                                className="font-bold text-[#006FB4] hover:underline"
                              >
                                Online Forms:
                              </button>
                              <span>
                                {readiness.forms === 'complete' ? 'Complete' : 'Pending'}
                                {patientForms.length > 0 && (
                                  <span className="text-gray-500 ml-1">({patientForms.filter(f => f.status === 'completed').length}/{patientForms.length})</span>
                                )}
                              </span>
                              {readiness.forms !== 'complete' && (
                                <button 
                                  onClick={() => markAsComplete(selectedAppointment.id, 'forms')} 
                                  className="text-[#006FB4] ml-1"
                                >
                                  Forms Complete
                                </button>
                              )}
                              <button onClick={() => readiness.forms === 'complete' ? toggleReadinessItem(selectedAppointment.id, 'forms') : setShowSendFormModal(true)} className="text-[#006FB4] ml-1">
                                {readiness.forms === 'complete' ? 'Edit' : 'Send'}
                              </button>
                            </div>

                            {/* FTC Rx Acknowledgement */}
                            {(() => {
                              const patientId = selectedAppointment.patientId || patientDetails?.PatientId;
                              // ftcComplianceRefresh dependency ensures re-render after form completion
                              const _ = ftcComplianceRefresh;
                              const ftcReqs = patientId ? FtcComplianceService.getComplianceRequirements(patientId) : null;
                              const hasExam = selectedAppointment.appointmentType?.toLowerCase().includes('exam') || true;
                              
                              if (!hasExam) return null;
                              
                              return (
                                <div className="flex items-center gap-2">
                                  {ftcReqs?.isComplete ? (
                                    <CheckCircle size={12} className="text-[#62A420] flex-shrink-0" />
                                  ) : ftcReqs?.needsConsent || ftcReqs?.needsAcknowledgement ? (
                                    <AlertTriangle size={12} className="text-amber-500 flex-shrink-0" />
                                  ) : (
                                    <X size={12} className="text-gray-400 flex-shrink-0" />
                                  )}
                                  <span className="font-bold">Rx Acknowledgement:</span>
                                  <span className={ftcReqs?.needsConsent || ftcReqs?.needsAcknowledgement ? 'text-amber-600' : ''}>
                                    {ftcReqs?.isComplete ? 'Complete' : 
                                     ftcReqs?.needsConsent ? 'Consent Required' :
                                     ftcReqs?.needsAcknowledgement ? 'Ack. Required' : 'Not Started'}
                                  </span>
                                  {!ftcReqs?.isComplete && (
                                    <button 
                                      onClick={() => ftcReqs?.needsConsent ? setShowRxConsentForm(true) : setShowRxAcknowledgementForm(true)} 
                                      className="text-[#006FB4] ml-1 font-medium"
                                    >
                                      {ftcReqs?.needsConsent ? 'Get Consent' : 'Get Ack.'}
                                    </button>
                                  )}
                                </div>
                              );
                            })()}

                            {/* HIPAA Signature */}
                            {(() => {
                              const patientId = selectedAppointment.patientId || patientDetails?.PatientId;
                              const hipaaStatus = patientId ? HipaaComplianceService.getComplianceStatus(patientId) : null;
                              
                              return (
                                <div className="flex items-center gap-2">
                                  {hipaaStatus?.isValid ? (
                                    <CheckCircle size={12} className="text-[#62A420] flex-shrink-0" />
                                  ) : hipaaStatus?.isExpired ? (
                                    <AlertTriangle size={12} className="text-red-500 flex-shrink-0" />
                                  ) : (
                                    <X size={12} className="text-red-500 flex-shrink-0" />
                                  )}
                                  <span className="font-bold">HIPAA Signature:</span>
                                  <span className={!hipaaStatus?.isValid ? 'text-red-600' : ''}>
                                    {hipaaStatus?.isValid 
                                      ? `Valid (${hipaaStatus.daysUntilExpiration}d remaining)` 
                                      : hipaaStatus?.isExpired 
                                        ? 'Expired - Renewal Required'
                                        : 'Required'}
                                  </span>
                                  {!hipaaStatus?.isValid && (
                                    <button 
                                      onClick={() => setShowHipaaSignatureForm(true)} 
                                      className="text-[#006FB4] ml-1 font-medium"
                                    >
                                      {hipaaStatus?.isExpired ? 'Renew' : 'Get Signature'}
                                    </button>
                                  )}
                                </div>
                              );
                            })()}
                          </div>

                          {/* Right Column: Forms Status & Actions */}
                          <div className="flex-1 border-l border-gray-200 pl-4 min-w-[200px]">
                            <div className="text-xs font-bold text-gray-600 mb-2">Forms</div>
                            {patientForms.length > 0 ? (
                              <div className="space-y-1 max-h-[120px] overflow-y-auto">
                                {patientForms.map(form => (
                                  <div key={form.submissionId} className="flex items-center gap-2 text-xs">
                                    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
                                      form.status === 'completed' ? 'bg-green-500' :
                                      form.status === 'in_progress' ? 'bg-yellow-500' :
                                      form.status === 'viewed' ? 'bg-blue-500' : 'bg-gray-400'
                                    }`} />
                                    <span className="font-medium text-gray-900 truncate" title={form.formTitle || form.templateId}>
                                      {form.formTitle || form.template?.title || 'Untitled Form'}
                                    </span>
                                    <span className={`text-[10px] font-medium flex-shrink-0 ${
                                      form.status === 'completed' ? 'text-green-600' :
                                      form.status === 'in_progress' ? 'text-yellow-600' :
                                      form.status === 'viewed' ? 'text-blue-600' : 'text-gray-500'
                                    }`}>
                                      {form.status === 'completed' ? 'Completed' : form.status === 'in_progress' ? 'In Progress' : form.status === 'viewed' ? 'Viewed' : 'Sent'}
                                    </span>
                                    <button onClick={() => window.open(form.accessLink, '_blank')} className="text-[#006FB4] hover:underline text-[10px] flex-shrink-0" title="View form">
                                      View
                                    </button>
                                    <button onClick={() => handleCopyFormLink(form.accessLink)} className="text-gray-400 hover:text-gray-600 flex-shrink-0" title="Copy link">
                                      {copiedFormLink === form.accessLink ? <CheckCircle size={10} className="text-green-500" /> : <Copy size={10} />}
                                    </button>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <div className="text-xs text-gray-400">No forms sent</div>
                            )}
                          </div>
                        </div>
                      </>
                    );
                  })()}
                </div>

{/* Prescriptions Section - Temporarily Removed */}
                {false && patientRx && patientRx.length > 0 && (
                  <div className="px-4 py-3 border-t border-gray-200">
                    <div className="font-bold text-sm text-[#222222] mb-2 flex items-center justify-between">
                      <span>Prescriptions ({patientRx.length})</span>
                      <button
                        onClick={() => openEpmPopup('rx', patientDetails?.PatientLegacyId || selectedAppointment?.patientId || patientDetails?.PatientId)}
                        className="text-xs font-normal text-[#006FB4] hover:underline"
                      >
                        View All in EPM
                      </button>
                    </div>
                    <div className="space-y-2 max-h-[150px] overflow-y-auto">
                      {patientRx.slice(0, 5).map((rx, idx) => (
                        <div key={rx.PatientExamUid || idx} className="bg-gray-50 rounded p-2 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-gray-800">
                              {rx.RxType || rx.rxType || 'Prescription'}
                            </span>
                            <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                              rx.IsIncomplete ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'
                            }`}>
                              {rx.IsIncomplete ? 'Incomplete' : 'Active'}
                            </span>
                          </div>
                          <div className="flex gap-4 mt-1 text-gray-500">
                            {(rx.ExamDate || rx.examDate) && (
                              <span>Exam: {new Date(rx.ExamDate || rx.examDate).toLocaleDateString()}</span>
                            )}
                            {(rx.ExpirationDate || rx.expirationDate) && (
                              <span>Expires: {new Date(rx.ExpirationDate || rx.expirationDate).toLocaleDateString()}</span>
                            )}
                          </div>
                          {/* Eyeglass Rx Details */}
                          {(rx.OdSphere !== undefined || rx.OsSphere !== undefined) && (
                            <div className="mt-1 grid grid-cols-2 gap-2 text-[10px] text-gray-600">
                              <div>OD: Sph {rx.OdSphere || '-'} Cyl {rx.OdCylinder || '-'} Axis {rx.OdAxis || '-'}</div>
                              <div>OS: Sph {rx.OsSphere || '-'} Cyl {rx.OsCylinder || '-'} Axis {rx.OsAxis || '-'}</div>
                            </div>
                          )}
                        </div>
                      ))}
                      {patientRx.length > 5 && (
                        <div className="text-xs text-gray-500 text-center">
                          +{patientRx.length - 5} more prescriptions
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Inline Patient Journey Panel */}
                {selectedAppointment && patientJourneys[selectedAppointment.patientId] && (
                  <div className="px-4 py-3 border-t border-gray-200">
                    <InlineJourneyPanel
                      journey={patientJourneys[selectedAppointment.patientId]}
                      officeId={selectedOffice}
                      rooms={prcRooms}
                      onStepAction={handlePrcStepAction}
                      onAssignRoom={handlePrcAssignRoom}
                      onTransitionPhase={handlePrcPhaseTransition}
                      collapsed={!showInlineJourney}
                      onToggleCollapse={() => setShowInlineJourney(prev => !prev)}
                    />
                  </div>
                )}

                {/* Unified Communications Panel */}
                <UnifiedCommunicationsPanel
                  communications={communications}
                  onSendSMS={async (content) => {
                    await CommunicationService.sendSMS(
                      selectedAppointment.patientId,
                      content,
                      currentUser?.name || 'Staff'
                    );
                    loadCommunications(selectedAppointment.patientId);
                  }}
                  onSendEmail={async (subject, content) => {
                    await CommunicationService.sendEmail(
                      selectedAppointment.patientId,
                      subject,
                      content,
                      currentUser?.name || 'Staff'
                    );
                    loadCommunications(selectedAppointment.patientId);
                  }}
                  onStartCall={(script, templateId) => handleStartCall(script, templateId)}
                  onEndCall={handleEndCall}
                  onToggleMute={handleToggleMute}
                  onToggleHold={handleToggleHold}
                  onEscalate={handleEscalate}
                  onSettingsClick={() => navigate('/ai-communication-settings')}
                  patientData={{
                    firstName: patientDetails?.firstName || selectedAppointment?.patientName?.split(' ')[0] || '',
                    lastName: patientDetails?.lastName || '',
                    fullName: patientDetails?.fullName || selectedAppointment?.patientName || '',
                    phone: patientDetails?.phone || patientDetails?.mobilePhone,
                    email: patientDetails?.email,
                  }}
                  appointmentData={{
                    date: selectedAppointment?.date ? new Date(selectedAppointment.date).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' }) : '',
                    time: selectedAppointment?.startTime,
                    type: selectedAppointment?.appointmentType || selectedAppointment?.reason,
                  }}
                  officeData={{
                    name: offices.find(o => o.OfficeNumber === selectedOffice)?.Address1 || 'Vision Care Center',
                    phone: '(555) 555-1234',
                  }}
                  providerData={{
                    name: selectedAppointment?.providerName || 'Dr. Provider',
                  }}
                  insuranceData={{
                    name: patientInsurance?.companyName || '',
                    planName: patientInsurance?.planName || '',
                  }}
                  patientPhone={patientDetails?.mobilePhone || patientDetails?.phone}
                  patientEmail={patientDetails?.email}
                  patientName={patientDetails?.fullName || selectedAppointment?.patientName}
                  activeCall={activeCall}
                  callDuration={callDuration}
                />

                {/* Patient Details Section */}
                <div className="border-t border-gray-200 bg-gray-50">
                  <div className="px-4 py-3">
                    <h3 className="text-sm font-bold text-[#222222] mb-4">Patient Details</h3>
                    <div className="space-y-4">
                      
                      <FullResponseDisplay 
                        title="Patient Details" 
                        data={fullPatientResponse}
                        isLoading={apiLoadingStates.patient}
                        error={apiErrors.patient}
                        defaultExpanded={false}
                      />
                      
                      <FullResponseDisplay 
                        title="Patient Prescriptions (Rx)" 
                        data={fullRxResponse}
                        isLoading={apiLoadingStates.rx}
                        error={apiErrors.rx}
                        defaultExpanded={false}
                      />
                      
                      <FullResponseDisplay 
                        title="Patient Orders" 
                        data={fullOrdersResponse}
                        isLoading={apiLoadingStates.orders}
                        error={apiErrors.orders}
                        defaultExpanded={false}
                      />
                      
                      <FullResponseDisplay 
                        title="Patient Appointments" 
                        data={fullAppointmentsResponse}
                        isLoading={apiLoadingStates.appointments}
                        error={apiErrors.appointments}
                        defaultExpanded={false}
                      />
                      
                    </div>
                  </div>
                </div>

              </>
            ) : (
              <div className="flex items-center justify-center h-full text-gray-500">
                Select an appointment to view details
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-white border-t border-gray-300 px-5 py-4 flex items-center justify-between shadow-sm text-xs">
        <span className="font-bold text-[#333333]">Eyefinity Live</span>
        <span className="text-[#333333] text-center">
          &copy; 2025 Eyefinity, Inc. All rights reserved.<br/>
          Eyefinity is a registered trademark of Eyefinity, Inc.
        </span>
        <span className="text-[#333333]">Version: 10.22.0.10</span>
      </div>

      {/* AI Chat Toggle Button */}
      <button
        onClick={() => setShowAiChat(!showAiChat)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-blue-600 text-white rounded-full shadow-lg hover:bg-blue-700 flex items-center justify-center z-40 transition-transform hover:scale-105"
        title="AI Assistant"
        aria-label="Toggle AI Assistant"
      >
        <Bot className="w-6 h-6" />
      </button>

      {/* AI Chat Panel */}
      {showAiChat && (
        <div className="fixed bottom-24 right-6 w-96 z-50 shadow-2xl">
          <AICommandChat
            staffId={currentUser?.id || 'staff-1'}
            staffName={currentUser?.name || 'Staff Member'}
            officeId={selectedOffice}
            companyId={activeCompany?.id}
            currentPatientName={selectedAppointment?.patientName}
            currentPatient={selectedAppointment ? {
              name: selectedAppointment.patientName,
              id: selectedAppointment.patientId,
              officeId: selectedOffice,
              appointmentId: selectedAppointment.id,
              appointmentDate: selectedAppointment.appointmentDate,
            } : undefined}
            onActionComplete={(result) => {
              console.log('[PatientReadinessCenter] AI action complete:', result);
              if (result.toolName === 'book_appointment' || result.toolName === 'cancel_appointment') {
                loadAppointments();
              }
            }}
          />
        </div>
      )}

      {/* Send Form Modal */}
      {showSendFormModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Send Form to Patient</h3>
                <button
                  onClick={() => {
                    setShowSendFormModal(false);
                    setSelectedFormTemplate(null);
                  }}
                  className="p-1 text-gray-400 hover:text-gray-600"
                >
                  <X size={20} />
                </button>
              </div>

              {selectedAppointment && (
                <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                  <p className="font-medium text-gray-900">{selectedAppointment.patientName}</p>
                  <p className="text-sm text-gray-500">
                    {patientDetails?.email || 'No email'} · {patientDetails?.mobilePhone || patientDetails?.homePhone || 'No phone'}
                  </p>
                </div>
              )}

              {!selectedFormTemplate ? (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  <p className="text-sm text-gray-600 mb-3">Select a form to send:</p>
                  {formTemplates.map(template => (
                    <button
                      key={template.id}
                      onClick={() => setSelectedFormTemplate(template)}
                      className="w-full p-3 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 text-left flex items-center gap-3"
                    >
                      <FileText size={18} className="text-purple-600" />
                      <div>
                        <div className="font-medium text-gray-900">{template.title}</div>
                        {template.description && (
                          <div className="text-xs text-gray-500">{template.description}</div>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="p-3 bg-purple-50 rounded-lg flex items-center gap-3">
                    <FileText size={18} className="text-purple-600" />
                    <div>
                      <div className="font-medium text-purple-900">{selectedFormTemplate.title}</div>
                      <div className="text-xs text-purple-700">{selectedFormTemplate.sections?.length || 0} sections</div>
                    </div>
                    <div className="flex items-start">
                      <button
                        onClick={() => openTaskModal(buildAppointmentTaskDefaults(selectedAppointment))}
                        className="px-3 py-1.5 bg-[#277FC1] text-white text-xs rounded shadow-sm hover:bg-[#1c6aa5]"
                      >
                        Create Task from Appointment
                      </button>
                    </div>
                  </div>

                  <p className="text-sm text-gray-600">
                    This form will be sent via email and/or SMS to the patient. They will receive a secure link to complete the form.
                  </p>

                  <div className="flex gap-3">
                    <button
                      onClick={() => setSelectedFormTemplate(null)}
                      className="flex-1 py-2 px-4 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                    >
                      Back
                    </button>
                    <button
                      onClick={handleSendForm}
                      disabled={sendingForm}
                      className="flex-1 py-2 px-4 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {sendingForm ? (
                        <>
                          <RefreshCw size={14} className="animate-spin" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send size={14} />
                          Send Form
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Task Creation Modal */}
      {showTaskModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="bg-white rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-auto">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-200">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{taskForm.appointmentId ? 'Appointment Task' : 'Manual Task'}</h3>
                {taskForm.patientName && (
                  <p className="text-xs text-gray-500">{taskForm.patientName} · Appointment #{taskForm.appointmentId}</p>
                )}
              </div>
              <button onClick={closeTaskModal} className="text-gray-400 hover:text-gray-600">
                <X size={18} />
              </button>
            </div>

            {taskError && (
              <div className="mx-5 mt-4 bg-red-50 border border-red-200 text-red-700 text-xs rounded px-3 py-2">
                {taskError}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 px-5 py-4">
              <label className="text-xs font-semibold text-gray-600 flex flex-col gap-1">
                Title
                <input
                  type="text"
                  value={taskForm.title}
                  onChange={(e) => handleTaskFieldChange('title', e.target.value)}
                  className="border border-gray-300 rounded px-3 py-2 text-sm"
                  placeholder="Enter task title"
                />
              </label>
              <label className="text-xs font-semibold text-gray-600 flex flex-col gap-1">
                Assign To Office
                <select
                  value={taskForm.assignedToOffice}
                  onChange={(e) => handleTaskFieldChange('assignedToOffice', e.target.value)}
                  className="border border-gray-300 rounded px-3 py-2 text-sm"
                >
                  <option value="">Select Office</option>
                  {offices.map(office => (
                    <option key={office.id} value={office.id}>
                      {office.officeName || office.name || `Office ${office.officeId}`}
                    </option>
                  ))}
                </select>
              </label>

              <label className="text-xs font-semibold text-gray-600 flex flex-col gap-1">
                Assign To Person
                <select
                  value={taskForm.assignee}
                  onChange={(e) => handleTaskFieldChange('assignee', e.target.value)}
                  className="border border-gray-300 rounded px-3 py-2 text-sm"
                >
                  <option value="">Unassigned</option>
                  <option value={currentUser?.id}>Me ({currentUser?.name || currentUser?.email})</option>
                  <option value="role:Front Desk">Front Desk</option>
                  <option value="role:Optician">Optician</option>
                  <option value="role:Optometrist">Optometrist</option>
                  <option value="role:Office Manager">Office Manager</option>
                  <option value="role:Technician">Technician</option>
                </select>
              </label>

              <label className="text-xs font-semibold text-gray-600 flex flex-col gap-1 md:col-span-2">
                Description
                <textarea
                  value={taskForm.description}
                  onChange={(e) => handleTaskFieldChange('description', e.target.value)}
                  className="border border-gray-300 rounded px-3 py-2 text-sm min-h-[90px]"
                  placeholder="Add context or instructions"
                />
              </label>

              <label className="text-xs font-semibold text-gray-600 flex flex-col gap-1">
                Priority
                <select
                  value={taskForm.priority}
                  onChange={(e) => handleTaskFieldChange('priority', e.target.value)}
                  className="border border-gray-300 rounded px-3 py-2 text-sm"
                >
                  <option value="low">Low</option>
                  <option value="normal">Normal</option>
                  <option value="high">High</option>
                  <option value="urgent">Urgent</option>
                </select>
              </label>

              <label className="text-xs font-semibold text-gray-600 flex flex-col gap-1">
                Status
                <select
                  value={taskForm.status}
                  onChange={(e) => handleTaskFieldChange('status', e.target.value)}
                  className="border border-gray-300 rounded px-3 py-2 text-sm"
                >
                  <option value="pending">Pending</option>
                  <option value="in_progress">In Progress</option>
                  <option value="completed">Completed</option>
                  <option value="blocked">Blocked</option>
                </select>
              </label>

              <label className="text-xs font-semibold text-gray-600 flex flex-col gap-1">
                Channel
                <select
                  value={taskForm.channel}
                  onChange={(e) => handleTaskFieldChange('channel', e.target.value)}
                  className="border border-gray-300 rounded px-3 py-2 text-sm"
                >
                  <option value="internal">Internal</option>
                  <option value="appointment_followup">Appointment Follow-up</option>
                  <option value="communication">Communication</option>
                </select>
              </label>

              <label className="text-xs font-semibold text-gray-600 flex flex-col gap-1">
                Category
                <input
                  type="text"
                  value={taskForm.category || ''}
                  onChange={(e) => handleTaskFieldChange('category', e.target.value)}
                  className="border border-gray-300 rounded px-3 py-2 text-sm"
                  placeholder="e.g. forms, insurance"
                />
              </label>

              <label className="text-xs font-semibold text-gray-600 flex flex-col gap-1">
                Due Date
                <input
                  type="date"
                  value={taskForm.dueDate}
                  onChange={(e) => handleTaskFieldChange('dueDate', e.target.value)}
                  className="border border-gray-300 rounded px-3 py-2 text-sm"
                />
              </label>

              <label className="text-xs font-semibold text-gray-600 flex flex-col gap-1">
                Due Time
                <select
                  value={taskForm.dueTime}
                  onChange={(e) => handleTaskFieldChange('dueTime', e.target.value)}
                  className="border border-gray-300 rounded px-3 py-2 text-sm"
                >
                  <option value="">Select time...</option>
                  {Array.from({ length: 288 }, (_, i) => {
                    const hour = Math.floor(i / 12);
                    const minute = (i % 12) * 5;
                    const time24 = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
                    const hour12 = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
                    const ampm = hour < 12 ? 'AM' : 'PM';
                    const timeDisplay = `${hour12}:${minute.toString().padStart(2, '0')} ${ampm}`;
                    return <option key={time24} value={time24}>{timeDisplay}</option>;
                  })}
                </select>
              </label>

              <label className="text-xs font-semibold text-gray-600 flex flex-col gap-1">
                Reminder (minutes before)
                <input
                  type="number"
                  min="0"
                  value={taskForm.reminderMinutes}
                  onChange={(e) => handleTaskFieldChange('reminderMinutes', e.target.value)}
                  className="border border-gray-300 rounded px-3 py-2 text-sm"
                  placeholder="Optional"
                />
              </label>

              {taskForm.patientName && (
                <div className="md:col-span-2 bg-gray-50 border border-gray-200 rounded p-3 text-xs text-gray-600">
                  <div className="font-semibold text-gray-800 mb-2">Linked Appointment</div>
                  <div className="flex flex-wrap gap-4">
                    <span><span className="text-gray-500">Patient:</span> {taskForm.patientName}</span>
                    <span><span className="text-gray-500">Appt ID:</span> {taskForm.appointmentId}</span>
                    <span><span className="text-gray-500">Provider:</span> {taskForm.providerName || '—'}</span>
                    <span><span className="text-gray-500">Office:</span> {taskForm.officeId || selectedOffice || '—'}</span>
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between px-5 py-4 border-t border-gray-200 bg-gray-50 rounded-b-lg">
              <button
                onClick={closeTaskModal}
                className="text-sm text-gray-600 hover:text-gray-800"
                disabled={taskSubmitting}
              >
                Cancel
              </button>
              <button
                onClick={handleCreateTask}
                disabled={taskSubmitting}
                className="px-4 py-2 bg-[#277FC1] text-white text-sm rounded shadow-sm hover:bg-[#1c6aa5] disabled:opacity-50"
              >
                {taskSubmitting ? 'Saving…' : (editingTaskId ? 'Save Task' : 'Create Task')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FTC Rx Consent Form Modal */}
      {showRxConsentForm && selectedAppointment && (
        <RxConsentForm
          patient={{
            id: selectedAppointment.patientId || patientDetails?.PatientId,
            patientId: selectedAppointment.patientId || patientDetails?.PatientId,
            patientUid: patientDetails?.PatientUid,
            firstName: patientDetails?.FirstName || selectedAppointment.patientName?.split(' ')[0],
            lastName: patientDetails?.LastName || selectedAppointment.patientName?.split(' ').slice(1).join(' '),
            email: patientDetails?.Email,
            phone: patientDetails?.HomePhone,
            mobilePhone: patientDetails?.MobilePhone,
          }}
          storeNumber={selectedOffice}
          storeId={selectedOffice}
          onComplete={(record) => {
            console.log('[FTC] Consent saved:', record);
            setShowRxConsentForm(false);
            setFtcComplianceRefresh(prev => prev + 1);
            // If physical delivery selected, show acknowledgement form
            if (record.consent?.consentType === 'physical') {
              setShowRxAcknowledgementForm(true);
            }
          }}
          onCancel={() => setShowRxConsentForm(false)}
        />
      )}

      {/* FTC Rx Acknowledgement Form Modal */}
      {showRxAcknowledgementForm && selectedAppointment && (
        <RxAcknowledgementForm
          patient={{
            id: selectedAppointment.patientId || patientDetails?.PatientId,
            patientId: selectedAppointment.patientId || patientDetails?.PatientId,
            patientUid: patientDetails?.PatientUid,
            firstName: patientDetails?.FirstName || selectedAppointment.patientName?.split(' ')[0],
            lastName: patientDetails?.LastName || selectedAppointment.patientName?.split(' ').slice(1).join(' '),
          }}
          examDate={selectedAppointment.date}
          storeNumber={selectedOffice}
          storeId={selectedOffice}
          associateId={currentUser?.id}
          associateName={currentUser?.name || currentUser?.email}
          onComplete={(record) => {
            console.log('[FTC] Acknowledgement saved:', record);
            setShowRxAcknowledgementForm(false);
            setFtcComplianceRefresh(prev => prev + 1);
            // Update readiness status
            setAppointmentReadiness(selectedAppointment.id, { rxAcknowledgement: 'complete' });
          }}
          onCancel={() => setShowRxAcknowledgementForm(false)}
        />
      )}

      {/* HIPAA Signature Form Modal */}
      {showHipaaSignatureForm && selectedAppointment && (
        <HipaaSignatureForm
          patient={{
            id: selectedAppointment.patientId || patientDetails?.PatientId,
            patientId: selectedAppointment.patientId || patientDetails?.PatientId,
            patientUid: patientDetails?.PatientUid,
            firstName: patientDetails?.FirstName || selectedAppointment.patientName?.split(' ')[0],
            lastName: patientDetails?.LastName || selectedAppointment.patientName?.split(' ').slice(1).join(' '),
          }}
          storeNumber={selectedOffice}
          storeId={selectedOffice}
          associateId={currentUser?.id}
          associateName={currentUser?.name || currentUser?.email}
          onComplete={(record) => {
            console.log('[HIPAA] Signature saved:', record);
            setShowHipaaSignatureForm(false);
            setHipaaComplianceRefresh(prev => prev + 1);
          }}
          onCancel={() => setShowHipaaSignatureForm(false)}
        />
      )}

      {/* Escalation Queue Popup */}
      <EscalationQueuePopup
        isOpen={showEscalationQueue}
        onClose={() => setShowEscalationQueue(false)}
        onSelectEscalation={(esc) => {
          console.log('[Escalation] Selected:', esc);
          setShowEscalationQueue(false);
          // Could navigate to patient or show details
        }}
      />

      {/* AI Performance Monitor */}
      <AIPerformanceMonitor
        isOpen={showAIPerformanceMonitor}
        onClose={() => setShowAIPerformanceMonitor(false)}
      />

      {/* MFA Code Relay Modal */}
      {mfaRequired && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96 shadow-xl">
            <h3 className="font-bold text-lg mb-2">MFA Code Required</h3>
            <p className="text-sm text-gray-600 mb-4">
              The <b>{(mfaRequired.payerType || '').toUpperCase()}</b> portal sent a verification code.
              Please enter it below to continue benefit verification.
            </p>
            <input
              type="text"
              value={mfaCode}
              onChange={(e) => setMfaCode(e.target.value.replace(/\D/g, ''))}
              onKeyDown={(e) => e.key === 'Enter' && submitMfaCode()}
              className="border rounded w-full p-3 text-center text-2xl tracking-widest font-mono"
              maxLength={6}
              placeholder="123456"
              autoFocus
            />
            <div className="flex gap-2 mt-4">
              <button
                onClick={() => { setMfaRequired(null); setMfaCode(''); }}
                className="flex-1 border border-gray-300 text-gray-700 rounded py-2 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={submitMfaCode}
                disabled={mfaCode.length < 4}
                className="flex-1 bg-[#006FB4] text-white rounded py-2 hover:bg-[#005a94] disabled:opacity-50"
              >
                Submit Code
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default PatientReadinessCenter;
