/**
 * Unit tests for TaskService
 * Tests CRUD operations for API-based task management
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { TaskService } from '../src/services/taskService';

// Mock fetch globally
global.fetch = vi.fn();

describe('TaskService', () => {
  beforeEach(() => {
    // Reset fetch mock before each test
    fetch.mockReset();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  describe('fetchTasks', () => {
    it('should fetch all tasks', async () => {
      const mockTasks = [
        { id: '1', title: 'Task 1', status: 'pending' },
        { id: '2', title: 'Task 2', status: 'completed' }
      ];

      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => ({ tasks: mockTasks, queue: null })
      });

      const result = await TaskService.fetchTasks();

      expect(fetch).toHaveBeenCalledWith('/api/tasks');
      expect(result.tasks).toEqual(mockTasks);
    });

    it('should filter tasks by status', async () => {
      const mockTasks = [
        { id: '1', title: 'Task 1', status: 'pending' }
      ];

      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => ({ tasks: mockTasks, queue: null })
      });

      const result = await TaskService.fetchTasks('pending');

      expect(fetch).toHaveBeenCalledWith('/api/tasks?status=pending');
      expect(result.tasks).toEqual(mockTasks);
    });

    it('should throw error on fetch failure', async () => {
      fetch.mockResolvedValueOnce({
        ok: false,
        status: 500,
        text: async () => 'Internal Server Error'
      });

      await expect(TaskService.fetchTasks()).rejects.toThrow();
    });
  });

  describe('createTask', () => {
    it('should create task with required fields', async () => {
      const mockTask = {
        id: '1',
        title: 'New Task',
        status: 'pending',
        priority: 'normal',
        createdAt: new Date().toISOString()
      };

      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => ({ task: mockTask })
      });

      const payload = {
        title: 'New Task',
        status: 'pending',
        priority: 'normal'
      };

      const result = await TaskService.createTask(payload);

      expect(fetch).toHaveBeenCalledWith('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...payload, reminderInSeconds: undefined })
      });
      expect(result.task.title).toBe('New Task');
    });

    it('should prevent creating task without title', async () => {
      fetch.mockResolvedValueOnce({
        ok: false,
        status: 400,
        text: async () => 'title is required'
      });

      const payload = { status: 'pending' };

      await expect(TaskService.createTask(payload)).rejects.toThrow('title is required');
    });

    it('should create task with reminder', async () => {
      const mockTask = {
        id: '1',
        title: 'Task with reminder',
        status: 'pending',
        priority: 'normal'
      };

      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => ({ task: mockTask })
      });

      const payload = { title: 'Task with reminder' };
      const options = { reminderInSeconds: 3600 };

      await TaskService.createTask(payload, options);

      expect(fetch).toHaveBeenCalledWith('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...payload, reminderInSeconds: 3600 })
      });
    });

    it('should validate title length', async () => {
      fetch.mockResolvedValueOnce({
        ok: false,
        status: 400,
        text: async () => 'Task title must be at least 3 characters'
      });

      const payload = { title: 'ab' };

      await expect(TaskService.createTask(payload)).rejects.toThrow();
    });

    it('should accept all valid priorities', async () => {
      const priorities = ['low', 'normal', 'high', 'urgent'];

      for (const priority of priorities) {
        fetch.mockResolvedValueOnce({
          ok: true,
          json: async () => ({ task: { id: '1', title: 'Test', priority } })
        });

        await TaskService.createTask({ title: 'Test', priority });
      }

      expect(fetch).toHaveBeenCalledTimes(4);
    });

    it('should accept all valid statuses', async () => {
      const statuses = ['pending', 'in_progress', 'completed', 'blocked'];

      for (const status of statuses) {
        fetch.mockResolvedValueOnce({
          ok: true,
          json: async () => ({ task: { id: '1', title: 'Test', status } })
        });

        await TaskService.createTask({ title: 'Test', status });
      }

      expect(fetch).toHaveBeenCalledTimes(4);
    });
  });

  describe('updateTask', () => {
    it('should update existing task', async () => {
      const mockTask = {
        id: '1',
        title: 'Updated Task',
        status: 'completed',
        priority: 'high'
      };

      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => ({ task: mockTask })
      });

      const updates = { title: 'Updated Task', status: 'completed' };
      const result = await TaskService.updateTask('1', updates);

      expect(fetch).toHaveBeenCalledWith('/api/tasks/1', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      expect(result.task.title).toBe('Updated Task');
      expect(result.task.status).toBe('completed');
    });

    it('should throw error if task not found', async () => {
      fetch.mockResolvedValueOnce({
        ok: false,
        status: 404,
        text: async () => 'Task not found'
      });

      await expect(TaskService.updateTask('999', { title: 'Test' })).rejects.toThrow();
    });

    it('should allow partial updates', async () => {
      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => ({ task: { id: '1', title: 'Original', status: 'completed' } })
      });

      await TaskService.updateTask('1', { status: 'completed' });

      expect(fetch).toHaveBeenCalledWith('/api/tasks/1', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'completed' })
      });
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty task list', async () => {
      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => ({ tasks: [], queue: null })
      });

      const result = await TaskService.fetchTasks();
      expect(result.tasks).toEqual([]);
    });

    it('should handle network errors', async () => {
      fetch.mockRejectedValueOnce(new Error('Network error'));

      await expect(TaskService.fetchTasks()).rejects.toThrow('Network error');
    });

    it('should handle malformed JSON response', async () => {
      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => { throw new Error('Invalid JSON'); }
      });

      await expect(TaskService.fetchTasks()).rejects.toThrow('Invalid JSON');
    });

    it('should handle missing required fields gracefully', async () => {
      fetch.mockResolvedValueOnce({
        ok: false,
        status: 400,
        text: async () => 'Missing required fields'
      });

      await expect(TaskService.createTask({})).rejects.toThrow();
    });
  });

  describe('Validation', () => {
    it('should reject invalid priority', async () => {
      fetch.mockResolvedValueOnce({
        ok: false,
        status: 400,
        text: async () => 'Invalid priority'
      });

      await expect(
        TaskService.createTask({ title: 'Test', priority: 'invalid' })
      ).rejects.toThrow();
    });

    it('should reject invalid status', async () => {
      fetch.mockResolvedValueOnce({
        ok: false,
        status: 400,
        text: async () => 'Invalid status'
      });

      await expect(
        TaskService.createTask({ title: 'Test', status: 'invalid' })
      ).rejects.toThrow();
    });
  });
});
