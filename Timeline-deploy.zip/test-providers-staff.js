/**
 * Test Providers and Staff endpoints
 */

import https from 'https';
import dotenv from 'dotenv';

dotenv.config();

const OAUTH_HOST = process.env.OAUTH_HOST || 'api-sandbox.eyefinity.com';
const API_BASE_URL = process.env.EYEFINITY_API_URL || 'https://api-sandbox.eyefinity.com';
const CLIENT_ID = process.env.EPM_CLIENT_ID;
const CLIENT_SECRET = process.env.EPM_CLIENT_SECRET;
const TENANT_UID = process.env.TENANT_UID;

const EPM_SCOPES = [
  'auth_epm',
  'ef.pm_pe_patient_rx',
  'ef.pm_pe_resource',
  'ef.pm_pe_insurance',
  'ef.pm_pe_appointment',
  'ef.pm_pe_office_recallreport',
  'ef.pm_pe_staff',
  'ef.pm_pe_office',
  'ef.pm_pe_company',
  'ef.pm_pe_order',
  'ef.pm_pe_provider',
  'ef.pm_pe_patient',
].join(' ');

async function getClientCredentialsToken() {
  return new Promise((resolve, reject) => {
    const credentials = Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString('base64');
    const body = `grant_type=client_credentials&scope=${encodeURIComponent(EPM_SCOPES)}`;
    
    const options = {
      hostname: OAUTH_HOST,
      port: 443,
      path: '/as/token.oauth2',
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(body),
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode === 200) {
          const json = JSON.parse(data);
          resolve(json.access_token || json.accesstoken);
        } else {
          reject(new Error(`Client credentials failed: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

async function exchangeToken(ccToken) {
  return new Promise((resolve, reject) => {
    const credentials = Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString('base64');
    const body = new URLSearchParams({
      'grant_type': 'urn:ietf:params:oauth:grant-type:token-exchange',
      'subject_token': ccToken,
      'subject_token_type': 'urn:ietf:params:oauth:token-type:access_token',
      'scope': EPM_SCOPES,
      'resource': 'https://VspEpmToken',
    }).toString();
    
    const options = {
      hostname: OAUTH_HOST,
      port: 443,
      path: '/as/token.oauth2',
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(body),
        'tenantuid': TENANT_UID,
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode === 200) {
          const json = JSON.parse(data);
          resolve(json.access_token || json.accesstoken);
        } else {
          reject(new Error(`Token exchange failed: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

async function testEndpoint(token, path, description) {
  return new Promise((resolve, reject) => {
    const url = new URL(`${API_BASE_URL}/al-pe/${path}`);
    
    const options = {
      hostname: url.hostname,
      port: 443,
      path: url.pathname + url.search,
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json',
      },
    };

    console.log(`\n📡 ${description}`);
    console.log(`   GET ${API_BASE_URL}/al-pe/${path}`);
    
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        console.log(`   Status: ${res.statusCode}`);
        
        if (res.statusCode === 200) {
          try {
            const json = JSON.parse(data);
            const count = Array.isArray(json) ? json.length : (json.data ? json.data.length : 0);
            console.log(`   ✅ Got ${count} items`);
            
            if (Array.isArray(json) && json.length > 0) {
              console.log(`\n   Sample response:`);
              console.log(JSON.stringify(json[0], null, 2));
            }
            resolve(json);
          } catch (e) {
            console.log(`   ❌ Parse error: ${e.message}`);
            console.log(`   Raw: ${data.substring(0, 200)}`);
            reject(e);
          }
        } else {
          console.log(`   ❌ Failed`);
          console.log(`   ${data.substring(0, 500)}`);
          reject(new Error(`Request failed: ${res.statusCode}`));
        }
      });
    });

    req.on('error', reject);
    req.end();
  });
}

async function runTests() {
  console.log('🧪 Testing Providers and Staff Endpoints');
  console.log('=========================================\n');
  
  try {
    // OAuth
    console.log('🔐 Step 1: Client Credentials');
    const ccToken = await getClientCredentialsToken();
    console.log('   ✅ Success');
    
    console.log('\n🔄 Step 2: Token Exchange');
    const epmToken = await exchangeToken(ccToken);
    console.log('   ✅ Success');
    
    // Test endpoints
    console.log('\n' + '='.repeat(60));
    console.log('Testing API Endpoints');
    console.log('='.repeat(60));
    
    await testEndpoint(epmToken, 'v2providers?page=1&pageSize=100', 'GET v2providers');
    await testEndpoint(epmToken, 'v2staff?page=1&pageSize=100', 'GET v2staff');
    
    console.log('\n✅ All tests completed!');
    
  } catch (error) {
    console.error('\n❌ Test failed:', error.message);
    process.exit(1);
  }
}

runTests();
