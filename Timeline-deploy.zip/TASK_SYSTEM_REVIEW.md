# Task Management System - Review & Fix Plan

## 🚨 Critical Issue: Dual Task Systems

The application has **TWO separate, non-communicating task management systems**:

### System A: LocalStorage-based (`task-management-service.ts`)
- **Storage**: Browser localStorage key `patient-tasks`
- **Used by**: `CheckoutTaskModal.jsx` (checkout flow)
- **Interface**: `Task` type with full CRUD
- **Pros**: Fast, works offline, rich feature set (AI completion, templates)
- **Cons**: Per-browser, no multi-user sync, data can become stale/corrupted

### System B: API-based (`taskService.ts` + `/api/tasks`)
- **Storage**: Backend database (via API)
- **Used by**: `PatientReadinessCenter.jsx` (main task view)
- **Interface**: `TimelineTask` type
- **Pros**: Multi-user, persistent, centralized
- **Cons**: Requires backend, network dependent

**Problem**: Tasks created in one system are invisible to the other, causing confusion and "untitled" task issues.

---

## ✅ Phase 1: Immediate Fixes (COMPLETED)

### 1. Fixed Button Text Bug
**File**: `PatientReadinessCenter.jsx:2475`
- ✅ Now shows "Save Task" when editing, "Create Task" when creating new
- Uses `editingTaskId` to determine mode

### 2. Added Title Validation
**File**: `PatientReadinessCenter.jsx:985-993`
- ✅ Prevents empty/whitespace-only titles
- ✅ Requires minimum 3 characters
- ✅ Shows clear error message

### 3. Added Cleanup Utilities
**File**: `task-management-service.ts:305-352`
- ✅ `removeUntitledTasks()` - Removes tasks with missing/short titles
- ✅ `cleanupOrphanedTasks()` - Removes tasks for deleted journeys
- ✅ `cleanupOldTasks()` - Removes completed tasks older than 30 days
- ✅ `cleanupAll()` - Runs all cleanup operations

### 4. Created Console Utility
**File**: `task-cleanup-utility.ts`
- ✅ Easy-to-use console commands for cleanup
- ✅ Preview mode to see what would be cleaned
- ✅ Safe confirmation for destructive operations

---

## 🧪 Testing Phase 1 Fixes

### Test 1: Button Text
1. Go to Patient Readiness Center
2. Click "Add Task" on any appointment → Should show **"Create Task"** button
3. Create a task, then click to edit it → Should show **"Save Task"** button

### Test 2: Title Validation
1. Open task modal
2. Try to save with empty title → Should show error "Task title is required"
3. Enter "ab" (2 chars) → Should show error "Task title must be at least 3 characters"
4. Enter "abc" (3 chars) → Should save successfully

### Test 3: Cleanup Existing Bad Tasks
1. Open browser console (F12)
2. Run: `taskCleanup.preview()` → Shows what would be cleaned
3. Run: `taskCleanup.cleanup()` → Removes untitled/orphaned/old tasks
4. Verify: No more untitled tasks in UI

---

## 📋 Phase 2: System Consolidation (PLANNED)

### Goal
Migrate to **single unified task system** (API-based) to fix root cause.

### Migration Steps

#### 2.1 Enhance API Task System
- Add missing features from localStorage system:
  - Task templates
  - AI completion support
  - Category/priority configs
  - Bulk operations

#### 2.2 Create Migration Script
**File**: `scripts/migrate-tasks-to-api.ts`
```typescript
// Read tasks from localStorage
// Transform to API format
// POST to /api/tasks
// Clear localStorage after successful migration
```

#### 2.3 Update CheckoutTaskModal
- Replace `taskManager` imports with `TaskService`
- Update all CRUD operations to use API
- Maintain same UI/UX

#### 2.4 Deprecate LocalStorage System
- Archive `task-management-service.ts`
- Remove localStorage reads/writes
- Update all imports

### Timeline
- Estimated: 4-6 hours
- Priority: High (prevents future data issues)
- Complexity: Medium (requires careful data migration)

---

## 📋 Phase 3: Testing (PLANNED)

### 3.1 Unit Tests
**File**: `tests/task-service.test.ts`
```typescript
- Create task with required fields
- Prevent creating task without title
- Update existing task
- Delete task
- Filter tasks by status/priority
```

### 3.2 Integration Tests
**File**: `tests/task-ui.test.tsx`
```typescript
- Render task modal
- Create new task via form
- Edit existing task
- Delete task
- Validate form inputs
```

### 3.3 E2E Tests
**File**: `e2e/tasks.spec.ts`
```typescript
- Complete task creation flow
- Task appears in list
- Edit and save task
- Task updates in list
- Delete task
- Task removed from list
```

### Timeline
- Estimated: 3-4 hours
- Priority: Medium
- Complexity: Low-Medium

---

## 📋 Phase 4: Documentation (PLANNED)

### 4.1 API Documentation
- Add task endpoints to Swagger
- Document request/response schemas
- Add example payloads

### 4.2 Developer Guide
**File**: `docs/TASK_SYSTEM.md`
- Architecture overview
- How to create tasks
- How to query tasks
- Best practices

### 4.3 User Guide
- How to create/edit tasks
- Task categories and priorities
- Task assignment
- Task reminders

### Timeline
- Estimated: 2 hours
- Priority: Low
- Complexity: Low

---

## 🎯 Immediate Next Steps

1. **Deploy Phase 1 fixes** (DONE ✅)
   - Wait for Vercel deployment
   - Hard refresh app

2. **Test in production**
   - Verify button text shows correctly
   - Verify validation prevents untitled tasks
   - Run `taskCleanup.cleanup()` in console

3. **Monitor for issues**
   - Check if untitled tasks still appear
   - Verify tasks save correctly
   - Collect user feedback

4. **Plan Phase 2 kickoff**
   - Review migration strategy
   - Allocate development time
   - Create detailed subtasks

---

## 🔧 Quick Fixes Available Now

### Remove All Untitled Tasks
```javascript
// In browser console:
taskCleanup.cleanup()
```

### Preview Cleanup
```javascript
// See what would be cleaned without making changes:
taskCleanup.preview()
```

### Debug Task Data
```javascript
// Show all tasks and stats:
taskCleanup.debug()
```

### Nuclear Option (Use with Caution!)
```javascript
// Delete ALL tasks:
taskCleanup.clearAll()
```

---

## 📊 Success Metrics

### Phase 1 Success Criteria
- ✅ No more untitled tasks created
- ✅ Button text shows correctly when editing
- ✅ Cleanup utilities remove existing bad data
- ✅ Zero breaking changes to existing functionality

### Phase 2 Success Criteria
- Single source of truth for tasks
- All task features work in unified system
- Zero data loss during migration
- All existing tasks accessible after migration

### Phase 3 Success Criteria
- 90%+ test coverage on task operations
- All critical paths covered by E2E tests
- CI/CD runs tests on every commit
- No regressions in task functionality

---

## 🐛 Known Issues (Post-Phase 1)

1. **Dual systems still exist** - Phase 2 will resolve
2. **Tasks may appear in one view but not the other** - Due to dual systems
3. **LocalStorage tasks not backed up** - Risk of data loss on browser clear
4. **No task assignment notifications** - Future enhancement
5. **No task analytics/reporting** - Future enhancement

---

## 📞 Support

For issues or questions about the task system:
1. Review this document
2. Check console for errors (`taskCleanup.debug()`)
3. Run cleanup utilities if needed
4. Escalate to development team if issues persist
