# Patient Care Timeline - Complete Implementation Plan

## Overview
Multi-tenant patient care management system with Eyefinity EHR integration, automated appointment syncing, and comprehensive REST APIs.

## Architecture

### Technology Stack
- **Frontend**: React, Next.js, TailwindCSS
- **Backend**: Next.js API Routes (serverless)
- **Database**: Supabase (PostgreSQL)
- **Integration**: Eyefinity API via OAuth 2.0 proxy
- **Documentation**: Swagger/OpenAPI 3.0
- **Deployment**: Vercel

### Data Model (VBD Pattern)

```
┌─────────────────────────────────────────────────────────────┐
│                    ORGANIZATIONAL LAYER                      │
├─────────────────────────────────────────────────────────────┤
│ accounts → companies → offices → staff ← staff_offices       │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                      PATIENT LAYER                           │
├─────────────────────────────────────────────────────────────┤
│ patients → patient_insurance                                 │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    SCHEDULING LAYER                          │
├─────────────────────────────────────────────────────────────┤
│ appointments → encounters → exams                            │
│                         └─→ prescriptions → orders           │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    AUTOMATION LAYER                          │
├─────────────────────────────────────────────────────────────┤
│ recalls (patient follow-ups)                                 │
│ sync_logs (integration tracking)                             │
└─────────────────────────────────────────────────────────────┘
```

## Database Schema

### Core Tables (14 total)

#### Organizational (5 tables)
1. **accounts** - Multi-tenant account containers
2. **companies** - Organizations with Eyefinity credentials
3. **offices** - Physical office locations
4. **staff** - Providers, doctors, technicians, admin
5. **staff_offices** - Many-to-many junction

#### Patient Management (2 tables)
6. **patients** - Patient demographics and contact info
7. **patient_insurance** - Insurance policies (primary, secondary, tertiary)

#### Clinical & Scheduling (5 tables)
8. **appointments** - Scheduled patient visits
9. **encounters** - Clinical visit documentation (SOAP notes)
10. **exams** - Eye exam results and measurements
11. **prescriptions** - Rx for glasses, contacts, medications
12. **orders** - Eyewear and product orders

#### Automation (2 tables)
13. **recalls** - Patient follow-up reminders
14. **sync_logs** - Eyefinity sync tracking and audit

### Key Features
- ✅ All tables have `created_at` and `updated_at` timestamps
- ✅ All tables have JSONB `settings` for extensibility
- ✅ Eyefinity foreign keys on all synced entities
- ✅ Comprehensive indexes for performance
- ✅ RLS enabled (permissive policies for dev)
- ✅ Automatic timestamp triggers

## REST API Endpoints

### Patients API
```
GET    /api/patients?company_id={uuid}&search={query}&status={active|inactive}
POST   /api/patients
GET    /api/patients/{id}
PUT    /api/patients/{id}
DELETE /api/patients/{id}
```

### Appointments API
```
GET    /api/appointments?office_id={uuid}&start_date={date}&end_date={date}
POST   /api/appointments
GET    /api/appointments/{id}
PUT    /api/appointments/{id}
DELETE /api/appointments/{id}
POST   /api/appointments/{id}/check-in
POST   /api/appointments/{id}/check-out
```

### Sync API
```
POST   /api/sync/appointments
       Body: { company_id, start_date, end_date } OR { company_id, mode: "upcoming" }
POST   /api/sync/patients
POST   /api/sync/providers
POST   /api/sync/staff
POST   /api/sync/offices
```

### Additional APIs (To Be Implemented)
```
/api/encounters
/api/exams
/api/prescriptions
/api/orders
/api/recalls
/api/companies
/api/offices
/api/staff
/api/sync/full (full sync of all entities)
```

## Eyefinity Integration

### OAuth Flow (Server-Side Proxy)
1. Client requests sync via `/api/sync/appointments`
2. Proxy `/api/eyefinity/[...path]` intercepts
3. Proxy fetches company credentials from DB
4. Proxy performs OAuth token exchange (cached)
5. Proxy forwards request to Eyefinity API
6. Response flows back to client

### Synced Entities
- ✅ **Offices** - v2offices endpoint (flat structure)
- ✅ **Providers** - v2providers endpoint (has ProviderId GUID)
- ✅ **Staff** - v2staff endpoint (has StaffId GUID)
- 🔄 **Patients** - v2patients endpoint
- 🔄 **Appointments** - appointments endpoint with date range
- 🔄 **Exams** - exam data
- 🔄 **Prescriptions** - Rx data
- 🔄 **Orders** - order tracking

### Sync Strategy
1. **On-Demand**: User-triggered via UI
2. **Scheduled** (Future): Cron job every 6 hours
3. **Incremental**: Sync only changed records
4. **Bi-directional** (Future): Push updates back to Eyefinity

## Implementation Status

### ✅ Completed
1. Database schema with all 14 tables
2. Eyefinity OAuth proxy working
3. Office, Provider, Staff sync working
4. Patient accessor and API
5. Appointment accessor and API
6. Appointment sync service
7. Swagger/OpenAPI documentation
8. Sync logging structure

### 🔄 In Progress
1. Additional accessors (Exams, Prescriptions, Orders, Recalls)
2. Full sync orchestration
3. Sync scheduler
4. Patient sync from Eyefinity
5. Encounter management

### 📋 Planned
1. Complete API implementation for all entities
2. Swagger UI integration
3. Automated sync scheduler (cron)
4. Real-time appointment reminders
5. Recall automation
6. Analytics and reporting
7. Audit logging
8. Production RLS policies
9. API rate limiting
10. Webhook support

## File Structure
```
/api
  /appointments
    index.js          # List/create appointments
    [id].js           # Get/update/delete appointment
  /patients
    index.js          # List/create patients
    [id].js           # Get/update/delete patient
  /sync
    appointments.js   # Appointment sync endpoint
  /eyefinity
    [...path].js      # OAuth proxy (existing)

/src/lib
  /accessors
    BaseAccessor.ts
    PatientAccessor.ts
    AppointmentAccessor.ts
    # More accessors needed...
  /services
    appointment-sync-service.ts
    eyefinity-integration-service.ts
  /db
    schema-complete.sql
    connection.ts

/api-docs
  swagger.json        # OpenAPI 3.0 spec
```

## Testing Requirements

### Unit Tests
- [ ] All accessors (CRUD operations)
- [ ] Sync services (mock Eyefinity API)
- [ ] Data transformations

### Integration Tests
- [x] Eyefinity OAuth flow
- [x] Office sync
- [x] Provider sync
- [x] Staff sync
- [ ] Patient sync
- [ ] Appointment sync
- [ ] Full sync workflow

### API Tests
- [ ] All REST endpoints
- [ ] Error handling
- [ ] Validation
- [ ] Performance (response times < 500ms)

## Security Considerations

### Current (Development)
- RLS enabled with permissive policies
- OAuth credentials stored in DB
- Server-side proxy for Eyefinity

### Production Requirements
- [ ] Tenant isolation via RLS policies
- [ ] Encrypt OAuth credentials at rest
- [ ] API key authentication
- [ ] Rate limiting
- [ ] Input validation and sanitization
- [ ] HIPAA compliance review
- [ ] Audit logging

## Performance Targets
- API response time: < 500ms (p95)
- Appointment sync: < 30 seconds for 1000 records
- Database queries: All indexed, < 100ms
- Concurrent users: 100+ per company

## Deployment Strategy

### Vercel Configuration
```json
{
  "buildCommand": "npm run build",
  "env": {
    "SUPABASE_URL": "@supabase_url",
    "SUPABASE_SERVICE_KEY": "@supabase_service_key",
    "OAUTH_HOST": "api-sandbox.eyefinity.com",
    "EPM_CLIENT_ID": "@epm_client_id",
    "EPM_CLIENT_SECRET": "@epm_client_secret",
    "TENANT_UID": "@tenant_uid"
  }
}
```

### Database Migrations
1. Apply `schema-complete.sql` to Supabase
2. Verify all tables created
3. Test RLS policies
4. Seed test data

## Next Steps (Priority Order)

1. **Database Migration** - Apply schema-complete.sql
2. **Complete Accessors** - Build remaining accessors
3. **Patient Sync** - Implement patient sync from Eyefinity
4. **Appointment Sync Testing** - Verify end-to-end flow
5. **Swagger UI** - Add interactive API documentation
6. **Sync Scheduler** - Automated background syncing
7. **Error Monitoring** - Integrate Sentry or similar
8. **Production RLS** - Lock down database access
9. **Performance Testing** - Load testing with realistic data
10. **Documentation** - Developer docs and user guides

## Success Metrics
- All 14 tables deployed and operational
- All REST APIs functional with Swagger docs
- Appointment sync < 1 minute for 500 appointments
- Zero data loss during sync
- 99.9% uptime on Vercel
- API response times consistently < 500ms
