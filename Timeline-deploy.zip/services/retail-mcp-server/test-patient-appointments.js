import 'dotenv/config';
import { getToken } from './auth.js';

const token = await getToken();
const PE = 'https://api-sandbox.eyefinity.com/al-pe';
const h = { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json', 'Content-Type': 'application/json' };

// Known sandbox IDs
const API9_GUID = 'd3dfa62d-83fc-4cd9-9357-4463720e4617';  // MARLO TEST 1 office
const API9_COMPANY = 'd246db03-a1e4-4963-a6c5-9bf0824aff3f'; // from appointment data
const EXISTING_PATIENT_GUID = '245adb98-c6f8-4c03-a0cd-4a865aeb40ce';

const sep = '─'.repeat(70);
let testNum = 0;
let pass = 0;
let fail = 0;

async function call(method, url, body) {
  const opts = { method, headers: h };
  if (body) opts.body = JSON.stringify(body);
  try {
    const res = await fetch(url, opts);
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch { data = text.substring(0, 500); }
    return { status: res.status, data, headers: res.headers };
  } catch (e) {
    return { status: 'ERR', data: e.message, headers: null };
  }
}

function log(name, result, maxLen = 3000) {
  testNum++;
  const icon = result.status >= 200 && result.status < 300 ? '✅' : result.status >= 400 && result.status < 500 ? '⚠️' : '❌';
  if (result.status >= 200 && result.status < 300) pass++; else fail++;
  console.log(`\n${sep}`);
  console.log(`${icon} ${testNum}) ${name}  [${result.status}]`);
  console.log(sep);
  const str = typeof result.data === 'string' ? result.data : JSON.stringify(result.data, null, 2);
  console.log(str.substring(0, maxLen));
}

// ═══════════════════════════════════════════════════════════════
// 0) GET STAFF LIST (need real staff GUIDs for appointments)
// ═══════════════════════════════════════════════════════════════

console.log('\n' + '═'.repeat(70));
console.log('SETUP — FIND REAL STAFF GUIDs');
console.log('═'.repeat(70));

const staffRes = await call('GET', `${PE}/v2staff?officeId=${API9_GUID}&page=1&pageSize=50`);
log('GET v2staff (get staff for API9 office)', staffRes);

const staffList = Array.isArray(staffRes.data) ? staffRes.data : (staffRes.data?.items || staffRes.data?.Items || []);
let staffGuid = null;
if (staffList.length > 0) {
  console.log(`\n  📋 ${staffList.length} staff members:`);
  for (const s of staffList) {
    const name = `${s.FirstName || s.firstName || ''} ${s.LastName || s.lastName || ''}`.trim();
    const id = s.StaffId || s.EmployeeId || s.Id || s.id;
    const allowSched = s.AllowToBeScheduled || s.allowToBeScheduled;
    console.log(`  • ${name} (ID: ${id}, schedulable: ${allowSched})`);
    if (!staffGuid) staffGuid = id; // Use first staff member
  }
} else {
  console.log('  No staff found via v2staff, checking v2offices endpoint...');
  const offStaffRes = await call('GET', `${PE}/v2offices/${API9_GUID}/staff?page=1&pageSize=50`);
  log('GET v2offices/{office}/staff', offStaffRes);
  const oStaff = Array.isArray(offStaffRes.data) ? offStaffRes.data : (offStaffRes.data?.items || offStaffRes.data?.Items || []);
  if (oStaff.length > 0) {
    staffGuid = oStaff[0].StaffId || oStaff[0].EmployeeId || oStaff[0].Id || oStaff[0].id;
    console.log(`  Using first staff: ${staffGuid}`);
  }
}

// Also get provider with known appointment data from past results
// MARLO ALCON (ProviderId: 4ec9ece0-b41c-40f4-be0d-064450ace2c5) had appointments
const MARLO_PROVIDER = '4ec9ece0-b41c-40f4-be0d-064450ace2c5';

// ═══════════════════════════════════════════════════════════════
// 1) PATIENT SEARCH (with page/pageSize)
// ═══════════════════════════════════════════════════════════════

console.log('\n' + '═'.repeat(70));
console.log('PATIENT CRUD TESTS');
console.log('═'.repeat(70));

// v2patients/search with proper pagination
const searchRes = await call('POST', `${PE}/v2patients/search?page=1&pageSize=10`, {
  LastName: 'Marlo',
  OfficeId: API9_GUID,
});
log('POST v2patients/search?page=1&pageSize=10 (LastName=Marlo)', searchRes);

const patients = Array.isArray(searchRes.data) ? searchRes.data : (searchRes.data?.items || searchRes.data?.Items || []);
if (patients.length > 0) {
  console.log(`\n  📋 ${patients.length} patients found:`);
  for (const p of patients.slice(0, 10)) {
    const name = `${p.FirstName || ''} ${p.LastName || ''}`.trim();
    const id = p.PatientId || p.patientId || p.Id || p.id;
    const legId = p.PatientLegacyId || p.LegacyId || '';
    console.log(`  • ${name} (GUID: ${id}, Legacy: ${legId})`);
  }
}

// Get existing patient by GUID
const getPatientRes = await call('GET', `${PE}/v2patients/${EXISTING_PATIENT_GUID}?page=1&pageSize=1`);
log(`GET v2patients/${EXISTING_PATIENT_GUID}`, getPatientRes);

// Try getting a patient we know exists from appointment data (Morticia Marlo-Adams)
const MORTICIA_GUID = '81a37f94-60ae-4fd1-9228-21338db530f1';
const getMorticiaRes = await call('GET', `${PE}/v2patients/${MORTICIA_GUID}?page=1&pageSize=1`);
log(`GET v2patients/${MORTICIA_GUID} (Morticia Marlo-Adams)`, getMorticiaRes);

// ═══════════════════════════════════════════════════════════════
// 2) CREATE A NEW PATIENT
// ═══════════════════════════════════════════════════════════════

const uniqueSuffix = Date.now().toString().slice(-6);
const newPatient = {
  PatientId: 0,
  FirstName: 'TestAI',
  LastName: `Marlo${uniqueSuffix}`,
  Dob: '1990-05-15',
  HomeOfficeId: API9_GUID,
  ExamOfficeId: API9_GUID,
  PrimaryProviderId: MARLO_PROVIDER,
  PhoneNumbers: [
    { Number: '5551234567', IsPrimary: true, Type: 'Mobile' }
  ],
  Email: `testai${uniqueSuffix}@example.com`,
  Gender: 'Male',
};
const createRes = await call('POST', `${PE}/v2patients`, newPatient);
log('POST v2patients (create)', createRes);

// Also try without PrimaryProviderId (might not be needed)
if (createRes.status >= 400) {
  const simplePatient = {
    FirstName: 'TestAI',
    LastName: `Simple${uniqueSuffix}`,
    Dob: '1990-05-15',
    HomeOfficeId: API9_GUID,
    PhoneNumbers: [
      { Number: '5551234567', IsPrimary: true, Type: 'Mobile' }
    ],
  };
  const createRes2 = await call('POST', `${PE}/v2patients`, simplePatient);
  log('POST v2patients (minimal payload)', createRes2);

  // Try with OfficeId instead of HomeOfficeId
  if (createRes2.status >= 400) {
    const altPatient = {
      FirstName: 'TestAI',
      LastName: `Alt${uniqueSuffix}`,
      DateOfBirth: '1990-05-15',
      OfficeId: API9_GUID,
      Phone: '5551234567',
    };
    const createRes3 = await call('POST', `${PE}/v2patients`, altPatient);
    log('POST v2patients (alt field names)', createRes3);
  }
}

let newPatientGuid = null;
if (createRes.status >= 200 && createRes.status < 300) {
  newPatientGuid = createRes.data?.PatientId || createRes.data?.patientId;
  const loc = createRes.headers?.get('location');
  if (loc) {
    const m = loc.match(/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i);
    if (m) newPatientGuid = m[1];
  }
  console.log(`  🆔 Created patient: ${newPatientGuid}`);
}

// ═══════════════════════════════════════════════════════════════
// 3) UPDATE PATIENT — try PUT instead of PATCH
// ═══════════════════════════════════════════════════════════════

const patientToUpdate = newPatientGuid || MORTICIA_GUID;
console.log(`\n  Updating patient: ${patientToUpdate}`);

// Try PUT v2patients/{guid}
const putRes = await call('PUT', `${PE}/v2patients/${patientToUpdate}`, {
  Email: `updated${uniqueSuffix}@example.com`,
  PhoneNumbers: [
    { Number: '5559876543', IsPrimary: true, Type: 'Mobile' }
  ],
});
log(`PUT v2patients/${patientToUpdate}`, putRes);

// Try POST v2patients/{guid} (some APIs use POST for update)
if (putRes.status >= 400) {
  const postRes = await call('POST', `${PE}/v2patients/${patientToUpdate}`, {
    Email: `updated${uniqueSuffix}@example.com`,
    PhoneNumbers: [
      { Number: '5559876543', IsPrimary: true, Type: 'Mobile' }
    ],
  });
  log(`POST v2patients/${patientToUpdate} (update via POST)`, postRes);
}

// ═══════════════════════════════════════════════════════════════
// 4) GET APPOINTMENTS (we know there are 15 in the past)
// ═══════════════════════════════════════════════════════════════

console.log('\n' + '═'.repeat(70));
console.log('APPOINTMENT TESTS');
console.log('═'.repeat(70));

// Past appointments — we know these exist
const past = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
const today = new Date().toISOString().split('T')[0];
const future = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

const pastRes = await call('GET', `${PE}/v2appointments?fromDate=${past}&toDate=${future}&officeId=${API9_GUID}&page=1&pageSize=50`);
log(`GET v2appointments (${past} to ${future})`, pastRes, 1000);

const allAppts = Array.isArray(pastRes.data) ? pastRes.data : (pastRes.data?.items || pastRes.data?.Items || []);
console.log(`\n  📋 ${allAppts.length} total appointments`);
for (const a of allAppts.slice(0, 5)) {
  const name = `${a.PatientFirstName || ''} ${a.PatientLastName || ''}`.trim();
  const apptId = a.AppointmentId || a.appointmentId;
  console.log(`  • ${a.AppointmentDate?.split('T')[0]} ${a.AppointmentStartTime} — ${name} [${apptId}]`);
}

// ═══════════════════════════════════════════════════════════════
// 5) CREATE APPOINTMENT — using STAFF GUID (not provider)
// ═══════════════════════════════════════════════════════════════

// Use Marlo Alcon's employee ID from appointment data — they appear as both provider AND staff creator
const apptPatient = MORTICIA_GUID;
const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000);
const apptDate = tomorrow.toISOString().split('T')[0];

// Try with the staff GUID we found
if (staffGuid) {
  const createAppt = {
    PatientId: apptPatient,
    OfficeId: API9_GUID,
    StaffId: staffGuid,
    AppointmentDate: apptDate,
    AppointmentStartTime: '10:00',
    AppointmentEndTime: '10:30',
    AppointmentTypeId: 197367,  // Routine Vision Exam - New Pt
    AppointmentReason: 'AI Test Appointment',
    CancelIndicator: false,
    Notes: [],
  };
  const createApptRes = await call('PUT', `${PE}/v2staff/${staffGuid}/appointments`, createAppt);
  log(`PUT v2staff/${staffGuid}/appointments (create appt ${apptDate})`, createApptRes);

  let newApptId = null;
  if (createApptRes.status >= 200 && createApptRes.status < 300) {
    newApptId = createApptRes.data?.AppointmentId || createApptRes.data?.appointmentId;
    const loc = createApptRes.headers?.get('location');
    if (loc) console.log(`  📍 Location: ${loc}`);
    console.log(`  🆔 Created appointment: ${newApptId}`);
  }

  // If create worked, try to update it
  if (newApptId) {
    // Try PUT v2appointments/{id} (not PATCH)
    const dayAfter = new Date(Date.now() + 2 * 24 * 60 * 60 * 1000);
    const newDate = dayAfter.toISOString().split('T')[0];

    const updateApptRes = await call('PUT', `${PE}/v2appointments/${newApptId}`, {
      AppointmentDate: newDate,
      AppointmentStartTime: '14:00',
      AppointmentEndTime: '14:30',
    });
    log(`PUT v2appointments/${newApptId} (reschedule to ${newDate})`, updateApptRes);

    // If PUT doesn't work, try POST
    if (updateApptRes.status >= 400) {
      const postApptRes = await call('POST', `${PE}/v2appointments/${newApptId}`, {
        AppointmentDate: newDate,
        AppointmentStartTime: '14:00',
        AppointmentEndTime: '14:30',
      });
      log(`POST v2appointments/${newApptId} (reschedule via POST)`, postApptRes);
    }
  }
} else {
  console.log('\n⏭️  No staff GUID available, trying with provider GUID from existing appointments...');

  // Use Marlo Alcon who had appointments (she's employee 978647)
  const MARLO_EMPLOYEE_ID = '650cd02c-be2e-4616-b403-8dfe7e50dc4e'; // API User employee
  const createAppt = {
    PatientId: apptPatient,
    OfficeId: API9_GUID,
    StaffId: MARLO_PROVIDER,
    AppointmentDate: apptDate,
    AppointmentStartTime: '10:00',
    AppointmentEndTime: '10:30',
    AppointmentTypeId: 197367,
    AppointmentReason: 'AI Test Appointment',
    CancelIndicator: false,
    Notes: [],
  };

  // Try with provider GUID
  const createApptRes = await call('PUT', `${PE}/v2staff/${MARLO_PROVIDER}/appointments`, createAppt);
  log(`PUT v2staff/${MARLO_PROVIDER}/appointments (Marlo Alcon as staff)`, createApptRes);

  // Try with employee GUID
  if (createApptRes.status >= 400) {
    const createApptRes2 = await call('PUT', `${PE}/v2staff/${MARLO_EMPLOYEE_ID}/appointments`, {
      ...createAppt,
      StaffId: MARLO_EMPLOYEE_ID,
    });
    log(`PUT v2staff/${MARLO_EMPLOYEE_ID}/appointments (API User employee)`, createApptRes2);
  }
}

// ═══════════════════════════════════════════════════════════════
// 6) TRY UPDATING AN EXISTING APPOINTMENT
// ═══════════════════════════════════════════════════════════════

// Use Morticia's appointment from the past: 5a0b23bd-b567-4c38-b408-7515d6cc87c8
const EXISTING_APPT = '5a0b23bd-b567-4c38-b408-7515d6cc87c8';

// GET single appointment
const getApptRes = await call('GET', `${PE}/v2appointments/${EXISTING_APPT}`);
log(`GET v2appointments/${EXISTING_APPT}`, getApptRes);

// Try PUT to update
const putApptRes = await call('PUT', `${PE}/v2appointments/${EXISTING_APPT}`, {
  AppointmentDate: '2026-03-15',
  AppointmentStartTime: '11:00',
  AppointmentEndTime: '11:30',
});
log(`PUT v2appointments/${EXISTING_APPT} (reschedule)`, putApptRes);

// Try via the staff endpoint — re-PUT the appointment with the staff path
if (putApptRes.status >= 400) {
  const reCreateRes = await call('PUT', `${PE}/v2staff/${MARLO_PROVIDER}/appointments`, {
    AppointmentId: EXISTING_APPT,
    PatientId: '81a37f94-60ae-4fd1-9228-21338db530f1',
    OfficeId: API9_GUID,
    StaffId: MARLO_PROVIDER,
    AppointmentDate: '2026-03-15',
    AppointmentStartTime: '11:00',
    AppointmentEndTime: '11:30',
    AppointmentTypeId: 1121274,
    AppointmentReason: 'Rescheduled by AI',
    CancelIndicator: false,
    Notes: [],
  });
  log(`PUT v2staff/${MARLO_PROVIDER}/appointments (update existing via re-PUT)`, reCreateRes);
}

// ═══════════════════════════════════════════════════════════════
// 7) APPOINTMENT TYPES (with page/pageSize)
// ═══════════════════════════════════════════════════════════════

const typesRes = await call('GET', `${PE}/v2offices/${API9_GUID}/appointmentTypes?page=1&pageSize=50`);
log(`GET v2offices/${API9_GUID}/appointmentTypes?page=1&pageSize=50`, typesRes);

const types = Array.isArray(typesRes.data) ? typesRes.data : (typesRes.data?.items || typesRes.data?.Items || []);
if (types.length > 0) {
  console.log(`\n  📋 ${types.length} appointment types:`);
  for (const t of types.slice(0, 10)) {
    const name = t.AppointmentTypeName || t.Name || t.name;
    const id = t.AppointmentTypeId || t.Id || t.id;
    const dur = t.Duration || t.duration || '?';
    console.log(`  • ${name} (ID: ${id}, ${dur}min)`);
  }
}

// ═══════════════════════════════════════════════════════════════
// SUMMARY
// ═══════════════════════════════════════════════════════════════

console.log('\n' + '═'.repeat(70));
console.log(`DONE — ${testNum} tests against ${PE}`);
console.log(`  ✅ ${pass} passed   ❌ ${fail} failed`);
console.log('═'.repeat(70));
