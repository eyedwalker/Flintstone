import 'dotenv/config';
import { getToken } from './auth.js';

const token = await getToken();
const PE = 'https://api-sandbox.eyefinity.com/al-pe';
const h = { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json', 'Content-Type': 'application/json' };

const API9_GUID = 'd3dfa62d-83fc-4cd9-9357-4463720e4617';
const COMPANY_GUID = 'd246db03-a1e4-4963-a6c5-9bf0824aff3f';
const ARRELLIO_STAFF = '3ae77931-5e38-43d8-ba34-9e050a12e116';
const MARLO_PROVIDER = '4ec9ece0-b41c-40f4-be0d-064450ace2c5';
const MORTICIA_PATIENT = '81a37f94-60ae-4fd1-9228-21338db530f1';

// Appointment we just created
const CREATED_APPT = 'd34bf412-b580-4d50-85b7-e977a70a65ab';

const sep = '─'.repeat(70);
let testNum = 0, pass = 0, fail = 0;

async function call(method, url, body) {
  const opts = { method, headers: h };
  if (body) opts.body = JSON.stringify(body);
  try {
    const res = await fetch(url, opts);
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch { data = text.substring(0, 500); }
    return { status: res.status, data, headers: res.headers };
  } catch (e) {
    return { status: 'ERR', data: e.message, headers: null };
  }
}

function log(name, result, maxLen = 2000) {
  testNum++;
  const ok = result.status >= 200 && result.status < 300;
  const icon = ok ? '✅' : result.status >= 400 && result.status < 500 ? '⚠️' : '❌';
  if (ok) pass++; else fail++;
  console.log(`\n${sep}`);
  console.log(`${icon} ${testNum}) ${name}  [${result.status}]`);
  console.log(sep);
  const str = typeof result.data === 'string' ? result.data : JSON.stringify(result.data, null, 2);
  console.log(str.substring(0, maxLen));
}

// ═══════════════════════════════════════════════════════════════
// FIX 1: CREATE PATIENT — use STAFF guid as PrimaryProviderId
// ═══════════════════════════════════════════════════════════════

console.log('\n' + '═'.repeat(70));
console.log('FIX 1: PATIENT CREATE with staff GUID as PrimaryProviderId');
console.log('═'.repeat(70));

const uniqueSuffix = Date.now().toString().slice(-6);

// Try with staff GUID as PrimaryProviderId
const createRes1 = await call('POST', `${PE}/v2patients`, {
  PatientId: 0,
  FirstName: 'TestAI',
  LastName: `CreatedByAI${uniqueSuffix}`,
  Dob: '1990-05-15',
  HomeOfficeId: API9_GUID,
  ExamOfficeId: API9_GUID,
  PrimaryProviderId: ARRELLIO_STAFF,  // Staff GUID instead of provider
  PhoneNumbers: [{ Number: '5551234567', IsPrimary: true, Type: 'Mobile' }],
  Gender: 'Male',
});
log('POST v2patients (PrimaryProviderId=staff GUID)', createRes1);

// Try with provider GUID but different fields
if (createRes1.status >= 400) {
  // Maybe needs legacy integer ID?
  const createRes2 = await call('POST', `${PE}/v2patients`, {
    PatientId: 0,
    FirstName: 'TestAI',
    LastName: `CreatedByAI${uniqueSuffix}b`,
    Dob: '1990-05-15',
    HomeOfficeId: API9_GUID,
    ExamOfficeId: API9_GUID,
    PrimaryProviderId: MARLO_PROVIDER,
    PhoneNumbers: [{ Number: '5551234567', IsPrimary: true, Type: 'Mobile' }],
    Gender: 'M',  // M not Male — matching Morticia's data
    Addresses: [{ Address: '123 Test St', City: 'Test', State: 'CA', ZipCode: '90210', Country: 'United States', IsPrimary: true, AddressType: 'Home' }],
  });
  log('POST v2patients (with Gender=M, Address)', createRes2);
}

// Try creating from Morticia-like patient (copy known-good structure)
if (createRes1.status >= 400) {
  const createRes3 = await call('POST', `${PE}/v2patients`, {
    PatientId: 0,
    FirstName: 'TestAI',
    LastName: `CreatedByAI${uniqueSuffix}c`,
    Dob: '1990-05-15 00:00:00.000',  // Match exact format from existing patient
    HomeOfficeId: API9_GUID,
    ExamOfficeId: API9_GUID,
    PrimaryProviderId: MARLO_PROVIDER,
    PhoneNumbers: [{ Number: '5551234567', IsPrimary: true, Type: 'Mobile', IsBadPhone: false }],
    Gender: 'M',
    Email: `testai${uniqueSuffix}@mailinator.com`,
    Addresses: [{ Address: '123 Test St', City: 'Rancho Cordova', State: 'CA', ZipCode: '95670', Country: 'United States', IsPrimary: true, AddressType: 'Home' }],
    CommunicationPreference: 'MAIL',
  });
  log('POST v2patients (full Morticia-like payload)', createRes3);
}

let newPatientGuid = null;
for (const r of [createRes1]) {
  if (r.status >= 200 && r.status < 300) {
    newPatientGuid = r.data?.PatientId || r.data?.patientId;
    break;
  }
}

// ═══════════════════════════════════════════════════════════════
// FIX 2: UPDATE APPOINTMENT via re-PUT with staff endpoint
// ═══════════════════════════════════════════════════════════════

console.log('\n' + '═'.repeat(70));
console.log('FIX 2: UPDATE APPOINTMENT via re-PUT to v2staff');
console.log('═'.repeat(70));

// The v2staff/{staffId}/appointments PUT endpoint creates appointments.
// To UPDATE, we should send the existing AppointmentId in the payload.
const reschedRes = await call('PUT', `${PE}/v2staff/${ARRELLIO_STAFF}/appointments`, {
  AppointmentId: CREATED_APPT,
  PatientId: MORTICIA_PATIENT,
  OfficeId: API9_GUID,
  StaffId: ARRELLIO_STAFF,
  AppointmentDate: '2026-02-25',
  AppointmentStartTime: '14:00',
  AppointmentEndTime: '14:30',
  AppointmentTypeId: 197367,
  AppointmentReason: 'Rescheduled by AI',
  CancelIndicator: false,
  Notes: [],
});
log(`PUT v2staff/${ARRELLIO_STAFF}/appointments (update appt ${CREATED_APPT} → Feb 25 14:00)`, reschedRes);

// ═══════════════════════════════════════════════════════════════
// FIX 3: CANCEL APPOINTMENT via POST to v2staff/{}/appointments
// ═══════════════════════════════════════════════════════════════

console.log('\n' + '═'.repeat(70));
console.log('FIX 3: CANCEL APPOINTMENT');
console.log('═'.repeat(70));

// Try v2staff/{staffId}/appointments/{appointmentId}/cancel
const cancelRes1 = await call('POST', `${PE}/v2staff/${ARRELLIO_STAFF}/appointments/${CREATED_APPT}/cancel`, {
  reason: 'Cancelled by AI test',
});
log(`POST v2staff/.../appointments/${CREATED_APPT}/cancel`, cancelRes1);

// Try v2appointments/{id}/cancel
if (cancelRes1.status >= 400) {
  const cancelRes2 = await call('POST', `${PE}/v2appointments/${CREATED_APPT}/cancel`, {
    reason: 'Cancelled by AI test',
  });
  log(`POST v2appointments/${CREATED_APPT}/cancel`, cancelRes2);
}

// Try with CancelIndicator via the PUT
if (cancelRes1.status >= 400) {
  const cancelRes3 = await call('PUT', `${PE}/v2staff/${ARRELLIO_STAFF}/appointments`, {
    AppointmentId: CREATED_APPT,
    PatientId: MORTICIA_PATIENT,
    OfficeId: API9_GUID,
    StaffId: ARRELLIO_STAFF,
    AppointmentDate: '2026-02-25',
    AppointmentStartTime: '14:00',
    AppointmentEndTime: '14:30',
    AppointmentTypeId: 197367,
    CancelIndicator: true,  // Cancel via flag
    Notes: [],
  });
  log('PUT v2staff/.../appointments (CancelIndicator=true)', cancelRes3);
}

// ═══════════════════════════════════════════════════════════════
// EXPLORE: Other patient update endpoints
// ═══════════════════════════════════════════════════════════════

console.log('\n' + '═'.repeat(70));
console.log('EXPLORE: Patient update methods');
console.log('═'.repeat(70));

// Try v2patients/{guid}/phonenumbers
const phoneRes = await call('PUT', `${PE}/v2patients/${MORTICIA_PATIENT}/phonenumbers`, [
  { Number: '5559876543', IsPrimary: true, Type: 'Mobile', IsBadPhone: false },
]);
log(`PUT v2patients/${MORTICIA_PATIENT}/phonenumbers`, phoneRes);

// Try v2patients/{guid}/addresses
const addrRes = await call('PUT', `${PE}/v2patients/${MORTICIA_PATIENT}/addresses`, [
  { Address: '456 Updated St', City: 'Updated City', State: 'CA', ZipCode: '95670', Country: 'United States', IsPrimary: true, AddressType: 'Home' },
]);
log(`PUT v2patients/${MORTICIA_PATIENT}/addresses`, addrRes);

// Try v2patients/{guid}/email
const emailRes = await call('PUT', `${PE}/v2patients/${MORTICIA_PATIENT}/email`, {
  Email: `updated${uniqueSuffix}@mailinator.com`,
});
log(`PUT v2patients/${MORTICIA_PATIENT}/email`, emailRes);

// Try PATCH with proper Content-Type
const patchRes = await call('PATCH', `${PE}/v2patients/${MORTICIA_PATIENT}`, [
  { op: 'replace', path: '/Email', value: `patched${uniqueSuffix}@mailinator.com` },
]);
log(`PATCH v2patients/${MORTICIA_PATIENT} (JSON Patch format)`, patchRes);

// Try v2patients/{guid}/communicationmethods
const commRes = await call('PUT', `${PE}/v2patients/${MORTICIA_PATIENT}/communicationmethods`, [
  { CommunicationEventType: 1, Call: true, Email: true, Text: true, Mail: true },
]);
log(`PUT v2patients/${MORTICIA_PATIENT}/communicationmethods`, commRes);

// ═══════════════════════════════════════════════════════════════
// VERIFY: Get all appointments to confirm our changes
// ═══════════════════════════════════════════════════════════════

console.log('\n' + '═'.repeat(70));
console.log('VERIFY: Check appointments after changes');
console.log('═'.repeat(70));

const verifyRes = await call('GET', `${PE}/v2appointments?fromDate=2026-02-19&toDate=2026-03-30&officeId=${API9_GUID}&page=1&pageSize=50`);
log('GET v2appointments (Feb-Mar 2026)', verifyRes, 1500);

const appts = Array.isArray(verifyRes.data) ? verifyRes.data : [];
console.log(`\n  📋 ${appts.length} upcoming appointments:`);
for (const a of appts) {
  const name = `${a.PatientFirstName || ''} ${a.PatientLastName || ''}`.trim();
  const staff = `${a.StaffFirstName || a.ProviderFirstName || ''} ${a.StaffLastName || a.ProviderLastName || ''}`.trim();
  const canceled = a.CancelIndicator ? ' [CANCELLED]' : '';
  console.log(`  • ${a.AppointmentDate?.split('T')[0]} ${a.AppointmentStartTime} — ${name} w/ ${staff}${canceled} [${a.AppointmentId}]`);
}

// ═══════════════════════════════════════════════════════════════
// SUMMARY
// ═══════════════════════════════════════════════════════════════

console.log('\n' + '═'.repeat(70));
console.log(`DONE — ${testNum} tests`);
console.log(`  ✅ ${pass} passed   ❌ ${fail} failed`);
console.log('═'.repeat(70));
