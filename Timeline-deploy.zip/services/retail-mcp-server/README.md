# Eyefinity Retail API — MCP Server

Standalone [Model Context Protocol](https://modelcontextprotocol.io/) server that exposes the Eyefinity Retail API (`/hosting-retailAPI`) as 38 tools for Claude Desktop or Claude Code.

## Quick Start

```bash
cd services/retail-mcp-server
npm install
```

Copy `.env.example` to `.env` and fill in your OAuth credentials:

```
RETAIL_API_BASE_URL=https://alsandapi1.eyefinity.com/hosting-retailAPI
EPM_CLIENT_ID=your-client-id
EPM_CLIENT_SECRET=your-client-secret
TENANT_UID=your-tenant-uid
OAUTH_HOST=api-sandbox.eyefinity.com
```

Test that the server starts:

```bash
node index.js
# Server will wait for JSON-RPC input on stdin — Ctrl+C to stop
```

## Claude Desktop Config

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "eyefinity-retail": {
      "command": "node",
      "args": ["/absolute/path/to/services/retail-mcp-server/index.js"],
      "env": {
        "RETAIL_API_BASE_URL": "https://alsandapi1.eyefinity.com/hosting-retailAPI",
        "EPM_CLIENT_ID": "...",
        "EPM_CLIENT_SECRET": "...",
        "TENANT_UID": "...",
        "OAUTH_HOST": "api-sandbox.eyefinity.com"
      }
    }
  }
}
```

## Claude Code Config

Add to `.claude/settings.json` or project settings:

```json
{
  "mcpServers": {
    "eyefinity-retail": {
      "command": "node",
      "args": ["services/retail-mcp-server/index.js"],
      "env": {
        "RETAIL_API_BASE_URL": "https://alsandapi1.eyefinity.com/hosting-retailAPI",
        "EPM_CLIENT_ID": "...",
        "EPM_CLIENT_SECRET": "...",
        "TENANT_UID": "...",
        "OAUTH_HOST": "api-sandbox.eyefinity.com"
      }
    }
  }
}
```

## Tools (38 total)

### Frames & Contact Lenses (8)
| Tool | Description |
|------|-------------|
| `search_frames` | Search frame catalog by keyword |
| `get_frame_by_upc` | Get frame by UPC barcode |
| `get_frame_colors` | Get colors for a frame model |
| `get_frame_sizes` | Get sizes for a frame model |
| `get_frame_details` | Get full details for a frame variant |
| `search_contact_lenses` | Search contact lens catalog |
| `get_contact_lens_parameters` | Get parameters for a contact lens |
| `get_visionweb_catalog` | Get VisionWeb catalog |

### Patient (7)
| Tool | Description |
|------|-------------|
| `get_patient_rx` | Get patient prescriptions |
| `get_patient_insurance_benefits` | Get insurance benefits |
| `get_patient_insurance_eligibility` | Check eligibility |
| `get_patient_pricing` | Get patient-specific pricing |
| `get_patient_promotions` | Get patient promotions |
| `get_patient_orders` | Get order history |
| `get_patient_order_detail` | Get order details |

### Pricing & Promotions (7)
| Tool | Description |
|------|-------------|
| `calculate_pricing` | Calculate pricing for items |
| `get_lens_pricing` | Get lens pricing catalog |
| `get_frame_pricing` | Get frame pricing by UPC |
| `get_promotions` | Get active promotions |
| `get_promotion_details` | Get promotion details |
| `apply_promotion` | Apply promotion to items |
| `get_discount_reasons` | Get discount reason codes |

### Orders (3)
| Tool | Description |
|------|-------------|
| `create_order` | Create a new order |
| `update_order` | Update an existing order |
| `submit_order_to_lab` | Submit order to lab |

### Tax (6)
| Tool | Description |
|------|-------------|
| `get_tax_rates` | Get office tax rates |
| `calculate_tax` | Calculate tax for items |
| `get_tax_exemptions` | Get exemption types |
| `get_tax_categories` | Get tax categories |
| `get_state_tax_rules` | Get state tax rules |
| `validate_tax_exempt_id` | Validate exemption ID |

### Selling Models (4)
| Tool | Description |
|------|-------------|
| `get_selling_models` | Get selling models |
| `get_selling_model_details` | Get model details |
| `get_lens_recommendations` | Get lens recommendations |
| `get_package_options` | Get package options |

### Other (3)
| Tool | Description |
|------|-------------|
| `get_office_settings` | Get office retail settings |
| `get_lab_list` | Get available labs |
| `get_measurements_template` | Get measurements template |

## Authentication

Uses the same 2-step OAuth 2.0 flow as the main Eyefinity API proxy:

1. **Client Credentials** → initial access token
2. **Token Exchange** → EPM token with tenant context (`tenantuid` header)

Tokens are cached in memory for ~25 minutes (30-minute expiry minus 5-minute buffer).
On 401 responses, the token is automatically invalidated and a fresh token is obtained for a single retry.
