#!/usr/bin/env node

/**
 * Eyefinity Retail API — MCP Server
 *
 * Exposes 38 tools covering frames, contact lenses, patient data,
 * pricing, promotions, orders, tax, selling models, and more.
 *
 * Transport: stdio (JSON-RPC over stdin/stdout)
 * Auth: 2-step OAuth (client credentials → token exchange)
 */

import 'dotenv/config';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';

import { registerFrameTools } from './tools/frames.js';
import { registerPatientTools } from './tools/patient.js';
import { registerPricingTools } from './tools/pricing.js';
import { registerOrderTools } from './tools/orders.js';
import { registerTaxTools } from './tools/tax.js';
import { registerSellingModelTools } from './tools/selling-models.js';
import { registerOtherTools } from './tools/other.js';

const server = new McpServer({
  name: 'eyefinity-retail',
  version: '1.0.0',
});

// Register all tool groups
registerFrameTools(server);
registerPatientTools(server);
registerPricingTools(server);
registerOrderTools(server);
registerTaxTools(server);
registerSellingModelTools(server);
registerOtherTools(server);

// Connect via stdio
const transport = new StdioServerTransport();
await server.connect(transport);

console.error('[eyefinity-retail] MCP server running on stdio');
