/**
 * Retail API HTTP Client
 *
 * Wraps fetch() with:
 *  - OAuth bearer token injection (via auth.js)
 *  - Automatic 401 retry (invalidate + re-auth once)
 *  - 15-second request timeout
 *  - Message envelope helper for POST requests
 */

import { getToken, invalidateToken } from './auth.js';

const BASE_URL = process.env.RETAIL_API_BASE_URL || 'https://alsandapi1.eyefinity.com/hosting-retailAPI';

/**
 * Make an authenticated request to the Retail API.
 *
 * @param {string} method  HTTP method
 * @param {string} path    API path (e.g. "/api/Retail/FindFrames")
 * @param {object} [opts]
 * @param {object} [opts.body]   JSON body for POST/PUT
 * @param {object} [opts.query]  Query parameters { key: value }
 * @returns {Promise<any>}       Parsed JSON response
 */
export async function request(method, path, { body, query } = {}) {
  const url = buildUrl(path, query);
  const token = await getToken();
  const res = await doFetch(method, url, token, body);

  // 401 → invalidate token and retry once
  if (res.status === 401) {
    console.error(`[retail-client] 401 on ${method} ${path}, refreshing token…`);
    invalidateToken();
    const newToken = await getToken();
    const retry = await doFetch(method, url, newToken, body);
    return parseResponse(retry);
  }

  return parseResponse(res);
}

/**
 * Build a standard message envelope for POST requests.
 * All Retail API POST bodies require messageId, correlationId, timestampUtc.
 */
export function envelope(fields = {}) {
  return {
    messageId: crypto.randomUUID(),
    correlationId: crypto.randomUUID(),
    timestampUtc: new Date().toISOString(),
    ...fields,
  };
}

// ─── Internal ────────────────────────────────────────────────

function buildUrl(path, query) {
  const url = new URL(`${BASE_URL}${path}`);
  if (query) {
    for (const [k, v] of Object.entries(query)) {
      if (v !== undefined && v !== null && v !== '') {
        url.searchParams.append(k, String(v));
      }
    }
  }
  return url.toString();
}

async function doFetch(method, url, token, body) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  const opts = {
    method,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
    signal: controller.signal,
  };

  if (body && method !== 'GET' && method !== 'HEAD') {
    opts.body = JSON.stringify(body);
  }

  try {
    const res = await fetch(url, opts);
    clearTimeout(timeout);
    return res;
  } catch (e) {
    clearTimeout(timeout);
    if (e.name === 'AbortError') {
      throw new Error(`Request timeout: ${method} ${url}`);
    }
    throw e;
  }
}

async function parseResponse(res) {
  const contentType = res.headers.get('content-type') || '';
  let data;

  if (contentType.includes('application/json')) {
    data = await res.json();
  } else {
    data = await res.text();
  }

  // Retail API returns 500 with structured errors — pass through
  // so the LLM can see the error details
  if (!res.ok && typeof data === 'string') {
    throw new Error(`Retail API ${res.status}: ${data}`);
  }

  return data;
}
