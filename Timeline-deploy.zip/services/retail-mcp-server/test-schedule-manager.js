import 'dotenv/config';
import { getToken } from './auth.js';
const token = await getToken();
const h = { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json', 'Content-Type': 'application/json' };

const PE = 'https://api-sandbox.eyefinity.com/al-pe';
const API9_GUID = 'd3dfa62d-83fc-4cd9-9357-4463720e4617';
const startDate = '2026-02-20';
const endDate = '2026-04-20';

const providers = [
  { name: 'Saul Test', id: '3a2aa937-de4c-467d-a2f9-9a4d296adc35' },
  { name: 'Seth Pearce', id: '0218cf28-3867-459a-bb8e-92a274b6f822' },
  { name: 'Ken Rivers', id: '6a563106-8a52-412a-a9ac-009d2c5213f7' },
];

console.log('v2staff/{providerId}/appointmentSlots with office GUID\n');

for (const p of providers) {
  const url = `${PE}/v2staff/${p.id}/appointmentSlots?officeId=${API9_GUID}&fromDate=${startDate}&toDate=${endDate}&page=1&pageSize=50`;
  const r = await fetch(url, { headers: h });
  const data = await r.json();
  const slots = Array.isArray(data) ? data : (data.items || data.Items || []);
  const icon = r.status === 200 ? (slots.length > 0 ? '✅' : '⚠️') : '❌';
  console.log(`${icon} ${p.name}: ${r.status} — ${slots.length} slots`);
  if (slots.length > 0) {
    for (const s of slots.slice(0, 10)) {
      console.log(`  ${s.Date || s.date} ${s.StartTime || s.startTime}-${s.EndTime || s.endTime}`);
    }
    console.log('\nRaw first slot:');
    console.log(JSON.stringify(slots[0], null, 2));
  }
  if (r.status >= 400) {
    console.log(`  Error: ${JSON.stringify(data).substring(0, 300)}`);
  }
}

// Also try v2providers endpoint for slots
console.log('\n\nv2providers/{id}/appointmentSlots with office GUID\n');

for (const p of providers) {
  const url = `${PE}/v2providers/${p.id}/appointmentSlots?officeId=${API9_GUID}&fromDate=${startDate}&toDate=${endDate}&page=1&pageSize=50`;
  const r = await fetch(url, { headers: h });
  const text = await r.text();
  let data;
  try { data = JSON.parse(text); } catch { data = text.substring(0, 300); }
  const slots = Array.isArray(data) ? data : (data?.items || data?.Items || []);
  const icon = r.status === 200 ? (slots.length > 0 ? '✅' : '⚠️') : '❌';
  console.log(`${icon} ${p.name}: ${r.status} — ${typeof data === 'string' ? data.substring(0, 100) : slots.length + ' slots'}`);
  if (slots.length > 0) {
    for (const s of slots.slice(0, 10)) {
      console.log(`  ${s.Date || s.date} ${s.StartTime || s.startTime}-${s.EndTime || s.endTime}`);
    }
    console.log('\nRaw first slot:');
    console.log(JSON.stringify(slots[0], null, 2));
  }
}

console.log('\nDONE');
