import 'dotenv/config';
import { getToken } from './auth.js';

const token = await getToken();
const BASE = process.env.RETAIL_API_BASE_URL;
const CO = '936';
const OFF = '936';
const PATIENT_ID = 39271525;  // legacy patient ID
const PATIENT_GUID = '245adb98-c6f8-4c03-a0cd-4a865aeb40ce';
const ELIGIBILITY_ID = 10071733;

console.log(`Testing against: ${BASE}`);
console.log(`Patient: ${PATIENT_ID} (${PATIENT_GUID})`);
console.log(`Eligibility: ${ELIGIBILITY_ID}\n`);

async function call(method, path, body) {
  const opts = {
    method,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
  };
  if (body) opts.body = JSON.stringify(body);
  try {
    const res = await fetch(`${BASE}${path}`, opts);
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch { data = text; }
    return { status: res.status, data };
  } catch (e) {
    return { status: 'ERR', data: e.cause?.code || e.message };
  }
}

const env = (f) => ({ messageId: crypto.randomUUID(), correlationId: crypto.randomUUID(), timestampUtc: new Date().toISOString(), ...f });
const sep = '─'.repeat(70);
let testNum = 0;
let pass = 0;
let fail = 0;

function log(name, result, maxLen = 2000) {
  testNum++;
  const icon = result.status === 200 ? '✅' : result.status === 500 ? '❌' : '⚠️';
  if (result.status === 200) pass++; else fail++;
  console.log(`\n${sep}`);
  console.log(`${icon} ${testNum}) ${name}  [${result.status}]`);
  console.log(sep);
  console.log(JSON.stringify(result.data, null, 2).substring(0, maxLen));
}

// ═══════════════════════════════════════════════════════════════
// SYSTEM / HEALTH
// ═══════════════════════════════════════════════════════════════

log('GET /version', await call('GET', '/version'));
log('GET /components', await call('GET', '/components'), 500);
log('GET /healthcheck?officeNum=936', await call('GET', '/healthcheck?officeNum=936'));
log('POST CheckStatus', await call('POST', '/api/Retail/CheckStatus', env({ stayInProcess: false })));

// ═══════════════════════════════════════════════════════════════
// FRAMES
// ═══════════════════════════════════════════════════════════════

const framesRes = await call('POST', '/api/Retail/FindFrames', env({
  frameSearchDTO: {
    companyExternalId: CO, officeExternalId: OFF,
    searchText: '', skip: 0, take: 5, draw: 1, showOnHandOnly: false, retailFrom: 0, retailTo: 0,
  },
  isFavoriteFramesOnly: false, patientInternalId: 0,
}));
log('POST FindFrames (browse all, take 5)', framesRes);

// Grab first frame's itemId for detail call
const firstFrame = framesRes.data?.frames?.[0];
const itemId = firstFrame?.catalogItemInternalId;

if (itemId) {
  log(`GET GetFrameDetail (itemId=${itemId})`, await call('GET', `/api/Retail/GetFrameDetail?companyId=${CO}&officeNum=${OFF}&itemId=${itemId}`));
}

// Search by keyword
log('POST FindFrames (searchText: "Gant")', await call('POST', '/api/Retail/FindFrames', env({
  frameSearchDTO: {
    companyExternalId: CO, officeExternalId: OFF,
    searchText: 'Gant', skip: 0, take: 5, draw: 1, showOnHandOnly: false, retailFrom: 0, retailTo: 0,
  },
  isFavoriteFramesOnly: false, patientInternalId: 0,
})));

log('POST FindFramesCollections', await call('POST', '/api/Retail/FindFramesCollections', env({
  companyExternalId: CO, officeExternalId: OFF, skip: 0, take: 100,
})));

log('POST FindFramesFilters', await call('POST', '/api/Retail/FindFramesFilters', env({
  frameSearchDTO: {
    companyExternalId: CO, officeExternalId: OFF,
    searchText: '', skip: 0, take: 0, draw: 1,
  },
})));

log('POST FindStylesFilters', await call('POST', '/api/Retail/FindStylesFilters', env({
  frameSearchDTO: {
    companyExternalId: CO, officeExternalId: OFF,
    searchText: '', skip: 0, take: 0, draw: 1,
  },
})));

// ═══════════════════════════════════════════════════════════════
// CONTACT LENSES
// ═══════════════════════════════════════════════════════════════

log('POST LookupContactLensFormularies (planId=0)', await call('POST', '/api/Retail/LookupContactLensFormularies', env({
  companyExternalId: CO, officeExternalId: OFF, insurancePlanInternalId: 0,
})));

// ═══════════════════════════════════════════════════════════════
// SELLING MODELS → DETAILS → PACKAGES (sequential chain)
// ═══════════════════════════════════════════════════════════════

const smRes = await call('GET', `/api/Retail/FindSellingModels?companyId=${CO}`);
log('GET FindSellingModels', smRes);

// Walk through ALL selling models sequentially
const sellingModels = smRes.data?.sellingModels || [];
if (sellingModels.length > 0) {
  console.log(`\n   📋 Found ${sellingModels.length} selling models — fetching details & packages for each...\n`);

  for (const sm of sellingModels) {
    const smId = sm.sellingModelId || sm.id;
    const smName = sm.sellingModelName || sm.name || smId;

    // Get details for this selling model
    const detailRes = await call('GET', `/api/Retail/GetSellingModelDetails?sellingModelId=${smId}`);
    log(`GET GetSellingModelDetails ("${smName}", id=${smId})`, detailRes);

    // Get packages for this selling model
    const pkgRes = await call('GET', `/api/Retail/GetSellingModelPackages?sellingModelId=${smId}`);
    log(`GET GetSellingModelPackages ("${smName}", id=${smId})`, pkgRes);

    // If packages exist, log the package names
    const packages = pkgRes.data?.packages || pkgRes.data?.sellingModelPackages || [];
    if (packages.length > 0) {
      console.log(`   📦 ${packages.length} packages: ${packages.map(p => p.packageName || p.name || 'unnamed').join(', ')}`);
    }
  }
} else {
  console.log('\n   ⏭️  No selling models found, skipping detail/package calls');
}

// ═══════════════════════════════════════════════════════════════
// PRICING CONFIGURATION
// ═══════════════════════════════════════════════════════════════

log('GET FindOrderPricingConfigurationAsync', await call('GET', `/api/Retail/FindOrderPricingConfigurationAsync?OfficeExternalId=${OFF}&CompanyExternalId=${CO}`));

// ═══════════════════════════════════════════════════════════════
// PROMOTIONS (with real patient)
// ═══════════════════════════════════════════════════════════════

log('POST FindAvailablePromotions (no patient)', await call('POST', '/api/Retail/FindAvailablePromotions', env({
  companyExternalId: CO, officeExternalId: OFF, patientInternalId: 0,
})));

log(`POST FindAvailablePromotions (patient=${PATIENT_ID})`, await call('POST', '/api/Retail/FindAvailablePromotions', env({
  companyExternalId: CO, officeExternalId: OFF, patientInternalId: PATIENT_ID,
})));

log(`GET FindPatientPromotionCouponCodes (patient=${PATIENT_ID})`, await call('GET', `/api/Retail/FindPatientPromotionCouponCodes?patientId=${PATIENT_ID}`));

// ═══════════════════════════════════════════════════════════════
// TAX
// ═══════════════════════════════════════════════════════════════

log('GET FindOfficeTaxConfigs', await call('GET', `/api/Retail/FindOfficeTaxConfigs?officeExternalIds=${OFF}`));

log('POST CalculateSalesTaxes (empty line items)', await call('POST', '/api/Retail/CalculateSalesTaxes', env({
  officeExternalId: OFF, companyExternalId: CO,
  patientInternalId: 0, patientName: '',
  taxEntityExternalId: '', orderType: 'Eyeglass',
  shouldUseThompsonReuters: false,
  lineItems: [], orderLineItems: [],
})));

// ═══════════════════════════════════════════════════════════════
// LABS
// ═══════════════════════════════════════════════════════════════

log('GET FindLabsForPrivateOrders (CA)', await call('GET', `/api/Retail/FindLabsForPrivateOrders?doctorState=CA&efan=${OFF}`));

// ═══════════════════════════════════════════════════════════════
// PATIENT-DEPENDENT (with real patient ID)
// ═══════════════════════════════════════════════════════════════

log(`POST FindPatientRxs (patient=${PATIENT_ID})`, await call('POST', '/api/Retail/FindPatientRxs', env({
  patientInternalId: PATIENT_ID, examRxTypeInternalId: 0,
})));

log(`POST GetCostOverview (patient=${PATIENT_ID}, eligibility=${ELIGIBILITY_ID})`, await call('POST', '/api/Retail/GetCostOverview', env({
  patientInternalId: PATIENT_ID, eligibilityInternalId: ELIGIBILITY_ID, officeExternalId: OFF,
})));

// ═══════════════════════════════════════════════════════════════
// RX CONVERSION
// ═══════════════════════════════════════════════════════════════

log('POST ConvertPatientEyeglassRx (synthetic)', await call('POST', '/api/Retail/ConvertPatientEyeglassRx', env({
  leftEye: { sphere: -2.25, cylinder: -0.75, axis: 180, add: 0 },
  rightEye: { sphere: -1.50, cylinder: -1.00, axis: 170, add: 0 },
  convertToType: 'PlusCylinder',
})));

// ═══════════════════════════════════════════════════════════════
// INSURANCE (with real eligibility ID)
// ═══════════════════════════════════════════════════════════════

log(`POST CalculateInsuranceBenefits (eligibility=${ELIGIBILITY_ID})`, await call('POST', '/api/Retail/CalculateInsuranceBenefits', env({
  eligibilityInternalId: ELIGIBILITY_ID,
  officeExternalId: OFF,
  companyExternalId: CO,
  patientInternalId: PATIENT_ID,
})));

// ═══════════════════════════════════════════════════════════════
// SUMMARY
// ═══════════════════════════════════════════════════════════════

console.log('\n' + '═'.repeat(70));
console.log(`DONE — ${testNum} endpoints tested against ${BASE}`);
console.log(`  ✅ ${pass} passed   ❌ ${fail} failed`);
console.log('═'.repeat(70));
