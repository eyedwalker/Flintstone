/**
 * Frame & Contact Lens Tools (7 tools)
 *
 * Maps to: FindFrames, FindFramesCollections, FindFramesFilters,
 *          FindStylesFilters, GetFrameDetail, LookupContactLensFormularies,
 *          FindPatientRxs, ConvertPatientEyeglassRx
 */

import { z } from 'zod';
import { request, envelope } from '../retail-client.js';

function text(data) {
  return { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] };
}

export function registerFrameTools(server) {

  server.tool(
    'find_frames',
    'Search the frame catalog by keyword, filters, or browse all frames. Returns matching frames with brand, model, color, pricing.',
    {
      companyExternalId: z.string().describe('Company external ID (e.g. "936")'),
      officeExternalId: z.string().describe('Office external ID (e.g. "936")'),
      searchText: z.string().optional().describe('Search keyword (brand name, model, etc.)'),
      showOnHandOnly: z.boolean().optional().describe('Only show frames in stock'),
      retailFrom: z.number().optional().describe('Minimum retail price filter'),
      retailTo: z.number().optional().describe('Maximum retail price filter'),
      skip: z.number().optional().describe('Number of results to skip (for paging, default 0)'),
      take: z.number().optional().describe('Number of results to return (default 25)'),
      isFavoriteFramesOnly: z.boolean().optional().describe('Only show favorite frames'),
      patientInternalId: z.number().optional().describe('Patient internal ID (for patient-specific results)'),
    },
    async ({ companyExternalId, officeExternalId, searchText, showOnHandOnly, retailFrom, retailTo, skip, take, isFavoriteFramesOnly, patientInternalId }) => {
      const data = await request('POST', '/api/Retail/FindFrames', {
        body: envelope({
          frameSearchDTO: {
            companyExternalId,
            officeExternalId,
            searchText: searchText || '',
            showOnHandOnly: showOnHandOnly || false,
            retailFrom: retailFrom || 0,
            retailTo: retailTo || 0,
            skip: skip || 0,
            take: take || 25,
            draw: 1,
          },
          isFavoriteFramesOnly: isFavoriteFramesOnly || false,
          patientInternalId: patientInternalId || 0,
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'find_frames_collections',
    'Get available frame collections (brands/lines) for an office.',
    {
      companyExternalId: z.string().describe('Company external ID'),
      officeExternalId: z.string().describe('Office external ID'),
      skip: z.number().optional().describe('Skip count (default 0)'),
      take: z.number().optional().describe('Take count (default 50)'),
    },
    async ({ companyExternalId, officeExternalId, skip, take }) => {
      const data = await request('POST', '/api/Retail/FindFramesCollections', {
        body: envelope({
          companyExternalId,
          officeExternalId,
          skip: skip || 0,
          take: take || 50,
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'find_frames_filters',
    'Get available filter options for frame search (categories, colors, sizes, etc.).',
    {
      companyExternalId: z.string().describe('Company external ID'),
      officeExternalId: z.string().describe('Office external ID'),
      searchText: z.string().optional().describe('Current search text to get relevant filters'),
    },
    async ({ companyExternalId, officeExternalId, searchText }) => {
      const data = await request('POST', '/api/Retail/FindFramesFilters', {
        body: envelope({
          frameSearchDTO: {
            companyExternalId,
            officeExternalId,
            searchText: searchText || '',
            skip: 0,
            take: 0,
            draw: 1,
          },
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'get_frame_detail',
    'Get full details for a specific frame by item ID.',
    {
      companyId: z.string().describe('Company ID'),
      officeNum: z.string().describe('Office number'),
      itemId: z.number().describe('Frame catalog item internal ID'),
    },
    async ({ companyId, officeNum, itemId }) => {
      const data = await request('GET', '/api/Retail/GetFrameDetail', {
        query: { companyId, officeNum, itemId },
      });
      return text(data);
    }
  );

  server.tool(
    'lookup_contact_lens_formularies',
    'Look up contact lens formularies (insurance-covered lenses) for an office.',
    {
      companyExternalId: z.string().describe('Company external ID'),
      officeExternalId: z.string().describe('Office external ID'),
      insurancePlanInternalId: z.number().describe('Insurance plan internal ID'),
    },
    async ({ companyExternalId, officeExternalId, insurancePlanInternalId }) => {
      const data = await request('POST', '/api/Retail/LookupContactLensFormularies', {
        body: envelope({
          companyExternalId,
          officeExternalId,
          insurancePlanInternalId,
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'find_patient_rxs',
    'Get prescription (Rx) records for a patient.',
    {
      patientInternalId: z.number().describe('Patient internal ID'),
      examRxTypeInternalId: z.number().optional().describe('Exam/Rx type filter (0 for all)'),
    },
    async ({ patientInternalId, examRxTypeInternalId }) => {
      const data = await request('POST', '/api/Retail/FindPatientRxs', {
        body: envelope({
          patientInternalId,
          examRxTypeInternalId: examRxTypeInternalId || 0,
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'convert_patient_eyeglass_rx',
    'Convert a patient eyeglass Rx between formats (e.g., minus to plus cylinder).',
    {
      leftEye: z.object({
        sphere: z.number().describe('Sphere power'),
        cylinder: z.number().describe('Cylinder power'),
        axis: z.number().describe('Axis in degrees'),
        add: z.number().optional().describe('Add power'),
      }).describe('Left eye Rx'),
      rightEye: z.object({
        sphere: z.number().describe('Sphere power'),
        cylinder: z.number().describe('Cylinder power'),
        axis: z.number().describe('Axis in degrees'),
        add: z.number().optional().describe('Add power'),
      }).describe('Right eye Rx'),
      convertToType: z.string().describe('Target format (e.g., "PlusCylinder", "MinusCylinder")'),
    },
    async ({ leftEye, rightEye, convertToType }) => {
      const data = await request('POST', '/api/Retail/ConvertPatientEyeglassRx', {
        body: envelope({ leftEye, rightEye, convertToType }),
      });
      return text(data);
    }
  );
}
