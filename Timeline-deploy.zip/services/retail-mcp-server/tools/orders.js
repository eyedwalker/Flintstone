/**
 * VisionWeb Order Tools (4 tools)
 *
 * Maps to: ValidateVisionwebLens, ValidateVisionwebDesignForEyes,
 *          SubmitVisionwebOrders, UpdateVisionwebOrderStatus
 */

import { z } from 'zod';
import { request, envelope } from '../retail-client.js';

function text(data) {
  return { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] };
}

export function registerOrderTools(server) {

  server.tool(
    'validate_visionweb_lens',
    'Validate a lens selection with VisionWeb before ordering.',
    {
      lensData: z.record(z.any()).describe('Lens data to validate (product code, parameters, etc.)'),
    },
    async ({ lensData }) => {
      const data = await request('POST', '/api/Retail/ValidateVisionwebLens', {
        body: envelope(lensData),
      });
      return text(data);
    }
  );

  server.tool(
    'validate_visionweb_design_for_eyes',
    'Validate that left and right lens selections have compatible material and style.',
    {
      lensDesignData: z.record(z.any()).describe('Left/right lens design data to validate'),
    },
    async ({ lensDesignData }) => {
      const data = await request('POST', '/api/Retail/ValidateVisionwebDesignForEyes', {
        body: envelope(lensDesignData),
      });
      return text(data);
    }
  );

  server.tool(
    'submit_visionweb_orders',
    'Submit finalized orders to VisionWeb for lab processing.',
    {
      orderData: z.record(z.any()).describe('Order submission data'),
    },
    async ({ orderData }) => {
      const data = await request('POST', '/api/Retail/SubmitVisionwebOrders', {
        body: envelope(orderData),
      });
      return text(data);
    }
  );

  server.tool(
    'update_visionweb_order_status',
    'Update the status of a VisionWeb order.',
    {
      orderStatusData: z.record(z.any()).describe('Order status update data'),
    },
    async ({ orderStatusData }) => {
      const data = await request('POST', '/api/Retail/UpdateVisionwebOrderStatus', {
        body: envelope(orderStatusData),
      });
      return text(data);
    }
  );
}
