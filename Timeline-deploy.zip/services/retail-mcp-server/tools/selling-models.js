/**
 * Selling Model & Package Tools (4 tools)
 *
 * Maps to: FindSellingModels, GetSellingModelDetails,
 *          GetSellingModelPackages, FindPackages
 */

import { z } from 'zod';
import { request } from '../retail-client.js';

function text(data) {
  return { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] };
}

export function registerSellingModelTools(server) {

  server.tool(
    'find_selling_models',
    'Get available selling models (pricing strategies) for a company.',
    {
      companyId: z.string().describe('Company ID'),
    },
    async ({ companyId }) => {
      const data = await request('GET', '/api/Retail/FindSellingModels', {
        query: { companyId },
      });
      return text(data);
    }
  );

  server.tool(
    'get_selling_model_details',
    'Get details for a specific selling model (display settings, price points).',
    {
      sellingModelId: z.string().describe('Selling model ID'),
    },
    async ({ sellingModelId }) => {
      const data = await request('GET', '/api/Retail/GetSellingModelDetails', {
        query: { sellingModelId },
      });
      return text(data);
    }
  );

  server.tool(
    'get_selling_model_packages',
    'Get available packages for a selling model (bundled lens + coating deals).',
    {
      sellingModelId: z.string().describe('Selling model ID'),
      patientId: z.number().optional().describe('Patient internal ID (for patient-specific packages)'),
    },
    async ({ sellingModelId, patientId }) => {
      const data = await request('GET', '/api/Retail/GetSellingModelPackages', {
        query: { sellingModelId, patientId },
      });
      return text(data);
    }
  );

  server.tool(
    'find_packages',
    'Get package details by package IDs.',
    {
      packageIds: z.array(z.string()).describe('Package IDs to look up'),
    },
    async ({ packageIds }) => {
      const params = new URLSearchParams();
      packageIds.forEach(id => params.append('packageIds', id));
      const data = await request('GET', `/api/Retail/FindPackages?${params.toString()}`);
      return text(data);
    }
  );
}
