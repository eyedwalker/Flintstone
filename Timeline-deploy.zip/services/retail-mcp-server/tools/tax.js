/**
 * Tax Tools (6 tools)
 *
 * Maps to: CalculateSalesTaxes, CommitSalesTaxes, ReverseSalesTaxes,
 *          FindOfficeTaxConfigs, AddOfficeTaxConfig, UpdateOfficeTaxConfig
 */

import { z } from 'zod';
import { request, envelope } from '../retail-client.js';

function text(data) {
  return { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] };
}

export function registerTaxTools(server) {

  server.tool(
    'calculate_sales_taxes',
    'Calculate sales taxes for order line items.',
    {
      officeExternalId: z.string().describe('Office external ID'),
      companyExternalId: z.string().describe('Company external ID'),
      patientInternalId: z.number().describe('Patient internal ID'),
      patientName: z.string().optional().describe('Patient name'),
      taxEntityExternalId: z.string().optional().describe('Tax entity external ID'),
      orderType: z.string().optional().describe('Order type (e.g., "Eyeglass", "ContactLens")'),
      shouldUseThompsonReuters: z.boolean().optional().describe('Use Thomson Reuters tax service'),
    },
    async ({ officeExternalId, companyExternalId, patientInternalId, patientName, taxEntityExternalId, orderType, shouldUseThompsonReuters }) => {
      const data = await request('POST', '/api/Retail/CalculateSalesTaxes', {
        body: envelope({
          officeExternalId,
          companyExternalId,
          patientInternalId,
          patientName: patientName || '',
          taxEntityExternalId: taxEntityExternalId || '',
          orderType: orderType || '',
          shouldUseThompsonReuters: shouldUseThompsonReuters || false,
          lineItems: [],
          orderLineItems: [],
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'commit_sales_taxes',
    'Commit sales taxes for a finalized order (marks transaction as taxable).',
    {
      officeExternalId: z.string().describe('Office external ID'),
      taxEntityExternalId: z.string().describe('Tax entity external ID'),
      invoiceSummaryInternalId: z.number().describe('Invoice summary internal ID'),
      orderInternalId: z.number().describe('Order internal ID'),
      patientInternalId: z.number().describe('Patient internal ID'),
      patientName: z.string().optional().describe('Patient name'),
      transactionDate: z.string().optional().describe('Transaction date (ISO)'),
    },
    async ({ officeExternalId, taxEntityExternalId, invoiceSummaryInternalId, orderInternalId, patientInternalId, patientName, transactionDate }) => {
      const data = await request('POST', '/api/Retail/CommitSalesTaxes', {
        body: envelope({
          officeExternalId,
          taxEntityExternalId,
          invoiceSummaryInternalId,
          orderInternalId,
          patientInternalId,
          patientName: patientName || '',
          transactionDate: transactionDate || new Date().toISOString(),
          lineItems: [],
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'reverse_sales_taxes',
    'Reverse/void previously committed sales taxes (for returns or cancellations).',
    {
      officeExternalId: z.string().describe('Office external ID'),
      taxEntityExternalId: z.string().describe('Tax entity external ID'),
      invoiceSummaryInternalId: z.number().describe('Invoice summary internal ID'),
      orderInternalId: z.number().describe('Order internal ID'),
      transactionDate: z.string().optional().describe('Transaction date (ISO)'),
    },
    async ({ officeExternalId, taxEntityExternalId, invoiceSummaryInternalId, orderInternalId, transactionDate }) => {
      const data = await request('POST', '/api/Retail/ReverseSalesTaxes', {
        body: envelope({
          officeExternalId,
          taxEntityExternalId,
          invoiceSummaryInternalId,
          orderInternalId,
          transactionDate: transactionDate || new Date().toISOString(),
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'find_office_tax_configs',
    'Get tax configuration for offices (Thomson Reuters tax entity IDs).',
    {
      officeExternalIds: z.array(z.string()).describe('Office external IDs to look up'),
    },
    async ({ officeExternalIds }) => {
      const params = new URLSearchParams();
      officeExternalIds.forEach(id => params.append('officeExternalIds', id));
      const data = await request('GET', `/api/Retail/FindOfficeTaxConfigs?${params.toString()}`);
      return text(data);
    }
  );

  server.tool(
    'add_office_tax_config',
    'Add tax configuration for an office.',
    {
      officeKey: z.string().describe('Office key/external ID'),
      thomsonReutersTaxEntityId: z.string().describe('Thomson Reuters tax entity ID'),
      isThomsonReutersTaxServiceEnabled: z.boolean().optional().describe('Enable Thomson Reuters tax service'),
    },
    async ({ officeKey, thomsonReutersTaxEntityId, isThomsonReutersTaxServiceEnabled }) => {
      const data = await request('POST', '/api/Retail/AddOfficeTaxConfig', {
        body: envelope({
          officeTaxConfig: {
            officeKey,
            thomsonReutersTaxEntityId,
            isThomsonReutersTaxServiceEnabled: isThomsonReutersTaxServiceEnabled !== false,
          },
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'update_office_tax_config',
    'Update tax configuration for an office.',
    {
      officeTaxConfigKey: z.string().describe('Existing tax config key to update'),
      officeKey: z.string().describe('Office key/external ID'),
      thomsonReutersTaxEntityId: z.string().describe('Updated Thomson Reuters tax entity ID'),
      isThomsonReutersTaxServiceEnabled: z.boolean().optional().describe('Enable/disable Thomson Reuters tax service'),
    },
    async ({ officeTaxConfigKey, officeKey, thomsonReutersTaxEntityId, isThomsonReutersTaxServiceEnabled }) => {
      const data = await request('POST', '/api/Retail/UpdateOfficeTaxConfig', {
        body: envelope({
          officeTaxConfig: {
            officeTaxConfigKey,
            officeKey,
            thomsonReutersTaxEntityId,
            isThomsonReutersTaxServiceEnabled: isThomsonReutersTaxServiceEnabled !== false,
          },
        }),
      });
      return text(data);
    }
  );
}
