/**
 * Patient Tools (5 tools)
 *
 * Maps to: GetCostOverview, AddPatientPromotionCode, AddPatientFavorites,
 *          RemovePatientFavorites, FindPatientPromotionCouponCodes
 */

import { z } from 'zod';
import { request, envelope } from '../retail-client.js';

function text(data) {
  return { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] };
}

export function registerPatientTools(server) {

  server.tool(
    'get_cost_overview',
    'Get cost overview / buying power for a patient (insurance coverage summary).',
    {
      patientInternalId: z.number().describe('Patient internal ID'),
      eligibilityInternalId: z.number().optional().describe('Insurance eligibility internal ID (0 for none)'),
      officeExternalId: z.string().describe('Office external ID'),
    },
    async ({ patientInternalId, eligibilityInternalId, officeExternalId }) => {
      const data = await request('POST', '/api/Retail/GetCostOverview', {
        body: envelope({
          patientInternalId,
          eligibilityInternalId: eligibilityInternalId || 0,
          officeExternalId,
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'add_patient_promotion_code',
    'Apply a promotion/coupon code for a patient.',
    {
      patientInternalId: z.number().describe('Patient internal ID'),
      couponCode: z.string().describe('Coupon/promotion code'),
      companyExternalId: z.string().describe('Company external ID'),
    },
    async ({ patientInternalId, couponCode, companyExternalId }) => {
      const data = await request('POST', '/api/Retail/AddPatientPromotionCode', {
        body: envelope({
          patientInternalId,
          couponCode,
          companyExternalId,
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'add_patient_favorites',
    'Add a catalog item to a patient\'s favorites.',
    {
      patientInternalId: z.number().describe('Patient internal ID'),
      catalogItemInternalId: z.number().describe('Catalog item internal ID'),
      favoriteNote: z.string().optional().describe('Note about why this was favorited'),
    },
    async ({ patientInternalId, catalogItemInternalId, favoriteNote }) => {
      const data = await request('POST', '/api/Retail/AddPatientFavorites', {
        body: envelope({
          patientInternalId,
          catalogItemInternalId,
          favoriteNote: favoriteNote || '',
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'remove_patient_favorites',
    'Remove a catalog item from a patient\'s favorites.',
    {
      patientId: z.number().describe('Patient internal ID'),
      itemId: z.number().describe('Catalog item internal ID'),
    },
    async ({ patientId, itemId }) => {
      const data = await request('GET', '/api/Retail/RemovePatientFavorites', {
        query: { patientId, itemId },
      });
      return text(data);
    }
  );

  server.tool(
    'find_patient_promotion_coupon_codes',
    'Find promotion coupon codes available for a patient.',
    {
      patientId: z.number().describe('Patient internal ID'),
      couponCode: z.string().optional().describe('Specific coupon code to look up'),
    },
    async ({ patientId, couponCode }) => {
      const data = await request('GET', '/api/Retail/FindPatientPromotionCouponCodes', {
        query: { patientId, couponCode },
      });
      return text(data);
    }
  );
}
