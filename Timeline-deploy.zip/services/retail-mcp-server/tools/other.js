/**
 * System & Lab Tools (4 tools)
 *
 * Maps to: CheckStatus, FindLabsForPrivateOrders, version, components
 */

import { z } from 'zod';
import { request, envelope } from '../retail-client.js';

function text(data) {
  return { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] };
}

export function registerOtherTools(server) {

  server.tool(
    'check_status',
    'Check the status/health of the Retail API pipeline (PricingEngine, SharedServices).',
    {},
    async () => {
      const data = await request('POST', '/api/Retail/CheckStatus', {
        body: envelope({ stayInProcess: false }),
      });
      return text(data);
    }
  );

  server.tool(
    'find_labs_for_private_orders',
    'Find labs available for private (non-VSP) orders.',
    {
      doctorState: z.string().describe('Doctor\'s state (two-letter code, e.g. "CA")'),
      efan: z.string().describe('EFAN (Eyefinity Account Number)'),
    },
    async ({ doctorState, efan }) => {
      const data = await request('GET', '/api/Retail/FindLabsForPrivateOrders', {
        query: { doctorState, efan },
      });
      return text(data);
    }
  );

  server.tool(
    'get_api_version',
    'Get the Retail API version and build info.',
    {},
    async () => {
      const data = await request('GET', '/version');
      return text(data);
    }
  );

  server.tool(
    'get_api_components',
    'Get hosted VBD components and their versions.',
    {},
    async () => {
      const data = await request('GET', '/components');
      return text(data);
    }
  );
}
