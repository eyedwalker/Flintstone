/**
 * Pricing, Promotions & Insurance Tools (7 tools)
 *
 * Maps to: CalculateEstimatedCharges, FindAvailablePromotions, ApplyPromotion,
 *          FindOrderPricingAsync, FindOrderPricingConfigurationAsync,
 *          CalculateInsuranceBenefits, SaveOrderPricingAsync
 */

import { z } from 'zod';
import { request, envelope } from '../retail-client.js';

function text(data) {
  return { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] };
}

export function registerPricingTools(server) {

  server.tool(
    'calculate_estimated_charges',
    'Calculate estimated charges for an order (with insurance eligibility).',
    {
      eligibilityId: z.number().describe('Insurance eligibility internal ID'),
      orderInternalId: z.number().describe('Order internal ID'),
      officeExternalId: z.string().describe('Office external ID'),
    },
    async ({ eligibilityId, orderInternalId, officeExternalId }) => {
      const data = await request('POST', '/api/Retail/CalculateEstimatedCharges', {
        body: envelope({
          eligibilityId,
          order: { orderInternalId, officeExternalId },
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'find_available_promotions',
    'Find promotions available for an order.',
    {
      companyExternalId: z.string().describe('Company external ID'),
      officeExternalId: z.string().describe('Office external ID'),
      patientInternalId: z.number().optional().describe('Patient internal ID'),
    },
    async ({ companyExternalId, officeExternalId, patientInternalId }) => {
      const data = await request('POST', '/api/Retail/FindAvailablePromotions', {
        body: envelope({
          companyExternalId,
          officeExternalId,
          patientInternalId: patientInternalId || 0,
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'apply_promotion',
    'Apply a promotion to order invoice summaries.',
    {
      promotionInternalId: z.number().describe('Promotion internal ID to apply'),
      promotionCouponCode: z.string().optional().describe('Coupon code'),
      pairOneOrderInternalId: z.number().optional().describe('Pair-one order ID (for BOGO)'),
    },
    async ({ promotionInternalId, promotionCouponCode, pairOneOrderInternalId }) => {
      const data = await request('POST', '/api/Retail/ApplyPromotion', {
        body: envelope({
          promotionInternalId,
          promotionCouponCode: promotionCouponCode || '',
          pairOneOrderInternalId: pairOneOrderInternalId || 0,
          invoiceSummaries: [],
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'find_order_pricing',
    'Get pricing details for an existing order.',
    {
      orderId: z.string().optional().describe('Order external ID'),
      orderInternalId: z.number().optional().describe('Order internal ID'),
      companyExternalId: z.string().describe('Company external ID'),
      officeExternalId: z.string().describe('Office external ID'),
    },
    async ({ orderId, orderInternalId, companyExternalId, officeExternalId }) => {
      const data = await request('GET', '/api/Retail/FindOrderPricingAsync', {
        query: {
          OrderId: orderId,
          OrderInternalId: orderInternalId,
          CompanyExternalId: companyExternalId,
          OfficeExternalId: officeExternalId,
        },
      });
      return text(data);
    }
  );

  server.tool(
    'find_order_pricing_configuration',
    'Get order pricing configuration for an office (promise days, feature flags, warranties, etc.).',
    {
      officeExternalId: z.string().describe('Office external ID'),
      companyExternalId: z.string().describe('Company external ID'),
    },
    async ({ officeExternalId, companyExternalId }) => {
      const data = await request('GET', '/api/Retail/FindOrderPricingConfigurationAsync', {
        query: {
          OfficeExternalId: officeExternalId,
          CompanyExternalId: companyExternalId,
        },
      });
      return text(data);
    }
  );

  server.tool(
    'calculate_insurance_benefits',
    'Calculate insurance benefits for an order (coverage, copays, patient responsibility).',
    {
      primaryEligibilityId: z.number().optional().describe('Primary insurance eligibility ID'),
      secondaryEligibilityId: z.number().optional().describe('Secondary insurance eligibility ID'),
      orderInternalId: z.number().describe('Order internal ID'),
      companyExternalId: z.string().describe('Company external ID'),
      officeExternalId: z.string().describe('Office external ID'),
    },
    async ({ primaryEligibilityId, secondaryEligibilityId, orderInternalId, companyExternalId, officeExternalId }) => {
      const data = await request('POST', '/api/Retail/CalculateInsuranceBenefits', {
        body: envelope({
          primaryEligibility: primaryEligibilityId ? { eligibilityId: primaryEligibilityId } : null,
          secondaryEligibility: secondaryEligibilityId ? { eligibilityId: secondaryEligibilityId } : null,
          pricingDetail: { orderInternalId, companyExternalId, officeExternalId },
          acknowledgements: [],
        }),
      });
      return text(data);
    }
  );

  server.tool(
    'save_order_pricing',
    'Save/update pricing for an order.',
    {
      orderInternalId: z.number().describe('Order internal ID'),
      companyExternalId: z.string().describe('Company external ID'),
      officeExternalId: z.string().describe('Office external ID'),
      userInternalId: z.number().describe('Staff/user internal ID'),
    },
    async ({ orderInternalId, companyExternalId, officeExternalId, userInternalId }) => {
      const data = await request('POST', '/api/Retail/SaveOrderPricingAsync', {
        body: envelope({
          orderPricingDetail: { orderInternalId, companyExternalId, officeExternalId },
          userInternalId,
        }),
      });
      return text(data);
    }
  );
}
