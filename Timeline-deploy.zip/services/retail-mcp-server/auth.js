/**
 * OAuth 2.0 Authentication for Eyefinity Retail API
 *
 * 2-step flow (same as api/_lib/eyefinity-auth.js, adapted for standalone use):
 *   1. Client Credentials → initial access token
 *   2. Token Exchange → EPM token with tenant context
 *
 * In-memory cache with 25-minute TTL + single in-flight deduplication.
 */

const EPM_SCOPES = [
  'auth_epm',
  'ef.pm_pe_patient_rx',
  'ef.pm_pe_resource',
  'ef.pm_pe_insurance',
  'ef.pm_pe_appointment',
  'ef.pm_pe_office_recallreport',
  'ef.pm_pe_staff',
  'ef.pm_pe_office',
  'ef.pm_pe_company',
  'ef.pm_pe_order',
  'ef.pm_pe_provider',
  'ef.pm_pe_patient',
  'read:ef.pm_schedule',
].join(' ');

let cachedToken = null;   // { token, expiry }
let fetchPromise = null;  // deduplication

/**
 * Get a valid EPM bearer token (cached or fresh).
 */
export async function getToken() {
  if (cachedToken && Date.now() < cachedToken.expiry) {
    return cachedToken.token;
  }

  // Deduplicate concurrent calls
  if (fetchPromise) return fetchPromise;

  fetchPromise = fetchFreshToken();
  try {
    return await fetchPromise;
  } finally {
    fetchPromise = null;
  }
}

/**
 * Invalidate the cached token (call on 401).
 */
export function invalidateToken() {
  cachedToken = null;
}

// ─── Internal ────────────────────────────────────────────────

async function fetchFreshToken() {
  const clientId = process.env.EPM_CLIENT_ID;
  const clientSecret = process.env.EPM_CLIENT_SECRET;
  const tenantUid = process.env.TENANT_UID;
  const oauthHost = process.env.OAUTH_HOST || 'api-sandbox.eyefinity.com';

  if (!clientId || !clientSecret) {
    throw new Error('EPM_CLIENT_ID and EPM_CLIENT_SECRET must be set');
  }

  // Step 1 — Client Credentials
  const ccToken = await clientCredentials(clientId, clientSecret, oauthHost);

  // Step 2 — Token Exchange
  const { token, expiresIn } = await tokenExchange(ccToken, clientId, clientSecret, tenantUid, oauthHost);

  // Cache with 5-minute buffer
  const ttlMs = (expiresIn - 300) * 1000;
  cachedToken = { token, expiry: Date.now() + ttlMs };

  console.error(`[retail-mcp auth] Token obtained (expires in ~${Math.round(ttlMs / 60000)}m)`);
  return token;
}

async function clientCredentials(clientId, clientSecret, oauthHost) {
  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  const body = `grant_type=client_credentials&scope=${encodeURIComponent(EPM_SCOPES)}`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  try {
    const res = await fetch(`https://${oauthHost}/as/token.oauth2`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body,
      signal: controller.signal,
    });
    clearTimeout(timeout);

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Client credentials failed: ${res.status} - ${err}`);
    }

    const data = await res.json();
    return data.access_token || data.accesstoken;
  } catch (e) {
    clearTimeout(timeout);
    if (e.name === 'AbortError') throw new Error('OAuth timeout - server unreachable');
    throw e;
  }
}

async function tokenExchange(ccToken, clientId, clientSecret, tenantUid, oauthHost) {
  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  const body = new URLSearchParams({
    grant_type: 'urn:ietf:params:oauth:grant-type:token-exchange',
    subject_token: ccToken,
    subject_token_type: 'urn:ietf:params:oauth:token-type:access_token',
    scope: EPM_SCOPES,
    resource: 'https://VspEpmToken',
  }).toString();

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  try {
    const res = await fetch(`https://${oauthHost}/as/token.oauth2`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        tenantuid: tenantUid || '',
      },
      body,
      signal: controller.signal,
    });
    clearTimeout(timeout);

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Token exchange failed: ${res.status} - ${err}`);
    }

    const data = await res.json();
    return {
      token: data.access_token || data.accesstoken,
      expiresIn: data.expires_in || 1799,
    };
  } catch (e) {
    clearTimeout(timeout);
    if (e.name === 'AbortError') throw new Error('Token exchange timeout');
    throw e;
  }
}
