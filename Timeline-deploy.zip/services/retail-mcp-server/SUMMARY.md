# Eyefinity Retail API — MCP Server

**Status**: Working prototype on `pm-ci.eyefinity.com`
**Location**: `services/retail-mcp-server/`
**Last tested**: 2026-02-18

---

## What Is This?

A **Model Context Protocol (MCP) server** that exposes the Eyefinity Retail API (`/hosting-retailAPI`) as **38 callable tools** for AI assistants (Claude Code, Claude Desktop). The AI can search frames, look up patient Rx data, calculate pricing, manage orders, and more — all through natural language.

**Example**: *"Search for Gant frames in office 936"* → Claude calls `find_frames` → returns real catalog data.

### How It Works

```
Claude Desktop / Claude Code
  ↕ stdio (JSON-RPC)
MCP Server (Node.js)
  → 2-step OAuth (client credentials + token exchange)
  → HTTP calls to Retail API
  → Returns structured data to Claude
```

The server runs locally, authenticates via the existing EPM OAuth flow, and translates MCP tool calls into Retail API requests. All POST endpoints use the standard message envelope (`messageId`, `correlationId`, `timestampUtc`).

---

## Architecture

```
services/retail-mcp-server/
├── index.js              # MCP server entry point (StdioServerTransport)
├── auth.js               # 2-step OAuth flow (25-min cached tokens)
├── retail-client.js      # HTTP wrapper (auth injection, 401 retry, 15s timeout)
├── package.json          # @modelcontextprotocol/sdk, zod, dotenv
├── .env                  # Credentials & base URL (not committed)
├── .env.example          # Template
└── tools/
    ├── frames.js         # 7 tools — frame search, detail, collections, filters, Rx, contact lenses
    ├── patient.js        # 5 tools — cost overview, favorites, promotions
    ├── pricing.js        # 7 tools — charges, promotions, insurance benefits, order pricing
    ├── orders.js         # 4 tools — VisionWeb lens validation, order submission
    ├── tax.js            # 6 tools — sales tax calculation, commit, reverse, config
    ├── selling-models.js # 4 tools — selling models, packages
    └── other.js          # 5 tools — health check, labs, version, components
```

---

## 38 Tools by Category

### Frames & Contact Lenses (7 tools)

| Tool | Method | Endpoint | Description |
|------|--------|----------|-------------|
| `find_frames` | POST | `FindFrames` | Search frame catalog by keyword, filters, browse all |
| `find_frames_collections` | POST | `FindFramesCollections` | Get available frame collections/brands |
| `find_frames_filters` | POST | `FindFramesFilters` | Get filter options (category, shape, gender, color) |
| `get_frame_detail` | GET | `GetFrameDetail` | Full details for a specific frame (manufacturer, measurements, edge type) |
| `lookup_contact_lens_formularies` | POST | `LookupContactLensFormularies` | Insurance-covered contact lenses by plan ID |
| `find_patient_rxs` | POST | `FindPatientRxs` | Get prescription records for a patient |
| `convert_patient_eyeglass_rx` | POST | `ConvertPatientEyeglassRx` | Convert Rx between minus/plus cylinder formats |

### Patient Management (5 tools)

| Tool | Method | Endpoint | Description |
|------|--------|----------|-------------|
| `get_cost_overview` | POST | `GetCostOverview` | Insurance coverage summary / buying power |
| `add_patient_promotion_code` | POST | `AddPatientPromotionCode` | Apply a coupon code for a patient |
| `add_patient_favorites` | POST | `AddPatientFavorites` | Add catalog item to patient's favorites |
| `remove_patient_favorites` | GET | `RemovePatientFavorites` | Remove item from favorites |
| `find_patient_promotion_coupon_codes` | GET | `FindPatientPromotionCouponCodes` | List available coupon codes for a patient |

### Pricing, Promotions & Insurance (7 tools)

| Tool | Method | Endpoint | Description |
|------|--------|----------|-------------|
| `calculate_estimated_charges` | POST | `CalculateEstimatedCharges` | Calculate charges with insurance eligibility |
| `find_available_promotions` | POST | `FindAvailablePromotions` | Find promotions available for an order |
| `apply_promotion` | POST | `ApplyPromotion` | Apply promotion to order invoice summaries |
| `find_order_pricing` | GET | `FindOrderPricingAsync` | Get pricing for an existing order |
| `find_order_pricing_configuration` | GET | `FindOrderPricingConfigurationAsync` | Pricing config (promise days, feature flags, warranties) |
| `calculate_insurance_benefits` | POST | `CalculateInsuranceBenefits` | Calculate coverage, copays, patient responsibility |
| `save_order_pricing` | POST | `SaveOrderPricingAsync` | Save/update order pricing |

### VisionWeb Orders (4 tools)

| Tool | Method | Endpoint | Description |
|------|--------|----------|-------------|
| `validate_visionweb_lens` | POST | `ValidateVisionwebLens` | Validate lens selection before ordering |
| `validate_visionweb_design_for_eyes` | POST | `ValidateVisionwebDesignForEyes` | Validate L/R lens compatibility |
| `submit_visionweb_orders` | POST | `SubmitVisionwebOrders` | Submit orders to VisionWeb for lab processing |
| `update_visionweb_order_status` | POST | `UpdateVisionwebOrderStatus` | Update VisionWeb order status |

### Tax Management (6 tools)

| Tool | Method | Endpoint | Description |
|------|--------|----------|-------------|
| `calculate_sales_taxes` | POST | `CalculateSalesTaxes` | Calculate sales taxes for order line items |
| `commit_sales_taxes` | POST | `CommitSalesTaxes` | Commit taxes (mark transaction as taxable) |
| `reverse_sales_taxes` | POST | `ReverseSalesTaxes` | Reverse/void committed taxes (returns) |
| `find_office_tax_configs` | GET | `FindOfficeTaxConfigs` | Get tax config for offices |
| `add_office_tax_config` | POST | `AddOfficeTaxConfig` | Add tax config for an office |
| `update_office_tax_config` | POST | `UpdateOfficeTaxConfig` | Update tax config for an office |

### Selling Models & Packages (4 tools)

| Tool | Method | Endpoint | Description |
|------|--------|----------|-------------|
| `find_selling_models` | GET | `FindSellingModels` | Get available selling models (pricing strategies) |
| `get_selling_model_details` | GET | `GetSellingModelDetails` | Model details (display settings, price points) |
| `get_selling_model_packages` | GET | `GetSellingModelPackages` | Packages for a selling model (bundled deals) |
| `find_packages` | GET | `FindPackages` | Get package details by IDs |

### System & Labs (5 tools)

| Tool | Method | Endpoint | Description |
|------|--------|----------|-------------|
| `check_status` | POST | `CheckStatus` | Health check of full pipeline |
| `find_labs_for_private_orders` | GET | `FindLabsForPrivateOrders` | Labs for non-VSP orders by state |
| `find_styles_filters` | POST | `FindStylesFilters` | Get style filter options |
| `get_api_version` | GET | `/version` | API version and build info |
| `get_api_components` | GET | `/components` | Hosted VBD component versions |

---

## Test Results (pm-ci.eyefinity.com, office 936)

**15 of 23 endpoints returned 200** on 2026-02-18.

### Working

| Endpoint | Notes |
|----------|-------|
| `/version` | v4.4.1335 |
| `/components` | 30+ service components |
| `/healthcheck` | OK |
| `CheckStatus` | Full pipeline verified |
| `FindFrames` (browse) | **1000 frames** with real catalog data |
| `FindFrames` (search) | Keyword search works (e.g., "Gant") |
| `GetFrameDetail` | Full detail: manufacturer, shape, measurements, edge type |
| `FindFramesCollections` | 20+ collections (ADIDAS, Gant, NIKE, CALVIN KLEIN, etc.) |
| `FindFramesFilters` | Categories, shapes, genders, statuses |
| `FindSellingModels` | 200 OK but **empty** for company 936 — needs correct companyId |
| `FindOrderPricingConfigurationAsync` | Full pricing configuration |
| `CalculateSalesTaxes` | Works (empty line items) |
| `FindPatientRxs` | 200 OK but empty for test patient — needs patient with Rx in CI |
| `FindPatientPromotionCouponCodes` | 200 OK |
| `CalculateInsuranceBenefits` | 200 but needs real eligibility + order data |

### Needs Data / Investigation

| Endpoint | Issue | What's Needed |
|----------|-------|---------------|
| `FindStylesFilters` | 500 — "Unable to get frame style data" | May be CI environment issue |
| `LookupContactLensFormularies` | 500 — "use correct planId" | Real `insurancePlanInternalId` |
| `FindAvailablePromotions` | 500 — "Unexpected error" | May need promo data configured in CI |
| `FindOfficeTaxConfigs` | 500 — "Not Found" | No tax config for office 936 |
| `FindLabsForPrivateOrders` | 500 — "Unauthorized" | May need additional OAuth scopes |
| `GetCostOverview` | 500 — NullRef | Needs valid selling model + eligibility together |
| `ConvertPatientEyeglassRx` | 500 — conversion failed | Rx field format may differ from Swagger |

---

## Authentication

Reuses the existing **2-step EPM OAuth flow** from the Eyefinity platform:

```
Step 1: POST https://{OAUTH_HOST}/as/token.oauth2
        grant_type=client_credentials
        → initial access_token

Step 2: POST https://{OAUTH_HOST}/as/token.oauth2
        grant_type=urn:ietf:params:oauth:grant-type:token-exchange
        subject_token={step1_token}
        resource=https://VspEpmToken
        tenantuid={TENANT_UID}
        → EPM-scoped token (30-min expiry)
```

Tokens are cached in-memory with 25-minute TTL. Concurrent requests share a single in-flight token fetch. On 401, the token is invalidated and one retry is attempted.

---

## Setup

### Prerequisites
- Node.js >= 18
- Network access to target host (VPN may be required for some hosts)
- EPM OAuth credentials

### Install
```bash
cd services/retail-mcp-server
npm install
```

### Configure
Copy `.env.example` to `.env` and fill in credentials:
```env
RETAIL_API_BASE_URL=https://pm-ci.eyefinity.com/hosting-retailAPI
EPM_CLIENT_ID=<your-client-id>
EPM_CLIENT_SECRET=<your-client-secret>
TENANT_UID=<your-tenant-uid>
OAUTH_HOST=api-sandbox.eyefinity.com
DEFAULT_COMPANY_ID=936
DEFAULT_OFFICE_ID=936
```

### Available Hosts
| Host | Status | Notes |
|------|--------|-------|
| `pm-ci.eyefinity.com` | Working | CI environment, has full frame catalog |
| `alsandapi1.eyefinity.com` | Working | Sandbox, limited data |
| `api9.eyefinity.com` | VPN only | DNS unreachable without VPN |

### Connect to Claude Code
```bash
claude mcp add eyefinity-retail \
  --transport stdio \
  -- node services/retail-mcp-server/index.js
```

### Connect to Claude Desktop
Add to `claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "eyefinity-retail": {
      "command": "node",
      "args": ["/absolute/path/to/services/retail-mcp-server/index.js"],
      "env": {
        "RETAIL_API_BASE_URL": "https://pm-ci.eyefinity.com/hosting-retailAPI",
        "EPM_CLIENT_ID": "...",
        "EPM_CLIENT_SECRET": "...",
        "TENANT_UID": "...",
        "OAUTH_HOST": "api-sandbox.eyefinity.com"
      }
    }
  }
}
```

---

## Dependencies
| Package | Version | Purpose |
|---------|---------|---------|
| `@modelcontextprotocol/sdk` | ^1.12.1 | MCP server framework (stdio transport) |
| `zod` | ^3.24.2 | Input schema validation for each tool |
| `dotenv` | ^16.4.7 | Environment variable loading |

---

## What Can You Build With This?

The MCP server is a **toolbox for AI assistants**, not a web API. The AI uses these tools to:

1. **Answer questions** — "What Gant frames do we have in stock?" → searches catalog
2. **Build applications** — Claude can use these tools to write a React/Next.js app that calls the Retail API directly, using real data shapes from the MCP tools to generate accurate TypeScript types and API integration code
3. **Automate workflows** — Chain tools together: find frames → check pricing → calculate insurance → generate order
4. **Explore the API** — Discover endpoints, data shapes, and relationships interactively

---

## Open Questions for Dev

1. **Selling Models**: `FindSellingModels` returns empty for `companyId=936`. What company ID has selling models configured in pm-ci?
2. **FindLabsForPrivateOrders**: Returns "Unauthorized" — does this endpoint require additional OAuth scopes beyond the standard EPM set?
3. **FindAvailablePromotions**: 500 on pm-ci regardless of patient ID — is promotion data configured in CI?
4. **FindStylesFilters**: Server-side "Unable to get frame style data" — known CI issue?
5. **ConvertPatientEyeglassRx**: What exact field format does this expect? The Swagger schema may not match the runtime validation.
6. **Patient Rx data**: Patient 39271525 has no Rx records in pm-ci. Which patients have Rx data for testing?
