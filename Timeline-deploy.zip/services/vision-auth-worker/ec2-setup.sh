#!/bin/bash
# Run this on the apps-server EC2 instance to prepare it for the verification worker
set -e

echo "=== Setting up apps-server for Vision Auth Worker ==="

# Install Docker if not present
if ! command -v docker &> /dev/null; then
  echo "[1] Installing Docker..."
  sudo apt-get update
  sudo apt-get install -y ca-certificates curl gnupg
  sudo install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  sudo chmod a+r /etc/apt/keyrings/docker.gpg
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
    sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
  sudo apt-get update
  sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
  sudo usermod -aG docker $USER
  echo "Docker installed. Log out and back in for group changes."
else
  echo "[1] Docker already installed: $(docker --version)"
fi

# Install AWS CLI if not present
if ! command -v aws &> /dev/null; then
  echo "[2] Installing AWS CLI..."
  curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "/tmp/awscliv2.zip"
  cd /tmp && unzip -q awscliv2.zip && sudo ./aws/install
  rm -rf /tmp/aws /tmp/awscliv2.zip
else
  echo "[2] AWS CLI already installed: $(aws --version)"
fi

# Create worker directory
echo "[3] Creating worker directory..."
sudo mkdir -p /home/ubuntu/vision-auth-worker
sudo chown ubuntu:ubuntu /home/ubuntu/vision-auth-worker

# Create .env file from template
if [ ! -f /home/ubuntu/vision-auth-worker/.env ]; then
  echo "[4] Creating .env file (you must fill in the values)..."
  cat > /home/ubuntu/vision-auth-worker/.env << 'ENVFILE'
# Supabase
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=your-service-key

# Anthropic (for benefit parsing)
ANTHROPIC_API_KEY=your-anthropic-key

# Encryption key for decrypting payer credentials
PAYER_ENCRYPTION_KEY=your-encryption-key

# Worker config
WORKER_ID=apps-server-1
POLL_INTERVAL_SECONDS=5
MAX_CONCURRENT_JOBS=1
JOB_TIMEOUT_SECONDS=300
ENVFILE
  echo "  IMPORTANT: Edit /home/ubuntu/vision-auth-worker/.env with real values!"
else
  echo "[4] .env file already exists"
fi

# Configure AWS credentials for ECR access
echo "[5] Configure AWS credentials for ECR pull access..."
aws configure set region us-west-2

echo ""
echo "=== Setup complete ==="
echo "Next steps:"
echo "  1. Edit /home/ubuntu/vision-auth-worker/.env with your Supabase and Anthropic keys"
echo "  2. Run: aws configure  (set access key for ECR pull)"
echo "  3. Deploy will pull from ECR and start the container"
