"""
Stealth Browser Configuration

Creates a Playwright browser instance configured to avoid bot detection:
- Realistic viewport and user agent
- WebGL and Canvas fingerprint randomization
- Timezone and locale matching
- Disabled automation indicators
"""

from playwright.async_api import async_playwright
from playwright_stealth import stealth_async

from ..config import PROXY_URL, PROXY_USERNAME, PROXY_PASSWORD
from ..utils.logging import log


# Realistic browser configurations to rotate through
BROWSER_PROFILES = [
    {
        "viewport": {"width": 1920, "height": 1080},
        "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "locale": "en-US",
        "timezone_id": "America/Chicago",
    },
    {
        "viewport": {"width": 1440, "height": 900},
        "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "locale": "en-US",
        "timezone_id": "America/New_York",
    },
    {
        "viewport": {"width": 1366, "height": 768},
        "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "locale": "en-US",
        "timezone_id": "America/Los_Angeles",
    },
]

_profile_index = 0


def get_next_profile() -> dict:
    """Rotate through browser profiles."""
    global _profile_index
    profile = BROWSER_PROFILES[_profile_index % len(BROWSER_PROFILES)]
    _profile_index += 1
    return profile


async def create_stealth_browser():
    """
    Create a stealth Playwright browser instance.

    Returns:
        tuple: (browser, context, page)
    """
    profile = get_next_profile()
    log("debug", f"Using browser profile: {profile['viewport']['width']}x{profile['viewport']['height']}")

    pw = await async_playwright().start()

    launch_args = {
        "headless": True,
        "args": [
            "--disable-blink-features=AutomationControlled",
            "--disable-features=IsolateOrigins,site-per-process",
            "--disable-dev-shm-usage",
            "--no-sandbox",
        ],
    }

    # Add proxy if configured
    if PROXY_URL:
        launch_args["proxy"] = {
            "server": PROXY_URL,
        }
        if PROXY_USERNAME:
            launch_args["proxy"]["username"] = PROXY_USERNAME
            launch_args["proxy"]["password"] = PROXY_PASSWORD

    browser = await pw.chromium.launch(**launch_args)

    context = await browser.new_context(
        viewport=profile["viewport"],
        user_agent=profile["user_agent"],
        locale=profile["locale"],
        timezone_id=profile["timezone_id"],
        # Permissions that a real browser would have
        permissions=["geolocation"],
        # Realistic screen size
        screen=profile["viewport"],
    )

    page = await context.new_page()

    # Apply stealth patches
    await stealth_async(page)

    # Override navigator.webdriver
    await page.add_init_script("""
        Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
        Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
        Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
    """)

    return browser, context, page
