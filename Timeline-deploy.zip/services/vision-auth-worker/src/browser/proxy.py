"""
Proxy Rotation Manager (Phase 3)

Manages a pool of residential proxies for avoiding portal rate limiting.
"""

from ..utils.logging import log


class ProxyManager:
    """Manages proxy rotation for browser sessions."""

    def __init__(self, proxies: list[str] | None = None):
        self.proxies = proxies or []
        self._index = 0

    def get_next(self) -> str | None:
        """Get the next proxy URL in rotation."""
        if not self.proxies:
            return None
        proxy = self.proxies[self._index % len(self.proxies)]
        self._index += 1
        log("debug", f"Using proxy {self._index}: {proxy[:20]}...")
        return proxy

    def mark_failed(self, proxy_url: str):
        """Mark a proxy as failed (remove from rotation)."""
        if proxy_url in self.proxies:
            self.proxies.remove(proxy_url)
            log("warn", f"Removed failed proxy: {proxy_url[:20]}... ({len(self.proxies)} remaining)")

    @property
    def available_count(self) -> int:
        return len(self.proxies)
