"""
Credential encryption/decryption utilities.

Uses base64 encoding with a shared key for Phase 1.
In production, migrate to pgcrypto server-side or AWS KMS.
"""

import base64


def decrypt_password(encrypted: str, key: str) -> str:
    """
    Decrypt a password that was encrypted by the API.

    The API uses: base64(key + ":" + password)
    """
    try:
        decoded = base64.b64decode(encrypted).decode("utf-8")
        # Format is "key:password"
        if ":" in decoded:
            stored_key, password = decoded.split(":", 1)
            return password
        return decoded
    except Exception as e:
        raise ValueError(f"Failed to decrypt credential: {e}")


def encrypt_password(password: str, key: str) -> str:
    """Encrypt a password (for testing purposes)."""
    combined = f"{key}:{password}"
    return base64.b64encode(combined.encode("utf-8")).decode("utf-8")
