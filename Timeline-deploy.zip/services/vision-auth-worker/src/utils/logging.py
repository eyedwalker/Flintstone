"""
Structured logging for the verification worker.
"""

import sys
from datetime import datetime, timezone


LOG_LEVELS = {"debug": 0, "info": 1, "warn": 2, "error": 3}
CURRENT_LEVEL = LOG_LEVELS.get("info", 1)


def log(level: str, message: str):
    """Log a message with timestamp and level."""
    if LOG_LEVELS.get(level, 0) < CURRENT_LEVEL:
        return

    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    prefix = {
        "debug": "DEBUG",
        "info": " INFO",
        "warn": " WARN",
        "error": "ERROR",
    }.get(level, level.upper())

    print(f"[{timestamp}] [{prefix}] {message}", file=sys.stderr if level == "error" else sys.stdout, flush=True)
