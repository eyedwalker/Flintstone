"""
AI-powered benefit parser using Claude to extract structured data from HTML.
"""

import json
import anthropic

from ..config import ANTHROPIC_API_KEY
from .prompts import BENEFIT_PARSER_PROMPT
from ..utils.logging import log


async def parse_benefits_html(html: str, payer_type: str) -> dict:
    """
    Parse benefit HTML using Claude to extract structured data.

    Args:
        html: Raw HTML from the payer portal benefits page
        payer_type: The payer type (vsp, eyemed, etc.)

    Returns:
        dict: Parsed benefit data matching the verification_results schema
    """
    if not ANTHROPIC_API_KEY:
        raise RuntimeError("ANTHROPIC_API_KEY is required for benefit parsing")

    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    # Truncate HTML to avoid token limits (keep most relevant content)
    truncated_html = truncate_html(html, max_chars=80000)

    log("info", f"Parsing {payer_type} benefits ({len(truncated_html)} chars)...")

    message = client.messages.create(
        model="claude-sonnet-4-5-20250929",
        max_tokens=4096,
        system=BENEFIT_PARSER_PROMPT,
        messages=[
            {
                "role": "user",
                "content": f"Payer portal: {payer_type.upper()}\n\nHTML content:\n{truncated_html}",
            }
        ],
    )

    response_text = message.content[0].text.strip()

    # Parse JSON response
    try:
        # Handle potential markdown code blocks
        if response_text.startswith("```"):
            response_text = response_text.split("```")[1]
            if response_text.startswith("json"):
                response_text = response_text[4:]

        parsed = json.loads(response_text)
    except json.JSONDecodeError as e:
        log("error", f"Failed to parse Claude response as JSON: {e}")
        log("debug", f"Response: {response_text[:500]}")
        # Return minimal result
        return {
            "is_eligible": False,
            "eligibility_status": "parse_error",
            "confidence_score": 0.0,
            "raw_benefits": {"parse_error": str(e)},
        }

    log("info", f"Parsed benefits: eligible={parsed.get('is_eligible')}, confidence={parsed.get('confidence_score')}")
    return parsed


def truncate_html(html: str, max_chars: int = 80000) -> str:
    """
    Truncate HTML while keeping the most relevant content.
    Removes scripts, styles, and navigation to focus on benefit data.
    """
    import re

    # Remove script and style tags
    html = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r'<style[^>]*>.*?</style>', '', html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r'<nav[^>]*>.*?</nav>', '', html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r'<header[^>]*>.*?</header>', '', html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r'<footer[^>]*>.*?</footer>', '', html, flags=re.DOTALL | re.IGNORECASE)

    # Remove HTML comments
    html = re.sub(r'<!--.*?-->', '', html, flags=re.DOTALL)

    # Collapse whitespace
    html = re.sub(r'\s+', ' ', html)

    if len(html) > max_chars:
        html = html[:max_chars] + "\n... [truncated]"

    return html
