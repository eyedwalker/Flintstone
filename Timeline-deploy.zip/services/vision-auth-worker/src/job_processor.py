"""
Job Processor - Routes verification jobs to the correct payer handler.

Uses configurable flow steps from payer_credentials.settings when available,
falling back to hardcoded payer classes for backwards compatibility.
"""

from .config import get_supabase, PAYER_ENCRYPTION_KEY
from .payers.vsp import VSPPayer
from .payers.eyemed import EyeMedPayer
from .payers.davis_vision import DavisVisionPayer
from .payers.flow_runner import FlowRunner
from .utils.encryption import decrypt_password
from .utils.logging import log


# Payer handler registry (fallback when no flow_steps configured)
PAYER_HANDLERS = {
    "vsp": VSPPayer,
    "eyemed": EyeMedPayer,
    "davis-vision": DavisVisionPayer,
}


async def process_job(job: dict, resume_mfa: bool = False) -> dict:
    """
    Process a verification job.

    Args:
        job: The verification_jobs row from Supabase
        resume_mfa: Whether this is resuming after MFA code was provided

    Returns:
        dict: Data to insert into verification_results
    """
    payer_type = job["payer_type"]

    # Fetch credentials
    supabase = get_supabase()
    cred_query = supabase.table("payer_credentials") \
        .select("*") \
        .eq("payer_type", payer_type) \
        .eq("is_active", True)

    if job.get("company_id"):
        cred_query = cred_query.eq("company_id", job["company_id"])

    cred_result = cred_query.limit(1).execute()

    if not cred_result.data:
        raise ValueError(f"No active credentials for {payer_type}")

    cred = cred_result.data[0]

    # Decrypt password
    credentials = {
        "username": cred["portal_username"],
        "password": decrypt_password(cred["portal_password_encrypted"], PAYER_ENCRYPTION_KEY),
        "portal_url": cred.get("portal_url"),
        "mfa_method": cred.get("mfa_method", "none"),
    }

    # MFA code if resuming
    mfa_code = job.get("mfa_code") if resume_mfa else None

    # Check for configurable flow steps
    settings = cred.get("settings") or {}
    flow_steps = settings.get("flow_steps", [])

    if flow_steps:
        # Use configurable flow runner
        log("info", f"Using flow runner for {payer_type} ({len(flow_steps)} steps)")
        runner = FlowRunner(payer_type)
        variables = {
            "username": credentials["username"],
            "password": credentials["password"],
            "member_id": job["member_id"],
            "subscriber_dob": job.get("subscriber_dob", ""),
        }
        raw_result = await runner.run(flow_steps, variables, mfa_code=mfa_code)
    else:
        # Fall back to hardcoded payer handler
        handler_class = PAYER_HANDLERS.get(payer_type)
        if not handler_class:
            raise ValueError(f"No handler or flow steps for payer type: {payer_type}")

        log("info", f"Using hardcoded handler for {payer_type}")
        handler = handler_class()
        raw_result = await handler.verify(
            member_id=job["member_id"],
            subscriber_dob=job.get("subscriber_dob"),
            patient_dob=job.get("patient_dob"),
            credentials=credentials,
            mfa_code=mfa_code,
        )

    # Update credential last login
    supabase.table("payer_credentials") \
        .update({
            "last_login_at": raw_result.get("login_timestamp"),
            "last_login_status": "success" if raw_result.get("is_eligible") is not None else "partial",
        }) \
        .eq("id", cred["id"]) \
        .execute()

    # Build verification_results row
    from datetime import datetime, timezone, timedelta

    expires_at = datetime.now(timezone.utc) + timedelta(hours=24)

    result = {
        "job_id": job["id"],
        "patient_id": job["patient_id"],
        "payer_type": payer_type,
        "is_eligible": raw_result.get("is_eligible", False),
        "eligibility_status": raw_result.get("eligibility_status", "unknown"),
        "plan_name": raw_result.get("plan_name"),
        "plan_type": raw_result.get("plan_type"),
        "effective_date": raw_result.get("effective_date"),
        "termination_date": raw_result.get("termination_date"),
        "exam_copay": raw_result.get("exam_copay"),
        "frames_allowance": raw_result.get("frames_allowance"),
        "frames_copay": raw_result.get("frames_copay"),
        "lenses_copay": raw_result.get("lenses_copay"),
        "contacts_allowance": raw_result.get("contacts_allowance"),
        "contacts_copay": raw_result.get("contacts_copay"),
        "exam_eligible_date": raw_result.get("exam_eligible_date"),
        "frames_eligible_date": raw_result.get("frames_eligible_date"),
        "lenses_eligible_date": raw_result.get("lenses_eligible_date"),
        "contacts_eligible_date": raw_result.get("contacts_eligible_date"),
        "raw_benefits": raw_result.get("raw_benefits", {}),
        "raw_html": raw_result.get("raw_html", ""),
        "parsed_by": "claude",
        "confidence_score": raw_result.get("confidence_score", 0.0),
        "expires_at": expires_at.isoformat(),
    }

    log("info", f"Parsed benefits for {payer_type} | Eligible: {result['is_eligible']} | Confidence: {result['confidence_score']}")

    return result
