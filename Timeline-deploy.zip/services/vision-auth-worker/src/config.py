"""
Configuration and shared clients for the verification worker.
"""

import os
from supabase import create_client, Client

# Load .env if present (for local development)
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


# Supabase client
_supabase: Client | None = None


def get_supabase() -> Client:
    global _supabase
    if _supabase is None:
        url = os.environ.get("SUPABASE_URL")
        key = os.environ.get("SUPABASE_SERVICE_KEY")
        if not url or not key:
            raise RuntimeError("SUPABASE_URL and SUPABASE_SERVICE_KEY are required")
        _supabase = create_client(url, key)
    return _supabase


# Worker settings
WORKER_ID = os.environ.get("WORKER_ID", f"worker-{os.getpid()}")
POLL_INTERVAL = int(os.environ.get("POLL_INTERVAL_SECONDS", "5"))
MAX_CONCURRENT = int(os.environ.get("MAX_CONCURRENT_JOBS", "1"))
JOB_TIMEOUT = int(os.environ.get("JOB_TIMEOUT_SECONDS", "300"))

# Anthropic API key
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

# Encryption key for decrypting portal passwords
PAYER_ENCRYPTION_KEY = os.environ.get("PAYER_ENCRYPTION_KEY", "default-dev-key")

# Proxy settings
PROXY_URL = os.environ.get("PROXY_URL", "")
PROXY_USERNAME = os.environ.get("PROXY_USERNAME", "")
PROXY_PASSWORD = os.environ.get("PROXY_PASSWORD", "")
