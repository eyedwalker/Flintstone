"""
EyeMed Portal Automation (Phase 2)

Portal: https://provider.eyemed.com
Flow: Login → Provider Services → Eligibility Check → Enter subscriber ID → Extract

NOTE: Placeholder implementation - requires actual portal inspection.
"""

from .base_payer import BasePayer
from ..utils.logging import log


class EyeMedPayer(BasePayer):
    PAYER_TYPE = "eyemed"
    PORTAL_URL = "https://provider.eyemed.com"

    async def verify(
        self,
        member_id: str,
        subscriber_dob: str | None,
        patient_dob: str | None,
        credentials: dict,
        mfa_code: str | None = None,
    ) -> dict:
        """EyeMed benefit verification - Phase 2 implementation."""
        raise NotImplementedError(
            "EyeMed portal automation is planned for Phase 2. "
            "Currently only VSP is supported."
        )
