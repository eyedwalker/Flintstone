"""
Flow Runner - Generic step-based portal automation.

Executes configurable portal automation steps stored in payer_credentials.settings.flow_steps.
Replaces the need for hardcoded payer classes when flow steps are configured.
"""

from ..browser.stealth import create_stealth_browser
from ..parser.benefit_parser import parse_benefits_html
from ..utils.logging import log
from .base_payer import MFARequiredError


class FlowRunner:
    """Execute configurable portal automation steps."""

    def __init__(self, payer_type: str):
        self.payer_type = payer_type

    def interpolate(self, value: str, variables: dict) -> str:
        """Replace {{variable}} placeholders with actual values."""
        result = value
        for key, val in variables.items():
            result = result.replace(f"{{{{{key}}}}}", val or "")
        return result

    async def run(self, steps: list, variables: dict, mfa_code: str | None = None) -> dict:
        """
        Execute a list of steps against a Playwright page.

        Args:
            steps: List of step dicts from settings.flow_steps
            variables: Dict with keys: username, password, member_id, subscriber_dob
            mfa_code: MFA code if resuming after MFA request

        Returns:
            dict with parsed benefit data

        Raises:
            MFARequiredError: If portal requires MFA
        """
        from playwright.async_api import async_playwright

        async with async_playwright() as pw:
            browser_obj, context, page = await create_stealth_browser()
            try:
                raw_html = None

                for i, step in enumerate(steps):
                    step_type = step.get("type")
                    log("debug", f"Step {i+1}/{len(steps)}: {step_type}")

                    if step_type == "navigate":
                        url = self.interpolate(step.get("url", ""), variables)
                        await page.goto(url, wait_until="domcontentloaded")

                    elif step_type == "fill":
                        selector = step.get("selector", "")
                        value = self.interpolate(step.get("value", ""), variables)
                        await page.wait_for_selector(selector, timeout=10000)
                        await page.fill(selector, value)

                    elif step_type == "click":
                        selector = step.get("selector", "")
                        await page.wait_for_selector(selector, timeout=10000)
                        await page.click(selector)

                    elif step_type == "wait":
                        selector = step.get("selector", "")
                        timeout = step.get("timeout", 10000)
                        await page.wait_for_selector(selector, timeout=timeout)

                    elif step_type == "check_mfa":
                        # If we have an MFA code, skip MFA detection
                        if mfa_code:
                            continue

                        for sel in step.get("selectors", []):
                            try:
                                el = await page.query_selector(sel)
                                if el:
                                    raise MFARequiredError(method="detected")
                            except MFARequiredError:
                                raise
                            except Exception:
                                pass

                    elif step_type == "extract":
                        selector = step.get("selector", "body")
                        if selector == "body":
                            raw_html = await page.content()
                        else:
                            el = await page.query_selector(selector)
                            if el:
                                raw_html = await el.inner_html()
                            else:
                                raw_html = await page.content()

                    elif step_type == "screenshot":
                        name = step.get("name", "debug")
                        try:
                            await page.screenshot(path=f"/tmp/{self.payer_type}_{name}.png")
                            log("debug", f"Screenshot: /tmp/{self.payer_type}_{name}.png")
                        except Exception:
                            pass

                    else:
                        log("warn", f"Unknown step type: {step_type}")

                # Parse extracted HTML
                if raw_html:
                    from datetime import datetime, timezone
                    parsed = await parse_benefits_html(raw_html, self.payer_type)
                    parsed["raw_html"] = raw_html[:50000]  # Truncate
                    parsed["login_timestamp"] = datetime.now(timezone.utc).isoformat()
                    return parsed
                else:
                    raise ValueError("Flow completed without extracting any content")

            finally:
                await context.close()
                await browser_obj.close()
