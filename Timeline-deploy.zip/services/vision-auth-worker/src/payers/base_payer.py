"""
Base payer class for portal automation.
All payer-specific handlers inherit from this.
"""

from abc import ABC, abstractmethod
from contextlib import asynccontextmanager

from ..browser.stealth import create_stealth_browser
from ..parser.benefit_parser import parse_benefits_html
from ..utils.logging import log


class MFARequiredError(Exception):
    """Raised when the portal requires MFA verification."""
    def __init__(self, method="unknown"):
        self.method = method
        super().__init__(f"MFA required: {method}")


class BasePayer(ABC):
    """Abstract base class for payer portal automation."""

    PAYER_TYPE: str = ""
    PORTAL_URL: str = ""

    @asynccontextmanager
    async def get_browser(self):
        """Get a stealth browser page."""
        browser, context, page = await create_stealth_browser()
        try:
            yield page
        finally:
            await context.close()
            await browser.close()

    @abstractmethod
    async def verify(
        self,
        member_id: str,
        subscriber_dob: str | None,
        patient_dob: str | None,
        credentials: dict,
        mfa_code: str | None = None,
    ) -> dict:
        """
        Run benefit verification on the payer portal.

        Args:
            member_id: Insurance member/subscriber ID
            subscriber_dob: Subscriber date of birth (YYYY-MM-DD)
            patient_dob: Patient date of birth (YYYY-MM-DD)
            credentials: Portal login credentials
            mfa_code: MFA code if resuming after MFA request

        Returns:
            dict with parsed benefit data

        Raises:
            MFARequiredError: If portal requires MFA
        """
        pass

    async def parse_benefits(self, html: str) -> dict:
        """Parse benefit HTML using Claude AI."""
        return await parse_benefits_html(html, self.PAYER_TYPE)

    async def detect_mfa(self, page) -> bool:
        """Check if the current page is showing an MFA challenge."""
        mfa_indicators = [
            "verification code",
            "two-factor",
            "two-step",
            "security code",
            "enter the code",
            "confirm your identity",
            "authentication code",
        ]

        content = await page.content()
        content_lower = content.lower()

        return any(indicator in content_lower for indicator in mfa_indicators)

    def detect_mfa_method(self, page_content: str) -> str:
        """Determine which MFA method the portal is requesting."""
        content_lower = page_content.lower()

        if "text message" in content_lower or "sms" in content_lower:
            return "sms"
        if "email" in content_lower:
            return "email"
        if "authenticator" in content_lower or "totp" in content_lower:
            return "totp"
        return "unknown"

    async def wait_and_click(self, page, selector: str, timeout: int = 10000):
        """Wait for element and click it."""
        await page.wait_for_selector(selector, timeout=timeout)
        await page.click(selector)

    async def wait_and_fill(self, page, selector: str, value: str, timeout: int = 10000):
        """Wait for input element and fill it."""
        await page.wait_for_selector(selector, timeout=timeout)
        await page.fill(selector, value)

    async def screenshot(self, page, name: str = "debug"):
        """Take a debug screenshot."""
        try:
            await page.screenshot(path=f"/tmp/{self.PAYER_TYPE}_{name}.png")
            log("debug", f"Screenshot saved: /tmp/{self.PAYER_TYPE}_{name}.png")
        except Exception:
            pass
