"""
VSP (Vision Service Plan) Portal Automation

Portal: https://www.vsp.com/providers
Flow: Login → Provider Portal → Eligibility & Benefits → Enter member ID + DOB → Extract

NOTE: Element selectors are placeholders and must be updated by inspecting
the actual VSP provider portal. Portal structures change frequently.
"""

import asyncio
from datetime import datetime, timezone

from .base_payer import BasePayer, MFARequiredError
from ..utils.logging import log


class VSPPayer(BasePayer):
    PAYER_TYPE = "vsp"
    PORTAL_URL = "https://www.vsp.com/eye-doctor"  # Provider portal entry

    async def verify(
        self,
        member_id: str,
        subscriber_dob: str | None,
        patient_dob: str | None,
        credentials: dict,
        mfa_code: str | None = None,
    ) -> dict:
        """Verify benefits on VSP provider portal."""

        portal_url = credentials.get("portal_url") or self.PORTAL_URL
        login_timestamp = datetime.now(timezone.utc).isoformat()

        async with self.get_browser() as page:
            try:
                # Step 1: Navigate to provider login
                log("info", f"[VSP] Navigating to {portal_url}")
                await page.goto(portal_url, wait_until="networkidle", timeout=30000)
                await asyncio.sleep(2)  # Let page fully render

                # Step 2: Login
                # NOTE: These selectors need to be verified against the actual portal
                log("info", "[VSP] Logging in...")
                await self.wait_and_fill(page, 'input[name="username"], input[id="username"], input[type="email"]', credentials["username"])
                await self.wait_and_fill(page, 'input[name="password"], input[id="password"], input[type="password"]', credentials["password"])
                await self.wait_and_click(page, 'button[type="submit"], input[type="submit"], button:has-text("Sign In"), button:has-text("Log In")')

                await page.wait_for_load_state("networkidle", timeout=15000)
                await asyncio.sleep(2)

                # Step 3: Check for MFA
                if await self.detect_mfa(page):
                    if mfa_code:
                        log("info", "[VSP] Entering MFA code...")
                        await self.wait_and_fill(page, 'input[name="code"], input[name="otp"], input[id="code"]', mfa_code)
                        await self.wait_and_click(page, 'button[type="submit"], button:has-text("Verify"), button:has-text("Submit")')
                        await page.wait_for_load_state("networkidle", timeout=15000)
                    else:
                        content = await page.content()
                        method = self.detect_mfa_method(content)
                        await self.screenshot(page, "mfa_required")
                        raise MFARequiredError(method=method)

                # Step 4: Navigate to eligibility section
                log("info", "[VSP] Navigating to eligibility...")
                # Look for eligibility/benefits link in the portal navigation
                eligibility_selectors = [
                    'a:has-text("Eligibility")',
                    'a:has-text("Benefits")',
                    'a:has-text("Eligibility & Benefits")',
                    'a[href*="eligibility"]',
                    'a[href*="benefits"]',
                ]

                clicked = False
                for selector in eligibility_selectors:
                    try:
                        await page.click(selector, timeout=5000)
                        clicked = True
                        break
                    except Exception:
                        continue

                if not clicked:
                    await self.screenshot(page, "no_eligibility_link")
                    log("warn", "[VSP] Could not find eligibility link, trying direct navigation")
                    # Try common direct URLs
                    await page.goto(f"{portal_url}/eligibility", timeout=15000)

                await page.wait_for_load_state("networkidle", timeout=15000)
                await asyncio.sleep(2)

                # Step 5: Enter patient/member info
                log("info", f"[VSP] Searching member: {member_id[:4]}****")

                member_selectors = [
                    'input[name="memberId"]',
                    'input[id="memberId"]',
                    'input[name="subscriberId"]',
                    'input[placeholder*="Member"]',
                    'input[placeholder*="Subscriber"]',
                ]

                for selector in member_selectors:
                    try:
                        await self.wait_and_fill(page, selector, member_id, timeout=3000)
                        break
                    except Exception:
                        continue

                # Enter DOB if field exists
                dob = subscriber_dob or patient_dob
                if dob:
                    dob_selectors = [
                        'input[name="dob"]',
                        'input[name="dateOfBirth"]',
                        'input[id="dob"]',
                        'input[placeholder*="DOB"]',
                        'input[placeholder*="Date of Birth"]',
                        'input[type="date"]',
                    ]
                    for selector in dob_selectors:
                        try:
                            await self.wait_and_fill(page, selector, dob, timeout=3000)
                            break
                        except Exception:
                            continue

                # Click search/submit
                search_selectors = [
                    'button:has-text("Search")',
                    'button:has-text("Check Eligibility")',
                    'button:has-text("Verify")',
                    'button:has-text("Submit")',
                    'input[type="submit"]',
                ]
                for selector in search_selectors:
                    try:
                        await page.click(selector, timeout=3000)
                        break
                    except Exception:
                        continue

                await page.wait_for_load_state("networkidle", timeout=20000)
                await asyncio.sleep(3)

                # Step 6: Extract benefits HTML
                log("info", "[VSP] Extracting benefits...")
                await self.screenshot(page, "benefits_page")

                # Get the main content area
                html = await page.content()

                # Step 7: Parse with Claude
                parsed = await self.parse_benefits(html)
                parsed["login_timestamp"] = login_timestamp
                parsed["raw_html"] = html[:50000]  # Limit stored HTML size

                log("info", f"[VSP] Parsed: eligible={parsed.get('is_eligible')}, plan={parsed.get('plan_name')}")
                return parsed

            except MFARequiredError:
                raise
            except Exception as e:
                await self.screenshot(page, "error")
                log("error", f"[VSP] Verification error: {e}")
                raise
