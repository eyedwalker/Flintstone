"""
Vision Auth Worker - Main Entry Point

Polls Supabase for queued verification jobs, processes them using
Playwright browser automation, and stores results.
"""

import asyncio
import signal
import sys
import time
from datetime import datetime, timedelta, timezone

from .config import get_supabase, WORKER_ID, POLL_INTERVAL, JOB_TIMEOUT
from .job_processor import process_job
from .utils.logging import log


# Graceful shutdown
shutdown_requested = False


def handle_shutdown(sig, frame):
    global shutdown_requested
    log("info", f"Shutdown signal received ({sig}). Finishing current job...")
    shutdown_requested = True


signal.signal(signal.SIGTERM, handle_shutdown)
signal.signal(signal.SIGINT, handle_shutdown)


async def poll_for_jobs():
    """Main polling loop."""
    supabase = get_supabase()
    log("info", f"Worker {WORKER_ID} started. Polling every {POLL_INTERVAL}s.")

    while not shutdown_requested:
        try:
            # 1. Check for queued jobs (priority first, then oldest)
            result = supabase.table("verification_jobs") \
                .select("*") \
                .eq("status", "queued") \
                .order("priority") \
                .order("created_at") \
                .limit(1) \
                .execute()

            if result.data:
                job = result.data[0]
                await claim_and_process(supabase, job)

            # 2. Check for MFA-waiting jobs that now have codes
            mfa_result = supabase.table("verification_jobs") \
                .select("*") \
                .eq("status", "mfa_waiting") \
                .not_.is_("mfa_code", "null") \
                .execute()

            for mfa_job in (mfa_result.data or []):
                await claim_and_process(supabase, mfa_job, resume_mfa=True)

            # 3. Expire stale jobs (started > JOB_TIMEOUT seconds ago, still in_progress)
            expire_stale_jobs(supabase)

        except Exception as e:
            log("error", f"Poll loop error: {e}")

        await asyncio.sleep(POLL_INTERVAL)

    log("info", f"Worker {WORKER_ID} shut down cleanly.")


async def claim_and_process(supabase, job, resume_mfa=False):
    """Claim a job and process it."""
    job_id = job["id"]

    if not resume_mfa:
        # Optimistic lock: only claim if still queued
        claim = supabase.table("verification_jobs") \
            .update({
                "status": "in_progress",
                "worker_id": WORKER_ID,
                "started_at": datetime.now(timezone.utc).isoformat(),
                "attempts": job["attempts"] + 1,
            }) \
            .eq("id", job_id) \
            .eq("status", "queued") \
            .execute()

        if not claim.data:
            log("debug", f"Job {job_id} already claimed by another worker")
            return
    else:
        # Resume MFA job
        supabase.table("verification_jobs") \
            .update({
                "status": "in_progress",
                "worker_id": WORKER_ID,
            }) \
            .eq("id", job_id) \
            .execute()

    log("info", f"Processing job {job_id} | Payer: {job['payer_type']} | Patient: {job['patient_id'][:8]}...")

    try:
        result = await process_job(job, resume_mfa=resume_mfa)

        # Store result
        supabase.table("verification_results").insert(result).execute()

        # Mark job complete
        supabase.table("verification_jobs") \
            .update({
                "status": "completed",
                "completed_at": datetime.now(timezone.utc).isoformat(),
                "mfa_code": None,  # Clear MFA code
            }) \
            .eq("id", job_id) \
            .execute()

        log("info", f"Job {job_id} completed | Eligible: {result.get('is_eligible')}")

    except MFARequiredError as e:
        supabase.table("verification_jobs") \
            .update({
                "status": "mfa_waiting",
                "mfa_requested_at": datetime.now(timezone.utc).isoformat(),
                "last_error": f"MFA required: {e.method}",
            }) \
            .eq("id", job_id) \
            .execute()
        log("info", f"Job {job_id} waiting for MFA ({e.method})")

    except Exception as e:
        error_msg = str(e)
        attempts = job["attempts"] + 1
        max_attempts = job.get("max_attempts", 3)

        new_status = "failed" if attempts >= max_attempts else "queued"

        supabase.table("verification_jobs") \
            .update({
                "status": new_status,
                "last_error": error_msg[:500],
                "mfa_code": None,
            }) \
            .eq("id", job_id) \
            .execute()

        if new_status == "failed":
            log("error", f"Job {job_id} FAILED after {attempts} attempts: {error_msg}")
        else:
            log("warn", f"Job {job_id} attempt {attempts}/{max_attempts} failed: {error_msg}")


def expire_stale_jobs(supabase):
    """Mark jobs as failed if they've been running too long."""
    cutoff = datetime.now(timezone.utc) - timedelta(seconds=JOB_TIMEOUT)

    supabase.table("verification_jobs") \
        .update({
            "status": "failed",
            "last_error": f"Job timed out after {JOB_TIMEOUT}s",
        }) \
        .eq("status", "in_progress") \
        .lt("started_at", cutoff.isoformat()) \
        .execute()


class MFARequiredError(Exception):
    def __init__(self, method="unknown"):
        self.method = method
        super().__init__(f"MFA required: {method}")


def main():
    log("info", "Starting Vision Auth Worker...")
    try:
        asyncio.run(poll_for_jobs())
    except KeyboardInterrupt:
        log("info", "Worker interrupted.")
        sys.exit(0)


if __name__ == "__main__":
    main()
