-- =============================================================
-- Vision Benefit Verification Engine - Database Migration
-- Run this in Supabase SQL Editor to create the required tables
-- =============================================================

-- 1. Payer Credentials (encrypted portal login credentials)
CREATE TABLE IF NOT EXISTS payer_credentials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  office_id UUID REFERENCES offices(id) ON DELETE CASCADE,
  payer_type TEXT NOT NULL CHECK (payer_type IN ('vsp', 'eyemed', 'davis-vision', 'spectera', 'superior-vision')),
  portal_username TEXT NOT NULL,
  portal_password_encrypted TEXT NOT NULL,
  mfa_method TEXT CHECK (mfa_method IN ('none', 'email', 'sms', 'totp')),
  mfa_secret_encrypted TEXT,
  portal_url TEXT,
  last_login_at TIMESTAMPTZ,
  last_login_status TEXT,
  is_active BOOLEAN DEFAULT true,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(company_id, office_id, payer_type)
);

-- 2. Verification Jobs (queue for worker processing)
CREATE TABLE IF NOT EXISTS verification_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  office_id UUID REFERENCES offices(id),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
  payer_type TEXT NOT NULL,
  member_id TEXT NOT NULL,
  subscriber_dob DATE,
  patient_dob DATE,
  relationship TEXT DEFAULT 'self',
  status TEXT NOT NULL DEFAULT 'queued' CHECK (status IN (
    'queued', 'in_progress', 'mfa_waiting', 'completed', 'failed', 'expired'
  )),
  priority INTEGER DEFAULT 5,
  attempts INTEGER DEFAULT 0,
  max_attempts INTEGER DEFAULT 3,
  last_error TEXT,
  worker_id TEXT,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  mfa_requested_at TIMESTAMPTZ,
  mfa_code TEXT,
  triggered_by TEXT DEFAULT 'manual',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Verification Results (parsed benefit data)
CREATE TABLE IF NOT EXISTS verification_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES verification_jobs(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  payer_type TEXT NOT NULL,
  is_eligible BOOLEAN NOT NULL,
  eligibility_status TEXT,
  plan_name TEXT,
  plan_type TEXT,
  effective_date DATE,
  termination_date DATE,
  exam_copay DECIMAL(8,2),
  frames_allowance DECIMAL(8,2),
  frames_copay DECIMAL(8,2),
  lenses_copay DECIMAL(8,2),
  contacts_allowance DECIMAL(8,2),
  contacts_copay DECIMAL(8,2),
  exam_eligible_date DATE,
  frames_eligible_date DATE,
  lenses_eligible_date DATE,
  contacts_eligible_date DATE,
  raw_benefits JSONB DEFAULT '{}',
  raw_html TEXT,
  parsed_by TEXT DEFAULT 'claude',
  confidence_score DECIMAL(3,2),
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Indexes
CREATE INDEX IF NOT EXISTS idx_payer_credentials_company ON payer_credentials(company_id);
CREATE INDEX IF NOT EXISTS idx_payer_credentials_active ON payer_credentials(is_active);
CREATE INDEX IF NOT EXISTS idx_verification_jobs_status ON verification_jobs(status);
CREATE INDEX IF NOT EXISTS idx_verification_jobs_patient ON verification_jobs(patient_id);
CREATE INDEX IF NOT EXISTS idx_verification_jobs_priority ON verification_jobs(priority, created_at);
CREATE INDEX IF NOT EXISTS idx_verification_jobs_appointment ON verification_jobs(appointment_id);
CREATE INDEX IF NOT EXISTS idx_verification_results_patient ON verification_results(patient_id);
CREATE INDEX IF NOT EXISTS idx_verification_results_job ON verification_results(job_id);
CREATE INDEX IF NOT EXISTS idx_verification_results_expires ON verification_results(expires_at);

-- 5. Auto-update timestamps
CREATE TRIGGER update_payer_credentials_updated_at BEFORE UPDATE ON payer_credentials FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_verification_jobs_updated_at BEFORE UPDATE ON verification_jobs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 6. Row Level Security
ALTER TABLE payer_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE verification_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE verification_results ENABLE ROW LEVEL SECURITY;

-- 7. Permissive policies (restrict in production)
DROP POLICY IF EXISTS "Allow all operations on payer_credentials" ON payer_credentials;
DROP POLICY IF EXISTS "Allow all operations on verification_jobs" ON verification_jobs;
DROP POLICY IF EXISTS "Allow all operations on verification_results" ON verification_results;

CREATE POLICY "Allow all operations on payer_credentials" ON payer_credentials FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on verification_jobs" ON verification_jobs FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on verification_results" ON verification_results FOR ALL USING (true) WITH CHECK (true);
