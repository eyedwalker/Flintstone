#!/bin/bash
set -e

# Configuration
AWS_PROFILE="eyentelligence"
AWS_REGION="us-west-2"
AWS_ACCOUNT="780457123717"
ECR_REPO="vision-auth-worker"
ECR_URI="${AWS_ACCOUNT}.dkr.ecr.${AWS_REGION}.amazonaws.com/${ECR_REPO}"
EC2_HOST="100.23.14.116"
EC2_USER="ec2-user"
SSH_KEY="${SSH_KEY:-~/.ssh/wabah-key.pem}"
CONTAINER_NAME="vision-auth-worker"

echo "=== Vision Auth Worker Deployment ==="
echo "ECR: ${ECR_URI}"
echo "EC2: ${EC2_HOST}"
echo ""

# Step 1: Build Docker image
echo "[1/5] Building Docker image..."
docker build --no-cache --platform linux/amd64 --provenance=false --sbom=false -t ${ECR_REPO}:latest "$(dirname "$0")"

# Step 2: Tag and push to ECR
echo "[2/5] Pushing to ECR..."
AWS_PROFILE=${AWS_PROFILE} aws ecr get-login-password --region ${AWS_REGION} | \
  docker login --username AWS --password-stdin ${ECR_URI}
docker tag ${ECR_REPO}:latest ${ECR_URI}:latest
docker tag ${ECR_REPO}:latest ${ECR_URI}:$(date +%Y%m%d-%H%M%S)
docker push ${ECR_URI}:latest

# Step 3: SSH into EC2 and pull the new image
echo "[3/5] Deploying to EC2..."
ssh -i ${SSH_KEY} -o StrictHostKeyChecking=no ${EC2_USER}@${EC2_HOST} << 'REMOTE_SCRIPT'
  # Login to ECR
  aws ecr get-login-password --region us-west-2 | \
    docker login --username AWS --password-stdin 780457123717.dkr.ecr.us-west-2.amazonaws.com

  # Pull latest image
  docker pull 780457123717.dkr.ecr.us-west-2.amazonaws.com/vision-auth-worker:latest

  # Stop existing container if running
  docker stop vision-auth-worker 2>/dev/null || true
  docker rm vision-auth-worker 2>/dev/null || true

  # Start new container
  docker run -d \
    --name vision-auth-worker \
    --restart unless-stopped \
    --env-file /home/ec2-user/vision-auth-worker/.env \
    --log-driver json-file \
    --log-opt max-size=50m \
    --log-opt max-file=3 \
    --shm-size=512m \
    780457123717.dkr.ecr.us-west-2.amazonaws.com/vision-auth-worker:latest

  echo "Container status:"
  docker ps --filter name=vision-auth-worker
REMOTE_SCRIPT

echo "[4/5] Verifying deployment..."
sleep 5
ssh -i ${SSH_KEY} ${EC2_USER}@${EC2_HOST} "docker logs --tail 20 ${CONTAINER_NAME}"

echo ""
echo "[5/5] Done! Worker deployed to ${EC2_HOST}"
echo "  View logs: ssh -i ${SSH_KEY} ${EC2_USER}@${EC2_HOST} 'docker logs -f ${CONTAINER_NAME}'"
