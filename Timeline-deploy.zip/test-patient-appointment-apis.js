/**
 * Test Patient and Appointment APIs
 * Tests all CRUD operations for patients and appointments
 */

import dotenv from 'dotenv';
import https from 'https';
import http from 'http';

dotenv.config();

// API routes only work on Vercel deployment (not Vite dev server)
const BASE_URL = 'https://patientcare-teal.vercel.app';
const COMPANY_ID = '4c7253f1-b02b-472d-9b31-23e7ff7c51e5';

let testPatientId = null;
let testAppointmentId = null;

async function makeRequest(method, path, body = null) {
  return new Promise((resolve, reject) => {
    const urlString = `${BASE_URL}${path}`;
    const url = new URL(urlString);
    const isHttps = url.protocol === 'https:';
    const httpModule = isHttps ? https : http;
    
    const options = {
      method,
      hostname: url.hostname,
      port: url.port || (isHttps ? 443 : 80),
      path: url.pathname + url.search,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    };

    const req = httpModule.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve({ status: res.statusCode, data: parsed });
        } catch (e) {
          resolve({ status: res.statusCode, data: data });
        }
      });
    });

    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function testGetOffices() {
  console.log('\n=== TEST: Get Offices ===');
  try {
    const response = await makeRequest('GET', `/api/offices?company_id=${COMPANY_ID}`);
    console.log(`Status: ${response.status}`);
    
    if (response.status === 200 && response.data.data?.length > 0) {
      const office = response.data.data[0];
      console.log(`✅ Found ${response.data.data.length} offices`);
      console.log(`   First office: ${office.name} (${office.id})`);
      return office.id;
    } else {
      console.log('❌ No offices found');
      return null;
    }
  } catch (error) {
    console.error('❌ Error:', error.message);
    return null;
  }
}

async function testCreatePatient() {
  console.log('\n=== TEST: Create Patient ===');
  try {
    const patientData = {
      company_id: COMPANY_ID,
      first_name: 'John',
      last_name: 'Doe',
      date_of_birth: '1985-06-15',
      gender: 'male',
      email: 'john.doe@example.com',
      phone: '555-0123',
      mobile_phone: '555-0124',
      address: {
        street: '123 Main St',
        city: 'Anytown',
        state: 'CA',
        zip: '12345'
      },
      status: 'active'
    };

    const response = await makeRequest('POST', '/api/patients', patientData);
    console.log(`Status: ${response.status}`);
    
    if (response.status === 201 && response.data.data) {
      testPatientId = response.data.data.id;
      console.log(`✅ Patient created: ${response.data.data.first_name} ${response.data.data.last_name}`);
      console.log(`   ID: ${testPatientId}`);
      return testPatientId;
    } else {
      console.log('❌ Failed to create patient');
      console.log(JSON.stringify(response.data, null, 2));
      return null;
    }
  } catch (error) {
    console.error('❌ Error:', error.message);
    return null;
  }
}

async function testGetPatient(patientId) {
  console.log('\n=== TEST: Get Patient by ID ===');
  try {
    const response = await makeRequest('GET', `/api/patients/${patientId}`);
    console.log(`Status: ${response.status}`);
    
    if (response.status === 200 && response.data.data) {
      const patient = response.data.data;
      console.log(`✅ Retrieved patient: ${patient.first_name} ${patient.last_name}`);
      console.log(`   DOB: ${patient.date_of_birth}`);
      console.log(`   Email: ${patient.email}`);
      console.log(`   Phone: ${patient.phone}`);
      return true;
    } else {
      console.log('❌ Failed to retrieve patient');
      return false;
    }
  } catch (error) {
    console.error('❌ Error:', error.message);
    return false;
  }
}

async function testListPatients() {
  console.log('\n=== TEST: List Patients ===');
  try {
    const response = await makeRequest('GET', `/api/patients?company_id=${COMPANY_ID}`);
    console.log(`Status: ${response.status}`);
    
    if (response.status === 200) {
      const count = response.data.data?.length || 0;
      console.log(`✅ Found ${count} patients`);
      if (count > 0) {
        console.log(`   First patient: ${response.data.data[0].first_name} ${response.data.data[0].last_name}`);
      }
      return true;
    } else {
      console.log('❌ Failed to list patients');
      return false;
    }
  } catch (error) {
    console.error('❌ Error:', error.message);
    return false;
  }
}

async function testSearchPatients() {
  console.log('\n=== TEST: Search Patients ===');
  try {
    const response = await makeRequest('GET', `/api/patients?company_id=${COMPANY_ID}&search=Doe`);
    console.log(`Status: ${response.status}`);
    
    if (response.status === 200) {
      const count = response.data.data?.length || 0;
      console.log(`✅ Search found ${count} patients matching "Doe"`);
      return true;
    } else {
      console.log('❌ Failed to search patients');
      return false;
    }
  } catch (error) {
    console.error('❌ Error:', error.message);
    return false;
  }
}

async function testUpdatePatient(patientId) {
  console.log('\n=== TEST: Update Patient ===');
  try {
    const updates = {
      email: 'john.doe.updated@example.com',
      phone: '555-9999'
    };

    const response = await makeRequest('PUT', `/api/patients/${patientId}`, updates);
    console.log(`Status: ${response.status}`);
    
    if (response.status === 200 && response.data.data) {
      console.log(`✅ Patient updated`);
      console.log(`   New email: ${response.data.data.email}`);
      console.log(`   New phone: ${response.data.data.phone}`);
      return true;
    } else {
      console.log('❌ Failed to update patient');
      return false;
    }
  } catch (error) {
    console.error('❌ Error:', error.message);
    return false;
  }
}

async function testCreateAppointment(patientId, officeId) {
  console.log('\n=== TEST: Create Appointment ===');
  try {
    const appointmentData = {
      company_id: COMPANY_ID,
      office_id: officeId,
      patient_id: patientId,
      appointment_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days from now
      duration_minutes: 30,
      appointment_type: 'annual_exam',
      reason_for_visit: 'Annual eye examination',
      status: 'scheduled'
    };

    const response = await makeRequest('POST', '/api/appointments', appointmentData);
    console.log(`Status: ${response.status}`);
    
    if (response.status === 201 && response.data.data) {
      testAppointmentId = response.data.data.id;
      console.log(`✅ Appointment created`);
      console.log(`   ID: ${testAppointmentId}`);
      console.log(`   Date: ${response.data.data.appointment_date}`);
      console.log(`   Type: ${response.data.data.appointment_type}`);
      return testAppointmentId;
    } else {
      console.log('❌ Failed to create appointment');
      console.log(JSON.stringify(response.data, null, 2));
      return null;
    }
  } catch (error) {
    console.error('❌ Error:', error.message);
    return null;
  }
}

async function testGetAppointment(appointmentId) {
  console.log('\n=== TEST: Get Appointment by ID ===');
  try {
    const response = await makeRequest('GET', `/api/appointments/${appointmentId}`);
    console.log(`Status: ${response.status}`);
    
    if (response.status === 200 && response.data.data) {
      const appt = response.data.data;
      console.log(`✅ Retrieved appointment`);
      console.log(`   Date: ${appt.appointment_date}`);
      console.log(`   Status: ${appt.status}`);
      console.log(`   Type: ${appt.appointment_type}`);
      return true;
    } else {
      console.log('❌ Failed to retrieve appointment');
      return false;
    }
  } catch (error) {
    console.error('❌ Error:', error.message);
    return false;
  }
}

async function testListAppointments(officeId) {
  console.log('\n=== TEST: List Appointments ===');
  try {
    const startDate = new Date().toISOString().split('T')[0];
    const endDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    const response = await makeRequest('GET', `/api/appointments?office_id=${officeId}&start_date=${startDate}&end_date=${endDate}`);
    console.log(`Status: ${response.status}`);
    
    if (response.status === 200) {
      const count = response.data.data?.length || 0;
      console.log(`✅ Found ${count} appointments in next 30 days`);
      if (count > 0) {
        console.log(`   First appointment: ${response.data.data[0].appointment_date}`);
      }
      return true;
    } else {
      console.log('❌ Failed to list appointments');
      return false;
    }
  } catch (error) {
    console.error('❌ Error:', error.message);
    return false;
  }
}

async function testUpdateAppointment(appointmentId) {
  console.log('\n=== TEST: Update Appointment ===');
  try {
    const updates = {
      status: 'confirmed',
      notes: 'Patient confirmed via phone'
    };

    const response = await makeRequest('PUT', `/api/appointments/${appointmentId}`, updates);
    console.log(`Status: ${response.status}`);
    
    if (response.status === 200 && response.data.data) {
      console.log(`✅ Appointment updated`);
      console.log(`   New status: ${response.data.data.status}`);
      console.log(`   Notes: ${response.data.data.notes}`);
      return true;
    } else {
      console.log('❌ Failed to update appointment');
      return false;
    }
  } catch (error) {
    console.error('❌ Error:', error.message);
    return false;
  }
}

async function cleanup(patientId, appointmentId) {
  console.log('\n=== CLEANUP: Delete Test Data ===');
  
  if (appointmentId) {
    try {
      const response = await makeRequest('DELETE', `/api/appointments/${appointmentId}`);
      if (response.status === 200) {
        console.log('✅ Appointment deleted');
      }
    } catch (error) {
      console.log('⚠️  Could not delete appointment:', error.message);
    }
  }
  
  if (patientId) {
    try {
      const response = await makeRequest('DELETE', `/api/patients/${patientId}`);
      if (response.status === 200) {
        console.log('✅ Patient deleted');
      }
    } catch (error) {
      console.log('⚠️  Could not delete patient:', error.message);
    }
  }
}

async function runTests() {
  console.log('========================================');
  console.log('Patient & Appointment API Tests');
  console.log('========================================');
  console.log(`Testing against: ${BASE_URL}`);
  console.log(`Company ID: ${COMPANY_ID}`);
  
  try {
    // Get office ID first
    const officeId = await testGetOffices();
    if (!officeId) {
      console.log('\n❌ Cannot proceed without an office. Please sync offices first.');
      return;
    }

    // Test Patient APIs
    const patientId = await testCreatePatient();
    if (!patientId) {
      console.log('\n❌ Cannot proceed without a patient');
      return;
    }

    await testGetPatient(patientId);
    await testListPatients();
    await testSearchPatients();
    await testUpdatePatient(patientId);

    // Test Appointment APIs
    const appointmentId = await testCreateAppointment(patientId, officeId);
    if (appointmentId) {
      await testGetAppointment(appointmentId);
      await testListAppointments(officeId);
      await testUpdateAppointment(appointmentId);
    }

    // Cleanup
    await cleanup(patientId, appointmentId);

    console.log('\n========================================');
    console.log('✅ All API tests completed successfully!');
    console.log('========================================\n');
  } catch (error) {
    console.error('\n❌ Test suite failed:', error);
  }
}

runTests();
