# Voice, SMS & Email AI-Enabled Communication Porting Guide

This document provides a complete reference for porting the AI-enabled voice calling, SMS, and email capabilities to the Timeline application.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Voice Calling System](#voice-calling-system)
3. [SMS System](#sms-system)
4. [Email System](#email-system)
5. [Dependencies](#dependencies)
6. [Environment Variables](#environment-variables)
7. [File-by-File Porting Guide](#file-by-file-porting-guide)
8. [Twilio Configuration](#twilio-configuration)
9. [AI Integration Points](#ai-integration-points)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                     INBOUND COMMUNICATIONS                               │
│                                                                          │
│  [Patient Phone]                     [Patient SMS]                       │
│        │                                   │                             │
│        ▼                                   ▼                             │
│  ┌─────────────────┐              ┌─────────────────┐                   │
│  │  Twilio Voice   │              │   Twilio SMS    │                   │
│  │    Webhook      │              │    Webhook      │                   │
│  └────────┬────────┘              └────────┬────────┘                   │
│           │                                │                             │
│           ▼                                ▼                             │
│  /api/webhooks/twilio/voice    /api/webhooks/twilio/sms                 │
│           │                                │                             │
│           ▼                                ▼                             │
│  ┌─────────────────┐              ┌─────────────────────┐               │
│  │  Voice Handler  │              │ EnhancedAISMSService│               │
│  │  (TwiML + AI)   │              │  (Intent + Reply)   │               │
│  └─────────────────┘              └─────────────────────┘               │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                    OUTBOUND COMMUNICATIONS                               │
│                                                                          │
│  [Your Application]                                                      │
│        │                                                                 │
│        ├────────────────┬────────────────┬───────────────┐              │
│        ▼                ▼                ▼               ▼              │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐          │
│  │ sendSMS  │    │makeVoice │    │sendEmail │    │ AI Voice │          │
│  │(twilio.ts│    │  Call    │    │(email.ts)│    │Selection │          │
│  └──────────┘    └──────────┘    └──────────┘    └──────────┘          │
│        │                │               │               │               │
│        ▼                ▼               ▼               ▼               │
│  [Twilio API]    [Twilio API]    [SMTP Server]   [Polly Voices]        │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Voice Calling System

### Core Files

| File | Purpose |
|------|---------|
| `src/lib/twilio.ts` | Twilio client, `sendSMS()`, `makeVoiceCall()` |
| `src/lib/voice.ts` | Extended voice with voice selection |
| `src/app/api/webhooks/twilio/voice/route.ts` | Main voice webhook handler |
| `src/app/api/webhooks/twilio/voice/menu/route.ts` | IVR menu handler |
| `src/app/api/webhooks/twilio/voice/ai-response/route.ts` | AI speech processing |
| `src/app/api/webhooks/twilio/voice/voicemail/route.ts` | Voicemail handling |

### Making Outbound Calls

**Simple call with TwiML:**

```typescript
import twilio from 'twilio';

const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

// Available Polly voices for voice selection
type TwilioVoice = 'Polly.Joanna' | 'Polly.Matthew' | 'Polly.Amy' | 'Polly.Emma' | 'Polly.Brian';

export async function makeVoiceCall(
  to: string, 
  message: string, 
  voice: TwilioVoice = 'Polly.Joanna'
) {
  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
    <Response>
      <Say voice="${voice}">${escapeXml(message)}</Say>
    </Response>`;

  const call = await client.calls.create({
    twiml,
    to,
    from: process.env.TWILIO_PHONE_NUMBER,
  });
  
  return { success: true, callId: call.sid };
}
```

### Handling Inbound Calls

**Voice Webhook Handler Pattern:**

```typescript
import VoiceResponse from 'twilio/lib/twiml/VoiceResponse';

export async function POST(request: NextRequest) {
  const body = await request.text();
  const params = new URLSearchParams(body);
  
  const callSid = params.get('CallSid');
  const from = params.get('From');
  const callStatus = params.get('CallStatus');
  const digits = params.get('Digits'); // IVR input
  
  const twiml = new VoiceResponse();
  
  // AI-powered greeting
  if (process.env.ENABLE_AI_VOICE_ANSWER === 'true') {
    twiml.say({ voice: 'alice' }, 'Hello, I am your AI assistant.');
    
    // Gather speech input
    const gather = twiml.gather({
      input: ['speech'],
      timeout: 10,
      speechTimeout: 'auto',
      action: '/api/webhooks/twilio/voice/ai-response',
      method: 'POST'
    });
    gather.say('Please tell me how I can assist you.');
  } else {
    // Standard IVR menu
    const gather = twiml.gather({
      numDigits: 1,
      action: '/api/webhooks/twilio/voice/menu',
      method: 'POST'
    });
    gather.say('Press 1 to confirm, Press 2 to reschedule...');
  }
  
  return new NextResponse(twiml.toString(), {
    headers: { 'Content-Type': 'text/xml' }
  });
}
```

### Voice Selection Options

| Voice ID | Description | Gender |
|----------|-------------|--------|
| `Polly.Joanna` | US English, clear | Female |
| `Polly.Matthew` | US English, professional | Male |
| `Polly.Amy` | British English | Female |
| `Polly.Emma` | British English | Female |
| `Polly.Brian` | British English | Male |
| `alice` | Twilio default, natural | Female |

---

## SMS System

### Core Files

| File | Purpose |
|------|---------|
| `src/lib/twilio.ts` | `sendSMS()` function |
| `src/lib/services/enhanced-ai-sms-service.ts` | AI intent analysis & reply generation |
| `src/lib/services/ai-sms-service.ts` | Basic AI SMS service |
| `src/app/api/webhooks/twilio/sms/route.ts` | Inbound SMS webhook |

### Sending SMS

```typescript
import twilio from 'twilio';

const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

export async function sendSMS(to: string, body: string) {
  const message = await client.messages.create({
    body,
    to,
    from: process.env.TWILIO_PHONE_NUMBER,
  });
  return { success: true, messageId: message.sid };
}
```

### AI-Enabled SMS Reply

**EnhancedAISMSService** provides:
- Intent analysis (emergency, confirmation, cancellation, booking, etc.)
- Sentiment detection (positive, neutral, negative)
- Urgency classification (low, medium, high, critical)
- AI-generated contextual replies
- Booking request detection and handling

```typescript
import { EnhancedAISMSService } from '@/lib/services/enhanced-ai-sms-service';

// Patient context for personalization
const patientContext = {
  firstName: 'John',
  lastName: 'Smith',
  phone: '+1234567890',
  appointmentDateTime: new Date('2026-01-25T10:00:00'),
  doctorName: 'Dr. Johnson',
  officeName: 'Main Street Eye Care',
  previousMessages: []
};

// Generate AI reply
const result = await EnhancedAISMSService.generateEnhancedReply(
  'Can I book an appointment for next Monday?',
  patientContext,
  { 
    personalize: true, 
    includeNextSteps: true,
    tone: 'friendly',
    maxLength: 160
  }
);

console.log(result.intent);  // { intent: 'booking', urgency: 'medium', ... }
console.log(result.reply);   // AI-generated reply text
console.log(result.mode);    // 'ai' or 'fallback'
```

### Message Intent Types

| Intent | Description | Auto-Reply |
|--------|-------------|------------|
| `emergency` | Urgent medical need | Direct to call 911/office |
| `confirmation` | Confirming appointment | Positive acknowledgment |
| `cancellation` | Cancel/reschedule | Direct to call office |
| `booking` | Wants to book appointment | Check availability |
| `scheduling` | General scheduling question | Direct to office |
| `question` | General question | Queue for staff |
| `complaint` | Patient complaint | Escalate to human |
| `compliment` | Positive feedback | Thank patient |
| `insurance` | Insurance inquiry | Direct to office |
| `directions` | Office location | Provide directions |

### SMS Webhook Flow

```typescript
// /api/webhooks/twilio/sms/route.ts
export async function POST(request: Request) {
  const formData = await request.formData();
  
  const messageBody = formData.get('Body') as string;
  const from = formData.get('From') as string;
  const messageSid = formData.get('MessageSid') as string;
  
  // Find patient by phone number
  const task = await TaskModel.findOne({ phone: from });
  
  // Log inbound message
  task.communications.push({
    type: 'sms',
    direction: 'incoming',
    message: messageBody,
    sender: from,
    createdAt: new Date()
  });
  
  // AI Auto-Reply
  if (process.env.ENABLE_AI_SMS_REPLY === 'true') {
    const aiResult = await EnhancedAISMSService.generateEnhancedReply(
      messageBody,
      patientContext,
      { tone: 'friendly', maxLength: 160 }
    );
    
    // Handle booking requests
    if (aiResult.intent.intent === 'booking') {
      // Check Eyefinity availability and respond
    }
    
    // Send AI reply
    await sendSMS(from, aiResult.reply);
  }
  
  // Return TwiML response
  return new NextResponse('<?xml version="1.0"?><Response></Response>', {
    headers: { 'Content-Type': 'text/xml' }
  });
}
```

---

## Email System

### Core Files

| File | Purpose |
|------|---------|
| `src/lib/email.ts` | `sendEmail()` function using nodemailer |
| `src/lib/services/email-service.ts` | Extended email service |
| `src/lib/services/email-polling-service.ts` | Poll for inbound emails |
| `src/app/api/webhooks/email/route.ts` | Inbound email webhook |

### Sending Email

```typescript
import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USERNAME,
    pass: process.env.SMTP_PASSWORD,
  },
});

export async function sendEmail(
  to: string, 
  subject: string, 
  text: string, 
  html?: string
) {
  const info = await transporter.sendMail({
    from: `"${process.env.SMTP_FROM_NAME}" <${process.env.SMTP_FROM_EMAIL}>`,
    to,
    subject,
    text,
    html
  });
  return { success: true, messageId: info.messageId };
}
```

### AI-Enhanced Email (using same pattern as SMS)

```typescript
// Apply same EnhancedAISMSService pattern for email
const emailContext = {
  firstName: patient.firstName,
  lastName: patient.lastName,
  // ... other context
};

const aiReply = await EnhancedAISMSService.generateEnhancedReply(
  emailBody,
  emailContext,
  { maxLength: 500, tone: 'professional' }  // Longer for email
);
```

---

## Dependencies

### Required NPM Packages

```json
{
  "twilio": "^4.x",
  "nodemailer": "^6.x",
  "@anthropic-ai/sdk": "^0.51.0"
}
```

### Install

```bash
npm install twilio nodemailer @anthropic-ai/sdk
```

---

## Environment Variables

### Twilio (Voice & SMS)

```env
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_PHONE_NUMBER=+1234567890

# AI Features
ENABLE_AI_SMS_REPLY=true
ENABLE_AI_VOICE_ANSWER=true

# Office fallback number
MAIN_OFFICE_NUMBER=+1234567890
```

### Email (SMTP)

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_FROM_NAME=Your Practice Name
SMTP_FROM_EMAIL=noreply@yourpractice.com
```

### AI (Anthropic Claude)

```env
ANTHROPIC_API_KEY=sk-ant-api03-xxxxx
```

---

## File-by-File Porting Guide

### Priority 1: Core Libraries

| File | Copy To | Notes |
|------|---------|-------|
| `src/lib/twilio.ts` | `lib/twilio.ts` | Twilio client + sendSMS + makeVoiceCall |
| `src/lib/voice.ts` | `lib/voice.ts` | Extended voice with voice selection |
| `src/lib/email.ts` | `lib/email.ts` | Nodemailer wrapper |

### Priority 2: AI Services

| File | Copy To | Notes |
|------|---------|-------|
| `src/lib/services/enhanced-ai-sms-service.ts` | `lib/services/` | AI intent + reply generation |
| `src/lib/services/ai-sms-service.ts` | `lib/services/` | Simpler AI SMS |

### Priority 3: Webhooks

| File | Copy To | Notes |
|------|---------|-------|
| `src/app/api/webhooks/twilio/sms/route.ts` | `app/api/webhooks/twilio/sms/` | Inbound SMS |
| `src/app/api/webhooks/twilio/voice/route.ts` | `app/api/webhooks/twilio/voice/` | Inbound voice |
| `src/app/api/webhooks/twilio/voice/menu/route.ts` | Same path | IVR menu |
| `src/app/api/webhooks/twilio/voice/ai-response/route.ts` | Same path | AI voice processing |

### Priority 4: Database Models

| File | Purpose |
|------|---------|
| `src/models/communication.ts` | Communication logging model |
| `src/models/voice-call.ts` | Voice call tracking |

---

## Twilio Configuration

### 1. Get Twilio Credentials

1. Go to [Twilio Console](https://console.twilio.com)
2. Copy Account SID and Auth Token
3. Buy or use existing phone number

### 2. Configure Webhooks in Twilio

**For SMS:**
- Go to Phone Numbers → Your Number → Messaging
- Set "A Message Comes In" webhook to:
  ```
  https://your-domain.com/api/webhooks/twilio/sms
  ```

**For Voice:**
- Go to Phone Numbers → Your Number → Voice & Fax
- Set "A Call Comes In" webhook to:
  ```
  https://your-domain.com/api/webhooks/twilio/voice
  ```

### 3. Webhook Validation (Production)

```typescript
import twilio from 'twilio';

const isValid = twilio.validateRequest(
  process.env.TWILIO_AUTH_TOKEN!,
  request.headers.get('x-twilio-signature')!,
  request.url,
  Object.fromEntries(params)
);

if (!isValid) {
  return new Response('Invalid signature', { status: 403 });
}
```

---

## AI Integration Points

### 1. Voice AI (Speech-to-Text + Response)

```
Patient speaks → Twilio transcribes → AI analyzes intent → Generate TwiML response
```

The `/api/webhooks/twilio/voice/ai-response` endpoint:
- Receives transcribed speech from Twilio
- Uses Claude to understand intent
- Generates appropriate TwiML response

### 2. SMS AI (Intent + Reply)

```
Patient texts → Webhook receives → AI analyzes intent → Generate reply → Send via Twilio
```

Key function: `EnhancedAISMSService.generateEnhancedReply()`

### 3. Voice Selection

Users can select from multiple Polly voices:
- Joanna (US Female)
- Matthew (US Male)
- Amy (UK Female)
- Emma (UK Female)
- Brian (UK Male)

Store preference in user settings and pass to `makeVoiceCall()`.

---

## Quick Start Steps

1. **Install dependencies:**
   ```bash
   npm install twilio nodemailer @anthropic-ai/sdk
   ```

2. **Copy core files:**
   - `lib/twilio.ts`
   - `lib/voice.ts`
   - `lib/email.ts`
   - `lib/services/enhanced-ai-sms-service.ts`

3. **Create webhook routes:**
   - `app/api/webhooks/twilio/sms/route.ts`
   - `app/api/webhooks/twilio/voice/route.ts`

4. **Set environment variables:**
   ```env
   TWILIO_ACCOUNT_SID=xxx
   TWILIO_AUTH_TOKEN=xxx
   TWILIO_PHONE_NUMBER=+1xxx
   ANTHROPIC_API_KEY=xxx
   ENABLE_AI_SMS_REPLY=true
   ENABLE_AI_VOICE_ANSWER=true
   ```

5. **Configure Twilio webhooks** to point to your deployed app URLs

6. **Test:**
   - Send SMS to your Twilio number
   - Call your Twilio number
   - Verify AI responses work

---

## Example Usage

### Make an AI-Voice Call

```typescript
import { makeVoiceCall } from '@/lib/twilio';

await makeVoiceCall(
  '+1234567890',
  'Hello John, this is a reminder about your appointment tomorrow at 10 AM.',
  'Polly.Joanna'
);
```

### Send AI-Generated SMS Reply

```typescript
import { EnhancedAISMSService } from '@/lib/services/enhanced-ai-sms-service';
import { sendSMS } from '@/lib/twilio';

const result = await EnhancedAISMSService.generateEnhancedReply(
  patientMessage,
  patientContext,
  { tone: 'friendly' }
);

await sendSMS(patientPhone, result.reply);
```

### Send Appointment Email

```typescript
import { sendEmail } from '@/lib/email';

await sendEmail(
  'patient@email.com',
  'Appointment Confirmation',
  'Your appointment is confirmed for January 25 at 10:00 AM.',
  '<h1>Appointment Confirmed</h1><p>See you soon!</p>'
);
```
