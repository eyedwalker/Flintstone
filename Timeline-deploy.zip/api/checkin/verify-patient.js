/**
 * Patient Verification API for Mobile Check-in
 * Verifies patient identity using phone, DOB, and last name
 */

import { PatientJourneyService } from '../../src/lib/services/patient-journey-service';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, message: 'Method not allowed' });
  }

  try {
    const { phone, dateOfBirth, lastName } = req.body;

    // Validate required fields
    if (!phone || !dateOfBirth || !lastName) {
      return res.status(400).json({ 
        success: false, 
        message: 'Phone number, date of birth, and last name are required' 
      });
    }

    // Clean phone number for matching
    const cleanPhone = phone.replace(/\D/g, '');
    
    // Mock patient lookup - in real implementation, this would query Eyefinity/database
    const mockPatients = [
      {
        id: 'patient-1',
        name: 'John Smith',
        phone: '5551234567',
        dateOfBirth: '1985-03-15',
        lastName: 'Smith',
        email: 'john.smith@email.com'
      },
      {
        id: 'patient-2',
        name: 'Sarah Johnson',
        phone: '5559876543',
        dateOfBirth: '1992-07-22',
        lastName: 'Johnson',
        email: 'sarah.johnson@email.com'
      },
      {
        id: 'patient-3',
        name: 'Michael Davis',
        phone: '5555551234',
        dateOfBirth: '1978-11-08',
        lastName: 'Davis',
        email: 'michael.davis@email.com'
      }
    ];

    // Find matching patient
    const patient = mockPatients.find(p => 
      p.phone.includes(cleanPhone.slice(-10)) &&
      p.dateOfBirth === dateOfBirth &&
      p.lastName.toLowerCase() === lastName.toLowerCase()
    );

    if (!patient) {
      return res.status(404).json({
        success: false,
        message: 'Patient not found. Please verify your information or contact the office.'
      });
    }

    // Check for today's appointment
    const today = new Date().toISOString().split('T')[0];
    const mockAppointments = [
      {
        id: 'appt-1',
        patientId: 'patient-1',
        date: today,
        time: '14:30',
        provider: 'Smith',
        status: 'scheduled',
        reasonForVisit: 'Annual Eye Exam'
      },
      {
        id: 'appt-2',
        patientId: 'patient-2',
        date: today,
        time: '15:15',
        provider: 'Johnson',
        status: 'scheduled',
        reasonForVisit: 'Contact Lens Fitting'
      }
    ];

    const appointment = mockAppointments.find(a => 
      a.patientId === patient.id && 
      a.date === today &&
      a.status === 'scheduled'
    );

    // Return patient info and appointment if found
    res.status(200).json({
      success: true,
      patient: {
        id: patient.id,
        name: patient.name,
        phone: patient.phone
      },
      appointment: appointment || null,
      message: appointment 
        ? 'Patient and appointment verified' 
        : 'Patient verified, but no appointment found for today'
    });

  } catch (error) {
    console.error('Patient verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during verification. Please try again.'
    });
  }
}
