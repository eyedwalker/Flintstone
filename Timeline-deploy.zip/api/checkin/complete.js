/**
 * Complete Mobile Check-in API
 * Creates patient journey and updates appointment status
 */

import { PatientJourneyService } from '../../src/lib/services/patient-journey-service';

// Office location coordinates (example - replace with actual coordinates)
const OFFICE_LOCATION = {
  latitude: 37.7749,
  longitude: -122.4194,
  radiusMeters: 100 // 100 meter radius around office
};

// Calculate distance between two coordinates
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = lat1 * Math.PI/180;
  const φ2 = lat2 * Math.PI/180;
  const Δφ = (lat2-lat1) * Math.PI/180;
  const Δλ = (lon2-lon1) * Math.PI/180;

  const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
          Math.cos(φ1) * Math.cos(φ2) *
          Math.sin(Δλ/2) * Math.sin(Δλ/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

  return R * c; // Distance in meters
}

// Validate location is near office
function isLocationValid(userLocation) {
  if (!userLocation || !userLocation.latitude || !userLocation.longitude) {
    return { valid: false, reason: 'Location not provided' };
  }

  const distance = calculateDistance(
    userLocation.latitude,
    userLocation.longitude,
    OFFICE_LOCATION.latitude,
    OFFICE_LOCATION.longitude
  );

  if (distance <= OFFICE_LOCATION.radiusMeters) {
    return { valid: true, distance };
  }

  return { 
    valid: false, 
    reason: `Location too far from office (${Math.round(distance)}m away)`,
    distance 
  };
}

// Create default journey steps for eye care practice
function createDefaultJourneySteps(appointmentType = 'comprehensive') {
  const baseSteps = [
    {
      id: 'forms',
      title: 'Complete Patient Forms',
      description: 'Update insurance and medical history',
      estimatedDuration: 10,
      isRequired: true,
      status: 'pending'
    },
    {
      id: 'pre-testing',
      title: 'Pre-Testing',
      description: 'Visual acuity and preliminary tests',
      estimatedDuration: 15,
      isRequired: true,
      status: 'pending'
    },
    {
      id: 'exam',
      title: 'Doctor Examination',
      description: 'Comprehensive eye examination',
      estimatedDuration: 30,
      isRequired: true,
      status: 'pending'
    }
  ];

  // Add dilation step for comprehensive exams
  if (appointmentType === 'comprehensive') {
    baseSteps.push({
      id: 'dilation',
      title: 'Dilation',
      description: 'Eye dilation and additional testing',
      estimatedDuration: 20,
      isRequired: false,
      status: 'pending'
    });
  }

  // Add optical consultation
  baseSteps.push({
    id: 'optical',
    title: 'Optical Consultation',
    description: 'Frame selection and lens options',
    estimatedDuration: 20,
    isRequired: false,
    status: 'pending'
  });

  return baseSteps;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, message: 'Method not allowed' });
  }

  try {
    const { patientId, appointmentId, location, verificationData } = req.body;

    if (!patientId) {
      return res.status(400).json({ 
        success: false, 
        message: 'Patient ID is required' 
      });
    }

    // Validate location if provided
    let locationValidation = { valid: true };
    if (location) {
      locationValidation = isLocationValid(location);
      
      // For now, log location issues but don't block check-in
      if (!locationValidation.valid) {
        console.warn('Location validation failed:', locationValidation.reason);
        // Could send notification to staff about remote check-in attempt
      }
    }

    // Mock patient and appointment lookup
    const mockPatients = [
      {
        id: 'patient-1',
        name: 'John Smith',
        phone: '5551234567',
        email: 'john.smith@email.com'
      },
      {
        id: 'patient-2', 
        name: 'Sarah Johnson',
        phone: '5559876543',
        email: 'sarah.johnson@email.com'
      },
      {
        id: 'patient-3',
        name: 'Michael Davis', 
        phone: '5555551234',
        email: 'michael.davis@email.com'
      }
    ];

    const patient = mockPatients.find(p => p.id === patientId);
    if (!patient) {
      return res.status(404).json({
        success: false,
        message: 'Patient not found'
      });
    }

    // Create patient journey
    const journeySteps = createDefaultJourneySteps('comprehensive');
    
    const journey = {
      id: `journey_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      patientId: patient.id,
      patientName: patient.name,
      patientPhone: patient.phone,
      patientEmail: patient.email,
      officeId: 'office-1',
      appointmentId,
      journeyPhase: 'in-office',
      priority: 'normal',
      reasonForVisit: 'Comprehensive Eye Exam',
      checkInTime: new Date().toISOString(),
      checkInMethod: 'mobile',
      checkInLocation: location,
      locationValidation,
      steps: journeySteps,
      currentStepId: 'forms',
      status: 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // Save journey using PatientJourneyService
    try {
      const savedJourney = PatientJourneyService.createJourney(journey);
      console.log('Patient journey created:', savedJourney.id);
    } catch (error) {
      console.error('Failed to save journey:', error);
      // Continue anyway - journey will be created in memory
    }

    // Send check-in notification to staff (in real implementation)
    // await sendStaffNotification(patient, journey);

    // Update appointment status (mock)
    if (appointmentId) {
      console.log(`Appointment ${appointmentId} marked as checked in`);
    }

    // Response based on location validation
    let message = 'Check-in completed successfully!';
    let warnings = [];

    if (location && !locationValidation.valid) {
      warnings.push('Location could not be verified - please confirm with front desk staff');
    }

    res.status(200).json({
      success: true,
      message,
      warnings,
      journey: {
        id: journey.id,
        patientName: journey.patientName,
        checkInTime: journey.checkInTime,
        currentStep: journeySteps[0],
        estimatedWaitTime: 10 // minutes
      },
      location: locationValidation
    });

  } catch (error) {
    console.error('Check-in completion error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during check-in. Please see front desk staff.'
    });
  }
}
