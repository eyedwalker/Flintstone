/**
 * Patient Favorites API
 * GET /api/patient/favorites - Get patient's favorite frames
 * DELETE /api/patient/favorites/:id - Remove a favorite
 */

import jwt from 'jsonwebtoken';
import { FrameScannerService } from '../../src/lib/services/frame-scanner-service';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    const { token } = req.query;

    if (!token) {
      return res.status(400).json({ error: 'Missing token parameter' });
    }

    // Verify token - accepts both 'measurements' and 'frame-scanner' token types
    let decoded;
    try {
      const secret = process.env.PATIENT_TOKEN_SECRET || 'default-secret-change-in-production';
      const payload = jwt.verify(token, secret);
      
      // Accept both measurements and frame-scanner token types
      if (payload.type === 'measurements' || payload.type === 'frame-scanner') {
        decoded = {
          patientId: payload.patientId || payload.patient_id,
          companyId: payload.companyId || payload.company_id
        };
      } else {
        console.warn('[favorites] Invalid token type:', payload.type);
        return res.status(401).json({ error: 'Invalid token type' });
      }
    } catch (error) {
      console.error('[favorites] Token verification failed:', error);
      return res.status(401).json({ error: 'Invalid or expired token' });
    }
    
    if (!decoded || !decoded.patientId || !decoded.companyId) {
      return res.status(401).json({ error: 'Invalid token structure' });
    }

    if (req.method === 'GET') {
      const favorites = await FrameScannerService.getFavorites(decoded.patientId, decoded.companyId);
      return res.status(200).json({ success: true, favorites });
    }

    if (req.method === 'DELETE') {
      const { id } = req.query;
      if (!id) {
        return res.status(400).json({ error: 'Missing favorite ID' });
      }

      const success = await FrameScannerService.removeFavorite(id);
      if (!success) {
        return res.status(404).json({ error: 'Favorite not found or already deleted' });
      }

      return res.status(200).json({ success: true, message: 'Favorite removed' });
    }

    return res.status(405).json({ error: 'Method not allowed' });

  } catch (error) {
    console.error('[favorites] Error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
