/**
 * Patient Frame Scan API
 * POST /api/patient/frame-scan - Scan UPC and add to favorites
 */

import jwt from 'jsonwebtoken';
import { FrameScannerService } from '../../src/lib/services/frame-scanner-service';

export default async function handler(req, res) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { token, upc_code, notes } = req.body;

    if (!token || !upc_code) {
      return res.status(400).json({ error: 'Missing required fields: token, upc_code' });
    }

    // Verify token - accepts both 'measurements' and 'frame-scanner' token types
    let decoded;
    try {
      const secret = process.env.PATIENT_TOKEN_SECRET || 'default-secret-change-in-production';
      const payload = jwt.verify(token, secret);
      
      // Accept both measurements and frame-scanner token types
      if (payload.type === 'measurements' || payload.type === 'frame-scanner') {
        decoded = {
          patientId: payload.patientId || payload.patient_id,
          companyId: payload.companyId || payload.company_id
        };
      } else {
        console.warn('[frame-scan] Invalid token type:', payload.type);
        return res.status(401).json({ error: 'Invalid token type' });
      }
    } catch (error) {
      console.error('[frame-scan] Token verification failed:', error);
      return res.status(401).json({ error: 'Invalid or expired token' });
    }
    
    if (!decoded || !decoded.patientId || !decoded.companyId) {
      return res.status(401).json({ error: 'Invalid token structure' });
    }

    // Scan frame
    const result = await FrameScannerService.scanFrame(
      upc_code,
      decoded.patientId,
      decoded.companyId,
      notes
    );

    if (!result.success) {
      return res.status(400).json({ error: result.message });
    }

    return res.status(200).json({
      success: true,
      message: result.message,
      frame: result.frame,
      favorite: result.favorite
    });

  } catch (error) {
    console.error('[frame-scan] Error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
