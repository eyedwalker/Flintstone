/**
 * Patient Measurements API
 * POST /api/patient/measurements - Save measurement results
 * GET /api/patient/measurements - Get patient's measurements
 */

import jwt from 'jsonwebtoken';
import { FrameScannerService } from '../../src/lib/services/frame-scanner-service';
import { patientMeasurementsAccessor } from '../../src/lib/accessors/PatientMeasurementsAccessor';
import { patientFaceProfileAccessor } from '../../src/lib/accessors/PatientFaceProfileAccessor';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    const token = req.method === 'GET' ? req.query.token : req.body?.token;

    if (!token) {
      return res.status(400).json({ error: 'Missing token' });
    }

    // Modify token verification to accept both 'measurements' and 'frame-scanner' token types
    let decoded;
    try {
      const secret = process.env.PATIENT_TOKEN_SECRET || 'default-secret-change-in-production';
      const payload = jwt.verify(token, secret);
      
      // Accept both measurements and frame-scanner token types
      if (payload.type === 'measurements' || payload.type === 'frame-scanner') {
        decoded = {
          patientId: payload.patientId || payload.patient_id,
          companyId: payload.companyId || payload.company_id
        };
      } else {
        console.warn('[measurements] Invalid token type:', payload.type);
        return res.status(401).json({ error: 'Invalid token type' });
      }
    } catch (error) {
      console.error('[measurements] Token verification failed:', error);
      return res.status(401).json({ error: 'Invalid or expired token' });
    }
    
    if (!decoded || !decoded.patientId || !decoded.companyId) {
      return res.status(401).json({ error: 'Invalid token structure' });
    }

    if (req.method === 'POST') {
      const {
        token, pd_total, pd_right, pd_left,
        seg_height_right, seg_height_left, 
        oc_height_right, oc_height_left,
        face_geometry, face_svg, 
        calibration_factor,
        has_lidar, device_type, face_landmarks,
        movement_sequence, depth_map, has_3d_data,
        movement_quality_score, reference_frame_id
      } = req.body;

      if (!pd_total) {
        return res.status(400).json({ error: 'PD measurement is required' });
      }

      const measurementId = await patientMeasurementsAccessor.saveMeasurement({
        patientId: decoded.patientId,
        companyId: decoded.companyId,
        pdTotal: parseFloat(pd_total) || null,
        pdRight: parseFloat(pd_right) || null,
        pdLeft: parseFloat(pd_left) || null,
        segHeightRight: parseFloat(seg_height_right) || null,
        segHeightLeft: parseFloat(seg_height_left) || null,
        ocHeightRight: parseFloat(oc_height_right) || null,
        ocHeightLeft: parseFloat(oc_height_left) || null,
        calibrationFactor: parseFloat(calibration_factor) || null,
        hasLidar: !!has_lidar,
        deviceType: device_type || 'unknown',
        status: 'pending_approval',
        movementSequence: movement_sequence || null,
        depthMap: depth_map || null,
        has3dData: !!has_3d_data,
        calibration_data: face_geometry ? {
          faceWidth: face_geometry.faceWidth,
          faceHeight: face_geometry.faceHeight,
          jawWidth: face_geometry.jawWidth,
          cheekboneWidth: face_geometry.cheekboneWidth,
          foreheadWidth: face_geometry.foreheadWidth,
          faceShape: face_geometry.faceShape,
          faceShapeConfidence: face_geometry.faceShapeConfidence,
          faceSVG: face_svg
        } : null,
        image_url: null,
        is_approved: false,
        notes: null
      });

      if (!result.success) {
        return res.status(400).json({ error: result.error || 'Failed to save measurements' });
      }

      // Auto-save face profile if face geometry data is present
      if (face_geometry) {
        try {
          const faceWidth = face_geometry.faceWidth;
          // Calculate frame recommendations based on face dimensions
          const recommendedFrameWidths = faceWidth ? {
            min: Math.round(faceWidth - 10),
            ideal: Math.round(faceWidth),
            max: Math.round(faceWidth + 8)
          } : null;

          const recommendedBridgeWidths = pd_total ? {
            min: Math.round((pd_total - 62) * 0.5 + 16),
            ideal: Math.round((pd_total - 62) * 0.5 + 18),
            max: Math.round((pd_total - 62) * 0.5 + 22)
          } : null;

          await patientFaceProfileAccessor.upsertProfile({
            patient_id: decoded.patientId,
            company_id: decoded.companyId,
            face_width: face_geometry.faceWidth,
            face_height: face_geometry.faceHeight,
            jaw_width: face_geometry.jawWidth,
            cheekbone_width: face_geometry.cheekboneWidth,
            forehead_width: face_geometry.foreheadWidth,
            face_shape: face_geometry.faceShape,
            face_shape_confidence: face_geometry.faceShapeConfidence,
            pd_total,
            pd_right,
            pd_left,
            outline_points: face_geometry.outlinePoints,
            face_svg: face_svg || null,
            measurement_id: result.data?.id || null,
            recommended_frame_widths: recommendedFrameWidths,
            recommended_bridge_widths: recommendedBridgeWidths,
            recommended_temple_lengths: null,
            is_active: true,
            source: 'self_service'
          });
          console.log('[measurements] Face profile saved for patient:', decoded.patientId);
        } catch (profileErr) {
          console.error('[measurements] Failed to save face profile (non-fatal):', profileErr);
        }
      }

      return res.status(200).json({
        success: true,
        measurement: result.data,
        message: 'Measurements saved successfully!'
      });
    }

    if (req.method === 'GET') {
      const result = await patientMeasurementsAccessor.getByPatient(
        decoded.patientId,
        decoded.companyId
      );

      return res.status(200).json({
        success: true,
        measurements: result.data || []
      });
    }

    return res.status(405).json({ error: 'Method not allowed' });

  } catch (error) {
    console.error('[measurements] Error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
