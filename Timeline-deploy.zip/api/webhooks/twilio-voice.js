/**
 * Twilio Voice Webhook Handler - Vercel Serverless Function
 * 
 * Features:
 * - HIGH-QUALITY ElevenLabs neural voices (human-like)
 * - AI-powered conversation with speech recognition
 * - Call recording with transcription
 * - Call transfer to staff
 * - Escalation queue integration
 * 
 * Configure in Twilio Console:
 * Phone Numbers → Your Number → Voice → "A Call Comes In" → POST to:
 * https://your-vercel-domain.vercel.app/api/webhooks/twilio-voice
 */

// In-memory call sessions (in production, use Redis/database via KV store)
const callSessions = new Map();

// Configuration
const FALLBACK_VOICE = 'Polly.Joanna'; // Fallback if ElevenLabs fails
const OFFICE_PHONE = process.env.OFFICE_PHONE_NUMBER || process.env.TWILIO_PHONE_NUMBER;
const RECORD_CALLS = process.env.TWILIO_RECORD_CALLS !== 'false';
const AI_MODE = process.env.TWILIO_AI_MODE !== 'false'; // Default ON for AI conversation
const USE_ELEVENLABS = process.env.USE_ELEVENLABS_VOICE !== 'false'; // Default ON
const ELEVENLABS_VOICE = process.env.ELEVENLABS_VOICE || 'sarah'; // sarah, rachel, emily, josh, adam

// Get base URL for audio generation
const getBaseUrl = () => {
  // Always use production domain for audio URLs to avoid TwiML parse failures
  return process.env.NEXT_PUBLIC_APP_URL || 'https://patientcare-teal.vercel.app';
};

// Build audio URL for ElevenLabs or fallback to Say
function buildSpeech(text, useFallback = false) {
  if (USE_ELEVENLABS && !useFallback) {
    // URL must be XML-escaped (& becomes &amp;) for valid TwiML
    const audioUrl = `${getBaseUrl()}/api/voice/generate-audio?voice=${ELEVENLABS_VOICE}&amp;text=${encodeURIComponent(text)}`;
    return `<Play>${audioUrl}</Play>`;
  }
  return `<Say voice="${FALLBACK_VOICE}">${escapeXml(text)}</Say>`;
}

export default async function handler(req, res) {
  // Allow both GET and POST for Twilio webhooks
  if (req.method !== 'POST' && req.method !== 'GET') {
    res.setHeader('Allow', ['GET', 'POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  try {
    const { From, To, CallSid, CallStatus, Digits, SpeechResult, RecordingUrl } = req.body || req.query;

    console.log('[Voice Webhook] Received call:', {
      from: From,
      to: To,
      callSid: CallSid,
      status: CallStatus,
      digits: Digits,
      speech: SpeechResult?.substring(0, 50),
      recording: RecordingUrl ? 'yes' : 'no',
    });

    // Store recording URL if provided
    if (RecordingUrl && CallSid) {
      const session = callSessions.get(CallSid) || { transcripts: [] };
      session.recordingUrl = RecordingUrl;
      callSessions.set(CallSid, session);
    }

    // Check if this is a gather callback (user pressed digits or spoke)
    if (Digits || SpeechResult) {
      // Store transcript
      if (SpeechResult && CallSid) {
        const session = callSessions.get(CallSid) || { transcripts: [] };
        session.transcripts.push({ role: 'patient', content: SpeechResult, timestamp: new Date() });
        callSessions.set(CallSid, session);
      }
      
      return AI_MODE 
        ? handleAIConversation(req, res, { Digits, SpeechResult, From, CallSid })
        : handleGatherResponse(req, res, { Digits, SpeechResult, From, CallSid });
    }

    // Initialize call session
    callSessions.set(CallSid, { 
      from: From, 
      startTime: new Date(), 
      transcripts: [],
      turnCount: 0 
    });

    // Initial call - present greeting with recording
    const greeting = getGreeting();
    const recordingTag = RECORD_CALLS 
      ? `<Record action="/api/webhooks/twilio-voice" recordingStatusCallback="/api/webhooks/twilio-status" maxLength="3600" transcribe="false" />`
      : '';
    
    const followup = AI_MODE 
      ? 'How may I help you today?' 
      : 'Press 1 for appointments. Press 2 for prescriptions. Press 3 for hours. Press 0 to speak with someone.';
    
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${recordingTag}
  ${buildSpeech(greeting)}
  <Gather input="dtmf speech" timeout="5" action="/api/webhooks/twilio-voice" method="POST" speechTimeout="auto" language="en-US" enhanced="true">
    ${buildSpeech(followup)}
  </Gather>
  ${buildSpeech("I didn't catch that. Let me transfer you to a staff member.")}
  <Dial timeout="30">
    <Number>${OFFICE_PHONE}</Number>
  </Dial>
</Response>`;

    res.setHeader('Content-Type', 'text/xml');
    return res.status(200).send(twiml);

  } catch (error) {
    console.error('[Voice Webhook] Error:', error);
    
    // Fallback to Polly on error (more reliable)
    const errorTwiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="${FALLBACK_VOICE}">We're experiencing technical difficulties. Let me connect you to a staff member.</Say>
  <Dial timeout="30">
    <Number>${OFFICE_PHONE}</Number>
  </Dial>
</Response>`;

    res.setHeader('Content-Type', 'text/xml');
    return res.status(200).send(errorTwiml);
  }
}

function getGreeting() {
  const hour = new Date().getHours();
  let timeGreeting = 'Good day';
  if (hour < 12) timeGreeting = 'Good morning';
  else if (hour < 17) timeGreeting = 'Good afternoon';
  else timeGreeting = 'Good evening';

  return `${timeGreeting} and thank you for calling. How may I help you today?`;
}

async function handleGatherResponse(req, res, { Digits, SpeechResult, From, CallSid }) {
  const input = Digits || SpeechResult?.toLowerCase() || '';
  console.log('[Voice Webhook] Processing input:', input);

  let message = '';
  let shouldTransfer = false;
  let shouldEnd = false;

  // Appointments
  if (input === '1' || input.includes('appointment') || input.includes('schedule')) {
    message = "I'd be happy to help with appointments. Our next available time is tomorrow at 10 AM. Press 1 to confirm, or press 0 to speak with our scheduler.";
  }
  // Pharmacy/Prescription
  else if (input === '2' || input.includes('pharmacy') || input.includes('prescription') || input.includes('refill')) {
    message = "For prescription refills, please contact your pharmacy directly. If you need a new prescription, I can help you schedule an appointment. Is there anything else?";
  }
  // Hours/Location
  else if (input === '3' || input.includes('hour') || input.includes('direction') || input.includes('location') || input.includes('address')) {
    message = "We're open Monday through Friday, 8 AM to 5 PM. We're located at 123 Medical Center Drive with free parking in back. Anything else I can help with?";
  }
  // Operator/Transfer
  else if (input === '0' || input.includes('operator') || input.includes('person') || input.includes('staff') || input.includes('human')) {
    message = "Of course! Let me connect you to a staff member. One moment please.";
    shouldTransfer = true;
  }
  // Unknown
  else {
    message = "I want to make sure I help you correctly. Could you tell me more about what you need?";
  }

  let response;
  if (shouldTransfer) {
    response = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeech(message)}
  <Dial timeout="30" action="/api/webhooks/twilio-voice/transfer-complete">
    <Number>${OFFICE_PHONE}</Number>
  </Dial>
  ${buildSpeech("I'm sorry, no one is available. Please leave a message after the tone.")}
  <Record maxLength="120" action="/api/webhooks/twilio-voice/voicemail" transcribe="true" />
</Response>`;
  } else {
    response = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeech(message)}
  <Gather input="dtmf speech" timeout="5" action="/api/webhooks/twilio-voice" method="POST" speechTimeout="auto" language="en-US" enhanced="true">
  </Gather>
  ${buildSpeech("Thank you for calling. Goodbye!")}
</Response>`;
  }

  res.setHeader('Content-Type', 'text/xml');
  return res.status(200).send(response);
}

/**
 * AI Conversation Mode - Natural language conversation with the AI agent
 */
async function handleAIConversation(req, res, { Digits, SpeechResult, From, CallSid }) {
  const input = SpeechResult?.toLowerCase() || '';
  const session = callSessions.get(CallSid) || { transcripts: [], turnCount: 0 };
  
  session.turnCount = (session.turnCount || 0) + 1;
  
  console.log('[Voice Webhook] AI Mode - Processing:', input, 'Turn:', session.turnCount);

  // Check for escalation keywords
  const escalationKeywords = ['angry', 'frustrated', 'upset', 'complaint', 'manager', 'supervisor', 'speak to someone', 'real person'];
  const needsEscalation = escalationKeywords.some(kw => input.includes(kw));
  
  // Check for transfer keywords
  const transferKeywords = ['operator', 'person', 'staff', 'human', 'transfer', 'connect me'];
  const needsTransfer = Digits === '0' || transferKeywords.some(kw => input.includes(kw));
  
  // Check for goodbye
  const goodbyeKeywords = ['goodbye', 'bye', 'thank you', 'thanks', 'that\'s all'];
  const isGoodbye = goodbyeKeywords.some(kw => input.includes(kw));
  
  // Max conversation turns
  if (session.turnCount > 10) {
    const response = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeech("Thank you for your patience. Let me connect you with a staff member who can help further.")}
  <Dial timeout="30" action="/api/webhooks/twilio-voice/transfer-complete">
    <Number>${OFFICE_PHONE}</Number>
  </Dial>
  ${buildSpeech("I'm sorry, no one is available. Please leave a message after the tone.")}
  <Record maxLength="120" action="/api/webhooks/twilio-voice/voicemail" transcribe="true" />
</Response>`;
    res.setHeader('Content-Type', 'text/xml');
    return res.status(200).send(response);
  }

  // Handle escalation
  if (needsEscalation) {
    const response = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeech("I completely understand this is important to you. Let me connect you with someone who can help right away.")}
  <Dial timeout="30" action="/api/webhooks/twilio-voice/transfer-complete">
    <Number>${OFFICE_PHONE}</Number>
  </Dial>
  ${buildSpeech("I apologize, but no one is available right now. Please leave a message and we'll call you back within the hour.")}
  <Record maxLength="120" action="/api/webhooks/twilio-voice/voicemail" transcribe="true" />
</Response>`;
    res.setHeader('Content-Type', 'text/xml');
    return res.status(200).send(response);
  }

  // Handle transfer request
  if (needsTransfer) {
    const response = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeech("Of course! Let me connect you to a staff member. One moment please.")}
  <Dial timeout="30" action="/api/webhooks/twilio-voice/transfer-complete">
    <Number>${OFFICE_PHONE}</Number>
  </Dial>
  ${buildSpeech("I'm sorry, no one is available right now. Please leave a message after the tone.")}
  <Record maxLength="120" action="/api/webhooks/twilio-voice/voicemail" transcribe="true" />
</Response>`;
    res.setHeader('Content-Type', 'text/xml');
    return res.status(200).send(response);
  }

  // Handle goodbye
  if (isGoodbye) {
    const response = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeech("Thank you so much for calling! Have a wonderful day. Goodbye!")}
  <Hangup />
</Response>`;
    res.setHeader('Content-Type', 'text/xml');
    return res.status(200).send(response);
  }

  // Generate contextual AI response
  const aiResponse = await generateAIResponse(input, session);
  
  // Store AI response in transcript
  session.transcripts.push({ role: 'assistant', content: aiResponse, timestamp: new Date() });
  callSessions.set(CallSid, session);

  const response = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeech(aiResponse)}
  <Gather input="dtmf speech" timeout="5" action="/api/webhooks/twilio-voice" method="POST" speechTimeout="auto" language="en-US" enhanced="true">
    ${buildSpeech("Is there anything else I can help you with?")}
  </Gather>
  ${buildSpeech("Thank you for calling. Goodbye!")}
</Response>`;

  res.setHeader('Content-Type', 'text/xml');
  return res.status(200).send(response);
}

/**
 * Generate AI response using comprehensive knowledge base and Claude AI
 */
async function generateAIResponse(input, session) {
  try {
    // Embedded practice knowledge for reliability
    const practiceKnowledge = `
**Vision Care Center Practice Information:**
- Hours: Monday-Friday 8:00 AM - 5:00 PM, Saturday 9:00 AM - 1:00 PM, Sunday Closed
- Address: 123 Vision Way, Suite 100, Dallas, TX 75201 with free parking
- Phone: (555) 555-1234
- Services: Eye Exams, Contact Lenses, Glasses, LASIK Consultations, Dry Eye Treatment
- Dr. Sarah Johnson, OD - 15+ years experience, accepting new patients
- Insurance: VSP, EyeMed, Spectera, Medicare, Davis Vision, Cigna, Aetna, BCBS
- Pricing: Eye Exam $99-149, Contact Lens Exam $149-199, Glasses $150-500+
- Bring to appointment: insurance card, ID, current glasses/contacts, medication list
- Exams take 30-45 minutes, arrive 15 minutes early for paperwork
`;
    
    // Use Claude with embedded knowledge for voice responses
    const Anthropic = require('@anthropic-ai/sdk').default;
    const anthropic = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });

    const systemPrompt = `You are an intelligent medical office AI assistant with comprehensive knowledge and capabilities handling VOICE calls.

${practiceKnowledge}

COMMUNICATION CHANNEL: VOICE (speak naturally, use conversational tone, keep responses under 30 seconds)

VOICE-SPECIFIC GUIDELINES:
- Speak clearly and at a moderate pace
- Use natural speech patterns, not text abbreviations
- Keep responses concise but complete (15-20 seconds max)
- Use "and" instead of "&", say "dollars" not "$"
- Be warm and conversational, like talking to a friend
- If you need more information, ask ONE specific question

CAPABILITIES - You can help with:
- Appointment scheduling, confirmation, rescheduling, cancellation
- Insurance verification and coverage questions  
- Practice information (hours, location, services, directions)
- Pre-visit instructions and what to bring
- General eye care questions and education
- Emergency triage and immediate escalation
- Prescription and glasses questions
- Billing and payment information

AVAILABLE ACTIONS you can take:
- Check appointment status by asking for name and date
- Schedule appointments by offering specific available times
- Confirm or reschedule existing appointments
- Provide detailed directions and parking information
- Answer specific insurance plan questions
- Detect emergencies and escalate immediately
- Transfer to appropriate staff when needed

CONVERSATION HISTORY:
${session.transcripts?.map(t => `${t.role}: ${t.content}`).join('\n') || 'No previous conversation'}

RESPONSE STYLE for VOICE:
- Professional but warm and friendly
- Speak as if you're right there helping them
- Use the patient's name if they provide it
- Give specific, actionable information
- Always end with asking if there's anything else
- If unsure, offer to transfer to a staff member

Current date: ${new Date().toLocaleDateString()}
Current time: ${new Date().toLocaleTimeString()}`;

    const aiResponse = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 150, // Keep voice responses concise
      system: systemPrompt,
      messages: [
        { role: 'user', content: `Patient said: "${input}"` }
      ],
    });

    const response = aiResponse.content[0]?.text || "I want to make sure I help you correctly. Could you tell me a bit more about what you need assistance with today?";
    
    console.log('[Voice Webhook] Enhanced AI response generated for voice:', response.substring(0, 100));
    return response;
    
  } catch (error) {
    console.error('[Voice Webhook] AI generation failed, using fallback:', error.message);
    
    // Fallback to basic rule-based response
    const lower = input.toLowerCase();
    
    if (lower.includes('appointment')) {
      return "I'd be happy to help you with your appointment. Can you tell me your name so I can look up your information?";
    }
    if (lower.includes('hour') || lower.includes('open')) {
      return "We're open Monday through Friday from 8 AM to 5 PM. We're closed weekends and holidays.";
    }
    if (lower.includes('location') || lower.includes('address')) {
      return "We're located at 123 Medical Center Drive with free parking in back. Would you like more detailed directions?";
    }
    if (lower.includes('insurance')) {
      return "We accept most major vision insurance plans. I can have our billing team verify your specific coverage. What insurance do you have?";
    }
    
    return "I want to make sure I help you correctly. Could you tell me a bit more about what you need assistance with today?";
  }
}

/**
 * Escape XML special characters
 */
function escapeXml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

/**
 * Get call session (exported for status webhook)
 */
export function getCallSession(callSid) {
  return callSessions.get(callSid);
}

/**
 * Clear call session (exported for cleanup)
 */
export function clearCallSession(callSid) {
  return callSessions.delete(callSid);
}
