/**
 * Inbound Email Webhook Handler
 * 
 * Handles incoming emails with AI-powered responses using Claude AI.
 * Supports SendGrid Inbound Parse and generic email webhook formats.
 * 
 * Configure in SendGrid:
 * Settings → Inbound Parse → Add Host & URL
 * URL: https://your-domain.vercel.app/api/webhooks/inbound-email
 */

import nodemailer from 'nodemailer';

export default async function handler(req, res) {
  // CORS for testing
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Parse email data (supports SendGrid Inbound Parse format)
    const {
      from,
      to,
      subject,
      text,
      html,
      // SendGrid specific fields
      envelope,
      headers,
      attachments,
      // Alternative field names
      sender,
      recipient,
      body,
    } = req.body;

    const senderEmail = from || sender || envelope?.from;
    const recipientEmail = to || recipient || envelope?.to;
    const emailSubject = subject || '(No Subject)';
    const emailBody = text || body || stripHtml(html) || '';

    console.log('[Inbound Email] Received:', {
      from: senderEmail,
      to: recipientEmail,
      subject: emailSubject,
      bodyPreview: emailBody?.substring(0, 100),
    });

    if (!senderEmail || !emailBody) {
      console.log('[Inbound Email] Missing required fields');
      return res.status(400).json({ error: 'Missing from or body' });
    }

    // Check if AI email reply is enabled
    const enableAI = process.env.ENABLE_AI_EMAIL_REPLY === 'true';
    
    let replySubject = `Re: ${emailSubject}`;
    let replyBody = 'Thank you for your email. We will respond during business hours.';
    let replyHtml = `<p>${replyBody}</p>`;

    if (enableAI && process.env.ANTHROPIC_API_KEY) {
      try {
        const Anthropic = require('@anthropic-ai/sdk').default;
        const anthropic = new Anthropic({
          apiKey: process.env.ANTHROPIC_API_KEY,
        });

        const systemPrompt = `You are an intelligent medical office AI assistant responding to patient emails for Vision Care Center.

PRACTICE INFORMATION:
- Name: Vision Care Center
- Hours: Monday-Friday 8:00 AM - 5:00 PM, Saturday 9:00 AM - 1:00 PM
- Address: 123 Vision Way, Suite 100, Dallas, TX 75201
- Phone: (555) 555-1234
- Services: Eye Exams, Contact Lenses, Glasses, LASIK Consultations, Dry Eye Treatment
- Insurance: VSP, EyeMed, Spectera, Medicare, Davis Vision, Cigna, Aetna, BCBS

EMAIL RESPONSE GUIDELINES:
- Be professional, warm, and helpful
- Use proper email formatting with greeting and signature
- Keep responses concise but thorough
- If appointment-related: offer to help schedule/confirm
- If question about services: provide relevant information
- If urgent/emergency: advise to call office or seek immediate care
- If billing/insurance: offer to connect with billing department
- Never provide specific medical advice
- Include office contact information
- Sign as "Sarah, Virtual Assistant" with disclaimer

EMAIL SUBJECT: ${emailSubject}
FROM: ${senderEmail}

Generate a professional email response:`;

        const aiResponse = await anthropic.messages.create({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 500,
          system: systemPrompt,
          messages: [
            { role: 'user', content: `Patient email:\n\n${emailBody}` }
          ],
        });

        replyBody = aiResponse.content[0]?.text || replyBody;
        
        // Convert to HTML
        replyHtml = formatEmailHtml(replyBody);
        
        console.log('[Inbound Email] AI reply generated:', replyBody.substring(0, 100));

      } catch (aiError) {
        console.error('[Inbound Email] AI error:', aiError.message);
        // Fall back to default response
      }
    }

    // Send reply email
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: false,
      auth: {
        user: process.env.SMTP_USERNAME,
        pass: process.env.SMTP_PASSWORD,
      },
    });

    await transporter.sendMail({
      from: `"${process.env.SMTP_FROM_NAME || 'Vision Care Center'}" <${process.env.SMTP_FROM_EMAIL || process.env.SMTP_USERNAME}>`,
      to: senderEmail,
      subject: replySubject,
      text: replyBody,
      html: replyHtml,
      replyTo: process.env.SMTP_FROM_EMAIL || process.env.SMTP_USERNAME,
    });

    console.log('[Inbound Email] Reply sent to:', senderEmail);

    // Log the email for records (would store in database in production)
    const emailRecord = {
      id: `email_${Date.now()}`,
      direction: 'inbound',
      from: senderEmail,
      to: recipientEmail,
      subject: emailSubject,
      body: emailBody,
      reply: replyBody,
      timestamp: new Date().toISOString(),
      aiGenerated: enableAI && !!process.env.ANTHROPIC_API_KEY,
    };

    console.log('[Inbound Email] Record:', JSON.stringify(emailRecord, null, 2));

    return res.status(200).json({
      success: true,
      message: 'Email processed and reply sent',
      from: senderEmail,
      replyPreview: replyBody.substring(0, 100) + '...',
    });

  } catch (error) {
    console.error('[Inbound Email] Error:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to process email',
    });
  }
}

function stripHtml(html) {
  if (!html) return '';
  return html
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .trim();
}

function formatEmailHtml(text) {
  // Convert plain text to HTML with proper formatting
  const lines = text.split('\n');
  let html = '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">';
  
  for (const line of lines) {
    if (line.trim() === '') {
      html += '<br>';
    } else if (line.startsWith('Subject:') || line.startsWith('Dear') || line.startsWith('Hi')) {
      html += `<p style="margin: 10px 0;"><strong>${escapeHtml(line)}</strong></p>`;
    } else if (line.includes('Sarah') || line.includes('Virtual Assistant')) {
      html += `<p style="margin: 10px 0; color: #666;">${escapeHtml(line)}</p>`;
    } else {
      html += `<p style="margin: 10px 0;">${escapeHtml(line)}</p>`;
    }
  }
  
  html += `
    <hr style="margin-top: 20px; border: none; border-top: 1px solid #ddd;">
    <p style="font-size: 12px; color: #888;">
      This email was sent by an AI assistant. For urgent matters, please call (555) 555-1234.<br>
      Vision Care Center | 123 Vision Way, Suite 100, Dallas, TX 75201
    </p>
  </div>`;
  
  return html;
}

function escapeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
