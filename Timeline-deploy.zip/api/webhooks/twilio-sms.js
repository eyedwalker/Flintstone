/**
 * Twilio SMS Webhook Handler - Two-Way AI Texting
 * 
 * Features:
 * - AI-powered responses using Claude
 * - Conversation history (remembers context)
 * - Patient lookup by phone number
 * - Actions: scheduling, links, transfers
 * 
 * Configure in Twilio Console:
 * Phone Numbers → Your Number → Messaging → "A Message Comes In" → POST to:
 * https://patientcare-teal.vercel.app/api/webhooks/twilio-sms
 */

import twilio from 'twilio';
import Anthropic from '@anthropic-ai/sdk';
import { getDb } from '../_lib/db.js';

// Conversation history storage (use Redis in production)
const conversations = new Map();
const CONVERSATION_TTL = 30 * 60 * 1000; // 30 minutes

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  try {
    const { From, To, Body, MessageSid, AccountSid } = req.body;

    console.log('[SMS] Received:', From, '-', Body?.substring(0, 50));

    // Validate Twilio signature
    if (AccountSid !== process.env.TWILIO_ACCOUNT_SID) {
      return res.status(403).send('Forbidden');
    }

    const client = twilio(
      process.env.TWILIO_ACCOUNT_SID,
      process.env.TWILIO_AUTH_TOKEN
    );

    // Get or create conversation
    let conversation = conversations.get(From) || { messages: [], patient: null };
    
    // Look up patient by phone number
    if (!conversation.patient) {
      conversation.patient = await lookupPatient(From);
    }

    // Add incoming message to history
    conversation.messages.push({
      role: 'user',
      content: Body,
      timestamp: Date.now(),
    });

    // Keep only last 10 messages
    if (conversation.messages.length > 10) {
      conversation.messages = conversation.messages.slice(-10);
    }

    // Generate AI response
    let replyMessage;
    try {
      replyMessage = await generateSMSResponse(Body, conversation, From);
    } catch (err) {
      console.error('[SMS] AI error:', err.message);
      replyMessage = "Thanks for your message! We'll get back to you shortly. For urgent matters, please call (555) 555-1234.";
    }

    // Add response to history
    conversation.messages.push({
      role: 'assistant',
      content: replyMessage,
      timestamp: Date.now(),
    });

    // Save conversation
    conversations.set(From, conversation);

    // Clean old conversations
    cleanOldConversations();

    // Check for escalation triggers
    await checkSMSEscalation(Body, From, MessageSid, conversation);

    // Check for actions in the message
    await handleSMSActions(Body, From, conversation, client);

    // Send reply
    await client.messages.create({
      body: replyMessage,
      to: From,
      from: process.env.TWILIO_PHONE_NUMBER,
    });

    console.log('[SMS] Replied:', replyMessage.substring(0, 50));

    res.setHeader('Content-Type', 'text/xml');
    return res.status(200).send('<?xml version="1.0" encoding="UTF-8"?><Response></Response>');

  } catch (error) {
    console.error('[SMS] Error:', error);
    res.setHeader('Content-Type', 'text/xml');
    return res.status(200).send('<?xml version="1.0" encoding="UTF-8"?><Response></Response>');
  }
}

/**
 * Look up patient by phone number
 */
async function lookupPatient(phone) {
  const cleanPhone = phone.replace(/\D/g, '').slice(-10);
  const baseUrl = process.env.VITE_APP_URL || 'https://patientcare-teal.vercel.app';

  try {
    const response = await fetch(`${baseUrl}/api/eyefinity/v2patients?Phone=${cleanPhone}&pageSize=1`);
    if (response.ok) {
      const data = await response.json();
      if (data.items?.length > 0) {
        const p = data.items[0];
        return {
          id: p.PatientId || p.Id,
          firstName: p.FirstName,
          lastName: p.LastName,
          name: `${p.FirstName} ${p.LastName}`,
        };
      }
    }
  } catch (err) {
    console.log('[SMS] Patient lookup failed:', err.message);
  }
  return null;
}

/**
 * Generate AI response with conversation context
 */
async function generateSMSResponse(message, conversation, phone) {
  const anthropic = new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY,
  });

  const patientName = conversation.patient?.firstName || 'there';
  const patientContext = conversation.patient 
    ? `KNOWN PATIENT: ${conversation.patient.name} (ID: ${conversation.patient.id})`
    : `UNKNOWN PATIENT - Phone: ${phone}`;

  const practiceKnowledge = `
VISION CARE CENTER INFORMATION:
- Hours: Monday-Friday 8:00 AM - 5:00 PM, Saturday 9:00 AM - 1:00 PM, Closed Sunday
- Address: 123 Vision Way, Suite 100, Dallas, TX 75201
- Phone: (555) 555-1234
- Services: Eye Exams, Contact Lenses, Glasses, LASIK Consultations
- Insurance: VSP, EyeMed, Spectera, Medicare, most major plans
- Pricing: Eye Exam $99-149, Contact Lens Exam $149-199
`;

  const conversationHistory = conversation.messages
    .slice(-6)
    .map(m => ({ role: m.role, content: m.content }));

  const systemPrompt = `You are Sarah, a friendly AI assistant for Vision Care Center responding via SMS.

${practiceKnowledge}

${patientContext}

RULES:
- Keep responses SHORT (under 160 characters when possible, max 300)
- Be warm and helpful
- Use patient's name (${patientName}) naturally
- For appointments, ask for preferred day/time
- For emergencies, tell them to call (555) 555-1234 or go to ER
- If they say YES/CONFIRM, acknowledge their confirmation
- If they want directions, give the address clearly
- End with a question or offer to help more

Current date: ${new Date().toLocaleDateString()}`;

  const aiResponse = await anthropic.messages.create({
    model: 'claude-3-5-haiku-20241022',
    max_tokens: 200,
    system: systemPrompt,
    messages: conversationHistory,
  });

  return aiResponse.content[0]?.text || "Thanks for your message! How can I help you today?";
}

/**
 * Handle SMS actions (send links, schedule, etc.)
 */
async function handleSMSActions(message, phone, conversation, client) {
  const lower = message.toLowerCase();
  const baseUrl = process.env.VITE_APP_URL || 'https://patientcare-teal.vercel.app';

  // Send directions link
  if (lower.includes('direction') || lower.includes('map') || lower.includes('where')) {
    setTimeout(async () => {
      await client.messages.create({
        body: "📍 Here's our location:\nhttps://maps.google.com/?q=123+Vision+Way+Suite+100+Dallas+TX+75201",
        to: phone,
        from: process.env.TWILIO_PHONE_NUMBER,
      });
    }, 2000);
  }

  // Send scheduling link
  if (lower.includes('book online') || lower.includes('schedule online')) {
    setTimeout(async () => {
      await client.messages.create({
        body: `📅 Book your appointment online:\n${baseUrl}/schedule`,
        to: phone,
        from: process.env.TWILIO_PHONE_NUMBER,
      });
    }, 2000);
  }
}

/**
 * Check if SMS message contains escalation triggers and save to Supabase
 */
async function checkSMSEscalation(message, phone, messageSid, conversation) {
  const lower = (message || '').toLowerCase();
  const escalationPhrases = [
    'manager', 'supervisor', 'complaint', 'speak to someone',
    'real person', 'human', 'unacceptable', 'lawyer', 'attorney',
    'sue', 'frustrated', 'ridiculous', 'terrible', 'escalate',
  ];

  const triggered = escalationPhrases.filter(p => lower.includes(p));
  if (triggered.length === 0) return;

  console.log('[SMS] Escalation triggered by:', triggered.join(', '));

  try {
    const db = getDb();

    // Build conversation transcript
    const transcript = conversation.messages
      .map(m => `${m.role === 'user' ? 'Patient' : 'AI'}: ${m.content}`)
      .join('\n');

    await db.from('call_enrichments').upsert({
      call_sid: `sms_${messageSid}`,
      transcript,
      from_phone: phone,
      direction: 'inbound',
      escalation_needed: true,
      escalation_reason: `SMS escalation: patient used "${triggered.join(', ')}"`,
      emotion: triggered.length >= 2 ? 'frustrated' : 'concerned',
      call_started_at: new Date().toISOString(),
    }, { onConflict: 'call_sid' });

    console.log('[SMS] Escalation saved to DB for:', phone);
  } catch (err) {
    console.error('[SMS] Failed to save escalation:', err.message);
  }
}

/**
 * Clean old conversations from memory
 */
function cleanOldConversations() {
  const now = Date.now();
  for (const [phone, conv] of conversations.entries()) {
    const lastMessage = conv.messages[conv.messages.length - 1];
    if (lastMessage && now - lastMessage.timestamp > CONVERSATION_TTL) {
      conversations.delete(phone);
    }
  }
}
