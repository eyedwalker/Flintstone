/**
 * Twilio Status Callback Handler - Vercel Serverless Function
 * 
 * Receives status updates for SMS and voice calls
 * Stores call recordings and transcripts
 */

// In-memory call log storage (use database in production)
// This is exported so other handlers can access it
export const callLogs = new Map();

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  try {
    const {
      MessageSid,
      CallSid,
      MessageStatus,
      CallStatus,
      From,
      To,
      ErrorCode,
      ErrorMessage,
      CallDuration,
      RecordingUrl,
      RecordingSid,
      RecordingDuration,
      TranscriptionText,
      TranscriptionStatus,
      Direction,
    } = req.body;

    const eventType = MessageSid ? 'SMS' : 'Voice';
    const sid = MessageSid || CallSid;
    const status = MessageStatus || CallStatus;

    console.log(`[Twilio Status] ${eventType} ${sid}: ${status}`, {
      from: From,
      to: To,
      duration: CallDuration,
      recording: RecordingUrl ? 'yes' : 'no',
      error: ErrorCode ? `${ErrorCode}: ${ErrorMessage}` : null,
    });

    // Store/update call log
    if (CallSid) {
      const existingLog = callLogs.get(CallSid) || {};
      const callLog = {
        ...existingLog,
        callSid: CallSid,
        from: From || existingLog.from,
        to: To || existingLog.to,
        direction: Direction || existingLog.direction,
        status: status,
        duration: CallDuration ? parseInt(CallDuration) : existingLog.duration,
        updatedAt: new Date().toISOString(),
      };

      // Add recording if present
      if (RecordingUrl) {
        callLog.recordingUrl = RecordingUrl;
        callLog.recordingSid = RecordingSid;
        callLog.recordingDuration = RecordingDuration ? parseInt(RecordingDuration) : null;
        console.log(`[Twilio Status] Recording saved for ${CallSid}:`, RecordingUrl);
      }

      // Add transcription if present
      if (TranscriptionText) {
        callLog.transcription = TranscriptionText;
        callLog.transcriptionStatus = TranscriptionStatus;
        console.log(`[Twilio Status] Transcription saved for ${CallSid}:`, TranscriptionText.substring(0, 100));
      }

      callLogs.set(CallSid, callLog);

      // Log completed calls
      if (status === 'completed') {
        console.log(`[Twilio Status] Call completed:`, {
          callSid: CallSid,
          from: From,
          to: To,
          duration: `${CallDuration}s`,
          hasRecording: !!callLog.recordingUrl,
          hasTranscript: !!callLog.transcription,
        });
      }
    }

    // Log errors for debugging
    if (ErrorCode) {
      console.error(`[Twilio Status] Error on ${eventType} ${sid}:`, {
        code: ErrorCode,
        message: ErrorMessage,
      });
    }

    return res.status(200).json({ received: true });

  } catch (error) {
    console.error('[Twilio Status] Error:', error);
    return res.status(200).json({ received: true, error: error.message });
  }
}

/**
 * Get call log by CallSid (exported for other handlers)
 */
export function getCallLog(callSid) {
  return callLogs.get(callSid);
}

/**
 * Get all call logs (exported for admin/reporting)
 */
export function getAllCallLogs() {
  return Array.from(callLogs.values());
}
