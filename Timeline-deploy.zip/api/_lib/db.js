/**
 * PostgreSQL Database Client for API Routes
 *
 * Drop-in replacement for @supabase/supabase-js createClient().
 * Provides the same fluent query builder API (.from().select().eq() etc.)
 * but executes against a direct PostgreSQL connection pool.
 *
 * Usage (same as Supabase):
 *   import { getDb } from '../_lib/db.js';
 *   const supabase = getDb();
 *   const { data, error } = await supabase.from('tablename').select('*').eq('id', someId);
 */

import pg from 'pg';
const { Pool } = pg;

// Connection pool singleton
let pool = null;

function getPool() {
  if (!pool) {
    const connectionString = process.env.DATABASE_URL;
    if (connectionString) {
      pool = new Pool({ connectionString, max: 20 });
    } else {
      // Fallback: construct from individual vars
      pool = new Pool({
        host: process.env.DB_HOST || 'db',
        port: parseInt(process.env.DB_PORT || '5432'),
        database: process.env.DB_NAME || 'eyefinity_prc',
        user: process.env.DB_USER || 'eyefinity_prc',
        password: process.env.DB_PASSWORD || process.env.PRC_DB_PASSWORD,
        max: 20,
      });
    }
  }
  return pool;
}

/**
 * Supabase-compatible query builder.
 * Supports: .select(), .insert(), .update(), .upsert(), .delete()
 * Filters: .eq(), .neq(), .gt(), .gte(), .lt(), .lte(), .in(), .is(), .or(), .ilike(), .like(), .match()
 * Result: .single(), .maybeSingle(), .limit(), .order(), .range()
 * Returns: { data, error, count }
 */
class QueryBuilder {
  constructor(table) {
    this._table = table;
    this._operation = 'select';
    this._columns = '*';
    this._filters = [];
    this._orFilters = [];
    this._orderClauses = [];
    this._limitVal = null;
    this._offsetVal = null;
    this._rangeFrom = null;
    this._rangeTo = null;
    this._singleRow = false;
    this._maybeSingle = false;
    this._insertData = null;
    this._updateData = null;
    this._upsertData = null;
    this._upsertConflict = null;
    this._countMode = null; // 'exact' or null
    this._headOnly = false;
  }

  // --- Operations ---

  select(columns, options) {
    this._operation = 'select';
    this._columns = columns || '*';
    if (options?.count === 'exact') this._countMode = 'exact';
    if (options?.head) this._headOnly = true;
    return this;
  }

  insert(data) {
    this._operation = 'insert';
    this._insertData = Array.isArray(data) ? data : [data];
    return this;
  }

  update(data) {
    this._operation = 'update';
    this._updateData = data;
    return this;
  }

  upsert(data, options) {
    this._operation = 'upsert';
    this._upsertData = Array.isArray(data) ? data : [data];
    this._upsertConflict = options?.onConflict || null;
    return this;
  }

  delete() {
    this._operation = 'delete';
    return this;
  }

  // --- Filters ---

  eq(column, value) {
    this._filters.push({ column, op: '=', value });
    return this;
  }

  neq(column, value) {
    this._filters.push({ column, op: '!=', value });
    return this;
  }

  gt(column, value) {
    this._filters.push({ column, op: '>', value });
    return this;
  }

  gte(column, value) {
    this._filters.push({ column, op: '>=', value });
    return this;
  }

  lt(column, value) {
    this._filters.push({ column, op: '<', value });
    return this;
  }

  lte(column, value) {
    this._filters.push({ column, op: '<=', value });
    return this;
  }

  in(column, values) {
    this._filters.push({ column, op: 'IN', value: values });
    return this;
  }

  is(column, value) {
    if (value === null) {
      this._filters.push({ column, op: 'IS NULL', value: null });
    } else {
      this._filters.push({ column, op: 'IS NOT NULL', value: null });
    }
    return this;
  }

  or(filterString) {
    // Supabase format: "col1.ilike.%val%,col2.ilike.%val%"
    this._orFilters.push(filterString);
    return this;
  }

  ilike(column, pattern) {
    this._filters.push({ column, op: 'ILIKE', value: pattern });
    return this;
  }

  like(column, pattern) {
    this._filters.push({ column, op: 'LIKE', value: pattern });
    return this;
  }

  match(filterObj) {
    for (const [key, value] of Object.entries(filterObj)) {
      this._filters.push({ column: key, op: '=', value });
    }
    return this;
  }

  // --- Result Modifiers ---

  order(column, options) {
    const dir = options?.ascending === false ? 'DESC' : (options?.ascending === true ? 'ASC' : 'DESC');
    this._orderClauses.push(`"${column}" ${dir}`);
    return this;
  }

  limit(n) {
    this._limitVal = n;
    return this;
  }

  range(from, to) {
    this._rangeFrom = from;
    this._rangeTo = to;
    return this;
  }

  single() {
    this._singleRow = true;
    this._limitVal = 1;
    return this;
  }

  maybeSingle() {
    this._maybeSingle = true;
    this._limitVal = 1;
    return this;
  }

  // --- Execution (via .then() for await compatibility) ---

  then(resolve, reject) {
    this._execute().then(resolve, reject);
  }

  async _execute() {
    const pool = getPool();
    try {
      switch (this._operation) {
        case 'select': return await this._execSelect(pool);
        case 'insert': return await this._execInsert(pool);
        case 'update': return await this._execUpdate(pool);
        case 'upsert': return await this._execUpsert(pool);
        case 'delete': return await this._execDelete(pool);
        default: return { data: null, error: new Error(`Unknown operation: ${this._operation}`) };
      }
    } catch (err) {
      return { data: null, error: err, count: null };
    }
  }

  // --- Build WHERE clause ---

  _buildWhere(params) {
    const conditions = [];

    for (const f of this._filters) {
      if (f.op === 'IS NULL') {
        conditions.push(`"${f.column}" IS NULL`);
      } else if (f.op === 'IS NOT NULL') {
        conditions.push(`"${f.column}" IS NOT NULL`);
      } else if (f.op === 'IN') {
        const placeholders = f.value.map((_, i) => `$${params.length + i + 1}`).join(', ');
        params.push(...f.value);
        conditions.push(`"${f.column}" IN (${placeholders})`);
      } else {
        params.push(f.value);
        conditions.push(`"${f.column}" ${f.op} $${params.length}`);
      }
    }

    // Handle OR filters (Supabase format: "col.op.val,col.op.val")
    for (const orStr of this._orFilters) {
      const parts = this._parseOrFilter(orStr, params);
      if (parts.length > 0) {
        conditions.push(`(${parts.join(' OR ')})`);
      }
    }

    return conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
  }

  _parseOrFilter(filterString, params) {
    const parts = [];
    // Split by comma but respect values that might contain commas
    const segments = filterString.split(',');

    for (const seg of segments) {
      // Format: column.operator.value
      const match = seg.match(/^(\w+)\.(eq|neq|gt|gte|lt|lte|ilike|like|is)\.(.+)$/);
      if (match) {
        const [, col, op, val] = match;
        const sqlOp = { eq: '=', neq: '!=', gt: '>', gte: '>=', lt: '<', lte: '<=', ilike: 'ILIKE', like: 'LIKE', is: 'IS' }[op];
        if (op === 'is' && val === 'null') {
          parts.push(`"${col}" IS NULL`);
        } else {
          params.push(val);
          parts.push(`"${col}" ${sqlOp} $${params.length}`);
        }
      }
    }
    return parts;
  }

  _buildOrderLimit() {
    let sql = '';
    if (this._orderClauses.length > 0) {
      sql += ` ORDER BY ${this._orderClauses.join(', ')}`;
    }
    if (this._rangeFrom !== null && this._rangeTo !== null) {
      sql += ` LIMIT ${this._rangeTo - this._rangeFrom + 1} OFFSET ${this._rangeFrom}`;
    } else {
      if (this._limitVal !== null) sql += ` LIMIT ${this._limitVal}`;
      if (this._offsetVal !== null) sql += ` OFFSET ${this._offsetVal}`;
    }
    return sql;
  }

  // --- Parse select columns (handle joins simply) ---

  _parseSelectColumns() {
    // For simple selects, just use the column spec
    // Complex joins (table(*)) are handled as separate queries
    if (this._columns === '*') return '*';
    // Strip join syntax for now — just select from main table
    const cols = this._columns.split(',')
      .map(c => c.trim())
      .filter(c => !c.includes('('))
      .map(c => c === '*' ? '*' : `"${c}"`);
    return cols.length > 0 ? cols.join(', ') : '*';
  }

  async _execSelect(pool) {
    const params = [];
    const columns = this._parseSelectColumns();
    const where = this._buildWhere(params);
    const orderLimit = this._buildOrderLimit();

    let sql = `SELECT ${columns} FROM "${this._table}" ${where} ${orderLimit}`;

    // Count query
    let count = null;
    if (this._countMode === 'exact') {
      const countParams = [...params.slice(0, this._filters.length + this._orFilters.length)];
      // Rebuild where for count
      const countParamsNew = [];
      const countWhere = this._buildWhereForCount(countParamsNew);
      const countResult = await pool.query(`SELECT COUNT(*) FROM "${this._table}" ${countWhere}`, countParamsNew);
      count = parseInt(countResult.rows[0].count);

      if (this._headOnly) {
        return { data: null, error: null, count };
      }
    }

    const result = await pool.query(sql, params);

    let data = result.rows;
    if (this._singleRow) {
      if (data.length === 0) {
        return { data: null, error: { code: 'PGRST116', message: 'Row not found' }, count };
      }
      data = data[0];
    } else if (this._maybeSingle) {
      data = data.length > 0 ? data[0] : null;
    }

    return { data, error: null, count };
  }

  _buildWhereForCount(params) {
    // Rebuild WHERE without order/limit params
    const conditions = [];
    for (const f of this._filters) {
      if (f.op === 'IS NULL') {
        conditions.push(`"${f.column}" IS NULL`);
      } else if (f.op === 'IS NOT NULL') {
        conditions.push(`"${f.column}" IS NOT NULL`);
      } else if (f.op === 'IN') {
        const placeholders = f.value.map((_, i) => `$${params.length + i + 1}`).join(', ');
        params.push(...f.value);
        conditions.push(`"${f.column}" IN (${placeholders})`);
      } else {
        params.push(f.value);
        conditions.push(`"${f.column}" ${f.op} $${params.length}`);
      }
    }
    for (const orStr of this._orFilters) {
      const parts = this._parseOrFilter(orStr, params);
      if (parts.length > 0) {
        conditions.push(`(${parts.join(' OR ')})`);
      }
    }
    return conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
  }

  async _execInsert(pool) {
    const results = [];
    for (const row of this._insertData) {
      const keys = Object.keys(row);
      const values = Object.values(row);
      const placeholders = keys.map((_, i) => `$${i + 1}`).join(', ');
      const cols = keys.map(k => `"${k}"`).join(', ');

      const sql = `INSERT INTO "${this._table}" (${cols}) VALUES (${placeholders}) RETURNING *`;
      const result = await pool.query(sql, values);
      results.push(...result.rows);
    }

    // If chained with .select(), return data
    let data = results;
    if (this._singleRow) {
      data = results[0] || null;
    }
    return { data, error: null, count: results.length };
  }

  async _execUpdate(pool) {
    const params = [];
    const setClauses = [];

    for (const [key, value] of Object.entries(this._updateData)) {
      params.push(value);
      setClauses.push(`"${key}" = $${params.length}`);
    }

    const where = this._buildWhere(params);
    const sql = `UPDATE "${this._table}" SET ${setClauses.join(', ')} ${where} RETURNING *`;
    const result = await pool.query(sql, params);

    let data = result.rows;
    if (this._singleRow) {
      data = data[0] || null;
    }
    return { data, error: null, count: result.rowCount };
  }

  async _execUpsert(pool) {
    const results = [];
    for (const row of this._upsertData) {
      const keys = Object.keys(row);
      const values = Object.values(row);
      const placeholders = keys.map((_, i) => `$${i + 1}`).join(', ');
      const cols = keys.map(k => `"${k}"`).join(', ');

      let conflictClause = '';
      if (this._upsertConflict) {
        const conflictCols = this._upsertConflict.split(',').map(c => `"${c.trim()}"`).join(', ');
        const updateCols = keys
          .filter(k => !this._upsertConflict.split(',').map(c => c.trim()).includes(k))
          .map(k => `"${k}" = EXCLUDED."${k}"`)
          .join(', ');
        conflictClause = `ON CONFLICT (${conflictCols}) DO UPDATE SET ${updateCols}`;
      } else {
        // Default: conflict on id
        const updateCols = keys
          .filter(k => k !== 'id')
          .map(k => `"${k}" = EXCLUDED."${k}"`)
          .join(', ');
        conflictClause = `ON CONFLICT (id) DO UPDATE SET ${updateCols}`;
      }

      const sql = `INSERT INTO "${this._table}" (${cols}) VALUES (${placeholders}) ${conflictClause} RETURNING *`;
      const result = await pool.query(sql, values);
      results.push(...result.rows);
    }

    let data = results;
    if (this._singleRow) {
      data = results[0] || null;
    }
    return { data, error: null, count: results.length };
  }

  async _execDelete(pool) {
    const params = [];
    const where = this._buildWhere(params);
    const sql = `DELETE FROM "${this._table}" ${where}`;
    const result = await pool.query(sql, params);
    return { data: null, error: null, count: result.rowCount };
  }
}

/**
 * Supabase-compatible database client.
 * Usage: const supabase = getDb(); supabase.from('table').select('*')...
 */
class PgSupabaseClient {
  from(table) {
    return new QueryBuilder(table);
  }

  async rpc(funcName, params) {
    const pool = getPool();
    try {
      if (funcName === 'set_tenant_context') {
        await pool.query(`SELECT set_tenant_context($1::uuid)`, [params.account_id || params.p_account_id]);
        return { data: null, error: null };
      } else if (funcName === 'exec_sql') {
        const result = await pool.query(params.query);
        return { data: result.rows, error: null };
      } else {
        // Generic RPC call
        const argNames = Object.keys(params || {});
        const argValues = Object.values(params || {});
        const placeholders = argNames.map((_, i) => `$${i + 1}`).join(', ');
        const sql = `SELECT * FROM ${funcName}(${placeholders})`;
        const result = await pool.query(sql, argValues);
        return { data: result.rows, error: null };
      }
    } catch (err) {
      return { data: null, error: err };
    }
  }
}

// Singleton client
let client = null;

/**
 * Get the database client (drop-in replacement for Supabase createClient())
 */
export function getDb() {
  if (!client) {
    client = new PgSupabaseClient();
  }
  return client;
}

/**
 * Get the raw pg Pool (for advanced queries)
 */
export { getPool };

/**
 * Get a dedicated client from the pool (for transaction-scoped tenant context).
 * Caller MUST release the client when done: client.release()
 */
export async function getPoolClient() {
  return getPool().connect();
}

export default { getDb, getPool, getPoolClient };
