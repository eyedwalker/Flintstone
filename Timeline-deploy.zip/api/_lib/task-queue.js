import { Redis } from '@upstash/redis';

const TASK_QUEUE_KEY = 'timeline:tasks:queue';
const TASK_SCHEDULED_KEY = 'timeline:tasks:scheduled';
const TASK_HISTORY_KEY = 'timeline:tasks:history';
const MAX_HISTORY_ITEMS = 500;

let redisClient = null;

function ensureEnv(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing required env var: ${name}`);
  }
  return value;
}

export function getRedis() {
  if (!redisClient) {
    const url = ensureEnv('KV_REST_API_URL');
    const token = ensureEnv('KV_REST_API_TOKEN');
    redisClient = new Redis({ url, token });
  }
  return redisClient;
}

function serializeJob(job) {
  return JSON.stringify(job);
}

function deserializeJob(raw) {
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (err) {
    console.warn('[TaskQueue] Failed to parse job payload', err);
    return null;
  }
}

export async function enqueueJob(job) {
  const redis = getRedis();
  const payload = serializeJob({
    id: job.id || `job_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    attempts: job.attempts ?? 0,
    maxAttempts: job.maxAttempts ?? 5,
    createdAt: job.createdAt || new Date().toISOString(),
    lastError: job.lastError || null,
    type: job.type,
    payload: job.payload || {},
    runAt: job.runAt || Date.now(),
  });
  await redis.rpush(TASK_QUEUE_KEY, payload);
  return JSON.parse(payload);
}

export async function scheduleJob(job, runAtMs) {
  const redis = getRedis();
  const payload = serializeJob({
    id: job.id || `job_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    attempts: job.attempts ?? 0,
    maxAttempts: job.maxAttempts ?? 5,
    createdAt: job.createdAt || new Date().toISOString(),
    lastError: job.lastError || null,
    type: job.type,
    payload: job.payload || {},
    runAt: runAtMs,
  });
  await redis.zadd(TASK_SCHEDULED_KEY, { score: runAtMs, member: payload });
  return JSON.parse(payload);
}

export async function moveDueScheduledJobs(limit = 100) {
  const redis = getRedis();
  const now = Date.now();
  const due = await redis.zrangebyscore(TASK_SCHEDULED_KEY, 0, now, {
    limit: { offset: 0, count: limit },
  });

  if (!due.length) return 0;

  const pipeline = redis.multi();
  for (const job of due) {
    pipeline.rpush(TASK_QUEUE_KEY, job);
    pipeline.zrem(TASK_SCHEDULED_KEY, job);
  }
  await pipeline.exec();
  return due.length;
}

export async function dequeueJobs(batchSize = 10) {
  const redis = getRedis();
  if (batchSize <= 0) return [];
  const raw = await redis.lpop(TASK_QUEUE_KEY, batchSize);
  if (!raw) return [];
  const entries = Array.isArray(raw) ? raw : [raw];
  return entries.map(deserializeJob).filter(Boolean);
}

export async function requeueJob(job, delayMs = 0) {
  if (delayMs <= 0) {
    return enqueueJob(job);
  }
  return scheduleJob(job, Date.now() + delayMs);
}

export async function recordJobResult(result) {
  const redis = getRedis();
  try {
    await redis.lpush(
      TASK_HISTORY_KEY,
      JSON.stringify({
        ...result,
        recordedAt: new Date().toISOString(),
      })
    );
    await redis.ltrim(TASK_HISTORY_KEY, 0, MAX_HISTORY_ITEMS - 1);
  } catch (err) {
    console.warn('[TaskQueue] Failed to record job result', err);
  }
}

export async function getQueueStats() {
  const redis = getRedis();
  const [queueLength, scheduledLength, nextJobRaw, nextScheduledRaw] = await redis.multi()
    .llen(TASK_QUEUE_KEY)
    .zcard(TASK_SCHEDULED_KEY)
    .lindex(TASK_QUEUE_KEY, 0)
    .zrange(TASK_SCHEDULED_KEY, 0, 0)
    .exec();

  return {
    queueLength: queueLength?.result ?? queueLength ?? 0,
    scheduledLength: scheduledLength?.result ?? scheduledLength ?? 0,
    nextJob: deserializeJob(nextJobRaw?.result ?? nextJobRaw ?? null),
    nextScheduled: deserializeJob(
      Array.isArray(nextScheduledRaw?.result)
        ? nextScheduledRaw.result[0]
        : nextScheduledRaw?.result ?? nextScheduledRaw ?? null
    ),
  };
}

export const TaskQueueKeys = {
  TASK_QUEUE_KEY,
  TASK_SCHEDULED_KEY,
  TASK_HISTORY_KEY,
};
