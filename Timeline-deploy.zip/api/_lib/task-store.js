import { v4 as uuidv4 } from 'uuid';
import { getRedis } from './task-queue.js';

const TASK_DATA_KEY = 'timeline:tasks:data';
const TASK_ACTIVITY_KEY = 'timeline:tasks:activity';

function serializeTask(task) {
  return JSON.stringify(task);
}

function deserializeTask(raw, taskId) {
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (error) {
    console.warn('[TaskStore] Failed to parse task payload', { taskId, error: error?.message || String(error) });
    return null;
  }
}

function withDefaults(data) {
  const now = new Date().toISOString();
  return {
    id: data.id || uuidv4(),
    title: data.title || 'Untitled Task',
    description: data.description || '',
    status: data.status || 'pending',
    priority: data.priority || 'normal',
    category: data.category || 'general',
    source: data.source || { type: 'manual' },
    channel: data.channel || 'internal',
    dueAt: data.dueAt || null,
    assignee: data.assignee || null,
    assignedToOffice: data.assignedToOffice || null,
    createdBy: data.createdBy || null,
    createdByName: data.createdByName || 'Unknown',
    metadata: data.metadata || {},
    createdAt: data.createdAt || now,
    updatedAt: now,
  };
}

export async function createTask(data) {
  const redis = getRedis();
  const task = withDefaults(data);
  await redis.hset(TASK_DATA_KEY, task.id, serializeTask(task));
  await recordTaskActivity(task.id, {
    event: 'created',
    status: task.status,
    detail: data.auditDetail || 'Task created via API',
  });
  return task;
}

export async function updateTask(id, updates) {
  const redis = getRedis();
  const existingRaw = await redis.hget(TASK_DATA_KEY, id);
  if (!existingRaw) {
    throw new Error(`Task ${id} not found`);
  }
  const existing = deserializeTask(existingRaw, id);
  if (!existing) {
    // Corrupted record in Redis (e.g., empty/partial JSON). Purge so it doesn't break future reads.
    await redis.hdel(TASK_DATA_KEY, id);
    throw new Error(`Task ${id} is corrupted and was removed`);
  }
  const updated = {
    ...existing,
    ...updates,
    updatedAt: new Date().toISOString(),
  };
  await redis.hset(TASK_DATA_KEY, id, serializeTask(updated));
  await recordTaskActivity(id, {
    event: 'updated',
    status: updated.status,
    detail: updates.auditDetail || 'Task updated via API',
  });
  return updated;
}

export async function getTask(id) {
  const redis = getRedis();
  const raw = await redis.hget(TASK_DATA_KEY, id);
  return deserializeTask(raw, id);
}

export async function listTasks() {
  const redis = getRedis();
  const entries = await redis.hgetall(TASK_DATA_KEY);
  if (!entries) return [];
  const tasks = [];
  const corruptedIds = [];

  for (const [taskId, raw] of Object.entries(entries)) {
    const parsed = deserializeTask(raw, taskId);
    if (parsed) {
      tasks.push(parsed);
    } else {
      corruptedIds.push(taskId);
    }
  }

  if (corruptedIds.length) {
    try {
      await redis.hdel(TASK_DATA_KEY, ...corruptedIds);
      console.warn('[TaskStore] Removed corrupted task entries', { count: corruptedIds.length });
    } catch (e) {
      console.warn('[TaskStore] Failed to remove corrupted task entries', { count: corruptedIds.length, error: e?.message || String(e) });
    }
  }

  return tasks.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
}

export async function recordTaskActivity(taskId, activity) {
  const redis = getRedis();
  const entry = {
    id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    taskId,
    ...activity,
    timestamp: new Date().toISOString(),
  };
  await redis.lpush(TASK_ACTIVITY_KEY, JSON.stringify(entry));
  await redis.ltrim(TASK_ACTIVITY_KEY, 0, 999);
  return entry;
}

export async function getTaskActivity(taskId) {
  const redis = getRedis();
  const entries = await redis.lrange(TASK_ACTIVITY_KEY, 0, 500);
  return entries
    .map((raw) => {
      try {
        return JSON.parse(raw);
      } catch (error) {
        return null;
      }
    })
    .filter((entry) => entry && (!taskId || entry.taskId === taskId));
}

export const TaskStoreKeys = {
  TASK_DATA_KEY,
  TASK_ACTIVITY_KEY,
};
