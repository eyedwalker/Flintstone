/**
 * Auth Middleware — Reusable session validator for API routes
 *
 * Extracts the Bearer token from the Authorization header,
 * looks up the session in Redis, and returns user context.
 */

import { kv } from './kv.js';

/**
 * Validate session from request and return user context.
 * @param {import('express').Request} req
 * @returns {Promise<{ userId: string, email: string, accountId: string|null, role: string|null }>}
 * @throws {{ status: number, message: string }} on auth failure
 */
export async function validateSession(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    throw { status: 401, message: 'Missing or invalid Authorization header' };
  }

  const token = authHeader.slice(7);
  if (!token) {
    throw { status: 401, message: 'Empty token' };
  }

  const sessionData = await kv.get(`session:${token}`);
  if (!sessionData) {
    throw { status: 401, message: 'Invalid or expired session' };
  }

  const session = typeof sessionData === 'string' ? JSON.parse(sessionData) : sessionData;

  return {
    userId: session.userId,
    email: session.email,
    accountId: session.accountId || null,
    role: session.role || null,
  };
}
