/**
 * Shared Eyefinity OAuth Authentication Module
 *
 * Extracted from the main Eyefinity proxy to be reused by:
 * - api/eyefinity/[...path].js (EPM API proxy)
 * - api/schedule-manager/[...path].js (Schedule Manager API proxy)
 *
 * Implements OAuth 2.0 Token Exchange flow with dual-layer caching (Redis + memory).
 */

import { kv } from './kv.js';
import { getDb } from './db.js';

// Initialize database client (singleton via getDb)
export function getSupabase() {
  return getDb();
}

// Redis via local kv adapter (drop-in replacement for @upstash/redis)
export function getRedis() {
  return kv;
}

/**
 * Fetch company credentials from database
 */
export async function getCompanyCredentials(companyId) {
  const supabase = getSupabase();

  // If no companyId, default to EyeCare 4 U (the only active company with OAuth credentials)
  if (!companyId) {
    try {
      const { data: defaultCompany } = await supabase
        .from('companies')
        .select('id')
        .eq('name', 'EyeCare 4 U')
        .single();
      if (defaultCompany?.id) {
        console.log(`[Eyefinity] No companyId provided, defaulting to EyeCare 4 U: ${defaultCompany.id}`);
        companyId = defaultCompany.id;
      }
    } catch (e) {
      // Fall through to env var defaults
    }
  }

  if (!companyId) {
    return {
      clientId: process.env.EPM_CLIENT_ID,
      clientSecret: process.env.EPM_CLIENT_SECRET,
      tenantUid: process.env.TENANT_UID,
      oauthHost: process.env.OAUTH_HOST || 'api-sandbox.eyefinity.com',
      apiBaseUrl: process.env.EYEFINITY_API_URL || 'https://api-sandbox.eyefinity.com',
      apiPath: process.env.EYEFINITY_API_PATH || 'al-pe',
      useStaticToken: false,
      staticToken: null,
    };
  }

  try {
    const { data, error } = await supabase
      .from('companies')
      .select('eyefinity_api_key, eyefinity_api_secret, tenant_uid, oauth_host, api_base_url, api_path, oauth_token')
      .eq('id', companyId)
      .single();

    if (error || !data) {
      console.warn('[Eyefinity] Failed to fetch company credentials, falling back to env vars');
      return {
        clientId: process.env.EPM_CLIENT_ID,
        clientSecret: process.env.EPM_CLIENT_SECRET,
        tenantUid: process.env.TENANT_UID,
        oauthHost: process.env.OAUTH_HOST || 'api-sandbox.eyefinity.com',
        apiBaseUrl: process.env.EYEFINITY_API_URL || 'https://api-sandbox.eyefinity.com',
        apiPath: process.env.EYEFINITY_API_PATH || 'al-pe',
        useStaticToken: false,
        staticToken: null,
      };
    }

    const useStaticToken = !data.eyefinity_api_key && data.oauth_token;

    return {
      clientId: data.eyefinity_api_key || process.env.EPM_CLIENT_ID,
      clientSecret: data.eyefinity_api_secret || process.env.EPM_CLIENT_SECRET,
      tenantUid: data.tenant_uid || process.env.TENANT_UID,
      oauthHost: data.oauth_host || process.env.OAUTH_HOST || 'api-sandbox.eyefinity.com',
      apiBaseUrl: data.api_base_url || process.env.EYEFINITY_API_URL || 'https://api-sandbox.eyefinity.com',
      apiPath: data.api_path || process.env.EYEFINITY_API_PATH || 'al-pe',
      useStaticToken,
      staticToken: useStaticToken ? data.oauth_token : null,
    };
  } catch (e) {
    console.error('[Eyefinity] Error fetching company credentials:', e);
    return {
      clientId: process.env.EPM_CLIENT_ID,
      clientSecret: process.env.EPM_CLIENT_SECRET,
      tenantUid: process.env.TENANT_UID,
      oauthHost: process.env.OAUTH_HOST || 'api-sandbox.eyefinity.com',
      apiBaseUrl: process.env.EYEFINITY_API_URL || 'https://api-sandbox.eyefinity.com',
      apiPath: process.env.EYEFINITY_API_PATH || 'al-pe',
      useStaticToken: false,
      staticToken: null,
    };
  }
}

// Full scopes for EPM API access (includes Schedule Manager)
const EPM_SCOPES = [
  'auth_epm',
  'ef.pm_pe_patient_rx',
  'ef.pm_pe_resource',
  'ef.pm_pe_insurance',
  'ef.pm_pe_appointment',
  'ef.pm_pe_office_recallreport',
  'ef.pm_pe_staff',
  'ef.pm_pe_office',
  'ef.pm_pe_company',
  'ef.pm_pe_order',
  'ef.pm_pe_provider',
  'ef.pm_pe_patient',
  'read:ef.pm_schedule',
].join(' ');

// In-memory token cache (per-company) and deduplication
const memoryTokens = new Map();
let authFailCount = 0;
const tokenFetchPromises = new Map();

/**
 * Get cached token from Redis or memory (per-company)
 */
export async function getCachedToken(companyId = 'default') {
  const cacheKey = `eyefinity:epm_token:${companyId}`;

  const memEntry = memoryTokens.get(companyId);
  if (memEntry && memEntry.expiry && Date.now() < memEntry.expiry) {
    console.log(`[OAuth] Using memory-cached token for company ${companyId}`);
    return memEntry.token;
  }

  const redis = getRedis();
  if (redis) {
    try {
      const cached = await redis.get(cacheKey);
      if (cached) {
        console.log(`[OAuth] Using Redis-cached token for company ${companyId}`);
        memoryTokens.set(companyId, {
          token: cached,
          expiry: Date.now() + 25 * 60 * 1000
        });
        return cached;
      }
    } catch (e) {
      console.warn('[OAuth] Redis read failed:', e.message);
    }
  }

  return null;
}

/**
 * Store token in Redis and memory (per-company)
 */
export async function cacheToken(token, expiresIn, companyId = 'default') {
  const ttl = expiresIn - 300;
  const cacheKey = `eyefinity:epm_token:${companyId}`;

  memoryTokens.set(companyId, {
    token,
    expiry: Date.now() + ttl * 1000
  });

  const redis = getRedis();
  if (redis) {
    try {
      await redis.setex(cacheKey, ttl, token);
      console.log(`[OAuth] Token cached in Redis for company ${companyId} (TTL: ${ttl}s)`);
    } catch (e) {
      console.warn('[OAuth] Redis write failed:', e.message);
    }
  } else {
    console.log(`[OAuth] Token cached in memory only for company ${companyId} (TTL: ${ttl}s)`);
  }
}

/**
 * Invalidate cached token (forces refresh on next request)
 */
export async function invalidateCachedToken(companyId = 'default') {
  const cacheKey = `eyefinity:epm_token:${companyId}`;
  memoryTokens.delete(companyId);

  const redis = getRedis();
  if (redis) {
    try {
      await redis.del(cacheKey);
      console.log(`[OAuth] Redis token invalidated for company ${companyId}`);
    } catch (e) {
      console.warn('[OAuth] Redis delete failed:', e.message);
    }
  }
}

/**
 * Step 1: Get Client Credentials Token
 */
async function getClientCredentialsToken(creds) {
  const { clientId, clientSecret, oauthHost } = creds;

  if (!clientId || !clientSecret) {
    throw new Error('OAuth credentials not configured');
  }

  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  const body = `grant_type=client_credentials&scope=${encodeURIComponent(EPM_SCOPES)}`;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);

  try {
    const response = await fetch(`https://${oauthHost}/as/token.oauth2`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Client credentials failed: ${response.status} - ${error}`);
    }

    const data = await response.json();
    return data.access_token || data.accesstoken;
  } catch (e) {
    clearTimeout(timeoutId);
    if (e.name === 'AbortError') {
      throw new Error('OAuth timeout - sandbox server unreachable');
    }
    throw e;
  }
}

/**
 * Step 2: Token Exchange for EPM Token
 */
async function exchangeToken(ccToken, creds) {
  const { clientId, clientSecret, tenantUid, oauthHost } = creds;

  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  const body = new URLSearchParams({
    'grant_type': 'urn:ietf:params:oauth:grant-type:token-exchange',
    'subject_token': ccToken,
    'subject_token_type': 'urn:ietf:params:oauth:token-type:access_token',
    'scope': EPM_SCOPES,
    'resource': 'https://VspEpmToken',
  }).toString();

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);

  try {
    const response = await fetch(`https://${oauthHost}/as/token.oauth2`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'tenantuid': tenantUid || '',
      },
      body,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Token exchange failed: ${response.status} - ${error}`);
    }

    const data = await response.json();
    return {
      token: data.access_token || data.accesstoken,
      expiresIn: data.expires_in || 1799,
    };
  } catch (e) {
    clearTimeout(timeoutId);
    if (e.name === 'AbortError') {
      throw new Error('Token exchange timeout');
    }
    throw e;
  }
}

/**
 * Get valid EPM token (cached or fresh OAuth)
 */
export async function getEpmToken(companyId, creds) {
  if (creds.useStaticToken && creds.staticToken) {
    console.log(`[Eyefinity] Using static bearer token for company ${companyId}`);
    return creds.staticToken;
  }

  const cached = await getCachedToken(companyId);
  if (cached) {
    return cached;
  }

  const existingPromise = tokenFetchPromises.get(companyId);
  if (existingPromise) {
    return await existingPromise;
  }

  const fetchPromise = (async () => {
    console.log(`[OAuth] Fetching new token for company ${companyId}...`);

    try {
      const ccToken = await getClientCredentialsToken(creds);
      const { token, expiresIn } = await exchangeToken(ccToken, creds);
      await cacheToken(token, expiresIn, companyId);
      authFailCount = 0;
      console.log(`[OAuth] Token obtained successfully for company ${companyId}`);
      return token;
    } catch (error) {
      authFailCount++;
      console.error(`[OAuth] Auth failed for company ${companyId} (attempt ${authFailCount}):`, error.message);
      throw error;
    } finally {
      tokenFetchPromises.delete(companyId);
    }
  })();

  tokenFetchPromises.set(companyId, fetchPromise);
  return await fetchPromise;
}
