/**
 * Redis KV Client — Drop-in replacement for @vercel/kv
 *
 * Provides the same API surface used by the auth routes:
 *   kv.get, kv.set, kv.del, kv.setex,
 *   kv.hgetall, kv.hset,
 *   kv.sadd, kv.smembers, kv.srem,
 *   kv.keys
 *
 * Uses ioredis for the connection to a local/networked Redis instance.
 */

import Redis from 'ioredis';

const REDIS_URL = process.env.REDIS_URL || 'redis://127.0.0.1:6379';

let redis = null;

function getRedis() {
  if (!redis) {
    redis = new Redis(REDIS_URL, {
      maxRetriesPerRequest: 3,
      lazyConnect: true,
    });
    redis.connect().catch(err => {
      console.error('[KV] Redis connection error:', err.message);
    });
  }
  return redis;
}

/**
 * Vercel KV-compatible wrapper around ioredis.
 * Vercel KV auto-serializes values to JSON; we replicate that behavior.
 */
export const kv = {
  // --- String commands (auto JSON serialize/deserialize) ---

  async get(key) {
    const val = await getRedis().get(key);
    if (val === null) return null;
    try { return JSON.parse(val); } catch { return val; }
  },

  async set(key, value) {
    const serialized = typeof value === 'string' ? value : JSON.stringify(value);
    await getRedis().set(key, serialized);
  },

  async setex(key, seconds, value) {
    const serialized = typeof value === 'string' ? value : JSON.stringify(value);
    await getRedis().setex(key, seconds, serialized);
  },

  async del(key) {
    await getRedis().del(key);
  },

  // --- Hash commands ---

  async hgetall(key) {
    const data = await getRedis().hgetall(key);
    if (!data || Object.keys(data).length === 0) return null;
    // Vercel KV auto-deserializes hash values
    const result = {};
    for (const [k, v] of Object.entries(data)) {
      try { result[k] = JSON.parse(v); } catch { result[k] = v; }
    }
    return result;
  },

  async hset(key, obj) {
    const r = getRedis();
    const pairs = [];
    for (const [k, v] of Object.entries(obj)) {
      pairs.push(k, v === null || v === undefined ? 'null' : typeof v === 'object' ? JSON.stringify(v) : String(v));
    }
    if (pairs.length > 0) {
      await r.hset(key, ...pairs);
    }
  },

  // --- Set commands ---

  async sadd(key, ...members) {
    await getRedis().sadd(key, ...members);
  },

  async smembers(key) {
    return await getRedis().smembers(key);
  },

  async srem(key, ...members) {
    await getRedis().srem(key, ...members);
  },

  // --- Key scanning ---

  async keys(pattern) {
    return await getRedis().keys(pattern);
  },
};

export default kv;
