/**
 * Schedule Manager API Proxy - Vercel Serverless Function
 *
 * Routes requests to the Eyefinity Schedule Manager API at:
 *   api-sandbox.eyefinity.com/al.sbox-hosting-schedulemanager
 *
 * Uses the same OAuth tokens as the main EPM proxy (shared auth module).
 * Key endpoint: POST /offices/{officeId}/appointmentSlots
 *   - Searches available appointment slots across all providers at once
 */

import { getCompanyCredentials, getEpmToken, invalidateCachedToken } from '../_lib/eyefinity-auth.js';

// Schedule Manager API base URL (sandbox)
const SCHEDULE_MANAGER_BASE = process.env.SCHEDULE_MANAGER_BASE_URL
  || 'https://api-sandbox.eyefinity.com/al.sbox-hosting-schedulemanager';

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Auth-Token, Authorization, X-Company-Id');

  // Handle OPTIONS preflight
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    // Get company ID from header
    const companyId = req.headers['x-company-id'] || 'default';

    // Fetch credentials (same OAuth creds as EPM)
    const creds = await getCompanyCredentials(companyId !== 'default' ? companyId : null);

    // Get the path segments after /api/schedule-manager/
    const pathParam = req.query['...path'];
    const pathString = Array.isArray(pathParam) ? pathParam.join('/') : pathParam || '';

    // Get other query params (exclude the path param)
    const otherParams = { ...req.query };
    delete otherParams['...path'];

    // Build query string
    const filteredParams = new URLSearchParams();
    for (const [key, value] of Object.entries(otherParams)) {
      if (Array.isArray(value)) {
        value.forEach(v => filteredParams.append(key, v));
      } else {
        filteredParams.append(key, value);
      }
    }
    const queryString = filteredParams.toString() ? `?${filteredParams.toString()}` : '';

    // Build target URL for Schedule Manager API
    const targetUrl = `${SCHEDULE_MANAGER_BASE}/${pathString}${queryString}`;

    console.log('[Schedule Manager Proxy] Request:', {
      method: req.method,
      companyId,
      path: pathString,
      target: targetUrl,
    });

    // Get OAuth token (shared cache with EPM proxy)
    const authToken = await getEpmToken(companyId, creds);

    // Forward the request
    const fetchOptions = {
      method: req.method,
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    };

    // Include body for non-GET requests
    if (req.method !== 'GET' && req.method !== 'HEAD' && req.body) {
      fetchOptions.body = JSON.stringify(req.body);
    }

    const response = await fetch(targetUrl, fetchOptions);

    console.log('[Schedule Manager Proxy] Response:', response.status);

    // Handle 401 - invalidate cache and retry once
    if (response.status === 401) {
      console.log(`[Schedule Manager Proxy] Token expired for company ${companyId}, refreshing...`);
      await invalidateCachedToken(companyId);

      const newToken = await getEpmToken(companyId, creds);

      const retryOptions = {
        method: req.method,
        headers: {
          'Authorization': `Bearer ${newToken}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      };

      if (req.method !== 'GET' && req.method !== 'HEAD' && req.body) {
        retryOptions.body = JSON.stringify(req.body);
      }

      const retryResponse = await fetch(targetUrl, retryOptions);
      const retryData = await retryResponse.json().catch(() => retryResponse.text());
      return res.status(retryResponse.status).json(retryData);
    }

    // Parse response
    const contentType = response.headers.get('content-type');
    let data;

    try {
      if (contentType?.includes('application/json')) {
        data = await Promise.race([
          response.json(),
          new Promise((_, reject) => setTimeout(() => reject(new Error('Response parse timeout')), 5000))
        ]);
      } else {
        data = await Promise.race([
          response.text(),
          new Promise((_, reject) => setTimeout(() => reject(new Error('Response parse timeout')), 5000))
        ]);
      }
    } catch (parseError) {
      console.error('[Schedule Manager Proxy] Response parse error:', parseError.message);
      data = { error: 'Failed to parse response', status: response.status };
    }

    // Forward pagination headers
    ['x-pagination', 'x-total-count'].forEach(header => {
      const value = response.headers.get(header);
      if (value) res.setHeader(header, value);
    });

    return res.status(response.status).json(data);

  } catch (error) {
    console.error('[Schedule Manager Proxy] Error:', error.message);
    return res.status(500).json({
      error: 'Schedule Manager proxy error',
      message: error.message,
    });
  }
}

export const config = {
  api: {
    bodyParser: true,
  },
  maxDuration: 30,
};
