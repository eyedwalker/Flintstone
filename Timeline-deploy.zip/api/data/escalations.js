/**
 * Escalations API
 *
 * GET - Fetches active escalations from call_enrichments table
 * Returns both voice call and SMS escalations
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const db = getDb();

    const { data, error } = await db
      .from('call_enrichments')
      .select('call_sid, from_phone, direction, transcript, escalation_reason, emotion, sentiment_score, call_started_at, created_at')
      .eq('escalation_needed', true)
      .order('created_at', { ascending: false })
      .limit(50);

    if (error) {
      console.error('[Escalations] DB error:', error.message);
      return res.status(200).json({ success: true, escalations: [] });
    }

    const escalations = (data || []).map(row => ({
      id: row.call_sid,
      phone: row.from_phone,
      direction: row.direction,
      reason: row.escalation_reason || 'Escalation triggered',
      transcript: row.transcript,
      emotion: row.emotion,
      sentimentScore: row.sentiment_score,
      createdAt: row.call_started_at || row.created_at,
      type: row.call_sid?.startsWith('sms_') ? 'sms' : 'voice',
    }));

    return res.status(200).json({ success: true, escalations });
  } catch (err) {
    console.error('[Escalations] Error:', err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
}
