/**
 * Call Logs Data API
 * 
 * POST - Store a new call log
 * GET - Retrieve call logs
 * 
 * Uses in-memory storage with periodic persistence
 * In production, connect to database or Vercel KV
 */

// Persistent storage (in-memory for now, replace with DB in production)
const callLogsDB = new Map();

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    if (req.method === 'POST') {
      return handlePost(req, res);
    }
    
    if (req.method === 'GET') {
      return handleGet(req, res);
    }

    return res.status(405).json({ error: 'Method not allowed' });

  } catch (error) {
    console.error('[Call Logs API] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}

/**
 * Store a new call log
 */
function handlePost(req, res) {
  const callLog = req.body;

  if (!callLog.callSid) {
    return res.status(400).json({ error: 'Missing callSid' });
  }

  // Add metadata
  callLog.storedAt = new Date().toISOString();
  callLog.id = callLog.callSid;

  // Store
  callLogsDB.set(callLog.callSid, callLog);

  console.log('[Call Logs API] Stored:', callLog.callSid, 'Total:', callLogsDB.size);

  return res.status(201).json({ 
    success: true, 
    id: callLog.callSid,
    totalLogs: callLogsDB.size,
  });
}

/**
 * Retrieve call logs
 */
function handleGet(req, res) {
  const { callSid, from, limit = 100 } = req.query;

  // Get specific call
  if (callSid) {
    const log = callLogsDB.get(callSid);
    if (!log) {
      return res.status(404).json({ error: 'Call not found' });
    }
    return res.status(200).json(log);
  }

  // Get all logs, optionally filtered by phone
  let logs = Array.from(callLogsDB.values());

  if (from) {
    logs = logs.filter(log => log.from === from || log.to === from);
  }

  // Sort by most recent
  logs.sort((a, b) => new Date(b.completedAt || b.storedAt) - new Date(a.completedAt || a.storedAt));

  // Limit
  logs = logs.slice(0, parseInt(limit));

  return res.status(200).json({
    count: logs.length,
    total: callLogsDB.size,
    calls: logs,
  });
}

/**
 * Export for other handlers
 */
export function getCallLog(callSid) {
  return callLogsDB.get(callSid);
}

export function getAllCallLogs() {
  return Array.from(callLogsDB.values());
}
