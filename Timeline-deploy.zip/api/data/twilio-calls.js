/**
 * Fetch Real Call Data from Twilio
 * 
 * GET - Fetches actual call records from Twilio API
 * Includes recordings and can be filtered by date
 * 
 * Data Flow:
 * 1. Always fetch fresh calls from Twilio API (source of truth)
 * 2. If USE_DATABASE=true, merge with our enrichments (sentiment, ratings)
 * 3. Return combined data
 */

import twilio from 'twilio';
import { getDb } from '../_lib/db.js';

// Feature flag check
const USE_DATABASE = process.env.USE_DATABASE === 'true';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;

    if (!accountSid || !authToken) {
      return res.status(500).json({ error: 'Twilio credentials not configured' });
    }

    const client = twilio(accountSid, authToken);
    
    // Get query params
    const { limit = 50, dateFrom } = req.query;
    
    // Build filter options
    const filterOptions = {
      limit: parseInt(limit),
    };
    
    // Optional date filter (defaults to last 7 days)
    if (dateFrom) {
      filterOptions.startTimeAfter = new Date(dateFrom);
    } else {
      // Default: last 7 days
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      filterOptions.startTimeAfter = weekAgo;
    }

    console.log('[Twilio Calls] Fetching calls with filter:', filterOptions);

    // Fetch calls from Twilio
    const calls = await client.calls.list(filterOptions);

    // Transform to our format and fetch recordings + transcripts
    const callLogs = await Promise.all(calls.map(async (call) => {
      // Try to get recordings for this call
      let recordings = [];
      let transcript = null;
      
      try {
        recordings = await client.recordings.list({
          callSid: call.sid,
          limit: 1,
        });
      } catch (err) {
        console.log('[Twilio Calls] No recordings for:', call.sid);
      }

      const recording = recordings[0];
      
      // If recording exists, try to get transcript
      if (recording) {
        try {
          // Check for Twilio transcription
          const transcriptions = await client.transcriptions.list({
            limit: 20,
          });
          
          // Find transcription for this recording
          const callTranscription = transcriptions.find(t => 
            t.recordingSid === recording.sid
          );
          
          if (callTranscription) {
            // Fetch full transcription text
            const fullTranscription = await client.transcriptions(callTranscription.sid).fetch();
            transcript = fullTranscription.transcriptionText;
          }
        } catch (err) {
          // Transcription not available - this is normal for many calls
          console.log('[Twilio Calls] No transcription for recording:', recording.sid);
        }
        
        // If no Twilio transcription, try to get from Intelligence (if configured)
        if (!transcript) {
          try {
            // Try fetching transcript from call annotations or voice intelligence
            const annotations = await client.calls(call.sid).fetch();
            if (annotations.annotation) {
              transcript = annotations.annotation;
            }
          } catch (err) {
            // Annotations not available
          }
        }
      }

      // Build recording URL through our proxy (avoids exposing Twilio credentials to browser)
      let recordingUrl = null;
      if (recording) {
        recordingUrl = `/api/data/twilio-recording?sid=${recording.sid}`;
      }

      return {
        id: call.sid,
        callSid: call.sid,
        from: call.from,
        to: call.to,
        direction: call.direction,
        status: call.status,
        duration: call.duration ? parseInt(call.duration) : 0,
        startTime: call.startTime?.toISOString(),
        endTime: call.endTime?.toISOString(),
        answeredBy: call.answeredBy,
        // Recording info
        recordingUrl: recordingUrl,
        recordingSid: recording?.sid,
        recordingDuration: recording?.duration,
        // Transcript from Twilio
        transcript: transcript,
        hasTranscript: !!transcript,
        // Default AI metadata (will be enriched from DB if enabled)
        handler: 'ai',
        aiHandled: true,
        topic: call.direction === 'outbound-api' ? 'Outbound AI Call' : 'Inbound AI Call',
        outcome: call.status === 'completed' ? 'resolved' : call.status,
        // Enrichment placeholders (populated from DB when USE_DATABASE=true)
        sentiment_score: null,
        emotion: null,
        staff_rating: null,
        staff_notes: null,
        escalation_needed: false,
      };
    }));

    // Fetch transcripts and enrichments from database (durable storage)
    // In-memory Maps don't survive Vercel serverless cold starts, so we always
    // query the database for transcripts persisted by ai-call-response.js
    let enrichedCalls = callLogs;

    try {
      const supabase = getDb();

      const callSids = callLogs.map(c => c.callSid);
      const { data: enrichments, error: dbError } = await supabase
        .from('call_enrichments')
        .select('*')
        .in('call_sid', callSids);

      if (dbError) {
        console.error('[Twilio Calls] DB query error:', dbError.message);
      } else if (enrichments?.length) {
        const enrichmentMap = new Map(enrichments.map(e => [e.call_sid, e]));
        enrichedCalls = callLogs.map(call => {
          const enrichment = enrichmentMap.get(call.callSid);
          if (enrichment) {
            return {
              ...call,
              sentiment_score: enrichment.sentiment_score ?? call.sentiment_score,
              emotion: enrichment.emotion ?? call.emotion,
              staff_rating: enrichment.staff_rating ?? call.staff_rating,
              staff_notes: enrichment.staff_notes ?? call.staff_notes,
              escalation_needed: enrichment.escalation_needed ?? call.escalation_needed,
              escalation_reason: enrichment.escalation_reason || null,
              transcript: enrichment.transcript || call.transcript,
              hasTranscript: !!(enrichment.transcript || call.transcript),
            };
          }
          return call;
        });
        console.log('[Twilio Calls] Merged', enrichments.length, 'enrichments from DB');
      }
    } catch (dbErr) {
      console.error('[Twilio Calls] DB enrichment failed (continuing without):', dbErr.message);
    }

    console.log('[Twilio Calls] Found', enrichedCalls.length, 'calls', USE_DATABASE ? '(DB enabled)' : '(API only)');

    return res.status(200).json({
      success: true,
      count: enrichedCalls.length,
      calls: enrichedCalls,
      dbEnabled: USE_DATABASE,
    });

  } catch (error) {
    console.error('[Twilio Calls] Error:', error);
    return res.status(500).json({ 
      success: false,
      error: error.message,
    });
  }
}
