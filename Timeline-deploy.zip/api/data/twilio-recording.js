/**
 * Twilio Recording Proxy
 *
 * GET /api/data/twilio-recording?sid=RExxxxx
 * Streams a Twilio recording through our server so the browser
 * doesn't need Twilio credentials.
 */

import twilio from 'twilio';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { sid } = req.query;

  if (!sid) {
    return res.status(400).json({ error: 'Recording SID is required' });
  }

  // Validate SID format to prevent path traversal
  if (!/^RE[a-f0-9]{32}$/i.test(sid)) {
    return res.status(400).json({ error: 'Invalid recording SID format' });
  }

  try {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;

    if (!accountSid || !authToken) {
      return res.status(500).json({ error: 'Twilio credentials not configured' });
    }

    // Fetch the recording from Twilio with authentication
    const recordingUrl = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Recordings/${sid}.mp3`;

    const response = await fetch(recordingUrl, {
      headers: {
        'Authorization': 'Basic ' + Buffer.from(`${accountSid}:${authToken}`).toString('base64'),
      },
    });

    if (!response.ok) {
      console.error('[Recording Proxy] Twilio returned:', response.status);
      return res.status(response.status).json({ error: 'Failed to fetch recording' });
    }

    // Stream the audio back to the client
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Cache-Control', 'private, max-age=3600');

    const contentLength = response.headers.get('content-length');
    if (contentLength) {
      res.setHeader('Content-Length', contentLength);
    }

    // Pipe the response body
    const arrayBuffer = await response.arrayBuffer();
    res.status(200).send(Buffer.from(arrayBuffer));

  } catch (error) {
    console.error('[Recording Proxy] Error:', error.message);
    return res.status(500).json({ error: 'Failed to proxy recording' });
  }
}
