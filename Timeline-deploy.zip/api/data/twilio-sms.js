/**
 * Fetch Real SMS Data from Twilio
 * 
 * GET - Fetches actual SMS messages from Twilio API
 * Includes both inbound (patient) and outbound (AI/staff) messages
 */

import twilio from 'twilio';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;

    if (!accountSid || !authToken) {
      return res.status(500).json({ error: 'Twilio credentials not configured' });
    }

    const client = twilio(accountSid, authToken);
    
    // Get query params
    const { limit = 50, dateFrom, phone } = req.query;

    // Build filter options
    const filterOptions = {
      limit: parseInt(limit),
    };

    // Optional date filter (defaults to last 7 days)
    if (dateFrom) {
      filterOptions.dateSentAfter = new Date(dateFrom);
    } else {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      filterOptions.dateSentAfter = weekAgo;
    }

    console.log('[Twilio SMS] Fetching messages with filter:', filterOptions, phone ? `phone: ${phone}` : '');

    // If phone number specified, fetch both directions separately
    let messages;
    if (phone) {
      const cleanPhone = phone.startsWith('+') ? phone : `+1${phone.replace(/\D/g, '')}`;
      const [fromMsgs, toMsgs] = await Promise.all([
        client.messages.list({ ...filterOptions, from: cleanPhone }),
        client.messages.list({ ...filterOptions, to: cleanPhone }),
      ]);
      // Merge and deduplicate by SID
      const seen = new Set();
      messages = [...fromMsgs, ...toMsgs].filter(m => {
        if (seen.has(m.sid)) return false;
        seen.add(m.sid);
        return true;
      });
    } else {
      messages = await client.messages.list(filterOptions);
    }

    // Transform to our format
    const smsLogs = messages.map((msg) => ({
      id: msg.sid,
      messageSid: msg.sid,
      from: msg.from,
      to: msg.to,
      content: msg.body,
      direction: msg.direction === 'inbound' ? 'inbound' : 'outbound',
      status: msg.status,
      timestamp: msg.dateSent?.toISOString() || msg.dateCreated?.toISOString(),
      type: 'sms',
      sentBy: msg.direction === 'inbound' ? 'Patient' : 'AI/Staff',
      // Use the external phone number as conversation key
      conversationId: msg.direction === 'inbound' ? msg.from : msg.to,
    }));

    // Group messages by conversation (phone number)
    const conversationsMap = new Map();
    smsLogs.forEach(msg => {
      const key = msg.conversationId;
      if (!conversationsMap.has(key)) {
        conversationsMap.set(key, {
          id: key,
          phone: key,
          messages: [],
          lastMessage: null,
          lastTimestamp: null,
        });
      }
      const conv = conversationsMap.get(key);
      conv.messages.push(msg);
      if (!conv.lastTimestamp || new Date(msg.timestamp) > new Date(conv.lastTimestamp)) {
        conv.lastTimestamp = msg.timestamp;
        conv.lastMessage = msg.content;
      }
    });

    // Sort messages within each conversation by time
    const conversations = Array.from(conversationsMap.values()).map(conv => ({
      ...conv,
      messages: conv.messages.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp)),
      messageCount: conv.messages.length,
      inboundCount: conv.messages.filter(m => m.direction === 'inbound').length,
      outboundCount: conv.messages.filter(m => m.direction === 'outbound').length,
    }));

    // Sort conversations by most recent
    conversations.sort((a, b) => new Date(b.lastTimestamp) - new Date(a.lastTimestamp));

    console.log('[Twilio SMS] Found', smsLogs.length, 'messages in', conversations.length, 'conversations');

    return res.status(200).json({
      success: true,
      count: smsLogs.length,
      conversationCount: conversations.length,
      messages: smsLogs,
      conversations: conversations,
    });

  } catch (error) {
    console.error('[Twilio SMS] Error:', error);
    return res.status(500).json({ 
      success: false,
      error: error.message,
    });
  }
}
