/**
 * Cancel Appointment API
 * POST /api/appointments/cancel
 * Body: { appointment_id, reason, cancelled_by }
 */

import { appointmentAccessor } from '../../src/lib/accessors/AppointmentAccessor';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { appointment_id, reason, cancelled_by } = req.body;

    if (!appointment_id) {
      return res.status(400).json({ error: 'appointment_id is required' });
    }

    // Get existing appointment
    const existing = await appointmentAccessor.getById(appointment_id);
    if (!existing.success) {
      return res.status(404).json({ error: 'Appointment not found' });
    }

    // Update status to cancelled
    const updates = {
      status: 'cancelled',
      notes: existing.data.notes 
        ? `${existing.data.notes}\n\nCancelled: ${reason || 'No reason provided'} (by ${cancelled_by || 'system'} on ${new Date().toISOString()})`
        : `Cancelled: ${reason || 'No reason provided'} (by ${cancelled_by || 'system'} on ${new Date().toISOString()})`,
    };

    const result = await appointmentAccessor.update(appointment_id, updates);
    
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    return res.status(200).json({ 
      success: true,
      data: result.data,
      message: 'Appointment cancelled successfully'
    });
  } catch (error) {
    console.error('[Appointments][Cancel] Error:', error);
    return res.status(500).json({ error: error.message || 'Failed to cancel appointment' });
  }
}
