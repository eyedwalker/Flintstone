/**
 * Appointments API
 * GET /api/appointments - List appointments
 * POST /api/appointments - Create appointment
 */

import { appointmentAccessor } from '../../src/lib/accessors/AppointmentAccessor';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    if (req.method === 'GET') {
      const { office_id, start_date, end_date, patient_id, status } = req.query;

      if (!office_id && !patient_id) {
        return res.status(400).json({ error: 'office_id or patient_id is required' });
      }

      let result;
      if (patient_id) {
        result = await appointmentAccessor.getByPatient(patient_id);
      } else if (office_id && start_date && end_date) {
        result = await appointmentAccessor.getByDateRange(office_id, start_date, end_date);
      } else {
        return res.status(400).json({ error: 'start_date and end_date required when using office_id' });
      }

      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }

      let appointments = result.data;
      if (status) {
        appointments = appointments.filter(a => a.status === status);
      }

      return res.status(200).json({ data: appointments });
    }

    if (req.method === 'POST') {
      const appointmentData = req.body;

      const required = ['company_id', 'office_id', 'patient_id', 'appointment_date', 'appointment_type'];
      for (const field of required) {
        if (!appointmentData[field]) {
          return res.status(400).json({ error: `${field} is required` });
        }
      }

      const result = await appointmentAccessor.create(appointmentData);

      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }

      return res.status(201).json({ data: result.data });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (error) {
    console.error('[Appointments API] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
