/**
 * Reschedule Appointment API
 * POST /api/appointments/reschedule
 * Body: { appointment_id, new_date, new_time, reason, rescheduled_by }
 */

import { appointmentAccessor } from '../../src/lib/accessors/AppointmentAccessor';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { appointment_id, new_date, new_time, reason, rescheduled_by } = req.body;

    if (!appointment_id || !new_date) {
      return res.status(400).json({ error: 'appointment_id and new_date are required' });
    }

    // Get existing appointment
    const existing = await appointmentAccessor.getById(appointment_id);
    if (!existing.success) {
      return res.status(404).json({ error: 'Appointment not found' });
    }

    const oldDate = existing.data.appointment_date;
    const newDateTime = new_time ? `${new_date}T${new_time}` : new_date;

    // Update appointment with new date/time
    const updates = {
      appointment_date: newDateTime,
      status: 'scheduled', // Reset to scheduled if it was confirmed
      notes: existing.data.notes 
        ? `${existing.data.notes}\n\nRescheduled from ${oldDate} to ${newDateTime}: ${reason || 'No reason provided'} (by ${rescheduled_by || 'system'} on ${new Date().toISOString()})`
        : `Rescheduled from ${oldDate} to ${newDateTime}: ${reason || 'No reason provided'} (by ${rescheduled_by || 'system'} on ${new Date().toISOString()})`,
    };

    const result = await appointmentAccessor.update(appointment_id, updates);
    
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    return res.status(200).json({ 
      success: true,
      data: result.data,
      message: 'Appointment rescheduled successfully',
      old_date: oldDate,
      new_date: newDateTime
    });
  } catch (error) {
    console.error('[Appointments][Reschedule] Error:', error);
    return res.status(500).json({ error: error.message || 'Failed to reschedule appointment' });
  }
}
