/**
 * AI Sentiment Analysis for Calls and SMS
 * 
 * Analyzes conversations for:
 * - Customer satisfaction (1-5 scale)
 * - Emotion detection (happy, neutral, frustrated, angry)
 * - Escalation recommendation
 * - Key issues identified
 */

import Anthropic from '@anthropic-ai/sdk';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { transcript, type = 'call', callSid, phone } = req.body;

    if (!transcript) {
      return res.status(400).json({ error: 'Missing transcript' });
    }

    if (!process.env.ANTHROPIC_API_KEY) {
      return res.status(500).json({ error: 'Anthropic API key not configured' });
    }

    const anthropic = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });

    const systemPrompt = `You are an expert call center quality analyst. Analyze the following ${type} conversation and provide a structured assessment.

ANALYZE FOR:
1. Customer Satisfaction (1-5 scale where 5 is very satisfied)
2. Primary Emotion: one of [happy, satisfied, neutral, confused, frustrated, angry, upset]
3. Escalation Needed: true/false - should this be reviewed by a human supervisor?
4. Escalation Reason: if escalation needed, explain why
5. Key Issues: list any problems or concerns the customer expressed
6. AI Performance: rate how well the AI handled the conversation (1-5)
7. Improvement Suggestions: brief notes on how the AI could have done better

Respond ONLY in valid JSON format with this exact structure:
{
  "satisfaction": 4,
  "emotion": "satisfied",
  "emotionConfidence": 0.85,
  "escalationNeeded": false,
  "escalationReason": null,
  "keyIssues": ["scheduling confusion"],
  "aiPerformance": 4,
  "improvementSuggestions": "Could have offered alternative times more proactively",
  "summary": "Customer called to confirm appointment, interaction was positive"
}`;

    const response = await anthropic.messages.create({
      model: 'claude-3-5-haiku-20241022',
      max_tokens: 500,
      system: systemPrompt,
      messages: [
        { role: 'user', content: `Analyze this ${type} conversation:\n\n${transcript}` }
      ],
    });

    const analysisText = response.content[0]?.text || '{}';
    
    // Parse the JSON response
    let analysis;
    try {
      // Extract JSON from response (in case there's extra text)
      const jsonMatch = analysisText.match(/\{[\s\S]*\}/);
      analysis = jsonMatch ? JSON.parse(jsonMatch[0]) : {};
    } catch (parseErr) {
      console.error('[Sentiment] Failed to parse AI response:', parseErr);
      analysis = {
        satisfaction: 3,
        emotion: 'neutral',
        emotionConfidence: 0.5,
        escalationNeeded: false,
        escalationReason: null,
        keyIssues: [],
        aiPerformance: 3,
        improvementSuggestions: 'Unable to analyze',
        summary: 'Analysis unavailable',
      };
    }

    // Add metadata
    analysis.analyzedAt = new Date().toISOString();
    analysis.callSid = callSid;
    analysis.phone = phone;
    analysis.type = type;

    console.log('[Sentiment] Analysis complete:', {
      callSid,
      satisfaction: analysis.satisfaction,
      emotion: analysis.emotion,
      escalationNeeded: analysis.escalationNeeded,
    });

    // If escalation needed, we could trigger an alert here
    if (analysis.escalationNeeded) {
      console.log('[Sentiment] ⚠️ ESCALATION RECOMMENDED:', analysis.escalationReason);
      // TODO: Store escalation in database and trigger notification
    }

    return res.status(200).json({
      success: true,
      analysis,
    });

  } catch (error) {
    console.error('[Sentiment] Analysis error:', error);
    return res.status(500).json({
      success: false,
      error: error.message,
    });
  }
}
