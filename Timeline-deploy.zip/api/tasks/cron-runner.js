import {
  moveDueScheduledJobs,
  dequeueJobs,
  requeueJob,
  recordJobResult,
} from '../_lib/task-queue.js';
import { createTask, updateTask } from '../_lib/task-store.js';

const DEFAULT_BATCH_SIZE = parseInt(process.env.TASK_CRON_BATCH_SIZE || '10', 10);
const MAX_RETRY_DELAY_MS = 60 * 60 * 1000; // 1 hour

function ensureCors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Cron-Secret');
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return true;
  }
  return false;
}

function authorize(req) {
  const secret = process.env.TASK_CRON_SECRET;
  if (!secret) return true;
  const headerSecret = req.headers['x-cron-secret'];
  const querySecret = req.query?.cronSecret || req.query?.secret;
  return headerSecret === secret || querySecret === secret;
}

async function handleJob(job) {
  switch (job.type) {
    case 'create-task': {
      const task = await createTask(job.payload || {});
      return { status: 'completed', detail: `Task ${task.id} created` };
    }
    case 'update-task': {
      const { id, updates } = job.payload || {};
      if (!id || !updates) {
        throw new Error('update-task requires id and updates');
      }
      const task = await updateTask(id, updates);
      return { status: 'completed', detail: `Task ${task.id} updated` };
    }
    case 'task-reminder': {
      // Placeholder: could send Twilio/email notifications
      return { status: 'completed', detail: 'Reminder processed (no-op placeholder)' };
    }
    default:
      throw new Error(`Unknown job type: ${job.type}`);
  }
}

function calcRetryDelay(attempts = 0) {
  const base = Math.min(2 ** attempts * 1000, MAX_RETRY_DELAY_MS);
  const jitter = Math.floor(Math.random() * 0.25 * base);
  return base + jitter;
}

export default async function handler(req, res) {
  if (ensureCors(req, res)) return;

  if (req.method !== 'POST' && req.method !== 'GET') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  if (!authorize(req)) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }

  const summary = {
    movedScheduled: 0,
    processed: 0,
    requeued: 0,
    failed: 0,
    errors: [],
  };

  try {
    summary.movedScheduled = await moveDueScheduledJobs();

    const jobs = await dequeueJobs(DEFAULT_BATCH_SIZE);

    for (const job of jobs) {
      try {
        const result = await handleJob(job);
        summary.processed += 1;
        await recordJobResult({
          jobId: job.id,
          type: job.type,
          status: result.status,
          detail: result.detail,
        });
      } catch (error) {
        summary.failed += 1;
        summary.errors.push({ jobId: job.id, error: error.message });

        const attempts = (job.attempts ?? 0) + 1;
        if (attempts < (job.maxAttempts ?? 5)) {
          await requeueJob(
            { ...job, attempts, lastError: error.message },
            calcRetryDelay(attempts)
          );
          summary.requeued += 1;
        } else {
          await recordJobResult({
            jobId: job.id,
            type: job.type,
            status: 'dead-letter',
            detail: error.message,
          });
        }
      }
    }

    res.status(200).json({ success: true, ...summary });
  } catch (error) {
    console.error('[Tasks][cron-runner] Fatal error', error);
    res.status(500).json({ error: error.message || 'Cron runner failed' });
  }
}
