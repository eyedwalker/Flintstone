import { listTasks, createTask } from '../_lib/task-store.js';
import { getQueueStats, scheduleJob, getRedis } from '../_lib/task-queue.js';

function sendJson(res, status, body) {
  res.status(status).json(body);
}

function ensureCors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Cron-Secret');
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return true;
  }
  return false;
}

function parseBody(req) {
  if (!req.body) return {};
  if (typeof req.body === 'string') {
    try {
      return JSON.parse(req.body);
    } catch (err) {
      throw new Error('Invalid JSON body');
    }
  }
  return req.body;
}

const VALID_PRIORITIES = new Set(['low', 'normal', 'high', 'urgent']);
const VALID_STATUS = new Set(['pending', 'in_progress', 'completed', 'blocked']);

function normalizeTaskPayload(payload) {
  const data = { ...payload };
  if (data.priority && !VALID_PRIORITIES.has(data.priority)) {
    throw new Error(`Invalid priority. Allowed: ${Array.from(VALID_PRIORITIES).join(', ')}`);
  }
  if (data.status && !VALID_STATUS.has(data.status)) {
    throw new Error(`Invalid status. Allowed: ${Array.from(VALID_STATUS).join(', ')}`);
  }
  return {
    title: data.title,
    description: data.description,
    priority: data.priority,
    status: data.status,
    dueAt: data.dueAt,
    assignee: data.assignee,
    assignedToOffice: data.assignedToOffice,
    createdBy: data.createdBy,
    createdByName: data.createdByName,
    channel: data.channel,
    category: data.category,
    metadata: data.metadata,
    source: data.source,
  };
}

export default async function handler(req, res) {
  if (ensureCors(req, res)) return;

  try {
    if (req.method === 'GET') {
      const { status } = req.query;
      const [tasks, stats] = await Promise.all([listTasks(), getQueueStats()]);
      const filtered = status ? tasks.filter((t) => t.status === status) : tasks;
      sendJson(res, 200, { tasks: filtered, queue: stats });
      return;
    }

    if (req.method === 'POST') {
      const body = parseBody(req);
      const taskPayload = normalizeTaskPayload(body);

      if (!taskPayload.title) {
        throw new Error('title is required');
      }

      const task = await createTask(taskPayload);

      if (body.reminderInSeconds && Number(body.reminderInSeconds) > 0) {
        await scheduleJob(
          {
            type: 'task-reminder',
            payload: { taskId: task.id },
          },
          Date.now() + Number(body.reminderInSeconds) * 1000
        );
      }

      sendJson(res, 201, { task });
      return;
    }

    if (req.method === 'DELETE') {
      // Clear all corrupted task data from Redis
      const redis = getRedis();
      const keys = [
        'timeline:tasks:data',
        'timeline:tasks:queue',
        'timeline:tasks:scheduled',
        'timeline:tasks:activity',
        'timeline:tasks:history',
      ];
      await Promise.all(keys.map(k => redis.del(k)));
      sendJson(res, 200, { success: true, message: 'All task data cleared', keys });
      return;
    }

    sendJson(res, 405, { error: 'Method not allowed' });
  } catch (error) {
    console.error('[Tasks][index] Error', error);
    sendJson(res, 400, { error: error.message || 'Task API error' });
  }
}
