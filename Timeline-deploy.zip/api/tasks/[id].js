import { getTask, updateTask } from '../_lib/task-store.js';

function sendJson(res, status, body) {
  res.status(status).json(body);
}

function ensureCors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PATCH, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Cron-Secret');
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return true;
  }
  return false;
}

export default async function handler(req, res) {
  if (ensureCors(req, res)) return;

  const { id } = req.query;
  if (!id) {
    sendJson(res, 400, { error: 'Task id is required' });
    return;
  }

  try {
    if (req.method === 'GET') {
      const task = await getTask(id);
      if (!task) {
        sendJson(res, 404, { error: 'Task not found' });
        return;
      }
      sendJson(res, 200, { task });
      return;
    }

    if (req.method === 'PATCH') {
      const updates = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : req.body || {};
      const task = await updateTask(id, updates);
      sendJson(res, 200, { task });
      return;
    }

    sendJson(res, 405, { error: 'Method not allowed' });
  } catch (error) {
    console.error('[Tasks][id] Error', error);
    sendJson(res, 400, { error: error.message || 'Task API error' });
  }
}
