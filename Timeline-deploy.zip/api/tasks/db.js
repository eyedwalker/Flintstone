/**
 * Database-backed task API
 * Replaces Redis-based task storage
 */

import { getDb } from '../_lib/db.js';

const supabase = getDb();

function ensureCors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return true;
  }
  return false;
}

function parseBody(req) {
  if (!req.body) return {};
  if (typeof req.body === 'string') {
    try {
      return JSON.parse(req.body);
    } catch (err) {
      throw new Error('Invalid JSON body');
    }
  }
  return req.body;
}

export default async function handler(req, res) {
  if (ensureCors(req, res)) return;

  try {
    // GET /api/tasks/db - List all tasks
    if (req.method === 'GET') {
      const { office_id, status, patient_id } = req.query;
      
      let query = supabase.from('tasks').select('*').order('created_at', { ascending: false });
      
      if (office_id) query = query.eq('office_id', office_id);
      if (status) query = query.eq('status', status);
      if (patient_id) query = query.eq('patient_id', patient_id);
      
      const { data, error } = await query;
      
      if (error) {
        console.error('[Tasks][db] Query error:', error);
        throw error;
      }
      
      res.status(200).json({ success: true, tasks: data || [] });
      return;
    }

    // POST /api/tasks/db - Create new task
    if (req.method === 'POST') {
      const body = parseBody(req);
      
      // Validate required fields
      if (!body.title || body.title.trim().length < 3) {
        res.status(400).json({ error: 'Title must be at least 3 characters' });
        return;
      }
      
      // Parse dueAt ISO string to separate date and time if provided
      let dueDate = body.due_date;
      let dueTime = body.due_time;
      if (body.dueAt) {
        const dueAtDate = new Date(body.dueAt);
        if (!isNaN(dueAtDate.getTime())) {
          dueDate = dueAtDate.toISOString().split('T')[0]; // YYYY-MM-DD
          dueTime = dueAtDate.toTimeString().split(' ')[0].substring(0, 5); // HH:MM
        }
      }
      
      // Extract metadata fields
      const metadata = body.metadata || {};
      const patientId = body.patient_id || metadata.patientId || null;
      const officeId = body.office_id || body.assignedToOffice || metadata.officeId || null;
      
      // Store assignee in settings JSON to avoid UUID type mismatch on assigned_to column
      const rawAssignee = body.assigned_to || body.assignee || null;
      let assigneeInfo = {};
      if (rawAssignee) {
        if (rawAssignee.startsWith('role:')) {
          assigneeInfo = { assignedRole: rawAssignee.substring(5) };
        } else {
          assigneeInfo = { assignedUserId: rawAssignee, assignedUserName: body.createdByName };
        }
      }

      const taskData = {
        company_id: body.company_id || null,
        office_id: officeId,
        title: body.title.trim(),
        description: body.description || null,
        category: body.category || 'other',
        priority: body.priority || 'medium',
        status: body.status || 'pending',
        patient_id: patientId,
        journey_id: body.journey_id || null,
        assigned_to: null,
        due_date: dueDate,
        due_time: dueTime,
        notes: body.notes || null,
        tags: body.tags || [],
        settings: {
          ...(body.settings || {}),
          createdBy: body.createdBy,
          createdByName: body.createdByName,
          channel: body.channel,
          source: body.source,
          metadata: body.metadata,
          ...assigneeInfo
        }
      };
      
      const { data, error } = await supabase
        .from('tasks')
        .insert(taskData)
        .select()
        .single();
      
      if (error) {
        console.error('[Tasks][db] Insert error:', error);
        throw error;
      }
      
      res.status(201).json({ success: true, task: data });
      return;
    }

    // PATCH /api/tasks/db/:id - Update task (from path after /db/)
    if (req.method === 'PATCH') {
      const taskId = req.url.split('/').pop();
      
      if (!taskId || taskId === 'db') {
        res.status(400).json({ error: 'Task ID required' });
        return;
      }
      
      const body = parseBody(req);
      
      // Validate title if provided
      if (body.title !== undefined && body.title.trim().length < 3) {
        res.status(400).json({ error: 'Title must be at least 3 characters' });
        return;
      }
      
      const updates = {};
      if (body.title) updates.title = body.title.trim();
      if (body.description !== undefined) updates.description = body.description;
      if (body.category) updates.category = body.category;
      if (body.priority) updates.priority = body.priority;
      if (body.status) {
        updates.status = body.status;
        if (body.status === 'completed') {
          updates.completed_at = new Date().toISOString();
        }
      }
      if (body.patient_id !== undefined) updates.patient_id = body.patient_id;
      if (body.journey_id !== undefined) updates.journey_id = body.journey_id;
      if (body.assigned_to !== undefined || body.assignee !== undefined) {
        const rawAssign = body.assigned_to !== undefined ? body.assigned_to : body.assignee;
        updates.assigned_to = null;
        if (rawAssign) {
          if (rawAssign.startsWith('role:')) {
            updates.settings = { ...(body.settings || {}), assignedRole: rawAssign.substring(5), assignedUserId: null };
          } else {
            updates.settings = { ...(body.settings || {}), assignedUserId: rawAssign, assignedRole: null };
          }
        }
      }
      if (body.due_date !== undefined) updates.due_date = body.due_date;
      if (body.due_time !== undefined) updates.due_time = body.due_time;
      if (body.notes !== undefined) updates.notes = body.notes;
      if (body.tags !== undefined) updates.tags = body.tags;
      if (body.settings !== undefined) updates.settings = body.settings;
      
      const { data, error } = await supabase
        .from('tasks')
        .update(updates)
        .eq('id', taskId)
        .select()
        .single();
      
      if (error) throw error;
      
      res.status(200).json({ success: true, task: data });
      return;
    }

    // DELETE /api/tasks/db/:id - Delete task
    if (req.method === 'DELETE') {
      const taskId = req.url.split('/').pop();
      
      if (!taskId || taskId === 'db') {
        res.status(400).json({ error: 'Task ID required' });
        return;
      }
      
      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', taskId);
      
      if (error) throw error;
      
      res.status(200).json({ success: true, message: 'Task deleted' });
      return;
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (error) {
    console.error('[Tasks][db] Error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
}
