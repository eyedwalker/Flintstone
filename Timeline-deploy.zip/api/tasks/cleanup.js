import { getRedis } from '../_lib/task-queue.js';
import { TaskStoreKeys } from '../_lib/task-store.js';

function ensureCors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return true;
  }
  return false;
}

function isUntitledTask(task) {
  const title = task?.title;
  if (!title) return true;
  const trimmed = String(title).trim();
  if (!trimmed) return true;
  if (trimmed.length < 3) return true;
  if (trimmed === 'Untitled Task') return true;
  return false;
}

export default async function handler(req, res) {
  if (ensureCors(req, res)) return;

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  try {
    const redis = getRedis();
    const entries = await redis.hgetall(TaskStoreKeys.TASK_DATA_KEY);
    
    if (!entries) {
      res.status(200).json({ success: true, deletedCount: 0, message: 'No tasks found' });
      return;
    }

    const matchedIds = [];

    for (const [taskId, raw] of Object.entries(entries)) {
      if (!raw) continue;
      try {
        const task = JSON.parse(raw);
        if (!task?.id) continue;
        if (isUntitledTask(task)) {
          matchedIds.push(task.id);
        }
      } catch (error) {
        console.error('[cleanup] Parse error for task:', taskId, error);
      }
    }

    if (matchedIds.length > 0) {
      await redis.hdel(TaskStoreKeys.TASK_DATA_KEY, ...matchedIds);
    }

    res.status(200).json({
      success: true,
      deletedCount: matchedIds.length,
      deletedIds: matchedIds,
      message: `Deleted ${matchedIds.length} untitled tasks`
    });
  } catch (error) {
    console.error('[cleanup] Error', error);
    res.status(500).json({ error: error.message || 'Cleanup failed' });
  }
}
