import { enqueueJob, scheduleJob } from '../_lib/task-queue.js';

function sendJson(res, status, body) {
  res.status(status).json(body);
}

function parseBody(req) {
  if (!req.body) return {};
  if (typeof req.body === 'string') {
    try {
      return JSON.parse(req.body);
    } catch (err) {
      throw new Error('Invalid JSON body');
    }
  }
  return req.body;
}

function ensureCors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Cron-Secret');
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return true;
  }
  return false;
}

function authorize(req) {
  const secret = process.env.TASK_CRON_SECRET;
  if (!secret) return true;
  return req.headers['x-cron-secret'] === secret;
}

export default async function handler(req, res) {
  if (ensureCors(req, res)) {
    return;
  }

  if (req.method !== 'POST') {
    sendJson(res, 405, { error: 'Method not allowed' });
    return;
  }

  if (!authorize(req)) {
    sendJson(res, 401, { error: 'Unauthorized' });
    return;
  }

  try {
    const body = parseBody(req);
    const { type, payload = {}, delaySeconds = 0, maxAttempts = 5, id } = body;

    if (!type) {
      throw new Error('type is required');
    }

    const baseJob = {
      id,
      type,
      payload,
      maxAttempts,
    };

    const job = delaySeconds > 0
      ? await scheduleJob(baseJob, Date.now() + delaySeconds * 1000)
      : await enqueueJob(baseJob);

    sendJson(res, 200, {
      success: true,
      queued: delaySeconds > 0 ? 'scheduled' : 'immediate',
      job,
    });
  } catch (error) {
    console.error('[Tasks][enqueue] Failed:', error);
    sendJson(res, 400, { error: error.message || 'Failed to enqueue job' });
  }
}
