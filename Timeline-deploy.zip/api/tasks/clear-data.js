/**
 * Clear corrupted task data from Redis
 * Run manually via: curl -X POST http://localhost:5173/api/tasks/clear-data
 */
import { getRedis } from '../_lib/task-queue.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const redis = getRedis();
    
    // Delete all task-related keys
    await Promise.all([
      redis.del('timeline:tasks:data'),
      redis.del('timeline:tasks:queue'),
      redis.del('timeline:tasks:scheduled'),
      redis.del('timeline:tasks:activity'),
      redis.del('timeline:tasks:history'),
    ]);

    res.status(200).json({ 
      success: true, 
      message: 'All task data cleared from Redis',
      cleared: [
        'timeline:tasks:data',
        'timeline:tasks:queue', 
        'timeline:tasks:scheduled',
        'timeline:tasks:activity',
        'timeline:tasks:history',
      ]
    });
  } catch (error) {
    console.error('[ClearData] Error:', error);
    res.status(500).json({ error: error.message });
  }
}
