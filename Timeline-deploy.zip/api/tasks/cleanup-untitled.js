import { getRedis } from '../_lib/task-queue.js';
import { TaskStoreKeys } from '../_lib/task-store.js';

function ensureCors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Cron-Secret');
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return true;
  }
  return false;
}

function authorize(req) {
  const secret = process.env.TASK_CRON_SECRET;
  if (!secret) return true;
  return req.headers['x-cron-secret'] === secret;
}

function parseBody(req) {
  if (!req.body) return {};
  if (typeof req.body === 'string') {
    try {
      return JSON.parse(req.body);
    } catch (err) {
      throw new Error('Invalid JSON body');
    }
  }
  return req.body;
}

function isUntitledTask(task) {
  const title = task?.title;
  if (!title) return true;
  const trimmed = String(title).trim();
  if (!trimmed) return true;
  return trimmed === 'Untitled Task';
}

export default async function handler(req, res) {
  if (ensureCors(req, res)) return;

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  if (!authorize(req)) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }

  try {
    const body = parseBody(req);
    const dryRun = body.dryRun !== undefined ? Boolean(body.dryRun) : true;

    const redis = getRedis();
    const entries = await redis.hgetall(TaskStoreKeys.TASK_DATA_KEY);
    const rawValues = entries ? Object.values(entries) : [];

    const matchedIds = [];
    const parseErrors = [];

    for (const raw of rawValues) {
      if (!raw) continue;
      try {
        const task = JSON.parse(raw);
        if (!task?.id) continue;
        if (task?.status === 'completed') continue;
        if (!isUntitledTask(task)) continue;
        matchedIds.push(task.id);
      } catch (error) {
        parseErrors.push(String(error?.message || error));
      }
    }

    if (!dryRun && matchedIds.length > 0) {
      await redis.hdel(TaskStoreKeys.TASK_DATA_KEY, matchedIds);
    }

    res.status(200).json({
      success: true,
      dryRun,
      matchedCount: matchedIds.length,
      deletedCount: dryRun ? 0 : matchedIds.length,
      sampleIds: matchedIds.slice(0, 25),
      parseErrorCount: parseErrors.length,
    });
  } catch (error) {
    console.error('[Tasks][cleanup-untitled] Error', error);
    res.status(500).json({ error: error.message || 'Cleanup failed' });
  }
}
