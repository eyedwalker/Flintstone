import twilio from 'twilio';

const getPublicBaseUrl = () => {
  // Always use production domain for consistency and to avoid TwiML parse failures
  return process.env.NEXT_PUBLIC_APP_URL || 'https://patientcare-teal.vercel.app';
};

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { to, message } = req.body;

    if (!to || !message) {
      return res.status(400).json({ error: 'Missing required fields: to, message' });
    }

    const demoPhone = process.env.DEMO_TEST_PHONE || '+12142085261';
    const targetPhone = demoPhone;

    // Check Twilio credentials
    if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN) {
      return res.status(500).json({ error: 'Twilio credentials not configured' });
    }

    if (!process.env.TWILIO_PHONE_NUMBER) {
      return res.status(500).json({ error: 'Twilio phone number not configured' });
    }

    const client = twilio(
      process.env.TWILIO_ACCOUNT_SID,
      process.env.TWILIO_AUTH_TOKEN
    );

    const baseUrl = getPublicBaseUrl();
    const canUseElevenLabs = !!(baseUrl && baseUrl.startsWith('https://') && process.env.ELEVENLABS_API_KEY && process.env.USE_ELEVENLABS_VOICE !== 'false');
    const cleanMessage = String(message).replace(/[<>]/g, '').substring(0, 200); // Limit message length
    
    // Enhanced voice with background noise and ElevenLabs fallback
    const useElevenLabs = req.body.useElevenLabs !== false && canUseElevenLabs; // Allow override
    const addBackgroundNoise = req.body.backgroundNoise !== false; // Office ambiance by default
    
    let speech;
    if (useElevenLabs) {
      // Try ElevenLabs with timeout and fallback (& must be &amp; in XML)
      const audioUrl = `${baseUrl}/api/voice/generate-audio?voice=sarah&amp;text=${encodeURIComponent(cleanMessage)}&amp;background=${addBackgroundNoise}`;
      speech = `
        <Play>${audioUrl}</Play>
        <Say voice="Polly.Joanna">If you're still on the line, we're having technical difficulties. Please hold while we connect you.</Say>
      `;
    } else {
      // Reliable Polly voice with office background
      speech = addBackgroundNoise
        ? `<Play>${baseUrl}/api/voice/office-background.mp3</Play><Say voice="Polly.Joanna">${cleanMessage}</Say>`
        : `<Say voice="Polly.Joanna">${cleanMessage}</Say>`;
    }
    
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>\n<Response>\n  ${speech}\n</Response>`;

    const result = await client.calls.create({
      to: targetPhone,
      from: process.env.TWILIO_PHONE_NUMBER,
      twiml,
    });

    console.log('[Voice] Call initiated:', result.sid);

    return res.status(200).json({
      success: true,
      callId: result.sid,
      status: result.status,
      to: targetPhone,
      elevenLabs: canUseElevenLabs,
    });
  } catch (error) {
    console.error('[Voice] Call error:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to make call',
    });
  }
}
