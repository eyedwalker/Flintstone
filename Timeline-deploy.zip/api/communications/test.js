/**
 * Test endpoint for communications services
 * GET /api/communications/test - Check configuration status
 * POST /api/communications/test - Send test messages
 */
export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // GET - Check configuration status
  if (req.method === 'GET') {
    const config = {
      twilio: {
        configured: !!(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_PHONE_NUMBER),
        accountSid: process.env.TWILIO_ACCOUNT_SID ? `${process.env.TWILIO_ACCOUNT_SID.substring(0, 6)}...` : null,
        phoneNumber: process.env.TWILIO_PHONE_NUMBER || null,
      },
      email: {
        configured: !!(process.env.SMTP_HOST && process.env.SMTP_USERNAME && process.env.SMTP_PASSWORD),
        host: process.env.SMTP_HOST || null,
        from: process.env.SMTP_FROM_EMAIL || process.env.SMTP_USERNAME || null,
      },
      elevenlabs: {
        configured: !!process.env.ELEVENLABS_API_KEY,
      },
      vercelUrl: process.env.VERCEL_URL || null,
    };

    return res.status(200).json({ config });
  }

  // POST - Send test message
  if (req.method === 'POST') {
    const { type } = req.body;

    if (!type) {
      return res.status(400).json({ error: 'Missing type field' });
    }

    const demoEmail = process.env.DEMO_TEST_EMAIL || 'daviwa2@vsp.com';
    const demoPhone = process.env.DEMO_TEST_PHONE || '+12142085261';

    const getPublicBaseUrl = () => {
      if (process.env.PUBLIC_BASE_URL) return process.env.PUBLIC_BASE_URL;
      if (process.env.VERCEL_URL) return `https://${process.env.VERCEL_URL}`;
      return null;
    };

    try {
      if (type === 'sms') {
        const twilio = (await import('twilio')).default;
        const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
        
        const result = await client.messages.create({
          body: 'VisionCare Timeline test: SMS routing is working. Reply STOP to opt out of future tests.',
          to: demoPhone,
          from: process.env.TWILIO_PHONE_NUMBER,
        });

        return res.status(200).json({ success: true, type: 'sms', to: demoPhone, messageId: result.sid });
      }

      if (type === 'email') {
        const nodemailer = (await import('nodemailer')).default;
        
        const transporter = nodemailer.createTransport({
          host: process.env.SMTP_HOST,
          port: parseInt(process.env.SMTP_PORT || '587'),
          secure: false,
          auth: {
            user: process.env.SMTP_USERNAME,
            pass: process.env.SMTP_PASSWORD,
          },
        });

        const info = await transporter.sendMail({
          from: `"${process.env.SMTP_FROM_NAME || 'VisionCare Timeline'}" <${process.env.SMTP_FROM_EMAIL || process.env.SMTP_USERNAME}>`,
          to: demoEmail,
          subject: 'VisionCare Timeline test email',
          text: 'VisionCare Timeline test: Email routing is working.',
          html: '<h2>VisionCare Timeline test</h2><p>Email routing is working.</p>',
        });

        return res.status(200).json({ success: true, type: 'email', to: demoEmail, messageId: info.messageId });
      }

      if (type === 'voice') {
        const twilio = (await import('twilio')).default;
        const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

        const message = 'This is a VisionCare Timeline test call. Voice routing is working.';
        const baseUrl = getPublicBaseUrl();
        const canUseElevenLabs = !!(baseUrl && baseUrl.startsWith('https://') && process.env.ELEVENLABS_API_KEY && process.env.USE_ELEVENLABS_VOICE !== 'false');
        const speech = canUseElevenLabs
          ? `<Play>${baseUrl}/api/voice/generate-audio?voice=sarah&text=${encodeURIComponent(message)}</Play>`
          : `<Say voice="alice">${message}</Say>`;
        const twiml = `<?xml version="1.0" encoding="UTF-8"?>\n<Response>\n  ${speech}\n</Response>`;

        const result = await client.calls.create({
          to: demoPhone,
          from: process.env.TWILIO_PHONE_NUMBER,
          twiml,
        });

        return res.status(200).json({ success: true, type: 'voice', to: demoPhone, callId: result.sid, elevenLabs: canUseElevenLabs });
      }

      return res.status(400).json({ error: 'Invalid type. Use "sms", "email", or "voice"' });

    } catch (error) {
      console.error(`[Test] ${type} error:`, error);
      return res.status(500).json({ success: false, type, error: error.message });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
