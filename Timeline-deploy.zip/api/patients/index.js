/**
 * Patients API
 * GET /api/patients - List patients (by company_id, optional search)
 * POST /api/patients - Create patient
 *
 * Uses process.env for Supabase connection (Vercel serverless compatible).
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const db = getDb();

  try {
    if (req.method === 'GET') {
      const { company_id, search, status } = req.query;

      if (!company_id) {
        return res.status(400).json({ error: 'company_id is required' });
      }

      let query = db.from('patients').select('*').eq('company_id', company_id);

      if (search) {
        query = query.or(`first_name.ilike.%${search}%,last_name.ilike.%${search}%`);
      }

      if (status) {
        query = query.eq('status', status);
      }

      query = query.order('last_name', { ascending: true });

      const { data, error } = await query;

      if (error) {
        console.error('[Patients API] GET error:', error);
        return res.status(400).json({ error: error.message });
      }

      return res.status(200).json({ data: data || [] });
    }

    if (req.method === 'POST') {
      const patientData = req.body;

      if (!patientData.company_id || !patientData.first_name || !patientData.last_name) {
        return res.status(400).json({ error: 'company_id, first_name, and last_name are required' });
      }

      const { data, error } = await db
        .from('patients')
        .insert({
          company_id: patientData.company_id,
          first_name: patientData.first_name,
          last_name: patientData.last_name,
          date_of_birth: patientData.date_of_birth || null,
          gender: patientData.gender || null,
          email: patientData.email || null,
          phone: patientData.phone || null,
          mobile_phone: patientData.mobile_phone || null,
          address: patientData.address || {},
          emergency_contact: patientData.emergency_contact || {},
          preferred_language: patientData.preferred_language || 'en',
          status: patientData.status || 'active',
          notes: patientData.notes || null,
          settings: patientData.settings || {},
        })
        .select()
        .single();

      if (error) {
        console.error('[Patients API] POST error:', error);
        return res.status(400).json({ error: error.message });
      }

      return res.status(201).json({ data });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (error) {
    console.error('[Patients API] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
