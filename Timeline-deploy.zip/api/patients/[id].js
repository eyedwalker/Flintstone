/**
 * Patient by ID API
 * GET /api/patients/[id] - Get patient
 * PUT /api/patients/[id] - Update patient
 * DELETE /api/patients/[id] - Delete patient
 */

import { patientAccessor } from '../../src/lib/accessors/PatientAccessor';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const { id } = req.query;

  try {
    if (req.method === 'GET') {
      const result = await patientAccessor.getById(id);
      if (!result.success) {
        return res.status(404).json({ error: 'Patient not found' });
      }
      return res.status(200).json({ data: result.data });
    }

    if (req.method === 'PUT') {
      const updates = req.body;
      const result = await patientAccessor.update(id, updates);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      return res.status(200).json({ data: result.data });
    }

    if (req.method === 'DELETE') {
      const result = await patientAccessor.delete(id);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      return res.status(200).json({ success: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (error) {
    console.error('[Patient API] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
