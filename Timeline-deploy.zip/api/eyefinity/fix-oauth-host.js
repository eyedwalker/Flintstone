/**
 * Revert OAuth Host to Working Configuration
 * Changes auth.eyefinity.com back to api-sandbox.eyefinity.com
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');

  try {
    const supabase = getDb();

    // Fix Vision Care / EyeCare 4 U OAuth host
    const { data, error } = await supabase
      .from('companies')
      .update({
        oauth_host: 'api-sandbox.eyefinity.com'
      })
      .or('name.ilike.%vision%,name.ilike.%eyecare%')
      .select();

    if (error) {
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }

    return res.status(200).json({
      success: true,
      message: 'OAuth host reverted to api-sandbox.eyefinity.com',
      updated: data,
      nextStep: 'Test at: /api/eyefinity/test-vision-care'
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message
    });
  }
}
