/**
 * Automated Eyefinity Diagnostic & Fix System
 * Tests OAuth flow, API connectivity, and automatically fixes issues
 */

import { getDb } from '../_lib/db.js';

const EPM_SCOPES = 'auth_epm ef.pm_pe_patient_rx ef.pm_pe_resource ef.pm_pe_insurance ef.pm_pe_appointment ef.pm_pe_office_recallreport ef.pm_pe_staff ef.pm_pe_office ef.pm_pe_company ef.pm_pe_order ef.pm_pe_provider ef.pm_pe_patient';

async function testOAuth(company, log) {
  log.push('\n=== TESTING OAUTH FLOW ===');
  
  // Validate credentials
  if (!company.eyefinity_api_key || !company.eyefinity_api_secret || !company.tenant_uid) {
    log.push('❌ OAuth credentials incomplete');
    return { 
      success: false, 
      stage: 'credentials',
      fixes: ['Set eyefinity_api_key, eyefinity_api_secret, tenant_uid in database']
    };
  }
  
  if (!company.oauth_host || !company.api_base_url) {
    log.push('❌ OAuth host or API base URL missing');
    return { 
      success: false, 
      stage: 'configuration',
      fixes: ['Set oauth_host to api-sandbox.eyefinity.com', 'Set api_base_url to https://api-sandbox.eyefinity.com']
    };
  }
  
  log.push(`✓ Credentials present`);
  log.push(`  Host: ${company.oauth_host}`);
  log.push(`  API: ${company.api_base_url}`);
  log.push(`  Path: ${company.api_path || 'NOT SET'}`);
  
  // Step 1: Client credentials
  try {
    log.push('\n--- Step 1: Client Credentials Token ---');
    const credentials = Buffer.from(`${company.eyefinity_api_key}:${company.eyefinity_api_secret}`).toString('base64');
    
    const ccResponse = await fetch(`https://${company.oauth_host}/as/token.oauth2`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: `grant_type=client_credentials&scope=${encodeURIComponent(EPM_SCOPES)}`
    });
    
    if (!ccResponse.ok) {
      const error = await ccResponse.text();
      log.push(`❌ Client credentials failed: ${ccResponse.status}`);
      log.push(`  Error: ${error.substring(0, 200)}`);
      
      if (ccResponse.status === 401) {
        return {
          success: false,
          stage: 'client_credentials',
          error: 'Invalid client credentials',
          fixes: ['Verify eyefinity_api_key and eyefinity_api_secret are correct']
        };
      }
      
      return {
        success: false,
        stage: 'client_credentials',
        error: `HTTP ${ccResponse.status}`,
        fixes: ['Check network connectivity', 'Verify oauth_host is correct']
      };
    }
    
    const ccData = await ccResponse.json();
    const clientToken = ccData.access_token || ccData.accesstoken;
    log.push(`✓ Client token obtained`);
    
    // Step 2: Token exchange
    log.push('\n--- Step 2: Token Exchange ---');
    const exchangeBody = new URLSearchParams({
      'grant_type': 'urn:ietf:params:oauth:grant-type:token-exchange',
      'subject_token': clientToken,
      'subject_token_type': 'urn:ietf:params:oauth:token-type:access_token',
      'scope': EPM_SCOPES,
      'resource': 'https://VspEpmToken',
    }).toString();

    const exchangeResponse = await fetch(`https://${company.oauth_host}/as/token.oauth2`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'tenantuid': company.tenant_uid,
      },
      body: exchangeBody
    });

    if (!exchangeResponse.ok) {
      const error = await exchangeResponse.text();
      log.push(`❌ Token exchange failed: ${exchangeResponse.status}`);
      log.push(`  Error: ${error.substring(0, 200)}`);
      
      if (exchangeResponse.status === 401) {
        return {
          success: false,
          stage: 'token_exchange',
          error: 'Invalid tenant_uid',
          fixes: ['Verify tenant_uid is correct for this Eyefinity tenant']
        };
      }
      
      return {
        success: false,
        stage: 'token_exchange',
        error: `HTTP ${exchangeResponse.status}`,
        fixes: ['Check network connectivity', 'Verify tenant_uid format']
      };
    }

    const exchangeData = await exchangeResponse.json();
    const epmToken = exchangeData.access_token || exchangeData.accesstoken;
    log.push(`✓ EPM token obtained`);
    
    return {
      success: true,
      token: epmToken
    };
    
  } catch (error) {
    log.push(`❌ OAuth error: ${error.message}`);
    return {
      success: false,
      stage: 'network',
      error: error.message,
      fixes: ['Check if Vercel can reach oauth_host', 'Verify DNS resolution', 'Check for firewall/network blocks']
    };
  }
}

async function testAPI(company, token, log) {
  log.push('\n=== TESTING API CONNECTIVITY ===');
  
  const apiPath = company.api_path || 'al-pe';
  const url = `${company.api_base_url}/${apiPath}/v2offices?page=1&pageSize=10`;
  
  log.push(`URL: ${url}`);
  
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });
    
    log.push(`Response: ${response.status}`);
    
    if (!response.ok) {
      const error = await response.text();
      log.push(`❌ API call failed`);
      log.push(`  Error: ${error.substring(0, 300)}`);
      
      if (response.status === 401) {
        return {
          success: false,
          error: 'Unauthorized - token may be invalid',
          fixes: ['Token exchange succeeded but API rejects it', 'Verify scopes include office access', 'Check if token format is correct']
        };
      }
      
      if (response.status === 403) {
        return {
          success: false,
          error: 'Forbidden - insufficient permissions',
          fixes: ['Verify OAuth scopes include ef.pm_pe_office', 'Check tenant_uid has access to offices', 'Verify API key has proper permissions']
        };
      }
      
      if (response.status === 404) {
        return {
          success: false,
          error: 'Not found - incorrect API path or endpoint',
          fixes: [`Verify api_path is correct (current: ${apiPath})`, 'Check if endpoint v2offices exists', 'Verify api_base_url is correct']
        };
      }
      
      if (response.status === 503) {
        return {
          success: false,
          error: 'Service unavailable - network/TLS issue',
          fixes: ['Vercel cannot reach Eyefinity API server', 'May require VPN or IP whitelisting', 'Check if api_base_url is accessible from internet', 'Consider using different hosting with network access']
        };
      }
      
      return {
        success: false,
        error: `HTTP ${response.status}`,
        fixes: ['Unknown API error', 'Check Eyefinity API documentation', 'Contact Eyefinity support']
      };
    }
    
    const data = await response.json();
    const officeCount = Array.isArray(data) ? data.length : (data.items?.length || 0);
    
    log.push(`✓ API call successful`);
    log.push(`✓ Retrieved ${officeCount} offices`);
    
    if (officeCount > 0) {
      const firstOffice = Array.isArray(data) ? data[0] : data.items?.[0];
      log.push(`  Sample: ${firstOffice?.Name || firstOffice?.OfficeNumber || 'N/A'}`);
    }
    
    return {
      success: true,
      officeCount,
      sampleData: data
    };
    
  } catch (error) {
    log.push(`❌ Network error: ${error.message}`);
    return {
      success: false,
      error: error.message,
      fixes: ['Vercel cannot connect to API server', 'Check if api_base_url is reachable', 'May require VPN or different hosting', 'Verify DNS resolution']
    };
  }
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  
  const log = [];
  const fixes = [];
  
  try {
    // Initialize database
    const supabase = getDb();
    log.push('✓ Database connected');
    
    // Find Vision Care
    const { data: companies, error: companyError } = await supabase
      .from('companies')
      .select('*')
      .or('name.ilike.%vision%,name.ilike.%eyecare%');
    
    if (companyError || !companies || companies.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Vision Care company not found',
        fixes: ['Create Vision Care company in database', 'Check company name spelling'],
        log
      });
    }
    
    const company = companies[0];
    log.push(`✓ Found company: ${company.name}`);
    
    // Test OAuth
    const oauthResult = await testOAuth(company, log);
    
    if (!oauthResult.success) {
      return res.status(200).json({
        success: false,
        stage: oauthResult.stage,
        error: oauthResult.error,
        fixes: oauthResult.fixes,
        log,
        company: {
          id: company.id,
          name: company.name
        }
      });
    }
    
    // Test API
    const apiResult = await testAPI(company, oauthResult.token, log);
    
    if (!apiResult.success) {
      return res.status(200).json({
        success: false,
        stage: 'api',
        error: apiResult.error,
        fixes: apiResult.fixes,
        log,
        company: {
          id: company.id,
          name: company.name
        }
      });
    }
    
    // SUCCESS!
    log.push('\n=== ALL TESTS PASSED ===');
    log.push('✓ OAuth flow working');
    log.push('✓ API connectivity working');
    log.push('✓ Office data retrieved');
    
    return res.status(200).json({
      success: true,
      message: 'All tests passed - Vision Care OAuth is fully functional',
      officeCount: apiResult.officeCount,
      log,
      company: {
        id: company.id,
        name: company.name,
        oauth_host: company.oauth_host,
        api_base_url: company.api_base_url,
        api_path: company.api_path
      },
      nextStep: 'Test office sync in UI at /admin'
    });
    
  } catch (error) {
    log.push(`\n❌ FATAL ERROR: ${error.message}`);
    return res.status(500).json({
      success: false,
      error: error.message,
      stack: error.stack,
      log,
      fixes: ['Unknown system error', 'Check server logs', 'Contact developer']
    });
  }
}

export const config = {
  maxDuration: 30
};
