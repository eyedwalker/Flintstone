/**
 * Test Both Authentication Methods
 * Tests OAuth and Static Token flows to fetch offices
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const results = {
    timestamp: new Date().toISOString(),
    tests: []
  };

  try {
    // Initialize database
    const supabase = getDb();

    // Get all companies
    const { data: companies, error: companiesError } = await supabase
      .from('companies')
      .select('id, name, eyefinity_api_key, eyefinity_api_secret, tenant_uid, oauth_token, api_base_url, api_path, oauth_host')
      .order('name');

    if (companiesError) {
      throw companiesError;
    }

    if (!companies || companies.length === 0) {
      return res.status(200).json({
        success: false,
        message: 'No companies found in database',
        results
      });
    }

    // Test each company
    for (const company of companies) {
      const testResult = {
        companyId: company.id,
        companyName: company.name,
        authMethod: null,
        apiUrl: null,
        success: false,
        officeCount: 0,
        error: null,
        details: {
          // Debug: Show what's in the database
          hasApiKey: !!company.eyefinity_api_key,
          hasApiSecret: !!company.eyefinity_api_secret,
          hasTenantUid: !!company.tenant_uid,
          hasOAuthToken: !!company.oauth_token,
          oauthTokenLength: company.oauth_token?.length || 0,
          apiBaseUrl: company.api_base_url,
          apiPath: company.api_path
        }
      };

      // Determine auth method
      const isStaticToken = !company.eyefinity_api_key && company.oauth_token;
      const isOAuth = company.eyefinity_api_key && company.tenant_uid;

      if (!isStaticToken && !isOAuth) {
        testResult.error = 'No valid credentials configured';
        results.tests.push(testResult);
        continue;
      }

      testResult.authMethod = isStaticToken ? 'Static Token' : 'OAuth';
      testResult.apiUrl = `${company.api_base_url}/${company.api_path}/v2offices`;

      try {
        let token;

        if (isStaticToken) {
          // Static token - use directly
          token = company.oauth_token;
          testResult.details.tokenSource = 'database (static)';
          testResult.details.tokenLength = token?.length || 0;
        } else {
          // OAuth - need to get token via token exchange
          testResult.details.clientId = company.eyefinity_api_key?.substring(0, 10) + '...';
          testResult.details.tenantUid = company.tenant_uid;
          testResult.details.oauthHost = company.oauth_host;

          // Step 1: Get client credentials token
          const tokenUrl = `https://${company.oauth_host}/connect/token`;
          const tokenBody = new URLSearchParams({
            grant_type: 'client_credentials',
            client_id: company.eyefinity_api_key,
            client_secret: company.eyefinity_api_secret,
            scope: 'auth_epm'
          });

          const tokenResponse = await fetch(tokenUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
              'Accept': 'application/json'
            },
            body: tokenBody.toString()
          });

          if (!tokenResponse.ok) {
            throw new Error(`OAuth token failed: ${tokenResponse.status}`);
          }

          const tokenData = await tokenResponse.json();
          testResult.details.clientTokenObtained = true;

          // Step 2: Exchange for EPM token
          const exchangeUrl = `https://${company.oauth_host}/connect/token`;
          const exchangeBody = new URLSearchParams({
            grant_type: 'urn:ietf:params:oauth:grant-type:token-exchange',
            client_id: company.eyefinity_api_key,
            client_secret: company.eyefinity_api_secret,
            scope: 'auth_epm ef.pm_pe_patient_rx ef.pm_pe_resource ef.pm_pe_insurance ef.pm_pe_appointment ef.pm_pe_office_recallreport ef.pm_pe_staff ef.pm_pe_office ef.pm_pe_company ef.pm_pe_order ef.pm_pe_provider ef.pm_pe_patient',
            subject_token: tokenData.access_token,
            subject_token_type: 'urn:ietf:params:oauth:token-type:access_token',
            resource: `urn:${company.tenant_uid}`
          });

          const exchangeResponse = await fetch(exchangeUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
              'Accept': 'application/json'
            },
            body: exchangeBody.toString()
          });

          if (!exchangeResponse.ok) {
            throw new Error(`Token exchange failed: ${exchangeResponse.status}`);
          }

          const exchangeData = await exchangeResponse.json();
          token = exchangeData.access_token;
          testResult.details.epmTokenObtained = true;
          testResult.details.tokenLength = token?.length || 0;
        }

        // Now test fetching offices with the token
        const officesUrl = `${company.api_base_url}/${company.api_path}/v2offices?page=1&pageSize=100`;
        testResult.details.requestUrl = officesUrl;

        const officesResponse = await fetch(officesUrl, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }
        });

        testResult.details.responseStatus = officesResponse.status;

        if (!officesResponse.ok) {
          const errorText = await officesResponse.text();
          throw new Error(`API request failed: ${officesResponse.status} - ${errorText}`);
        }

        const officesData = await officesResponse.json();
        testResult.success = true;
        testResult.officeCount = Array.isArray(officesData) ? officesData.length : (officesData.items?.length || 0);
        testResult.details.responseStructure = Array.isArray(officesData) ? 'array' : 'object';
        
        if (testResult.officeCount > 0) {
          testResult.details.firstOfficeName = Array.isArray(officesData) 
            ? officesData[0]?.Name 
            : officesData.items?.[0]?.Name;
        }

      } catch (err) {
        testResult.error = err.message;
        testResult.details.errorStack = err.stack;
      }

      results.tests.push(testResult);
    }

    // Summary
    const summary = {
      totalCompanies: companies.length,
      successful: results.tests.filter(t => t.success).length,
      failed: results.tests.filter(t => !t.success).length,
      staticTokenTests: results.tests.filter(t => t.authMethod === 'Static Token').length,
      oauthTests: results.tests.filter(t => t.authMethod === 'OAuth').length
    };

    return res.status(200).json({
      success: summary.successful > 0,
      summary,
      results: results.tests
    });

  } catch (error) {
    console.error('[Test] Error:', error);
    return res.status(500).json({
      success: false,
      error: error.message,
      stack: error.stack,
      results
    });
  }
}

export const config = {
  maxDuration: 60 // Allow longer timeout for testing
};
