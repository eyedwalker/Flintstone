/**
 * Check Vision Care Credentials
 * Shows what's in database (masked) and allows updating
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    const supabase = getDb();

    // Find Vision Care / EyeCare 4 U
    const { data: companies, error } = await supabase
      .from('companies')
      .select('*')
      .or('name.ilike.%vision%,name.ilike.%eyecare%');

    if (error || !companies || companies.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Vision Care company not found'
      });
    }

    const company = companies[0];

    // POST: Update credentials
    if (req.method === 'POST') {
      const { client_id, client_secret, tenant_uid } = req.body || {};
      
      if (!client_id || !client_secret || !tenant_uid) {
        return res.status(400).json({
          success: false,
          error: 'Missing required fields: client_id, client_secret, tenant_uid'
        });
      }

      const { data: updated, error: updateError } = await supabase
        .from('companies')
        .update({
          eyefinity_api_key: client_id,
          eyefinity_api_secret: client_secret,
          tenant_uid: tenant_uid
        })
        .eq('id', company.id)
        .select();

      if (updateError) {
        return res.status(500).json({
          success: false,
          error: updateError.message
        });
      }

      return res.status(200).json({
        success: true,
        message: 'Credentials updated successfully',
        company: updated[0].name,
        nextStep: 'Test at: /api/eyefinity/test-vision-care'
      });
    }

    // GET: Show current credentials (masked)
    return res.status(200).json({
      success: true,
      company: {
        id: company.id,
        name: company.name,
        credentials: {
          client_id: company.eyefinity_api_key ? 
            `${company.eyefinity_api_key.substring(0, 15)}...` : 
            'NOT SET',
          client_secret: company.eyefinity_api_secret ? 
            `${company.eyefinity_api_secret.substring(0, 10)}...` : 
            'NOT SET',
          tenant_uid: company.tenant_uid || 'NOT SET',
          oauth_host: company.oauth_host || 'NOT SET',
          api_base_url: company.api_base_url || 'NOT SET',
          api_path: company.api_path || 'al-pe'
        }
      },
      envVarDefaults: {
        client_id: process.env.EPM_CLIENT_ID ? 
          `${process.env.EPM_CLIENT_ID.substring(0, 15)}...` : 
          'NOT SET',
        client_secret: process.env.EPM_CLIENT_SECRET ? 
          '(available in env)' : 
          'NOT SET',
        tenant_uid: process.env.TENANT_UID || 'NOT SET'
      },
      usage: {
        get: 'View current credentials (this endpoint)',
        post: 'Update credentials with JSON body: { client_id, client_secret, tenant_uid }'
      }
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message,
      stack: error.stack
    });
  }
}

export const config = {
  maxDuration: 30
};
