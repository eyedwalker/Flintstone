/**
 * Specific route handler for v2patients endpoints
 * This handles /api/eyefinity/v2patients/* routes that the main [...path].js wasn't catching
 */

// Import the main proxy handler
import mainHandler from '../[...path].js';

export default async function handler(req, res) {
  // Prepend 'v2patients' to the path since this route handles v2patients/* specifically
  const pathSegments = req.query['...path'] || [];
  req.query['...path'] = ['v2patients', ...(Array.isArray(pathSegments) ? pathSegments : [pathSegments])];
  
  console.log('[v2patients Proxy] Forwarding to main handler:', {
    originalPath: pathSegments,
    modifiedPath: req.query['...path'],
    url: req.url
  });
  
  // Use the main proxy handler
  return await mainHandler(req, res);
}
