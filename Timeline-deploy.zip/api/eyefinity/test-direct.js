// Direct Eyefinity API test helper
import { Redis } from '@upstash/redis';

const TOKEN_CACHE_KEY = 'eyefinity:epm_token';

export const config = { maxDuration: 30 };

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const path = req.query.path;
  if (!path) {
    return res.status(400).json({ error: 'Provide "path" query param, e.g. /v2offices?page=1&pageSize=2' });
  }

  const apiBaseUrl = process.env.EYEFINITY_API_URL || 'https://api-sandbox.eyefinity.com';

  try {
    // Step 1: get cached token
    let token = null;
    if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
      const redis = new Redis({
        url: process.env.KV_REST_API_URL,
        token: process.env.KV_REST_API_TOKEN,
      });
      token = await redis.get(TOKEN_CACHE_KEY);
    }

    if (!token) {
      return res.status(400).json({ error: 'No cached token found. Run /api/eyefinity/test-oauth first.' });
    }

    const cleanPath = path.startsWith('/') ? path : `/${path}`;
    const targetUrl = `${apiBaseUrl}/al-pe${cleanPath}`;
    const start = Date.now();

    const response = await fetch(targetUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    const duration = Date.now() - start;
    const contentType = response.headers.get('content-type') || '';
    const body = contentType.includes('application/json')
      ? await response.json()
      : await response.text();

    return res.status(200).json({
      targetUrl,
      status: response.status,
      durationMs: duration,
      body,
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}
