/**
 * Copy Env Var Credentials to Vision Care
 * Fixes database credentials by copying from working env vars
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');

  try {
    const supabase = getDb();

    // Get env var values
    const envCreds = {
      client_id: process.env.EPM_CLIENT_ID,
      client_secret: process.env.EPM_CLIENT_SECRET,
      tenant_uid: process.env.TENANT_UID
    };

    if (!envCreds.client_id || !envCreds.client_secret || !envCreds.tenant_uid) {
      return res.status(500).json({
        success: false,
        error: 'Env vars not configured in Vercel',
        available: {
          client_id: !!envCreds.client_id,
          client_secret: !!envCreds.client_secret,
          tenant_uid: !!envCreds.tenant_uid
        }
      });
    }

    // Update Vision Care / EyeCare 4 U
    const { data, error } = await supabase
      .from('companies')
      .update({
        eyefinity_api_key: envCreds.client_id,
        eyefinity_api_secret: envCreds.client_secret,
        tenant_uid: envCreds.tenant_uid,
        oauth_host: 'api-sandbox.eyefinity.com',
        api_base_url: 'https://api-sandbox.eyefinity.com',
        api_path: 'al-pe'
      })
      .or('name.ilike.%vision%,name.ilike.%eyecare%')
      .select();

    if (error) {
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }

    if (!data || data.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Vision Care company not found'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Credentials copied from env vars to database',
      company: data[0].name,
      updated: {
        client_id: `${envCreds.client_id.substring(0, 15)}...`,
        client_secret: 'Updated (full secret)',
        tenant_uid: envCreds.tenant_uid,
        oauth_host: 'api-sandbox.eyefinity.com',
        api_base_url: 'https://api-sandbox.eyefinity.com'
      },
      nextStep: 'Test at: /api/eyefinity/test-vision-care'
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message,
      stack: error.stack
    });
  }
}

export const config = {
  maxDuration: 30
};
