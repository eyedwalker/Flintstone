export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  
  const config = {
    EPM_CLIENT_ID: process.env.EPM_CLIENT_ID ? `${process.env.EPM_CLIENT_ID.substring(0, 25)}...` : 'NOT SET',
    EPM_CLIENT_SECRET: process.env.EPM_CLIENT_SECRET ? 'SET (hidden)' : 'NOT SET',
    TENANT_UID: process.env.TENANT_UID ? `${process.env.TENANT_UID.substring(0, 8)}...` : 'NOT SET',
    EYEFINITY_API_URL: process.env.EYEFINITY_API_URL || 'NOT SET (using default)',
    OAUTH_HOST: process.env.OAUTH_HOST || 'NOT SET (using default)',
    KV_REST_API_URL: process.env.KV_REST_API_URL ? 'SET' : 'NOT SET',
    KV_REST_API_TOKEN: process.env.KV_REST_API_TOKEN ? 'SET' : 'NOT SET',
  };

  const redisConfigured = !!(process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN);

  return res.status(200).json({ 
    status: 'Eyefinity Config Check',
    config,
    redisConfigured,
    allSet: !!(process.env.EPM_CLIENT_ID && process.env.EPM_CLIENT_SECRET && process.env.TENANT_UID)
  });
}
