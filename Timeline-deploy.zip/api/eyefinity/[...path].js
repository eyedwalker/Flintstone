/**
 * Eyefinity API Proxy - Vercel Serverless Function
 *
 * Implements OAuth 2.0 Token Exchange flow:
 * 1. Client Credentials -> Get initial token
 * 2. Token Exchange -> Get EPM token with tenant context
 *
 * Token Caching:
 * - Uses Vercel KV (Redis) for secure, persistent token storage
 * - Falls back to in-memory if KV not configured
 * - Tokens cached per company for ~25 minutes (with 5 min buffer)
 *
 * Multi-tenant Support:
 * - Reads credentials from Supabase database per company
 * - Falls back to env vars if company ID not provided
 * - Company ID passed via X-Company-Id header
 *
 * Environment Variables Required:
 * - VITE_SUPABASE_URL: Supabase project URL
 * - VITE_SUPABASE_ANON_KEY: Supabase anon key
 * - KV_REST_API_URL: Upstash Redis URL (for persistent caching)
 * - KV_REST_API_TOKEN: Upstash Redis token
 *
 * Optional (fallback if no company specified):
 * - EPM_CLIENT_ID, EPM_CLIENT_SECRET, TENANT_UID, OAUTH_HOST, EYEFINITY_API_URL
 */

import { getCompanyCredentials, getEpmToken, invalidateCachedToken } from '../_lib/eyefinity-auth.js';

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Auth-Token, Authorization, X-Company-Id');

  // Handle OPTIONS preflight
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    // Get company ID from header (optional, falls back to env vars)
    const companyId = req.headers['x-company-id'] || 'default';

    // Fetch credentials from database (or fallback to env vars)
    const creds = await getCompanyCredentials(companyId !== 'default' ? companyId : null);

    // Get the path segments after /api/eyefinity/
    const pathParam = req.query['...path'];
    const pathString = Array.isArray(pathParam) ? pathParam.join('/') : pathParam || '';

    // Get other query params (exclude the path param)
    const otherParams = { ...req.query };
    delete otherParams['...path'];

    // Build query string
    const filteredParams = new URLSearchParams();
    for (const [key, value] of Object.entries(otherParams)) {
      if (Array.isArray(value)) {
        value.forEach(v => filteredParams.append(key, v));
      } else {
        filteredParams.append(key, value);
      }
    }
    const queryString = filteredParams.toString() ? `?${filteredParams.toString()}` : '';

    // Build target URL using company-specific API base URL and path
    const targetUrl = `${creds.apiBaseUrl}/${creds.apiPath}/${pathString}${queryString}`;

    console.log('[Eyefinity Proxy] Request:', {
      method: req.method,
      companyId,
      path: pathString,
      apiPath: creds.apiPath,
      target: targetUrl,
    });

    // Get OAuth token (cached or fresh) using company credentials
    const authToken = await getEpmToken(companyId, creds);

    // Forward the request
    const fetchOptions = {
      method: req.method,
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    };

    // Include body for non-GET requests
    if (req.method !== 'GET' && req.method !== 'HEAD' && req.body) {
      fetchOptions.body = JSON.stringify(req.body);
    }

    // Log full request details
    console.log('[Debug] Full API Request:', {
      url: targetUrl,
      method: req.method,
      token: authToken.substring(0, 30) + '...' + authToken.substring(authToken.length - 10),
      tokenLength: authToken.length,
      headers: fetchOptions.headers
    });

    const response = await fetch(targetUrl, fetchOptions);

    console.log('[Eyefinity Proxy] Response:', response.status);

    // Handle 401 - invalidate cache and retry once
    if (response.status === 401) {
      console.log(`[Eyefinity Proxy] Token expired for company ${companyId}, refreshing...`);
      await invalidateCachedToken(companyId);

      const newToken = await getEpmToken(companyId, creds);

      // Reconstruct fetch options with new token
      const retryOptions = {
        method: req.method,
        headers: {
          'Authorization': `Bearer ${newToken}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      };

      // Re-add body for non-GET requests
      if (req.method !== 'GET' && req.method !== 'HEAD' && req.body) {
        retryOptions.body = JSON.stringify(req.body);
      }

      const retryResponse = await fetch(targetUrl, retryOptions);
      const retryData = await retryResponse.json().catch(() => retryResponse.text());
      return res.status(retryResponse.status).json(retryData);
    }

    // Get response data with timeout
    const contentType = response.headers.get('content-type');
    let data;

    const parseController = new AbortController();
    const parseTimeout = setTimeout(() => parseController.abort(), 5000);

    try {
      if (contentType?.includes('application/json')) {
        data = await Promise.race([
          response.json(),
          new Promise((_, reject) => setTimeout(() => reject(new Error('Response parse timeout')), 5000))
        ]);
      } else {
        data = await Promise.race([
          response.text(),
          new Promise((_, reject) => setTimeout(() => reject(new Error('Response parse timeout')), 5000))
        ]);
      }
      clearTimeout(parseTimeout);
    } catch (parseError) {
      clearTimeout(parseTimeout);
      console.error('[Proxy] Response parse error:', parseError.message);
      data = { error: 'Failed to parse response', status: response.status };
    }

    // Forward pagination headers
    ['x-pagination', 'x-total-count'].forEach(header => {
      const value = response.headers.get(header);
      if (value) res.setHeader(header, value);
    });

    return res.status(response.status).json(data);

  } catch (error) {
    console.error('[Eyefinity Proxy] Error:', error.message);
    return res.status(500).json({
      error: 'Proxy error',
      message: error.message,
    });
  }
}

export const config = {
  api: {
    bodyParser: true,
  },
  maxDuration: 30, // Extend timeout to 30s for OAuth + API calls
};
