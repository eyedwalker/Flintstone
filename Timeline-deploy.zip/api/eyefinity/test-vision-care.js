/**
 * Test Vision Care OAuth Flow
 * Verify OAuth token exchange and office fetch work end-to-end
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const log = [];
  
  try {
    // Initialize database
    const supabase = getDb();

    log.push('✓ Database connected');

    // Find Vision Care company (might be "Vision Care" or "EyeCare 4 U")
    const { data: companies, error: companiesError } = await supabase
      .from('companies')
      .select('*')
      .or('name.ilike.%vision%,name.ilike.%eyecare%');

    if (companiesError || !companies || companies.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Vision Care company not found',
        availableCompanies: companies || []
      });
    }

    const company = companies[0];
    log.push(`✓ Found company: ${company.name} (ID: ${company.id})`);

    // Check OAuth credentials
    if (!company.eyefinity_api_key || !company.eyefinity_api_secret || !company.tenant_uid) {
      return res.status(400).json({
        success: false,
        error: 'OAuth credentials incomplete',
        company: company.name,
        has: {
          apiKey: !!company.eyefinity_api_key,
          apiSecret: !!company.eyefinity_api_secret,
          tenantUid: !!company.tenant_uid,
          oauthHost: company.oauth_host,
          apiBaseUrl: company.api_base_url
        }
      });
    }

    log.push(`✓ OAuth credentials found`);
    log.push(`  OAuth Host: ${company.oauth_host}`);
    log.push(`  API Base URL: ${company.api_base_url}`);
    log.push(`  API Path: ${company.api_path || 'al-pe'}`);

    // Step 1: Get client credentials token
    log.push('\n--- Step 1: Client Credentials Token ---');
    
    const EPM_SCOPES = 'auth_epm ef.pm_pe_patient_rx ef.pm_pe_resource ef.pm_pe_insurance ef.pm_pe_appointment ef.pm_pe_office_recallreport ef.pm_pe_staff ef.pm_pe_office ef.pm_pe_company ef.pm_pe_order ef.pm_pe_provider ef.pm_pe_patient';
    
    const credentials = Buffer.from(`${company.eyefinity_api_key}:${company.eyefinity_api_secret}`).toString('base64');
    const tokenUrl = `https://${company.oauth_host}/as/token.oauth2`;
    
    log.push(`  Token URL: ${tokenUrl}`);
    
    const ccResponse = await fetch(tokenUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: `grant_type=client_credentials&scope=${encodeURIComponent(EPM_SCOPES)}`
    });

    if (!ccResponse.ok) {
      const errorText = await ccResponse.text();
      log.push(`  ✗ Failed: ${ccResponse.status}`);
      log.push(`  Error: ${errorText}`);
      return res.status(200).json({
        success: false,
        stage: 'client_credentials',
        status: ccResponse.status,
        error: errorText,
        log
      });
    }

    const ccData = await ccResponse.json();
    const clientToken = ccData.access_token || ccData.accesstoken;
    
    log.push(`  ✓ Client token obtained (${clientToken.substring(0, 20)}...)`);

    // Step 2: Token exchange for EPM token
    log.push('\n--- Step 2: Token Exchange ---');
    
    const exchangeBody = new URLSearchParams({
      'grant_type': 'urn:ietf:params:oauth:grant-type:token-exchange',
      'subject_token': clientToken,
      'subject_token_type': 'urn:ietf:params:oauth:token-type:access_token',
      'scope': EPM_SCOPES,
      'resource': 'https://VspEpmToken',
    }).toString();

    const exchangeResponse = await fetch(tokenUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'tenantuid': company.tenant_uid,
      },
      body: exchangeBody
    });

    if (!exchangeResponse.ok) {
      const errorText = await exchangeResponse.text();
      log.push(`  ✗ Failed: ${exchangeResponse.status}`);
      log.push(`  Error: ${errorText}`);
      return res.status(200).json({
        success: false,
        stage: 'token_exchange',
        status: exchangeResponse.status,
        error: errorText,
        log
      });
    }

    const exchangeData = await exchangeResponse.json();
    const epmToken = exchangeData.access_token || exchangeData.accesstoken;
    
    log.push(`  ✓ EPM token obtained (${epmToken.substring(0, 20)}...)`);

    // Step 3: Test API call - fetch offices
    log.push('\n--- Step 3: Fetch Offices ---');
    
    const apiPath = company.api_path || 'al-pe';
    const officesUrl = `${company.api_base_url}/${apiPath}/v2offices?page=1&pageSize=100`;
    
    log.push(`  URL: ${officesUrl}`);
    
    const officesResponse = await fetch(officesUrl, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${epmToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });

    log.push(`  Response: ${officesResponse.status}`);

    if (!officesResponse.ok) {
      const errorText = await officesResponse.text();
      log.push(`  ✗ Failed to fetch offices`);
      log.push(`  Error: ${errorText.substring(0, 500)}`);
      return res.status(200).json({
        success: false,
        stage: 'api_call',
        status: officesResponse.status,
        error: errorText,
        log
      });
    }

    const offices = await officesResponse.json();
    const officeCount = Array.isArray(offices) ? offices.length : (offices.items?.length || 0);
    
    log.push(`  ✓ Success! Found ${officeCount} offices`);
    
    if (officeCount > 0) {
      const firstOffice = Array.isArray(offices) ? offices[0] : offices.items?.[0];
      log.push(`  First office: ${firstOffice?.Name || firstOffice?.OfficeNumber || 'N/A'}`);
    }

    return res.status(200).json({
      success: true,
      company: {
        id: company.id,
        name: company.name,
        oauthHost: company.oauth_host,
        apiBaseUrl: company.api_base_url,
        apiPath
      },
      offices: {
        count: officeCount,
        sample: officeCount > 0 ? (Array.isArray(offices) ? offices.slice(0, 3) : offices.items?.slice(0, 3)) : []
      },
      log
    });

  } catch (error) {
    log.push(`\n✗ ERROR: ${error.message}`);
    return res.status(500).json({
      success: false,
      error: error.message,
      stack: error.stack,
      log
    });
  }
}

export const config = {
  maxDuration: 30
};
