// Super minimal - ONLY reads from Redis, no API call
import { Redis } from '@upstash/redis';

const TOKEN_CACHE_KEY = 'eyefinity:epm_token';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  const start = Date.now();
  
  try {
    const redis = new Redis({
      url: process.env.KV_REST_API_URL,
      token: process.env.KV_REST_API_TOKEN,
    });
    
    const token = await redis.get(TOKEN_CACHE_KEY);
    
    return res.status(200).json({
      hasToken: !!token,
      tokenPreview: token ? token.substring(0, 20) + '...' : null,
      duration: Date.now() - start,
    });
  } catch (e) {
    return res.status(200).json({ error: e.message, duration: Date.now() - start });
  }
}
