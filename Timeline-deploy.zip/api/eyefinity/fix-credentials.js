/**
 * Auto-fix Mixed Credentials
 * Cleans up West Eye static token and fixes EyeCare 4 U OAuth host
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const fixes = [];
  const errors = [];

  try {
    // Initialize database
    const supabase = getDb();

    // Fix 1: Clean up West Eye - remove OAuth credentials, keep static token
    const { data: westEye, error: westEyeError } = await supabase
      .from('companies')
      .update({
        eyefinity_api_key: null,
        eyefinity_api_secret: null,
        tenant_uid: null,
        oauth_host: null
      })
      .eq('name', 'West Eye')
      .select();

    if (westEyeError) {
      errors.push({
        company: 'West Eye',
        fix: 'Clear OAuth credentials',
        error: westEyeError.message
      });
    } else if (westEye && westEye.length > 0) {
      fixes.push({
        company: 'West Eye',
        fix: 'Cleared OAuth credentials (api_key, api_secret, tenant_uid, oauth_host)',
        details: {
          kept: 'oauth_token (static bearer token)',
          apiBaseUrl: westEye[0].api_base_url,
          apiPath: westEye[0].api_path,
          tokenLength: westEye[0].oauth_token?.length || 0
        }
      });
    }

    // Fix 2: Update EyeCare 4 U OAuth host
    const { data: eyeCare, error: eyeCareError } = await supabase
      .from('companies')
      .update({
        oauth_host: 'auth.eyefinity.com'
      })
      .eq('name', 'EyeCare 4 U')
      .select();

    if (eyeCareError) {
      errors.push({
        company: 'EyeCare 4 U',
        fix: 'Update OAuth host',
        error: eyeCareError.message
      });
    } else if (eyeCare && eyeCare.length > 0) {
      fixes.push({
        company: 'EyeCare 4 U',
        fix: 'Updated OAuth host from api-sandbox.eyefinity.com to auth.eyefinity.com',
        details: {
          newOAuthHost: eyeCare[0].oauth_host,
          apiBaseUrl: eyeCare[0].api_base_url,
          hasCredentials: {
            apiKey: !!eyeCare[0].eyefinity_api_key,
            apiSecret: !!eyeCare[0].eyefinity_api_secret,
            tenantUid: !!eyeCare[0].tenant_uid
          }
        }
      });
    }

    // Get final state of both companies
    const { data: companies, error: companiesError } = await supabase
      .from('companies')
      .select('id, name, eyefinity_api_key, eyefinity_api_secret, tenant_uid, oauth_token, oauth_host, api_base_url, api_path')
      .in('name', ['West Eye', 'EyeCare 4 U'])
      .order('name');

    if (companiesError) {
      errors.push({
        fix: 'Verify fixes',
        error: companiesError.message
      });
    }

    return res.status(200).json({
      success: errors.length === 0,
      timestamp: new Date().toISOString(),
      fixesApplied: fixes.length,
      errors: errors.length,
      fixes,
      errors: errors.length > 0 ? errors : undefined,
      finalState: companies ? companies.map(c => ({
        name: c.name,
        authMethod: (!c.eyefinity_api_key && c.oauth_token) ? 'Static Token' : 
                    (c.eyefinity_api_key && c.tenant_uid) ? 'OAuth' : 'Unconfigured',
        hasStaticToken: !!c.oauth_token,
        hasOAuthCreds: !!(c.eyefinity_api_key && c.tenant_uid),
        oauthHost: c.oauth_host,
        apiBaseUrl: c.api_base_url,
        apiPath: c.api_path
      })) : undefined,
      nextStep: 'Navigate to https://patientcare-teal.vercel.app/api/eyefinity/test-both-auth to verify both auth methods work'
    });

  } catch (error) {
    console.error('[Fix] Error:', error);
    return res.status(500).json({
      success: false,
      error: error.message,
      stack: error.stack,
      fixes,
      errors
    });
  }
}

export const config = {
  maxDuration: 30
};
