// Test ONLY the Eyefinity API call (get token from Redis, then call API)
import { Redis } from '@upstash/redis';

const TOKEN_CACHE_KEY = 'eyefinity:epm_token';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  const start = Date.now();
  const apiUrl = process.env.EYEFINITY_API_URL || 'https://api-sandbox.eyefinity.com';
  
  try {
    // Step 1: Get token from Redis (should be ~100ms)
    const redis = new Redis({
      url: process.env.KV_REST_API_URL,
      token: process.env.KV_REST_API_TOKEN,
    });
    const token = await redis.get(TOKEN_CACHE_KEY);
    const redisTime = Date.now() - start;
    
    if (!token) {
      return res.status(200).json({ error: 'No cached token', redisTime });
    }
    
    // Step 2: Call Eyefinity API
    const apiStart = Date.now();
    const apiResponse = await fetch(`${apiUrl}/al-pe/v2offices?page=1&pageSize=2`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });
    const apiTime = Date.now() - apiStart;
    
    const data = await apiResponse.json();
    
    return res.status(200).json({
      success: true,
      redisTime,
      apiTime,
      apiStatus: apiResponse.status,
      officeCount: Array.isArray(data) ? data.length : 0,
      totalTime: Date.now() - start,
    });
  } catch (e) {
    return res.status(200).json({ error: e.message, duration: Date.now() - start });
  }
}
