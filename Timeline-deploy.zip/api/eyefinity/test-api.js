// Minimal API test - Uses cached token from Redis, then makes API call
import { Redis } from '@upstash/redis';

const TOKEN_CACHE_KEY = 'eyefinity:epm_token';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  
  const startTime = Date.now();
  const apiUrl = process.env.EYEFINITY_API_URL || 'https://api-sandbox.eyefinity.com';
  const log = (msg) => console.log(`[TestAPI] ${msg}`);
  
  try {
    // Get cached token from Redis
    log('Getting cached token from Redis...');
    let epmToken = null;
    
    if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
      const redis = new Redis({
        url: process.env.KV_REST_API_URL,
        token: process.env.KV_REST_API_TOKEN,
      });
      epmToken = await redis.get(TOKEN_CACHE_KEY);
      log(`Token from Redis: ${epmToken ? 'found' : 'not found'} (${Date.now() - startTime}ms)`);
    }
    
    if (!epmToken) {
      return res.status(200).json({
        error: 'No cached token. Call /api/eyefinity/test-oauth first to seed the cache.',
        duration: Date.now() - startTime,
      });
    }
    
    // API Call with cached token
    log('Making API call to offices...');
    const apiResponse = await fetch(`${apiUrl}/al-pe/v2offices?page=1&pageSize=2`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${epmToken}`,
        'Content-Type': 'application/json',
      },
    });
    const apiData = await apiResponse.json();
    log(`API call done: ${Date.now() - startTime}ms`);
    
    return res.status(200).json({
      success: true,
      tokenSource: 'redis_cache',
      apiStatus: apiResponse.status,
      hasOffices: Array.isArray(apiData),
      officeCount: Array.isArray(apiData) ? apiData.length : 0,
      duration: Date.now() - startTime,
    });
  } catch (e) {
    log(`Error: ${e.message}`);
    return res.status(200).json({
      error: e.message,
      duration: Date.now() - startTime,
    });
  }
}
