import { kv } from '../_lib/kv.js';

const TOKEN_CACHE_KEY = 'eyefinity:epm_token';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  
  const startTime = Date.now();
  const log = (msg) => console.log(`[${Date.now() - startTime}ms] ${msg}`);
  
  // GET - check cached token
  if (req.method === 'GET') {
    try {
      log('Checking KV cache...');
      const cached = await kv.get(TOKEN_CACHE_KEY);
      log('KV check complete');
      return res.status(200).json({
        hasCachedToken: !!cached,
        tokenPreview: cached ? `${String(cached).substring(0, 20)}...` : null,
        duration: Date.now() - startTime,
      });
    } catch (e) {
      return res.status(500).json({ error: e.message, duration: Date.now() - startTime });
    }
  }
  
  // DELETE - clear cached token
  if (req.method === 'DELETE') {
    try {
      log('Deleting from KV...');
      await kv.del(TOKEN_CACHE_KEY);
      log('Delete complete');
      return res.status(200).json({ success: true, message: 'Token cache cleared', duration: Date.now() - startTime });
    } catch (e) {
      return res.status(500).json({ error: e.message, duration: Date.now() - startTime });
    }
  }
  
  // POST - test OAuth flow with timeout
  if (req.method === 'POST') {
    const oauthHost = process.env.OAUTH_HOST || 'api-sandbox.eyefinity.com';
    const clientId = process.env.EPM_CLIENT_ID;
    const clientSecret = process.env.EPM_CLIENT_SECRET;
    
    try {
      log(`Starting OAuth to ${oauthHost}...`);
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);
      
      // Use Basic auth header (matches working local proxy)
      const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
      const body = `grant_type=client_credentials&scope=${encodeURIComponent('auth_epm ef.pm_pe_office')}`;
      
      const response = await fetch(`https://${oauthHost}/as/token.oauth2`, {
        method: 'POST',
        headers: { 
          'Authorization': `Basic ${credentials}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body,
        signal: controller.signal,
      });
      
      clearTimeout(timeoutId);
      log(`OAuth response: ${response.status}`);

      const text = await response.text();
      let data;
      try { data = JSON.parse(text); } catch { data = text; }
      
      return res.status(200).json({
        oauthHost,
        status: response.status,
        success: response.ok,
        response: data,
        duration: Date.now() - startTime,
      });
    } catch (e) {
      log(`OAuth error: ${e.message}`);
      return res.status(500).json({ 
        error: e.message, 
        isTimeout: e.name === 'AbortError',
        duration: Date.now() - startTime 
      });
    }
  }
  
  return res.status(405).json({ error: 'Use GET to check, DELETE to clear, POST to test OAuth' });
}
