// Full OAuth test - Step 1 + Step 2 token exchange + cache in Redis
import { Redis } from '@upstash/redis';

export const config = { maxDuration: 30 };

const EPM_SCOPES = 'auth_epm ef.pm_pe_patient_rx ef.pm_pe_resource ef.pm_pe_insurance ef.pm_pe_appointment ef.pm_pe_office_recallreport ef.pm_pe_staff ef.pm_pe_office ef.pm_pe_company ef.pm_pe_order ef.pm_pe_provider ef.pm_pe_patient';
const TOKEN_CACHE_KEY = 'eyefinity:epm_token';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  
  const startTime = Date.now();
  const oauthHost = process.env.OAUTH_HOST || 'api-sandbox.eyefinity.com';
  const clientId = process.env.EPM_CLIENT_ID;
  const clientSecret = process.env.EPM_CLIENT_SECRET;
  const tenantUid = process.env.TENANT_UID;
  
  if (!clientId || !clientSecret) {
    return res.status(200).json({ error: 'Missing credentials', duration: Date.now() - startTime });
  }
  
  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  
  try {
    // Step 1: Client Credentials
    console.log(`[TestOAuth] Step 1: Client credentials to ${oauthHost}...`);
    const step1Body = `grant_type=client_credentials&scope=${encodeURIComponent(EPM_SCOPES)}`;
    
    const step1Response = await fetch(`https://${oauthHost}/as/token.oauth2`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: step1Body,
    });
    
    const step1Data = await step1Response.json();
    const ccToken = step1Data.access_token || step1Data.accesstoken;
    
    if (!ccToken) {
      return res.status(200).json({
        step: 1,
        error: 'No token in response',
        response: step1Data,
        duration: Date.now() - startTime,
      });
    }
    
    console.log(`[TestOAuth] Step 1 success, got CC token`);
    
    // Step 2: Token Exchange
    console.log(`[TestOAuth] Step 2: Token exchange with tenant ${tenantUid}...`);
    const step2Body = new URLSearchParams({
      'grant_type': 'urn:ietf:params:oauth:grant-type:token-exchange',
      'subject_token': ccToken,
      'subject_token_type': 'urn:ietf:params:oauth:token-type:access_token',
      'scope': EPM_SCOPES,
      'resource': 'https://VspEpmToken',
    }).toString();
    
    const step2Response = await fetch(`https://${oauthHost}/as/token.oauth2`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'tenantuid': tenantUid || '',
      },
      body: step2Body,
    });
    
    const step2Data = await step2Response.json();
    const epmToken = step2Data.access_token || step2Data.accesstoken;
    const expiresIn = step2Data.expires_in || 1799;
    
    // Cache token in Redis for main proxy to use
    let cached = false;
    if (epmToken && process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
      try {
        const redis = new Redis({
          url: process.env.KV_REST_API_URL,
          token: process.env.KV_REST_API_TOKEN,
        });
        const ttl = expiresIn - 300; // 5 min buffer
        await redis.set(TOKEN_CACHE_KEY, epmToken, { ex: ttl });
        cached = true;
        console.log(`[TestOAuth] Token cached in Redis (TTL: ${ttl}s)`);
      } catch (e) {
        console.warn('[TestOAuth] Redis cache failed:', e.message);
      }
    }
    
    return res.status(200).json({
      oauthHost,
      tenantUid: tenantUid ? `${tenantUid.substring(0, 8)}...` : 'NOT SET',
      step1: { status: step1Response.status, hasToken: !!ccToken },
      step2: { 
        status: step2Response.status, 
        hasToken: !!epmToken,
        error: step2Data.error || null,
        errorDesc: step2Data.error_description || null,
      },
      cached,
      duration: Date.now() - startTime,
    });
  } catch (e) {
    console.log(`[TestOAuth] Error: ${e.name} - ${e.message}`);
    return res.status(200).json({
      error: e.message,
      duration: Date.now() - startTime,
    });
  }
}
