// Check if token exists in Redis cache
import { Redis } from '@upstash/redis';

const TOKEN_CACHE_KEY = 'eyefinity:epm_token';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  
  const result = {
    hasEnvVars: !!(process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN),
    cachedToken: null,
    error: null,
  };
  
  if (result.hasEnvVars) {
    try {
      const redis = new Redis({
        url: process.env.KV_REST_API_URL,
        token: process.env.KV_REST_API_TOKEN,
      });
      const token = await redis.get(TOKEN_CACHE_KEY);
      result.cachedToken = token ? `${token.substring(0, 20)}...` : null;
    } catch (e) {
      result.error = e.message;
    }
  }
  
  return res.status(200).json(result);
}
