/**
 * Fix api_path for all companies
 * Sets api_path to 'al-pe' for any company that has NULL
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');

  try {
    const supabase = getDb();

    // Update all companies with NULL api_path to 'al-pe'
    const { data, error } = await supabase
      .from('companies')
      .update({
        api_path: 'al-pe'
      })
      .is('api_path', null)
      .select();

    if (error) {
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }

    // Also ensure Vision Care has correct api_path
    const { data: visionCare, error: vcError } = await supabase
      .from('companies')
      .update({
        api_path: 'al-pe'
      })
      .or('name.ilike.%vision%,name.ilike.%eyecare%')
      .select();

    return res.status(200).json({
      success: true,
      message: 'api_path set to al-pe for all companies',
      updatedCompanies: data || [],
      visionCareUpdated: visionCare || [],
      nextStep: 'Test office sync in UI'
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message,
      stack: error.stack
    });
  }
}

export const config = {
  maxDuration: 30
};
