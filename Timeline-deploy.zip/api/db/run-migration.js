/**
 * Database Migration Runner
 * POST /api/db/run-migration - Execute frame scanner migration
 * 
 * Uses Supabase service key for DDL operations
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });

  const supabase = getDb();
  const results = [];

  try {
    // Step 1: Create frame_catalog table
    const { error: e1 } = await supabase.rpc('exec_sql', { sql: `
      CREATE TABLE IF NOT EXISTS frame_catalog (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        upc_code VARCHAR(13) UNIQUE NOT NULL,
        manufacturer VARCHAR(255),
        brand VARCHAR(255),
        model_name VARCHAR(255),
        model_number VARCHAR(100),
        color_name VARCHAR(100),
        color_code VARCHAR(50),
        lens_width INTEGER,
        bridge_width INTEGER,
        temple_length INTEGER,
        frame_width INTEGER,
        material VARCHAR(100),
        frame_type VARCHAR(50),
        shape VARCHAR(50),
        wholesale_price DECIMAL(10,2),
        retail_price DECIMAL(10,2),
        image_url TEXT,
        additional_images JSONB DEFAULT '[]',
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `});

    if (e1) {
      // If rpc doesn't exist, try creating tables via insert/select pattern
      results.push({ table: 'frame_catalog', method: 'rpc', error: e1.message });
      
      // Fallback: Try to verify table exists via select
      const { error: selectErr } = await supabase.from('frame_catalog').select('id').limit(1);
      if (selectErr && selectErr.code === '42P01') {
        results.push({ table: 'frame_catalog', status: 'TABLE_NOT_EXISTS', hint: 'Run migration SQL manually in Supabase SQL Editor' });
      } else if (!selectErr) {
        results.push({ table: 'frame_catalog', status: 'ALREADY_EXISTS' });
      } else {
        results.push({ table: 'frame_catalog', status: 'CHECK_FAILED', error: selectErr.message });
      }
    } else {
      results.push({ table: 'frame_catalog', status: 'CREATED' });
    }

    // Check each table existence via select
    const tables = [
      'frame_catalog',
      'patient_favorite_frames', 
      'patient_measurements',
      'patient_scanner_tokens',
      'patient_face_profiles'
    ];

    const tableStatus = {};
    for (const table of tables) {
      const { error } = await supabase.from(table).select('id').limit(1);
      if (error && error.code === '42P01') {
        tableStatus[table] = 'MISSING';
      } else if (error) {
        tableStatus[table] = `ERROR: ${error.message}`;
      } else {
        tableStatus[table] = 'EXISTS';
      }
    }

    return res.status(200).json({
      message: 'Migration check complete',
      tableStatus,
      results,
      hint: tableStatus.frame_catalog === 'MISSING' 
        ? 'Tables do not exist. Please run the SQL migration in Supabase SQL Editor: src/lib/db/migration-frame-scanner.sql'
        : 'Tables appear to exist already.'
    });

  } catch (error) {
    console.error('[Migration] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
