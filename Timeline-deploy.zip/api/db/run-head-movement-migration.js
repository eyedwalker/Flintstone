// API endpoint to run the head movement calibration database migrations
import { getDb } from '../_lib/db.js';
import fs from 'fs';
import path from 'path';

export default async function handler(req, res) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Check for service key - only admin should be able to run migrations
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid authorization token' });
  }

  const token = authHeader.substring(7);
  const serviceKey = process.env.SUPABASE_SERVICE_KEY;
  if (token !== serviceKey) {
    return res.status(403).json({ error: 'Invalid service key' });
  }

  try {
    // Initialize database client
    const supabase = getDb();

    // Read the SQL migration file
    const migrationPath = path.join(process.cwd(), 'src', 'lib', 'db', 'migration-head-movement.sql');
    let sql;
    
    try {
      sql = fs.readFileSync(migrationPath, 'utf8');
    } catch (error) {
      return res.status(500).json({ 
        error: 'Failed to read migration file',
        details: error.message
      });
    }

    // Check if the required tables exist
    const { data: tableCheck, error: tableError } = await supabase
      .from('patient_measurements')
      .select('id')
      .limit(1);

    if (tableError) {
      return res.status(500).json({ 
        error: 'Error checking required tables',
        details: tableError.message,
        hint: 'Make sure the patient_measurements table exists' 
      });
    }

    // Execute the SQL migration
    const { error: migrationError } = await supabase.rpc('exec_sql', {
      sql_query: sql
    });

    if (migrationError) {
      return res.status(500).json({ 
        error: 'Migration failed',
        details: migrationError.message 
      });
    }

    // Check if new columns were created successfully
    const { data: columnsCheck, error: columnsError } = await supabase
      .from('patient_measurements')
      .select('movement_sequence, depth_map, has_3d_data')
      .limit(1);

    if (columnsError) {
      return res.status(500).json({ 
        error: 'Failed to verify migration',
        details: columnsError.message,
        hint: 'The SQL execution appeared to succeed, but the new columns could not be accessed'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Head movement calibration database migration completed successfully',
      tables_modified: ['patient_measurements', 'patient_face_profiles', 'patient_movement_frames'],
      columns_added: {
        patient_measurements: ['movement_sequence', 'depth_map', 'has_3d_data'],
        patient_face_profiles: ['depth_enhanced_geometry', 'movement_quality_score', 'reference_frame_id'],
      }
    });

  } catch (error) {
    console.error('Unexpected error during migration:', error);
    return res.status(500).json({ 
      error: 'Unexpected error during migration',
      details: error.message
    });
  }
}
