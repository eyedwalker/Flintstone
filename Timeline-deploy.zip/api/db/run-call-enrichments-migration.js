/**
 * Migration Runner: Create call_enrichments table
 * POST /api/db/run-call-enrichments-migration
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });

  const supabase = getDb();

  try {
    // Check if table already exists
    const { error: checkError } = await supabase.from('call_enrichments').select('id').limit(1);

    if (!checkError) {
      return res.status(200).json({
        status: 'EXISTS',
        message: 'call_enrichments table already exists'
      });
    }

    if (checkError.code !== '42P01') {
      // Some other error (not "table doesn't exist")
      return res.status(200).json({
        status: 'EXISTS_WITH_WARNING',
        message: 'Table seems to exist but had a query error',
        error: checkError.message,
      });
    }

    // Table doesn't exist - try to create via RPC
    const { error: createError } = await supabase.rpc('exec_sql', { sql: `
      CREATE TABLE IF NOT EXISTS call_enrichments (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id UUID,
        office_id UUID,
        call_sid TEXT NOT NULL UNIQUE,
        from_phone TEXT,
        to_phone TEXT,
        direction TEXT,
        duration_seconds INTEGER,
        sentiment_score NUMERIC(3,1),
        emotion TEXT,
        emotion_confidence NUMERIC(3,2),
        escalation_needed BOOLEAN DEFAULT FALSE,
        escalation_reason TEXT,
        ai_performance_score NUMERIC(3,1),
        staff_rating TEXT,
        staff_notes TEXT,
        reviewed_by TEXT,
        reviewed_at TIMESTAMPTZ,
        transcript TEXT,
        recording_url TEXT,
        call_started_at TIMESTAMPTZ,
        created_at TIMESTAMPTZ DEFAULT NOW(),
        updated_at TIMESTAMPTZ DEFAULT NOW()
      );

      CREATE INDEX IF NOT EXISTS idx_call_enrichments_call_sid ON call_enrichments(call_sid);
      CREATE INDEX IF NOT EXISTS idx_call_enrichments_created_at ON call_enrichments(created_at DESC);
    `});

    if (createError) {
      return res.status(200).json({
        status: 'RPC_FAILED',
        message: 'Could not create table via RPC. Run the SQL manually in Supabase SQL Editor.',
        sqlFile: 'src/lib/db/migration-call-enrichments.sql',
        error: createError.message,
      });
    }

    return res.status(200).json({
      status: 'CREATED',
      message: 'call_enrichments table created successfully',
    });

  } catch (error) {
    console.error('[Migration] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
