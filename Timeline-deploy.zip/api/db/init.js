/**
 * Database Initialization API
 * Creates tables and seeds initial data
 * 
 * POST /api/db/init - Initialize database schema
 * GET /api/db/init - Check database status
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    const supabase = getDb();

    if (req.method === 'GET') {
      // Check database status
      const { data, error } = await supabase.from('accounts').select('id').limit(1);
      
      return res.status(200).json({
        connected: !error,
        tablesExist: !error,
        error: error?.message,
      });
    }

    if (req.method === 'POST') {
      const { action, seedData } = req.body || {};

      if (action === 'seed') {
        // Seed initial data
        const result = await seedInitialData(supabase, seedData);
        return res.status(200).json(result);
      }

      // Schema creation would be done via Supabase dashboard or migrations
      // This endpoint is mainly for seeding and status checks
      return res.status(200).json({
        message: 'Use Supabase dashboard to run schema.sql',
        hint: 'Copy contents of src/lib/db/schema.sql to SQL Editor in Supabase',
      });
    }

    return res.status(405).json({ error: 'Method not allowed' });

  } catch (error) {
    console.error('[DB Init] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}

/**
 * Seed initial data for a new installation
 */
async function seedInitialData(supabase, seedData = {}) {
  const results = { created: [], errors: [] };

  try {
    // Create default account if not exists
    const accountName = seedData.accountName || 'Default Account';
    const { data: account, error: accountError } = await supabase
      .from('accounts')
      .upsert({ 
        name: accountName,
        settings: {},
      }, { onConflict: 'name' })
      .select()
      .single();

    if (accountError) {
      results.errors.push({ table: 'accounts', error: accountError.message });
    } else {
      results.created.push({ table: 'accounts', id: account.id, name: account.name });

      // Create default company
      const companyName = seedData.companyName || 'Vision Care Center';
      const { data: company, error: companyError } = await supabase
        .from('companies')
        .upsert({
          account_id: account.id,
          name: companyName,
          twilio_phone_number: process.env.TWILIO_PHONE_NUMBER,
          settings: {},
        }, { onConflict: 'account_id,name' })
        .select()
        .single();

      if (companyError) {
        results.errors.push({ table: 'companies', error: companyError.message });
      } else {
        results.created.push({ table: 'companies', id: company.id, name: company.name });

        // Create default office
        const officeName = seedData.officeName || 'Main Office';
        const { data: office, error: officeError } = await supabase
          .from('offices')
          .upsert({
            company_id: company.id,
            name: officeName,
            timezone: 'America/Chicago',
            settings: {},
          }, { onConflict: 'company_id,name' })
          .select()
          .single();

        if (officeError) {
          results.errors.push({ table: 'offices', error: officeError.message });
        } else {
          results.created.push({ table: 'offices', id: office.id, name: office.name });
        }

        // Create admin user if email provided
        if (seedData.adminEmail) {
          const { data: user, error: userError } = await supabase
            .from('users')
            .upsert({
              account_id: account.id,
              email: seedData.adminEmail.toLowerCase(),
              name: seedData.adminName || 'Admin',
              role: 'admin',
              settings: {},
            }, { onConflict: 'account_id,email' })
            .select()
            .single();

          if (userError) {
            results.errors.push({ table: 'users', error: userError.message });
          } else {
            results.created.push({ table: 'users', id: user.id, email: user.email });

            // Assign user to office
            if (office) {
              await supabase.from('user_offices').upsert({
                user_id: user.id,
                office_id: office.id,
                role: 'admin',
              });
            }
          }
        }
      }
    }

  } catch (error) {
    results.errors.push({ error: error.message });
  }

  return {
    success: results.errors.length === 0,
    ...results,
  };
}
