/**
 * Generic Tenant-Scoped CRUD API Endpoint
 *
 * Receives serialized query specifications from the frontend ApiProxyClient,
 * validates the session, sets transaction-scoped tenant context, and executes
 * the query against PostgreSQL with RLS enforcement.
 *
 * POST /api/db/crud
 */

import { validateSession } from '../_lib/auth-middleware.js';
import { getPoolClient } from '../_lib/db.js';

// Allowed tables — only these can be queried through the CRUD endpoint
const TABLE_WHITELIST = new Set([
  'accounts',
  'companies',
  'offices',
  'staff',
  'staff_offices',
  'patients',
  'patient_insurance',
  'appointments',
  'encounters',
  'exams',
  'prescriptions',
  'orders',
  'recalls',
  'tasks',
  'users',
  'user_offices',
  'escalations',
  'call_enrichments',
  'frame_catalog',
  'patient_favorite_frames',
  'patient_face_profiles',
  'patient_measurements',
  'patient_scanner_tokens',
  'patient_movement_frames',
  'payer_credentials',
  'verification_jobs',
  'verification_results',
  'sync_logs',
  'form_submissions_cache',
  'voice_settings',
  'audit_logs',
]);

// Allowed filter operators
const ALLOWED_OPS = new Set(['=', '!=', '>', '>=', '<', '<=', 'IN', 'IS NULL', 'IS NOT NULL', 'ILIKE', 'LIKE']);

// Column name validation: only alphanumeric + underscore
const VALID_COLUMN = /^[a-zA-Z_][a-zA-Z0-9_]*$/;

// Known FK relationships for relation expansion
// key: "parentTable.childTable" → { fk, type }
const FK_MAP = {
  // one-to-many: child has FK pointing to parent.id
  'accounts.companies':       { fk: 'account_id', type: 'one-to-many' },
  'companies.offices':        { fk: 'company_id', type: 'one-to-many' },
  'offices.staff_offices':    { fk: 'office_id', type: 'one-to-many' },
  'staff.staff_offices':      { fk: 'staff_id', type: 'one-to-many' },
  'users.user_offices':       { fk: 'user_id', type: 'one-to-many' },
  // many-to-one: parent has FK pointing to child.id
  'companies.accounts':       { fk: 'account_id', type: 'many-to-one' },
  'offices.companies':        { fk: 'company_id', type: 'many-to-one' },
  'staff_offices.staff':      { fk: 'staff_id', type: 'many-to-one' },
  'staff_offices.offices':    { fk: 'office_id', type: 'many-to-one' },
  'user_offices.offices':     { fk: 'office_id', type: 'many-to-one' },
  'user_offices.users':       { fk: 'user_id', type: 'many-to-one' },
  'appointments.patients':    { fk: 'patient_id', type: 'many-to-one' },
  'appointments.staff':       { fk: 'provider_id', type: 'many-to-one' },
  'appointments.offices':     { fk: 'office_id', type: 'many-to-one' },
  'verification_results.verification_jobs': { fk: 'job_id', type: 'many-to-one' },
};

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Get user from server.js middleware (req.user) or validate directly
  let user;
  if (req.user?.userId) {
    user = {
      userId: req.user.userId,
      email: req.user.email,
      accountId: req.user.accountId || null,
      role: req.user.role || null,
    };
  } else {
    try {
      user = await validateSession(req);
    } catch (authErr) {
      return res.status(authErr.status || 401).json({ error: authErr.message });
    }
  }

  const {
    table,
    operation = 'select',
    columns = '*',
    filters = [],
    orFilters = [],
    order = [],
    limit,
    offset,
    rangeFrom,
    rangeTo,
    single = false,
    maybeSingle = false,
    data,
    upsertConflict,
    countMode,
    headOnly = false,
    rpcName,
    rpcParams,
  } = req.body;

  // Handle RPC calls
  if (operation === 'rpc') {
    return handleRpc(req, res, user, rpcName, rpcParams);
  }

  // Validate table
  if (!table || !TABLE_WHITELIST.has(table)) {
    return res.status(400).json({ error: `Table not allowed: ${table}` });
  }

  // Validate operation
  if (!['select', 'insert', 'update', 'upsert', 'delete'].includes(operation)) {
    return res.status(400).json({ error: `Invalid operation: ${operation}` });
  }

  // Validate filters
  for (const f of filters) {
    if (!VALID_COLUMN.test(f.column)) {
      return res.status(400).json({ error: `Invalid column name: ${f.column}` });
    }
    if (!ALLOWED_OPS.has(f.op)) {
      return res.status(400).json({ error: `Invalid operator: ${f.op}` });
    }
  }

  let client;
  try {
    client = await getPoolClient();
    await client.query('BEGIN');

    // Set tenant context (transaction-local)
    if (user.accountId) {
      await client.query(
        `SELECT set_config('app.current_account_id', $1, true)`,
        [user.accountId]
      );
    }

    let result;
    switch (operation) {
      case 'select':
        result = await execSelect(client, table, columns, filters, orFilters, order, limit, offset, rangeFrom, rangeTo, single, maybeSingle, countMode, headOnly);
        break;
      case 'insert':
        result = await execInsert(client, table, data, single);
        break;
      case 'update':
        result = await execUpdate(client, table, data, filters, single);
        break;
      case 'upsert':
        result = await execUpsert(client, table, data, upsertConflict, single);
        break;
      case 'delete':
        result = await execDelete(client, table, filters);
        break;
    }

    await client.query('COMMIT');
    return res.status(200).json(result);

  } catch (err) {
    if (client) {
      try { await client.query('ROLLBACK'); } catch (_) {}
    }
    console.error('[CRUD] Error:', err.message);
    return res.status(500).json({ data: null, error: { message: err.message } });
  } finally {
    if (client) client.release();
  }
}

// ============================================================
// RPC handler
// ============================================================

async function handleRpc(req, res, user, funcName, params) {
  if (!funcName) {
    return res.status(400).json({ error: 'rpcName is required' });
  }

  let client;
  try {
    client = await getPoolClient();
    await client.query('BEGIN');

    if (user.accountId) {
      await client.query(
        `SELECT set_config('app.current_account_id', $1, true)`,
        [user.accountId]
      );
    }

    let result;
    if (funcName === 'set_tenant_context') {
      await client.query(`SELECT set_tenant_context($1::uuid)`, [params?.account_id || params?.p_account_id]);
      result = { data: null, error: null };
    } else if (funcName === 'exec_sql') {
      // Block raw SQL from frontend for security
      return res.status(403).json({ error: 'Raw SQL execution not allowed from frontend' });
    } else {
      const argValues = Object.values(params || {});
      const placeholders = argValues.map((_, i) => `$${i + 1}`).join(', ');
      const sql = `SELECT * FROM ${funcName.replace(/[^a-zA-Z0-9_]/g, '')}(${placeholders})`;
      const pgResult = await client.query(sql, argValues);
      result = { data: pgResult.rows, error: null };
    }

    await client.query('COMMIT');
    return res.status(200).json(result);
  } catch (err) {
    if (client) {
      try { await client.query('ROLLBACK'); } catch (_) {}
    }
    console.error('[CRUD RPC] Error:', err.message);
    return res.status(500).json({ data: null, error: { message: err.message } });
  } finally {
    if (client) client.release();
  }
}

// ============================================================
// SELECT with relation expansion
// ============================================================

async function execSelect(client, table, columns, filters, orFilters, order, limit, offset, rangeFrom, rangeTo, single, maybeSingle, countMode, headOnly) {
  // Parse relation expansion from columns string
  const { mainColumns, relations } = parseSelectColumns(table, columns);

  // Build main query
  const params = [];
  const where = buildWhere(filters, orFilters, params);
  const orderLimit = buildOrderLimit(order, limit, offset, rangeFrom, rangeTo);
  const sql = `SELECT ${mainColumns} FROM "${table}" ${where} ${orderLimit}`;

  // Count query if requested
  let count = null;
  if (countMode === 'exact') {
    const countParams = [];
    const countWhere = buildWhere(filters, orFilters, countParams);
    const countResult = await client.query(`SELECT COUNT(*) FROM "${table}" ${countWhere}`, countParams);
    count = parseInt(countResult.rows[0].count);
    if (headOnly) {
      return { data: null, error: null, count };
    }
  }

  const result = await client.query(sql, params);
  let data = result.rows;

  // Expand relations if any
  if (relations.length > 0 && data.length > 0) {
    data = await expandRelations(client, table, data, relations);
  }

  // Handle single/maybeSingle
  if (single) {
    if (data.length === 0) {
      return { data: null, error: { code: 'PGRST116', message: 'Row not found' }, count };
    }
    data = data[0];
  } else if (maybeSingle) {
    data = data.length > 0 ? data[0] : null;
  }

  return { data, error: null, count };
}

// ============================================================
// Parse PostgREST-style select string for relation expansion
// ============================================================

function parseSelectColumns(parentTable, columnsStr) {
  if (!columnsStr || columnsStr === '*') {
    return { mainColumns: '*', relations: [] };
  }

  const relations = [];
  const mainCols = [];

  // Tokenize respecting nested parentheses
  const tokens = tokenizeSelect(columnsStr);

  for (const token of tokens) {
    const trimmed = token.trim();
    if (!trimmed) continue;

    // Check for relation syntax: table(columns) or alias:table(columns)
    // Also handles !inner modifier
    const relMatch = trimmed.match(/^(?:(\w+):)?(\w+?)(?:!inner)?\s*\((.+)\)$/s);
    if (relMatch) {
      const [, alias, relTable, relColumns] = relMatch;
      relations.push({
        alias: alias || relTable,
        table: relTable,
        columns: relColumns.trim(),
        parentTable,
      });
    } else if (!trimmed.includes('(')) {
      mainCols.push(trimmed === '*' ? '*' : `"${trimmed}"`);
    }
  }

  return {
    mainColumns: mainCols.length > 0 ? mainCols.join(', ') : '*',
    relations,
  };
}

/**
 * Tokenize a select string by commas, respecting nested parentheses.
 * "*, offices(*), company:companies(id, name)" → ["*", "offices(*)", "company:companies(id, name)"]
 */
function tokenizeSelect(str) {
  const tokens = [];
  let depth = 0;
  let current = '';
  for (const ch of str) {
    if (ch === '(') depth++;
    if (ch === ')') depth--;
    if (ch === ',' && depth === 0) {
      tokens.push(current);
      current = '';
    } else {
      current += ch;
    }
  }
  if (current.trim()) tokens.push(current);
  return tokens;
}

// ============================================================
// Expand relations (batch fetch + nest)
// ============================================================

async function expandRelations(client, parentTable, parentRows, relations) {
  for (const rel of relations) {
    const fkInfo = FK_MAP[`${parentTable}.${rel.table}`];
    if (!fkInfo) {
      // Unknown relation — try to resolve by convention
      console.warn(`[CRUD] Unknown relation: ${parentTable}.${rel.table}, skipping`);
      // Attach empty arrays/nulls
      for (const row of parentRows) {
        row[rel.alias] = fkInfo?.type === 'many-to-one' ? null : [];
      }
      continue;
    }

    // Parse nested relations from the relation's columns
    const { mainColumns: relCols, relations: nestedRelations } = parseSelectColumns(rel.table, rel.columns);

    if (fkInfo.type === 'one-to-many') {
      // Child table has FK pointing to parent.id
      const parentIds = [...new Set(parentRows.map(r => r.id))];
      if (parentIds.length === 0) continue;

      const placeholders = parentIds.map((_, i) => `$${i + 1}`).join(', ');
      const relSql = `SELECT ${relCols === '*' ? '*' : relCols} FROM "${rel.table}" WHERE "${fkInfo.fk}" IN (${placeholders})`;
      const relResult = await client.query(relSql, parentIds);
      let relRows = relResult.rows;

      // Expand nested relations
      if (nestedRelations.length > 0 && relRows.length > 0) {
        relRows = await expandRelations(client, rel.table, relRows, nestedRelations);
      }

      // Group by FK and attach
      const grouped = {};
      for (const relRow of relRows) {
        const key = relRow[fkInfo.fk];
        if (!grouped[key]) grouped[key] = [];
        grouped[key].push(relRow);
      }
      for (const row of parentRows) {
        row[rel.alias] = grouped[row.id] || [];
      }

    } else if (fkInfo.type === 'many-to-one') {
      // Parent has FK pointing to child.id
      const fkValues = [...new Set(parentRows.map(r => r[fkInfo.fk]).filter(Boolean))];
      if (fkValues.length === 0) {
        for (const row of parentRows) { row[rel.alias] = null; }
        continue;
      }

      const placeholders = fkValues.map((_, i) => `$${i + 1}`).join(', ');
      const relSql = `SELECT ${relCols === '*' ? '*' : relCols} FROM "${rel.table}" WHERE "id" IN (${placeholders})`;
      const relResult = await client.query(relSql, fkValues);
      let relRows = relResult.rows;

      // Expand nested relations
      if (nestedRelations.length > 0 && relRows.length > 0) {
        relRows = await expandRelations(client, rel.table, relRows, nestedRelations);
      }

      // Index by id and attach
      const indexed = {};
      for (const relRow of relRows) { indexed[relRow.id] = relRow; }
      for (const row of parentRows) {
        row[rel.alias] = indexed[row[fkInfo.fk]] || null;
      }
    }
  }

  return parentRows;
}

// ============================================================
// INSERT
// ============================================================

async function execInsert(client, table, data, single) {
  const rows = Array.isArray(data) ? data : [data];
  const results = [];

  for (const row of rows) {
    const keys = Object.keys(row);
    for (const k of keys) {
      if (!VALID_COLUMN.test(k)) throw new Error(`Invalid column name: ${k}`);
    }
    const values = Object.values(row);
    const placeholders = keys.map((_, i) => `$${i + 1}`).join(', ');
    const cols = keys.map(k => `"${k}"`).join(', ');
    const sql = `INSERT INTO "${table}" (${cols}) VALUES (${placeholders}) RETURNING *`;
    const result = await client.query(sql, values);
    results.push(...result.rows);
  }

  let resultData = results;
  if (single) {
    resultData = results[0] || null;
  }
  return { data: resultData, error: null, count: results.length };
}

// ============================================================
// UPDATE
// ============================================================

async function execUpdate(client, table, data, filters, single) {
  const params = [];
  const setClauses = [];

  for (const [key, value] of Object.entries(data)) {
    if (!VALID_COLUMN.test(key)) throw new Error(`Invalid column name: ${key}`);
    params.push(value);
    setClauses.push(`"${key}" = $${params.length}`);
  }

  const where = buildWhere(filters, [], params);
  if (!where) throw new Error('UPDATE requires at least one filter');

  const sql = `UPDATE "${table}" SET ${setClauses.join(', ')} ${where} RETURNING *`;
  const result = await client.query(sql, params);

  let resultData = result.rows;
  if (single) {
    resultData = resultData[0] || null;
  }
  return { data: resultData, error: null, count: result.rowCount };
}

// ============================================================
// UPSERT
// ============================================================

async function execUpsert(client, table, data, upsertConflict, single) {
  const rows = Array.isArray(data) ? data : [data];
  const results = [];

  for (const row of rows) {
    const keys = Object.keys(row);
    for (const k of keys) {
      if (!VALID_COLUMN.test(k)) throw new Error(`Invalid column name: ${k}`);
    }
    const values = Object.values(row);
    const placeholders = keys.map((_, i) => `$${i + 1}`).join(', ');
    const cols = keys.map(k => `"${k}"`).join(', ');

    let conflictClause;
    if (upsertConflict) {
      const conflictCols = upsertConflict.split(',').map(c => `"${c.trim()}"`).join(', ');
      const updateCols = keys
        .filter(k => !upsertConflict.split(',').map(c => c.trim()).includes(k))
        .map(k => `"${k}" = EXCLUDED."${k}"`)
        .join(', ');
      conflictClause = `ON CONFLICT (${conflictCols}) DO UPDATE SET ${updateCols}`;
    } else {
      const updateCols = keys
        .filter(k => k !== 'id')
        .map(k => `"${k}" = EXCLUDED."${k}"`)
        .join(', ');
      conflictClause = `ON CONFLICT (id) DO UPDATE SET ${updateCols}`;
    }

    const sql = `INSERT INTO "${table}" (${cols}) VALUES (${placeholders}) ${conflictClause} RETURNING *`;
    const result = await client.query(sql, values);
    results.push(...result.rows);
  }

  let resultData = results;
  if (single) {
    resultData = results[0] || null;
  }
  return { data: resultData, error: null, count: results.length };
}

// ============================================================
// DELETE
// ============================================================

async function execDelete(client, table, filters) {
  const params = [];
  const where = buildWhere(filters, [], params);
  if (!where) throw new Error('DELETE requires at least one filter');

  const sql = `DELETE FROM "${table}" ${where}`;
  const result = await client.query(sql, params);
  return { data: null, error: null, count: result.rowCount };
}

// ============================================================
// SQL helpers
// ============================================================

function buildWhere(filters, orFilters, params) {
  const conditions = [];

  for (const f of filters) {
    if (f.op === 'IS NULL') {
      conditions.push(`"${f.column}" IS NULL`);
    } else if (f.op === 'IS NOT NULL') {
      conditions.push(`"${f.column}" IS NOT NULL`);
    } else if (f.op === 'IN') {
      const values = Array.isArray(f.value) ? f.value : [f.value];
      const placeholders = values.map((_, i) => `$${params.length + i + 1}`).join(', ');
      params.push(...values);
      conditions.push(`"${f.column}" IN (${placeholders})`);
    } else {
      params.push(f.value);
      conditions.push(`"${f.column}" ${f.op} $${params.length}`);
    }
  }

  for (const orStr of (orFilters || [])) {
    const parts = parseOrFilter(orStr, params);
    if (parts.length > 0) {
      conditions.push(`(${parts.join(' OR ')})`);
    }
  }

  return conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
}

function parseOrFilter(filterString, params) {
  const parts = [];
  const segments = filterString.split(',');
  for (const seg of segments) {
    const match = seg.trim().match(/^(\w+)\.(eq|neq|gt|gte|lt|lte|ilike|like|is)\.(.+)$/);
    if (match) {
      const [, col, op, val] = match;
      if (!VALID_COLUMN.test(col)) continue;
      const sqlOp = { eq: '=', neq: '!=', gt: '>', gte: '>=', lt: '<', lte: '<=', ilike: 'ILIKE', like: 'LIKE', is: 'IS' }[op];
      if (op === 'is' && val === 'null') {
        parts.push(`"${col}" IS NULL`);
      } else {
        params.push(val);
        parts.push(`"${col}" ${sqlOp} $${params.length}`);
      }
    }
  }
  return parts;
}

function buildOrderLimit(order, limit, offset, rangeFrom, rangeTo) {
  let sql = '';
  if (order && order.length > 0) {
    const clauses = order.map(o => {
      if (!VALID_COLUMN.test(o.column)) return null;
      const dir = o.ascending === false ? 'DESC' : (o.ascending === true ? 'ASC' : 'DESC');
      return `"${o.column}" ${dir}`;
    }).filter(Boolean);
    if (clauses.length > 0) sql += ` ORDER BY ${clauses.join(', ')}`;
  }
  if (rangeFrom !== undefined && rangeFrom !== null && rangeTo !== undefined && rangeTo !== null) {
    sql += ` LIMIT ${parseInt(rangeTo) - parseInt(rangeFrom) + 1} OFFSET ${parseInt(rangeFrom)}`;
  } else {
    if (limit !== undefined && limit !== null) sql += ` LIMIT ${parseInt(limit)}`;
    if (offset !== undefined && offset !== null) sql += ` OFFSET ${parseInt(offset)}`;
  }
  return sql;
}
