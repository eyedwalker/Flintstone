/**
 * Analytics Metrics API
 *
 * GET - Returns aggregated metrics from audit_logs for dashboard visualization
 * Supports date range and office/company filtering
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  const db = getDb();

  try {
    const {
      officeId, companyId,
      startDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
      endDate = new Date().toISOString(),
    } = req.query;

    // Build base filter
    let baseQuery = db.from('audit_logs').select('*');
    if (officeId) baseQuery = baseQuery.eq('office_id', officeId);
    if (companyId) baseQuery = baseQuery.eq('company_id', companyId);
    baseQuery = baseQuery.gte('event_timestamp', startDate).lte('event_timestamp', endDate);

    const { data: logs, error } = await baseQuery.order('event_timestamp', { ascending: true });

    if (error) {
      console.error('[Analytics/Metrics] Query error:', error.message);
      return res.status(500).json({ success: false, error: error.message });
    }

    const allLogs = logs || [];

    // Compute metrics from raw logs
    const uniqueJourneys = new Set(allLogs.map(l => l.journey_id));
    const completedEvents = allLogs.filter(l => l.event_type === 'step-completed');
    const stepsWithDuration = allLogs.filter(l => l.step_duration != null && l.step_duration > 0);
    const stepsWithWait = allLogs.filter(l => l.wait_time != null && l.wait_time > 0);
    const overtimeSteps = allLogs.filter(l => l.is_overtime === true);

    // Journey completion: journeys where at least one step was completed
    const journeysWithCompletion = new Set(completedEvents.map(l => l.journey_id));

    // Average calculations
    const avgDuration = stepsWithDuration.length > 0
      ? stepsWithDuration.reduce((sum, l) => sum + Number(l.step_duration), 0) / stepsWithDuration.length
      : 0;
    const avgWaitTime = stepsWithWait.length > 0
      ? stepsWithWait.reduce((sum, l) => sum + Number(l.wait_time), 0) / stepsWithWait.length
      : 0;

    // Phase metrics
    const phaseMetrics = {};
    for (const phase of ['pre-visit', 'in-office', 'post-visit']) {
      const phaseLogs = allLogs.filter(l => l.journey_phase === phase);
      const phaseCompleted = phaseLogs.filter(l => l.event_type === 'step-completed');
      const phaseDurations = phaseLogs.filter(l => l.step_duration != null && l.step_duration > 0);
      const phaseWaits = phaseLogs.filter(l => l.wait_time != null && l.wait_time > 0);
      const phaseOvertime = phaseLogs.filter(l => l.is_overtime === true);

      phaseMetrics[phase] = {
        totalSteps: phaseLogs.length,
        completedSteps: phaseCompleted.length,
        averageDuration: phaseDurations.length > 0
          ? phaseDurations.reduce((s, l) => s + Number(l.step_duration), 0) / phaseDurations.length
          : 0,
        averageWaitTime: phaseWaits.length > 0
          ? phaseWaits.reduce((s, l) => s + Number(l.wait_time), 0) / phaseWaits.length
          : 0,
        overtimeRate: phaseLogs.length > 0
          ? (phaseOvertime.length / phaseLogs.length) * 100
          : 0,
      };
    }

    // Step type breakdown
    const stepTypeMap = {};
    for (const log of allLogs) {
      const title = log.step_title || 'Unknown';
      if (!stepTypeMap[title]) {
        stepTypeMap[title] = { count: 0, durations: [], waits: [], overtime: 0, completed: 0 };
      }
      stepTypeMap[title].count++;
      if (log.step_duration != null && log.step_duration > 0) stepTypeMap[title].durations.push(Number(log.step_duration));
      if (log.wait_time != null && log.wait_time > 0) stepTypeMap[title].waits.push(Number(log.wait_time));
      if (log.is_overtime) stepTypeMap[title].overtime++;
      if (log.event_type === 'step-completed') stepTypeMap[title].completed++;
    }

    const stepTypeMetrics = Object.entries(stepTypeMap).map(([title, data]) => ({
      stepTitle: title,
      count: data.count,
      averageDuration: data.durations.length > 0
        ? data.durations.reduce((a, b) => a + b, 0) / data.durations.length
        : 0,
      averageWaitTime: data.waits.length > 0
        ? data.waits.reduce((a, b) => a + b, 0) / data.waits.length
        : 0,
      overtimeRate: data.count > 0 ? (data.overtime / data.count) * 100 : 0,
      completedCount: data.completed,
    }));

    // Provider breakdown
    const providerMap = {};
    for (const log of allLogs) {
      if (!log.provider_id) continue;
      if (!providerMap[log.provider_id]) {
        providerMap[log.provider_id] = {
          providerId: log.provider_id,
          providerName: log.provider_name || 'Unknown',
          journeys: new Set(),
          durations: [],
        };
      }
      providerMap[log.provider_id].journeys.add(log.journey_id);
      if (log.step_duration != null && log.step_duration > 0) {
        providerMap[log.provider_id].durations.push(Number(log.step_duration));
      }
    }

    const providerMetrics = Object.values(providerMap).map(p => ({
      providerId: p.providerId,
      providerName: p.providerName,
      totalJourneys: p.journeys.size,
      averageStepDuration: p.durations.length > 0
        ? p.durations.reduce((a, b) => a + b, 0) / p.durations.length
        : 0,
    }));

    // Daily volume (for line chart)
    const dailyVolume = {};
    for (const log of allLogs) {
      const day = log.event_timestamp.split('T')[0];
      if (!dailyVolume[day]) dailyVolume[day] = { date: day, events: 0, journeys: new Set() };
      dailyVolume[day].events++;
      dailyVolume[day].journeys.add(log.journey_id);
    }
    const dailyData = Object.values(dailyVolume)
      .map(d => ({ date: d.date, events: d.events, journeys: d.journeys.size }))
      .sort((a, b) => a.date.localeCompare(b.date));

    // Hourly distribution (for identifying peak hours)
    const hourlyDist = Array(24).fill(0);
    for (const log of allLogs) {
      const hour = new Date(log.event_timestamp).getHours();
      hourlyDist[hour]++;
    }
    const hourlyData = hourlyDist.map((count, hour) => ({
      hour: `${hour.toString().padStart(2, '0')}:00`,
      count,
    }));

    const metrics = {
      dateRange: { startDate, endDate },
      // Volume
      totalJourneys: uniqueJourneys.size,
      completedJourneys: journeysWithCompletion.size,
      totalEvents: allLogs.length,
      totalSteps: completedEvents.length,
      // Performance
      averageStepDuration: Math.round(avgDuration * 10) / 10,
      averageWaitTime: Math.round(avgWaitTime * 10) / 10,
      // Efficiency
      overtimeSteps: overtimeSteps.length,
      overtimeRate: stepsWithDuration.length > 0
        ? Math.round((overtimeSteps.length / stepsWithDuration.length) * 1000) / 10
        : 0,
      // Breakdowns
      phaseMetrics,
      stepTypeMetrics,
      providerMetrics,
      dailyData,
      hourlyData,
    };

    return res.status(200).json({ success: true, metrics });
  } catch (err) {
    console.error('[Analytics/Metrics] Error:', err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
}
