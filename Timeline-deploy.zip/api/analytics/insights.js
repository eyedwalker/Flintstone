/**
 * AI Analytics Insights API
 *
 * POST - Sends aggregated metrics to Claude for natural language analysis
 * Two modes:
 *   - Auto-insights: pass metrics, get operational insights
 *   - Question mode: pass metrics + question, get targeted answer
 */

import Anthropic from '@anthropic-ai/sdk';

const SYSTEM_PROMPT = `You are an operational analytics assistant for an eye care practice management system. You analyze patient journey metrics and provide actionable insights.

Your analysis should focus on:
1. BOTTLENECKS — Steps or phases that take longer than expected
2. EFFICIENCY — Opportunities to reduce patient wait times
3. STAFFING — Patterns that suggest staffing adjustments (peak hours, provider load)
4. PATIENT EXPERIENCE — Wait time trends and their impact on satisfaction
5. COMPLIANCE — Overtime rates and steps being skipped

Guidelines:
- Be specific with numbers and percentages
- Compare against reasonable benchmarks for eye care (15-min avg step, <10-min wait, <5% overtime)
- Prioritize insights by impact
- Keep recommendations practical and actionable
- If data is sparse, acknowledge limitations rather than speculating

Respond in JSON format:
{
  "summary": "1-2 sentence executive summary",
  "insights": [
    {
      "title": "Short insight title",
      "description": "Detailed explanation with specific data points",
      "severity": "info|warning|critical",
      "category": "bottleneck|efficiency|staffing|patient-experience|compliance",
      "recommendation": "Specific actionable recommendation"
    }
  ],
  "highlights": {
    "bestPerforming": "What's going well",
    "needsAttention": "Most urgent area to address"
  }
}`;

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ success: false, error: 'Anthropic API key not configured' });
  }

  try {
    const { metrics, question } = req.body;

    if (!metrics) {
      return res.status(400).json({ success: false, error: 'Missing metrics data' });
    }

    const anthropic = new Anthropic({ apiKey });

    // Build the user message based on mode
    let userMessage;
    if (question) {
      userMessage = `Here are the current operational metrics for our eye care practice:\n\n${JSON.stringify(metrics, null, 2)}\n\nQuestion from staff: "${question}"\n\nProvide your analysis answering the question, plus any relevant insights from the data.`;
    } else {
      userMessage = `Analyze the following operational metrics for our eye care practice and provide insights:\n\n${JSON.stringify(metrics, null, 2)}\n\nProvide a comprehensive analysis with actionable insights.`;
    }

    const response = await anthropic.messages.create({
      model: 'claude-3-5-haiku-20241022',
      max_tokens: 1500,
      system: SYSTEM_PROMPT,
      messages: [
        { role: 'user', content: userMessage },
      ],
    });

    const responseText = response.content[0]?.text || '{}';

    // Parse JSON from response
    let analysis;
    try {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      analysis = jsonMatch ? JSON.parse(jsonMatch[0]) : { summary: responseText, insights: [] };
    } catch (parseErr) {
      console.warn('[Analytics/Insights] JSON parse failed, using raw text');
      analysis = {
        summary: responseText,
        insights: [{
          title: 'Analysis',
          description: responseText,
          severity: 'info',
          category: 'efficiency',
          recommendation: 'Review the detailed analysis above.',
        }],
        highlights: { bestPerforming: 'N/A', needsAttention: 'N/A' },
      };
    }

    return res.status(200).json({
      success: true,
      analysis,
      model: 'claude-3-5-haiku-20241022',
      question: question || null,
    });
  } catch (err) {
    console.error('[Analytics/Insights] Error:', err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
}
