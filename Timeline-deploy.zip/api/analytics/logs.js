/**
 * Audit Logs API
 *
 * GET  - Query audit logs with filters (date range, office, provider, event type, etc.)
 * POST - Persist a new audit log entry from the browser
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const db = getDb();

  try {
    // POST — persist a new audit log entry
    if (req.method === 'POST') {
      const log = req.body;
      if (!log || !log.journeyId || !log.eventType) {
        return res.status(400).json({ success: false, error: 'Missing required fields: journeyId, eventType' });
      }

      const row = {
        id: log.id || undefined,
        journey_id: log.journeyId,
        step_id: log.stepId,
        step_title: log.stepTitle,
        patient_id: log.patientId,
        patient_name: log.patientName,
        event_type: log.eventType,
        event_timestamp: log.eventTimestamp || new Date().toISOString(),
        performed_by: log.performedBy,
        performed_by_name: log.performedByName,
        location: log.location,
        step_start_time: log.stepStartTime,
        step_end_time: log.stepEndTime,
        step_duration: log.stepDuration,
        wait_time: log.waitTime,
        room_id: log.roomId,
        room_name: log.roomName,
        room_type: log.roomType,
        external_system_action: log.externalSystemAction,
        external_system_url: log.externalSystemUrl,
        external_patient_id: log.externalPatientId,
        external_appointment_id: log.externalAppointmentId,
        journey_phase: log.journeyPhase,
        metadata: log.metadata || {},
        provider_id: log.providerId,
        provider_name: log.providerName,
        office_id: log.officeId,
        office_name: log.officeName,
        company_id: log.companyId,
        outcome: log.outcome,
        error_message: log.errorMessage,
        is_overtime: log.isOvertime || false,
        expected_duration: log.expectedDuration,
      };

      const { data, error } = await db.from('audit_logs').insert(row).select().single();

      if (error) {
        console.error('[Analytics/Logs] Insert error:', error.message);
        return res.status(500).json({ success: false, error: error.message });
      }

      return res.status(201).json({ success: true, log: data });
    }

    // GET — query audit logs with filters
    if (req.method === 'GET') {
      const {
        officeId, companyId, startDate, endDate,
        eventType, patientId, providerId, journeyId,
        limit = '100', offset = '0',
        sortBy = 'event_timestamp', sortOrder = 'desc',
      } = req.query;

      let query = db
        .from('audit_logs')
        .select('*', { count: 'exact' });

      if (officeId) query = query.eq('office_id', officeId);
      if (companyId) query = query.eq('company_id', companyId);
      if (patientId) query = query.eq('patient_id', patientId);
      if (providerId) query = query.eq('provider_id', providerId);
      if (journeyId) query = query.eq('journey_id', journeyId);
      if (eventType) query = query.eq('event_type', eventType);
      if (startDate) query = query.gte('event_timestamp', startDate);
      if (endDate) query = query.lte('event_timestamp', endDate);

      const validSortColumns = ['event_timestamp', 'step_duration', 'wait_time', 'created_at'];
      const sortCol = validSortColumns.includes(sortBy) ? sortBy : 'event_timestamp';

      query = query
        .order(sortCol, { ascending: sortOrder === 'asc' })
        .range(parseInt(offset), parseInt(offset) + parseInt(limit) - 1);

      const { data, error, count } = await query;

      if (error) {
        console.error('[Analytics/Logs] Query error:', error.message);
        return res.status(500).json({ success: false, error: error.message });
      }

      return res.status(200).json({
        success: true,
        logs: data || [],
        total: count || 0,
        limit: parseInt(limit),
        offset: parseInt(offset),
      });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('[Analytics/Logs] Error:', err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
}
