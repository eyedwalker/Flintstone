/**
 * Queue Insurance Verification Job
 *
 * POST - Creates a verification job for a patient's insurance benefits
 * Checks for cached results first, returns them if valid
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Company-Id');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const supabase = getDb();

    const {
      patientId,
      appointmentId,
      payerType,
      memberId,
      subscriberDob,
      patientDob,
      relationship = 'self',
      triggeredBy = 'manual',
      priority = 5,
    } = req.body;

    if (!patientId || !payerType || !memberId) {
      return res.status(400).json({
        error: 'Missing required fields: patientId, payerType, memberId',
      });
    }

    const companyId = req.headers['x-company-id'];

    // Check for cached valid result (not expired)
    const { data: cachedResult } = await supabase
      .from('verification_results')
      .select('*')
      .eq('patient_id', patientId)
      .eq('payer_type', payerType)
      .gt('expires_at', new Date().toISOString())
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (cachedResult) {
      console.log('[Verification] Cache hit for patient:', patientId);
      return res.status(200).json({
        success: true,
        status: 'cached',
        result: cachedResult,
      });
    }

    // Check for existing pending/in-progress job
    const { data: existingJob } = await supabase
      .from('verification_jobs')
      .select('*')
      .eq('patient_id', patientId)
      .eq('payer_type', payerType)
      .in('status', ['queued', 'in_progress', 'mfa_waiting'])
      .limit(1)
      .single();

    if (existingJob) {
      console.log('[Verification] Existing job found:', existingJob.id);
      return res.status(200).json({
        success: true,
        status: existingJob.status,
        jobId: existingJob.id,
      });
    }

    // Check for payer credentials
    const credentialFilter = { payer_type: payerType, is_active: true };
    if (companyId) credentialFilter.company_id = companyId;

    const { data: credentials } = await supabase
      .from('payer_credentials')
      .select('id')
      .match(credentialFilter)
      .limit(1)
      .single();

    if (!credentials) {
      return res.status(400).json({
        error: `No active credentials configured for ${payerType}. Add credentials in Settings.`,
      });
    }

    // Create verification job
    const jobData = {
      patient_id: patientId,
      appointment_id: appointmentId || null,
      payer_type: payerType,
      member_id: memberId,
      subscriber_dob: subscriberDob || null,
      patient_dob: patientDob || null,
      relationship,
      status: 'queued',
      priority,
      triggered_by: triggeredBy,
    };

    if (companyId) jobData.company_id = companyId;

    const { data: job, error } = await supabase
      .from('verification_jobs')
      .insert(jobData)
      .select()
      .single();

    if (error) {
      console.error('[Verification] Failed to create job:', error);
      return res.status(500).json({ error: 'Failed to queue verification job' });
    }

    console.log('[Verification] Job queued:', job.id, 'Patient:', patientId, 'Payer:', payerType);

    return res.status(201).json({
      success: true,
      status: 'queued',
      jobId: job.id,
    });

  } catch (error) {
    console.error('[Verification] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
