/**
 * Batch Insurance Verification
 *
 * POST - Queue verification jobs for all appointments on a given date
 * Skips patients with cached valid results
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Company-Id, X-Cron-Secret');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const supabase = getDb();

    const companyId = req.headers['x-company-id'];

    // Default to tomorrow
    const { date, officeId } = req.body || {};
    const targetDate = date || getTomorrow();

    console.log('[Batch Verification] Processing date:', targetDate, 'Office:', officeId || 'all');

    // Get appointments for the target date
    const startOfDay = `${targetDate}T00:00:00Z`;
    const endOfDay = `${targetDate}T23:59:59Z`;

    let apptQuery = supabase
      .from('appointments')
      .select('id, patient_id, office_id, status')
      .gte('appointment_date', startOfDay)
      .lte('appointment_date', endOfDay)
      .in('status', ['scheduled', 'confirmed']);

    if (officeId) apptQuery = apptQuery.eq('office_id', officeId);
    if (companyId) apptQuery = apptQuery.eq('company_id', companyId);

    const { data: appointments, error: apptError } = await apptQuery;

    if (apptError) {
      console.error('[Batch Verification] Appointment query error:', apptError);
      return res.status(500).json({ error: 'Failed to fetch appointments' });
    }

    if (!appointments?.length) {
      return res.status(200).json({
        success: true,
        message: 'No appointments found for date',
        date: targetDate,
        jobsQueued: 0,
        alreadyCached: 0,
        skipped: 0,
      });
    }

    const patientIds = [...new Set(appointments.map(a => a.patient_id))];

    // Get patient insurance data
    const { data: insuranceRecords } = await supabase
      .from('patient_insurance')
      .select('patient_id, carrier_name, policy_number')
      .in('patient_id', patientIds)
      .eq('is_active', true);

    // Get existing cached results
    const { data: cachedResults } = await supabase
      .from('verification_results')
      .select('patient_id, payer_type')
      .in('patient_id', patientIds)
      .gt('expires_at', new Date().toISOString());

    const cachedSet = new Set(
      (cachedResults || []).map(r => `${r.patient_id}:${r.payer_type}`)
    );

    // Get existing pending jobs
    const { data: pendingJobs } = await supabase
      .from('verification_jobs')
      .select('patient_id, payer_type')
      .in('patient_id', patientIds)
      .in('status', ['queued', 'in_progress', 'mfa_waiting']);

    const pendingSet = new Set(
      (pendingJobs || []).map(j => `${j.patient_id}:${j.payer_type}`)
    );

    // Map carrier names to payer types
    const carrierToPayer = {
      'vsp': 'vsp',
      'vision service plan': 'vsp',
      'eyemed': 'eyemed',
      'davis vision': 'davis-vision',
      'spectera': 'spectera',
      'superior vision': 'superior-vision',
    };

    let jobsQueued = 0;
    let alreadyCached = 0;
    let skipped = 0;

    for (const insurance of (insuranceRecords || [])) {
      const carrierLower = (insurance.carrier_name || '').toLowerCase();
      const payerType = Object.entries(carrierToPayer).find(
        ([key]) => carrierLower.includes(key)
      )?.[1];

      if (!payerType) {
        skipped++;
        continue;
      }

      const cacheKey = `${insurance.patient_id}:${payerType}`;

      if (cachedSet.has(cacheKey)) {
        alreadyCached++;
        continue;
      }

      if (pendingSet.has(cacheKey)) {
        skipped++;
        continue;
      }

      // Find appointment for this patient
      const appt = appointments.find(a => a.patient_id === insurance.patient_id);

      const jobData = {
        patient_id: insurance.patient_id,
        appointment_id: appt?.id || null,
        office_id: appt?.office_id || null,
        payer_type: payerType,
        member_id: insurance.policy_number || '',
        status: 'queued',
        priority: 7, // Batch jobs are lower priority than manual
        triggered_by: 'batch',
      };

      if (companyId) jobData.company_id = companyId;

      const { error: insertError } = await supabase
        .from('verification_jobs')
        .insert(jobData);

      if (!insertError) {
        jobsQueued++;
      }
    }

    console.log(
      '[Batch Verification] Date:', targetDate,
      '| Queued:', jobsQueued,
      '| Cached:', alreadyCached,
      '| Skipped:', skipped
    );

    return res.status(200).json({
      success: true,
      date: targetDate,
      totalAppointments: appointments.length,
      jobsQueued,
      alreadyCached,
      skipped,
    });

  } catch (error) {
    console.error('[Batch Verification] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}

function getTomorrow() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().split('T')[0];
}
