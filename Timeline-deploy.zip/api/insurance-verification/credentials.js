/**
 * Payer Credentials Management
 *
 * GET  - List payer credentials (passwords masked)
 * POST - Add new payer credential
 * PUT  - Update existing credential
 */

import { getDb } from '../_lib/db.js';

// Accept any slug-format payer type (built-in + custom)
const BUILTIN_PAYER_TYPES = ['vsp', 'eyemed', 'davis-vision', 'spectera', 'superior-vision'];
function isValidPayerType(type) {
  if (!type || typeof type !== 'string') return false;
  return /^[a-z0-9][a-z0-9-]*[a-z0-9]$/.test(type) || BUILTIN_PAYER_TYPES.includes(type);
}
const VALID_MFA_METHODS = ['none', 'email', 'sms', 'totp'];

// Simple encryption using base64 + reversal as placeholder
// In production, use pgcrypto server-side or AWS KMS
function encryptPassword(password) {
  const key = process.env.PAYER_ENCRYPTION_KEY || 'default-dev-key';
  const combined = `${key}:${password}`;
  return Buffer.from(combined).toString('base64');
}

function maskPassword(encrypted) {
  return '••••••••';
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Company-Id');

  if (req.method === 'OPTIONS') return res.status(200).end();

  try {
    const supabase = getDb();

    const companyId = req.headers['x-company-id'];

    if (req.method === 'GET') {
      return handleGet(req, res, supabase, companyId);
    }
    if (req.method === 'POST') {
      return handlePost(req, res, supabase, companyId);
    }
    if (req.method === 'PUT') {
      return handlePut(req, res, supabase, companyId);
    }
    if (req.method === 'DELETE') {
      return handleDelete(req, res, supabase, companyId);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (error) {
    console.error('[Payer Credentials] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}

async function handleGet(req, res, supabase, companyId) {
  let query = supabase
    .from('payer_credentials')
    .select('id, company_id, office_id, payer_type, portal_username, mfa_method, portal_url, last_login_at, last_login_status, is_active, settings, created_at, updated_at')
    .eq('is_active', true);

  if (companyId) {
    query = query.eq('company_id', companyId);
  }

  const { data, error } = await query.order('payer_type');

  if (error) {
    return res.status(500).json({ error: 'Failed to fetch credentials' });
  }

  // Mask passwords in response
  const masked = (data || []).map(cred => ({
    ...cred,
    password: maskPassword(),
  }));

  return res.status(200).json({
    success: true,
    count: masked.length,
    credentials: masked,
  });
}

async function handlePost(req, res, supabase, companyId) {
  const {
    officeId,
    payerType,
    portalUsername,
    portalPassword,
    mfaMethod = 'none',
    portalUrl,
    settings,
  } = req.body;

  if (!payerType || !portalUsername || !portalPassword) {
    return res.status(400).json({
      error: 'Missing required fields: payerType, portalUsername, portalPassword',
    });
  }

  if (!isValidPayerType(payerType)) {
    return res.status(400).json({
      error: 'Invalid payerType. Must be a lowercase slug (letters, numbers, hyphens).',
    });
  }

  if (!VALID_MFA_METHODS.includes(mfaMethod)) {
    return res.status(400).json({
      error: `Invalid mfaMethod. Must be one of: ${VALID_MFA_METHODS.join(', ')}`,
    });
  }

  const credData = {
    payer_type: payerType,
    portal_username: portalUsername,
    portal_password_encrypted: encryptPassword(portalPassword),
    mfa_method: mfaMethod,
    portal_url: portalUrl || null,
    is_active: true,
  };

  if (settings) credData.settings = settings;
  if (companyId) credData.company_id = companyId;
  if (officeId) credData.office_id = officeId;

  const { data, error } = await supabase
    .from('payer_credentials')
    .insert(credData)
    .select('id, payer_type, portal_username, mfa_method, created_at')
    .single();

  if (error) {
    if (error.code === '23505') {
      return res.status(409).json({
        error: `Credentials already exist for ${payerType} at this office. Use PUT to update.`,
      });
    }
    console.error('[Payer Credentials] Insert error:', error);
    return res.status(500).json({ error: 'Failed to save credentials' });
  }

  console.log('[Payer Credentials] Added:', payerType, 'User:', portalUsername);

  return res.status(201).json({
    success: true,
    credential: data,
  });
}

async function handlePut(req, res, supabase, companyId) {
  const { credentialId, portalUsername, portalPassword, mfaMethod, portalUrl, isActive, settings } = req.body;

  if (!credentialId) {
    return res.status(400).json({ error: 'Missing credentialId' });
  }

  const updates = { updated_at: new Date().toISOString() };

  if (portalUsername) updates.portal_username = portalUsername;
  if (portalPassword) updates.portal_password_encrypted = encryptPassword(portalPassword);
  if (mfaMethod && VALID_MFA_METHODS.includes(mfaMethod)) updates.mfa_method = mfaMethod;
  if (portalUrl !== undefined) updates.portal_url = portalUrl;
  if (isActive !== undefined) updates.is_active = isActive;
  if (settings !== undefined) updates.settings = settings;

  let query = supabase
    .from('payer_credentials')
    .update(updates)
    .eq('id', credentialId);

  if (companyId) query = query.eq('company_id', companyId);

  const { data, error } = await query
    .select('id, payer_type, portal_username, mfa_method, is_active, updated_at')
    .single();

  if (error) {
    console.error('[Payer Credentials] Update error:', error);
    return res.status(500).json({ error: 'Failed to update credentials' });
  }

  console.log('[Payer Credentials] Updated:', credentialId);

  return res.status(200).json({
    success: true,
    credential: data,
  });
}

async function handleDelete(req, res, supabase, companyId) {
  const { credentialId } = req.query;

  if (!credentialId) {
    return res.status(400).json({ error: 'Missing credentialId query param' });
  }

  // Soft delete - mark as inactive
  let query = supabase
    .from('payer_credentials')
    .update({ is_active: false })
    .eq('id', credentialId);

  if (companyId) query = query.eq('company_id', companyId);

  const { error } = await query;

  if (error) {
    console.error('[Payer Credentials] Delete error:', error);
    return res.status(500).json({ error: 'Failed to delete credentials' });
  }

  return res.status(200).json({ success: true });
}
