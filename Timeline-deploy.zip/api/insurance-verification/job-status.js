/**
 * Verification Job Status
 *
 * GET - Check status of a verification job
 * Supports lookup by jobId, patientId, or appointmentId
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Company-Id');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const supabase = getDb();

    const { jobId, patientId, appointmentId } = req.query;

    if (!jobId && !patientId && !appointmentId) {
      return res.status(400).json({ error: 'Provide jobId, patientId, or appointmentId' });
    }

    let query = supabase.from('verification_jobs').select('*');

    if (jobId) {
      query = query.eq('id', jobId);
    } else if (appointmentId) {
      query = query.eq('appointment_id', appointmentId);
    } else {
      query = query.eq('patient_id', patientId);
    }

    query = query.order('created_at', { ascending: false }).limit(1);

    const { data: job, error } = await query.single();

    if (error || !job) {
      return res.status(404).json({ error: 'Job not found' });
    }

    // If completed, include result
    let result = null;
    if (job.status === 'completed') {
      const { data: resultData } = await supabase
        .from('verification_results')
        .select('*')
        .eq('job_id', job.id)
        .single();
      result = resultData;
    }

    return res.status(200).json({
      success: true,
      job: {
        id: job.id,
        status: job.status,
        payerType: job.payer_type,
        patientId: job.patient_id,
        attempts: job.attempts,
        maxAttempts: job.max_attempts,
        lastError: job.last_error,
        startedAt: job.started_at,
        completedAt: job.completed_at,
        mfaRequestedAt: job.mfa_requested_at,
        triggeredBy: job.triggered_by,
        createdAt: job.created_at,
      },
      result,
    });

  } catch (error) {
    console.error('[Verification Status] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
