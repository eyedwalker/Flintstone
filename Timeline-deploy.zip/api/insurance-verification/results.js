/**
 * Verification Results
 *
 * GET - Retrieve benefit verification results for a patient
 * Returns most recent non-expired result
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Company-Id');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const supabase = getDb();

    const { patientId, appointmentId, includeExpired } = req.query;

    if (!patientId && !appointmentId) {
      return res.status(400).json({ error: 'Provide patientId or appointmentId' });
    }

    let query = supabase
      .from('verification_results')
      .select('*, verification_jobs!inner(appointment_id, triggered_by)');

    if (appointmentId) {
      query = query.eq('verification_jobs.appointment_id', appointmentId);
    } else {
      query = query.eq('patient_id', patientId);
    }

    // Filter out expired results unless requested
    if (!includeExpired) {
      query = query.gt('expires_at', new Date().toISOString());
    }

    query = query.order('created_at', { ascending: false }).limit(5);

    const { data: results, error } = await query;

    if (error) {
      console.error('[Verification Results] Query error:', error);
      return res.status(500).json({ error: 'Failed to fetch results' });
    }

    // Format results (strip raw_html for response size)
    const formatted = (results || []).map(r => ({
      id: r.id,
      jobId: r.job_id,
      patientId: r.patient_id,
      payerType: r.payer_type,
      isEligible: r.is_eligible,
      eligibilityStatus: r.eligibility_status,
      planName: r.plan_name,
      planType: r.plan_type,
      effectiveDate: r.effective_date,
      terminationDate: r.termination_date,
      benefits: {
        examCopay: r.exam_copay,
        framesAllowance: r.frames_allowance,
        framesCopay: r.frames_copay,
        lensesCopay: r.lenses_copay,
        contactsAllowance: r.contacts_allowance,
        contactsCopay: r.contacts_copay,
      },
      eligibleDates: {
        exam: r.exam_eligible_date,
        frames: r.frames_eligible_date,
        lenses: r.lenses_eligible_date,
        contacts: r.contacts_eligible_date,
      },
      rawBenefits: r.raw_benefits,
      parsedBy: r.parsed_by,
      confidenceScore: r.confidence_score,
      expiresAt: r.expires_at,
      createdAt: r.created_at,
      appointmentId: r.verification_jobs?.appointment_id,
      triggeredBy: r.verification_jobs?.triggered_by,
    }));

    return res.status(200).json({
      success: true,
      count: formatted.length,
      results: formatted,
    });

  } catch (error) {
    console.error('[Verification Results] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
