/**
 * Portal Scanner - AI-powered flow step generation
 *
 * POST - Fetches a portal URL and uses Claude to analyze the page
 *         and generate automation flow steps
 */

import Anthropic from '@anthropic-ai/sdk';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Company-Id');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { url, payerName } = req.body;

  if (!url) {
    return res.status(400).json({ error: 'URL is required' });
  }

  try {
    // Fetch the portal page HTML
    let html = '';
    let fetchError = null;

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 15000);

      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
        signal: controller.signal,
        redirect: 'follow',
      });

      clearTimeout(timeout);

      if (response.ok) {
        html = await response.text();
        // Trim to avoid sending too much to the AI
        if (html.length > 50000) {
          html = html.substring(0, 50000);
        }
      } else {
        fetchError = `HTTP ${response.status}`;
      }
    } catch (err) {
      fetchError = err.message;
    }

    // Use Claude to analyze and generate flow steps
    const anthropic = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });

    const systemPrompt = `You are an expert web automation engineer. Your job is to analyze web portal login pages and generate browser automation flow steps.

You will receive HTML from a portal page (or just a URL if the HTML couldn't be fetched). Generate a complete automation flow for:
1. Navigating to the login page
2. Filling in credentials (use {{username}} and {{password}} placeholders)
3. Clicking the login/sign-in button
4. Waiting for the dashboard to load
5. Checking for MFA prompts
6. Navigating to the eligibility/benefits section
7. Filling member search fields (use {{member_id}} and {{subscriber_dob}} placeholders)
8. Clicking search
9. Waiting for results
10. Extracting the results

Each step must be a JSON object with these possible formats:
- { "type": "navigate", "url": "https://..." }
- { "type": "fill", "selector": "#elementId or .className or [name=fieldName]", "value": "{{variable}}" }
- { "type": "click", "selector": "#elementId or .className or text=Button Text" }
- { "type": "wait", "selector": ".className or #elementId", "timeout": 10000 }
- { "type": "check_mfa", "selectors": ["#mfaField", ".mfa-prompt", "text=verification"] }
- { "type": "extract", "selector": "body or .results-container" }
- { "type": "screenshot", "name": "step-name" }

RULES:
- Use CSS selectors based on actual HTML element IDs, names, classes, or aria-labels you find
- For Angular Material forms, use selectors like input[type=email], input[type=password], or mat-form-field input
- For elements without good IDs, use attribute selectors: [aria-label="Email"], [placeholder="Email"], etc.
- Use text= selectors for buttons/links by their visible text
- If the HTML is from an SPA (Angular, React), note that form fields may be in the rendered DOM
- Always include a check_mfa step after login
- After the login section, add reasonable guesses for eligibility/benefits navigation based on common insurance portal patterns
- Generate 10-15 steps for a complete flow

IMPORTANT: Return ONLY a valid JSON array of step objects. No markdown, no explanation, just the JSON array.`;

    const userMessage = html
      ? `Analyze this portal page for "${payerName || 'insurance payer'}" and generate automation flow steps.\n\nURL: ${url}\n\nHTML:\n${html}`
      : `The HTML could not be fetched (${fetchError}). Based on the URL and common portal patterns for "${payerName || 'insurance payer'}", generate a reasonable automation flow.\n\nURL: ${url}`;

    const aiResponse = await anthropic.messages.create({
      model: 'claude-sonnet-4-5-20250929',
      max_tokens: 4000,
      system: systemPrompt,
      messages: [{ role: 'user', content: userMessage }],
    });

    const responseText = aiResponse.content[0]?.text || '[]';

    // Parse the AI response - it should be a JSON array
    let steps;
    try {
      // Handle case where AI wraps in markdown code block
      const jsonMatch = responseText.match(/\[[\s\S]*\]/);
      steps = jsonMatch ? JSON.parse(jsonMatch[0]) : [];
    } catch (parseErr) {
      console.error('[Scan] Failed to parse AI response:', parseErr.message);
      return res.status(200).json({
        success: false,
        error: 'AI generated invalid flow steps. Try again or build manually.',
        raw: responseText,
      });
    }

    // Validate step structure
    const validTypes = ['navigate', 'fill', 'click', 'wait', 'check_mfa', 'extract', 'screenshot'];
    steps = steps.filter(s => s && validTypes.includes(s.type));

    return res.status(200).json({
      success: true,
      steps,
      htmlFetched: !!html,
      fetchError: fetchError || null,
    });

  } catch (err) {
    console.error('[Scan] Error:', err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
}
