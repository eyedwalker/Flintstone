/**
 * MFA Code Relay
 *
 * POST - Submit an MFA code for a waiting verification job
 * The worker polls for this code and resumes verification
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Company-Id');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const supabase = getDb();

    const { jobId, mfaCode } = req.body;

    if (!jobId || !mfaCode) {
      return res.status(400).json({ error: 'Missing jobId or mfaCode' });
    }

    // Verify job exists and is waiting for MFA
    const { data: job, error: fetchError } = await supabase
      .from('verification_jobs')
      .select('id, status, payer_type')
      .eq('id', jobId)
      .single();

    if (fetchError || !job) {
      return res.status(404).json({ error: 'Job not found' });
    }

    if (job.status !== 'mfa_waiting') {
      return res.status(400).json({
        error: `Job is not waiting for MFA. Current status: ${job.status}`,
      });
    }

    // Update job with MFA code
    const { error: updateError } = await supabase
      .from('verification_jobs')
      .update({ mfa_code: mfaCode.trim() })
      .eq('id', jobId);

    if (updateError) {
      console.error('[MFA Relay] Update error:', updateError);
      return res.status(500).json({ error: 'Failed to submit MFA code' });
    }

    console.log('[MFA Relay] Code submitted for job:', jobId, 'Payer:', job.payer_type);

    return res.status(200).json({
      success: true,
      message: 'MFA code submitted. Verification will resume shortly.',
    });

  } catch (error) {
    console.error('[MFA Relay] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
