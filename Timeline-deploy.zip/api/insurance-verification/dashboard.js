/**
 * Insurance Verification Dashboard API
 *
 * GET - Returns stats and recent jobs for the company
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Company-Id');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const supabase = getDb();

    const companyId = req.headers['x-company-id'];
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();

    // Fetch recent jobs (last 50)
    let jobsQuery = supabase
      .from('verification_jobs')
      .select('id, payer_type, status, started_at, completed_at, last_error, triggered_by, created_at')
      .order('created_at', { ascending: false })
      .limit(50);

    if (companyId) {
      jobsQuery = jobsQuery.eq('company_id', companyId);
    }

    const { data: jobs, error: jobsError } = await jobsQuery;
    if (jobsError) {
      console.error('[Dashboard] Jobs query error:', jobsError);
      return res.status(500).json({ error: 'Failed to fetch jobs' });
    }

    // Compute stats from the jobs data
    const recentJobs = (jobs || []);
    const last7d = recentJobs.filter(j => j.created_at >= sevenDaysAgo);
    const completed7d = last7d.filter(j => j.status === 'completed');
    const failed7d = last7d.filter(j => j.status === 'failed');
    const pending = recentJobs.filter(j => ['queued', 'in_progress', 'mfa_waiting'].includes(j.status));

    // Average processing time for completed jobs
    let avgTime = null;
    const timesArray = completed7d
      .filter(j => j.started_at && j.completed_at)
      .map(j => (new Date(j.completed_at) - new Date(j.started_at)) / 1000);
    if (timesArray.length > 0) {
      avgTime = timesArray.reduce((a, b) => a + b, 0) / timesArray.length;
    }

    // Success rate
    const totalFinished7d = completed7d.length + failed7d.length;
    const successRate = totalFinished7d > 0 ? (completed7d.length / totalFinished7d) * 100 : null;

    // Payer health breakdown
    const payerMap = {};
    for (const job of last7d) {
      if (!payerMap[job.payer_type]) {
        payerMap[job.payer_type] = { payer_type: job.payer_type, total: 0, success: 0 };
      }
      if (job.status === 'completed' || job.status === 'failed') {
        payerMap[job.payer_type].total++;
        if (job.status === 'completed') payerMap[job.payer_type].success++;
      }
    }

    return res.status(200).json({
      success: true,
      stats: {
        total_7d: last7d.length,
        success_rate: successRate,
        avg_time_seconds: avgTime,
        pending: pending.length,
        payer_health: Object.values(payerMap),
      },
      recent_jobs: recentJobs.slice(0, 25),
    });
  } catch (error) {
    console.error('[Dashboard] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
