/**
 * Batch Verification Cron Trigger
 *
 * Called by Vercel cron at 8 PM daily
 * Triggers batch verification for next-day appointments
 */

const getBaseUrl = () => process.env.VITE_APP_URL || 'https://patientcare-teal.vercel.app';

export default async function handler(req, res) {
  // Verify cron secret
  const secret = process.env.TASK_CRON_SECRET;
  if (secret && req.headers['x-cron-secret'] !== secret) {
    // Vercel cron calls don't have custom headers, check Authorization header too
    const authHeader = req.headers['authorization'];
    if (!authHeader || authHeader !== `Bearer ${secret}`) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
  }

  try {
    const baseUrl = getBaseUrl();

    console.log('[Verification Cron] Triggering batch verification');

    const response = await fetch(`${baseUrl}/api/insurance-verification/batch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}), // Defaults to tomorrow
    });

    const result = await response.json();

    console.log('[Verification Cron] Result:', result);

    return res.status(200).json({
      success: true,
      cron: true,
      result,
    });

  } catch (error) {
    console.error('[Verification Cron] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
