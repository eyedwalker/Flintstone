/**
 * ElevenLabs Conversational AI - Voice Call Handler
 * 
 * Uses the ElevenLabs register_call pattern for real-time AI conversations:
 * - Twilio hits this endpoint when call comes in
 * - We register the call with ElevenLabs Conversational AI
 * - ElevenLabs returns TwiML to stream audio bidirectionally
 * - ElevenLabs AI handles the entire conversation
 * 
 * Configure in Twilio:
 * Voice → "A Call Comes In" → POST /api/voice/elevenlabs-call
 * 
 * Required ENV:
 * - ELEVENLABS_API_KEY
 * - ELEVENLABS_AGENT_ID (create in ElevenLabs Dashboard → Conversational AI → Agents)
 */

import { ElevenLabsClient } from '@elevenlabs/elevenlabs-js';

const OFFICE_PHONE = process.env.OFFICE_PHONE_NUMBER || process.env.TWILIO_PHONE_NUMBER;

export default async function handler(req, res) {
  // Set content type for TwiML
  res.setHeader('Content-Type', 'text/xml');
  
  if (req.method !== 'POST' && req.method !== 'GET') {
    return res.status(405).send(`<?xml version="1.0" encoding="UTF-8"?><Response><Say>Method not allowed</Say></Response>`);
  }

  try {
    const { CallSid, From, To } = req.body || req.query;

    console.log('[ElevenLabs Conversational AI] Incoming call:', { 
      callSid: CallSid?.slice(-8), 
      from: From,
      to: To
    });

    // Check for required config
    const apiKey = process.env.ELEVENLABS_API_KEY;
    const agentId = process.env.ELEVENLABS_AGENT_ID;

    if (!apiKey || !agentId) {
      console.warn('[ElevenLabs] Missing ELEVENLABS_API_KEY or ELEVENLABS_AGENT_ID - falling back to Polly');
      return fallbackToPolly(res, "Thank you for calling Vision Care Center. How can I help you today?");
    }

    // Initialize ElevenLabs client
    const client = new ElevenLabsClient({ apiKey });

    // Register the call with ElevenLabs Conversational AI
    // This tells ElevenLabs to prepare for this specific Twilio call
    const response = await client.conversationalAi.twilio.registerCall({
      agentId: agentId,
      twilioCallSid: CallSid,
    });

    console.log('[ElevenLabs] Call registered, returning TwiML');

    // Return the TwiML from ElevenLabs - this connects Twilio's audio stream to ElevenLabs
    return res.status(200).send(response.twiml);

  } catch (error) {
    console.error('[ElevenLabs Conversational AI] Error:', error.message);
    
    // Fallback to simple Polly response if ElevenLabs fails
    return fallbackToPolly(res, "We're experiencing technical difficulties. Let me connect you with a staff member.");
  }
}

/**
 * Fallback to Polly TTS if ElevenLabs Conversational AI is not configured
 */
function fallbackToPolly(res, message) {
  const baseUrl = process.env.VITE_APP_URL || 'https://patientcare-teal.vercel.app';
  
  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Joanna">${escapeXml(message)}</Say>
  <Gather input="speech dtmf" timeout="5" action="${baseUrl}/api/voice/ai-call-response" method="POST" speechTimeout="auto" language="en-US">
    <Say voice="Polly.Joanna">I'm listening.</Say>
  </Gather>
  <Say voice="Polly.Joanna">I didn't hear anything. Goodbye!</Say>
</Response>`;

  return res.status(200).send(twiml);
}

function escapeXml(text) {
  return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}
