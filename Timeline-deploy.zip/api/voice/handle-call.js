/**
 * High-Quality Voice Call Handler
 * Uses ElevenLabs for human-like AI voice instead of Polly
 *
 * Strategy:
 * - For greeting/short responses: Use Twilio's <Play> with pre-generated audio URLs
 * - For real-time conversation: Stream audio to a media endpoint
 * - Fallback to Polly if ElevenLabs fails (for reliability)
 *
 * Configure in Twilio Console:
 * Phone Numbers → Your Number → Voice → "A Call Comes In" → POST to:
 * https://your-domain.vercel.app/api/voice/handle-call
 */

import { getVoiceSettings, getVoiceSettingsAsync } from './settings.js';

// In-memory call state (use Redis/KV in production)
const callStates = new Map();

// Environment config
const OFFICE_ID = process.env.OFFICE_ID || '936';
const OFFICE_PHONE = process.env.OFFICE_PHONE_NUMBER || process.env.TWILIO_PHONE_NUMBER;
const RECORD_CALLS = process.env.TWILIO_RECORD_CALLS !== 'false';
const USE_ELEVENLABS = process.env.USE_ELEVENLABS_TTS === 'true' || process.env.USE_ELEVENLABS_VOICE === 'true';
const POLLY_VOICE = 'Polly.Joanna-Neural';
const getBaseUrl = () => process.env.VITE_APP_URL || 'https://patientcare-teal.vercel.app';

export default async function handler(req, res) {
  if (req.method !== 'POST' && req.method !== 'GET') {
    res.setHeader('Allow', ['GET', 'POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  try {
    // Warm voice settings cache from DB on cold start
    await getVoiceSettingsAsync();

    const {
      From,
      To,
      CallSid,
      CallStatus,
      Digits,
      SpeechResult,
      RecordingUrl,
      RecordingSid
    } = req.body || req.query;

    console.log('[Voice] Incoming:', {
      callSid: CallSid,
      from: From,
      status: CallStatus,
      hasSpeech: !!SpeechResult,
      hasDigits: !!Digits
    });

    // Handle recording callback
    if (RecordingUrl) {
      await handleRecording(CallSid, RecordingUrl, RecordingSid);
    }

    // Handle speech/digit input
    if (SpeechResult || Digits) {
      return handleConversation(req, res, { CallSid, SpeechResult, Digits, From });
    }

    // Initial call - generate greeting
    return handleInitialCall(req, res, { CallSid, From, To });

  } catch (error) {
    console.error('[Voice] Error:', error);
    return sendFallbackResponse(res, 'technical-difficulty');
  }
}

/**
 * Handle initial incoming call
 */
async function handleInitialCall(req, res, { CallSid, From, To }) {
  // Initialize call state
  const state = {
    callSid: CallSid,
    from: From,
    to: To,
    startTime: new Date(),
    turnCount: 0,
    messages: [],
    escalated: false
  };
  callStates.set(CallSid, state);

  // Try to look up patient by phone (would connect to your patient service)
  const patientName = await lookupPatientByPhone(From);
  
  // Build greeting
  const greeting = buildGreeting(patientName);
  
  // Generate TwiML
  const twiml = buildGatherTwiML(greeting, '/api/voice/handle-call');
  
  // Add recording if enabled
  const fullTwiml = RECORD_CALLS 
    ? addRecordingToTwiML(twiml)
    : twiml;

  res.setHeader('Content-Type', 'text/xml');
  return res.status(200).send(fullTwiml);
}

/**
 * Handle ongoing conversation
 */
async function handleConversation(req, res, { CallSid, SpeechResult, Digits, From }) {
  const state = callStates.get(CallSid) || { turnCount: 0, messages: [] };
  state.turnCount++;
  
  const input = SpeechResult || Digits || '';
  console.log('[Voice] Input:', input, 'Turn:', state.turnCount);

  // Store patient message
  state.messages.push({ role: 'patient', content: input, time: new Date() });

  // Check for transfer/escalation triggers
  if (shouldTransfer(input, state)) {
    return handleTransfer(res, state, getTransferReason(input));
  }

  // Check for goodbye
  if (isGoodbye(input)) {
    return handleGoodbye(res, state);
  }

  // Max turns reached
  if (state.turnCount > 8) {
    return handleTransfer(res, state, 'max-turns');
  }

  // Generate AI response
  const response = await generateAIResponse(input, state);
  
  // Store assistant message
  state.messages.push({ role: 'assistant', content: response.text, time: new Date() });
  callStates.set(CallSid, state);

  // Build response TwiML
  const twiml = buildGatherTwiML(
    response.text,
    '/api/voice/handle-call',
    "Is there anything else I can help you with?"
  );

  res.setHeader('Content-Type', 'text/xml');
  return res.status(200).send(twiml);
}

/**
 * Handle call transfer
 */
function handleTransfer(res, state, reason) {
  const messages = {
    'escalation': "I understand this is important. Let me connect you with a team member right away.",
    'request': "Of course, I'll transfer you to a staff member now. Please hold.",
    'max-turns': "I want to make sure you get the best help. Let me connect you with our team."
  };

  const message = messages[reason] || messages['request'];
  
  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeechTag(message)}
  <Dial timeout="30" action="/api/voice/transfer-result">
    <Number>${OFFICE_PHONE}</Number>
  </Dial>
  ${buildSpeechTag("I'm sorry, no one is available. Please leave a message after the tone.")}
  <Record maxLength="120" action="/api/voice/voicemail" transcribe="true" />
</Response>`;

  res.setHeader('Content-Type', 'text/xml');
  return res.status(200).send(twiml);
}

/**
 * Handle goodbye
 */
function handleGoodbye(res, state) {
  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeechTag("Thank you for calling! Have a wonderful day. Goodbye!")}
  <Hangup />
</Response>`;

  // Cleanup
  callStates.delete(state.callSid);

  res.setHeader('Content-Type', 'text/xml');
  return res.status(200).send(twiml);
}

/**
 * Build greeting based on time, patient info, and voice settings
 */
function buildGreeting(patientName) {
  const voiceSettings = getVoiceSettings();
  const agentName = voiceSettings.agentName || 'Emily';

  const hour = new Date().getHours();
  let timeGreeting = 'Hello';
  if (hour < 12) timeGreeting = 'Good morning';
  else if (hour < 17) timeGreeting = 'Good afternoon';
  else timeGreeting = 'Good evening';

  if (patientName) {
    return `${timeGreeting}, ${patientName}! Thank you for calling. This is ${agentName}, your virtual assistant. How can I help you today?`;
  }

  return `${timeGreeting}, and thank you for calling! This is ${agentName}. How may I assist you today?`;
}

/**
 * Build speech tag - ElevenLabs Play or Twilio Say
 */
function buildSpeechTag(message) {
  if (USE_ELEVENLABS && process.env.ELEVENLABS_API_KEY) {
    const voiceSettings = getVoiceSettings();
    const baseUrl = getBaseUrl();
    const params = new URLSearchParams({
      voice: voiceSettings.voiceName || 'emily',
      text: message,
      stability: (voiceSettings.stability ?? 0.3).toString(),
      style: (voiceSettings.style ?? 0.55).toString(),
      speed: (voiceSettings.voiceSpeed ?? 1.15).toString(),
    });
    const audioUrl = `${baseUrl}/api/voice/generate-audio?${params.toString().replace(/&/g, '&amp;')}`;
    return `<Play>${audioUrl}</Play>`;
  }
  return `<Say voice="${POLLY_VOICE}">${escapeXml(message)}</Say>`;
}

/**
 * Build TwiML with Gather for speech input
 */
function buildGatherTwiML(mainMessage, actionUrl, followupMessage = null) {
  const followup = followupMessage
    ? buildSpeechTag(followupMessage)
    : '';

  return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeechTag(mainMessage)}
  <Gather input="speech" timeout="5" action="${actionUrl}" method="POST" speechTimeout="auto" language="en-US">
    ${followup}
  </Gather>
  ${buildSpeechTag("I didn't catch that. Could you please repeat?")}
  <Gather input="speech" timeout="5" action="${actionUrl}" method="POST" speechTimeout="auto" language="en-US">
  </Gather>
  ${buildSpeechTag("Thank you for calling. Goodbye!")}
</Response>`;
}

/**
 * Add recording element to TwiML
 */
function addRecordingToTwiML(twiml) {
  // Insert Record element after Response open tag
  return twiml.replace(
    '<Response>',
    `<Response>
  <Record recordingStatusCallback="/api/webhooks/twilio-status" maxLength="3600" transcribe="false" />`
  );
}

/**
 * Generate AI response (simplified - use UnifiedAIResponseService in production)
 */
async function generateAIResponse(input, state) {
  const lower = input.toLowerCase();
  
  // Appointment-related
  if (lower.includes('appointment') || lower.includes('schedule')) {
    if (lower.includes('cancel')) {
      return { text: "I understand you'd like to cancel your appointment. I can help with that. Can you confirm your name and the date of the appointment you'd like to cancel?" };
    }
    if (lower.includes('reschedule') || lower.includes('change')) {
      return { text: "I can help you reschedule. Our next available appointments are tomorrow at 10 AM or 2 PM. Which would work better for you?" };
    }
    return { text: "I'd be happy to help you with scheduling. We have appointments available this week. Would you prefer a morning or afternoon time?" };
  }
  
  // Hours
  if (lower.includes('hour') || lower.includes('open') || lower.includes('close')) {
    return { text: "Our office is open Monday through Friday from 8 AM to 5 PM. We're closed on weekends and major holidays. Is there anything else I can help with?" };
  }
  
  // Location
  if (lower.includes('location') || lower.includes('address') || lower.includes('direction')) {
    return { text: "We're located at 123 Medical Center Drive. There's free parking available in the lot behind the building. Would you like me to text you the address?" };
  }
  
  // Insurance
  if (lower.includes('insurance') || lower.includes('accept') || lower.includes('coverage')) {
    return { text: "We accept most major insurance plans including VSP, EyeMed, and Spectera. If you'd like, I can have our billing team verify your specific coverage. Would that help?" };
  }
  
  // Prescription
  if (lower.includes('prescription') || lower.includes('glasses') || lower.includes('contacts')) {
    return { text: "For prescription questions, our optician can best assist you. Would you like me to connect you to them, or would you prefer to come in for a quick check?" };
  }
  
  // Confirmation
  if (lower.includes('yes') || lower.includes('correct') || lower.includes('that works') || lower.includes('sounds good')) {
    return { text: "Perfect! I've noted that down. Is there anything else I can help you with today?" };
  }
  
  // Default
  return { text: "I want to make sure I help you correctly. Could you tell me a bit more about what you need assistance with?" };
}

/**
 * Check if patient wants transfer
 */
function shouldTransfer(input, state) {
  const lower = input.toLowerCase();
  const transferPhrases = [
    'speak to someone', 'real person', 'human', 'operator', 
    'representative', 'transfer', 'staff', 'manager', 'supervisor'
  ];
  const escalationPhrases = [
    'angry', 'frustrated', 'upset', 'complaint', 'unacceptable'
  ];
  
  return transferPhrases.some(p => lower.includes(p)) ||
         escalationPhrases.some(p => lower.includes(p));
}

function getTransferReason(input) {
  const lower = input.toLowerCase();
  if (['angry', 'frustrated', 'upset', 'complaint'].some(p => lower.includes(p))) {
    return 'escalation';
  }
  return 'request';
}

function isGoodbye(input) {
  const lower = input.toLowerCase();
  return ['goodbye', 'bye', 'thank you', 'thanks', "that's all", 'nothing else'].some(p => lower.includes(p));
}

/**
 * Look up patient by phone number (stub - implement with your patient service)
 */
async function lookupPatientByPhone(phone) {
  // TODO: Connect to EyefinityService.searchPatientsByPhone()
  return null;
}

/**
 * Handle recording callback
 */
async function handleRecording(callSid, recordingUrl, recordingSid) {
  const state = callStates.get(callSid);
  if (state) {
    state.recordingUrl = recordingUrl;
    state.recordingSid = recordingSid;
  }
  console.log('[Voice] Recording saved:', { callSid, recordingUrl });
}

/**
 * Send fallback response for errors
 */
function sendFallbackResponse(res, type) {
  const messages = {
    'technical-difficulty': "We're experiencing technical difficulties. Please hold while I connect you to a staff member.",
  };

  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeechTag(messages[type] || messages['technical-difficulty'])}
  <Dial timeout="30">
    <Number>${OFFICE_PHONE}</Number>
  </Dial>
</Response>`;

  res.setHeader('Content-Type', 'text/xml');
  return res.status(200).send(twiml);
}

/**
 * Escape XML special characters
 */
function escapeXml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
