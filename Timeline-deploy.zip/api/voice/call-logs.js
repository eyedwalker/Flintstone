/**
 * Call Logs API Endpoint
 * 
 * GET /api/voice/call-logs - Get all call logs
 * GET /api/voice/call-logs?callSid=xxx - Get specific call
 */

import { callLogs, getCallLog, getAllCallLogs } from '../webhooks/twilio-status.js';

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    res.setHeader('Allow', ['GET']);
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { callSid } = req.query;

    if (callSid) {
      const log = getCallLog(callSid);
      if (!log) {
        return res.status(404).json({ error: 'Call not found' });
      }
      return res.status(200).json(log);
    }

    // Return all logs, sorted by most recent
    const logs = getAllCallLogs()
      .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
      .slice(0, 100); // Limit to last 100

    return res.status(200).json({
      count: logs.length,
      calls: logs,
    });

  } catch (error) {
    console.error('[Call Logs] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
