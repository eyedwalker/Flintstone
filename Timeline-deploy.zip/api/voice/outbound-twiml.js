/**
 * Outbound Call TwiML Generator
 * Returns TwiML for outbound calls - fetched by Twilio via URL
 * Supports ElevenLabs with full voice settings passthrough
 */

import { getVoiceSettingsAsync } from './settings.js';

const getBaseUrl = () => {
  return process.env.VITE_APP_URL || 'https://patientcare-teal.vercel.app';
};
const USE_ELEVENLABS = process.env.USE_ELEVENLABS_TTS === 'true' || process.env.USE_ELEVENLABS_VOICE === 'true';

export default async function handler(req, res) {
  res.setHeader('Content-Type', 'text/xml');

  const {
    message,
    callbackUrl,
    useElevenLabs,
    voicePreset,
    voiceSpeed,
    stability,
    style,
  } = req.query;

  const voiceSettings = await getVoiceSettingsAsync();

  const text = message || 'Hello, this is a test call from Vision Care Center.';
  const baseCallback = callbackUrl || `${getBaseUrl()}/api/voice/ai-call-response`;
  // Append initial message to callback so ai-call-response knows what was said
  const callbackWithContext = `${baseCallback}${baseCallback.includes('?') ? '&' : '?'}initialMessage=${encodeURIComponent(text)}`;
  // Use env var by default, allow query param override
  const useEL = useElevenLabs !== undefined ? useElevenLabs === 'true' : USE_ELEVENLABS;

  let speechElement;

  if (useEL && process.env.ELEVENLABS_API_KEY) {
    const baseUrl = getBaseUrl();
    const params = new URLSearchParams({
      voice: voicePreset || voiceSettings.voiceName || 'emily',
      text,
      stability: (stability || voiceSettings.stability || 0.3).toString(),
      style: (style || voiceSettings.style || 0.55).toString(),
      speed: (voiceSpeed || voiceSettings.voiceSpeed || 1.15).toString(),
    });
    const audioUrl = `${baseUrl}/api/voice/generate-audio?${params.toString().replace(/&/g, '&amp;')}`;
    speechElement = `<Play>${audioUrl}</Play>`;
    console.log('[Outbound TwiML] Using ElevenLabs audio');
  } else {
    const speed = parseFloat(voiceSpeed || voiceSettings.voiceSpeed || 1.15);
    const prosodyRate = Math.round(speed * 100);
    const prosodyText = `<prosody rate="${prosodyRate}%">${escapeXml(text)}</prosody>`;
    speechElement = `<Say voice="Polly.Joanna-Neural">${prosodyText}</Say>`;
    console.log('[Outbound TwiML] Using Twilio Polly Neural at', prosodyRate + '%');
  }

  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${speechElement}
  <Gather input="speech dtmf" timeout="8" action="${escapeXml(callbackWithContext)}" method="POST" speechTimeout="auto" language="en-US">
  </Gather>
  <Say voice="Polly.Joanna-Neural">I didn't hear anything. If you need help, please call back. Goodbye!</Say>
</Response>`;

  console.log('[Outbound TwiML] Serving script:', text.substring(0, 80) + '...');

  return res.status(200).send(twiml);
}

function escapeXml(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
