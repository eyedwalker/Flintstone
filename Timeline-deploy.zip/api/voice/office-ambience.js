/**
 * Office Ambience Audio Generator
 * 
 * Returns a subtle office background audio for calls
 * This makes the AI voice sound more natural and less robotic
 * 
 * Enable with VOICE_BACKGROUND_NOISE=true
 */

// Free ambient office sounds (royalty-free URLs)
const AMBIENCE_OPTIONS = {
  office: 'https://cdn.pixabay.com/audio/2022/03/10/audio_c8c8a73467.mp3', // Subtle office
  quiet: 'https://cdn.pixabay.com/audio/2021/08/04/audio_0625c1539c.mp3',  // Very quiet ambience
  // Fallback to silence if none available
  none: null,
};

export default async function handler(req, res) {
  const { type = 'office' } = req.query;
  
  const ambienceUrl = AMBIENCE_OPTIONS[type] || AMBIENCE_OPTIONS.office;
  
  if (!ambienceUrl) {
    return res.status(204).end(); // No content
  }

  // Redirect to the ambience audio
  return res.redirect(302, ambienceUrl);
}
