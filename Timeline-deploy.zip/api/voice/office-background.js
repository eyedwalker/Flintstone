/**
 * Generate office background ambiance audio
 * Creates realistic medical office sounds for voice calls
 */

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // For now, we'll generate a simple tone that mimics office ambiance
    // In production, you'd use a pre-recorded office ambiance file
    
    // Set audio headers
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Cache-Control', 'public, max-age=86400'); // Cache for 24 hours
    res.setHeader('Content-Length', '1024'); // Small audio file
    
    // Generate a very quiet background tone (simulating office ambiance)
    // This is a minimal MP3-like response - in production use real office sounds
    const silenceData = Buffer.alloc(1024, 0x00); // Silent audio buffer
    
    console.log('[Background Audio] Serving office ambiance');
    return res.send(silenceData);
    
  } catch (error) {
    console.error('[Background Audio] Error:', error);
    return res.status(500).json({ error: 'Failed to generate background audio' });
  }
}
