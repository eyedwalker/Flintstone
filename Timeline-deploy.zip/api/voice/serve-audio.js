/**
 * Serve Audio - Returns stored ElevenLabs audio
 * 
 * Used by Twilio <Play> to fetch generated audio
 */

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { id } = req.query;

    if (!id) {
      return res.status(400).json({ error: 'Missing audio id' });
    }

    // Get from global store
    const audioStore = global.audioStore;
    if (!audioStore) {
      return res.status(404).json({ error: 'Audio store not initialized' });
    }

    const audio = audioStore.get(id);
    if (!audio) {
      return res.status(404).json({ error: 'Audio not found' });
    }

    // Set headers for audio streaming
    res.setHeader('Content-Type', audio.contentType || 'audio/mpeg');
    res.setHeader('Content-Length', audio.buffer.length);
    res.setHeader('Cache-Control', 'public, max-age=3600');

    // Send audio buffer
    return res.status(200).send(audio.buffer);

  } catch (error) {
    console.error('[Serve Audio] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
