/**
 * AI Call Response Handler - Full Custom AI System
 * 
 * Uses Claude AI with patient context for intelligent conversations:
 * - Patient lookup by phone number
 * - Appointment booking via Eyefinity
 * - Insurance and billing knowledge
 * - Natural conversation flow
 * - Transfer and escalation handling
 * - Optional ElevenLabs TTS for premium voice
 */

import Anthropic from '@anthropic-ai/sdk';
import { getDb } from '../_lib/db.js';
import { getVoiceSettings, getVoiceSettingsAsync } from './settings.js';

// In-memory call sessions (use Redis in production)
const callSessions = new Map();

// Clean up ended sessions older than 1 hour (keep them around for transcript retrieval)
const SESSION_TTL_MS = 60 * 60 * 1000;
function cleanupOldSessions() {
  const now = Date.now();
  for (const [sid, session] of callSessions) {
    if (session.endedAt && (now - new Date(session.endedAt).getTime()) > SESSION_TTL_MS) {
      callSessions.delete(sid);
    }
  }
}

const getBaseUrl = () => process.env.VITE_APP_URL || 'https://patientcare-teal.vercel.app';
const OFFICE_PHONE = process.env.OFFICE_PHONE_NUMBER || process.env.TWILIO_PHONE_NUMBER;
const MAX_TURNS = 10;
const USE_ELEVENLABS = process.env.USE_ELEVENLABS_TTS === 'true' || process.env.USE_ELEVENLABS_VOICE === 'true';

// Office knowledge base
const OFFICE_INFO = `
VISION CARE CENTER INFORMATION:
- Hours: Monday-Friday 8:00 AM - 5:00 PM, Saturday 9:00 AM - 1:00 PM, Closed Sunday
- Address: 123 Vision Way, Suite 100, Dallas, TX 75201
- Phone: (555) 555-1234
- Services: Comprehensive Eye Exams, Contact Lens Fittings, Glasses, LASIK Consultations, Pediatric Eye Care
- Insurance: We accept VSP, EyeMed, Spectera, Medicare, Medicaid, and most major insurance plans
- Appointments: Available same-week for routine exams, same-day for emergencies
- Parking: Free parking available in rear lot
`;

export default async function handler(req, res) {
  // Housekeeping: remove sessions that ended over 1 hour ago
  cleanupOldSessions();

  // GET: Fetch transcript for a call session
  if (req.method === 'GET') {
    const { callSid } = req.query;
    const session = callSid ? callSessions.get(callSid) : null;
    if (session) {
      const transcript = formatTranscript(session);
      return res.status(200).json({ transcript, turns: session.turns });
    }
    return res.status(404).json({ transcript: null });
  }

  res.setHeader('Content-Type', 'text/xml');

  if (req.method !== 'POST') {
    return res.status(200).send(buildTwiML("Goodbye!", true));
  }

  try {
    // Warm voice settings cache from DB on cold start
    await getVoiceSettingsAsync();

    const { CallSid, From, SpeechResult, Digits } = req.body || {};
    const input = SpeechResult || '';
    const baseUrl = getBaseUrl();

    // Check for initial outbound message passed from outbound-twiml
    const initialMessage = req.query?.initialMessage || '';

    console.log('[AI Voice] CallSid:', CallSid?.slice(-8), 'Input:', input.substring(0, 50));

    // Get or create session
    let session = callSessions.get(CallSid);
    if (!session) {
      session = await createSession(CallSid, From);
      // Seed the session with the initial outbound message so Claude knows what was said
      if (initialMessage) {
        session.history.push({ role: 'assistant', content: initialMessage });
        console.log('[AI Voice] Seeded session with initial outbound message:', initialMessage.substring(0, 80) + '...');
      }
      callSessions.set(CallSid, session);
    }

    session.turns++;
    session.history.push({ role: 'user', content: input || '[no speech detected]' });

    // Real-time sentiment detection
    updateSessionSentiment(session, input);
    
    // Auto-escalate if caller is very frustrated
    if (session.sentiment.escalationNeeded) {
      console.log('[AI Voice] ⚠️ Auto-escalating due to caller frustration');
      session.escalationReason = `Auto-escalated: caller frustration detected (score: ${session.sentiment.overallScore}, emotion: ${session.sentiment.emotion})`;
      await saveTranscript(session);
      session.endedAt = new Date().toISOString();
      return res.status(200).send(buildTransferTwiML("I understand this is frustrating. Let me connect you with a team member who can help resolve this right away."));
    }

    // Check for immediate actions
    if (shouldTransfer(input, Digits)) {
      session.sentiment.escalationNeeded = true;
      session.escalationReason = `Caller requested transfer: "${input || 'pressed 0'}"`;
      await saveTranscript(session);
      session.endedAt = new Date().toISOString();
      return res.status(200).send(buildTransferTwiML("Of course! Let me connect you with a staff member right away."));
    }

    if (shouldEndCall(input)) {
      await saveTranscript(session);
      session.endedAt = new Date().toISOString();
      return res.status(200).send(buildTwiML("Thank you so much for calling Vision Care Center! Have a wonderful day. Goodbye!", true));
    }

    // Check for booking intent or continue booking flow
    const bookingResult = await handleBookingFlow(input, session, From);
    if (bookingResult) {
      session.history.push({ role: 'assistant', content: bookingResult.message });
      callSessions.set(CallSid, session);
      
      if (bookingResult.complete) {
        // Booking complete - reset booking state
        session.booking = { active: false, step: null };
      }
      
      return res.status(200).send(buildGatherTwiML(bookingResult.message, baseUrl));
    }

    // Check if caller wants a link sent to their phone
    const linkRequest = detectLinkRequest(input);
    console.log('[AI Voice] Link detection:', { input: input.substring(0, 50), linkRequest, hasFrom: !!From, from: From });
    if (linkRequest && From) {
      let linkResponse;
      try {
        await sendLinkToPhone(From, linkRequest, session);
        linkResponse = getLinkConfirmation(linkRequest);
      } catch (err) {
        console.error('[AI Voice] Send link failed:', err.message);
        linkResponse = "I'm sorry, I wasn't able to send that text right now. Let me give you the information verbally instead. " + getLinkFallbackInfo(linkRequest);
      }
      session.history.push({ role: 'assistant', content: linkResponse });
      callSessions.set(CallSid, session);
      return res.status(200).send(buildGatherTwiML(linkResponse, baseUrl));
    }

    if (session.turns > MAX_TURNS) {
      await saveTranscript(session);
      session.endedAt = new Date().toISOString();
      return res.status(200).send(buildTransferTwiML("I want to make sure you get the best help. Let me connect you with our team."));
    }

    // Generate AI response
    let aiResponse;
    try {
      aiResponse = await generateAIResponse(input, session);
    } catch (err) {
      console.error('[AI Voice] Claude error:', err.message);
      aiResponse = "I want to make sure I help you correctly. Could you please repeat that?";
    }

    // Store response
    session.history.push({ role: 'assistant', content: aiResponse });
    callSessions.set(CallSid, session);

    // Save transcript after every turn so it's persisted even if the caller hangs up
    await saveTranscript(session);

    // Build response TwiML
    const twiml = buildGatherTwiML(aiResponse, baseUrl);
    return res.status(200).send(twiml);

  } catch (error) {
    console.error('[AI Voice] Error:', error.message);
    return res.status(200).send(buildTransferTwiML("I apologize, we're having technical difficulties. Let me connect you with someone who can help."));
  }
}

/**
 * Create new call session with patient lookup
 */
async function createSession(callSid, fromPhone) {
  const session = {
    callSid,
    fromPhone,
    startTime: new Date(),
    turns: 0,
    history: [],
    patient: null,
    // Booking state tracking
    booking: {
      active: false,
      step: null,
      patientData: null,
      officeId: null,
      providerId: null,
      slots: null,
      selectedSlot: null,
    },
    // Sentiment tracking
    sentiment: {
      overallScore: 3, // 1-5 scale
      emotion: 'neutral',
      frustrationSignals: 0,
      escalationNeeded: false,
    },
  };

  // Try to look up patient by phone
  if (fromPhone) {
    try {
      session.patient = await lookupPatientByPhone(fromPhone);
      if (session.patient) {
        console.log('[AI Voice] Found patient:', session.patient.firstName, session.patient.lastName);
      }
    } catch (err) {
      console.log('[AI Voice] Patient lookup failed:', err.message);
    }
  }

  return session;
}

/**
 * Look up patient by phone number
 */
async function lookupPatientByPhone(phone) {
  // Clean phone number
  const cleanPhone = phone.replace(/\D/g, '').slice(-10);
  
  try {
    const baseUrl = getBaseUrl();
    const response = await fetch(`${baseUrl}/api/eyefinity/v2patients?Phone=${cleanPhone}&pageSize=1`);
    
    if (response.ok) {
      const data = await response.json();
      if (data.items && data.items.length > 0) {
        const p = data.items[0];
        return {
          id: p.PatientId || p.Id,
          firstName: p.FirstName,
          lastName: p.LastName,
          phone: p.Phone || p.CellPhone,
          email: p.Email,
          dob: p.DateOfBirth,
          // Add any upcoming appointments
          nextAppointment: p.NextAppointment || null,
        };
      }
    }
  } catch (err) {
    console.log('[AI Voice] Patient API error:', err.message);
  }
  
  return null;
}

/**
 * Generate AI response using Claude
 */
async function generateAIResponse(input, session) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return "How can I help you today?";
  }

  const anthropic = new Anthropic({ apiKey });

  // Build patient context
  let patientContext = '';
  if (session.patient) {
    patientContext = `
CALLER INFORMATION (Patient in our system):
- Name: ${session.patient.firstName} ${session.patient.lastName}
- Phone: ${session.fromPhone || session.patient.phone || 'on file'}
${session.patient.nextAppointment ? `- Next Appointment: ${session.patient.nextAppointment}` : '- No upcoming appointments on file'}

Address the patient by name when appropriate.
`;
  } else {
    patientContext = `
CALLER: Unknown (not found in patient database)
- Phone: ${session.fromPhone || 'unknown'}
Offer to help them as a new or existing patient.
`;
  }

  // Get agent name from voice settings
  const voiceSettings = getVoiceSettings();
  const agentName = voiceSettings.agentName || 'Emily';
  
  // Build conversation history
  const historyText = session.history
    .slice(-6) // Last 6 turns for context
    .map(h => `${h.role === 'user' ? 'Patient' : agentName}: ${h.content}`)
    .join('\n');

  const systemPrompt = `You are ${agentName}, a friendly and upbeat AI receptionist for Vision Care Center. You handle phone calls with energy and enthusiasm while remaining professional.

${OFFICE_INFO}

${patientContext}

CONVERSATION SO FAR:
${historyText || '(This is the start of the conversation)'}

VOICE CALL GUIDELINES:
- Keep responses SHORT (2-3 sentences, under 15 seconds of speech)
- Be friendly, upbeat, and enthusiastic - show genuine interest in helping
- DO NOT reintroduce yourself - the greeting already introduced you as ${agentName}
- DO NOT say "Hi, this is ${agentName}" or "My name is ${agentName}" during the conversation
- Just respond directly to what the caller asked
- If confirming an appointment: verify the date/time and thank them
- If scheduling: offer available times (morning or afternoon options)
- If they want to reschedule: ask what day works better
- If asked about insurance: confirm we accept most major plans and offer to verify theirs
- If unsure or complex request: offer to connect with a staff member
- NEVER provide medical advice
- If patient seems frustrated or asks for a person: offer to transfer immediately

SENDING LINKS/TEXTS:
- You have the caller's phone number on file from caller ID — NEVER ask for their phone number
- Do NOT say "I'll text you" or "I'll send that to your phone" — the system handles texting AUTOMATICALLY before your response
- If the caller asks for directions, forms, or info to be texted, just provide the information verbally (address, hours, etc.) — the system will separately send the text
- Do NOT promise to text or send anything — just answer the question with the information directly
- Do NOT ask "What is your phone number?" or "Can I get your number?" — you already have it

CRITICAL OUTPUT RULES:
- Output ONLY the spoken words - no stage directions, no asterisks, no quotes
- Do NOT include things like *in a friendly tone* or "text in quotes"
- Do NOT start with greetings like "Hi!" or "Hello!" - just answer their question
- Just respond with plain conversational text that will be read aloud
- Example good response: "Sure, we're open Monday through Friday 8am to 5pm."
- Example bad response: "Hi! This is Sarah. We're open..."

Respond naturally to: "${input}"`;

  const response = await anthropic.messages.create({
    model: 'claude-3-haiku-20240307',
    max_tokens: 150,
    messages: [{ role: 'user', content: systemPrompt }],
  });

  return response.content[0]?.text || "I'd be happy to help. Could you tell me more?";
}

/**
 * Check if caller wants to transfer
 */
function shouldTransfer(input, digits) {
  if (digits === '0') return true;
  const lower = (input || '').toLowerCase();
  const transferPhrases = [
    'operator', 'real person', 'human', 'staff', 'transfer',
    'speak to someone', 'representative', 'manager', 'supervisor',
  ];
  return transferPhrases.some(p => lower.includes(p));
}

/**
 * Check if call should end
 */
function shouldEndCall(input) {
  const lower = (input || '').toLowerCase();
  const goodbyePhrases = ['goodbye', 'bye', "that's all", 'nothing else', 'no thanks', 'no thank you', "i'm good", "that's it"];
  return goodbyePhrases.some(p => lower.includes(p));
}

/**
 * Build speech tag - Polly or ElevenLabs
 * Passes all voice settings through to generate-audio endpoint
 */
function buildSpeechTag(message) {
  const voiceSettings = getVoiceSettings();

  if (USE_ELEVENLABS) {
    const baseUrl = getBaseUrl();
    const params = new URLSearchParams({
      voice: voiceSettings.voiceName || 'emily',
      text: message,
      stability: (voiceSettings.stability ?? 0.3).toString(),
      style: (voiceSettings.style ?? 0.55).toString(),
      speed: (voiceSettings.voiceSpeed ?? 1.15).toString(),
    });
    const audioUrl = `${baseUrl}/api/voice/generate-audio?${params.toString().replace(/&/g, '&amp;')}`;
    return `<Play>${audioUrl}</Play>`;
  }
  return `<Say voice="Polly.Joanna-Neural">${escapeXml(message)}</Say>`;
}

/**
 * Build TwiML with Gather for continued conversation
 */
function buildGatherTwiML(message, baseUrl) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeechTag(message)}
  <Gather input="speech" timeout="7" action="${baseUrl}/api/voice/ai-call-response" method="POST" speechTimeout="auto" language="en-US">
  </Gather>
  <Say voice="Polly.Joanna-Neural">I didn't hear anything. If you need help, please call back. Goodbye!</Say>
  <Hangup/>
</Response>`;
}

/**
 * Build simple TwiML (say and optionally hangup)
 */
function buildTwiML(message, hangup = false) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeechTag(message)}
  ${hangup ? '<Hangup/>' : ''}
</Response>`;
}

/**
 * Build transfer TwiML
 */
function buildTransferTwiML(message) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${buildSpeechTag(message)}
  <Dial timeout="30" action="${getBaseUrl()}/api/voice/transfer-complete">
    <Number>${OFFICE_PHONE}</Number>
  </Dial>
  <Say voice="Polly.Joanna-Neural">I'm sorry, no one is available right now. Please leave a message after the tone.</Say>
  <Record maxLength="120" transcribe="true" playBeep="true"/>
  <Say voice="Polly.Joanna-Neural">Thank you for your message. Goodbye!</Say>
  <Hangup/>
</Response>`;
}

function escapeXml(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// ============================================
// BOOKING FLOW HANDLER
// ============================================

/**
 * Handle multi-step appointment booking flow
 * Returns null if not a booking request, otherwise returns response message
 */
async function handleBookingFlow(input, session, fromPhone) {
  const lower = (input || '').toLowerCase();
  const baseUrl = getBaseUrl();
  
  // Check if we're already in a booking flow
  if (session.booking.active) {
    return await continueBookingFlow(input, session, fromPhone);
  }
  
  // Detect new booking intent
  const bookingIntent = detectBookingIntent(lower);
  if (!bookingIntent) {
    return null; // Not a booking request
  }
  
  console.log('[AI Voice] Booking intent detected:', bookingIntent);
  
  // Start booking flow
  session.booking.active = true;
  session.booking.step = 'verify_patient';
  
  // Call booking API to verify patient
  try {
    const response = await fetch(`${baseUrl}/api/voice/book-appointment`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        step: 'verify_patient',
        patientPhone: fromPhone,
        patientName: session.patient ? `${session.patient.firstName} ${session.patient.lastName}` : null,
        preferredDate: bookingIntent.preferredDate,
        preferredTime: bookingIntent.preferredTime,
      }),
    });
    
    const result = await response.json();
    return processBookingResult(result, session, bookingIntent);
  } catch (err) {
    console.error('[AI Voice] Booking API error:', err.message);
    session.booking.active = false;
    return null; // Fall back to AI response
  }
}

/**
 * Continue an active booking flow based on caller's response
 */
async function continueBookingFlow(input, session, fromPhone) {
  const lower = (input || '').toLowerCase();
  const baseUrl = getBaseUrl();
  const booking = session.booking;
  
  // Handle cancellation
  if (lower.includes('never mind') || lower.includes('cancel') || lower.includes("don't want")) {
    session.booking = { active: false, step: null };
    return { message: "No problem! Is there anything else I can help you with today?", complete: false };
  }
  
  // Extract info from response based on current step
  let apiParams = {
    step: booking.step,
    patientData: booking.patientData,
    officeId: booking.officeId,
    providerId: booking.providerId,
  };
  
  switch (booking.step) {
    case 'verify_patient':
      // Check if they said yes to new patient
      if (lower.includes('yes') || lower.includes('sure') || lower.includes('new patient')) {
        apiParams.isNewPatient = true;
        apiParams.step = 'verify_patient';
      }
      // Extract DOB if they provided it
      const dobMatch = extractDOB(input);
      if (dobMatch) {
        apiParams.patientDOB = dobMatch;
      }
      break;
      
    case 'select_office':
      // Extract office selection
      const officeMatch = extractOfficeSelection(input, booking.offices);
      if (officeMatch) {
        apiParams.officeId = officeMatch;
      }
      break;
      
    case 'select_provider':
      // Check for "first available" or extract provider name
      if (lower.includes('first available') || lower.includes('anyone') || lower.includes("doesn't matter") || lower.includes("don't care")) {
        apiParams.providerId = booking.providers?.[0]?.id;
        apiParams.providerName = 'first available';
      } else {
        apiParams.providerName = extractProviderName(input);
      }
      break;
      
    case 'find_slots':
      // Extract date preference
      const datePreference = extractDatePreference(input);
      if (datePreference) {
        apiParams.preferredDate = datePreference;
        apiParams.preferredTime = extractTimePreference(input);
      }
      break;
      
    case 'book':
      // Confirm or select slot
      if (lower.includes('yes') || lower.includes('perfect') || lower.includes('that works') || lower.includes('sounds good')) {
        apiParams.selectedSlot = booking.slots?.[0];
      } else {
        // Try to match a different slot
        const slotIndex = extractSlotSelection(input, booking.slots);
        if (slotIndex !== null && booking.slots?.[slotIndex]) {
          apiParams.selectedSlot = booking.slots[slotIndex];
        }
      }
      break;
  }
  
  // Call booking API with updated params
  try {
    const response = await fetch(`${baseUrl}/api/voice/book-appointment`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(apiParams),
    });
    
    const result = await response.json();
    return processBookingResult(result, session, {});
  } catch (err) {
    console.error('[AI Voice] Booking API error:', err.message);
    session.booking.active = false;
    return { message: "I'm having trouble with the booking system. Let me connect you with someone who can help.", complete: false };
  }
}

/**
 * Process booking API result and update session state
 */
function processBookingResult(result, session, intent) {
  if (!result.success && result.needsInfo) {
    return { message: result.message, complete: false };
  }
  
  // Update session booking state based on result
  if (result.nextStep) {
    session.booking.step = result.nextStep;
  }
  
  if (result.patientData) {
    session.booking.patientData = result.patientData;
  }
  
  if (result.patient) {
    session.booking.patientData = { patient: result.patient };
  }
  
  if (result.officeId) {
    session.booking.officeId = result.officeId;
  }
  
  if (result.providerId) {
    session.booking.providerId = result.providerId;
  }
  
  if (result.providers) {
    session.booking.providers = result.providers;
  }
  
  if (result.offices) {
    session.booking.offices = result.offices;
  }
  
  if (result.slots) {
    session.booking.slots = result.slots;
  }
  
  // Check if booking is complete
  if (result.booked) {
    return { 
      message: result.message, 
      complete: true,
      appointment: result.appointment,
    };
  }
  
  return { message: result.message, complete: false };
}

/**
 * Detect booking intent from input
 */
function detectBookingIntent(lower) {
  const bookingPhrases = [
    'book an appointment', 'schedule an appointment', 'make an appointment',
    'need an appointment', 'want an appointment', 'set up an appointment',
    'get an appointment', 'book a time', 'schedule a time',
    'come in', 'see the doctor', 'see a doctor', 'need to be seen',
    'available appointments', 'when can i come', 'next available',
  ];
  
  const hasBookingIntent = bookingPhrases.some(phrase => lower.includes(phrase));
  if (!hasBookingIntent) return null;
  
  // Extract any mentioned preferences
  return {
    preferredDate: extractDatePreference(lower),
    preferredTime: extractTimePreference(lower),
    preferredProvider: extractProviderName(lower),
  };
}

/**
 * Extract date preference from input
 */
function extractDatePreference(input) {
  const lower = input.toLowerCase();
  
  if (lower.includes('today')) return 'today';
  if (lower.includes('tomorrow')) return 'tomorrow';
  if (lower.includes('monday')) return 'monday';
  if (lower.includes('tuesday')) return 'tuesday';
  if (lower.includes('wednesday')) return 'wednesday';
  if (lower.includes('thursday')) return 'thursday';
  if (lower.includes('friday')) return 'friday';
  if (lower.includes('saturday')) return 'saturday';
  if (lower.includes('next week')) return 'next week';
  if (lower.includes('this week')) return 'this week';
  
  // Match date patterns like "January 28" or "1/28"
  const dateMatch = input.match(/(\d{1,2})[\/\-](\d{1,2})/);
  if (dateMatch) {
    return `${dateMatch[1]}/${dateMatch[2]}`;
  }
  
  return null;
}

/**
 * Extract time preference from input
 */
function extractTimePreference(input) {
  const lower = input.toLowerCase();
  
  if (lower.includes('morning')) return 'morning';
  if (lower.includes('afternoon')) return 'afternoon';
  if (lower.includes('evening')) return 'evening';
  
  // Match specific times
  const timeMatch = input.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?/i);
  if (timeMatch) {
    return timeMatch[0];
  }
  
  return null;
}

/**
 * Extract provider name from input
 */
function extractProviderName(input) {
  const lower = input.toLowerCase();
  
  // Match "Dr. Name" or "Doctor Name"
  const drMatch = input.match(/(?:dr\.?|doctor)\s+([a-z]+)/i);
  if (drMatch) {
    return drMatch[1];
  }
  
  return null;
}

/**
 * Extract DOB from input
 */
function extractDOB(input) {
  // Match various date formats
  const patterns = [
    /(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/, // MM/DD/YYYY or MM-DD-YYYY
    /(january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{1,2})(?:st|nd|rd|th)?,?\s*(\d{4})?/i,
  ];
  
  for (const pattern of patterns) {
    const match = input.match(pattern);
    if (match) {
      return match[0];
    }
  }
  
  return null;
}

/**
 * Extract office selection from input
 */
function extractOfficeSelection(input, offices) {
  if (!offices || offices.length === 0) return null;
  
  const lower = input.toLowerCase();
  
  for (const office of offices) {
    if (lower.includes(office.name?.toLowerCase()) || 
        lower.includes(office.address?.toLowerCase()?.split(',')[0])) {
      return office.id;
    }
  }
  
  // Check for numeric selection
  const numMatch = input.match(/(\d+)/);
  if (numMatch) {
    const index = parseInt(numMatch[1]) - 1;
    if (offices[index]) {
      return offices[index].id;
    }
  }
  
  return null;
}

/**
 * Extract slot selection from input
 */
function extractSlotSelection(input, slots) {
  if (!slots || slots.length === 0) return null;
  
  const lower = input.toLowerCase();
  
  // Check for time mentions
  for (let i = 0; i < slots.length; i++) {
    const slot = slots[i];
    if (lower.includes(slot.time?.toLowerCase()) || 
        lower.includes(slot.startTime?.toLowerCase())) {
      return i;
    }
  }
  
  // Check for numeric/ordinal selection
  if (lower.includes('first') || lower.includes('1st')) return 0;
  if (lower.includes('second') || lower.includes('2nd')) return 1;
  if (lower.includes('third') || lower.includes('3rd')) return 2;
  
  const numMatch = input.match(/(\d+)/);
  if (numMatch) {
    return parseInt(numMatch[1]) - 1;
  }
  
  return null;
}

/**
 * Detect if caller is requesting a link to be sent
 */
function detectLinkRequest(input) {
  const lower = (input || '').toLowerCase();

  // Trigger words indicating they want something sent to their phone
  const sendTriggers = ['send', 'text', 'message', 'email', 'forward'];
  const hasSendTrigger = sendTriggers.some(t => lower.includes(t));

  // Also catch "can I get directions" / "I need the address" patterns
  const getTriggers = ['get', 'need', 'want', 'give me', 'how do i get'];
  const hasGetTrigger = getTriggers.some(t => lower.includes(t));

  // Directions / Location
  const directionWords = ['direction', 'address', 'location', 'map', 'where are you', 'how to get there', 'get there', 'find you', 'navigate'];
  if ((hasSendTrigger || hasGetTrigger) && directionWords.some(w => lower.includes(w))) {
    return 'directions';
  }

  // Forms
  const formWords = ['form', 'paperwork', 'intake', 'patient form'];
  if ((hasSendTrigger || hasGetTrigger) && formWords.some(w => lower.includes(w))) {
    return 'forms';
  }

  // Invoice / Payment
  const invoiceWords = ['invoice', 'bill', 'payment', 'pay', 'balance', 'owe'];
  if ((hasSendTrigger || hasGetTrigger) && invoiceWords.some(w => lower.includes(w))) {
    return 'invoice';
  }

  // Prescription
  const rxWords = ['prescription', 'rx', 'script'];
  if ((hasSendTrigger || hasGetTrigger) && rxWords.some(w => lower.includes(w))) {
    return 'prescription';
  }

  // Appointment
  const apptWords = ['appointment', 'confirmation', 'booking'];
  if ((hasSendTrigger || hasGetTrigger) && apptWords.some(w => lower.includes(w))) {
    return 'appointment';
  }

  // Schedule link
  if ((hasSendTrigger || hasGetTrigger) && (lower.includes('schedule') || lower.includes('book online'))) {
    return 'schedule';
  }

  // Insurance upload
  if ((hasSendTrigger || hasGetTrigger) && lower.includes('insurance')) {
    return 'insurance';
  }

  return null;
}

/**
 * Send link to phone number
 */
async function sendLinkToPhone(phoneNumber, linkType, session) {
  const baseUrl = getBaseUrl();
  
  const response = await fetch(`${baseUrl}/api/voice/send-link`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      phoneNumber,
      linkType,
      patientId: session.patient?.id,
    }),
  });

  if (!response.ok) {
    throw new Error(`Send link failed: ${response.status}`);
  }

  return response.json();
}

/**
 * Update session sentiment based on caller input
 * Detects frustration, anger, and satisfaction signals
 */
function updateSessionSentiment(session, input) {
  if (!input || !session.sentiment) return;
  
  const lowerInput = input.toLowerCase();
  
  // Frustration/anger indicators
  const frustrationWords = [
    'frustrated', 'frustrating', 'angry', 'upset', 'ridiculous',
    'unacceptable', 'terrible', 'awful', 'horrible', 'worst',
    'hate', 'stupid', 'idiot', 'incompetent', 'useless',
    'sick of', 'tired of', 'fed up', 'had enough', 'waste of time',
    'speak to someone', 'talk to a human', 'real person', 'manager',
    'supervisor', 'complaint', 'complain', 'sue', 'lawyer', 'attorney',
    'unbelievable', 'pathetic', 'disgrace', 'outrageous', 'insane',
  ];
  
  // Satisfaction indicators
  const satisfactionWords = [
    'thank you', 'thanks', 'great', 'perfect', 'wonderful',
    'appreciate', 'helpful', 'excellent', 'amazing', 'awesome',
    'good', 'nice', 'love', 'happy', 'pleased', 'satisfied',
  ];
  
  // Check for frustration signals
  let frustrationScore = 0;
  for (const word of frustrationWords) {
    if (lowerInput.includes(word)) {
      frustrationScore++;
      session.sentiment.frustrationSignals++;
    }
  }
  
  // Check for satisfaction signals
  let satisfactionScore = 0;
  for (const word of satisfactionWords) {
    if (lowerInput.includes(word)) {
      satisfactionScore++;
    }
  }
  
  // Update emotion detection
  if (frustrationScore >= 2) {
    session.sentiment.emotion = 'angry';
    session.sentiment.overallScore = Math.max(1, session.sentiment.overallScore - 1);
  } else if (frustrationScore === 1) {
    session.sentiment.emotion = 'frustrated';
    session.sentiment.overallScore = Math.max(1, session.sentiment.overallScore - 0.5);
  } else if (satisfactionScore >= 2) {
    session.sentiment.emotion = 'happy';
    session.sentiment.overallScore = Math.min(5, session.sentiment.overallScore + 0.5);
  } else if (satisfactionScore === 1) {
    session.sentiment.emotion = 'satisfied';
  }
  
  // Trigger escalation if frustration is high
  if (session.sentiment.frustrationSignals >= 3 || session.sentiment.overallScore <= 1.5) {
    session.sentiment.escalationNeeded = true;
    console.log('[AI Voice] Frustration threshold reached:', {
      signals: session.sentiment.frustrationSignals,
      score: session.sentiment.overallScore,
      emotion: session.sentiment.emotion,
    });
  }
}

/**
 * Get confirmation message after sending link
 */
function getLinkConfirmation(linkType) {
  const confirmations = {
    directions: "I just sent you a text with a link to our location and directions. You should receive it in just a moment. Is there anything else I can help you with?",
    forms: "I've texted you a link to our patient forms. You can fill them out before your visit to save time. Anything else?",
    invoice: "I just sent you a link to view and pay your invoice. Let me know if you have any questions about it.",
    prescription: "I've texted you a link to your prescription information. Is there anything else you need?",
    appointment: "I just sent your appointment details to your phone. You should see it shortly. Anything else I can help with?",
    schedule: "I've sent you a link to book or manage your appointments online. Is there anything else?",
    insurance: "I just texted you a link to upload your insurance card. This helps us verify your coverage before your visit. Anything else?",
  };

  return confirmations[linkType] || "I've sent that information to your phone. Is there anything else I can help with?";
}

/**
 * Fallback info when SMS send fails
 */
function getLinkFallbackInfo(linkType) {
  const fallbacks = {
    directions: "Our office is at 123 Vision Way, Suite 100, Dallas, Texas 75201. There's free parking in the rear lot. Is there anything else I can help with?",
    forms: "You can find our patient forms on our website. Is there anything else I can help with?",
    invoice: "Please call us back during business hours for billing questions. Is there anything else I can help with?",
    prescription: "For prescription information, please visit our website or call during business hours. Is there anything else?",
    appointment: "Is there anything else I can help you with today?",
    schedule: "You can schedule online through our website. Is there anything else I can help with?",
    insurance: "You can bring your insurance card to your visit and we'll take care of it. Is there anything else?",
  };

  return fallbacks[linkType] || "Is there anything else I can help you with?";
}

/**
 * Format session history into a readable transcript
 */
function formatTranscript(session) {
  if (!session?.history?.length) return null;

  const voiceSettings = getVoiceSettings();
  const agentName = voiceSettings.agentName || 'AI';

  return session.history
    .filter(h => h.content && h.content !== '[no speech detected]')
    .map(h => `${h.role === 'user' ? 'Caller' : agentName}: ${h.content}`)
    .join('\n');
}

/**
 * Save transcript to Supabase call_enrichments table for durable storage.
 * In-memory Maps don't survive Vercel serverless cold starts, so we persist
 * directly to the database.
 */
async function saveTranscript(session) {
  if (!session?.history?.length || session.history.length < 2) return;

  const transcript = formatTranscript(session);
  if (!transcript) return;

  try {
    const db = getDb();
    const { error } = await db.from('call_enrichments').upsert({
      call_sid: session.callSid,
      transcript,
      from_phone: session.fromPhone || null,
      direction: 'outbound-api',
      sentiment_score: session.sentiment?.overallScore ?? null,
      emotion: session.sentiment?.emotion ?? null,
      escalation_needed: session.sentiment?.escalationNeeded || false,
      escalation_reason: session.escalationReason || null,
      call_started_at: session.startTime?.toISOString?.() || session.startTime || null,
    }, { onConflict: 'call_sid' });

    if (error) {
      console.error('[AI Voice] DB transcript save error:', error.message);
    } else {
      console.log('[AI Voice] Transcript saved to DB for:', session.callSid?.slice(-8));
    }
  } catch (err) {
    console.error('[AI Voice] Failed to save transcript:', err.message);
  }
}
