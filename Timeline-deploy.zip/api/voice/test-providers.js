/**
 * Voice Provider Test API
 * 
 * Test endpoints for Deepgram STT and ElevenLabs TTS
 * GET - Check provider status and configuration
 * POST - Test transcription or speech synthesis
 */

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // Feature flags
  const useDeepgram = process.env.USE_DEEPGRAM_STT === 'true';
  const useElevenLabs = process.env.USE_ELEVENLABS_TTS === 'true';
  const backgroundNoise = process.env.VOICE_BACKGROUND_NOISE === 'true';

  // Check configuration
  const deepgramConfigured = process.env.DEEPGRAM_API_KEY && 
    process.env.DEEPGRAM_API_KEY !== 'your_deepgram_api_key_here';
  const elevenLabsConfigured = process.env.ELEVENLABS_API_KEY && 
    process.env.ELEVENLABS_API_KEY !== 'your_elevenlabs_api_key_here';

  if (req.method === 'GET') {
    // Return current configuration and status
    return res.status(200).json({
      success: true,
      providers: {
        stt: {
          current: useDeepgram ? 'deepgram' : 'twilio',
          deepgram: {
            enabled: useDeepgram,
            configured: deepgramConfigured,
          },
          twilio: {
            enabled: !useDeepgram,
            configured: true, // Always configured if Twilio is set up
          },
        },
        tts: {
          current: useElevenLabs ? 'elevenlabs' : 'twilio',
          elevenlabs: {
            enabled: useElevenLabs,
            configured: elevenLabsConfigured,
            voiceId: process.env.ELEVENLABS_VOICE_ID || '21m00Tcm4TlvDq8ikWAM',
          },
          twilio: {
            enabled: !useElevenLabs,
            configured: true,
          },
        },
        options: {
          backgroundNoise: backgroundNoise,
        },
      },
      featureFlags: {
        USE_DEEPGRAM_STT: useDeepgram,
        USE_ELEVENLABS_TTS: useElevenLabs,
        VOICE_BACKGROUND_NOISE: backgroundNoise,
      },
      instructions: {
        enableDeepgram: 'Set USE_DEEPGRAM_STT=true and DEEPGRAM_API_KEY in .env',
        enableElevenLabs: 'Set USE_ELEVENLABS_TTS=true and ELEVENLABS_API_KEY in .env',
        enableBackgroundNoise: 'Set VOICE_BACKGROUND_NOISE=true in .env',
      },
    });
  }

  if (req.method === 'POST') {
    const { action, audioUrl, text, voiceId } = req.body;

    // Test Deepgram transcription
    if (action === 'transcribe') {
      if (!deepgramConfigured) {
        return res.status(400).json({
          success: false,
          error: 'Deepgram not configured. Set DEEPGRAM_API_KEY in .env',
        });
      }

      if (!audioUrl) {
        return res.status(400).json({
          success: false,
          error: 'audioUrl is required for transcription test',
        });
      }

      try {
        const response = await fetch(
          'https://api.deepgram.com/v1/listen?model=nova-2-medical&punctuate=true&diarize=true&smart_format=true&utterances=true',
          {
            method: 'POST',
            headers: {
              'Authorization': `Token ${process.env.DEEPGRAM_API_KEY}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ url: audioUrl }),
          }
        );

        if (!response.ok) {
          const error = await response.text();
          return res.status(response.status).json({
            success: false,
            error: `Deepgram API error: ${error}`,
          });
        }

        const data = await response.json();
        const result = data.results?.channels?.[0]?.alternatives?.[0];
        const utterances = data.results?.utterances || [];

        // Format transcript with speaker labels
        const formattedTranscript = utterances.map(u => {
          const label = u.speaker === 0 ? 'Patient' : 'AI';
          return `${label}: ${u.transcript}`;
        }).join('\n');

        return res.status(200).json({
          success: true,
          provider: 'deepgram',
          result: {
            transcript: result?.transcript || '',
            confidence: result?.confidence || 0,
            duration: data.metadata?.duration || 0,
            speakers: data.results?.channels?.[0]?.detected_speakers || 0,
            formattedTranscript: formattedTranscript || result?.transcript,
            utterances: utterances.map(u => ({
              speaker: u.speaker === 0 ? 'Patient' : 'AI',
              text: u.transcript,
              start: u.start,
              end: u.end,
            })),
          },
        });
      } catch (error) {
        return res.status(500).json({
          success: false,
          error: `Transcription failed: ${error.message}`,
        });
      }
    }

    // Test ElevenLabs TTS
    if (action === 'synthesize') {
      if (!elevenLabsConfigured) {
        return res.status(400).json({
          success: false,
          error: 'ElevenLabs not configured. Set ELEVENLABS_API_KEY in .env',
        });
      }

      if (!text) {
        return res.status(400).json({
          success: false,
          error: 'text is required for speech synthesis test',
        });
      }

      try {
        const voice = voiceId || process.env.ELEVENLABS_VOICE_ID || '21m00Tcm4TlvDq8ikWAM';
        
        const response = await fetch(
          `https://api.elevenlabs.io/v1/text-to-speech/${voice}`,
          {
            method: 'POST',
            headers: {
              'Accept': 'audio/mpeg',
              'Content-Type': 'application/json',
              'xi-api-key': process.env.ELEVENLABS_API_KEY,
            },
            body: JSON.stringify({
              text,
              model_id: 'eleven_turbo_v2_5',
              voice_settings: {
                stability: 0.3,
                similarity_boost: 0.75,
                style: 0.55,
                use_speaker_boost: true,
              },
            }),
          }
        );

        if (!response.ok) {
          const error = await response.text();
          return res.status(response.status).json({
            success: false,
            error: `ElevenLabs API error: ${error}`,
          });
        }

        // Get audio as base64
        const audioBuffer = await response.arrayBuffer();
        const base64Audio = Buffer.from(audioBuffer).toString('base64');

        return res.status(200).json({
          success: true,
          provider: 'elevenlabs',
          result: {
            voiceId: voice,
            textLength: text.length,
            audioSize: audioBuffer.byteLength,
            audioBase64: base64Audio,
            mimeType: 'audio/mpeg',
          },
        });
      } catch (error) {
        return res.status(500).json({
          success: false,
          error: `Speech synthesis failed: ${error.message}`,
        });
      }
    }

    // List ElevenLabs voices
    if (action === 'listVoices') {
      if (!elevenLabsConfigured) {
        return res.status(400).json({
          success: false,
          error: 'ElevenLabs not configured',
        });
      }

      try {
        const response = await fetch('https://api.elevenlabs.io/v1/voices', {
          headers: {
            'xi-api-key': process.env.ELEVENLABS_API_KEY,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch voices: ${response.status}`);
        }

        const data = await response.json();
        return res.status(200).json({
          success: true,
          voices: data.voices.map(v => ({
            voiceId: v.voice_id,
            name: v.name,
            category: v.category,
            description: v.description,
            previewUrl: v.preview_url,
          })),
          recommended: {
            RACHEL: '21m00Tcm4TlvDq8ikWAM',
            DOMI: 'AZnzlk1XvdvUeBnXmlld',
            BELLA: 'EXAVITQu4vr4xnSDxMaL',
            ADAM: 'pNInz6obpgDQGcFmaJgB',
            JOSH: 'TxGEqnHWrfWFTfGW9XjX',
            ELLI: 'MF3mGyEYCl7XYWbV9V6O',
          },
        });
      } catch (error) {
        return res.status(500).json({
          success: false,
          error: error.message,
        });
      }
    }

    // Get ElevenLabs usage
    if (action === 'usage') {
      if (!elevenLabsConfigured) {
        return res.status(400).json({
          success: false,
          error: 'ElevenLabs not configured',
        });
      }

      try {
        const response = await fetch('https://api.elevenlabs.io/v1/user/subscription', {
          headers: {
            'xi-api-key': process.env.ELEVENLABS_API_KEY,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch usage: ${response.status}`);
        }

        const data = await response.json();
        return res.status(200).json({
          success: true,
          usage: {
            characterCount: data.character_count,
            characterLimit: data.character_limit,
            remainingCharacters: data.character_limit - data.character_count,
            percentUsed: ((data.character_count / data.character_limit) * 100).toFixed(1),
          },
        });
      } catch (error) {
        return res.status(500).json({
          success: false,
          error: error.message,
        });
      }
    }

    return res.status(400).json({
      success: false,
      error: 'Invalid action. Use: transcribe, synthesize, listVoices, or usage',
    });
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
