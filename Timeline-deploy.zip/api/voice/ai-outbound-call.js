/**
 * AI-Powered Outbound Call System
 * 
 * Makes intelligent outbound calls with:
 * - ElevenLabs high-quality voice synthesis
 * - Claude AI for dynamic conversation
 * - Deepgram for speech recognition
 * - Patient context awareness
 * - Appointment reminders, follow-ups, surveys
 */

import twilio from 'twilio';
import { getVoiceSettingsAsync } from './settings.js';

const getBaseUrl = () => {
  return process.env.VITE_APP_URL || 'https://patientcare-teal.vercel.app';
};

// Call templates — agentName is injected dynamically from voice settings
function getCallTemplates(agentName) {
  return {
    appointment_reminder: {
      greeting: (patient, appointment) =>
        `Hi ${patient.firstName}! This is ${agentName} from ${appointment.officeName || 'Vision Care Center'}. ` +
        `I'm calling to remind you about your upcoming appointment on ${appointment.date} at ${appointment.time}. `,
      followup: 'Would you like to confirm this appointment?',
      confirmResponse: 'Great! You\'re all set. We\'ll see you then. Is there anything else I can help you with?',
      rescheduleResponse: 'No problem! I can help you reschedule. What day works better for you?',
      cancelResponse: 'I understand. I\'ll cancel this appointment for you. Would you like to schedule a new appointment?',
    },

    post_visit_followup: {
      greeting: (patient) =>
        `Hi ${patient.firstName}! This is ${agentName} from Vision Care Center. ` +
        `I'm following up on your recent visit. How are you feeling?`,
      followup: 'Is there anything you\'d like us to know about your experience?',
    },

    prescription_ready: {
      greeting: (patient) =>
        `Hi ${patient.firstName}! Great news from Vision Care Center. ` +
        `Your prescription is ready for pickup. `,
      followup: 'Will you be picking it up today, or would you like us to hold it for you?',
    },

    recall_reminder: {
      greeting: (patient) =>
        `Hi ${patient.firstName}! This is ${agentName} from Vision Care Center. ` +
        `According to our records, it's been about a year since your last eye exam. ` +
        `Annual exams are important for maintaining good eye health.`,
      followup: 'Would you like me to help you schedule an appointment?',
    },

    custom: {
      greeting: (patient, context) => context.customGreeting || `Hi ${patient.firstName}! This is ${agentName} from Vision Care Center calling.`,
      followup: (context) => context.customFollowup || 'How can I help you today?',
    }
  };
}

export default async function handler(req, res) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    // Get saved voice settings from DB (handles cold start)
    const savedVoiceSettings = await getVoiceSettingsAsync();
    
    const {
      to,
      patientId,
      patientFirstName,
      patientLastName,
      callType = 'custom',
      appointmentDate,
      appointmentTime,
      providerName,
      officeName,
      customGreeting,
      customFollowup,
      script, // Custom script from template - overrides template
      useElevenLabs = true,
      voicePreset = savedVoiceSettings.voiceName || 'emily',
      recordCall = true,
      voiceSpeed = savedVoiceSettings.voiceSpeed || 1.15,
    } = req.body;

    if (!to) {
      return res.status(400).json({ error: 'Missing required field: to (phone number)' });
    }

    // Build patient context
    const patient = {
      id: patientId,
      firstName: patientFirstName || 'there',
      lastName: patientLastName || '',
    };

    // Build appointment context
    const appointment = {
      date: appointmentDate,
      time: appointmentTime,
      officeName: officeName || 'Vision Care Center',
    };

    // Use custom script if provided, otherwise use template
    let fullMessage;
    
    if (script && script.trim()) {
      // Use provided script directly
      fullMessage = script.trim();
      console.log('[AI Outbound] Using custom script');
    } else {
      // Get template with dynamic agent name
      const templates = getCallTemplates(savedVoiceSettings.agentName || 'Emily');
      const template = templates[callType] || templates.custom;
      
      // Generate greeting
      const greeting = typeof template.greeting === 'function' 
        ? template.greeting(patient, appointment)
        : template.greeting;
      
      const followup = typeof template.followup === 'function'
        ? template.followup({ customFollowup })
        : template.followup;

      fullMessage = `${greeting} ${followup}`;
    }

    // Check Twilio credentials
    if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN) {
      return res.status(500).json({ error: 'Twilio credentials not configured' });
    }

    const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    const baseUrl = getBaseUrl();
    
    // Build callback URL for conversation continuation
    const callbackUrl = `${baseUrl}/api/voice/ai-call-response`;
    
    // Pass all parameters to TwiML endpoint (including stability/style)
    const twimlUrl = `${baseUrl}/api/voice/outbound-twiml?` + new URLSearchParams({
      message: fullMessage,
      callbackUrl,
      useElevenLabs: useElevenLabs.toString(),
      voicePreset,
      voiceSpeed: voiceSpeed.toString(),
      stability: (savedVoiceSettings.stability ?? 0.3).toString(),
      style: (savedVoiceSettings.style ?? 0.55).toString(),
    }).toString();

    // Make the call with recording enabled
    const call = await client.calls.create({
      to,
      from: process.env.TWILIO_PHONE_NUMBER,
      url: twimlUrl,
      record: recordCall,
      recordingStatusCallback: `${baseUrl}/api/webhooks/twilio-status`,
      recordingStatusCallbackEvent: ['completed'],
      statusCallback: `${baseUrl}/api/webhooks/twilio-status`,
      statusCallbackEvent: ['initiated', 'ringing', 'answered', 'completed'],
    });

    console.log('[AI Outbound] Call initiated:', {
      callSid: call.sid,
      to,
      callType,
      patientId,
    });

    return res.status(200).json({
      success: true,
      callId: call.sid,
      status: call.status,
      to,
      callType,
      message: fullMessage.substring(0, 100) + '...',
      elevenLabs: useElevenLabs && !!process.env.ELEVENLABS_API_KEY,
    });

  } catch (error) {
    console.error('[AI Outbound] Call error:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to initiate call',
    });
  }
}

function escapeXml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
