/**
 * Transfer Complete Handler
 * 
 * Called by Twilio after a Dial action completes (transfer attempt)
 * Handles both successful transfers and failed/unanswered transfers
 */

export default async function handler(req, res) {
  res.setHeader('Content-Type', 'text/xml');
  
  const { DialCallStatus, DialCallDuration, CallSid } = req.body || {};
  
  console.log('[Transfer Complete] Status:', DialCallStatus, 'Duration:', DialCallDuration);

  // If call was answered and completed, just hang up
  if (DialCallStatus === 'completed' || DialCallStatus === 'answered') {
    return res.status(200).send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Hangup/>
</Response>`);
  }

  // If transfer failed (busy, no-answer, failed), offer voicemail
  return res.status(200).send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Joanna">I'm sorry, no one is available right now. Please leave a message after the tone, and someone will call you back as soon as possible.</Say>
  <Record maxLength="120" transcribe="true" playBeep="true" action="/api/voice/voicemail-complete"/>
  <Say voice="Polly.Joanna">Thank you for your message. We'll get back to you soon. Goodbye!</Say>
  <Hangup/>
</Response>`);
}
