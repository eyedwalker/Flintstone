/**
 * Book Appointment via Eyefinity API
 * 
 * Multi-step booking flow:
 * 1. verify_patient - Search and verify patient identity
 * 2. select_office - Choose office location
 * 3. select_provider - Choose doctor/provider
 * 4. find_slots - Get available slots for provider at office
 * 5. book - Create the appointment
 * 
 * Each step returns nextStep and required data for the AI to continue
 */

const getBaseUrl = () => process.env.VITE_APP_URL || 'https://patientcare-teal.vercel.app';

// Default office for single-location practices
const DEFAULT_OFFICE = {
  id: process.env.DEFAULT_OFFICE_ID || '1',
  name: 'Vision Care Center',
  address: '123 Vision Way, Suite 100, Dallas, TX 75201',
};

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { step = 'verify_patient', ...params } = req.body;
    
    console.log('[Book Appointment] Step:', step, 'Params:', JSON.stringify(params).slice(0, 200));

    switch (step) {
      case 'verify_patient':
        return await handleVerifyPatient(params, res);
      
      case 'select_office':
        return await handleSelectOffice(params, res);
      
      case 'select_provider':
        return await handleSelectProvider(params, res);
      
      case 'find_slots':
        return await handleFindSlots(params, res);
      
      case 'book':
        return await handleBookAppointment(params, res);
      
      default:
        return res.status(400).json({ error: `Unknown step: ${step}` });
    }

  } catch (error) {
    console.error('[Book Appointment] Error:', error);
    return res.status(500).json({ 
      success: false, 
      error: error.message,
    });
  }
}

/**
 * Step 1: Verify Patient Identity
 * - Search by phone and/or name
 * - If multiple matches, return list with DOB for disambiguation
 * - If no matches, offer to create new patient
 */
async function handleVerifyPatient(params, res) {
  const { patientPhone, patientName, patientDOB, isNewPatient } = params;
  
  if (!patientPhone && !patientName) {
    return res.status(200).json({
      success: false,
      needsInfo: true,
      message: 'I need your phone number or name to look up your record.',
      askFor: ['patientPhone', 'patientName'],
    });
  }

  // If explicitly creating new patient
  if (isNewPatient) {
    return res.status(200).json({
      success: true,
      isNewPatient: true,
      message: 'I\'ll set you up as a new patient.',
      nextStep: 'select_office',
      patientData: { patientPhone, patientName, patientDOB, isNewPatient: true },
    });
  }

  const patients = await searchPatients(patientPhone, patientName);
  
  // No matches found
  if (patients.length === 0) {
    return res.status(200).json({
      success: true,
      noMatchFound: true,
      message: `I couldn't find a patient record for ${patientName || patientPhone}. Would you like me to set you up as a new patient?`,
      nextStep: 'verify_patient',
      suggestNewPatient: true,
      patientData: { patientPhone, patientName },
    });
  }

  // Single exact match
  if (patients.length === 1) {
    const p = patients[0];
    return res.status(200).json({
      success: true,
      patientVerified: true,
      patient: {
        id: p.PatientId || p.patientId,
        firstName: p.FirstName || p.firstName,
        lastName: p.LastName || p.lastName,
        dob: p.DateOfBirth || p.dob,
        phone: p.Phone || p.phone,
      },
      message: `I found your record, ${p.FirstName || p.firstName}. Let me check availability for you.`,
      nextStep: 'select_office',
    });
  }

  // Multiple matches - need disambiguation
  const patientOptions = patients.slice(0, 5).map(p => ({
    id: p.PatientId || p.patientId,
    name: `${p.FirstName || p.firstName} ${p.LastName || p.lastName}`,
    dob: p.DateOfBirth || p.dob,
    phone: p.Phone || p.phone,
  }));

  return res.status(200).json({
    success: true,
    multipleMatches: true,
    patients: patientOptions,
    message: `I found ${patients.length} patients with that information. Can you confirm your date of birth so I can find the right record?`,
    askFor: ['patientDOB'],
    nextStep: 'verify_patient',
  });
}

/**
 * Step 2: Select Office (for multi-location practices)
 */
async function handleSelectOffice(params, res) {
  const { patientData, officeId } = params;
  
  // If office already selected, proceed
  if (officeId) {
    return res.status(200).json({
      success: true,
      officeSelected: true,
      officeId,
      nextStep: 'select_provider',
      patientData,
    });
  }

  // Get available offices
  const offices = await getOffices();
  
  // Single office - auto-select
  if (offices.length <= 1) {
    const office = offices[0] || DEFAULT_OFFICE;
    return res.status(200).json({
      success: true,
      officeSelected: true,
      office,
      officeId: office.id,
      message: `I'll check availability at ${office.name}.`,
      nextStep: 'select_provider',
      patientData,
    });
  }

  // Multiple offices - ask user
  return res.status(200).json({
    success: true,
    multipleOffices: true,
    offices: offices.map(o => ({ id: o.id, name: o.name, address: o.address })),
    message: 'Which location works best for you?',
    askFor: ['officeId'],
    nextStep: 'select_office',
    patientData,
  });
}

/**
 * Step 3: Select Provider/Doctor
 */
async function handleSelectProvider(params, res) {
  const { patientData, officeId, providerId, providerName, preferredDate, preferredTime } = params;
  
  if (!officeId) {
    return res.status(200).json({
      success: false,
      error: 'Office must be selected first',
      nextStep: 'select_office',
      patientData,
    });
  }

  // If provider already selected, proceed to slots
  if (providerId) {
    return res.status(200).json({
      success: true,
      providerSelected: true,
      providerId,
      nextStep: 'find_slots',
      patientData,
      officeId,
      preferredDate,
      preferredTime,
    });
  }

  // Get providers at this office
  const providers = await getProviders(officeId);
  
  // If user specified a provider name, try to match
  if (providerName) {
    const lowerName = providerName.toLowerCase();
    const matched = providers.find(p => 
      p.fullName?.toLowerCase().includes(lowerName) ||
      p.lastName?.toLowerCase().includes(lowerName)
    );
    
    if (matched) {
      return res.status(200).json({
        success: true,
        providerSelected: true,
        provider: { id: matched.guid || matched.staffId, name: matched.fullName },
        providerId: matched.guid || matched.staffId,
        message: `Great, I'll check ${matched.fullName}'s availability.`,
        nextStep: 'find_slots',
        patientData,
        officeId,
        preferredDate,
        preferredTime,
      });
    }
  }

  // No specific provider - show options or use first available
  if (providers.length === 0) {
    return res.status(200).json({
      success: false,
      error: 'No providers available at this office',
      nextStep: 'select_office',
      patientData,
    });
  }

  // Ask user to select or offer "first available"
  return res.status(200).json({
    success: true,
    multipleProviders: true,
    providers: providers.slice(0, 5).map(p => ({
      id: p.guid || p.staffId,
      name: p.fullName,
      specialty: p.specialty || 'Optometrist',
    })),
    message: 'Do you have a preferred doctor, or would you like the first available appointment?',
    askFor: ['providerName'],
    allowFirstAvailable: true,
    nextStep: 'select_provider',
    patientData,
    officeId,
    preferredDate,
    preferredTime,
  });
}

/**
 * Step 4: Find Available Slots
 */
async function handleFindSlots(params, res) {
  const { patientData, officeId, providerId, preferredDate, preferredTime, appointmentType } = params;
  
  if (!officeId || !providerId) {
    return res.status(200).json({
      success: false,
      error: 'Office and provider must be selected first',
      nextStep: !officeId ? 'select_office' : 'select_provider',
      patientData,
      officeId,
    });
  }

  const targetDate = parseDate(preferredDate) || getNextBusinessDay();
  const slots = await getAvailableSlots(officeId, providerId, targetDate, preferredTime, appointmentType);
  
  if (!slots || slots.length === 0) {
    return res.status(200).json({
      success: true,
      noSlotsAvailable: true,
      message: `I don't see any openings on ${formatDate(targetDate)}. Would you like me to check a different day?`,
      askFor: ['preferredDate'],
      nextStep: 'find_slots',
      patientData,
      officeId,
      providerId,
    });
  }

  // Return top slots
  return res.status(200).json({
    success: true,
    slotsFound: true,
    slots: slots.slice(0, 5).map(s => ({
      date: s.date,
      time: s.startTime || s.time,
      provider: s.providerName,
      providerId: s.providerId,
    })),
    message: `I have openings on ${formatDate(slots[0].date)}. Would ${formatTime(slots[0].startTime || slots[0].time)} work for you?`,
    nextStep: 'book',
    patientData,
    officeId,
    providerId,
  });
}

/**
 * Step 5: Book the Appointment
 */
async function handleBookAppointment(params, res) {
  const { 
    patientData, 
    officeId, 
    providerId, 
    selectedSlot,
    appointmentType = 'eye_exam',
    notes,
  } = params;

  if (!selectedSlot) {
    return res.status(200).json({
      success: false,
      error: 'No slot selected',
      nextStep: 'find_slots',
      patientData,
      officeId,
      providerId,
    });
  }

  // Create the appointment
  const appointment = await createAppointment({
    patientId: patientData?.patient?.id,
    patientPhone: patientData?.patientPhone,
    patientName: patientData?.patientName,
    isNewPatient: patientData?.isNewPatient,
    officeId,
    providerId,
    date: selectedSlot.date,
    time: selectedSlot.time,
    type: appointmentType,
    notes,
  });

  console.log('[Book Appointment] Created:', appointment);

  return res.status(200).json({
    success: true,
    booked: true,
    appointment: {
      id: appointment.id,
      date: appointment.date,
      time: appointment.time,
      provider: appointment.provider,
      location: appointment.location || 'Vision Care Center',
    },
    message: `Perfect! You're all set for ${formatDate(appointment.date)} at ${formatTime(appointment.time)} with ${appointment.provider}.`,
  });
}

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Search patients by phone and/or name
 * Returns multiple matches for disambiguation
 */
async function searchPatients(phone, name) {
  const baseUrl = getBaseUrl();
  const params = new URLSearchParams({ pageSize: '10' });
  
  if (phone) {
    const cleanPhone = phone.replace(/\D/g, '').slice(-10);
    params.append('Phone', cleanPhone);
  }
  
  if (name) {
    const names = name.trim().split(' ');
    if (names.length >= 2) {
      params.append('FirstName', names[0]);
      params.append('LastName', names[names.length - 1]);
    } else {
      params.append('LastName', names[0]);
    }
  }

  try {
    const response = await fetch(`${baseUrl}/api/eyefinity/v2patients?${params}`);
    
    if (response.ok) {
      const data = await response.json();
      return data.items || [];
    }
  } catch (err) {
    console.log('[Book Appointment] Patient search failed:', err.message);
  }
  
  return [];
}

/**
 * Get available offices
 */
async function getOffices() {
  const baseUrl = getBaseUrl();

  try {
    const response = await fetch(`${baseUrl}/api/eyefinity/v2offices`);
    
    if (response.ok) {
      const data = await response.json();
      return (data.items || []).map(o => ({
        id: o.OfficeId || o.officeId || o.id,
        name: o.OfficeName || o.officeName || o.name,
        address: o.Address || o.address,
      }));
    }
  } catch (err) {
    console.log('[Book Appointment] Office fetch failed:', err.message);
  }
  
  // Return default office if API fails
  return [DEFAULT_OFFICE];
}

/**
 * Get providers/doctors at an office
 */
async function getProviders(officeId) {
  const baseUrl = getBaseUrl();

  try {
    const response = await fetch(`${baseUrl}/api/eyefinity/v2staff?officeId=${officeId}&isProvider=true`);
    
    if (response.ok) {
      const data = await response.json();
      return (data.items || []).map(p => ({
        guid: p.Guid || p.guid || p.staffId,
        staffId: p.StaffId || p.staffId,
        fullName: p.FullName || p.fullName || `${p.FirstName || ''} ${p.LastName || ''}`.trim(),
        firstName: p.FirstName || p.firstName,
        lastName: p.LastName || p.lastName,
        specialty: p.Specialty || p.specialty || 'Optometrist',
      }));
    }
  } catch (err) {
    console.log('[Book Appointment] Provider fetch failed:', err.message);
  }
  
  // Return mock providers if API fails
  return [
    { guid: 'dr-1', staffId: '1', fullName: 'Dr. Sarah Johnson', specialty: 'Optometrist' },
    { guid: 'dr-2', staffId: '2', fullName: 'Dr. Michael Chen', specialty: 'Optometrist' },
  ];
}

/**
 * Get available appointment slots for a provider at an office
 */
async function getAvailableSlots(officeId, providerId, targetDate, preferredTime, appointmentType) {
  const baseUrl = getBaseUrl();
  const isMorning = preferredTime?.toLowerCase().includes('morning') || 
                    preferredTime?.toLowerCase().includes('am');
  
  // Calculate date range (7 days)
  const fromDate = targetDate;
  const toDateObj = new Date(targetDate);
  toDateObj.setDate(toDateObj.getDate() + 7);
  const toDate = toDateObj.toISOString().split('T')[0];

  try {
    const params = new URLSearchParams({
      officeId,
      fromDate,
      toDate,
      itemDuration: '30',
      pageSize: '20',
    });
    
    const response = await fetch(`${baseUrl}/api/eyefinity/v2staff/${providerId}/appointmentSlots?${params}`);
    
    if (response.ok) {
      const data = await response.json();
      let slots = data.items || [];
      
      // Filter by morning/afternoon preference if specified
      if (preferredTime) {
        slots = slots.filter(slot => {
          const hour = parseInt((slot.startTime || slot.time || '12:00').split(':')[0]);
          return isMorning ? hour < 12 : hour >= 12;
        });
      }
      
      return slots;
    }
  } catch (err) {
    console.log('[Book Appointment] Slot fetch failed:', err.message);
  }

  // Fallback: Generate mock available slots
  const slots = [];
  
  if (isMorning) {
    slots.push({ date: targetDate, startTime: '08:30', providerName: 'Dr. Johnson', providerId });
    slots.push({ date: targetDate, startTime: '09:00', providerName: 'Dr. Johnson', providerId });
    slots.push({ date: targetDate, startTime: '10:30', providerName: 'Dr. Johnson', providerId });
  } else {
    slots.push({ date: targetDate, startTime: '13:30', providerName: 'Dr. Johnson', providerId });
    slots.push({ date: targetDate, startTime: '14:00', providerName: 'Dr. Johnson', providerId });
    slots.push({ date: targetDate, startTime: '15:30', providerName: 'Dr. Johnson', providerId });
  }

  return slots;
}

/**
 * Create appointment in Eyefinity
 */
async function createAppointment(appointmentData) {
  const baseUrl = getBaseUrl();
  const { patientId, officeId, providerId, date, time, type, notes, patientPhone, isNewPatient } = appointmentData;

  // Convert time to 24h format if needed
  const startTime = formatTime24(time);
  const endTimeDate = new Date(`2000-01-01T${startTime}`);
  endTimeDate.setMinutes(endTimeDate.getMinutes() + 30);
  const endTime = endTimeDate.toTimeString().slice(0, 5);

  try {
    const payload = {
      PatientId: patientId,
      OfficeId: officeId,
      StaffId: providerId,
      AppointmentDate: date,
      AppointmentStartTime: startTime,
      AppointmentEndTime: endTime,
      AppointmentTypeId: 1,
      AppointmentReason: type || 'Eye Exam',
      Notes: notes || (isNewPatient ? 'New patient - booked via AI' : `Booked via AI from ${patientPhone || 'phone call'}`),
      CancelIndicator: false,
    };

    const response = await fetch(`${baseUrl}/api/eyefinity/v2staff/${providerId}/appointments`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (response.ok) {
      const data = await response.json();
      return {
        id: data.AppointmentId || data.appointmentId || data.Id,
        date: date,
        time: time,
        provider: data.ProviderName || 'Dr. Johnson',
        location: DEFAULT_OFFICE.name,
        status: 'confirmed',
      };
    }
  } catch (err) {
    console.log('[Book Appointment] Eyefinity create failed:', err.message);
  }

  // Fallback: Create local confirmation
  return {
    id: `APT-${Date.now()}`,
    date: date,
    time: time,
    provider: 'Dr. Johnson',
    location: DEFAULT_OFFICE.name,
    status: 'pending_confirmation',
    note: 'Appointment request received - staff will confirm',
  };
}

/**
 * Parse natural language date
 */
function parseDate(input) {
  if (!input) return null;
  
  const lower = input.toLowerCase();
  const today = new Date();
  
  if (lower.includes('today')) {
    return today.toISOString().split('T')[0];
  }
  if (lower.includes('tomorrow')) {
    today.setDate(today.getDate() + 1);
    return today.toISOString().split('T')[0];
  }
  
  const weekdays = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  for (let i = 0; i < weekdays.length; i++) {
    if (lower.includes(weekdays[i])) {
      return getNextWeekday(i);
    }
  }
  
  // Try to parse as date
  const parsed = new Date(input);
  if (!isNaN(parsed)) {
    return parsed.toISOString().split('T')[0];
  }
  
  return null;
}

function getNextWeekday(dayOfWeek) {
  const today = new Date();
  const diff = (dayOfWeek - today.getDay() + 7) % 7 || 7;
  today.setDate(today.getDate() + diff);
  return today.toISOString().split('T')[0];
}

function getNextBusinessDay() {
  const today = new Date();
  let daysToAdd = 1;
  
  // Skip weekend
  if (today.getDay() === 5) daysToAdd = 3; // Friday -> Monday
  if (today.getDay() === 6) daysToAdd = 2; // Saturday -> Monday
  
  today.setDate(today.getDate() + daysToAdd);
  return today.toISOString().split('T')[0];
}

function formatDate(dateStr) {
  if (!dateStr) return 'the requested date';
  const date = new Date(dateStr + 'T12:00:00');
  return date.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
}

function formatTime(timeStr) {
  if (!timeStr) return 'the requested time';
  
  // Already formatted (e.g., "2:30 PM")
  if (timeStr.includes('AM') || timeStr.includes('PM')) return timeStr;
  
  // 24h format (e.g., "14:30")
  const [hours, minutes] = timeStr.split(':').map(Number);
  const period = hours >= 12 ? 'PM' : 'AM';
  const displayHours = hours % 12 || 12;
  return `${displayHours}:${minutes.toString().padStart(2, '0')} ${period}`;
}

function formatTime24(timeStr) {
  if (!timeStr) return '09:00';
  
  // Already 24h format
  if (!timeStr.includes('AM') && !timeStr.includes('PM')) {
    return timeStr.includes(':') ? timeStr : `${timeStr}:00`;
  }
  
  // Convert from 12h format
  const match = timeStr.match(/(\d{1,2}):?(\d{2})?\s*(AM|PM)/i);
  if (match) {
    let hours = parseInt(match[1]);
    const minutes = match[2] || '00';
    const period = match[3].toUpperCase();
    
    if (period === 'PM' && hours !== 12) hours += 12;
    if (period === 'AM' && hours === 12) hours = 0;
    
    return `${hours.toString().padStart(2, '0')}:${minutes}`;
  }
  
  return timeStr;
}
