/**
 * ElevenLabs Text-to-Speech API
 * 
 * Generates high-quality audio from text
 * Returns audio URL for Twilio <Play> tag
 */

// Cache generated audio URLs (avoid regenerating same text)
const audioCache = new Map();
const CACHE_TTL = 60 * 60 * 1000; // 1 hour

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    const text = req.method === 'GET' ? req.query.text : req.body?.text;
    const voice = req.method === 'GET' ? req.query.voice : req.body?.voice;

    if (!text) {
      return res.status(400).json({ error: 'Missing text parameter' });
    }

    const apiKey = process.env.ELEVENLABS_API_KEY;
    if (!apiKey) {
      console.log('[ElevenLabs TTS] No API key, falling back to Polly indicator');
      return res.status(200).json({ 
        fallback: true, 
        text,
        message: 'ElevenLabs not configured - use Polly',
      });
    }

    // Check cache
    const cacheKey = `${voice || 'sarah'}-${text}`;
    const cached = audioCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      console.log('[ElevenLabs TTS] Cache hit');
      return res.status(200).json({ audioUrl: cached.url, cached: true });
    }

    // Generate audio via ElevenLabs
    const audio = await generateElevenLabsAudio(text, voice, apiKey);
    
    if (audio.error) {
      return res.status(500).json({ error: audio.error, fallback: true });
    }

    // Cache the result
    audioCache.set(cacheKey, { url: audio.url, timestamp: Date.now() });

    // Clean old cache entries
    cleanCache();

    return res.status(200).json({ 
      audioUrl: audio.url,
      duration: audio.duration,
      cached: false,
    });

  } catch (error) {
    console.error('[ElevenLabs TTS] Error:', error);
    return res.status(500).json({ error: error.message, fallback: true });
  }
}

/**
 * Generate audio using ElevenLabs API
 */
async function generateElevenLabsAudio(text, voiceName, apiKey) {
  // Voice IDs from ElevenLabs
  const voices = {
    'sarah':   'EXAVITQu4vr4xnSDxMaL',
    'rachel':  '21m00Tcm4TlvDq8ikWAM',
    'emily':   'LcfcDJNUP1GQjkzn1xUU',
    'jessica': 'cgSgspJ2msm6clMCkdW9',
    'amy':     'nPczCjzI2devNBz1zQrb',
    'josh':    'TxGEqnHWrfWFTfGW9XjX',
    'adam':    'pNInz6obpgDQGcFmaJgB',
  };

  const voiceId = voices[voiceName?.toLowerCase()] || voices.emily;

  try {
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: 'POST',
      headers: {
        'Accept': 'audio/mpeg',
        'Content-Type': 'application/json',
        'xi-api-key': apiKey,
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_turbo_v2_5',
        voice_settings: {
          stability: 0.3,
          similarity_boost: 0.75,
          style: 0.55,
          use_speaker_boost: true,
        },
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error('[ElevenLabs TTS] API error:', error);
      return { error: `ElevenLabs API error: ${response.status}` };
    }

    // Get audio buffer
    const audioBuffer = await response.arrayBuffer();
    
    // Convert to base64 data URL (for immediate playback)
    const base64Audio = Buffer.from(audioBuffer).toString('base64');
    const dataUrl = `data:audio/mpeg;base64,${base64Audio}`;

    // For Twilio, we need a public URL - store temporarily and return URL
    // In production, upload to S3/Cloud Storage
    const audioUrl = await storeAudioTemporarily(audioBuffer, text);

    return { 
      url: audioUrl,
      duration: estimateDuration(text),
    };

  } catch (error) {
    console.error('[ElevenLabs TTS] Generation failed:', error);
    return { error: error.message };
  }
}

/**
 * Store audio temporarily and return URL
 * In production, use S3/Cloud Storage
 */
async function storeAudioTemporarily(audioBuffer, text) {
  // For now, we'll use a simple approach:
  // Store the audio in memory and serve via a separate endpoint
  const audioId = generateAudioId(text);
  
  // Store in global cache (accessible by generate-audio endpoint)
  global.audioStore = global.audioStore || new Map();
  global.audioStore.set(audioId, {
    buffer: Buffer.from(audioBuffer),
    contentType: 'audio/mpeg',
    createdAt: Date.now(),
  });

  const baseUrl = process.env.VITE_APP_URL || 'https://patientcare-teal.vercel.app';
  return `${baseUrl}/api/voice/serve-audio?id=${audioId}`;
}

/**
 * Generate unique audio ID
 */
function generateAudioId(text) {
  const hash = text.split('').reduce((a, b) => {
    a = ((a << 5) - a) + b.charCodeAt(0);
    return a & a;
  }, 0);
  return `el-${Math.abs(hash)}-${Date.now()}`;
}

/**
 * Estimate audio duration from text
 */
function estimateDuration(text) {
  // Average speaking rate: ~150 words per minute
  const words = text.split(/\s+/).length;
  return Math.ceil((words / 150) * 60);
}

/**
 * Clean old cache entries
 */
function cleanCache() {
  const now = Date.now();
  for (const [key, value] of audioCache.entries()) {
    if (now - value.timestamp > CACHE_TTL) {
      audioCache.delete(key);
    }
  }
}
