/**
 * Inbound Call Handler - AI Agent Greeting
 *
 * Configure in Twilio Console:
 * Phone Numbers → Your Number → Voice → "A Call Comes In" → POST to:
 * https://patientcare-teal.vercel.app/api/voice/inbound-call
 *
 * This greets callers and routes them to the AI conversation handler
 *
 * Uses ElevenLabs TTS when USE_ELEVENLABS_TTS or USE_ELEVENLABS_VOICE is true
 */

import { getVoiceSettingsAsync } from './settings.js';

const getBaseUrl = () => process.env.VITE_APP_URL || 'https://patientcare-teal.vercel.app';
const USE_ELEVENLABS = process.env.USE_ELEVENLABS_TTS === 'true' || process.env.USE_ELEVENLABS_VOICE === 'true';
const USE_BACKGROUND_NOISE = process.env.VOICE_BACKGROUND_NOISE === 'true';
const POLLY_VOICE = 'Polly.Joanna-Neural';

export default async function handler(req, res) {
  res.setHeader('Content-Type', 'text/xml');

  const { From, CallSid } = req.body || req.query || {};
  const baseUrl = getBaseUrl();

  // Get saved voice settings (async to load from DB on cold start)
  const voiceSettings = await getVoiceSettingsAsync();
  const agentName = voiceSettings.agentName || 'Emily';
  const voiceName = voiceSettings.voiceName || 'emily';

  console.log('[Inbound Call] From:', From, 'CallSid:', CallSid?.slice(-8), 'Voice:', voiceName, 'Agent:', agentName, 'ElevenLabs:', USE_ELEVENLABS);

  // Time-based greeting
  const hour = new Date().getHours();
  const timeGreeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  const greeting = `${timeGreeting} and thank you for calling Vision Care Center! This is ${agentName}, your virtual assistant. How can I help you today?`;
  const noInputMessage = "I didn't hear anything. If you need help, please call back or press zero to leave a message.";

  // Build speech tag based on provider — settings flow through to generate-audio
  const greetingSpeech = buildSpeechTag(greeting, baseUrl, voiceSettings);
  const noInputSpeech = buildSpeechTag(noInputMessage, baseUrl, voiceSettings);

  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Start>
    <Record recordingStatusCallback="${baseUrl}/api/webhooks/twilio-status" recordingStatusCallbackEvent="completed"/>
  </Start>
  ${greetingSpeech}
  <Gather input="speech" timeout="4" action="${baseUrl}/api/voice/ai-call-response" method="POST" speechTimeout="auto" language="en-US">
  </Gather>
  ${noInputSpeech}
  <Hangup/>
</Response>`;

  return res.status(200).send(twiml);
}

/**
 * Build speech tag - ElevenLabs Play or Twilio Say
 * Passes all voice settings through to generate-audio endpoint
 */
function buildSpeechTag(message, baseUrl, voiceSettings) {
  if (USE_ELEVENLABS) {
    const params = new URLSearchParams({
      voice: voiceSettings.voiceName || 'emily',
      text: message,
      stability: (voiceSettings.stability ?? 0.3).toString(),
      style: (voiceSettings.style ?? 0.55).toString(),
      speed: (voiceSettings.voiceSpeed ?? 1.15).toString(),
    });
    const audioUrl = `${baseUrl}/api/voice/generate-audio?${params.toString().replace(/&/g, '&amp;')}`;
    return `<Play>${audioUrl}</Play>`;
  }
  return `<Say voice="${POLLY_VOICE}">${escapeXml(message)}</Say>`;
}

function escapeXml(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
