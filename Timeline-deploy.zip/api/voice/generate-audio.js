/**
 * ElevenLabs Audio Generation API
 * Generates high-quality AI voice audio that Twilio can play
 *
 * Usage: GET /api/voice/generate-audio?text=Hello&voice=sarah&stability=0.3&style=0.4&speed=1.15
 * Returns: audio/mpeg stream
 */

import { getVoiceSettingsAsync } from './settings.js';

const ELEVENLABS_API_URL = 'https://api.elevenlabs.io/v1';

// Voice ID mappings
const VOICE_IDS = {
  sarah:   'EXAVITQu4vr4xnSDxMaL',
  rachel:  '21m00Tcm4TlvDq8ikWAM',
  emily:   'LcfcDJNUP1GQjkzn1xUU',
  jessica: 'cgSgspJ2msm6clMCkdW9',
  amy:     'nPczCjzI2devNBz1zQrb',
  josh:    'TxGEqnHWrfWFTfGW9XjX',
  adam:    'pNInz6obpgDQGcFmaJgB',
};

export default async function handler(req, res) {
  if (req.method !== 'GET' && req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const params = req.method === 'GET' ? req.query : req.body;
  const { text, voice, format = 'mp3_44100_128' } = params;

  if (!text) {
    return res.status(400).json({ error: 'Text parameter required' });
  }

  const apiKey = process.env.ELEVENLABS_API_KEY || process.env.VITE_ELEVENLABS_API_KEY;
  if (!apiKey) {
    console.error('[Audio] ElevenLabs API key not configured');
    return res.status(500).json({ error: 'Voice service not configured' });
  }

  // Get saved voice settings as defaults (loads from DB on cold start)
  const savedSettings = await getVoiceSettingsAsync();

  // Resolve voice ID
  const selectedVoice = voice || savedSettings.voiceName || 'emily';
  const voiceId = VOICE_IDS[selectedVoice] || VOICE_IDS.emily;

  // Use params if provided, fall back to saved settings, then defaults
  const stability = parseFloatParam(params.stability, savedSettings.stability, 0.3);
  const style = parseFloatParam(params.style, savedSettings.style, 0.55);
  const speed = parseFloatParam(params.speed, savedSettings.voiceSpeed, 1.15);

  try {
    console.log('[Audio] Generating:', {
      text: text.substring(0, 50) + '...',
      voice: selectedVoice,
      stability,
      style,
      speed,
      format,
    });

    const response = await fetch(
      `${ELEVENLABS_API_URL}/text-to-speech/${voiceId}?output_format=${format}`,
      {
        method: 'POST',
        headers: {
          'xi-api-key': apiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: cleanTextForSpeech(text),
          model_id: 'eleven_turbo_v2_5',
          voice_settings: {
            stability,
            similarity_boost: 0.75,
            style,
            use_speaker_boost: true,
          },
        }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('[Audio] ElevenLabs error:', response.status, error);
      return res.status(500).json({ error: 'Failed to generate audio' });
    }

    // Stream the audio response
    const contentType = format.startsWith('mp3') ? 'audio/mpeg' :
                       format.startsWith('pcm') ? 'audio/wav' :
                       'audio/basic';

    res.setHeader('Content-Type', contentType);
    res.setHeader('Cache-Control', 'public, max-age=3600');

    const audioBuffer = await response.arrayBuffer();
    return res.send(Buffer.from(audioBuffer));

  } catch (error) {
    console.error('[Audio] Generation failed:', error);
    return res.status(500).json({ error: 'Audio generation failed' });
  }
}

/**
 * Parse a float parameter with fallbacks
 */
function parseFloatParam(value, fallback1, fallback2) {
  if (value !== undefined && value !== null && value !== '') {
    const parsed = parseFloat(value);
    if (!isNaN(parsed)) return parsed;
  }
  if (fallback1 !== undefined && fallback1 !== null) return fallback1;
  return fallback2;
}

/**
 * Clean text for speech - light touch, no artificial pauses
 */
function cleanTextForSpeech(text) {
  return text
    .replace(/I am /g, "I'm ")
    .replace(/you are /g, "you're ")
    .replace(/we are /g, "we're ")
    .replace(/they are /g, "they're ")
    .replace(/it is /g, "it's ")
    .replace(/that is /g, "that's ")
    .replace(/what is /g, "what's ")
    .replace(/cannot /g, "can't ")
    .replace(/do not /g, "don't ")
    .replace(/does not /g, "doesn't ")
    .replace(/will not /g, "won't ")
    .replace(/would not /g, "wouldn't ");
}
