/**
 * Voicemail Complete Handler
 * 
 * Called after a voicemail recording is finished
 * Logs the recording URL for follow-up
 */

export default async function handler(req, res) {
  res.setHeader('Content-Type', 'text/xml');
  
  const { RecordingUrl, RecordingSid, CallSid, From, TranscriptionText } = req.body || {};
  
  console.log('[Voicemail] New voicemail received:', {
    callSid: CallSid?.slice(-8),
    from: From,
    recordingSid: RecordingSid,
    recordingUrl: RecordingUrl,
    transcription: TranscriptionText?.substring(0, 100),
  });

  // TODO: Save voicemail to database, send notification to staff
  // Could integrate with email/SMS to notify office of new voicemail

  return res.status(200).send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Joanna">Thank you for your message. We'll get back to you soon. Goodbye!</Say>
  <Hangup/>
</Response>`);
}
