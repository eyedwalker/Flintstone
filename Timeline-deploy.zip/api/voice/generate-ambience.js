/**
 * ElevenLabs Sound Effects API - Office Ambience Generator
 * 
 * Generates subtle office background sounds using ElevenLabs Sound Effects API
 * Used to make AI voice calls sound more natural
 * 
 * Usage: GET /api/voice/generate-ambience?type=office
 * Returns: audio/mpeg stream
 */

const ELEVENLABS_API_URL = 'https://api.elevenlabs.io/v1';

// Ambience prompts for different settings
const AMBIENCE_PROMPTS = {
  office: 'Subtle quiet office ambience, soft keyboard typing in background, very faint distant phone ringing, gentle air conditioning hum, professional workspace atmosphere',
  medical: 'Quiet medical office waiting room ambience, very soft background, gentle air conditioning, professional healthcare setting, calm atmosphere',
  reception: 'Professional reception desk ambience, subtle background activity, calm office environment, soft ambient noise',
  quiet: 'Very subtle room tone, almost silent background ambience, gentle air movement',
};

// Cache for generated ambience (to avoid regenerating)
const ambienceCache = new Map();

export default async function handler(req, res) {
  if (req.method !== 'GET' && req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { type = 'office', duration = 30, refresh = 'false' } = req.query;
  const forceRefresh = refresh === 'true';

  const apiKey = process.env.ELEVENLABS_API_KEY;
  if (!apiKey) {
    console.error('[Ambience] ElevenLabs API key not configured');
    return res.status(500).json({ error: 'Voice service not configured' });
  }

  const prompt = AMBIENCE_PROMPTS[type] || AMBIENCE_PROMPTS.office;
  const cacheKey = `${type}-${duration}`;

  // Check cache first (unless force refresh)
  if (!forceRefresh && ambienceCache.has(cacheKey)) {
    console.log('[Ambience] Serving from cache:', type);
    const cached = ambienceCache.get(cacheKey);
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Cache-Control', 'public, max-age=86400'); // Cache for 24 hours
    return res.send(cached);
  }

  try {
    console.log('[Ambience] Generating:', { type, duration, prompt: prompt.substring(0, 50) + '...' });

    const response = await fetch(
      `${ELEVENLABS_API_URL}/sound-generation`,
      {
        method: 'POST',
        headers: {
          'xi-api-key': apiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: prompt,
          duration_seconds: Math.min(parseFloat(duration), 30), // Max 30 seconds
          prompt_influence: 0.3, // Lower = more creative/natural
        }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('[Ambience] ElevenLabs error:', response.status, error);
      return res.status(500).json({ error: 'Failed to generate ambience' });
    }

    const audioBuffer = Buffer.from(await response.arrayBuffer());
    
    // Cache the result
    ambienceCache.set(cacheKey, audioBuffer);
    console.log('[Ambience] Generated and cached:', type, audioBuffer.length, 'bytes');

    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    return res.send(audioBuffer);

  } catch (error) {
    console.error('[Ambience] Generation failed:', error);
    return res.status(500).json({ error: 'Ambience generation failed' });
  }
}
