/**
 * Voice Settings API
 *
 * GET - Retrieve current voice settings
 * POST - Save voice settings
 *
 * Settings are persisted to Supabase (voice_settings table) with in-memory cache.
 * Falls back to in-memory + defaults if Supabase is not configured.
 */

import { getDb } from '../_lib/db.js';

// Default settings — single source of truth for all voice endpoints
const DEFAULT_SETTINGS = {
  voiceName: 'emily',
  agentName: 'Emily',
  stability: 0.3,
  style: 0.55,
  voiceSpeed: 1.15,
  greeting: '',
};

// In-memory cache (fast reads, persists within same serverless instance)
let cachedSettings = null;
let cacheTimestamp = 0;
const CACHE_TTL = 60 * 1000; // 1 minute cache

/**
 * Load settings from database
 */
async function loadFromDb() {
  try {
    const supabase = getDb();
    const { data, error } = await supabase
      .from('voice_settings')
      .select('settings')
      .eq('id', 'default')
      .single();

    if (error || !data) return null;
    return data.settings;
  } catch (err) {
    console.error('[Voice Settings] DB load error:', err.message);
    return null;
  }
}

/**
 * Save settings to database
 */
async function saveToDb(settings) {
  try {
    const supabase = getDb();
    const { error } = await supabase
      .from('voice_settings')
      .upsert({
        id: 'default',
        settings,
        updated_at: new Date().toISOString(),
      });

    if (error) {
      console.error('[Voice Settings] DB save error:', error.message);
      return false;
    }
    return true;
  } catch (err) {
    console.error('[Voice Settings] DB save error:', err.message);
    return false;
  }
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method === 'GET') {
    // Try cache first, then DB, then defaults
    let settings = cachedSettings;
    let source = 'cache';

    if (!settings || Date.now() - cacheTimestamp > CACHE_TTL) {
      const dbSettings = await loadFromDb();
      if (dbSettings) {
        settings = dbSettings;
        cachedSettings = dbSettings;
        cacheTimestamp = Date.now();
        source = 'database';
      }
    }

    if (!settings) {
      settings = {
        ...DEFAULT_SETTINGS,
        voiceName: process.env.ELEVENLABS_VOICE_NAME || DEFAULT_SETTINGS.voiceName,
      };
      source = 'defaults';
    }

    return res.status(200).json({
      success: true,
      settings,
      source,
    });
  }

  if (req.method === 'POST') {
    const { voiceName, agentName, stability, style, voiceSpeed, greeting } = req.body;

    // Validate
    const validVoices = ['emily', 'amy', 'jessica', 'sarah', 'rachel', 'josh', 'adam'];
    if (voiceName && !validVoices.includes(voiceName)) {
      return res.status(400).json({
        success: false,
        error: `Invalid voice. Choose from: ${validVoices.join(', ')}`,
      });
    }

    // Build settings
    const settings = {
      voiceName: voiceName || DEFAULT_SETTINGS.voiceName,
      agentName: agentName || DEFAULT_SETTINGS.agentName,
      stability: typeof stability === 'number' ? stability : DEFAULT_SETTINGS.stability,
      style: typeof style === 'number' ? style : DEFAULT_SETTINGS.style,
      voiceSpeed: typeof voiceSpeed === 'number' ? voiceSpeed : DEFAULT_SETTINGS.voiceSpeed,
      greeting: greeting || DEFAULT_SETTINGS.greeting,
    };

    // Save to memory cache
    cachedSettings = settings;
    cacheTimestamp = Date.now();

    // Persist to database
    const persisted = await saveToDb(settings);

    console.log('[Voice Settings] Saved:', settings, 'Persisted:', persisted);

    return res.status(200).json({
      success: true,
      settings,
      persisted,
      message: persisted
        ? 'Settings saved and persisted to database.'
        : 'Settings saved to memory. Create voice_settings table for persistence across deploys.',
    });
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

/**
 * Get current voice settings (for use by other API endpoints)
 * Returns cached settings, or defaults if nothing saved yet.
 * Note: This is synchronous for fast access from TwiML builders.
 * The cache is populated on first GET request or POST save.
 */
export function getVoiceSettings() {
  return cachedSettings || {
    ...DEFAULT_SETTINGS,
    voiceName: process.env.ELEVENLABS_VOICE_NAME || DEFAULT_SETTINGS.voiceName,
  };
}

/**
 * Async version that checks DB if cache is empty (for use at call start)
 */
export async function getVoiceSettingsAsync() {
  if (cachedSettings && Date.now() - cacheTimestamp < CACHE_TTL) {
    return cachedSettings;
  }

  const dbSettings = await loadFromDb();
  if (dbSettings) {
    cachedSettings = dbSettings;
    cacheTimestamp = Date.now();
    return dbSettings;
  }

  return {
    ...DEFAULT_SETTINGS,
    voiceName: process.env.ELEVENLABS_VOICE_NAME || DEFAULT_SETTINGS.voiceName,
  };
}
