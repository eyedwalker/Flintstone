/**
 * Send Link via SMS During Voice Call
 * 
 * Sends contextual links to caller while on the phone:
 * - Directions / Google Maps
 * - Appointment confirmation
 * - Invoice / Payment link
 * - Prescription info
 * - Forms to fill out
 * 
 * Called by AI during conversation when user requests info
 */

import twilio from 'twilio';

const getBaseUrl = () => process.env.VITE_APP_URL || 'https://patientcare-teal.vercel.app';

// Link templates
const LINK_TEMPLATES = {
  directions: {
    message: "Here's a link to our location with directions:",
    url: "https://maps.google.com/?q=123+Vision+Way+Suite+100+Dallas+TX+75201",
    type: "location",
  },
  appointment: {
    message: "Here's your appointment details:",
    url: `${getBaseUrl()}/appointments/{{appointmentId}}`,
    type: "appointment",
  },
  invoice: {
    message: "Here's a link to view and pay your invoice:",
    url: `${getBaseUrl()}/pay/{{invoiceId}}`,
    type: "payment",
  },
  prescription: {
    message: "Here's your prescription information:",
    url: `${getBaseUrl()}/rx/{{patientId}}`,
    type: "prescription",
  },
  forms: {
    message: "Please complete these forms before your visit:",
    url: `${getBaseUrl()}/forms/intake?patient={{patientId}}`,
    type: "forms",
  },
  schedule: {
    message: "Book or manage your appointment online:",
    url: `${getBaseUrl()}/schedule`,
    type: "scheduling",
  },
  insurance: {
    message: "Upload your insurance card here:",
    url: `${getBaseUrl()}/upload-insurance?patient={{patientId}}`,
    type: "insurance",
  },
  contact: {
    message: "Save our contact info:",
    url: `${getBaseUrl()}/contact`,
    type: "contact",
  },
};

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const {
      phoneNumber,
      linkType,
      patientId,
      appointmentId,
      invoiceId,
      customMessage,
      customUrl,
    } = req.body;

    if (!phoneNumber) {
      return res.status(400).json({ error: 'Missing phoneNumber' });
    }

    if (!linkType && !customUrl) {
      return res.status(400).json({ error: 'Missing linkType or customUrl' });
    }

    // Get template or use custom
    let message, url;
    
    if (customUrl) {
      message = customMessage || "Here's the link you requested:";
      url = customUrl;
    } else {
      const template = LINK_TEMPLATES[linkType];
      if (!template) {
        return res.status(400).json({ 
          error: 'Invalid linkType', 
          validTypes: Object.keys(LINK_TEMPLATES),
        });
      }
      
      message = template.message;
      url = template.url
        .replace('{{patientId}}', patientId || '')
        .replace('{{appointmentId}}', appointmentId || '')
        .replace('{{invoiceId}}', invoiceId || '');
    }

    // Send SMS with link
    const client = twilio(
      process.env.TWILIO_ACCOUNT_SID,
      process.env.TWILIO_AUTH_TOKEN
    );

    const fullMessage = `${message}\n\n${url}\n\n- Vision Care Center`;

    const result = await client.messages.create({
      body: fullMessage,
      to: phoneNumber,
      from: process.env.TWILIO_PHONE_NUMBER,
    });

    console.log('[Send Link] Sent to', phoneNumber, '- Type:', linkType || 'custom', '- SID:', result.sid);

    return res.status(200).json({
      success: true,
      messageId: result.sid,
      linkType: linkType || 'custom',
      sentTo: phoneNumber,
    });

  } catch (error) {
    console.error('[Send Link] Error:', error);
    return res.status(500).json({ 
      success: false, 
      error: error.message,
    });
  }
}

/**
 * Helper function for AI to call during conversation
 * Can be imported and used directly
 */
export async function sendLinkToPatient(phoneNumber, linkType, context = {}) {
  const baseUrl = getBaseUrl();
  
  const response = await fetch(`${baseUrl}/api/voice/send-link`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      phoneNumber,
      linkType,
      ...context,
    }),
  });

  return response.json();
}

/**
 * Get available link types (for AI context)
 */
export function getAvailableLinkTypes() {
  return Object.entries(LINK_TEMPLATES).map(([key, value]) => ({
    type: key,
    description: value.message,
  }));
}
