/**
 * Call Complete Handler
 * 
 * Called when a call ends - handles:
 * 1. SMS follow-up with call summary
 * 2. Recording storage to database
 * 3. Call log persistence
 */

import twilio from 'twilio';

const getBaseUrl = () => process.env.VITE_APP_URL || 'https://patientcare-teal.vercel.app';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const {
      CallSid,
      CallStatus,
      CallDuration,
      From,
      To,
      Direction,
      RecordingUrl,
      RecordingSid,
    } = req.body || {};

    console.log('[Call Complete] CallSid:', CallSid?.slice(-8), 'Status:', CallStatus, 'Duration:', CallDuration);

    // Only process completed calls
    if (CallStatus !== 'completed') {
      return res.status(200).json({ received: true, skipped: 'not completed' });
    }

    // Build call summary
    const callLog = {
      callSid: CallSid,
      from: From,
      to: To,
      direction: Direction,
      status: CallStatus,
      duration: parseInt(CallDuration) || 0,
      recordingUrl: RecordingUrl || null,
      recordingSid: RecordingSid || null,
      completedAt: new Date().toISOString(),
    };

    // 1. Send SMS follow-up (for calls over 30 seconds)
    if (callLog.duration > 30 && From) {
      try {
        await sendFollowUpSMS(From, callLog);
        callLog.smsFollowUpSent = true;
      } catch (err) {
        console.error('[Call Complete] SMS follow-up failed:', err.message);
        callLog.smsFollowUpSent = false;
      }
    }

    // 2. Store call log (using Vercel KV or fallback to API)
    try {
      await storeCallLog(callLog);
      console.log('[Call Complete] Call log stored:', CallSid);
    } catch (err) {
      console.error('[Call Complete] Storage failed:', err.message);
    }

    // 3. Trigger sentiment analysis (async - don't wait)
    if (callLog.duration > 10) {
      analyzeSentimentAsync(callLog).catch(err => {
        console.error('[Call Complete] Sentiment analysis failed:', err.message);
      });
    }

    return res.status(200).json({ 
      received: true, 
      callSid: CallSid,
      smsFollowUpSent: callLog.smsFollowUpSent || false,
    });

  } catch (error) {
    console.error('[Call Complete] Error:', error);
    return res.status(200).json({ received: true, error: error.message });
  }
}

/**
 * Send SMS follow-up after call
 */
async function sendFollowUpSMS(phoneNumber, callLog) {
  const client = twilio(
    process.env.TWILIO_ACCOUNT_SID,
    process.env.TWILIO_AUTH_TOKEN
  );

  const duration = Math.ceil(callLog.duration / 60);
  const message = `Thank you for calling Vision Care Center! ` +
    `Your call lasted ${duration} minute${duration > 1 ? 's' : ''}. ` +
    `If you scheduled an appointment, you'll receive a confirmation shortly. ` +
    `Questions? Call us at (555) 555-1234 or reply to this message.`;

  const result = await client.messages.create({
    body: message,
    to: phoneNumber,
    from: process.env.TWILIO_PHONE_NUMBER,
  });

  console.log('[Call Complete] SMS follow-up sent:', result.sid);
  return result;
}

/**
 * Store call log to database/KV
 */
async function storeCallLog(callLog) {
  const baseUrl = getBaseUrl();
  
  // Store via internal API (which can use KV, database, etc.)
  const response = await fetch(`${baseUrl}/api/data/call-logs`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(callLog),
  });

  if (!response.ok) {
    throw new Error(`Storage API returned ${response.status}`);
  }

  return response.json();
}

/**
 * Analyze call sentiment asynchronously
 * This fetches call context and runs AI analysis
 */
async function analyzeSentimentAsync(callLog) {
  const baseUrl = getBaseUrl();
  
  // For now, we'll use a placeholder transcript
  // In production, this would fetch the actual transcript from Twilio
  const transcript = `Call from ${callLog.from} to ${callLog.to}. Duration: ${callLog.duration} seconds. Direction: ${callLog.direction}.`;
  
  console.log('[Call Complete] Triggering sentiment analysis for:', callLog.callSid);
  
  const response = await fetch(`${baseUrl}/api/ai/analyze-sentiment`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      transcript,
      type: 'call',
      callSid: callLog.callSid,
      phone: callLog.from,
    }),
  });

  if (!response.ok) {
    throw new Error(`Sentiment API returned ${response.status}`);
  }

  const result = await response.json();
  
  // If escalation needed, create an escalation alert
  if (result.analysis?.escalationNeeded) {
    console.log('[Call Complete] ⚠️ Creating escalation for:', callLog.callSid);
    // Store escalation (would go to database in production)
  }

  return result;
}
