/**
 * Form Verification API
 * Verifies patient identity before form access
 * 
 * POST - Verify patient with DOB, phone, email, etc.
 */

import { getDb } from '../_lib/db.js';

// Initialize database client
const supabase = getDb();

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { token, verificationData } = req.body;

    if (!token) {
      return res.status(400).json({ error: 'Missing token' });
    }

    // Look up submission in database
    let submission = null;
    let supabaseRecord = null;

    try {
      const { data, error } = await supabase
        .from('form_submissions_cache')
        .select('*')
        .eq('access_token', token)
        .single();

      if (data && !error) {
        submission = data.submission_data;
        supabaseRecord = data;
        console.log('[Forms Verify] Found in database:', data.submission_id);
      }
    } catch (err) {
      console.log('[Forms Verify] Database lookup failed');
    }

    if (!submission) {
      console.log('[Forms Verify] Submission not found for token:', token?.substring(0, 8) + '...');
      return res.status(404).json({ 
        success: false,
        error: 'Form not found',
        message: 'Unable to find this form. Please use the link provided to you.',
      });
    }

    // Check if already verified
    if (submission.verification?.verified) {
      return res.status(200).json({
        success: true,
        message: 'Already verified',
        verified: true,
      });
    }

    // For now, accept any verification (can add actual DOB checking later)
    // In production, you'd verify against patient data from Eyefinity
    const isValid = verifyPatientData(submission, verificationData);

    if (isValid) {
      // Mark as verified
      submission.verification = {
        ...submission.verification,
        verified: true,
        verifiedAt: new Date().toISOString(),
      };
      
      // Update in database
      if (supabaseRecord) {
        try {
          await supabase
            .from('form_submissions_cache')
            .update({ submission_data: submission })
            .eq('access_token', token);
        } catch (err) { /* ignore */ }
      }

      console.log('[Forms Verify] Verification successful for:', submission.submissionId);
      
      return res.status(200).json({
        success: true,
        verified: true,
        message: 'Identity verified successfully',
      });
    } else {
      // Track failed attempts
      submission.verification = {
        ...submission.verification,
        attempts: (submission.verification?.attempts || 0) + 1,
      };
      
      const locked = submission.verification.attempts >= 5;
      
      // Update in database
      if (supabaseRecord) {
        try {
          await supabase
            .from('form_submissions_cache')
            .update({ submission_data: submission })
            .eq('access_token', token);
        } catch (err) { /* ignore */ }
      }

      console.log('[Forms Verify] Verification failed, attempts:', submission.verification.attempts);
      
      return res.status(200).json({
        success: false,
        verified: false,
        error: 'Verification failed. Please check your information and try again.',
        locked,
        attemptsRemaining: Math.max(0, 5 - submission.verification.attempts),
      });
    }

  } catch (error) {
    console.error('[Forms Verify] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}

/**
 * Verify patient data
 * For demo purposes, accepts any non-empty verification
 * In production, would check against actual patient records
 */
function verifyPatientData(submission, verificationData) {
  if (!verificationData) return false;
  
  const { dob, phone, email, lastName, zip } = verificationData;
  
  // Accept if any verification field is provided
  // In production: check against Eyefinity patient data
  if (dob) {
    // For demo: accept any valid date format
    return dob.length >= 8;
  }
  
  if (phone) {
    // Accept if phone has digits
    return phone.replace(/\D/g, '').length >= 10;
  }
  
  if (email) {
    // Accept if email looks valid
    return email.includes('@');
  }
  
  if (lastName && zip) {
    return lastName.length >= 2 && zip.length >= 5;
  }
  
  return false;
}
