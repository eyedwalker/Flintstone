/**
 * Form Submission API
 * Server-side storage for patient forms using Supabase
 * 
 * POST - Create new form submission
 * GET - Retrieve form by access token
 * PUT - Update form responses
 */

import { getDb } from '../_lib/db.js';

// Initialize database client
const supabase = getDb();

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    if (req.method === 'POST') {
      return await handleCreate(req, res);
    }
    
    if (req.method === 'GET') {
      return await handleGet(req, res);
    }
    
    if (req.method === 'PUT') {
      return await handleUpdate(req, res);
    }

    return res.status(405).json({ error: 'Method not allowed' });

  } catch (error) {
    console.error('[Forms API] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}

/**
 * Create a new form submission
 */
async function handleCreate(req, res) {
  const { 
    templateId, 
    template,
    patientId, 
    patientName,
    patientEmail,
    patientPhone,
    accessToken,
    expiresAt,
    verification,
    prefillData,
  } = req.body;

  if (!templateId || !accessToken) {
    return res.status(400).json({ error: 'Missing required fields: templateId, accessToken' });
  }

  const appUrl = process.env.VITE_APP_URL || 'https://prc.wubba.ai';
  const submission = {
    submissionId: `sub_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    templateId,
    formTitle: template?.title || templateId,
    template, // Store the full template
    patientId,
    patientName,
    patientEmail,
    patientPhone,
    accessToken,
    accessLink: `${appUrl}/forms/patient/${accessToken}`,
    status: 'sent',
    responses: prefillData || {},
    verification: verification || { required: false, verified: false },
    expiresAt: expiresAt || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days
    viewCount: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  // Store in database
  try {
    const { error } = await supabase
      .from('form_submissions_cache')
      .upsert({
        submission_id: submission.submissionId,
        access_token: submission.accessToken,
        submission_data: submission,
        created_at: new Date().toISOString(),
        expires_at: submission.expiresAt,
      }, { onConflict: 'access_token' });

    if (error) {
      console.error('[Forms API] Database store error:', error.message);
    } else {
      console.log('[Forms API] Stored in database');
    }
  } catch (err) {
    console.error('[Forms API] Database error:', err);
  }

  console.log('[Forms API] Created submission:', submission.submissionId, 'Token:', accessToken.substring(0, 8) + '...');

  return res.status(201).json({
    success: true,
    submission,
    accessLink: submission.accessLink,
  });
}

/**
 * Get form(s) — by access token, or list all submissions
 */
async function handleGet(req, res) {
  const { token } = req.query;

  // No token = list all submissions
  if (!token) {
    return await handleListAll(req, res);
  }

  // Look up in database
  let submission = null;
  try {
    const { data, error } = await supabase
      .from('form_submissions_cache')
      .select('*')
      .eq('access_token', token)
      .single();

    if (data && !error) {
      submission = data.submission_data;
      console.log('[Forms API] Found in database:', data.submission_id);
    }
  } catch (err) {
    console.log('[Forms API] Database lookup failed');
  }

  if (!submission) {
    console.log('[Forms API] Token not found:', token.substring(0, 8) + '...');
    return res.status(404).json({ 
      error: 'Form not found',
      message: 'This form link may be invalid or expired. Please contact your healthcare provider for a new link.',
    });
  }

  // Check expiration
  if (new Date(submission.expiresAt) < new Date()) {
    return res.status(410).json({
      error: 'Form expired',
      message: 'This form link has expired. Please contact your healthcare provider for a new link.',
    });
  }

  // Check if already completed — return full submission so staff can view responses
  if (submission.status === 'completed') {
    return res.status(200).json({
      success: true,
      completed: true,
      message: 'This form has already been submitted. Thank you!',
      submission,
      template: submission.template,
    });
  }

  // Increment view count
  submission.viewCount = (submission.viewCount || 0) + 1;
  submission.lastViewedAt = new Date().toISOString();
  if (submission.status === 'sent') {
    submission.status = 'viewed';
  }

  // Persist the updated status and view count back to database
  try {
    await supabase
      .from('form_submissions_cache')
      .update({ submission_data: submission })
      .eq('access_token', token);
  } catch (err) {
    console.error('[Forms API] Failed to persist view update:', err);
  }

  console.log('[Forms API] Form accessed:', submission.submissionId, 'Views:', submission.viewCount);

  return res.status(200).json({
    success: true,
    submission,
    template: submission.template,
  });
}

/**
 * Update form responses
 */
async function handleUpdate(req, res) {
  const { token } = req.query;
  const { responses, status, verification } = req.body;

  if (!token) {
    return res.status(400).json({ error: 'Missing token parameter' });
  }

  // Look up in database
  let submission = null;
  try {
    const { data } = await supabase
      .from('form_submissions_cache')
      .select('*')
      .eq('access_token', token)
      .single();
    if (data) submission = data.submission_data;
  } catch (err) { /* ignore */ }

  if (!submission) {
    return res.status(404).json({ error: 'Form not found' });
  }

  // Update responses
  if (responses) {
    submission.responses = { ...submission.responses, ...responses };
    submission.status = 'in_progress';
  }

  // Update verification
  if (verification) {
    submission.verification = { ...submission.verification, ...verification };
  }

  // Mark as completed
  if (status === 'completed') {
    submission.status = 'completed';
    submission.completedAt = new Date().toISOString();
  }

  submission.updatedAt = new Date().toISOString();
  
  // Update in database
  try {
    await supabase
      .from('form_submissions_cache')
      .update({ submission_data: submission })
      .eq('access_token', token);
  } catch (err) { /* ignore */ }

  console.log('[Forms API] Updated submission:', submission.submissionId, 'Status:', submission.status);

  return res.status(200).json({
    success: true,
    submission,
  });
}

/**
 * List all submissions from database
 */
async function handleListAll(req, res) {
  try {
    const { data, error } = await supabase
      .from('form_submissions_cache')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('[Forms API] List error:', error.message);
      return res.status(500).json({ error: 'Failed to fetch submissions' });
    }

    const submissions = (data || []).map(row => {
      const sub = row.submission_data;
      // Backfill formTitle from template for older records
      if (!sub.formTitle && sub.template?.title) {
        sub.formTitle = sub.template.title;
      }
      return sub;
    });
    return res.status(200).json({ success: true, submissions });
  } catch (err) {
    console.error('[Forms API] List error:', err);
    return res.status(500).json({ error: err.message });
  }
}

/**
 * Export for other handlers
 */
export async function getSubmissionByToken(token) {
  try {
    const { data } = await supabase
      .from('form_submissions_cache')
      .select('*')
      .eq('access_token', token)
      .single();
    return data?.submission_data || null;
  } catch {
    return null;
  }
}

export async function getAllSubmissions() {
  try {
    const { data } = await supabase
      .from('form_submissions_cache')
      .select('*')
      .order('created_at', { ascending: false });
    return (data || []).map(row => row.submission_data);
  } catch {
    return [];
  }
}
