/**
 * Appointment Sync API
 * POST /api/sync/appointments - Sync appointments from Eyefinity
 */

import { AppointmentSyncService } from '../../src/lib/services/appointment-sync-service';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { company_id, start_date, end_date, mode } = req.body;

    if (!company_id) {
      return res.status(400).json({ error: 'company_id is required' });
    }

    let result;

    if (mode === 'upcoming') {
      // Sync upcoming appointments (today + 90 days)
      result = await AppointmentSyncService.syncUpcoming(company_id);
    } else if (mode === 'recent') {
      // Sync recent appointments (past 30 days)
      result = await AppointmentSyncService.syncRecent(company_id);
    } else if (start_date && end_date) {
      // Custom date range sync
      result = await AppointmentSyncService.syncAppointments(company_id, start_date, end_date);
    } else {
      return res.status(400).json({ 
        error: 'Either mode (upcoming/recent) or start_date and end_date are required' 
      });
    }

    return res.status(200).json(result);
  } catch (error) {
    console.error('[Appointment Sync API] Error:', error);
    return res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
}
