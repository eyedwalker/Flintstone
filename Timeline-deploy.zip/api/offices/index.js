/**
 * Offices API
 * GET /api/offices - List offices
 */

import { getDb } from '../_lib/db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { company_id } = req.query;

    if (!company_id) {
      return res.status(400).json({ error: 'company_id is required' });
    }

    const db = getDb();
    const { data, error } = await db
      .from('offices')
      .select('*')
      .eq('company_id', company_id)
      .order('name', { ascending: true });

    if (error) {
      console.error('[Offices API] Supabase error:', error);
      return res.status(400).json({ error: error.message });
    }

    return res.status(200).json({ data: data || [] });
  } catch (error) {
    console.error('[Offices API] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
