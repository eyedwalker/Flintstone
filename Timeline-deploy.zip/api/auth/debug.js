import { kv } from '../_lib/kv.js';

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { email, key } = req.query;

    // If specific key requested
    if (key) {
      const data = await kv.get(key);
      return res.status(200).json({ key, data });
    }

    // If email requested, get user data
    if (email) {
      const user = await kv.hgetall(`user:${email.toLowerCase()}`);
      
      if (!user) {
        return res.status(404).json({ error: 'User not found', email });
      }

      // Redact sensitive fields
      const safeUser = {
        ...user,
        passwordHash: user.passwordHash ? '[REDACTED]' : null,
        mfaSecret: user.mfaSecret ? '[REDACTED]' : null,
      };

      return res.status(200).json({ 
        email, 
        user: safeUser,
        rawTypes: {
          mustChangePassword: typeof user.mustChangePassword,
          mfaEnabled: typeof user.mfaEnabled,
          failedLoginAttempts: typeof user.failedLoginAttempts,
        }
      });
    }

    // List all users, invites, and sessions
    const allUsers = await kv.smembers('users:all');
    const allInvites = await kv.smembers('invites:all');
    const sessionKeys = await kv.keys('session:*');
    const refreshKeys = await kv.keys('refresh:*');

    return res.status(200).json({
      users: allUsers || [],
      invites: allInvites || [],
      activeSessions: sessionKeys.length,
      activeRefreshTokens: refreshKeys.length,
      sessionKeyPreviews: sessionKeys.slice(0, 5).map(k => k.substring(0, 25) + '...'),
      message: 'Use ?email=xxx to get user details'
    });

  } catch (error) {
    console.error('[Debug] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
