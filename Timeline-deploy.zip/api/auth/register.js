import { kv } from '../_lib/kv.js';
import bcrypt from 'bcryptjs';

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { inviteToken, email, firstName, lastName, password, confirmPassword } = req.body;

    // Validate required fields
    if (!inviteToken || !email || !firstName || !lastName || !password) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Validate invite token
    const inviteData = await kv.get(`invite:${inviteToken}`);
    if (!inviteData) {
      return res.status(400).json({ error: 'Invalid or expired invite token' });
    }

    const invite = typeof inviteData === 'string' ? JSON.parse(inviteData) : inviteData;

    // Check invite status
    if (invite.status !== 'pending') {
      return res.status(400).json({ error: 'This invite has already been used' });
    }

    // Check invite expiry
    if (new Date(invite.expiresAt) < new Date()) {
      await kv.hset(`invite:${inviteToken}`, { status: 'expired' });
      return res.status(400).json({ error: 'This invite has expired' });
    }

    // Check email matches invite
    if (invite.email.toLowerCase() !== email.toLowerCase()) {
      return res.status(400).json({ error: 'Email does not match invitation' });
    }

    // Check if user already exists
    const existingUser = await kv.hgetall(`user:${email.toLowerCase()}`);
    if (existingUser) {
      return res.status(400).json({ error: 'An account with this email already exists' });
    }

    // Validate passwords match
    if (password !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match' });
    }

    // Validate password strength
    const passwordValidation = validatePassword(password);
    if (!passwordValidation.valid) {
      return res.status(400).json({ error: passwordValidation.errors.join('. ') });
    }

    // Hash password with bcrypt
    const saltRounds = 12;
    const passwordHash = await bcrypt.hash(password, saltRounds);

    // Create user
    const userId = generateToken(16);
    const user = {
      id: userId,
      email: email.toLowerCase(),
      firstName,
      lastName,
      role: invite.role,
      passwordHash,
      mfaEnabled: false,
      mfaSecret: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      failedLoginAttempts: 0,
      lockedUntil: null,
      mustChangePassword: false,
      lastLogin: null
    };

    // Save user to KV
    await kv.hset(`user:${email.toLowerCase()}`, user);
    
    // Add to users list for admin lookup
    await kv.sadd('users:all', email.toLowerCase());

    // Mark invite as used
    await kv.set(`invite:${inviteToken}`, JSON.stringify({
      ...invite,
      status: 'used',
      usedAt: new Date().toISOString(),
      usedBy: userId
    }));

    // Return success (without sensitive data)
    return res.status(201).json({
      success: true,
      user: {
        id: userId,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role
      }
    });

  } catch (error) {
    console.error('[Auth] Registration error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

function validatePassword(password) {
  const errors = [];
  
  if (password.length < 12) {
    errors.push('Password must be at least 12 characters');
  }
  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }
  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }
  if (!/\d/.test(password)) {
    errors.push('Password must contain at least one number');
  }
  if (!/[@$!%*?&]/.test(password)) {
    errors.push('Password must contain at least one special character (@$!%*?&)');
  }
  
  return { valid: errors.length === 0, errors };
}

function generateToken(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  const randomValues = new Uint8Array(length);
  crypto.getRandomValues(randomValues);
  for (let i = 0; i < length; i++) {
    result += chars[randomValues[i] % chars.length];
  }
  return result;
}
