import { kv } from '../_lib/kv.js';

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // GET - Validate session
  if (req.method === 'GET') {
    return validateSession(req, res);
  }

  // POST - Refresh session
  if (req.method === 'POST') {
    return refreshSession(req, res);
  }

  // DELETE - Logout
  if (req.method === 'DELETE') {
    return logout(req, res);
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

async function validateSession(req, res) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ valid: false, error: 'No token provided' });
    }

    const token = authHeader.substring(7);
    const sessionData = await kv.get(`session:${token}`);

    if (!sessionData) {
      return res.status(401).json({ valid: false, error: 'Invalid or expired session' });
    }

    const session = typeof sessionData === 'string' ? JSON.parse(sessionData) : sessionData;

    // Check expiry
    if (new Date(session.expiresAt) < new Date()) {
      await kv.del(`session:${token}`);
      return res.status(401).json({ valid: false, error: 'Session expired' });
    }

    // Get user data
    const user = await kv.hgetall(`user:${session.email}`);
    if (!user) {
      return res.status(401).json({ valid: false, error: 'User not found' });
    }

    // Note: Vercel KV stores booleans as strings, so we need to handle both
    return res.status(200).json({
      valid: true,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        mfaEnabled: user.mfaEnabled === true || user.mfaEnabled === 'true',
        mustChangePassword: user.mustChangePassword === true || user.mustChangePassword === 'true'
      },
      session: {
        id: session.id,
        expiresAt: session.expiresAt
      }
    });

  } catch (error) {
    console.error('[Auth] Session validation error:', error);
    return res.status(500).json({ valid: false, error: 'Internal server error' });
  }
}

async function refreshSession(req, res) {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({ error: 'Refresh token required' });
    }

    const refreshData = await kv.get(`refresh:${refreshToken}`);
    if (!refreshData) {
      return res.status(401).json({ error: 'Invalid or expired refresh token' });
    }

    const refresh = typeof refreshData === 'string' ? JSON.parse(refreshData) : refreshData;

    // Get user
    const user = await kv.hgetall(`user:${refresh.email}`);
    if (!user) {
      return res.status(401).json({ error: 'User not found' });
    }

    // Delete old refresh token
    await kv.del(`refresh:${refreshToken}`);

    // Create new session
    const newSessionId = generateToken(32);
    const newToken = generateToken(64);
    const newRefreshToken = generateToken(64);
    const expiresAt = new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString();

    const session = {
      id: newSessionId,
      userId: user.id,
      email: user.email,
      accountId: refresh.accountId || null,
      role: refresh.role || user.role,
      token: newToken,
      refreshToken: newRefreshToken,
      expiresAt,
      createdAt: new Date().toISOString()
    };

    // Store new session
    await kv.setex(`session:${newToken}`, 8 * 60 * 60, JSON.stringify(session));
    await kv.setex(`refresh:${newRefreshToken}`, 7 * 24 * 60 * 60, JSON.stringify({
      sessionId: newSessionId,
      userId: user.id,
      email: user.email,
      accountId: refresh.accountId || null,
      role: refresh.role || user.role
    }));

    return res.status(200).json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        mfaEnabled: user.mfaEnabled || false
      },
      session: {
        id: newSessionId,
        token: newToken,
        refreshToken: newRefreshToken,
        expiresAt
      }
    });

  } catch (error) {
    console.error('[Auth] Session refresh error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

async function logout(req, res) {
  try {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      await kv.del(`session:${token}`);
    }

    return res.status(200).json({ success: true });

  } catch (error) {
    console.error('[Auth] Logout error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

function generateToken(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  const randomValues = new Uint8Array(length);
  crypto.getRandomValues(randomValues);
  for (let i = 0; i < length; i++) {
    result += chars[randomValues[i] % chars.length];
  }
  return result;
}
