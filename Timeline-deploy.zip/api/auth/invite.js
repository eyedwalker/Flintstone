import { kv } from '../_lib/kv.js';

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // Validate admin session for protected routes
  if (req.method === 'POST' || req.method === 'DELETE') {
    const authResult = await validateAdminSession(req);
    if (!authResult.valid) {
      return res.status(401).json({ error: authResult.error || 'Unauthorized' });
    }
    req.user = authResult.user;
  }

  // GET - Validate invite token (public) or list invites (admin)
  if (req.method === 'GET') {
    const { token } = req.query;
    if (token) {
      return validateInvite(req, res, token);
    }
    // List invites requires auth
    const authResult = await validateAdminSession(req);
    if (!authResult.valid) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    return listInvites(req, res);
  }

  // POST - Create invite (admin only)
  if (req.method === 'POST') {
    return createInvite(req, res);
  }

  // DELETE - Revoke invite (admin only)
  if (req.method === 'DELETE') {
    return revokeInvite(req, res);
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

async function validateAdminSession(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return { valid: false, error: 'No token provided' };
  }

  const token = authHeader.substring(7);
  const sessionData = await kv.get(`session:${token}`);

  if (!sessionData) {
    return { valid: false, error: 'Invalid session' };
  }

  const session = typeof sessionData === 'string' ? JSON.parse(sessionData) : sessionData;
  const user = await kv.hgetall(`user:${session.email}`);

  if (!user) {
    return { valid: false, error: 'User not found' };
  }

  if (user.role !== 'admin') {
    return { valid: false, error: 'Admin access required' };
  }

  return { valid: true, user };
}

async function validateInvite(req, res, token) {
  try {
    const inviteData = await kv.get(`invite:${token}`);

    if (!inviteData) {
      return res.status(404).json({ valid: false, error: 'Invalid invite token' });
    }

    const invite = typeof inviteData === 'string' ? JSON.parse(inviteData) : inviteData;

    if (invite.status === 'used') {
      return res.status(400).json({ valid: false, error: 'This invite has already been used' });
    }

    if (invite.status === 'revoked') {
      return res.status(400).json({ valid: false, error: 'This invite has been revoked' });
    }

    if (new Date(invite.expiresAt) < new Date()) {
      return res.status(400).json({ valid: false, error: 'This invite has expired' });
    }

    return res.status(200).json({
      valid: true,
      invite: {
        email: invite.email,
        role: invite.role,
        invitedByName: invite.invitedByName,
        expiresAt: invite.expiresAt
      }
    });

  } catch (error) {
    console.error('[Auth] Invite validation error:', error);
    return res.status(500).json({ valid: false, error: 'Internal server error' });
  }
}

async function listInvites(req, res) {
  try {
    // Get all invite keys
    const inviteKeys = await kv.smembers('invites:all');
    const invites = [];

    for (const key of inviteKeys) {
      const inviteData = await kv.get(`invite:${key}`);
      if (inviteData) {
        const invite = typeof inviteData === 'string' ? JSON.parse(inviteData) : inviteData;
        invites.push({
          id: invite.id,
          token: key,
          email: invite.email,
          role: invite.role,
          status: invite.status,
          invitedBy: invite.invitedBy,
          invitedByName: invite.invitedByName,
          createdAt: invite.createdAt,
          expiresAt: invite.expiresAt,
          usedAt: invite.usedAt
        });
      }
    }

    // Sort by created date (newest first)
    invites.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    return res.status(200).json({ invites });

  } catch (error) {
    console.error('[Auth] List invites error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

async function createInvite(req, res) {
  try {
    const { email, role, expirationDays = 7 } = req.body;

    if (!email || !role) {
      return res.status(400).json({ error: 'Email and role are required' });
    }

    if (!['admin', 'manager', 'associate'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }

    // Check if user already exists
    const existingUser = await kv.hgetall(`user:${email.toLowerCase()}`);
    if (existingUser) {
      return res.status(400).json({ error: 'A user with this email already exists' });
    }

    // Generate invite token
    const token = generateToken(48);
    const inviteId = generateToken(16);
    const expiresAt = new Date(Date.now() + expirationDays * 24 * 60 * 60 * 1000).toISOString();

    const invite = {
      id: inviteId,
      email: email.toLowerCase(),
      role,
      status: 'pending',
      invitedBy: req.user.id,
      invitedByName: `${req.user.firstName} ${req.user.lastName}`,
      createdAt: new Date().toISOString(),
      expiresAt
    };

    // Store invite
    await kv.set(`invite:${token}`, JSON.stringify(invite));
    await kv.sadd('invites:all', token);

    // Generate invite URL - always use production domain for consistency
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://patientcare-teal.vercel.app';
    const inviteUrl = `${baseUrl}/register?invite=${token}`;

    return res.status(201).json({
      success: true,
      invite: {
        id: inviteId,
        token,
        email: invite.email,
        role: invite.role,
        expiresAt: invite.expiresAt,
        inviteUrl
      }
    });

  } catch (error) {
    console.error('[Auth] Create invite error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

async function revokeInvite(req, res) {
  try {
    const { token } = req.query;

    if (!token) {
      return res.status(400).json({ error: 'Invite token required' });
    }

    const inviteData = await kv.get(`invite:${token}`);
    if (!inviteData) {
      return res.status(404).json({ error: 'Invite not found' });
    }

    const invite = typeof inviteData === 'string' ? JSON.parse(inviteData) : inviteData;

    if (invite.status !== 'pending') {
      return res.status(400).json({ error: 'Only pending invites can be revoked' });
    }

    // Update invite status
    await kv.set(`invite:${token}`, JSON.stringify({
      ...invite,
      status: 'revoked',
      revokedAt: new Date().toISOString()
    }));

    return res.status(200).json({ success: true });

  } catch (error) {
    console.error('[Auth] Revoke invite error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

function generateToken(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  const randomValues = new Uint8Array(length);
  crypto.getRandomValues(randomValues);
  for (let i = 0; i < length; i++) {
    result += chars[randomValues[i] % chars.length];
  }
  return result;
}
