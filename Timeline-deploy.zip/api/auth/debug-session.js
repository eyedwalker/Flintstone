import { kv } from '../_lib/kv.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(200).json({ 
        hasAuth: false, 
        error: 'No authorization header',
        receivedHeader: authHeader || 'none'
      });
    }

    const token = authHeader.substring(7);
    const sessionData = await kv.get(`session:${token}`);

    if (!sessionData) {
      // Check if any session keys exist
      const keys = await kv.keys('session:*');
      return res.status(200).json({
        hasAuth: true,
        tokenPreview: `${token.substring(0, 10)}...`,
        sessionFound: false,
        totalSessionKeys: keys.length,
        existingKeyPreviews: keys.slice(0, 5).map(k => k.substring(0, 20) + '...')
      });
    }

    const session = typeof sessionData === 'string' ? JSON.parse(sessionData) : sessionData;

    return res.status(200).json({
      hasAuth: true,
      tokenPreview: `${token.substring(0, 10)}...`,
      sessionFound: true,
      session: {
        id: session.id,
        email: session.email,
        expiresAt: session.expiresAt,
        createdAt: session.createdAt,
        isExpired: new Date(session.expiresAt) < new Date()
      }
    });

  } catch (error) {
    console.error('[Debug Session] Error:', error);
    return res.status(500).json({ error: error.message });
  }
}
