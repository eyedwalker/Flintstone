import { kv } from '../_lib/kv.js';
import { getDb } from '../_lib/db.js';
import bcrypt from 'bcryptjs';

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { email, password, mfaCode, mfaToken } = req.body;

    // If MFA token provided, verify MFA
    if (mfaToken && mfaCode) {
      return await verifyMfa(res, mfaToken, mfaCode);
    }

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    // Get user by email
    const user = await kv.hgetall(`user:${email.toLowerCase()}`);
    
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // Check if account is locked
    if (user.lockedUntil) {
      const lockExpiry = new Date(user.lockedUntil);
      if (lockExpiry > new Date()) {
        const minutesLeft = Math.ceil((lockExpiry.getTime() - Date.now()) / 60000);
        return res.status(423).json({ 
          error: `Account is locked. Try again in ${minutesLeft} minute(s)` 
        });
      }
    }

    // Verify password
    const passwordValid = await bcrypt.compare(password, user.passwordHash);

    if (!passwordValid) {
      // Increment failed attempts
      const failedAttempts = (user.failedLoginAttempts || 0) + 1;
      
      if (failedAttempts >= 5) {
        const lockUntil = new Date(Date.now() + 15 * 60000).toISOString();
        await kv.hset(`user:${email.toLowerCase()}`, {
          failedLoginAttempts: failedAttempts,
          lockedUntil: lockUntil
        });
        return res.status(423).json({ 
          error: 'Too many failed attempts. Account locked for 15 minutes' 
        });
      }

      await kv.hset(`user:${email.toLowerCase()}`, {
        failedLoginAttempts: failedAttempts
      });

      const attemptsLeft = 5 - failedAttempts;
      return res.status(401).json({ 
        error: `Invalid email or password. ${attemptsLeft} attempt(s) remaining` 
      });
    }

    // Password correct - reset failed attempts
    await kv.hset(`user:${email.toLowerCase()}`, {
      failedLoginAttempts: 0,
      lockedUntil: null
    });

    // Check if MFA is enabled (handle string/boolean from KV)
    const mfaEnabled = user.mfaEnabled === true || user.mfaEnabled === 'true';
    if (mfaEnabled && user.mfaSecret) {
      // Generate MFA pending token
      const mfaPendingToken = generateToken(32);
      await kv.setex(`mfa:${mfaPendingToken}`, 300, JSON.stringify({
        userId: user.id,
        email: user.email,
        createdAt: new Date().toISOString()
      }));

      return res.status(200).json({
        success: true,
        requiresMfa: true,
        mfaToken: mfaPendingToken
      });
    }

    // No MFA - create session
    return await createSession(res, user);

  } catch (error) {
    console.error('[Auth] Login error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

async function verifyMfa(res, mfaToken, code) {
  try {
    const pendingData = await kv.get(`mfa:${mfaToken}`);
    
    if (!pendingData) {
      return res.status(401).json({ error: 'Invalid or expired MFA session' });
    }

    const pending = typeof pendingData === 'string' ? JSON.parse(pendingData) : pendingData;
    const user = await kv.hgetall(`user:${pending.email}`);

    if (!user || !user.mfaSecret) {
      return res.status(401).json({ error: 'User not found' });
    }

    // Verify TOTP code (simplified - in production use a proper TOTP library)
    const isValid = verifyTOTP(user.mfaSecret, code);
    
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid verification code' });
    }

    // Delete pending MFA
    await kv.del(`mfa:${mfaToken}`);

    // Create session
    return await createSession(res, user);

  } catch (error) {
    console.error('[Auth] MFA verification error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

async function createSession(res, user) {
  const sessionId = generateToken(32);
  const token = generateToken(64);
  const refreshToken = generateToken(64);
  const expiresAt = new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString(); // 8 hours

  // Look up account_id from PostgreSQL
  let accountId = null;
  try {
    const db = getDb();
    // Try users table first (has account_id directly)
    const { data: pgUser } = await db.from('users').select('id, account_id').eq('email', user.email.toLowerCase()).maybeSingle();
    if (pgUser?.account_id) {
      accountId = pgUser.account_id;
    } else {
      // Fallback: get the first account from DB (single-tenant bootstrap)
      const { data: firstAccount } = await db.from('accounts').select('id').limit(1).single();
      if (firstAccount?.id) {
        accountId = firstAccount.id;
      }
    }
  } catch (e) {
    console.warn('[Auth] Could not look up account_id from PG:', e.message);
  }

  const session = {
    id: sessionId,
    userId: user.id,
    email: user.email,
    accountId,
    role: user.role,
    token,
    refreshToken,
    expiresAt,
    createdAt: new Date().toISOString()
  };

  // Store session (expires in 8 hours)
  await kv.setex(`session:${token}`, 8 * 60 * 60, JSON.stringify(session));
  await kv.setex(`refresh:${refreshToken}`, 7 * 24 * 60 * 60, JSON.stringify({ sessionId, userId: user.id, email: user.email, accountId, role: user.role }));

  // Update last login
  await kv.hset(`user:${user.email}`, {
    lastLogin: new Date().toISOString()
  });

  // Return user data without sensitive fields
  // Note: Vercel KV stores booleans as strings, so we need to handle both
  const safeUser = {
    id: user.id,
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName,
    role: user.role,
    mfaEnabled: user.mfaEnabled === true || user.mfaEnabled === 'true',
    mustChangePassword: user.mustChangePassword === true || user.mustChangePassword === 'true'
  };

  return res.status(200).json({
    success: true,
    user: safeUser,
    session: {
      id: sessionId,
      token,
      refreshToken,
      expiresAt
    }
  });
}

function generateToken(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  const randomValues = new Uint8Array(length);
  crypto.getRandomValues(randomValues);
  for (let i = 0; i < length; i++) {
    result += chars[randomValues[i] % chars.length];
  }
  return result;
}

// Simplified TOTP verification (checks current and adjacent time windows)
function verifyTOTP(secret, code) {
  // For proper TOTP, use a library like 'otpauth' or 'speakeasy'
  // This is a simplified check
  const time = Math.floor(Date.now() / 1000 / 30);
  
  for (let i = -1; i <= 1; i++) {
    const expected = generateSimpleTOTP(secret, time + i);
    if (expected === code) return true;
  }
  return false;
}

function generateSimpleTOTP(secret, counter) {
  // Simplified TOTP - in production use proper HMAC-SHA1
  let hash = 0;
  const counterStr = counter.toString();
  for (let i = 0; i < secret.length; i++) {
    hash = ((hash << 5) - hash + secret.charCodeAt(i)) | 0;
  }
  for (let i = 0; i < counterStr.length; i++) {
    hash = ((hash << 5) - hash + counterStr.charCodeAt(i)) | 0;
  }
  return Math.abs(hash % 1000000).toString().padStart(6, '0');
}
