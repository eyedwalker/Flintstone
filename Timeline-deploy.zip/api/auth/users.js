import { kv } from '../_lib/kv.js';
import bcrypt from 'bcryptjs';

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // All routes require admin auth
  const authResult = await validateAdminSession(req);
  if (!authResult.valid) {
    return res.status(401).json({ error: authResult.error || 'Unauthorized' });
  }
  req.user = authResult.user;

  // GET - List all users
  if (req.method === 'GET') {
    return listUsers(req, res);
  }

  // PUT - Update user (role, reset password)
  if (req.method === 'PUT') {
    return updateUser(req, res);
  }

  // DELETE - Delete user
  if (req.method === 'DELETE') {
    return deleteUser(req, res);
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

async function validateAdminSession(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return { valid: false, error: 'No token provided' };
  }

  const token = authHeader.substring(7);
  const sessionData = await kv.get(`session:${token}`);

  if (!sessionData) {
    return { valid: false, error: 'Invalid session' };
  }

  const session = typeof sessionData === 'string' ? JSON.parse(sessionData) : sessionData;
  const user = await kv.hgetall(`user:${session.email}`);

  if (!user) {
    return { valid: false, error: 'User not found' };
  }

  if (user.role !== 'admin') {
    return { valid: false, error: 'Admin access required' };
  }

  return { valid: true, user };
}

async function listUsers(req, res) {
  try {
    const userEmails = await kv.smembers('users:all');
    const users = [];

    for (const email of userEmails) {
      const user = await kv.hgetall(`user:${email}`);
      if (user) {
        users.push({
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
          mfaEnabled: user.mfaEnabled || false,
          createdAt: user.createdAt,
          lastLogin: user.lastLogin
        });
      }
    }

    // Sort by created date (newest first)
    users.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    return res.status(200).json({ users });

  } catch (error) {
    console.error('[Auth] List users error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

async function updateUser(req, res) {
  try {
    const { email } = req.query;
    const { role, resetPassword } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email required' });
    }

    const user = await kv.hgetall(`user:${email.toLowerCase()}`);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const updates = {
      updatedAt: new Date().toISOString()
    };

    // Update role
    if (role && ['admin', 'manager', 'associate'].includes(role)) {
      updates.role = role;
    }

    // Reset password (generates temporary password)
    if (resetPassword) {
      const tempPassword = generateTempPassword();
      const saltRounds = 12;
      const passwordHash = await bcrypt.hash(tempPassword, saltRounds);
      
      updates.passwordHash = passwordHash;
      updates.mustChangePassword = true;

      await kv.hset(`user:${email.toLowerCase()}`, updates);

      return res.status(200).json({ 
        success: true, 
        temporaryPassword: tempPassword,
        message: 'Password reset. User must change password on next login.'
      });
    }

    await kv.hset(`user:${email.toLowerCase()}`, updates);

    return res.status(200).json({ success: true });

  } catch (error) {
    console.error('[Auth] Update user error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

async function deleteUser(req, res) {
  try {
    const { email } = req.query;

    if (!email) {
      return res.status(400).json({ error: 'Email required' });
    }

    // Prevent self-deletion
    if (email.toLowerCase() === req.user.email.toLowerCase()) {
      return res.status(400).json({ error: 'Cannot delete your own account' });
    }

    const user = await kv.hgetall(`user:${email.toLowerCase()}`);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Delete user
    await kv.del(`user:${email.toLowerCase()}`);
    await kv.srem('users:all', email.toLowerCase());

    return res.status(200).json({ success: true });

  } catch (error) {
    console.error('[Auth] Delete user error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

function generateTempPassword() {
  const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const lower = 'abcdefghijklmnopqrstuvwxyz';
  const numbers = '0123456789';
  const special = '@$!%*?&';
  
  let password = '';
  password += upper[Math.floor(Math.random() * upper.length)];
  password += lower[Math.floor(Math.random() * lower.length)];
  password += numbers[Math.floor(Math.random() * numbers.length)];
  password += special[Math.floor(Math.random() * special.length)];
  
  const all = upper + lower + numbers + special;
  for (let i = 0; i < 8; i++) {
    password += all[Math.floor(Math.random() * all.length)];
  }
  
  // Shuffle
  return password.split('').sort(() => Math.random() - 0.5).join('');
}
