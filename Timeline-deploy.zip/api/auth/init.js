import { kv } from '../_lib/kv.js';
import bcrypt from 'bcryptjs';

/**
 * Initialize the auth system with a default admin user
 * This should be called once during initial setup
 * 
 * GET /api/auth/init - Check if initialized
 * POST /api/auth/init - Initialize with default admin (only works if no users exist)
 */
export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // GET - Check initialization status
  if (req.method === 'GET') {
    return checkInitStatus(req, res);
  }

  // POST - Initialize default admin
  if (req.method === 'POST') {
    return initializeAdmin(req, res);
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

async function checkInitStatus(req, res) {
  try {
    const userEmails = await kv.smembers('users:all');
    const initialized = userEmails && userEmails.length > 0;

    return res.status(200).json({
      initialized,
      userCount: userEmails?.length || 0
    });

  } catch (error) {
    console.error('[Auth] Init check error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

async function initializeAdmin(req, res) {
  try {
    // Check if already initialized
    const userEmails = await kv.smembers('users:all');
    if (userEmails && userEmails.length > 0) {
      return res.status(400).json({ 
        error: 'System already initialized',
        message: 'Users already exist. Cannot reinitialize.'
      });
    }

    // Create default admin
    const email = 'admin@visioncare.local';
    const defaultPassword = 'Admin@123456';
    
    const saltRounds = 12;
    const passwordHash = await bcrypt.hash(defaultPassword, saltRounds);

    const userId = generateToken(16);
    const admin = {
      id: userId,
      email: email,
      firstName: 'System',
      lastName: 'Administrator',
      role: 'admin',
      passwordHash,
      mfaEnabled: false,
      mfaSecret: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      failedLoginAttempts: 0,
      lockedUntil: null,
      mustChangePassword: true, // Force password change on first login
      lastLogin: null
    };

    // Save admin user
    await kv.hset(`user:${email}`, admin);
    await kv.sadd('users:all', email);

    console.log('[Auth] Default admin created:', email);

    return res.status(201).json({
      success: true,
      message: 'Default admin created',
      credentials: {
        email: email,
        password: defaultPassword,
        note: 'You will be required to change the password on first login'
      }
    });

  } catch (error) {
    console.error('[Auth] Init error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

function generateToken(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  const randomValues = new Uint8Array(length);
  crypto.getRandomValues(randomValues);
  for (let i = 0; i < length; i++) {
    result += chars[randomValues[i] % chars.length];
  }
  return result;
}
