# Frame Scanner - Deployment Guide

## What's Been Built

### ✅ Phase 1 Complete (UPC Scanner & Favorites)

**Database:**
- Migration SQL with 4 new tables
- Sample frame catalog data
- Indexes for performance

**Backend:**
- 3 TypeScript accessors (data layer)
- FrameScannerService (business logic)
- 2 API endpoints (scan, favorites)
- JWT token system for patient access

**Frontend:**
- Full UPC scanner page with Quagga.js
- Favorites list with delete
- Mobile-optimized UI
- Camera access handling

**Missing for MVP:**
- Route configuration
- npm package installation
- Database migration execution
- Environment variable setup

---

## Installation Steps

### 1. Install Dependencies

```bash
cd /Users/daviwa2@vsp.com/CascadeProjects/Timeline

npm install quagga @mediapipe/face_mesh jsonwebtoken
npm install --save-dev @types/jsonwebtoken
```

### 2. Add Environment Variable

Add to `.env`:
```
PATIENT_TOKEN_SECRET=your-random-secret-key-min-32-chars-change-this-in-production
```

Generate a secure secret:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### 3. Run Database Migration

```bash
# Connect to your Supabase database and run:
psql $DATABASE_URL -f src/lib/db/migration-frame-scanner.sql
```

Or in Supabase dashboard:
1. Go to SQL Editor
2. Copy contents of `migration-frame-scanner.sql`
3. Run the migration

### 4. Add Route to App

In `src/App.jsx` or your routing file, add:

```jsx
import FrameScanner from './pages/patient/FrameScanner';

// Add to routes:
<Route path="/patient/frame-scanner" element={<FrameScanner />} />
```

### 5. Add "Send Link" Button (Optional but recommended)

In `PatientReadinessCenter.jsx`, add button to patient details:

```jsx
import { FrameScannerService } from '../lib/services/frame-scanner-service';

const sendFrameScannerLink = async (patient) => {
  try {
    const token = FrameScannerService.generatePatientToken(
      patient.id,
      activeCompany.id
    );
    
    const link = `${window.location.origin}/patient/frame-scanner?token=${token}`;
    
    // Send via SMS
    await CommunicationService.sendSMS(
      patient.phone,
      `Hi ${patient.firstName}! Try our Frame Finder to scan frames you like: ${link}`
    );
    
    alert('Frame scanner link sent!');
  } catch (error) {
    alert('Failed to send link: ' + error.message);
  }
};

// Add button in patient details section:
<button
  onClick={() => sendFrameScannerLink(selectedAppointment)}
  className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700"
>
  Send Frame Scanner Link
</button>
```

---

## Testing the Feature

### 1. Generate a Test Token

In browser console or create a test endpoint:
```javascript
// Temporary test - remove after testing
fetch('/api/test-token', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    patientId: 'your-patient-uuid',
    companyId: 'your-company-uuid'
  })
}).then(r => r.json()).then(console.log);
```

### 2. Test Scanner

1. Navigate to: `http://localhost:5173/patient/frame-scanner?token=YOUR_TOKEN`
2. Grant camera permission
3. Click "Start Scanning"
4. Point camera at a barcode (any UPC barcode will work)
5. Verify frame is saved to favorites

### 3. Test with Real Frame

Use one of these test UPC codes:
- `123456789012` - Ray-Ban Wayfarer (in sample data)
- `123456789013` - Oakley Holbrook (in sample data)
- `123456789014` - Warby Parker Haskell (in sample data)

---

## Mobile Testing

**iOS Safari:**
- Requires HTTPS (use ngrok or deploy to Vercel)
- User must grant camera permission
- Test on real device, not simulator

**Android Chrome:**
- Works on localhost
- Grant camera permission when prompted
- Test on real device for best results

**Ngrok for local HTTPS:**
```bash
ngrok http 5173
# Use the https://xxx.ngrok.io URL for mobile testing
```

---

## What's NOT Built Yet (Future Phases)

### Phase 2 - Measurements
- MediaPipe face detection
- PD calculation
- Credit card calibration
- Measurement storage

### Phase 3 - Frame-On Measurements
- Seg height calculation
- OC height calculation
- Frame marker UI

### Phase 4 - LiDAR
- WebXR integration
- iPhone LiDAR support
- 3D face mesh

---

## File Locations

**Database:**
- `src/lib/db/migration-frame-scanner.sql`

**Accessors:**
- `src/lib/accessors/FrameCatalogAccessor.ts`
- `src/lib/accessors/PatientFavoriteFramesAccessor.ts`
- `src/lib/accessors/PatientMeasurementsAccessor.ts`

**Services:**
- `src/lib/services/frame-scanner-service.ts`

**API Endpoints:**
- `api/patient/frame-scan.js`
- `api/patient/favorites.js`

**Frontend:**
- `src/pages/patient/FrameScanner.jsx`

**Documentation:**
- `FRAME_SCANNER_PLAN.md` - Full technical plan
- `FRAME_SCANNER_IMPLEMENTATION_STATUS.md` - Progress tracker
- `FRAME_SCANNER_DEPLOYMENT.md` - This file

---

## Troubleshooting

### Camera Not Working
- Verify HTTPS (required for camera access)
- Check browser permissions
- Try different browser
- Verify camera not in use by another app

### Barcode Not Scanning
- Ensure good lighting
- Hold camera steady
- Frame barcode in center
- Try closer/farther distance
- Use higher quality camera

### Database Errors
- Verify migration ran successfully
- Check Supabase connection
- Verify patient_id and company_id exist
- Check CORS headers in vercel.json

### Token Errors
- Verify PATIENT_TOKEN_SECRET is set
- Check token hasn't expired (7 days default)
- Verify token format in URL
- Check token generation logic

---

## Security Checklist

- [ ] Change PATIENT_TOKEN_SECRET in production
- [ ] Set token expiration appropriately
- [ ] Verify CORS headers restrict origins in production
- [ ] Enable HTTPS for production
- [ ] Test token validation
- [ ] Verify company isolation
- [ ] Add rate limiting to API endpoints (optional)

---

## Performance Optimization

### For Production:
1. Add Redis caching for frame catalog lookups
2. Optimize Quagga.js settings for faster scanning
3. Add image compression before storage
4. Implement lazy loading for favorites list
5. Add pagination for large favorites lists

---

## Next Steps After MVP

1. **Test with real users** - Get feedback on UX
2. **Add measurement tool** - Phase 2 implementation
3. **Staff review UI** - Allow staff to review/approve frames
4. **Frame recommendations** - AI-based suggestions
5. **Virtual try-on** - AR overlay (Phase 4)

---

## Support

For issues or questions:
1. Check `FRAME_SCANNER_PLAN.md` for technical details
2. Review `FRAME_SCANNER_IMPLEMENTATION_STATUS.md` for what's complete
3. Test with sample UPC codes first
4. Verify all dependencies installed
5. Check browser console for errors
