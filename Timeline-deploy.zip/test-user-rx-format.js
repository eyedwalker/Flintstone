#!/usr/bin/env node

/**
 * Test user's specific RX format: /patients/{patientid}/rx?page=1&pageSize=22
 * Test with Legacy ID 1166950 and GUID 34f9334e-2dcd-4190-9190-e87709fad676
 */

console.log('🎯 TESTING USER\'S SPECIFIC RX FORMAT');
console.log('════════════════════════════════════════════════════════════════════════');
console.log('Format: /patients/{patientid}/rx?page=1&pageSize=22');

const testIds = [
  { id: '1166950', type: 'Legacy ID' },
  { id: '34f9334e-2dcd-4190-9190-e87709fad676', type: 'GUID' }
];

const formatValue = (value) => {
  if (value === null || value === undefined) return '⚪ null';
  if (value === '') return '⚪ empty';
  return value;
};

const displayRxData = (rxItems, patientId, idType) => {
  console.log(`\n💊 RX DATA FOR ${idType} ${patientId}:`);
  console.log('═'.repeat(80));
  
  if (rxItems.length > 0) {
    console.log(`   📊 Found ${rxItems.length} prescriptions`);
    
    rxItems.forEach((rx, i) => {
      console.log(`\n📋 Prescription ${i + 1}:`);
      console.log('─'.repeat(60));
      console.log(`   RX Number................: ${formatValue(rx.RxNumber)}`);
      console.log(`   Date Prescribed..........: ${formatValue(rx.DatePrescribed)}`);
      console.log(`   Product Type.............: ${formatValue(rx.Product)}`);
      console.log(`   Status...................: ${formatValue(rx.Status)}`);
      console.log(`   Provider.................: ${formatValue(rx.ProviderName)}`);
      
      // Prescription details
      console.log(`   OD Sphere................: ${formatValue(rx.OdSphere)}`);
      console.log(`   OD Cylinder..............: ${formatValue(rx.OdCylinder)}`);
      console.log(`   OD Axis..................: ${formatValue(rx.OdAxis)}`);
      console.log(`   OS Sphere................: ${formatValue(rx.OsSphere)}`);
      console.log(`   OS Cylinder..............: ${formatValue(rx.OsCylinder)}`);
      console.log(`   OS Axis..................: ${formatValue(rx.OsAxis)}`);
      console.log(`   Add Power................: ${formatValue(rx.AddPower)}`);
      console.log(`   PD.......................: ${formatValue(rx.PupillaryDistance || rx.PD)}`);
      console.log(`   Expiration Date..........: ${formatValue(rx.ExpirationDate)}`);
      console.log(`   Notes....................: ${formatValue(rx.Notes)}`);
    });
    
    // Show prescription summary
    console.log(`\n📊 PRESCRIPTION SUMMARY:`);
    console.log('─'.repeat(40));
    
    const statuses = rxItems.reduce((acc, rx) => {
      const status = rx.Status || 'Unknown';
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {});
    
    console.log(`   Total Prescriptions: ${rxItems.length}`);
    console.log(`   Status Distribution:`);
    Object.entries(statuses).forEach(([status, count]) => {
      console.log(`     - ${status}: ${count}`);
    });
    
    const providers = [...new Set(rxItems.map(rx => rx.ProviderName).filter(Boolean))];
    if (providers.length > 0) {
      console.log(`   Providers: ${providers.join(', ')}`);
    }
    
    const dates = rxItems.map(rx => rx.DatePrescribed).filter(Boolean).sort();
    if (dates.length > 0) {
      console.log(`   Date Range: ${dates[0]} to ${dates[dates.length - 1]}`);
    }
    
    return true;
  } else {
    console.log('   📭 No prescriptions found for this patient');
    return false;
  }
};

const testRxFormat = async (patientId, idType) => {
  try {
    console.log(`\n🧪 Testing ${idType}: ${patientId}`);
    console.log('─'.repeat(80));
    
    const endpoint = `/api/eyefinity/patients/${patientId}/rx`;
    const url = `https://patientcare-teal.vercel.app${endpoint}?page=1&pageSize=22`;
    
    console.log(`   Endpoint: ${endpoint}`);
    console.log(`   Full URL: ${url}`);
    
    const startTime = Date.now();
    const response = await fetch(url);
    const duration = Date.now() - startTime;
    
    console.log(`   Status: ${response.status} ${response.statusText} (${duration}ms)`);
    
    if (response.ok) {
      const data = await response.json();
      const rxItems = data.items || data || [];
      
      console.log(`   🎉 SUCCESS! User's RX format works!`);
      
      const hasData = displayRxData(rxItems, patientId, idType);
      
      return {
        success: true,
        patientId,
        idType,
        endpoint,
        rxCount: rxItems.length,
        hasData,
        data,
        duration
      };
      
    } else if (response.status === 400) {
      const text = await response.text();
      console.log(`   ⚠️  Bad Request: ${text.substring(0, 200)}`);
      return { success: false, patientId, idType, status: 400, error: text, duration };
      
    } else if (response.status === 404) {
      console.log(`   ❌ Not Found: Endpoint doesn't exist or patient not found`);
      return { success: false, patientId, idType, status: 404, duration };
      
    } else {
      const text = await response.text();
      console.log(`   ❌ Failed: ${response.status} - ${text.substring(0, 100)}`);
      return { success: false, patientId, idType, status: response.status, error: text, duration };
    }
    
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
    return { success: false, patientId, idType, error: error.message };
  }
};

const runUserFormatTests = async () => {
  console.log('\n🚀 Testing User\'s Specific RX Format with Both IDs');
  console.log('═'.repeat(80));
  
  const results = [];
  
  for (let i = 0; i < testIds.length; i++) {
    const { id, type } = testIds[i];
    const result = await testRxFormat(id, type);
    results.push(result);
    
    if (i < testIds.length - 1) {
      console.log('\n' + '═'.repeat(100));
    }
  }
  
  console.log('\n\n🎯 FINAL RESULTS:');
  console.log('═'.repeat(80));
  
  const successful = results.filter(r => r.success);
  const withData = results.filter(r => r.success && r.hasData);
  
  console.log(`\n📊 TEST SUMMARY:`);
  console.log(`   Total Tests: ${results.length}`);
  console.log(`   ✅ Successful (200): ${successful.length}`);
  console.log(`   📦 With RX Data: ${withData.length}`);
  
  if (withData.length > 0) {
    console.log(`\n🎉 BREAKTHROUGH! FOUND WORKING RX API!`);
    console.log('═'.repeat(50));
    
    withData.forEach(r => {
      console.log(`   🏆 ${r.idType} ${r.patientId}: ${r.rxCount} prescriptions`);
      console.log(`   ✅ Endpoint: ${r.endpoint}`);
    });
    
    const workingResult = withData[0];
    console.log(`\n💡 SOLUTION FOR EYEFINITY SERVICE:`);
    console.log(`   ✅ Format: /api/eyefinity/patients/{patientId}/rx`);
    console.log(`   ✅ ID Type: ${workingResult.idType}`);
    console.log(`   ✅ Parameters: ?page=1&pageSize=22`);
    console.log(`   ✅ This format successfully returns RX data!`);
    
    console.log(`\n🔧 NEXT STEPS:`);
    console.log(`   1. Update getPatientRx() in EyefinityService`);
    console.log(`   2. Use ${workingResult.idType} for patient identification`);
    console.log(`   3. Test in Patient Readiness Center`);
    console.log(`   4. Both Orders and RX APIs will be working!`);
    
  } else if (successful.length > 0) {
    console.log(`\n✅ RX FORMAT WORKS (but no data for these patients):`);
    successful.forEach(r => {
      console.log(`   ✅ ${r.idType} ${r.patientId}: endpoint works`);
    });
    
    console.log(`\n💡 RX API CONFIRMED:`);
    console.log(`   Format: /api/eyefinity/patients/{patientId}/rx`);
    console.log(`   Status: Working (200) but patients have no RX data`);
    
  } else {
    console.log(`\n❌ USER'S FORMAT STILL NOT WORKING:`);
    results.forEach(r => {
      console.log(`   ❌ ${r.idType} ${r.patientId}: ${r.status || 'Error'}`);
    });
    
    console.log(`\n🔍 ANALYSIS:`);
    console.log(`   - User's format /patients/{id}/rx also returns errors`);
    console.log(`   - May need different patient IDs with actual RX data`);
    console.log(`   - Or RX data not available in current API environment`);
  }
  
  console.log(`\n📋 OVERALL PROGRESS:`);
  console.log('─'.repeat(40));
  console.log('✅ Orders API: WORKING (/v2orders)');
  console.log('✅ Patient Details: WORKING (/v2patients)');
  if (withData.length > 0) {
    console.log('✅ RX API: WORKING (/patients/{id}/rx)');
    console.log('🎊 ALL THREE APIs WORKING!');
  } else {
    console.log('❌ RX API: Still investigating...');
  }
};

runUserFormatTests().catch(console.error);
