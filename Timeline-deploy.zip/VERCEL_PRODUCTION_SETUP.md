# Vercel Production Setup Guide

## Overview
This guide covers deploying the Timeline app to Vercel with working Twilio SMS/Voice webhooks and Eyefinity API integration.

---

## 1. Environment Variables in Vercel

Go to your Vercel project → Settings → Environment Variables and add:

### Required for Twilio (SMS & Voice)
```
TWILIO_ACCOUNT_SID=AC4f1eff3c432ecd8a1a0552b6d4549c07
TWILIO_AUTH_TOKEN=9f5fb700d065b7c00b273f0da1f8f566
TWILIO_PHONE_NUMBER=+17155675309
ENABLE_AI_SMS_REPLY=true
ENABLE_AI_VOICE_ANSWER=true
```

### Required for AI Features
```
ANTHROPIC_API_KEY=sk-ant-api03-...
VITE_ANTHROPIC_API_KEY=sk-ant-api03-...
```

### Required for Eyefinity API
```
EYEFINITY_ACCESS_TOKEN=eyJhbGciOiJIUzI1NiIs...
NEXT_PUBLIC_EYEFINITY_TOKEN=eyJhbGciOiJIUzI1NiIs...
VITE_EYEFINITY_ACCESS_TOKEN=eyJhbGciOiJIUzI1NiIs...
```

### Optional
```
OFFICE_PHONE_NUMBER=+1555123456  # For call forwarding
```

---

## 2. Configure Twilio Webhooks

After deploying to Vercel, get your production URL (e.g., `https://timeline-xyz.vercel.app`)

### SMS Webhook
1. Go to [Twilio Console](https://console.twilio.com)
2. Navigate to: **Phone Numbers** → **Manage** → **Active Numbers**
3. Click your phone number (+17155675309)
4. Under **Messaging Configuration**:
   - **A Message Comes In**: Webhook
   - **URL**: `https://YOUR-VERCEL-URL.vercel.app/api/webhooks/twilio-sms`
   - **HTTP Method**: POST
5. Under **Status Callback URL** (optional):
   - `https://YOUR-VERCEL-URL.vercel.app/api/webhooks/twilio-status`

### Voice Webhook
1. Same phone number settings page
2. Under **Voice Configuration**:
   - **A Call Comes In**: Webhook
   - **URL**: `https://YOUR-VERCEL-URL.vercel.app/api/webhooks/twilio-voice`
   - **HTTP Method**: POST
3. Under **Call Status Changes** (optional):
   - `https://YOUR-VERCEL-URL.vercel.app/api/webhooks/twilio-status`

---

## 3. API Endpoints Available

Once deployed, these endpoints are available:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/webhooks/twilio-sms` | POST | Handles inbound SMS, sends AI replies |
| `/api/webhooks/twilio-voice` | POST | Handles inbound calls with IVR menu |
| `/api/webhooks/twilio-status` | POST | Receives delivery/call status updates |
| `/api/eyefinity/*` | ALL | Proxies to Eyefinity PM API |

---

## 4. Testing Webhooks

### Test SMS
Send a text to your Twilio number. You should receive an AI-generated reply.

### Test Voice
Call your Twilio number. You should hear the IVR greeting and menu.

### Test from Twilio Console
1. Go to Twilio Console → Phone Numbers → Your Number
2. Click "Logs" to see webhook requests and responses

### Local Testing with ngrok
For local development testing with real Twilio webhooks:
```bash
# Terminal 1: Run the app
npm run dev

# Terminal 2: Expose with ngrok
ngrok http 5173

# Update Twilio webhooks to ngrok URL temporarily
```

---

## 5. Eyefinity API Access from Vercel

The `/api/eyefinity/*` proxy routes requests to `pm-ci.eyefinity.com`.

**Note**: If you need to access Eyefinity from your local VPN machine while the app is on Vercel:
1. The Vercel serverless functions can reach Eyefinity directly
2. No VPN tunnel needed - Eyefinity API is publicly accessible with token auth

If Eyefinity requires VPN access:
- Option A: Use a service like [Tailscale](https://tailscale.com) to create a mesh network
- Option B: Deploy the API proxy separately on a VPN-connected server
- Option C: Use Vercel's private networking (Enterprise feature)

---

## 6. Deployment Checklist

- [ ] Push code to GitHub (already done)
- [ ] Connect GitHub repo to Vercel
- [ ] Add all environment variables
- [ ] Deploy and get production URL
- [ ] Update Twilio SMS webhook URL
- [ ] Update Twilio Voice webhook URL
- [ ] Test SMS by texting the number
- [ ] Test Voice by calling the number
- [ ] Verify Eyefinity API calls work

---

## 7. Troubleshooting

### SMS not working
- Check Twilio Console → Messaging Logs
- Verify webhook URL is correct
- Check Vercel function logs

### Voice not working
- Check Twilio Console → Call Logs
- Verify TwiML is valid XML
- Check Vercel function logs

### Eyefinity API errors
- Verify token is valid and not expired
- Check CORS headers in browser console
- Verify the proxy path rewriting is correct

### View Vercel Logs
```bash
vercel logs --follow
```
Or view in Vercel Dashboard → Deployments → Functions tab
