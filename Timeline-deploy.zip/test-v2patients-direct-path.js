#!/usr/bin/env node

/**
 * Test specific v2patients direct path format: /v2patients/{patientguid}/rx?page=1&pageSize=500
 */

console.log('🎯 TESTING V2PATIENTS DIRECT PATH FORMAT');
console.log('════════════════════════════════════════════════════════════════════════');
console.log('Format: /v2patients/{patientguid}/rx?page=1&pageSize=500');

const testPatientGuids = [
  'ecab1a6c-5aba-457a-870a-2743822de084',
  '34f9334e-2dcd-4190-9190-e87709fad676',
];

const formatValue = (value) => {
  if (value === null || value === undefined) return '⚪ null';
  if (value === '') return '⚪ empty';
  return value;
};

const displayRxData = (rxItems, guid) => {
  console.log(`\n💊 RX DATA FOR GUID ${guid}:`);
  console.log('═'.repeat(80));
  
  if (rxItems.length > 0) {
    console.log(`   📊 Found ${rxItems.length} prescriptions`);
    
    rxItems.forEach((rx, i) => {
      console.log(`\n📋 Prescription ${i + 1}:`);
      console.log('─'.repeat(60));
      console.log(`   RX Number................: ${formatValue(rx.RxNumber)}`);
      console.log(`   Date Prescribed..........: ${formatValue(rx.DatePrescribed)}`);
      console.log(`   Product Type.............: ${formatValue(rx.Product)}`);
      console.log(`   Status...................: ${formatValue(rx.Status)}`);
      console.log(`   Provider.................: ${formatValue(rx.ProviderName)}`);
      console.log(`   OD Sphere................: ${formatValue(rx.OdSphere)}`);
      console.log(`   OD Cylinder..............: ${formatValue(rx.OdCylinder)}`);
      console.log(`   OD Axis..................: ${formatValue(rx.OdAxis)}`);
      console.log(`   OS Sphere................: ${formatValue(rx.OsSphere)}`);
      console.log(`   OS Cylinder..............: ${formatValue(rx.OsCylinder)}`);
      console.log(`   OS Axis..................: ${formatValue(rx.OsAxis)}`);
      console.log(`   Add Power................: ${formatValue(rx.AddPower)}`);
      console.log(`   PD.......................: ${formatValue(rx.PupillaryDistance || rx.PD)}`);
      console.log(`   Expiration Date..........: ${formatValue(rx.ExpirationDate)}`);
    });
    
    return true;
  } else {
    console.log('   📭 No prescriptions found for this patient');
    return false;
  }
};

const testV2PatientsDirectPath = async (patientGuid) => {
  try {
    console.log(`\n🧪 Testing V2Patients Direct Path: ${patientGuid}`);
    console.log('─'.repeat(80));
    
    const endpoint = `/api/eyefinity/v2patients/${patientGuid}/rx`;
    const url = `https://patientcare-teal.vercel.app${endpoint}?page=1&pageSize=500`;
    
    console.log(`   Endpoint: ${endpoint}`);
    console.log(`   Full URL: ${url}`);
    
    const startTime = Date.now();
    const response = await fetch(url);
    const duration = Date.now() - startTime;
    
    console.log(`   Status: ${response.status} ${response.statusText} (${duration}ms)`);
    
    if (response.ok) {
      const data = await response.json();
      const rxItems = data.items || data || [];
      
      console.log(`   🎉 SUCCESS! V2Patients direct path works!`);
      
      const hasData = displayRxData(rxItems, patientGuid);
      
      return {
        success: true,
        patientGuid,
        endpoint,
        rxCount: rxItems.length,
        hasData,
        data,
        duration
      };
      
    } else if (response.status === 400) {
      const text = await response.text();
      console.log(`   ⚠️  Bad Request: ${text.substring(0, 200)}`);
      return { success: false, patientGuid, status: 400, error: text, duration };
      
    } else if (response.status === 404) {
      console.log(`   ❌ Not Found: Direct path endpoint doesn't exist`);
      return { success: false, patientGuid, status: 404, duration };
      
    } else {
      const text = await response.text();
      console.log(`   ❌ Failed: ${response.status} - ${text.substring(0, 100)}`);
      return { success: false, patientGuid, status: response.status, error: text, duration };
    }
    
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
    return { success: false, patientGuid, error: error.message };
  }
};

const runV2PatientsDirectPathTests = async () => {
  console.log('\n🚀 Testing V2Patients Direct Path Format');
  console.log('User asked: v2patients/[patintguid}/rx?page=1&pageSize=500');
  console.log('═'.repeat(80));
  
  const results = [];
  
  for (let i = 0; i < testPatientGuids.length; i++) {
    const guid = testPatientGuids[i];
    const result = await testV2PatientsDirectPath(guid);
    results.push(result);
    
    if (i < testPatientGuids.length - 1) {
      console.log('\n' + '═'.repeat(100));
    }
  }
  
  console.log('\n\n🎯 V2PATIENTS DIRECT PATH RESULTS:');
  console.log('═'.repeat(80));
  
  const successful = results.filter(r => r.success);
  const withData = results.filter(r => r.success && r.hasData);
  
  console.log(`\n📊 TEST SUMMARY:`);
  console.log(`   Total Tests: ${results.length}`);
  console.log(`   ✅ Successful (200): ${successful.length}`);
  console.log(`   📦 With RX Data: ${withData.length}`);
  
  if (withData.length > 0) {
    console.log(`\n🎉 BREAKTHROUGH! V2PATIENTS DIRECT PATH WORKS!`);
    console.log('═'.repeat(60));
    
    withData.forEach(r => {
      console.log(`   🏆 GUID ${r.patientGuid}: ${r.rxCount} prescriptions`);
      console.log(`   ✅ Working Endpoint: ${r.endpoint}`);
    });
    
    const workingResult = withData[0];
    console.log(`\n💡 SOLUTION FOUND:`);
    console.log(`   ✅ Format: /api/eyefinity/v2patients/{patientGuid}/rx`);
    console.log(`   ✅ Parameters: ?page=1&pageSize=500`);
    console.log(`   ✅ This is the correct RX endpoint structure!`);
    
    console.log(`\n🔧 UPDATE EYEFINITY SERVICE:`);
    console.log(`   1. Change getPatientRx() to use: /v2patients/{patientGuid}/rx`);
    console.log(`   2. Use patient GUID directly in path`);
    console.log(`   3. Add pagination parameters`);
    console.log(`   4. Test in Patient Readiness Center`);
    
    console.log(`\n🎊 FINAL STATUS:`);
    console.log(`   ✅ Patient Details: WORKING`);
    console.log(`   ✅ Orders API: WORKING`);  
    console.log(`   ✅ RX API: WORKING`);
    console.log(`   🎉 ALL THREE APIs WORKING!`);
    
  } else if (successful.length > 0) {
    console.log(`\n✅ V2PATIENTS DIRECT PATH WORKS (but no RX data):`);
    successful.forEach(r => {
      console.log(`   ✅ GUID ${r.patientGuid}: endpoint works`);
    });
    
    console.log(`\n💡 RX API FORMAT CONFIRMED:`);
    console.log(`   Format: /api/eyefinity/v2patients/{patientGuid}/rx`);
    console.log(`   Status: Working (200) - need patients with RX data`);
    
  } else {
    console.log(`\n❌ V2PATIENTS DIRECT PATH RESULTS:`);
    results.forEach(r => {
      console.log(`   ❌ GUID ${r.patientGuid}: ${r.status || 'Error'}`);
      if (r.error && r.error.length < 100) {
        console.log(`       ${r.error}`);
      }
    });
    
    console.log(`\n🔍 THIS FORMAT ALSO NOT WORKING:`);
    console.log(`   - Direct path /v2patients/{guid}/rx returns same errors`);
    console.log(`   - All RX endpoint variations tested return 404 or 400`);
  }
  
  // Show what we know works
  console.log(`\n📋 CONFIRMED WORKING APIS:`);
  console.log('─'.repeat(40));
  console.log('✅ Orders: /api/eyefinity/v2orders?patientId={guid}');
  console.log('✅ Patient Details: /api/eyefinity/v2patients/{guid}');
  
  if (withData.length > 0) {
    console.log('✅ RX: /api/eyefinity/v2patients/{guid}/rx');
  } else {
    console.log('❌ RX: No working endpoint found yet');
  }
};

runV2PatientsDirectPathTests().catch(console.error);
