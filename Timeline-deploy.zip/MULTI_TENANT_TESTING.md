# Multi-Tenant System Testing Guide

## Pre-Testing: Database Migration

Run this in your Supabase SQL Editor:

```sql
-- Add api_path column to companies table
ALTER TABLE companies ADD COLUMN IF NOT EXISTS api_path TEXT DEFAULT 'al-pe';

COMMENT ON COLUMN companies.api_path IS 'API path prefix (e.g., al-pe, api, v1) - used to construct full API URL';

-- Verify the column was added
SELECT column_name, data_type, column_default 
FROM information_schema.columns 
WHERE table_name = 'companies' AND column_name = 'api_path';
```

Expected result: Should show the new `api_path` column with default `'al-pe'`.

---

## Test 1: West Eyes Static Token Setup

### Setup Steps
1. Navigate to `https://patientcare-teal.vercel.app/admin`
2. If no companies exist, you'll see the Account Setup Wizard
3. If companies exist, click "Add New Company" or similar

### Configuration
- **Account Name**: `West Eyes Practice`
- **Company Name**: `West Eyes`
- **Eyefinity Company ID**: [Your company ID]
- **Authentication Method**: Select "Static Access Token"

### Credentials (Static Token Form)
- **API Base URL**: `https://pm-ci.eyefinity.com`
- **API Path**: `al-pe`
- **Access Token**: [Paste your static bearer token]

### Import Data
1. Click "Connect to Eyefinity"
2. Import Offices
3. Import Staff/Providers

### Verification
- ✅ Company appears in company switcher
- ✅ Offices listed correctly
- ✅ Staff listed correctly
- ✅ Console shows: `[Eyefinity] Using static bearer token for company [id]`
- ✅ Console shows: `apiPath: 'al-pe'` in proxy logs

---

## Test 2: Multi-Company Isolation

### Setup Second Company (Optional)
If you have Vision Care OAuth credentials:
1. Add another company using OAuth method
2. Enter Client ID, Secret, Tenant UID
3. Complete OAuth flow
4. Import offices/staff

### Test Data Isolation
1. **Switch to West Eyes**
   - Open company switcher in header
   - Select "West Eyes"
   - Wait for page reload

2. **Verify West Eyes Data**
   - Navigate to Staff Management
   - Verify ONLY West Eyes staff are listed
   - Check Office list - should show ONLY West Eyes offices
   - Note down staff count: ______

3. **Switch to Vision Care** (if configured)
   - Open company switcher
   - Select "Vision Care"
   - Wait for page reload

4. **Verify Vision Care Data**
   - Navigate to Staff Management
   - Verify ONLY Vision Care staff are listed
   - Check Office list - should show ONLY Vision Care offices
   - Note down staff count: ______

5. **Critical Test**
   - Staff counts should be DIFFERENT between companies
   - No staff should appear in both lists
   - ❌ If same staff appear in both = DATA LEAK (report immediately)

---

## Test 3: API Path Configuration

### Change API Path
1. Navigate to Company Settings for West Eyes
2. Update "API Path" field to a different value (e.g., `api`)
3. Save settings
4. Try to import offices or make an API call

### Verification
- Console should show new path: `apiPath: 'api'`
- Target URL should be: `https://pm-ci.eyefinity.com/api/[endpoint]`

### Restore Original Path
1. Change back to `al-pe`
2. Save settings
3. Verify API calls work again

---

## Test 4: Security Verification

### Patient Data Isolation (if patients exist)
1. Switch to Company A
2. Navigate to Patients list
3. Note first patient name: ______
4. Switch to Company B
5. Navigate to Patients list
6. Verify first patient name is DIFFERENT
7. ❌ If same patient appears = SECURITY ISSUE

### Appointment Data Isolation (if appointments exist)
1. Switch to Company A
2. View appointment calendar
3. Note appointment count: ______
4. Switch to Company B
5. View appointment calendar
6. Note appointment count: ______
7. Counts should be independent
8. ❌ If appointments cross over = SECURITY ISSUE

---

## Test 5: Console Monitoring

### What to Look For
Open browser DevTools Console and watch for:

**Good Signs:**
```
[Eyefinity Proxy] Request: {
  companyId: "uuid-here",
  apiPath: "al-pe",
  target: "https://pm-ci.eyefinity.com/al-pe/v2offices"
}
[Eyefinity] Using static bearer token for company [id]
```

**Warning Signs:**
```
❌ Error: Patient not found
❌ 401 Unauthorized
❌ Missing companyId in request
❌ No api_path field in database
```

---

## Test 6: Company Switcher

### Functionality
1. Click company switcher in header
2. Verify all companies listed
3. Current company should be highlighted
4. Switch between companies multiple times

### Data Refresh
After each switch:
- ✅ URL should NOT change
- ✅ Data should reload automatically
- ✅ Header should show new company name
- ✅ Office/staff lists should update

---

## Test 7: Static Token Persistence

### Verify Token Saved
1. Go to Company Settings for West Eyes
2. Authentication section should show "Static Access Token" mode
3. Token field should be populated (masked)
4. API Base URL should show: `https://pm-ci.eyefinity.com`
5. API Path should show: `al-pe`

### Edit and Save
1. Edit the token (change last character)
2. Save settings
3. Refresh page
4. Verify token is still changed (not reverted)
5. ✅ Token should persist
6. ❌ If reverts = SAVE BUG (already fixed, should not happen)

---

## Checklist Summary

- [ ] Database migration completed
- [ ] West Eyes company added with static token
- [ ] Offices imported for West Eyes
- [ ] Staff imported for West Eyes
- [ ] Company switcher shows West Eyes
- [ ] Static token mode detected in console
- [ ] API path configurable and working
- [ ] (Optional) Second company added
- [ ] Data isolation verified between companies
- [ ] No staff cross-contamination
- [ ] No patient cross-contamination
- [ ] Console logs show correct company IDs
- [ ] Token persistence working

---

## Troubleshooting

### Issue: "No companies found"
- Check database - `SELECT * FROM companies;`
- Verify account/company were created

### Issue: "401 Unauthorized"
- Check token is correct and not expired
- Verify API base URL is correct
- Check VPN connection if required

### Issue: "Staff from other company showing"
- **CRITICAL** - Report immediately
- Check console for SQL queries
- Verify company filter in requests

### Issue: "API path not working"
- Check database: `SELECT name, api_path FROM companies;`
- Verify migration ran successfully
- Check console for `apiPath` value

---

## Success Criteria

✅ **System is ready for production when:**
1. All tests pass
2. No data cross-contamination
3. Static token persists correctly
4. API path configurable
5. Company switching works smoothly
6. Console shows no errors
7. Multi-tenant isolation verified

---

## Next Steps After Testing

Once all tests pass:
1. Document any issues found
2. Report test results
3. Plan AWS migration (if desired)
4. Deploy to production
5. Train users on company switcher

---

## Support

If you encounter issues:
1. Check browser console for errors
2. Check Supabase logs
3. Verify Vercel deployment succeeded
4. Check this testing guide for troubleshooting steps
