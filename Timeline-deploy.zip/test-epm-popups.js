#!/usr/bin/env node

/**
 * Test script to debug EPM popup PatientLegacyId issues
 * Tests patient data mapping and legacy ID availability
 */

console.log('🧪 Testing EPM Popup PatientLegacyId Issues...\n');

// Test 1: Check patient API response structure
console.log('1. Testing Patient API Response Structure...');

const testPatientApi = async () => {
  try {
    // Test a known patient ID - using one from the logs
    const testPatientId = '1167046'; // Legacy ID
    const testGuid = 'ecab1a6c-5aba-457a-870a-2743822de084'; // GUID from debug
    
    console.log('   Testing with Legacy ID:', testPatientId);
    
    const response = await fetch(`https://patientcare-teal.vercel.app/api/eyefinity/patients/${testPatientId}`, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    });
    
    console.log('   Response status:', response.status);
    
    if (response.ok) {
      const patientData = await response.json();
      console.log('   Raw API Response Keys:', Object.keys(patientData));
      
      // Check for PatientLegacyId in response
      console.log('   PatientLegacyId in response:', patientData.PatientLegacyId);
      console.log('   PatientId in response:', patientData.PatientId);
      console.log('   patientId in response:', patientData.patientId);
      console.log('   id in response:', patientData.id);
      
      // Check if legacy ID exists
      if (patientData.PatientLegacyId) {
        console.log('   ✅ PatientLegacyId found:', patientData.PatientLegacyId);
      } else {
        console.log('   ❌ PatientLegacyId NOT found in API response');
        console.log('   Available fields:', JSON.stringify(patientData, null, 2).substring(0, 500) + '...');
      }
    } else {
      const errorText = await response.text();
      console.log('   ❌ API Error:', response.status, errorText);
    }
    
    console.log('\n   Testing with GUID:', testGuid);
    
    const guidResponse = await fetch(`https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testGuid}`, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    });
    
    console.log('   GUID Response status:', guidResponse.status);
    
    if (guidResponse.ok) {
      const guidPatientData = await guidResponse.json();
      console.log('   GUID Response Keys:', Object.keys(guidPatientData));
      console.log('   PatientLegacyId from GUID call:', guidPatientData.PatientLegacyId);
      console.log('   PatientId from GUID call:', guidPatientData.PatientId);
    }
    
  } catch (error) {
    console.log('   ❌ Error testing patient API:', error.message);
  }
};

await testPatientApi();

console.log('\n2. EPM Popup Logic Test:');
console.log('   Expected behavior:');
console.log('   - patientDetails.PatientLegacyId should contain integer ID (e.g., 1167046)');
console.log('   - patientDetails.PatientId should contain GUID');
console.log('   - Popup URLs should use: selectedAppointment.patientId || patientDetails.PatientLegacyId || patientDetails.PatientId');
console.log('');

// Test 3: Simulate popup logic
console.log('3. Simulating Popup URL Logic:');

const simulatePopupLogic = (selectedAppointment, patientDetails) => {
  const patientId = selectedAppointment?.patientId || patientDetails?.PatientLegacyId || patientDetails?.PatientId;
  console.log('   selectedAppointment.patientId:', selectedAppointment?.patientId);
  console.log('   patientDetails.PatientLegacyId:', patientDetails?.PatientLegacyId);
  console.log('   patientDetails.PatientId:', patientDetails?.PatientId);
  console.log('   Final patientId used:', patientId);
  
  const isLegacyId = typeof patientId === 'number' || (typeof patientId === 'string' && /^\d+$/.test(patientId));
  console.log('   ✅ Using Legacy ID (integer)?', isLegacyId);
  console.log('   ❌ Using GUID?', !isLegacyId && /^[0-9a-f-]{36}$/.test(patientId));
  
  return patientId;
};

// Test case 1: GUID in selectedAppointment
console.log('\n   Test Case 1 - GUID in selectedAppointment:');
simulatePopupLogic(
  { patientId: 'ecab1a6c-5aba-457a-870a-2743822de084' },
  { PatientLegacyId: 1167046, PatientId: 'ecab1a6c-5aba-457a-870a-2743822de084' }
);

// Test case 2: Legacy ID available
console.log('\n   Test Case 2 - No selectedAppointment, PatientLegacyId available:');
simulatePopupLogic(
  null,
  { PatientLegacyId: 1167046, PatientId: 'ecab1a6c-5aba-457a-870a-2743822de084' }
);

// Test case 3: Legacy ID missing (current issue)
console.log('\n   Test Case 3 - PatientLegacyId missing (CURRENT ISSUE):');
simulatePopupLogic(
  { patientId: 'ecab1a6c-5aba-457a-870a-2743822de084' },
  { PatientLegacyId: undefined, PatientId: undefined, id: 'ecab1a6c-5aba-457a-870a-2743822de084' }
);

console.log('\n🎯 Issues to Fix:');
console.log('1. If PatientLegacyId is undefined in patientDetails, patient mapping is not preserving it');
console.log('2. selectedAppointment.patientId contains GUID, should prioritize PatientLegacyId first');
console.log('3. May need to update popup call order or patient data loading');
