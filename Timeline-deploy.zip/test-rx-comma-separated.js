#!/usr/bin/env node

/**
 * Test RX endpoints with comma-separated UUID format
 * Error message indicates: "Patient UUIDs should be UUID strings and comma separated"
 */

console.log('🔥 TESTING RX API - COMMA SEPARATED UUID FORMAT');
console.log('════════════════════════════════════════════════════════════════════════');

const testPatientGuids = [
  'ecab1a6c-5aba-457a-870a-2743822de084',
  '34f9334e-2dcd-4190-9190-e87709fad676',
];

const formatValue = (value) => {
  if (value === null || value === undefined) return '⚪ null';
  if (value === '') return '⚪ empty';
  return value;
};

const displayRxData = (rxItems, guid) => {
  console.log(`\n💊 RX DATA FOR ${guid} (${rxItems.length} items):`);
  console.log('═'.repeat(80));
  
  if (rxItems.length > 0) {
    rxItems.forEach((rx, i) => {
      console.log(`\n📋 Prescription ${i + 1}:`);
      console.log('─'.repeat(60));
      console.log(`   RX Number................: ${formatValue(rx.RxNumber)}`);
      console.log(`   Date Prescribed..........: ${formatValue(rx.DatePrescribed)}`);
      console.log(`   Product Type.............: ${formatValue(rx.Product)}`);
      console.log(`   Status...................: ${formatValue(rx.Status)}`);
      console.log(`   Provider.................: ${formatValue(rx.ProviderName)}`);
      console.log(`   OD Sphere................: ${formatValue(rx.OdSphere)}`);
      console.log(`   OD Cylinder..............: ${formatValue(rx.OdCylinder)}`);
      console.log(`   OD Axis..................: ${formatValue(rx.OdAxis)}`);
      console.log(`   OS Sphere................: ${formatValue(rx.OsSphere)}`);
      console.log(`   OS Cylinder..............: ${formatValue(rx.OsCylinder)}`);
      console.log(`   OS Axis..................: ${formatValue(rx.OsAxis)}`);
      console.log(`   Add Power................: ${formatValue(rx.AddPower)}`);
      console.log(`   PD.......................: ${formatValue(rx.PupillaryDistance || rx.PD)}`);
      console.log(`   Expiration Date..........: ${formatValue(rx.ExpirationDate)}`);
    });
    
    return true;
  } else {
    console.log('   📭 No prescriptions found for this patient');
    return false;
  }
};

const testRxFormat = async (endpoint, paramName, guid, description) => {
  try {
    console.log(`\n🧪 ${description}`);
    console.log(`   GUID: ${guid}`);
    console.log(`   Parameter: ${paramName}`);
    
    const url = `https://patientcare-teal.vercel.app${endpoint}?${paramName}=${guid}&page=1&pageSize=500`;
    console.log(`   URL: ${url}`);
    
    const response = await fetch(url);
    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    if (response.ok) {
      const data = await response.json();
      const rxItems = data.items || data || [];
      
      console.log(`   🎉 SUCCESS! RX endpoint works!`);
      const hasData = displayRxData(rxItems, guid);
      
      return { 
        success: true, 
        endpoint, 
        paramName,
        guid, 
        rxCount: rxItems.length, 
        hasData,
        data 
      };
    } else if (response.status === 400) {
      const text = await response.text();
      console.log(`   ⚠️  Bad Request: ${text.substring(0, 200)}`);
      return { success: false, endpoint, paramName, guid, status: 400, error: text };
    } else {
      console.log(`   ❌ Failed: ${response.status}`);
      return { success: false, endpoint, paramName, guid, status: response.status };
    }
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
    return { success: false, endpoint, paramName, guid, error: error.message };
  }
};

const runRxFormatTests = async () => {
  console.log('\n🚀 Testing different RX parameter formats based on error message');
  console.log('Error said: "Patient UUIDs should be UUID strings and comma separated"');
  console.log('═'.repeat(80));
  
  const allResults = [];
  
  for (const guid of testPatientGuids) {
    console.log(`\n👤 Testing Patient GUID: ${guid}`);
    console.log('─'.repeat(80));
    
    // Test different parameter formats based on the error message
    const testCases = [
      // Original failing formats
      { endpoint: '/api/eyefinity/v2patients/rx', param: 'id', desc: 'Original id parameter' },
      { endpoint: '/api/eyefinity/v2patients/rx', param: 'patientId', desc: 'Original patientId parameter' },
      
      // Try different parameter names that might work
      { endpoint: '/api/eyefinity/v2patients/rx', param: 'patientIds', desc: 'Plural patientIds parameter' },
      { endpoint: '/api/eyefinity/v2patients/rx', param: 'ids', desc: 'Plural ids parameter' },
      { endpoint: '/api/eyefinity/v2patients/rx', param: 'uuids', desc: 'UUIDs parameter' },
      { endpoint: '/api/eyefinity/v2patients/rx', param: 'patientUuids', desc: 'Patient UUIDs parameter' },
      
      // Try without parameters (maybe it's a POST?)
      { endpoint: `/api/eyefinity/v2patients/${guid}/rx`, param: '', desc: 'Direct path with GUID' },
      
      // Try the bulk endpoint format (comma separated might be for bulk queries)
      { endpoint: '/api/eyefinity/v2patients/rx', param: 'patientIds', desc: 'Comma-separated format', value: `${guid},${guid}` },
    ];
    
    for (const testCase of testCases) {
      const testValue = testCase.value || guid;
      if (testCase.param) {
        const result = await testRxFormat(testCase.endpoint, testCase.param, testValue, testCase.desc);
        allResults.push(result);
      } else {
        // Test direct path
        const result = await testRxFormat(testCase.endpoint, '', '', testCase.desc);
        allResults.push(result);
      }
      console.log('─'.repeat(60));
    }
  }
  
  // Also test if it's a batch/bulk endpoint that expects multiple patients
  console.log('\n🔄 Testing Bulk/Batch RX Endpoint:');
  console.log('─'.repeat(80));
  
  const bulkGuidList = testPatientGuids.join(',');
  console.log(`\n🧪 Testing bulk format with comma-separated GUIDs:`);
  console.log(`   GUIDs: ${bulkGuidList}`);
  
  const bulkEndpoints = [
    { endpoint: '/api/eyefinity/v2patients/rx', param: 'patientIds' },
    { endpoint: '/api/eyefinity/v2patients/rx', param: 'ids' },
    { endpoint: '/api/eyefinity/v2patients/rx', param: 'patientUuids' },
  ];
  
  for (const bulk of bulkEndpoints) {
    const result = await testRxFormat(bulk.endpoint, bulk.param, bulkGuidList, `Bulk ${bulk.param} parameter`);
    allResults.push(result);
    console.log('─'.repeat(60));
  }
  
  console.log('\n\n🎯 COMPREHENSIVE RX FORMAT TEST RESULTS:');
  console.log('═'.repeat(80));
  
  const successful = allResults.filter(r => r.success);
  const withData = allResults.filter(r => r.success && r.hasData);
  const badRequests = allResults.filter(r => r.status === 400);
  
  console.log(`\n📊 RESULTS SUMMARY:`);
  console.log(`   Total Tests: ${allResults.length}`);
  console.log(`   ✅ Successful (200): ${successful.length}`);
  console.log(`   📦 With RX Data: ${withData.length}`);
  console.log(`   ⚠️  Bad Request (400): ${badRequests.length}`);
  
  if (withData.length > 0) {
    console.log(`\n🎉 FOUND WORKING RX ENDPOINTS WITH DATA!`);
    withData.forEach(r => {
      console.log(`   🏆 ${r.endpoint}?${r.paramName}=${r.guid} - ${r.rxCount} prescriptions`);
    });
    
    console.log(`\n💡 SOLUTION FOUND - UPDATE EYEFINITY SERVICE:`);
    const workingEndpoint = withData[0];
    console.log(`   ✅ Endpoint: ${workingEndpoint.endpoint}`);
    console.log(`   ✅ Parameter: ${workingEndpoint.paramName}`);
    console.log(`   ✅ Format: ${workingEndpoint.endpoint}?${workingEndpoint.paramName}={patientGuid}`);
    
  } else if (successful.length > 0) {
    console.log(`\n✅ RX ENDPOINTS WORK (but no data for these patients):`);
    successful.forEach(r => {
      console.log(`   ✅ ${r.endpoint}?${r.paramName}=${r.guid.substring(0, 8)}... - works`);
    });
    
  } else {
    console.log(`\n❌ No working RX format found yet`);
    
    // Analyze the 400 errors for patterns
    if (badRequests.length > 0) {
      console.log(`\n🔍 ANALYZING BAD REQUEST PATTERNS:`);
      const errorPatterns = {};
      badRequests.forEach(r => {
        const errorKey = r.error?.substring(0, 100) || 'Unknown error';
        errorPatterns[errorKey] = (errorPatterns[errorKey] || 0) + 1;
      });
      
      Object.entries(errorPatterns).forEach(([error, count]) => {
        console.log(`   (${count}x) ${error}`);
      });
    }
  }
};

runRxFormatTests().catch(console.error);
