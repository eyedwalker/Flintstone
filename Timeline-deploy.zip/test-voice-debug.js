#!/usr/bin/env node

/**
 * Debug voice API issues - test ElevenLabs audio generation endpoint
 */

console.log('🔍 Debugging Voice API Issues...\n');

const BASE_URL = 'https://patientcare-teal.vercel.app';

// Test ElevenLabs audio generation endpoint directly
const testAudioGeneration = async () => {
  console.log('1. Testing ElevenLabs Audio Generation Endpoint...');
  try {
    const testText = 'Hello, this is a test message.';
    const audioUrl = `${BASE_URL}/api/voice/generate-audio?voice=sarah&text=${encodeURIComponent(testText)}`;
    
    console.log('   Audio URL:', audioUrl);
    
    const response = await fetch(audioUrl, {
      method: 'GET',
      headers: { 'Accept': 'audio/mpeg' }
    });

    console.log('   Response status:', response.status);
    console.log('   Content-Type:', response.headers.get('content-type'));
    console.log('   Content-Length:', response.headers.get('content-length'));
    
    if (response.ok) {
      console.log('   ✅ Audio generation endpoint working');
      
      // Check if it's actually audio
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('audio')) {
        console.log('   ✅ Returns audio content');
      } else {
        console.log('   ❌ Not returning audio - Content-Type:', contentType);
        const text = await response.text();
        console.log('   Response body:', text.substring(0, 200));
      }
    } else {
      console.log('   ❌ Audio generation failed');
      const errorText = await response.text();
      console.log('   Error:', errorText);
    }
  } catch (error) {
    console.log('   ❌ Audio generation error:', error.message);
  }
  console.log('');
};

// Test simple TwiML without ElevenLabs
const testSimpleTwiML = async () => {
  console.log('2. Testing Simple Voice Call (no ElevenLabs)...');
  try {
    const response = await fetch(`${BASE_URL}/api/communications/voice`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        to: '+12142085261',
        message: 'This is a simple test message without ElevenLabs.',
        useSimpleTwiML: true, // Force simple TwiML
      })
    });

    const result = await response.json();
    console.log('   Response:', result);
    
    if (result.success) {
      console.log('   ✅ Simple voice call initiated');
      console.log('   Call ID:', result.callId);
    } else {
      console.log('   ❌ Simple voice call failed:', result.error);
    }
  } catch (error) {
    console.log('   ❌ Simple voice call error:', error.message);
  }
  console.log('');
};

// Check environment variables
const checkEnvironment = () => {
  console.log('3. Environment Variables Check:');
  
  // We can't access server env vars from client, but we can make a test call
  console.log('   Testing if ElevenLabs API key is configured...');
  
  // This will be checked by the actual API call
  console.log('   ℹ️  Will be verified by API responses above');
  console.log('');
};

// Run diagnostics
const runDiagnostics = async () => {
  checkEnvironment();
  await testAudioGeneration();
  await testSimpleTwiML();
  
  console.log('🎯 Likely Issues:');
  console.log('1. ElevenLabs API quota exceeded or key invalid');
  console.log('2. Audio generation endpoint timeout (>30s)');
  console.log('3. TwiML malformed or audio URL unreachable');
  console.log('4. Network issues between Twilio and Vercel');
  console.log('');
  console.log('💡 Solutions:');
  console.log('1. Fallback to simple Twilio <Say> voice');
  console.log('2. Add error handling and retries');
  console.log('3. Reduce audio generation timeout');
  console.log('4. Test with shorter messages');
};

runDiagnostics();
