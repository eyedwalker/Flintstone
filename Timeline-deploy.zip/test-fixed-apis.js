#!/usr/bin/env node

/**
 * Test the fixed RX and Orders API endpoints
 */

const testPatientId = 'ecab1a6c-5aba-457a-870a-2743822de084'; // GUID
const testLegacyId = '1166951'; // From console logs

console.log('🧪 TESTING FIXED RX AND ORDERS API ENDPOINTS\n');

const testEndpoints = [
  {
    name: 'Orders API (v2orders with patientId query)',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2orders?patientId=${testPatientId}&fromStatusChangedDate=2020-01-01&toStatusChangedDate=2026-01-27&page=1&pageSize=100`,
    expectedResult: 'Should return 200 with orders data'
  },
  {
    name: 'RX API (v2patients with legacy ID)', 
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testLegacyId}/rx?page=1&pageSize=100`,
    expectedResult: 'Should return 200 with RX data'
  }
];

const testEndpoint = async (endpoint) => {
  try {
    console.log(`\n🔍 ${endpoint.name}:`);
    console.log(`   URL: ${endpoint.url}`);
    console.log(`   Expected: ${endpoint.expectedResult}`);
    
    const startTime = Date.now();
    const response = await fetch(endpoint.url);
    const duration = Date.now() - startTime;
    
    console.log(`   Status: ${response.status} (${duration}ms)`);
    
    if (response.status === 200) {
      try {
        const data = await response.json();
        const itemCount = data.items?.length || (Array.isArray(data) ? data.length : 'unknown');
        console.log(`   ✅ SUCCESS - Items: ${itemCount}`);
        
        if (data.items && data.items.length > 0) {
          console.log(`   Sample keys: ${Object.keys(data.items[0]).slice(0, 6).join(', ')}`);
        }
        
        return { status: 'SUCCESS', itemCount, duration };
      } catch (e) {
        console.log(`   ✅ SUCCESS - Response received (non-JSON)`);
        return { status: 'SUCCESS', duration };
      }
    } else if (response.status === 404) {
      console.log(`   ❌ NOT FOUND - Endpoint still incorrect`);
      return { status: 'NOT_FOUND', duration };
    } else {
      console.log(`   ⚠️  Error ${response.status}`);
      const text = await response.text();
      console.log(`   Response: ${text.substring(0, 100)}`);
      return { status: `ERROR_${response.status}`, duration };
    }
    
  } catch (error) {
    console.log(`   ❌ FETCH ERROR: ${error.message}`);
    return { status: 'FETCH_ERROR', error: error.message };
  }
};

const runTests = async () => {
  console.log('🔧 TESTING FIXED API ENDPOINTS:');
  console.log('════════════════════════════════════════');
  
  const results = {};
  
  for (const endpoint of testEndpoints) {
    results[endpoint.name] = await testEndpoint(endpoint);
  }
  
  console.log('\n📊 TEST RESULTS:');
  console.log('════════════════');
  
  const successCount = Object.values(results).filter(r => r.status === 'SUCCESS').length;
  const totalTests = Object.keys(results).length;
  
  Object.entries(results).forEach(([name, result]) => {
    const icon = result.status === 'SUCCESS' ? '✅' : '❌';
    console.log(`${icon} ${name}: ${result.status}`);
  });
  
  console.log(`\n🎯 SUMMARY: ${successCount}/${totalTests} APIs working`);
  
  if (successCount === totalTests) {
    console.log('\n🎉 ALL API ENDPOINTS FIXED AND WORKING!');
    console.log('✅ Orders: Uses /v2orders with patientId query parameter');
    console.log('✅ RX: Uses /v2patients/{legacyId}/rx with PatientLegacyId');
    console.log('\nThe Patient Readiness Center should now load RX and Orders data without 404 errors.');
  } else {
    console.log('\n⚠️  Some endpoints still need fixing:');
    Object.entries(results).forEach(([name, result]) => {
      if (result.status !== 'SUCCESS') {
        console.log(`   - ${name}: ${result.status}`);
      }
    });
  }
};

runTests().catch(console.error);
