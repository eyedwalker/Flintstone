#!/usr/bin/env node

/**
 * Debug Vercel Environment Variables
 * Check if required environment variables are set on Vercel
 */

console.log('🔍 DEBUGGING VERCEL ENVIRONMENT VARIABLES\n');

const requiredEnvVars = [
  'ENABLE_AI_SMS_REPLY',
  'ENABLE_AI_VOICE_ANSWER', 
  'ANTHROPIC_API_KEY',
  'TWILIO_ACCOUNT_SID',
  'TWILIO_AUTH_TOKEN',
  'TWILIO_PHONE_NUMBER',
  'ELEVENLABS_API_KEY'
];

console.log('📋 CHECKING REQUIRED ENVIRONMENT VARIABLES:');
console.log('┌─────────────────────────────────────────────────────────────────┐');

let missingVars = [];

requiredEnvVars.forEach(varName => {
  const value = process.env[varName];
  const status = value ? '✅ SET' : '❌ MISSING';
  const displayValue = value ? (varName.includes('KEY') || varName.includes('TOKEN') ? '***HIDDEN***' : value) : 'undefined';
  
  console.log(`│ ${varName.padEnd(25)} │ ${status.padEnd(10)} │ ${displayValue.substring(0, 20).padEnd(20)} │`);
  
  if (!value) {
    missingVars.push(varName);
  }
});

console.log('└─────────────────────────────────────────────────────────────────┘\n');

if (missingVars.length > 0) {
  console.log('❌ MISSING ENVIRONMENT VARIABLES ON VERCEL:');
  missingVars.forEach(varName => {
    console.log(`   - ${varName}`);
  });
  console.log('\n🔧 TO FIX: Add these to your Vercel project settings:');
  console.log('   1. Go to https://vercel.com/dashboard');
  console.log('   2. Select your project');
  console.log('   3. Go to Settings → Environment Variables');
  console.log('   4. Add each missing variable');
  console.log('');
} else {
  console.log('✅ ALL REQUIRED ENVIRONMENT VARIABLES ARE SET!\n');
}

// Test webhook endpoints directly
const testWebhookEndpoint = async (url, data) => {
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams(data).toString(),
    });
    
    const text = await response.text();
    return { status: response.status, body: text };
  } catch (error) {
    return { status: 'ERROR', error: error.message };
  }
};

// Test SMS webhook
console.log('🧪 TESTING WEBHOOK ENDPOINTS...\n');

const smsTestData = {
  From: '+12142085261',
  To: '+15806336937',
  Body: 'Test message for debugging',
  MessageSid: 'test123',
  AccountSid: 'AC4f1eff3c432ecd8a1a0552b6d4549c07'
};

console.log('📱 Testing SMS Webhook:');
testWebhookEndpoint('https://patientcare-teal.vercel.app/api/webhooks/twilio-sms', smsTestData)
  .then(result => {
    console.log(`   Status: ${result.status}`);
    console.log(`   Response: ${result.body?.substring(0, 200) || result.error}`);
    console.log('');
  });

// Test Voice webhook
const voiceTestData = {
  From: '+12142085261',
  To: '+15806336937',
  CallSid: 'test456',
  CallStatus: 'ringing'
};

console.log('📞 Testing Voice Webhook:');
testWebhookEndpoint('https://patientcare-teal.vercel.app/api/webhooks/twilio-voice', voiceTestData)
  .then(result => {
    console.log(`   Status: ${result.status}`);
    console.log(`   Response Length: ${result.body?.length || 0} characters`);
    console.log(`   Contains TwiML: ${result.body?.includes('<Response>') ? 'Yes' : 'No'}`);
    console.log('');
  });

console.log('📋 NEXT STEPS:');
console.log('1. ✅ Fix any missing environment variables on Vercel');
console.log('2. 🔄 Redeploy after adding environment variables');
console.log('3. 📱 Test SMS: "What are your hours?" to +15806336937');
console.log('4. 📞 Test Voice: Call +15806336937 and speak');
console.log('5. ✅ Confirm AI responses with practice knowledge');
