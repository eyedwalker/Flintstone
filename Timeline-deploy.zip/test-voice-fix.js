#!/usr/bin/env node

/**
 * Test the voice API fix - should now use reliable Polly voice
 */

console.log('🔧 Testing Voice API Fix...\n');

const BASE_URL = 'https://patientcare-teal.vercel.app';
const testPhone = '+12142085261';

const testVoiceFix = async () => {
  console.log('Testing Voice API with Polly.Joanna fallback...');
  try {
    const response = await fetch(`${BASE_URL}/api/communications/voice`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        to: testPhone,
        message: 'Hello! This is a test of the fixed voice system using Polly Joanna voice.',
        patientId: 'test-patient-fix',
      })
    });

    const result = await response.json();
    console.log('   Response status:', response.status);
    console.log('   Response:', result);
    
    if (result.success) {
      console.log('   ✅ Voice API call successful!');
      console.log('   📞 Call ID:', result.callId);
      console.log('   🎙️ Using Polly voice (should not get application error)');
      console.log('   📱 Call should connect and speak clearly');
    } else {
      console.log('   ❌ Voice API still failing:', result.error);
    }
  } catch (error) {
    console.log('   ❌ Voice API request error:', error.message);
  }
  console.log('');
  
  console.log('🎯 What Changed:');
  console.log('   - Now uses Twilio Polly.Joanna voice instead of ElevenLabs');
  console.log('   - No external audio generation URL dependencies');
  console.log('   - Message limited to 200 characters for reliability');
  console.log('   - Should eliminate "application error has occurred" message');
  console.log('');
  
  console.log('📞 Expected Result:');
  console.log('   - Call connects successfully');
  console.log('   - Clear female voice (Polly.Joanna) speaks the message');
  console.log('   - No application errors');
};

testVoiceFix();
