/**
 * Test Get Offices Flow
 * 
 * Tests the complete flow:
 * 1. OAuth (client credentials + token exchange)
 * 2. GET /v2/companies/{companyId}/offices
 * 3. Parse and display office data
 */

import https from 'https';
import dotenv from 'dotenv';

dotenv.config();

const OAUTH_HOST = process.env.OAUTH_HOST || 'api-sandbox.eyefinity.com';
const API_BASE_URL = process.env.EYEFINITY_API_URL || 'https://api-sandbox.eyefinity.com';
const CLIENT_ID = process.env.EPM_CLIENT_ID;
const CLIENT_SECRET = process.env.EPM_CLIENT_SECRET;
const TENANT_UID = process.env.TENANT_UID;
const EYEFINITY_COMPANY_ID = '234234'; // From your database

const EPM_SCOPES = [
  'auth_epm',
  'ef.pm_pe_patient_rx',
  'ef.pm_pe_resource',
  'ef.pm_pe_insurance',
  'ef.pm_pe_appointment',
  'ef.pm_pe_office_recallreport',
  'ef.pm_pe_staff',
  'ef.pm_pe_office',
  'ef.pm_pe_company',
  'ef.pm_pe_order',
  'ef.pm_pe_provider',
  'ef.pm_pe_patient',
].join(' ');

/**
 * Step 1: Get Client Credentials Token
 */
async function getClientCredentialsToken() {
  return new Promise((resolve, reject) => {
    const credentials = Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString('base64');
    const body = `grant_type=client_credentials&scope=${encodeURIComponent(EPM_SCOPES)}`;
    
    const options = {
      hostname: OAUTH_HOST,
      port: 443,
      path: '/as/token.oauth2',
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(body),
      },
    };

    console.log('🔐 Step 1: Client Credentials');
    console.log(`   Host: ${OAUTH_HOST}`);
    
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode === 200) {
          const json = JSON.parse(data);
          const token = json.access_token || json.accesstoken;
          console.log(`   ✅ Success: ${token.substring(0, 20)}...`);
          resolve(token);
        } else {
          console.error(`   ❌ Failed: ${res.statusCode}`);
          console.error(`   ${data}`);
          reject(new Error(`Client credentials failed: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

/**
 * Step 2: Token Exchange
 */
async function exchangeToken(ccToken) {
  return new Promise((resolve, reject) => {
    const credentials = Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString('base64');
    const body = new URLSearchParams({
      'grant_type': 'urn:ietf:params:oauth:grant-type:token-exchange',
      'subject_token': ccToken,
      'subject_token_type': 'urn:ietf:params:oauth:token-type:access_token',
      'scope': EPM_SCOPES,
      'resource': 'https://VspEpmToken',
    }).toString();
    
    const options = {
      hostname: OAUTH_HOST,
      port: 443,
      path: '/as/token.oauth2',
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(body),
        'tenantuid': TENANT_UID,
      },
    };

    console.log('\n🔄 Step 2: Token Exchange');
    console.log(`   Tenant UID: ${TENANT_UID}`);
    
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode === 200) {
          const json = JSON.parse(data);
          const token = json.access_token || json.accesstoken;
          console.log(`   ✅ Success: ${token.substring(0, 20)}...`);
          console.log(`   Expires in: ${json.expires_in || 1799}s`);
          resolve(token);
        } else {
          console.error(`   ❌ Failed: ${res.statusCode}`);
          console.error(`   ${data}`);
          reject(new Error(`Token exchange failed: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

/**
 * Step 3: Get Offices
 */
async function getOffices(epmToken) {
  return new Promise((resolve, reject) => {
    const path = `/al-pe/v2/companies/${EYEFINITY_COMPANY_ID}/offices`;
    const url = new URL(API_BASE_URL);
    
    const options = {
      hostname: url.hostname,
      port: 443,
      path: path,
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${epmToken}`,
        'Accept': 'application/json',
      },
    };

    console.log('\n🏢 Step 3: Get Offices');
    console.log(`   URL: ${API_BASE_URL}${path}`);
    
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        console.log(`   Status: ${res.statusCode}`);
        
        if (res.statusCode === 200) {
          const offices = JSON.parse(data);
          console.log(`   ✅ Success: Got ${offices.length} offices`);
          resolve(offices);
        } else {
          console.error(`   ❌ Failed: ${res.statusCode}`);
          console.error(`   ${data.substring(0, 500)}`);
          reject(new Error(`Get offices failed: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.end();
  });
}

/**
 * Run complete test
 */
async function runTest() {
  console.log('🧪 Testing Get Offices Flow');
  console.log('============================\n');
  
  if (!CLIENT_ID || !CLIENT_SECRET || !TENANT_UID) {
    console.error('❌ Missing credentials in .env');
    console.log('   EPM_CLIENT_ID:', CLIENT_ID ? '✓' : '✗');
    console.log('   EPM_CLIENT_SECRET:', CLIENT_SECRET ? '✓' : '✗');
    console.log('   TENANT_UID:', TENANT_UID ? '✓' : '✗');
    process.exit(1);
  }
  
  try {
    // Step 1: Client Credentials
    const ccToken = await getClientCredentialsToken();
    
    // Step 2: Token Exchange
    const epmToken = await exchangeToken(ccToken);
    
    // Step 3: Get Offices
    const offices = await getOffices(epmToken);
    
    // Display results
    console.log('\n📊 Offices Retrieved:');
    console.log('====================');
    offices.forEach((office, i) => {
      console.log(`\n${i + 1}. ${office.name || 'Unnamed Office'}`);
      console.log(`   Location ID: ${office.locationId || 'N/A'}`);
      console.log(`   Address: ${office.address || 'N/A'}`);
      console.log(`   Phone: ${office.phone || 'N/A'}`);
      console.log(`   Status: ${office.status || 'N/A'}`);
    });
    
    console.log('\n✅ Test completed successfully!');
    console.log(`\n📝 This is the EXACT flow the proxy uses:`);
    console.log(`   1. Client Credentials → ${OAUTH_HOST}/as/token.oauth2`);
    console.log(`   2. Token Exchange → ${OAUTH_HOST}/as/token.oauth2`);
    console.log(`   3. API Call → ${API_BASE_URL}/al-pe/v2/companies/${EYEFINITY_COMPANY_ID}/offices`);
    
  } catch (error) {
    console.error('\n❌ Test failed:', error.message);
    process.exit(1);
  }
}

runTest();
