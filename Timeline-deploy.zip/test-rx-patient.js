#!/usr/bin/env node

/**
 * Test RX API with patient that should have RX data
 */

const testPatientId = '34f9334e-2dcd-4190-9190-e87709fad676'; // Should have RX data

console.log('🧪 TESTING RX API WITH PATIENT THAT SHOULD HAVE DATA\n');
console.log(`Patient ID: ${testPatientId}\n`);

const endpoints = [
  {
    name: 'Patient Details',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testPatientId}`,
    description: 'Basic patient information - should return patient data',
    expectedStatus: 200
  },
  {
    name: 'Patient RX (FIXED)',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testPatientId}/rx?page=1&pageSize=100`,
    description: 'Patient prescriptions - SHOULD HAVE RX DATA',
    expectedStatus: 200
  },
  {
    name: 'Patient Orders (FIXED)', 
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2orders?patientId=${testPatientId}&fromStatusChangedDate=2020-01-01&toStatusChangedDate=2026-01-27&page=1&pageSize=100`,
    description: 'Patient orders using fixed v2orders endpoint',
    expectedStatus: 200
  },
  {
    name: 'Communication Methods',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testPatientId}/communicationmethods`,
    description: 'Patient communication preferences and methods',
    expectedStatus: 200
  }
];

const testEndpoint = async (endpoint) => {
  try {
    console.log(`\n🔍 ${endpoint.name}:`);
    console.log(`   Description: ${endpoint.description}`);
    console.log(`   URL: ${endpoint.url}`);
    
    const startTime = Date.now();
    const response = await fetch(endpoint.url);
    const duration = Date.now() - startTime;
    
    console.log(`   Status: ${response.status} (${duration}ms)`);
    console.log(`   Expected: ${endpoint.expectedStatus}`);
    
    if (response.status === endpoint.expectedStatus) {
      try {
        const data = await response.json();
        
        if (endpoint.name.includes('RX')) {
          const itemCount = data.items?.length || 0;
          console.log(`   ✅ SUCCESS - RX Items: ${itemCount}`);
          if (data.items && data.items.length > 0) {
            console.log(`   🎯 RX FOUND! Sample keys: ${Object.keys(data.items[0]).slice(0, 8).join(', ')}`);
            // Show first RX item details if available
            const firstRx = data.items[0];
            if (firstRx.RxNumber) console.log(`   RX Number: ${firstRx.RxNumber}`);
            if (firstRx.DatePrescribed) console.log(`   Date Prescribed: ${firstRx.DatePrescribed}`);
            if (firstRx.Product) console.log(`   Product: ${firstRx.Product}`);
          }
        } else if (endpoint.name.includes('Orders')) {
          const itemCount = data.items?.length || 0;
          console.log(`   ✅ SUCCESS - Order Items: ${itemCount}`);
          if (data.items && data.items.length > 0) {
            console.log(`   Sample Order keys: ${Object.keys(data.items[0]).slice(0, 6).join(', ')}`);
          }
        } else if (endpoint.name.includes('Communication')) {
          console.log(`   ✅ SUCCESS - Communication Methods`);
          if (data.Methods) {
            console.log(`   Communication Methods: ${data.Methods.length} found`);
            console.log(`   Primary Phone: ${data.PrimaryPhone || 'N/A'}`);
            console.log(`   Email: ${data.Email || 'N/A'}`);
          }
        } else if (endpoint.name.includes('Details')) {
          const patient = data.items?.[0] || data;
          console.log(`   ✅ SUCCESS - Patient: ${patient.FirstName || 'N/A'} ${patient.LastName || 'N/A'}`);
          console.log(`   Legacy ID: ${patient.PatientLegacyId || 'N/A'}`);
        }
        
        return { status: 'SUCCESS', data, itemCount: data.items?.length || 0, duration };
      } catch (e) {
        console.log(`   ✅ SUCCESS - Response received`);
        return { status: 'SUCCESS', duration };
      }
    } else if (response.status === 404) {
      console.log(`   ❌ NOT FOUND - Endpoint may not exist for this patient`);
      return { status: 'NOT_FOUND', duration };
    } else if (response.status === 400) {
      const text = await response.text();
      console.log(`   ⚠️  BAD REQUEST - Parameter issue`);
      console.log(`   Response: ${text.substring(0, 100)}`);
      return { status: 'BAD_REQUEST', duration, error: text };
    } else if (response.status === 401) {
      console.log(`   🔐 UNAUTHORIZED - Authentication issue`);
      return { status: 'UNAUTHORIZED', duration };
    } else {
      console.log(`   ⚠️  ERROR ${response.status}`);
      const text = await response.text();
      console.log(`   Response: ${text.substring(0, 100)}`);
      return { status: `ERROR_${response.status}`, duration, error: text };
    }
    
  } catch (error) {
    console.log(`   ❌ FETCH ERROR: ${error.message}`);
    return { status: 'FETCH_ERROR', error: error.message };
  }
};

const runTests = async () => {
  console.log('🔧 TESTING PATIENT WITH RX DATA:');
  console.log('═════════════════════════════════════════');
  
  const results = {};
  
  for (const endpoint of endpoints) {
    results[endpoint.name] = await testEndpoint(endpoint);
  }
  
  console.log('\n📊 COMPREHENSIVE TEST RESULTS:');
  console.log('═════════════════════════════════════════');
  
  const categories = {
    working: [],
    broken: [],
    missing: []
  };
  
  Object.entries(results).forEach(([name, result]) => {
    if (result.status === 'SUCCESS') {
      categories.working.push({ name, itemCount: result.itemCount });
      console.log(`✅ ${name}: ${result.status} (${result.itemCount || 'N/A'} items)`);
    } else if (result.status === 'NOT_FOUND') {
      categories.missing.push(name);
      console.log(`❌ ${name}: ${result.status}`);
    } else {
      categories.broken.push(name);
      console.log(`⚠️  ${name}: ${result.status}`);
    }
  });
  
  console.log('\n🎯 KEY FINDINGS:');
  console.log('═══════════════');
  
  const rxResult = results['Patient RX (FIXED)'];
  if (rxResult?.status === 'SUCCESS' && rxResult.itemCount > 0) {
    console.log('🎉 RX API CONFIRMED WORKING - Patient has RX data!');
    console.log('   Previous patient likely had no RX data (404 was correct)');
  } else if (rxResult?.status === 'NOT_FOUND') {
    console.log('❌ RX API still returns 404 - endpoint structure may be wrong');
  }
  
  const ordersResult = results['Patient Orders (FIXED)'];
  if (ordersResult?.status === 'SUCCESS') {
    console.log('✅ Orders API working correctly');
  }
  
  console.log(`\n📈 Final Success Rate: ${categories.working.length}/${endpoints.length} (${Math.round(categories.working.length/endpoints.length*100)}%)`);
  
  if (categories.working.length === endpoints.length) {
    console.log('\n🎉 ALL APIS WORKING! Patient Readiness Center should load all data.');
  }
};

runTests().catch(console.error);
