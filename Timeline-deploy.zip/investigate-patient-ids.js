#!/usr/bin/env node

/**
 * Investigate patient ID fields and test RX endpoints with different ID formats
 */

console.log('🔍 INVESTIGATING PATIENT ID FIELDS FOR RX API');
console.log('════════════════════════════════════════════════════════════════════════');

const testPatients = [
  'ecab1a6c-5aba-457a-870a-2743822de084',
  '34f9334e-2dcd-4190-9190-e87709fad676',
  // Add more patient GUIDs to test
];

const analyzePatientData = async (guid) => {
  try {
    console.log(`\n🔍 Analyzing Patient: ${guid}`);
    console.log('─'.repeat(80));
    
    const response = await fetch(`https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${guid}`);
    
    if (response.ok) {
      const data = await response.json();
      const patient = data.items?.[0] || data;
      
      console.log(`\n📋 ALL PATIENT ID FIELDS:`);
      console.log('─'.repeat(50));
      
      // Show all ID-related fields
      const idFields = Object.keys(patient).filter(key => 
        key.toLowerCase().includes('id') || 
        key.toLowerCase().includes('num') ||
        key.toLowerCase().includes('number') ||
        key.toLowerCase().includes('legacy')
      );
      
      idFields.forEach(field => {
        console.log(`   ${field.padEnd(25, '.')}: ${patient[field] || 'null'}`);
      });
      
      console.log(`\n📊 PATIENT SUMMARY:`);
      console.log(`   Name: ${patient.FirstName || 'N/A'} ${patient.LastName || 'N/A'}`);
      console.log(`   Active: ${!patient.InActive}`);
      console.log(`   Has Data: ${!!(patient.FirstName || patient.LastName || patient.Email)}`);
      
      return {
        guid,
        patientLegacyId: patient.PatientLegacyId,
        patientId: patient.PatientId,
        medicalRecordNum: patient.MedicalRecordNum,
        emrPatientNum: patient.EMRPatientNum,
        hasData: !!(patient.FirstName || patient.LastName || patient.Email),
        allIds: idFields.reduce((acc, field) => {
          acc[field] = patient[field];
          return acc;
        }, {})
      };
    } else {
      console.log(`   ❌ Failed to get patient: ${response.status}`);
      return null;
    }
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
    return null;
  }
};

const testRxWithDifferentIds = async (patientData) => {
  const { guid, allIds } = patientData;
  
  console.log(`\n🧪 Testing RX Endpoints with Different ID Formats for ${guid}:`);
  console.log('─'.repeat(80));
  
  const idTestCases = [];
  
  // Collect all non-null ID values to test
  Object.entries(allIds).forEach(([field, value]) => {
    if (value && value !== 'null' && value !== '') {
      idTestCases.push({ field, value, type: 'v1' });
      idTestCases.push({ field, value, type: 'v2' });
    }
  });
  
  // Always test with GUID
  idTestCases.push({ field: 'GUID', value: guid, type: 'v1' });
  idTestCases.push({ field: 'GUID', value: guid, type: 'v2' });
  
  const results = [];
  
  for (const testCase of idTestCases) {
    const { field, value, type } = testCase;
    
    let endpoint;
    if (type === 'v1') {
      endpoint = `/api/eyefinity/patients/${value}/rx`;
    } else {
      endpoint = `/api/eyefinity/v2patients/${value}/rx`;
    }
    
    try {
      console.log(`\n   Testing ${type.toUpperCase()} with ${field}: ${value}`);
      console.log(`   Endpoint: ${endpoint}`);
      
      const url = `https://patientcare-teal.vercel.app${endpoint}?page=1&pageSize=10`;
      const response = await fetch(url);
      
      console.log(`   Status: ${response.status} ${response.statusText}`);
      
      if (response.ok) {
        const data = await response.json();
        const rxCount = data.items?.length || 0;
        
        console.log(`   🎉 SUCCESS! Found ${rxCount} RX items`);
        
        if (rxCount > 0) {
          const firstRx = data.items[0];
          console.log(`   Sample RX: ${firstRx.RxNumber || 'N/A'} - ${firstRx.DatePrescribed || 'N/A'}`);
        }
        
        results.push({
          success: true,
          endpoint,
          field,
          value,
          type,
          rxCount,
          status: response.status
        });
      } else {
        results.push({
          success: false,
          endpoint,
          field,
          value,
          type,
          status: response.status
        });
      }
    } catch (error) {
      console.log(`   ❌ Error: ${error.message}`);
      results.push({
        success: false,
        endpoint,
        field,
        value,
        type,
        error: error.message
      });
    }
  }
  
  return results;
};

const searchForPatientsWithData = async () => {
  console.log('\n🔍 Phase 1: Analyzing Patient Data Structures');
  console.log('═'.repeat(80));
  
  const patientAnalyses = [];
  
  for (const guid of testPatients) {
    const analysis = await analyzePatientData(guid);
    if (analysis) {
      patientAnalyses.push(analysis);
    }
  }
  
  console.log('\n🧪 Phase 2: Testing RX Endpoints with All Available IDs');
  console.log('═'.repeat(80));
  
  const allResults = [];
  
  for (const patient of patientAnalyses) {
    const results = await testRxWithDifferentIds(patient);
    allResults.push(...results);
  }
  
  console.log('\n🎯 Phase 3: Summary of All Tests');
  console.log('═'.repeat(80));
  
  const successfulTests = allResults.filter(r => r.success);
  const testsWithData = allResults.filter(r => r.success && r.rxCount > 0);
  
  console.log(`\n📊 OVERALL RESULTS:`);
  console.log(`   Total Tests: ${allResults.length}`);
  console.log(`   Successful (200): ${successfulTests.length}`);
  console.log(`   With RX Data: ${testsWithData.length}`);
  
  if (successfulTests.length > 0) {
    console.log(`\n✅ WORKING ENDPOINTS:`);
    successfulTests.forEach(r => {
      console.log(`   ${r.type.toUpperCase()}: ${r.endpoint} (${r.field}: ${r.value}) - ${r.rxCount || 0} items`);
    });
  }
  
  if (testsWithData.length > 0) {
    console.log(`\n🎉 ENDPOINTS WITH RX DATA:`);
    testsWithData.forEach(r => {
      console.log(`   🏆 ${r.endpoint} (${r.field}: ${r.value}) - ${r.rxCount} prescriptions`);
    });
    
    console.log(`\n💡 RECOMMENDATION:`);
    const workingEndpoint = testsWithData[0];
    console.log(`   Use ${workingEndpoint.type.toUpperCase()} endpoint: ${workingEndpoint.endpoint}`);
    console.log(`   ID Field: ${workingEndpoint.field}`);
    console.log(`   This endpoint successfully returns RX data!`);
  } else {
    console.log(`\n❌ NO RX DATA FOUND:`);
    console.log(`   - All endpoints returned 404 or empty results`);
    console.log(`   - RX endpoints may not be available in current API`);
    console.log(`   - May need different patient IDs or API version`);
  }
  
  // Test specific legacy ID from user's example
  console.log('\n🔬 Phase 4: Testing User\'s Specific Legacy ID');
  console.log('═'.repeat(80));
  
  const userLegacyId = '1080416';
  console.log(`\nTesting Legacy ID from user example: ${userLegacyId}`);
  
  const endpoints = [
    `/api/eyefinity/patients/${userLegacyId}/rx`,
    `/api/eyefinity/v2patients/${userLegacyId}/rx`
  ];
  
  for (const endpoint of endpoints) {
    try {
      const url = `https://patientcare-teal.vercel.app${endpoint}?page=1&pageSize=500`;
      console.log(`\n   Testing: ${endpoint}`);
      console.log(`   URL: ${url}`);
      
      const response = await fetch(url);
      console.log(`   Status: ${response.status} ${response.statusText}`);
      
      if (response.ok) {
        const data = await response.json();
        const rxCount = data.items?.length || 0;
        console.log(`   🎉 SUCCESS! Found ${rxCount} RX items`);
        
        if (rxCount > 0) {
          console.log(`   This confirms the RX endpoint structure works!`);
        }
      }
    } catch (error) {
      console.log(`   ❌ Error: ${error.message}`);
    }
  }
};

searchForPatientsWithData().catch(console.error);
