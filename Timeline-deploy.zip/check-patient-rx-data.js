#!/usr/bin/env node

/**
 * Check if RX data is included in patient details response
 * or find alternative RX endpoints
 */

const testPatientId = 'ecab1a6c-5aba-457a-870a-2743822de084';

const checkPatientDetails = async () => {
  try {
    console.log('🔍 CHECKING PATIENT DETAILS FOR RX DATA:');
    console.log('═══════════════════════════════════════════');
    
    const response = await fetch(`https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testPatientId}`);
    
    if (response.status === 200) {
      const data = await response.json();
      console.log('✅ Patient details retrieved successfully');
      
      // Check if patient data contains RX information
      const patientData = data.items?.[0] || data;
      
      console.log('\n📋 PATIENT DATA STRUCTURE:');
      console.log('Keys:', Object.keys(patientData));
      
      // Look for RX-related fields
      const rxFields = Object.keys(patientData).filter(key => 
        key.toLowerCase().includes('rx') || 
        key.toLowerCase().includes('prescription') ||
        key.toLowerCase().includes('glasses') ||
        key.toLowerCase().includes('contact')
      );
      
      if (rxFields.length > 0) {
        console.log('\n🎯 FOUND RX-RELATED FIELDS:');
        rxFields.forEach(field => {
          console.log(`   - ${field}: ${typeof patientData[field]}`);
          if (Array.isArray(patientData[field])) {
            console.log(`     Array length: ${patientData[field].length}`);
          }
        });
      } else {
        console.log('\n❌ NO RX-RELATED FIELDS FOUND IN PATIENT DETAILS');
      }
      
      // Check for nested objects that might contain RX data
      const nestedObjects = Object.keys(patientData).filter(key => 
        typeof patientData[key] === 'object' && patientData[key] !== null
      );
      
      if (nestedObjects.length > 0) {
        console.log('\n🔍 CHECKING NESTED OBJECTS:');
        nestedObjects.forEach(key => {
          const obj = patientData[key];
          if (Array.isArray(obj)) {
            console.log(`   - ${key}: Array with ${obj.length} items`);
            if (obj.length > 0) {
              console.log(`     Sample item keys: ${Object.keys(obj[0]).join(', ')}`);
            }
          } else {
            console.log(`   - ${key}: Object with keys: ${Object.keys(obj).join(', ')}`);
          }
        });
      }
      
    } else {
      console.log(`❌ Failed to get patient details: ${response.status}`);
    }
    
  } catch (error) {
    console.log(`❌ Error checking patient details: ${error.message}`);
  }
};

// Test alternative RX endpoints based on Swagger docs
const testAlternativeRxEndpoints = async () => {
  console.log('\n🧪 TESTING ALTERNATIVE RX ENDPOINTS:');
  console.log('════════════════════════════════════════');
  
  const endpoints = [
    {
      name: 'V2Patients RX (from Swagger)',
      url: `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testPatientId}/rx?page=1&pageSize=100`
    },
    {
      name: 'V1 Patients RX (from Swagger)', 
      url: `https://patientcare-teal.vercel.app/api/eyefinity/patients/${testPatientId}/rx?page=1&pageSize=100`
    },
    {
      name: 'RX search by patient',
      url: `https://patientcare-teal.vercel.app/api/eyefinity/rx?patientId=${testPatientId}&page=1&pageSize=100`
    },
    {
      name: 'V2 RX search',
      url: `https://patientcare-teal.vercel.app/api/eyefinity/v2rx?patientId=${testPatientId}&page=1&pageSize=100`
    }
  ];
  
  for (const endpoint of endpoints) {
    try {
      console.log(`\n🧪 ${endpoint.name}:`);
      const response = await fetch(endpoint.url);
      console.log(`   Status: ${response.status}`);
      
      if (response.status === 200) {
        const data = await response.json();
        const itemCount = data.items?.length || (Array.isArray(data) ? data.length : 'N/A');
        console.log(`   ✅ SUCCESS - Items: ${itemCount}`);
        if (data.items && data.items.length > 0) {
          console.log(`   Sample RX keys: ${Object.keys(data.items[0]).slice(0, 8).join(', ')}`);
        }
      } else if (response.status === 404) {
        console.log(`   ❌ NOT FOUND`);
      } else {
        console.log(`   ⚠️  Error: ${response.status}`);
      }
    } catch (error) {
      console.log(`   ❌ Error: ${error.message}`);
    }
  }
};

const runInvestigation = async () => {
  await checkPatientDetails();
  await testAlternativeRxEndpoints();
  
  console.log('\n💡 CONCLUSION:');
  console.log('═════════════');
  console.log('1. Check if RX data is embedded in patient details');
  console.log('2. If not, determine which RX endpoint works');
  console.log('3. Update EyefinityService accordingly');
  console.log('4. Test the complete fix');
};

runInvestigation().catch(console.error);
