/**
 * Local Eyefinity Proxy Server with OAuth 2.0 Token Exchange
 * 
 * Implements the 2-step OAuth flow:
 * 1. Client Credentials -> Get initial token
 * 2. Token Exchange -> Get EPM token with tenant context
 * 
 * Features:
 * - Dynamic settings from admin UI (via config file)
 * - Automatic 401 detection and token refresh
 * - Falls back to environment variables if no config
 * 
 * Usage:
 *   node server.js
 *   ngrok http 3099
 */

import http from 'http';
import https from 'https';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3099;
const CONFIG_FILE = path.join(__dirname, 'oauth-config.json');

// Dynamic config loader - checks file first, then env vars
function loadConfig() {
  // Try to load from config file (set by admin UI)
  if (fs.existsSync(CONFIG_FILE)) {
    try {
      const fileConfig = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
      console.log('[Config] Loaded from oauth-config.json');
      // Check for static token in config or env
      const staticToken = fileConfig.staticBearerToken || 
                          process.env.EYEFINITY_STATIC_TOKEN || 
                          process.env.NEXT_PUBLIC_EYEFINITY_TOKEN || '';
      
      return {
        oauthHost: fileConfig.oauthHost || fileConfig.host,
        clientId: fileConfig.clientId,
        clientSecret: fileConfig.clientSecret,
        tenantUid: fileConfig.tenantUid,
        apiBaseUrl: fileConfig.apiBaseUrl,
        enabled: fileConfig.enabled !== false,
        // Static bearer token for local dev (bypasses OAuth)
        staticBearerToken: staticToken,
        useStaticToken: fileConfig.useStaticToken || !!staticToken,
      };
    } catch (e) {
      console.warn('[Config] Failed to parse config file:', e.message);
    }
  }
  
  // Fall back to environment variables
  console.log('[Config] Using environment variables');
  
  // Check for static token (multiple possible env var names)
  const staticToken = process.env.EYEFINITY_STATIC_TOKEN || 
                      process.env.NEXT_PUBLIC_EYEFINITY_TOKEN || 
                      process.env.VITE_EYEFINITY_TOKEN || '';
  
  return {
    oauthHost: process.env.OAUTH_HOST || 'login-uswest2.staging.eyefinity.com',
    clientId: process.env.EPM_CLIENT_ID || '',
    clientSecret: process.env.EPM_CLIENT_SECRET || '',
    tenantUid: process.env.TENANT_UID || '',
    apiBaseUrl: process.env.EYEFINITY_API_BASE || 'https://api-integration.eyefinity.com',
    enabled: !!(process.env.EPM_CLIENT_ID && process.env.EPM_CLIENT_SECRET),
    // Static bearer token for local dev (bypasses OAuth)
    staticBearerToken: staticToken,
    useStaticToken: process.env.USE_STATIC_TOKEN === 'true' || !!staticToken,
  };
}

// Get current config (reloads each time to pick up changes)
function getConfig() {
  return loadConfig();
}

// Token cache
let cachedToken = null;
let tokenExpiry = null;

// Full scopes for EPM API access
const EPM_SCOPES = [
  'auth_epm',
  'ef.pm_pe_patient_rx',
  'ef.pm_pe_resource',
  'ef.pm_pe_insurance',
  'ef.pm_pe_appointment',
  'ef.pm_pe_office_recallreport',
  'ef.pm_pe_staff',
  'ef.pm_pe_office',
  'ef.pm_pe_company',
  'ef.pm_pe_order',
  'ef.pm_pe_provider',
  'ef.pm_pe_patient',
].join(' ');

/**
 * Step 1: Get Client Credentials Token
 */
async function getClientCredentialsToken() {
  const config = getConfig();
  
  return new Promise((resolve, reject) => {
    const credentials = Buffer.from(`${config.clientId}:${config.clientSecret}`).toString('base64');
    
    const postData = `grant_type=client_credentials&scope=${encodeURIComponent(EPM_SCOPES)}`;
    
    const options = {
      hostname: config.oauthHost,
      port: 443,
      path: '/as/token.oauth2',
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData),
      },
    };

    console.log('[OAuth] Step 1: Getting client credentials token from', config.oauthHost);
    
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (json.accesstoken || json.access_token) {
            console.log('[OAuth] Step 1: Success - Got client credentials token');
            resolve(json.accesstoken || json.access_token);
          } else {
            console.error('[OAuth] Step 1: Failed -', data);
            reject(new Error(`Client credentials failed: ${data}`));
          }
        } catch (e) {
          reject(new Error(`Parse error: ${e.message}`));
        }
      });
    });

    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

/**
 * Step 2: Token Exchange - Exchange CC token for EPM token
 */
async function exchangeToken(ccToken) {
  const config = getConfig();
  
  return new Promise((resolve, reject) => {
    const credentials = Buffer.from(`${config.clientId}:${config.clientSecret}`).toString('base64');
    
    const postData = new URLSearchParams({
      'grant_type': 'urn:ietf:params:oauth:grant-type:token-exchange',
      'subject_token': ccToken,
      'subject_token_type': 'urn:ietf:params:oauth:token-type:access_token',
      'scope': EPM_SCOPES,
      'resource': 'https://VspEpmToken',
    }).toString();
    
    const options = {
      hostname: config.oauthHost,
      port: 443,
      path: '/as/token.oauth2',
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData),
        'tenantuid': config.tenantUid,
      },
    };

    console.log('[OAuth] Step 2: Exchanging token for EPM access...');
    
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (json.access_token || json.accesstoken) {
            console.log('[OAuth] Step 2: Success - Got EPM token');
            resolve({
              token: json.access_token || json.accesstoken,
              expiresIn: json.expires_in || 3600,
            });
          } else {
            console.error('[OAuth] Step 2: Failed -', data);
            reject(new Error(`Token exchange failed: ${data}`));
          }
        } catch (e) {
          reject(new Error(`Parse error: ${e.message}`));
        }
      });
    });

    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

/**
 * Get valid EPM token (with caching)
 */
async function getEpmToken() {
  // Check if we have a valid cached token
  if (cachedToken && tokenExpiry && Date.now() < tokenExpiry) {
    console.log('[OAuth] Using cached token');
    return cachedToken;
  }

  // Step 1: Get client credentials token
  const ccToken = await getClientCredentialsToken();
  
  // Step 2: Exchange for EPM token
  const { token, expiresIn } = await exchangeToken(ccToken);
  
  // Cache the token (with 5 minute buffer)
  cachedToken = token;
  tokenExpiry = Date.now() + (expiresIn - 300) * 1000;
  
  return token;
}

/**
 * Invalidate cached token (called on 401)
 */
function invalidateToken() {
  console.log('[OAuth] Invalidating cached token');
  cachedToken = null;
  tokenExpiry = null;
}

/**
 * Save config from admin UI
 */
function saveConfig(configData) {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(configData, null, 2));
    console.log('[Config] Saved to oauth-config.json');
    // Invalidate token since config changed
    invalidateToken();
    return true;
  } catch (e) {
    console.error('[Config] Failed to save:', e.message);
    return false;
  }
}

const server = http.createServer(async (req, res) => {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Auth-Token, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    return res.end();
  }

  // Config management endpoints
  if (req.url === '/proxy/config' && req.method === 'GET') {
    const config = getConfig();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({
      enabled: config.enabled,
      oauthHost: config.oauthHost,
      apiBaseUrl: config.apiBaseUrl,
      hasCredentials: !!(config.clientId && config.clientSecret),
      hasTenant: !!config.tenantUid,
    }));
  }

  if (req.url === '/proxy/config' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const configData = JSON.parse(body);
        const success = saveConfig(configData);
        res.writeHead(success ? 200 : 500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success, message: success ? 'Config saved' : 'Failed to save config' }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: e.message }));
      }
    });
    return;
  }

  if (req.url === '/proxy/token/invalidate' && req.method === 'POST') {
    invalidateToken();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success: true, message: 'Token invalidated' }));
  }

  // Get current config
  const config = getConfig();

  // Check for static bearer token mode (local dev with VPN)
  // This bypasses OAuth entirely and uses the token from header or config
  if (config.useStaticToken || config.staticBearerToken) {
    const authToken = config.staticBearerToken || 
                      req.headers['x-auth-token'] || 
                      req.headers['authorization']?.replace('Bearer ', '');
    if (authToken) {
      console.log('[Proxy] Using static bearer token (bypassing OAuth)');
      return proxyRequest(req, res, authToken, false);
    }
  }

  // Check for token passed in header (pass-through mode)
  const headerToken = req.headers['x-auth-token'] || req.headers['authorization']?.replace('Bearer ', '');
  if (headerToken && !config.clientId) {
    console.log('[Proxy] Using header token (pass-through mode)');
    return proxyRequest(req, res, headerToken, false);
  }

  // Check if OAuth is configured
  if (!config.clientId || !config.clientSecret || !config.tenantUid) {
    res.writeHead(401, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ 
      error: 'No authentication configured',
      hint: 'Set USE_STATIC_TOKEN=true and EYEFINITY_STATIC_TOKEN in .env for local dev, or configure OAuth credentials',
    }));
  }

  try {
    // Get EPM token via OAuth flow
    const epmToken = await getEpmToken();
    return proxyRequest(req, res, epmToken, true);
  } catch (err) {
    console.error('[OAuth] Error:', err.message);
    res.writeHead(500, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ error: 'OAuth failed', details: err.message }));
  }
});

function proxyRequest(req, res, authToken, canRetryOnAuth = false) {
  const config = getConfig();
  
  // Build target URL
  const targetPath = req.url.replace(/^\/api\/eyefinity/, '/al-pe');
  const targetUrl = `${config.apiBaseUrl}${targetPath}`;

  console.log(`[Proxy] ${req.method} ${req.url} -> ${targetUrl}`);

  // Collect request body
  let body = '';
  req.on('data', chunk => body += chunk);
  req.on('end', () => {
    makeProxyRequest(targetUrl, req.method, body, authToken, res, canRetryOnAuth);
  });
}

async function makeProxyRequest(targetUrl, method, body, authToken, res, canRetry) {
  const url = new URL(targetUrl);
  const options = {
    hostname: url.hostname,
    port: 443,
    path: url.pathname + url.search,
    method: method,
    headers: {
      'Authorization': `Bearer ${authToken}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
  };

  const proxyReq = https.request(options, async (proxyRes) => {
    console.log(`[Proxy] Response: ${proxyRes.statusCode}`);
    
    // Handle 401 - token expired, try to refresh
    if (proxyRes.statusCode === 401 && canRetry) {
      console.log('[Proxy] Got 401 - attempting token refresh...');
      
      // Consume the error response
      proxyRes.resume();
      
      // Invalidate and get new token
      invalidateToken();
      
      try {
        const newToken = await getEpmToken();
        console.log('[Proxy] Token refreshed, retrying request...');
        // Retry with new token (but don't retry again)
        makeProxyRequest(targetUrl, method, body, newToken, res, false);
        return;
      } catch (err) {
        console.error('[Proxy] Token refresh failed:', err.message);
        res.writeHead(401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Authentication failed', details: err.message }));
        return;
      }
    }
    
    res.writeHead(proxyRes.statusCode, {
      'Content-Type': proxyRes.headers['content-type'] || 'application/json',
      'Access-Control-Allow-Origin': '*',
    });

    proxyRes.pipe(res);
  });

  proxyReq.on('error', (err) => {
    console.error('[Proxy] Error:', err.message);
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: err.message }));
  });

  if (body && method !== 'GET') {
    proxyReq.write(body);
  }
  proxyReq.end();
}

server.listen(PORT, () => {
  const config = getConfig();
  const oauthConfigured = config.clientId && config.clientSecret && config.tenantUid;
  const staticTokenMode = config.useStaticToken || !!config.staticBearerToken;
  
  console.log(`
╔════════════════════════════════════════════════════════════════╗
║  Eyefinity Proxy Server                                        ║
║  Port: ${PORT}                                                    ║
║                                                                ║
║  Mode: ${staticTokenMode ? '🔑 STATIC TOKEN (VPN/Local Dev)' : (oauthConfigured ? '🔐 OAuth 2.0' : '⚠️  Not configured')}${staticTokenMode ? '          ' : (oauthConfigured ? '                      ' : '                   ')}║
║  API Base: ${config.apiBaseUrl.padEnd(42)}║
${staticTokenMode ? `║  Token: ${config.staticBearerToken ? '✓ Set (' + config.staticBearerToken.length + ' chars)' : '✗ Missing - set EYEFINITY_STATIC_TOKEN'}${config.staticBearerToken ? '                          ' : '   '}║` : `║  OAuth Host: ${config.oauthHost.padEnd(40)}║`}
║                                                                ║
║  Config Source: ${fs.existsSync(CONFIG_FILE) ? 'oauth-config.json' : 'environment variables'}                          ║
║                                                                ║
║  For local dev with VPN, set in .env:                          ║
║    USE_STATIC_TOKEN=true                                       ║
║    EYEFINITY_STATIC_TOKEN=your_bearer_token                    ║
╚════════════════════════════════════════════════════════════════╝
  `);
});
