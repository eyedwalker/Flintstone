/**
 * Test Eyefinity API calls directly (no proxy)
 * Tests the same calls PRC makes
 */

import https from 'https';

const CONFIG = {
  oauthHost: 'api-sandbox.eyefinity.com',
  apiBaseUrl: 'https://api-sandbox.eyefinity.com',
  clientId: 'ef-productmgmt-test-client',
  clientSecret: 'VD24uag29VepKKeG1zuSMXKuXg6Q9bXEvCM3csm9cb3sX84GCLh7P20UUdFucToB',
  tenantUid: '12345678-1234-1234-1234-123456789012',
};

const EPM_SCOPES = [
  'auth_epm',
  'ef.pm_pe_patient_rx',
  'ef.pm_pe_resource',
  'ef.pm_pe_insurance',
  'ef.pm_pe_appointment',
  'ef.pm_pe_office',
  'ef.pm_pe_patient',
].join(' ');

function httpsRequest(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        resolve({ status: res.statusCode, headers: res.headers, body: data });
      });
    });
    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

async function getClientCredentialsToken() {
  console.log('\n1️⃣  Step 1: Client Credentials');
  console.log(`   POST https://${CONFIG.oauthHost}/as/token.oauth2`);
  
  const postData = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: CONFIG.clientId,
    client_secret: CONFIG.clientSecret,
    scope: EPM_SCOPES,
  }).toString();

  const response = await httpsRequest({
    hostname: CONFIG.oauthHost,
    port: 443,
    path: '/as/token.oauth2',
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(postData),
    },
  }, postData);

  const json = JSON.parse(response.body);
  if (json.access_token) {
    console.log(`   ✅ Got CC token (${json.access_token.length} chars)`);
    return json.access_token;
  } else {
    console.log(`   ❌ Failed:`, json);
    throw new Error(json.error_description || json.error);
  }
}

async function exchangeToken(ccToken) {
  console.log('\n2️⃣  Step 2: Token Exchange');
  console.log(`   POST https://${CONFIG.oauthHost}/as/token.oauth2`);
  
  // Match the Vercel proxy's approach
  const postData = new URLSearchParams({
    grant_type: 'urn:ietf:params:oauth:grant-type:token-exchange',
    client_id: CONFIG.clientId,
    client_secret: CONFIG.clientSecret,
    subject_token: ccToken,
    subject_token_type: 'urn:ietf:params:oauth:token-type:access_token',
    scope: EPM_SCOPES,
    resource: 'https://VspEpmToken',
  }).toString();

  const response = await httpsRequest({
    hostname: CONFIG.oauthHost,
    port: 443,
    path: '/as/token.oauth2',
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(postData),
      'tenantuid': CONFIG.tenantUid,
    },
  }, postData);

  const json = JSON.parse(response.body);
  if (json.access_token) {
    console.log(`   ✅ Got EPM token (${json.access_token.length} chars)`);
    return json.access_token;
  } else {
    console.log(`   ❌ Failed:`, json);
    throw new Error(json.error_description || json.error);
  }
}

async function testApiCall(token, endpoint, description) {
  console.log(`\n📡 ${description}`);
  console.log(`   GET ${CONFIG.apiBaseUrl}/al-pe/${endpoint}`);
  
  const url = new URL(`${CONFIG.apiBaseUrl}/al-pe/${endpoint}`);
  
  const response = await httpsRequest({
    hostname: url.hostname,
    port: 443,
    path: url.pathname + url.search,
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Accept': 'application/json',
    },
  });

  console.log(`   Status: ${response.status}`);
  
  try {
    const json = JSON.parse(response.body);
    if (Array.isArray(json)) {
      console.log(`   ✅ Got array with ${json.length} items`);
      if (json.length > 0) {
        console.log(`   Sample:`, JSON.stringify(json[0], null, 2).substring(0, 200) + '...');
      }
    } else if (json.data) {
      console.log(`   ✅ Got paginated response with ${json.data?.length || 0} items`);
    } else if (response.body.includes('<!DOCTYPE')) {
      console.log(`   ❌ Got HTML instead of JSON (wrong endpoint or auth issue)`);
    } else {
      console.log(`   Response:`, JSON.stringify(json, null, 2).substring(0, 300));
    }
    return json;
  } catch (e) {
    if (response.body.includes('<!DOCTYPE')) {
      console.log(`   ❌ Got HTML page instead of JSON`);
      console.log(`   First 200 chars:`, response.body.substring(0, 200));
    } else {
      console.log(`   Raw response:`, response.body.substring(0, 300));
    }
    return null;
  }
}

async function main() {
  console.log('='.repeat(60));
  console.log('Testing Eyefinity API calls (same as PRC uses)');
  console.log('='.repeat(60));
  console.log(`Target: ${CONFIG.apiBaseUrl}`);

  try {
    // Get OAuth token
    const ccToken = await getClientCredentialsToken();
    const epmToken = await exchangeToken(ccToken);
    
    console.log('\n' + '='.repeat(60));
    console.log('Testing API Endpoints');
    console.log('='.repeat(60));

    // Test v2offices (what PRC calls first)
    await testApiCall(epmToken, 'v2offices?page=1&pageSize=100', 'GET v2offices (office list)');
    
    // Test appointments (what PRC calls after selecting office)
    const today = new Date().toISOString().split('T')[0];
    const future = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    await testApiCall(epmToken, `appointments?fromDate=${today}&toDate=${future}&page=1&pageSize=100`, 'GET appointments');

  } catch (error) {
    console.error('\n❌ Error:', error.message);
  }
}

main();
