/**
 * OAuth Environment Tester
 * Tests SINGLE OAuth attempt against each environment
 * Run: node test-oauth.js [sandbox|staging]
 */

import https from 'https';

// Environment configurations
const ENVIRONMENTS = {
  sandbox: {
    name: 'Sandbox',
    oauthHost: 'api-sandbox.eyefinity.com',
    apiBaseUrl: 'https://api-sandbox.eyefinity.com',
    // From local .env
    clientId: 'ef-productmgmt-test-client',
    clientSecret: 'VD24uag29VepKKeG1zuSMXKuXg6Q9bXEvCM3csm9cb3sX84GCLh7P20UUdFucToB',
    tenantUid: '12345678-1234-1234-1234-123456789012',
  },
  staging: {
    name: 'Staging',
    oauthHost: 'api-staging.eyefinity.com',
    apiBaseUrl: 'https://api-staging.eyefinity.com',
    // From Vercel (user's current settings)
    clientId: 'ef-productmgmt-test-client',
    clientSecret: 'eWHwDWLwK1igPrN8Al03DNICT2smhBbILvy8VkujNnv1UfChCcD9qQAb8RfRIym5',
    tenantUid: '12345678-1234-1234-1234-123456789012',
  },
};

const EPM_SCOPES = [
  'auth_epm',
  'ef.pm_pe_patient_rx',
  'ef.pm_pe_resource',
  'ef.pm_pe_insurance',
  'ef.pm_pe_appointment',
  'ef.pm_pe_office',
  'ef.pm_pe_patient',
].join(' ');

/**
 * Test OAuth Client Credentials (Step 1 only - minimal request)
 */
function testClientCredentials(env) {
  return new Promise((resolve, reject) => {
    const config = ENVIRONMENTS[env];
    if (!config) {
      return reject(new Error(`Unknown environment: ${env}`));
    }

    console.log(`\n${'='.repeat(60)}`);
    console.log(`Testing: ${config.name} (${config.oauthHost})`);
    console.log(`${'='.repeat(60)}`);
    console.log(`Client ID: ${config.clientId}`);
    console.log(`Secret: ${config.clientSecret.substring(0, 8)}...`);

    const postData = new URLSearchParams({
      'grant_type': 'client_credentials',
      'client_id': config.clientId,
      'client_secret': config.clientSecret,
      'scope': EPM_SCOPES,
    }).toString();

    const options = {
      hostname: config.oauthHost,
      port: 443,
      path: '/as/token.oauth2',
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData),
      },
    };

    console.log(`\nRequesting: https://${config.oauthHost}/as/token.oauth2`);

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        console.log(`\nStatus: ${res.statusCode}`);
        
        try {
          const json = JSON.parse(data);
          
          if (json.access_token) {
            console.log(`✅ SUCCESS - Got access token (${json.access_token.length} chars)`);
            console.log(`   Expires in: ${json.expires_in}s`);
            resolve({ success: true, env, token: json.access_token });
          } else if (json.error) {
            console.log(`❌ FAILED - ${json.error}: ${json.error_description || 'No description'}`);
            resolve({ success: false, env, error: json.error, description: json.error_description });
          } else {
            console.log(`⚠️  UNKNOWN RESPONSE:`, data.substring(0, 200));
            resolve({ success: false, env, error: 'unknown', raw: data });
          }
        } catch (e) {
          console.log(`⚠️  PARSE ERROR:`, data.substring(0, 200));
          resolve({ success: false, env, error: 'parse_error', raw: data });
        }
      });
    });

    req.on('error', (err) => {
      console.log(`❌ CONNECTION ERROR: ${err.message}`);
      resolve({ success: false, env, error: 'connection', message: err.message });
    });

    req.write(postData);
    req.end();
  });
}

// Main
const envArg = process.argv[2];

if (!envArg) {
  console.log(`
OAuth Environment Tester
========================

Usage: node test-oauth.js <environment>

Environments:
  sandbox  - Test Sandbox (api-sandbox.eyefinity.com)
  staging  - Test Staging (api-staging.eyefinity.com)
  both     - Test both (2 requests total)

Example:
  node test-oauth.js sandbox
  node test-oauth.js staging
  node test-oauth.js both
`);
  process.exit(0);
}

(async () => {
  console.log('\n🔐 OAuth Environment Tester');
  console.log('⚠️  Making minimal requests to avoid lockout\n');

  if (envArg === 'both') {
    const results = [];
    
    // Test sandbox first
    results.push(await testClientCredentials('sandbox'));
    
    // Small delay between requests
    await new Promise(r => setTimeout(r, 2000));
    
    // Test staging
    results.push(await testClientCredentials('staging'));
    
    console.log('\n' + '='.repeat(60));
    console.log('SUMMARY');
    console.log('='.repeat(60));
    results.forEach(r => {
      const status = r.success ? '✅ WORKS' : '❌ FAILED';
      console.log(`${ENVIRONMENTS[r.env].name.padEnd(10)} ${status}`);
    });
    
  } else if (ENVIRONMENTS[envArg]) {
    await testClientCredentials(envArg);
  } else {
    console.log(`Unknown environment: ${envArg}`);
    console.log('Use: sandbox, staging, or both');
  }
  
  console.log('\n');
})();
