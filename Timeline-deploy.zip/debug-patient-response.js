#!/usr/bin/env node

/**
 * Debug actual patient API response structure
 */

console.log('🔍 Debugging Patient API Response Structure...\n');

const testPatientResponse = async () => {
  try {
    // Use a working GUID from the debug output
    const testGuid = 'ecab1a6c-5aba-457a-870a-2743822de084';
    
    console.log('Testing GUID:', testGuid);
    console.log('URL:', `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testGuid}`);
    
    const response = await fetch(`https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testGuid}`, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    });
    
    console.log('Response status:', response.status);
    console.log('Response headers:', Object.fromEntries(response.headers.entries()));
    
    if (response.ok) {
      const rawData = await response.json();
      console.log('\n📋 Raw API Response:');
      console.log(JSON.stringify(rawData, null, 2));
      
      // Check different possible locations for PatientLegacyId
      console.log('\n🔍 Searching for PatientLegacyId:');
      
      const searchForLegacyId = (obj, path = '') => {
        if (typeof obj !== 'object' || obj === null) return;
        
        for (const [key, value] of Object.entries(obj)) {
          const currentPath = path ? `${path}.${key}` : key;
          
          if (key.toLowerCase().includes('legacy') || key.toLowerCase().includes('patientlegacy')) {
            console.log(`   Found at ${currentPath}:`, value);
          }
          
          if (key.toLowerCase() === 'patientlegacyid') {
            console.log(`   ✅ PatientLegacyId at ${currentPath}:`, value);
          }
          
          if (typeof value === 'object' && value !== null) {
            searchForLegacyId(value, currentPath);
          }
        }
      };
      
      searchForLegacyId(rawData);
      
      // Check if it's an array response
      if (Array.isArray(rawData)) {
        console.log('\n📊 Response is an array with', rawData.length, 'items');
        if (rawData.length > 0) {
          console.log('First item keys:', Object.keys(rawData[0]));
          searchForLegacyId(rawData[0], 'items[0]');
        }
      }
      
      // Check if it's wrapped in items
      if (rawData.items && Array.isArray(rawData.items)) {
        console.log('\n📊 Response has items array with', rawData.items.length, 'items');
        if (rawData.items.length > 0) {
          console.log('First item keys:', Object.keys(rawData.items[0]));
          searchForLegacyId(rawData.items[0], 'items[0]');
        }
      }
      
    } else {
      const errorText = await response.text();
      console.log('❌ Error:', errorText);
    }
    
  } catch (error) {
    console.log('❌ Request failed:', error.message);
  }
};

await testPatientResponse();
