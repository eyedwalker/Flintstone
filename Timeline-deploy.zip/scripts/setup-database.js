/**
 * Database Setup Script
 * Connects to PostgreSQL and executes the multi-tenant schema
 */

import pkg from 'pg';
const { Client } = pkg;
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { readFileSync } from 'fs';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Database connection configuration - Supabase PostgreSQL
const connectionString = process.env.SUPABASE_DB_URL || 'postgresql://postgres:[YOUR-PASSWORD]@db.sdxinswwxtuuyeurkqec.supabase.co:5432/postgres';

async function setupDatabase() {
  const client = new Client({
    connectionString: connectionString,
    ssl: {
      rejectUnauthorized: false
    }
  });
  
  try {
    console.log('🔌 Connecting to Supabase PostgreSQL...');
    console.log(`   Connection: ${connectionString.replace(/:[^:@]+@/, ':****@')}`);
    
    await client.connect();
    console.log('✅ Connected successfully!\n');
    
    // Test the connection
    const versionResult = await client.query('SELECT version()');
    console.log('📊 PostgreSQL Version:');
    console.log(`   ${versionResult.rows[0].version}\n`);
    
    // Read the schema file
    const schemaPath = join(__dirname, '..', 'src', 'lib', 'db', 'schema.sql');
    console.log(`📄 Reading schema file: ${schemaPath}`);
    
    const schemaSql = readFileSync(schemaPath, 'utf8');
    console.log('✅ Schema file loaded\n');
    
    // Execute the schema
    console.log('🚀 Executing schema...');
    await client.query(schemaSql);
    console.log('✅ Schema executed successfully!\n');
    
    // Verify tables were created
    const tablesResult = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_type = 'BASE TABLE'
      ORDER BY table_name
    `);
    
    console.log('📋 Created tables:');
    tablesResult.rows.forEach(row => {
      console.log(`   ✓ ${row.table_name}`);
    });
    
    // Check for seed data
    const accountCount = await client.query('SELECT COUNT(*) FROM accounts');
    const companyCount = await client.query('SELECT COUNT(*) FROM companies');
    
    console.log('\n📊 Initial data:');
    console.log(`   Accounts: ${accountCount.rows[0].count}`);
    console.log(`   Companies: ${companyCount.rows[0].count}`);
    
    console.log('\n✅ Database setup complete!');
    
  } catch (error) {
    console.error('❌ Error setting up database:', error.message);
    if (error.stack) {
      console.error(error.stack);
    }
    process.exit(1);
  } finally {
    await client.end();
    console.log('\n🔌 Connection closed');
  }
}

// Run the setup
setupDatabase();
