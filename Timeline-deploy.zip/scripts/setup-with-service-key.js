/**
 * Setup database schema using Supabase Service Role Key
 */

import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const supabaseUrl = process.env.SUPABASE_URL || 'https://sdxinswwxtuuyeurkqec.supabase.co';
const serviceKey = process.env.SUPABASE_SERVICE_KEY;

if (!serviceKey) {
  console.error('❌ SUPABASE_SERVICE_KEY not found in .env');
  process.exit(1);
}

console.log('🔐 Using service role key for admin access');
const supabase = createClient(supabaseUrl, serviceKey);

async function setupDatabase() {
  try {
    console.log('📄 Reading safe schema file...');
    const schemaPath = join(__dirname, '..', 'src', 'lib', 'db', 'schema-safe.sql');
    const schemaSql = readFileSync(schemaPath, 'utf8');
    
    console.log('🚀 Executing schema statements...\n');
    
    // Split SQL into individual statements
    const statements = schemaSql
      .split(';')
      .map(s => s.trim())
      .filter(s => s.length > 0 && !s.startsWith('--') && !s.startsWith('/*'));
    
    console.log(`Found ${statements.length} SQL statements\n`);
    
    for (let i = 0; i < statements.length; i++) {
      const statement = statements[i] + ';';
      
      // Log what we're executing (truncated)
      const preview = statement.substring(0, 80).replace(/\s+/g, ' ');
      process.stdout.write(`[${i + 1}/${statements.length}] ${preview}...`);
      
      try {
        // Execute via RPC
        const { error } = await supabase.rpc('exec_sql', { query: statement });
        
        if (error) {
          console.log(` ⚠️  ${error.message}`);
        } else {
          console.log(` ✅`);
        }
      } catch (err) {
        console.log(` ❌ ${err.message}`);
      }
    }
    
    console.log('\n✅ Schema execution complete!\n');
    
    // Verify tables were created
    console.log('🔍 Verifying tables...');
    
    const tables = ['accounts', 'companies', 'offices', 'staff', 'staff_offices'];
    
    for (const table of tables) {
      const { data, error } = await supabase
        .from(table)
        .select('id')
        .limit(1);
      
      if (!error) {
        console.log(`✅ ${table} table exists and is accessible`);
      } else {
        console.log(`❌ ${table} table error: ${error.message}`);
      }
    }
    
    console.log('\n🎉 Database setup complete! Navigate to http://localhost:5173/account-setup to begin.\n');
    
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

setupDatabase();
