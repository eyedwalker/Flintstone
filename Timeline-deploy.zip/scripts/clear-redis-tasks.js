#!/usr/bin/env node
/**
 * Clear corrupted task data from production Redis
 * 
 * Usage:
 *   node scripts/clear-redis-tasks.js
 * 
 * Requires environment variables:
 *   KV_REST_API_URL
 *   KV_REST_API_TOKEN
 */

import { Redis } from '@upstash/redis';

async function clearTaskData() {
  const url = process.env.KV_REST_API_URL;
  const token = process.env.KV_REST_API_TOKEN;

  if (!url || !token) {
    console.error('❌ Missing required environment variables:');
    console.error('   KV_REST_API_URL');
    console.error('   KV_REST_API_TOKEN');
    console.error('\nThese should be set in your .env file or passed directly.');
    process.exit(1);
  }

  console.log('🔌 Connecting to Redis...');
  const redis = new Redis({ url, token });

  const keys = [
    'timeline:tasks:data',
    'timeline:tasks:queue',
    'timeline:tasks:scheduled',
    'timeline:tasks:activity',
    'timeline:tasks:history',
  ];

  console.log('🗑️  Clearing task data...');
  
  for (const key of keys) {
    try {
      await redis.del(key);
      console.log(`   ✓ Cleared: ${key}`);
    } catch (error) {
      console.error(`   ✗ Failed to clear ${key}:`, error.message);
    }
  }

  console.log('\n✅ Task data cleared successfully!');
  console.log('   You can now create new tasks without JSON parsing errors.');
}

clearTaskData().catch((error) => {
  console.error('❌ Error:', error);
  process.exit(1);
});
