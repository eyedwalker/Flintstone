/**
 * Setup database schema via Supabase REST API
 */

import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://sdxinswwxtuuyeurkqec.supabase.co';
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseKey) {
  console.error('❌ VITE_SUPABASE_ANON_KEY not found in .env');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function setupDatabase() {
  try {
    console.log('📄 Reading safe schema file...');
    const schemaPath = join(__dirname, '..', 'src', 'lib', 'db', 'schema-safe.sql');
    const schemaSql = readFileSync(schemaPath, 'utf8');
    
    console.log('🚀 Executing schema via Supabase...\n');
    
    // Split SQL into individual statements
    const statements = schemaSql
      .split(';')
      .map(s => s.trim())
      .filter(s => s.length > 0 && !s.startsWith('--'));
    
    let successCount = 0;
    let errorCount = 0;
    
    for (let i = 0; i < statements.length; i++) {
      const statement = statements[i] + ';';
      
      // Skip comments
      if (statement.startsWith('/*') || statement.startsWith('--')) {
        continue;
      }
      
      try {
        const { data, error } = await supabase.rpc('exec_sql', { 
          query: statement 
        });
        
        if (error) {
          // Try direct query for DDL statements
          const { error: queryError } = await supabase.from('_').select('*').limit(0);
          
          if (queryError && queryError.message.includes('does not exist')) {
            console.log(`⚠️  Statement ${i + 1}/${statements.length}: Cannot execute via RPC, needs direct access`);
            errorCount++;
          } else {
            console.log(`✅ Statement ${i + 1}/${statements.length} executed`);
            successCount++;
          }
        } else {
          console.log(`✅ Statement ${i + 1}/${statements.length} executed`);
          successCount++;
        }
      } catch (err) {
        console.log(`⚠️  Statement ${i + 1}/${statements.length}: ${err.message}`);
        errorCount++;
      }
    }
    
    console.log(`\n📊 Results: ${successCount} succeeded, ${errorCount} skipped/failed`);
    console.log('\n⚠️  Note: Some DDL statements require direct PostgreSQL access.');
    console.log('Please run the schema manually in Supabase SQL Editor for full setup.\n');
    
    // Verify tables exist
    console.log('🔍 Verifying tables...');
    const { data: accounts, error: accountsError } = await supabase
      .from('accounts')
      .select('id')
      .limit(1);
    
    if (!accountsError) {
      console.log('✅ accounts table exists');
    } else {
      console.log('❌ accounts table not found - manual SQL execution needed');
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

setupDatabase();
