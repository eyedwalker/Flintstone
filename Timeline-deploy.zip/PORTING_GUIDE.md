# AI & Eyefinity API Porting Guide

This document provides a complete reference for porting the AI chat system and Eyefinity API integration to another application.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [AI System Components](#ai-system-components)
3. [Eyefinity API Integration](#eyefinity-api-integration)
4. [Dependencies](#dependencies)
5. [Environment Variables](#environment-variables)
6. [File-by-File Porting Guide](#file-by-file-porting-guide)
7. [API Routes](#api-routes)
8. [Database Models](#database-models)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      AI Chat Component                          │
│                   (AICommandChat.tsx)                           │
└─────────────────────────────┬───────────────────────────────────┘
                              │ POST /api/ai-commands/process
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    API Route Handler                             │
│              (api/ai-commands/process/route.ts)                  │
└─────────────────────────────┬───────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│              AI Natural Language Service                         │
│           (ai-natural-language-service.ts)                       │
│                                                                  │
│   • Builds system prompt with context                           │
│   • Sends to Claude with tool schemas                           │
│   • Parses tool calls and executes handlers                     │
└──────────────┬──────────────────────────────┬───────────────────┘
               │                              │
               ▼                              ▼
┌──────────────────────────┐    ┌──────────────────────────────────┐
│    AI Tool Registry      │    │      AI Tool Handlers            │
│ (ai-tool-registry.ts)    │    │   (ai-tool-handlers.ts)          │
│                          │    │                                  │
│ • Tool schemas (Claude)  │    │ • Actual implementations         │
│ • Tool metadata          │    │ • Calls EyefinityService         │
│ • Handler references     │    │ • Calls database                 │
└──────────────────────────┘    └──────────────┬───────────────────┘
                                               │
                                               ▼
                              ┌──────────────────────────────────────┐
                              │         Eyefinity Service            │
                              │       (eyefinity-service.ts)         │
                              │                                      │
                              │ • Patient search/lookup              │
                              │ • Appointment slots                  │
                              │ • Create/cancel appointments         │
                              │ • Provider/office listing            │
                              └──────────────────────────────────────┘
```

---

## AI System Components

### 1. Core NLU Service

**File:** `src/lib/services/ai-natural-language-service.ts`

**Purpose:** Main entry point for natural language processing using Claude function calling.

**Key Interfaces:**

```typescript
interface NLUResult {
  success: boolean;
  toolName?: string;
  parameters?: Record<string, any>;
  message: string;
  data?: any;
  requiresConfirmation?: boolean;
  confidence?: number;
  suggestedFollowUp?: string;
  updatedContext?: ConversationContext;
}

interface ConversationContext {
  currentPatient?: {
    name: string;
    id?: string;
    officeId?: string;
    providerId?: string;
    // ... more fields
  };
  lastPatient?: { name: string; id?: string };
  lastProvider?: { name: string; id?: string };
  lastDate?: string;
  pendingSelection?: {
    type: 'patient' | 'provider' | 'appointment' | 'slot';
    options: Array<{ id: string; label: string; data?: any }>;
    prompt: string;
  };
  lastAction?: { tool: string; parameters: Record<string, any> };
  currentWorkflow?: { type: string; step: string; collectedData: Record<string, any> };
}
```

**Key Function:**

```typescript
export async function processNaturalLanguage(
  userMessage: string,
  toolContext: ToolContext,
  conversationHistory?: ConversationMessage[],
  conversationContext?: ConversationContext,
  conversationSummary?: string
): Promise<NLUResult>
```

---

### 2. Tool Registry

**File:** `src/lib/services/ai-tool-registry.ts`

**Purpose:** Defines all available tools with Claude-compatible schemas.

**Key Interfaces:**

```typescript
interface ToolHandler {
  name: string;
  description: string;
  category: 'scheduling' | 'patient' | 'communication' | 'orders' | 'admin' | 'eyefinity';
  schema: Tool; // Anthropic SDK Tool type
  handler: (params: Record<string, any>, context: ToolContext) => Promise<ToolResult>;
  requiresConfirmation?: boolean;
}

interface ToolContext {
  staffId?: string;
  staffName?: string;
  officeId?: string;
  currentPatientId?: string;
  currentPatient?: {
    name: string;
    id?: string;
    officeId?: string;
    providerId?: string;
  };
}

interface ToolResult {
  success: boolean;
  message: string;
  data?: any;
  error?: string;
  suggestedFollowUp?: string;
  requiresConfirmation?: boolean;
  pendingSelection?: {
    type: 'patient' | 'provider' | 'appointment' | 'slot';
    options: Array<{ id: string; label: string; data?: any }>;
    prompt: string;
  };
}
```

**Available Tools:**

| Tool Name | Category | Description |
|-----------|----------|-------------|
| `find_available_slots` | scheduling | Find appointment slots by date/provider |
| `book_appointment` | scheduling | Book an appointment for a patient |
| `cancel_appointment` | scheduling | Cancel an existing appointment |
| `reschedule_appointment` | scheduling | Reschedule an appointment |
| `get_todays_schedule` | scheduling | Get today's appointment schedule |
| `search_patient` | patient | Search for patients by name/phone/DOB |
| `get_patient_details` | patient | Get full patient information |
| `checkin_patient` | patient | Check in a patient |
| `send_sms` | communication | Send SMS to patient |
| `send_email` | communication | Send email to patient |
| `list_providers` | eyefinity | List available providers/doctors |
| `list_offices` | eyefinity | List practice offices |

---

### 3. Tool Handlers

**File:** `src/lib/services/ai-tool-handlers.ts`

**Purpose:** Actual implementations that connect tool schemas to backend services.

**Key Functions:**

```typescript
export const ToolHandlers = {
  find_available_slots: handleFindAvailableSlots,
  book_appointment: handleBookAppointment,
  search_patient: handleSearchPatient,
  get_todays_schedule: handleGetTodaysSchedule,
  list_providers: handleListProviders,
  // ... more handlers
};
```

**Example Handler:**

```typescript
async function handleFindAvailableSlots(
  params: Record<string, any>,
  context: ToolContext
): Promise<ToolResult> {
  const { EyefinityService } = await getServices();
  
  // Priority: 1) explicit param, 2) current patient's office, 3) context office
  const officeId = params.officeId || 
    context.currentPatient?.officeId || 
    context.officeId || 
    process.env.DEFAULT_OFFICE_ID;
    
  const result = await EyefinityService.findNextAvailableSlot(officeId, {
    fromDate: parseNaturalDate(params.date),
    providerName: params.providerName
  });
  
  return {
    success: true,
    message: `Found ${result.slots.length} available slots`,
    data: result.slots
  };
}
```

---

### 4. Chat Component

**File:** `src/components/ai-chat/AICommandChat.tsx`

**Purpose:** React component for the AI chat interface.

**Key Props:**

```typescript
interface AICommandChatProps {
  staffId: string;
  staffName: string;
  officeId: string;
  currentTaskId?: string;
  currentPatientName?: string;
  currentPatient?: CurrentPatientContext;
}
```

**State Management:**

```typescript
const [messages, setMessages] = useState<Message[]>([]);
const [conversationContext, setConversationContext] = useState<ConversationContext>({});

// Update context from API response
if (data.updatedContext) {
  setConversationContext(prev => ({
    ...prev,
    ...data.updatedContext
  }));
}
```

---

## Eyefinity API Integration

### 1. Main Service

**File:** `src/lib/services/eyefinity-service.ts`

**Base URL:** `https://pm-ci.eyefinity.com/al-pe` (configurable via env)

**Authentication:** Bearer token (static or OAuth)

**Key Methods:**

| Method | Endpoint | Description |
|--------|----------|-------------|
| `getOffices()` | `GET /v2offices` | List all offices with GUIDs |
| `getProviders()` | `GET /v2staff` | List providers/staff |
| `searchPatients()` | `GET /patients` | Search patients |
| `getPatientById()` | `GET /patients/{id}` | Get patient details |
| `getAppointments()` | `GET /appointments` | List appointments |
| `getAppointmentSlots()` | `GET /v2staff/{staffId}/appointmentSlots` | Get available slots |
| `createAppointment()` | `PUT /v2staff/{staffId}/appointments` | Create appointment |
| `cancelAppointment()` | `POST /appointments/{id}/cancel` | Cancel appointment |
| `rescheduleAppointment()` | `PATCH /appointments/{id}` | Reschedule |

**Authentication Pattern:**

```typescript
private static async getHeaders(context?: AuthContext) {
  // Option 1: Static token (for testing)
  const staticToken = process.env.EYEFINITY_STATIC_ACCESS_TOKEN;
  if (staticToken) {
    return {
      Authorization: `Bearer ${staticToken}`,
      'Content-Type': 'application/json',
    };
  }
  
  // Option 2: OAuth token
  const accessToken = await EyefinityOAuthService.getValidAccessToken(context);
  return {
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
  };
}
```

### 2. OAuth Service

**File:** `src/lib/services/eyefinity-oauth-service.ts`

**Purpose:** Handle OAuth token management for Eyefinity API.

### 3. Key API Patterns

**Appointment Slots (v2 API):**

```typescript
// Endpoint: GET /v2staff/{staffId}/appointmentSlots
// Required params: officeId (GUID), fromDate, toDate, itemDuration OR appointmentTypeId

const params = new URLSearchParams({
  officeId: 'guid-here',
  fromDate: '2026-01-21',
  toDate: '2026-01-28',
  itemDuration: '30',
  page: '1',
  pageSize: '20'
});

const url = `${BASE_URL}/v2staff/${staffId}/appointmentSlots?${params}`;
```

**Create Appointment:**

```typescript
// Endpoint: PUT /v2staff/{staffId}/appointments
const payload = {
  PatientId: '123456',
  OfficeId: 'office-guid',
  StaffId: 'staff-guid',
  AppointmentDate: '2026-01-25',
  AppointmentStartTime: '10:00',
  AppointmentEndTime: '10:30',
  AppointmentTypeId: 1,
  AppointmentReason: 'General Exam',
  CancelIndicator: false,
  Notes: []
};
```

---

## Dependencies

### Required NPM Packages

```json
{
  "@anthropic-ai/sdk": "^0.51.0",
  "axios": "^1.x",
  "mongoose": "^8.x"
}
```

### Optional (for full feature set)

```json
{
  "twilio": "^4.x",
  "nodemailer": "^6.x"
}
```

---

## Environment Variables

### Required

```env
# Anthropic Claude
ANTHROPIC_API_KEY=sk-ant-api03-xxx

# Eyefinity API
EYEFINITY_PRACTICE_API_BASE_URL=https://pm-ci.eyefinity.com/al-pe
EYEFINITY_STATIC_ACCESS_TOKEN=xxx  # Or use OAuth
EYEFINITY_DEFAULT_TENANT_ID=936
EYEFINITY_DEFAULT_OFFICE_ID=999

# Database
MONGODB_URI=mongodb+srv://xxx
```

### Optional

```env
# Twilio (for SMS)
TWILIO_ACCOUNT_SID=xxx
TWILIO_AUTH_TOKEN=xxx
TWILIO_PHONE_NUMBER=+1xxx

# Default office for slot searches
DEFAULT_OFFICE_ID=999
```

---

## File-by-File Porting Guide

### Priority 1: Core AI (Copy These First)

| File | Purpose | Dependencies |
|------|---------|--------------|
| `src/lib/services/ai-natural-language-service.ts` | NLU core | @anthropic-ai/sdk, ai-tool-registry |
| `src/lib/services/ai-tool-registry.ts` | Tool definitions | ai-tool-handlers |
| `src/lib/services/ai-tool-handlers.ts` | Tool implementations | eyefinity-service, db, twilio |

### Priority 2: Eyefinity Integration

| File | Purpose | Dependencies |
|------|---------|--------------|
| `src/lib/services/eyefinity-service.ts` | Eyefinity API wrapper | axios, eyefinity-oauth-service |
| `src/lib/services/eyefinity-oauth-service.ts` | OAuth token management | axios |

### Priority 3: API Routes

| File | Purpose |
|------|---------|
| `src/app/api/ai-commands/process/route.ts` | Main AI processing endpoint |
| `src/app/api/ai-commands/execute/route.ts` | Execute confirmed commands |
| `src/app/api/eyefinity/route.ts` | Direct Eyefinity API proxy |

### Priority 4: UI Components

| File | Purpose |
|------|---------|
| `src/components/ai-chat/AICommandChat.tsx` | Chat interface |

---

## API Routes

### POST /api/ai-commands/process

**Request:**

```typescript
{
  command: string;                    // User's natural language input
  context: {
    staffId: string;
    staffName: string;
    officeId: string;
  };
  conversationHistory?: Array<{       // Previous messages
    role: 'user' | 'assistant';
    content: string;
  }>;
  conversationContext?: ConversationContext;  // Rich context
  conversationSummary?: string;       // Summary for context retention
  useLegacy?: boolean;                // Use legacy regex parser
}
```

**Response:**

```typescript
{
  success: boolean;
  message: string;
  data?: any;
  toolName?: string;
  parameters?: Record<string, any>;
  requiresConfirmation?: boolean;
  suggestedFollowUp?: string;
  updatedContext?: ConversationContext;
  source: 'nlu' | 'legacy' | 'legacy-fallback';
}
```

---

## Database Models

### Task Model (for patient context)

```typescript
interface Task {
  _id: ObjectId;
  patientId?: string;
  patientName: string;
  patientPhone?: string;
  patientDetails?: {
    firstName: string;
    lastName: string;
    dob?: string;
  };
  officeId?: string;
  providerId?: string;
  appointmentId?: string;
  appointmentDate?: string;
}
```

---

## Quick Start Porting Steps

1. **Copy core files:**
   - `ai-natural-language-service.ts`
   - `ai-tool-registry.ts`
   - `ai-tool-handlers.ts`
   - `eyefinity-service.ts`

2. **Install dependencies:**
   ```bash
   npm install @anthropic-ai/sdk axios
   ```

3. **Set environment variables:**
   ```env
   ANTHROPIC_API_KEY=your-key
   EYEFINITY_STATIC_ACCESS_TOKEN=your-token
   EYEFINITY_PRACTICE_API_BASE_URL=https://pm-ci.eyefinity.com/al-pe
   ```

4. **Create API route:**
   - Copy `api/ai-commands/process/route.ts`
   - Adjust imports for your project structure

5. **Add chat component:**
   - Copy `AICommandChat.tsx`
   - Adjust styling/imports as needed

6. **Customize tools:**
   - Edit `ai-tool-registry.ts` to add/remove tools
   - Implement handlers in `ai-tool-handlers.ts`

---

## Notes

- The v2 Eyefinity endpoints require GUIDs, not legacy integer IDs
- Use `v2offices` to get office GUIDs, `v2staff` for provider GUIDs
- Appointment slots require `officeId` (GUID) + either `itemDuration` or `appointmentTypeId`
- The AI system supports multi-turn conversations via `ConversationContext`
- Pending selections (patient lists, provider lists) are tracked in context for follow-up handling
