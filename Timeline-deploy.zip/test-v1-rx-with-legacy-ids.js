#!/usr/bin/env node

/**
 * Test RX API using v1 endpoint /patients/{legacyId}/rx with multiple patients
 * Then test v2 endpoint if v1 works
 */

console.log('🔬 TESTING RX API: V1 vs V2 ENDPOINT COMPARISON');
console.log('════════════════════════════════════════════════════════════════════════');

// Known patient GUIDs to get legacy IDs from
const knownPatients = [
  'ecab1a6c-5aba-457a-870a-2743822de084',
  '34f9334e-2dcd-4190-9190-e87709fad676',
  // We'll also test with the known legacy ID from the user's example
];

const knownLegacyIds = [
  '1080416' // From user's example
];

const formatValue = (value) => {
  if (value === null || value === undefined) return '⚪ null';
  if (value === '') return '⚪ empty';
  return value;
};

const displayRxData = (rxItems, title) => {
  console.log(`\n💊 ${title} (${rxItems.length} items):`);
  console.log('═'.repeat(80));
  
  if (rxItems.length > 0) {
    rxItems.slice(0, 3).forEach((rx, i) => {
      console.log(`\n📋 Prescription ${i + 1}:`);
      console.log('─'.repeat(50));
      console.log(`   RX Number............: ${formatValue(rx.RxNumber)}`);
      console.log(`   Date Prescribed......: ${formatValue(rx.DatePrescribed)}`);
      console.log(`   Product..............: ${formatValue(rx.Product)}`);
      console.log(`   OD Sphere............: ${formatValue(rx.OdSphere)}`);
      console.log(`   OD Cylinder..........: ${formatValue(rx.OdCylinder)}`);
      console.log(`   OD Axis..............: ${formatValue(rx.OdAxis)}`);
      console.log(`   OS Sphere............: ${formatValue(rx.OsSphere)}`);
      console.log(`   OS Cylinder..........: ${formatValue(rx.OsCylinder)}`);
      console.log(`   OS Axis..............: ${formatValue(rx.OsAxis)}`);
      console.log(`   Add Power............: ${formatValue(rx.AddPower)}`);
      console.log(`   PD...................: ${formatValue(rx.PupillaryDistance)}`);
      console.log(`   Provider.............: ${formatValue(rx.ProviderName)}`);
      console.log(`   Status...............: ${formatValue(rx.Status)}`);
      console.log(`   Expiration...........: ${formatValue(rx.ExpirationDate)}`);
    });
    
    if (rxItems.length > 3) {
      console.log(`\n   ... and ${rxItems.length - 3} more prescriptions`);
    }
    
    return true; // Has RX data
  } else {
    console.log('   📭 No prescriptions found');
    return false; // No RX data
  }
};

const getLegacyIdFromGuid = async (guid) => {
  try {
    console.log(`\n🔍 Getting legacy ID for GUID: ${guid}`);
    
    const response = await fetch(`https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${guid}`);
    
    if (response.ok) {
      const data = await response.json();
      const patient = data.items?.[0] || data;
      const legacyId = patient.PatientLegacyId;
      
      console.log(`   ✅ Found Legacy ID: ${legacyId}`);
      console.log(`   Patient: ${patient.FirstName || 'N/A'} ${patient.LastName || 'N/A'}`);
      
      return { guid, legacyId, patient };
    } else {
      console.log(`   ❌ Failed to get patient details: ${response.status}`);
      return null;
    }
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
    return null;
  }
};

const testV1RxEndpoint = async (legacyId, patientInfo = null) => {
  try {
    console.log(`\n🧪 Testing V1 RX Endpoint with Legacy ID: ${legacyId}`);
    if (patientInfo) {
      console.log(`   Patient: ${patientInfo.FirstName || 'N/A'} ${patientInfo.LastName || 'N/A'}`);
    }
    
    const url = `https://patientcare-teal.vercel.app/api/eyefinity/patients/${legacyId}/rx?page=1&pageSize=500`;
    console.log(`   URL: ${url}`);
    
    const response = await fetch(url);
    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    if (response.ok) {
      const data = await response.json();
      const rxItems = data.items || [];
      
      console.log(`   🎉 SUCCESS! V1 RX endpoint works!`);
      displayRxData(rxItems, `V1 RX Data for Legacy ID ${legacyId}`);
      
      return { success: true, data, legacyId, rxCount: rxItems.length };
    } else {
      console.log(`   ❌ V1 endpoint failed: ${response.status}`);
      return { success: false, status: response.status, legacyId };
    }
  } catch (error) {
    console.log(`   ❌ V1 endpoint error: ${error.message}`);
    return { success: false, error: error.message, legacyId };
  }
};

const testV2RxEndpoint = async (guid, legacyId) => {
  try {
    console.log(`\n🧪 Testing V2 RX Endpoint with GUID: ${guid}`);
    
    const url = `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${guid}/rx?page=1&pageSize=500`;
    console.log(`   URL: ${url}`);
    
    const response = await fetch(url);
    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    if (response.ok) {
      const data = await response.json();
      const rxItems = data.items || [];
      
      console.log(`   🎉 SUCCESS! V2 RX endpoint also works!`);
      displayRxData(rxItems, `V2 RX Data for GUID ${guid}`);
      
      return { success: true, data, guid, rxCount: rxItems.length };
    } else {
      console.log(`   ❌ V2 endpoint failed: ${response.status}`);
      return { success: false, status: response.status, guid };
    }
  } catch (error) {
    console.log(`   ❌ V2 endpoint error: ${error.message}`);
    return { success: false, error: error.message, guid };
  }
};

const runRxEndpointTests = async () => {
  console.log('\n🚀 Phase 1: Collecting Legacy IDs from Known Patients');
  console.log('═'.repeat(80));
  
  const patientData = [];
  
  // Get legacy IDs from known GUIDs
  for (const guid of knownPatients) {
    const result = await getLegacyIdFromGuid(guid);
    if (result && result.legacyId) {
      patientData.push(result);
    }
  }
  
  // Add the known legacy ID from user's example
  patientData.push({ 
    legacyId: '1080416', 
    guid: null, 
    patient: { FirstName: 'Unknown', LastName: '(User Example)' } 
  });
  
  console.log(`\n📋 Found ${patientData.length} patients to test:`);
  patientData.forEach((p, i) => {
    console.log(`   ${i + 1}. Legacy ID ${p.legacyId} - ${p.patient.FirstName} ${p.patient.LastName}`);
  });
  
  console.log('\n\n🚀 Phase 2: Testing V1 RX Endpoints');
  console.log('═'.repeat(80));
  
  const v1Results = [];
  const workingPatients = [];
  
  for (const patient of patientData) {
    const result = await testV1RxEndpoint(patient.legacyId, patient.patient);
    v1Results.push(result);
    
    if (result.success && result.rxCount > 0) {
      workingPatients.push({ ...patient, v1Result: result });
    }
    
    console.log('\n' + '─'.repeat(80));
  }
  
  console.log('\n\n🚀 Phase 3: Testing V2 RX Endpoints (for working V1 patients)');
  console.log('═'.repeat(80));
  
  const v2Results = [];
  
  if (workingPatients.length > 0) {
    console.log(`\nTesting ${workingPatients.length} patients that had V1 RX data...`);
    
    for (const patient of workingPatients) {
      if (patient.guid) {
        const result = await testV2RxEndpoint(patient.guid, patient.legacyId);
        v2Results.push({ ...result, legacyId: patient.legacyId });
        console.log('\n' + '─'.repeat(80));
      } else {
        console.log(`\n⚠️  Skipping V2 test for Legacy ID ${patient.legacyId} - no GUID available`);
      }
    }
  } else {
    console.log('\n📭 No patients with V1 RX data found - skipping V2 tests');
  }
  
  console.log('\n\n🎯 FINAL RESULTS SUMMARY:');
  console.log('═'.repeat(80));
  
  const v1Working = v1Results.filter(r => r.success && r.rxCount > 0);
  const v2Working = v2Results.filter(r => r.success && r.rxCount > 0);
  
  console.log(`\n📊 V1 Endpoint Results (/patients/{legacyId}/rx):`);
  console.log(`   ✅ Working: ${v1Working.length}/${v1Results.length}`);
  console.log(`   📦 With RX Data: ${v1Working.length}`);
  
  if (v1Working.length > 0) {
    console.log(`\n   Working V1 Patients:`);
    v1Working.forEach(r => {
      console.log(`     - Legacy ID ${r.legacyId}: ${r.rxCount} prescriptions`);
    });
  }
  
  console.log(`\n📊 V2 Endpoint Results (/v2patients/{guid}/rx):`);
  console.log(`   ✅ Working: ${v2Working.length}/${v2Results.length}`);
  console.log(`   📦 With RX Data: ${v2Working.length}`);
  
  if (v2Working.length > 0) {
    console.log(`\n   Working V2 Patients:`);
    v2Working.forEach(r => {
      console.log(`     - GUID ${r.guid}: ${r.rxCount} prescriptions`);
    });
  }
  
  console.log('\n🔍 CONCLUSION:');
  if (v1Working.length > 0) {
    console.log('🎉 V1 RX ENDPOINT WORKS! Use /patients/{legacyId}/rx');
    if (v2Working.length > 0) {
      console.log('🎉 V2 RX ENDPOINT ALSO WORKS! Use /v2patients/{guid}/rx');
      console.log('💡 Both endpoints are available - can use either format');
    } else {
      console.log('❌ V2 RX endpoint still doesn\'t work - stick with V1 format');
    }
  } else {
    console.log('❌ No working RX endpoints found - may need different API approach');
  }
};

runRxEndpointTests().catch(console.error);
