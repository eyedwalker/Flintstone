# Vercel Deployment Guide

## Prerequisites
- Vercel account connected to your GitHub repo
- Eyefinity OAuth credentials

## Environment Variables

Set these in Vercel Dashboard → Settings → Environment Variables:

| Variable | Description | Example |
|----------|-------------|---------|
| `EPM_CLIENT_ID` | OAuth client ID | `ef-productmgmt-test-client` |
| `EPM_CLIENT_SECRET` | OAuth secret (env-specific) | See below |
| `TENANT_UID` | Tenant UUID | `12345678-1234-1234-1234-123456789012` |
| `OAUTH_HOST` | OAuth server | `api-sandbox.eyefinity.com` |
| `EYEFINITY_API_URL` | API base URL | `https://api-sandbox.eyefinity.com` |

### Environment-Specific Secrets

| Environment | Secret | OAuth Host | API URL |
|-------------|--------|------------|---------|
| **Sandbox** (No VPN) | `VD24uag29VepKKeG1zuSMXKuXg6Q9bXEvCM3csm9cb3sX84GCLh7P20UUdFucToB` | `api-sandbox.eyefinity.com` | `https://api-sandbox.eyefinity.com` |
| **Staging** (No VPN) | `eWHwDWLwK1igPrN8Al03DNICT2smhBbILvy8VkujNnv1UfChCcD9qQAb8RfRIym5` | `api-staging.eyefinity.com` | `https://api-staging.eyefinity.com` |
| **Integration** (VPN) | `p6cZ37pWOc39dObF5L8ttY9tZZRTNKs5zsJpoL3TN2GJ36tgzqm2kAT1DLt7DSTe` | `api-integration.eyefinity.com` | `https://api-integration.eyefinity.com` |

> **Note:** Integration environment requires VPN access and won't work from Vercel's servers.

## Deployment Steps

### 1. Connect Repository to Vercel

```bash
# Install Vercel CLI (optional)
npm i -g vercel

# Login
vercel login

# Link project
vercel link
```

Or use the Vercel Dashboard:
1. Go to https://vercel.com/new
2. Import your GitHub repository
3. Vercel auto-detects Vite framework

### 2. Configure Environment Variables

In Vercel Dashboard:
1. Go to your project → Settings → Environment Variables
2. Add each variable from the table above
3. Set for Production, Preview, and Development as needed

### 3. Deploy

```bash
# Deploy to preview
vercel

# Deploy to production
vercel --prod
```

Or push to `main` branch for automatic deployment.

## Architecture

```
┌─────────────────┐     ┌──────────────────────┐     ┌─────────────────┐
│   Browser       │────▶│  Vercel Edge         │────▶│  Eyefinity API  │
│   (React App)   │     │  /api/eyefinity/*    │     │  (Sandbox)      │
└─────────────────┘     └──────────────────────┘     └─────────────────┘
                               │
                               ▼
                        OAuth Token Exchange
                        (Client Credentials →
                         Token Exchange)
```

## Vercel KV Setup (Authentication)

The authentication system uses **Vercel KV** (Redis) for persistent storage. This enables:

- User accounts with secure password hashing (bcrypt)
- Session management with tokens
- Invite-only registration
- MFA support

### 1. Enable Vercel KV

In Vercel Dashboard:

1. Go to your project → **Storage** tab
2. Click **Create Database** → Select **KV**
3. Name it (e.g., `timeline-auth`)
4. Click **Create**

Vercel will automatically add these environment variables:

- `KV_URL`
- `KV_REST_API_URL`
- `KV_REST_API_TOKEN`
- `KV_REST_API_READ_ONLY_TOKEN`

### 2. Initialize Admin User

After deploying, the system will auto-initialize on first login with:

- **Email:** `admin@visioncare.local`
- **Password:** `Admin@123456`

You'll be required to change the password on first login.

### 3. Auth API Endpoints

| Endpoint | Method | Description |
| ---------- | -------- | ------------- |
| `/api/auth/init` | GET/POST | Check/initialize system |
| `/api/auth/login` | POST | Login with email/password |
| `/api/auth/session` | GET/POST/DELETE | Validate/refresh/logout |
| `/api/auth/register` | POST | Register with invite token |
| `/api/auth/invite` | GET/POST/DELETE | Manage invites |
| `/api/auth/users` | GET/PUT/DELETE | Admin user management |

### 4. Security Features

- **Password Requirements:** 12+ chars, uppercase, lowercase, number, special char
- **Account Lockout:** 5 failed attempts = 15 min lockout
- **Session Duration:** 8 hours (with 7-day refresh tokens)
- **MFA:** TOTP-based (Google Authenticator compatible)

## Communications (SMS, Voice, Email)

### Required Environment Variables

Add these to Vercel Dashboard → Settings → Environment Variables:

**Twilio (SMS & Voice):**

- `TWILIO_ACCOUNT_SID` - Your Twilio Account SID
- `TWILIO_AUTH_TOKEN` - Your Twilio Auth Token
- `TWILIO_PHONE_NUMBER` - Your Twilio phone number (e.g., +15551234567)

**Email (SMTP):**

- `SMTP_HOST` - SMTP server (e.g., smtp.gmail.com)
- `SMTP_PORT` - SMTP port (typically 587 for TLS)
- `SMTP_USERNAME` - SMTP username/email
- `SMTP_PASSWORD` - SMTP password or app-specific password
- `SMTP_FROM_NAME` - Display name for sent emails
- `SMTP_FROM_EMAIL` - From email address

### Test Endpoints

After deployment, test your configuration:

```bash
# Check configuration status
curl https://your-app.vercel.app/api/communications/test

# Send test SMS
curl -X POST https://your-app.vercel.app/api/communications/test \
  -H "Content-Type: application/json" \
  -d '{"type": "sms", "to": "+1234567890"}'

# Send test email
curl -X POST https://your-app.vercel.app/api/communications/test \
  -H "Content-Type: application/json" \
  -d '{"type": "email", "to": "test@example.com"}'
```

### API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/communications/send-sms` | POST | Send SMS message |
| `/api/communications/send-email` | POST | Send email |
| `/api/communications/test` | GET/POST | Test configuration |

## Local Development

For local development with the OAuth proxy:

```bash
# Terminal 1: Start OAuth proxy
cd local-proxy && node server.js

# Terminal 2: Start Vite dev server
npm run dev
```

The local proxy handles OAuth and the Vite dev server proxies to it.

## Troubleshooting

### API returns 401
- Check that environment variables are set correctly
- Verify client secret matches the environment
- Token may have expired - serverless function auto-refreshes

### API returns 500
- Check Vercel function logs for detailed error
- Verify OAUTH_HOST and EYEFINITY_API_URL are correct
- Ensure the environment is accessible (Sandbox/Staging work without VPN)

### CORS errors

- The API function sets CORS headers automatically

## Task Management System

### Overview

The task management system provides comprehensive task handling with:

- Manual task creation and management
- Tasks linked to appointments and patients
- Automated reminders and scheduling
- Multi-channel task sources (SMS, voice, email, API)
- Queue-based job processing with retry logic
- Unified worklist combining appointments and tasks

### Task System Environment Variables

**Upstash Redis (Queue & Storage):**

- `KV_REST_API_URL` - Upstash Redis REST API URL (auto-added by Vercel KV)
- `KV_REST_API_TOKEN` - Upstash Redis REST API Token (auto-added by Vercel KV)

**Task Cron Authentication:**

- `TASK_CRON_SECRET` - Secure random string for authenticating cron requests

Generate the cron secret:

```bash
openssl rand -base64 32
```

Add it to Vercel Dashboard → Settings → Environment Variables as `TASK_CRON_SECRET`.

### Cron Job Setup

The system uses Vercel Cron Jobs to process scheduled tasks and reminders. The cron is already configured in `vercel.json`:

```json
"crons": [
  {
    "path": "/api/tasks/cron-runner",
    "schedule": "*/5 * * * *"
  }
]
```

This runs every 5 minutes to:

- Move scheduled jobs that are due into the active queue
- Process queued tasks with retry logic
- Handle reminders and delayed notifications

### Task API Endpoints

| Endpoint | Method | Description |
| ---------- | -------- | ------------- |
| `/api/tasks` | GET | List tasks with optional status filtering |
| `/api/tasks` | POST | Create new task with optional reminder |
| `/api/tasks/[id]` | GET | Retrieve specific task by ID |
| `/api/tasks/[id]` | PATCH | Update task (status, assignee, etc.) |
| `/api/tasks/enqueue` | POST | Enqueue immediate or delayed job |
| `/api/tasks/cron-runner` | POST | Cron processor (authenticated) |

### Task Creation

**Via API:**

```bash
# Create a task with a reminder
curl -X POST https://your-app.vercel.app/api/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Follow up on insurance",
    "description": "Verify coverage details",
    "priority": "high",
    "status": "pending",
    "assignee": "Front Desk",
    "dueDate": "2026-02-01",
    "dueTime": "14:00",
    "reminderInSeconds": 3600,
    "patientId": "12345",
    "appointmentId": "67890",
    "metadata": {
      "channel": "appointment_followup",
      "category": "insurance"
    }
  }'
```

**Via UI:**

1. Navigate to Patient Readiness Center
2. Click **New Manual Task** to create a standalone task
3. Or select an appointment and click **Task from Appointment** to pre-fill fields
4. Set reminder time (minutes before due date) if needed
5. Submit to create and optionally schedule reminder

### Task Lifecycle

**Statuses:**

- `pending` - Task created, awaiting action
- `in_progress` - Task actively being worked on
- `completed` - Task finished successfully
- `blocked` - Task cannot proceed (waiting on external dependency)

**Queue Flow:**

1. Task created → stored in Redis with unique ID
2. Reminder set → job scheduled in sorted set with timestamp
3. Cron runs → moves due jobs to active queue
4. Worker dequeues → processes job (send notification, etc.)
5. Success → mark complete | Failure → retry with exponential backoff (max 3 attempts)

### UI Features

**Patient Readiness Center Integration:**

- **Unified Worklist**: View appointments and tasks together
- **Filter Toggle**: Switch between All/Appointments/Tasks
- **Task Status Filter**: Filter by pending/in_progress/completed/blocked
- **Queue Stats**: Real-time metrics (active, scheduled, total tasks)
- **Create Modal**: Full-featured form with relationship tracking
- **Appointment Linking**: Automatically populate patient/appointment fields

### Queue Management

**View Queue Stats:**

```bash
curl https://your-app.vercel.app/api/tasks
```

Response includes:

```json
{
  "tasks": [...],
  "queueStats": {
    "activeCount": 5,
    "scheduledCount": 12,
    "totalTasks": 47
  }
}
```

**Monitor Cron Execution:**

Check Vercel → Deployments → Functions → `/api/tasks/cron-runner` for logs and execution history.

### Task Metadata Structure

Tasks support rich metadata for tracking relationships:

```json
{
  "taskId": "uuid",
  "title": "string",
  "description": "string",
  "priority": "low|normal|high|urgent",
  "status": "pending|in_progress|completed|blocked",
  "assignee": "string",
  "dueDate": "YYYY-MM-DD",
  "dueTime": "HH:mm",
  "patientId": "string",
  "appointmentId": "string",
  "patientName": "string",
  "officeId": "string",
  "providerName": "string",
  "metadata": {
    "channel": "internal|sms|voice|email|appointment_followup",
    "category": "string",
    "source": "manual|automated|api",
    "custom": "any additional fields"
  },
  "createdAt": "ISO timestamp",
  "updatedAt": "ISO timestamp",
  "activity": [
    {
      "action": "created|updated|completed",
      "timestamp": "ISO timestamp",
      "details": "string"
    }
  ]
}
```

### Testing the System

**1. Create a test task:**

```bash
curl -X POST http://localhost:5173/api/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test task",
    "description": "Verify queue processing",
    "priority": "normal",
    "status": "pending",
    "reminderInSeconds": 300
  }'
```

**2. Check queue stats:**

```bash
curl http://localhost:5173/api/tasks | jq '.queueStats'
```

**3. Trigger cron manually** (for testing):

```bash
curl -X POST http://localhost:5173/api/tasks/cron-runner \
  -H "X-Cron-Secret: your-secret-here"
```

**4. Verify in UI:**

- Open Patient Readiness Center
- Switch filter to "Tasks"
- Confirm your test task appears
- Check queue stats display

### Best Practices

1. **Set realistic reminders**: Use 15+ minutes before appointments
2. **Link to patients/appointments**: Always populate relationship fields when applicable
3. **Use meaningful priorities**: Reserve "urgent" for true emergencies
4. **Monitor queue depth**: If scheduled count grows large, consider more frequent cron
5. **Activity logs**: Review task activity for audit trails and debugging
