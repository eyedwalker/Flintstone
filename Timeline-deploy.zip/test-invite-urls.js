#!/usr/bin/env node

/**
 * Test script to verify invite URL generation
 * Tests both client-side and server-side invite URL generation
 */

console.log('🧪 Testing Invite URL Generation...\n');

// Test 1: Check environment variables
console.log('1. Environment Variables:');
console.log('   NODE_ENV:', process.env.NODE_ENV);
console.log('   VERCEL_URL:', process.env.VERCEL_URL);
console.log('   NEXT_PUBLIC_APP_URL:', process.env.NEXT_PUBLIC_APP_URL);
console.log('   VITE_APP_URL:', process.env.VITE_APP_URL);
console.log('');

// Test 2: Simulate server-side invite API logic
console.log('2. Server-side API Logic (from /api/auth/invite.js):');
const serverBaseUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://patientcare-teal.vercel.app';
const testToken = 'test-token-123';
const serverInviteUrl = `${serverBaseUrl}/register?invite=${testToken}`;
console.log('   Base URL:', serverBaseUrl);
console.log('   Generated URL:', serverInviteUrl);
console.log('   ✅ Uses production domain?', serverInviteUrl.includes('patientcare-teal.vercel.app'));
console.log('   ❌ Uses dynamic Vercel URL?', serverInviteUrl.includes('-projects.vercel.app'));
console.log('');

// Test 3: Test actual invite creation API
console.log('3. Testing Live Invite API...');

const testInviteCreation = async () => {
  try {
    const response = await fetch('https://patientcare-teal.vercel.app/api/auth/invite', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer test-token' // This will fail auth but we can see URL generation
      },
      body: JSON.stringify({
        email: 'test@example.com',
        role: 'staff',
        expiresInDays: 7
      })
    });

    const result = await response.text();
    console.log('   Response status:', response.status);
    console.log('   Response:', result);
    
    if (result.includes('/register?invite=')) {
      const urlMatch = result.match(/(https?:\/\/[^\/]+\/register\?invite=[^"]+)/);
      if (urlMatch) {
        const actualUrl = urlMatch[1];
        console.log('   📧 Actual invite URL found:', actualUrl);
        console.log('   ✅ Uses production domain?', actualUrl.includes('patientcare-teal.vercel.app'));
        console.log('   ❌ Uses dynamic Vercel URL?', actualUrl.includes('-projects.vercel.app'));
      }
    }
  } catch (error) {
    console.log('   ❌ Error testing API:', error.message);
  }
};

testInviteCreation();

console.log('\n🎯 Expected Result: All URLs should use https://patientcare-teal.vercel.app');
console.log('📝 If still showing dynamic URLs, check Vercel environment variables deployment');
