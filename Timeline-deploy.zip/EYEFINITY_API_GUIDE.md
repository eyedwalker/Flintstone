# Eyefinity API Integration Guide

Complete reference for integrating Eyefinity Practice Management APIs with **v2 GUID-based endpoints**.

## Quick Start

### Environment Variables

```bash
# .env.local
EYEFINITY_PRACTICE_API_BASE_URL=https://pm-ci.eyefinity.com/al-pe
EYEFINITY_STATIC_ACCESS_TOKEN=your_bearer_token_here
EYEFINITY_DEFAULT_TENANT_ID=your_tenant_id
EYEFINITY_DEFAULT_OFFICE_ID=your_office_guid  # Must be GUID for v2 endpoints
```

### TypeScript Types

```typescript
// src/types/env.d.ts
declare global {
  namespace NodeJS {
    interface ProcessEnv {
      EYEFINITY_PRACTICE_API_BASE_URL?: string;
      EYEFINITY_STATIC_ACCESS_TOKEN?: string;
      EYEFINITY_DEFAULT_TENANT_ID?: string;
      EYEFINITY_DEFAULT_OFFICE_ID?: string;
    }
  }
}
```

---

## API Endpoints

**Base URL**: `https://pm-ci.eyefinity.com/al-pe`

> **IMPORTANT**: v2 endpoints require GUIDs instead of legacy integer IDs. Use `v2offices` and `v2staff` endpoints to retrieve GUIDs.

---

## v2 Endpoints (GUID-based) - RECOMMENDED

### Offices (v2)

```http
GET /v2offices?page=1&pageSize=100
GET /v2offices/{officeGuid}
```

**Response includes**: `guid`, `officeId`, `officeName`, `address`, `phone`

### Providers/Staff (v2)

```http
GET /v2staff?page=1&pageSize=50&officeId={officeGuid}
GET /v2staff/{staffGuid}
```

**Response includes**: `guid`, `staffId`, `firstName`, `lastName`, `fullName`, `providerType`

### Appointment Slots (v2) - **Critical for Scheduling**

```http
GET /v2staff/{staffGuid}/appointmentSlots?officeId={officeGuid}&fromDate=2026-01-21&toDate=2026-01-28&itemDuration=30&page=1&pageSize=20
```

**Required Parameters**:
- `officeId` - Office GUID (not integer ID)
- `fromDate` - Start date (YYYY-MM-DD)
- `toDate` - End date (YYYY-MM-DD)
- `itemDuration` OR `appointmentTypeId` - Duration in minutes or appointment type

### Create Appointment (v2)

```http
PUT /v2staff/{staffGuid}/appointments
```

**Payload**:
```json
{
  "PatientId": "123456",
  "OfficeId": "office-guid-here",
  "StaffId": "staff-guid-here",
  "AppointmentDate": "2026-01-25",
  "AppointmentStartTime": "10:00",
  "AppointmentEndTime": "10:30",
  "AppointmentTypeId": 1,
  "AppointmentReason": "General Exam",
  "CancelIndicator": false,
  "Notes": []
}
```

---

## Legacy Endpoints (v1)

### Offices (Legacy)

```http
GET /offices?page=1&pageSize=20
```

### Patients

```http
GET /patients?lastName=Smith&firstName=John&page=1&pageSize=50
GET /patients/{patientId}
GET /patients/{patientId}/rx?page=1&pageSize=500
GET /patients/{patientId}/orders?fromStatusChangedDate=2023-01-01&toStatusChangedDate=2024-12-31
PATCH /patients/{patientId}/contact
GET /patients/{patientId}/insurance/verification
```

### Appointments (Legacy)

```http
GET /appointments/?fromDate=2024-01-01&toDate=2024-12-31&page=1&pageSize=50
GET /appointments/{appointmentId}
POST /appointments
PUT /appointments/{appointmentId}
POST /appointments/{appointmentId}/cancel
PATCH /appointments/{appointmentId}
```

### Providers (Legacy)

```http
GET /providers?page=1&pageSize=20
```

### Insurance

```http
GET /offices/{officeId}/insuranceCarriers?page=1&pageSize=500
```

---

## Service Implementation

### EyefinityService (Main Service)

```typescript
// src/lib/services/eyefinity-service.ts
import axios from 'axios';

const BASE_URL = process.env.EYEFINITY_PRACTICE_API_BASE_URL || 'https://pm-ci.eyefinity.com/al-pe';

export class EyefinityService {
  private static async getHeaders() {
    const token = process.env.EYEFINITY_STATIC_ACCESS_TOKEN;
    if (!token) throw new Error('No authentication token');
    
    return {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    };
  }

  static async getOffices(page = 1, pageSize = 20) {
    const headers = await this.getHeaders();
    const response = await axios.get(`${BASE_URL}/offices`, {
      params: { page, pageSize },
      headers
    });
    return response.data;
  }

  static async getPatientEyewearOrders(patientId: string, options?: {
    fromStatusChangedDate?: string;
    toStatusChangedDate?: string;
    page?: number;
    pageSize?: number;
  }) {
    const {
      fromStatusChangedDate = '2020-01-01',
      toStatusChangedDate = new Date().toISOString().split('T')[0],
      page = 1,
      pageSize = 1000
    } = options || {};

    const headers = await this.getHeaders();
    const url = `${BASE_URL}/patients/${patientId}/orders?fromStatusChangedDate=${fromStatusChangedDate}&toStatusChangedDate=${toStatusChangedDate}&page=${page}&pageSize=${pageSize}`;
    
    const response = await axios.get(url, { headers });
    return response.data;
  }

  static async updatePatientContactInfo(patientId: string, contactData: {
    email?: string;
    phone?: string;
  }) {
    const headers = await this.getHeaders();
    const payload: any = {};
    if (contactData.email) payload.Email = contactData.email;
    if (contactData.phone) payload.Phone = contactData.phone;

    const response = await axios.patch(
      `${BASE_URL}/patients/${patientId}/contact`,
      payload,
      { headers }
    );
    return response.data;
  }

  static async getAppointmentSlots(officeId: string, options: {
    fromDate: string;
    toDate: string;
    page?: number;
    pageSize?: number;
    itemDuration?: number;
  }) {
    const headers = await this.getHeaders();
    const params = new URLSearchParams({
      fromDate: options.fromDate,
      toDate: options.toDate,
      page: String(options.page ?? 1),
      pageSize: String(options.pageSize ?? 20),
      itemDuration: String(options.itemDuration ?? 20),
    });

    const url = `${BASE_URL}/v2/offices/${officeId}/appointmentSlots?${params}`;
    const response = await axios.get(url, { headers });
    return response.data;
  }
}
```

### AppointmentService

```typescript
// src/lib/services/appointment-service.ts
export class AppointmentService {
  static async fetchAppointments(
    page = 1,
    fromDate?: Date,
    toDate?: Date,
    officeId?: string,
    providerId?: string
  ) {
    const fromDateStr = fromDate?.toISOString().split('T')[0] || '2023-01-01';
    const toDateStr = toDate?.toISOString().split('T')[0] || new Date().toISOString().split('T')[0];

    const params = new URLSearchParams({
      fromDate: fromDateStr,
      toDate: toDateStr,
      page: page.toString(),
      pageSize: '50'
    });

    if (officeId) params.append('officeId', officeId);
    if (providerId) params.append('providerId', providerId);

    // Use local API proxy to avoid CORS
    const response = await fetch(`/api/appointments?${params}`);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return response.json();
  }

  static async createAppointment(data: any) {
    const token = process.env.EYEFINITY_STATIC_ACCESS_TOKEN;
    const response = await fetch('https://pm-ci.eyefinity.com/al-pe/appointments', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return response.json();
  }
}
```

---

## API Routes (CORS Proxies)

### Appointments Route
```typescript
// src/app/api/appointments/route.ts
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = request.nextUrl;
  const params = new URLSearchParams({
    fromDate: searchParams.get('fromDate') || '2023-01-01',
    toDate: searchParams.get('toDate') || '2025-12-31',
    page: searchParams.get('page') || '1',
    pageSize: searchParams.get('pageSize') || '50'
  });

  const officeId = searchParams.get('officeId');
  const providerId = searchParams.get('providerId');
  if (officeId) params.append('officeId', officeId);
  if (providerId) params.append('providerId', providerId);

  const apiUrl = `https://pm-ci.eyefinity.com/al-pe/appointments/?${params}`;
  const token = process.env.EYEFINITY_STATIC_ACCESS_TOKEN;

  const response = await fetch(apiUrl, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    return NextResponse.json({ error: 'API error' }, { status: response.status });
  }

  const data = await response.json();
  return NextResponse.json(data);
}
```

### Patients Route
```typescript
// src/app/api/patients/route.ts
import { NextResponse } from 'next/server';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const params = new URLSearchParams();

  ['lastName', 'firstName', 'dob', 'gender', 'page', 'pageSize'].forEach(param => {
    const value = searchParams.get(param);
    if (value) params.append(param, value);
  });

  if (!params.has('page')) params.append('page', '1');
  if (!params.has('pageSize')) params.append('pageSize', '50');

  const url = `https://pm-ci.eyefinity.com/al-pe/patients?${params}`;
  const token = process.env.EYEFINITY_STATIC_ACCESS_TOKEN;

  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    return NextResponse.json({ error: 'API error' }, { status: response.status });
  }

  return NextResponse.json(await response.json());
}
```

---

## Usage Examples

### Search Patients
```typescript
const patients = await fetch('/api/patients?lastName=Smith&firstName=John')
  .then(res => res.json());
```

### Get Appointments
```typescript
import { AppointmentService } from '@/lib/services/appointment-service';

const appointments = await AppointmentService.fetchAppointments(
  1,
  new Date('2024-01-01'),
  new Date('2024-12-31'),
  '10128' // officeId
);
```

### Get Available Slots
```typescript
import { EyefinityService } from '@/lib/services/eyefinity-service';

const slots = await EyefinityService.getAppointmentSlots('10128', {
  fromDate: '2025-01-01',
  toDate: '2025-03-31',
  itemDuration: 30
});
```

### Update Patient Contact
```typescript
import { EyefinityService } from '@/lib/services/eyefinity-service';

await EyefinityService.updatePatientContactInfo('123456', {
  email: 'patient@example.com',
  phone: '555-1234'
});
```

---

## Testing

### Test All Endpoints
```typescript
// src/app/api/eyefinity/test-all/route.ts
import { NextResponse } from 'next/server';

const BASE_URL = 'https://pm-ci.eyefinity.com/al-pe';

export async function GET() {
  const token = process.env.EYEFINITY_STATIC_ACCESS_TOKEN;
  const results = [];

  const testEndpoint = async (name: string, url: string) => {
    try {
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        }
      });
      return { endpoint: name, status: response.ok ? 'success' : 'error', code: response.status };
    } catch (error) {
      return { endpoint: name, status: 'error', error: String(error) };
    }
  };

  results.push(await testEndpoint('Offices', `${BASE_URL}/offices?page=1&pageSize=5`));
  results.push(await testEndpoint('Patients', `${BASE_URL}/patients?lastName=Smith&page=1`));
  results.push(await testEndpoint('Appointments', `${BASE_URL}/appointments/?fromDate=2024-01-01&toDate=2024-12-31`));
  results.push(await testEndpoint('Providers', `${BASE_URL}/providers?page=1`));

  return NextResponse.json({ results });
}
```

---

## Troubleshooting

### CORS Issues
**Always use server-side proxies** - Never call Eyefinity APIs from frontend/browser

```typescript
// ❌ Wrong
fetch('https://pm-ci.eyefinity.com/al-pe/patients');

// ✅ Correct
fetch('/api/patients');
```

### 401 Unauthorized
- Check token is valid and not expired
- Verify token audience matches domain (`pm-ci.eyefinity.com`)
- Ensure token has required scopes

### 404 Not Found
- Verify endpoint path is correct
- Check patient/appointment IDs exist in the system
- Confirm API version (v1 vs v2)

---

## Dependencies

```json
{
  "dependencies": {
    "axios": "^1.6.0"
  }
}
```

---

## Summary

This integration provides:
- ✅ **Office Management** - List and query offices
- ✅ **Patient Management** - Search, view, update patient data
- ✅ **Appointment Management** - Full CRUD + slot availability
- ✅ **Provider Management** - List providers
- ✅ **Insurance Management** - Query insurance carriers
- ✅ **CORS-Safe** - Server-side proxy routes
- ✅ **TypeScript** - Fully typed interfaces
- ✅ **Tested** - Comprehensive test suite included

**Base URL**: `https://pm-ci.eyefinity.com/al-pe`  
**Auth**: Bearer token (static or OAuth 2.0)
