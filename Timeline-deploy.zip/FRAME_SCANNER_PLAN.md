# Patient Self-Service Frame Scanner & Measurement Tool

## Feature Overview
Patient-facing web application where patients can:
1. **Scan frame UPC codes** to build a favorites list
2. **Take facial measurements** (PD, seg height, OC height) using their phone camera
3. **Utilize iPhone LiDAR** for enhanced 3D measurements

---

## Technology Research

### 1. UPC Barcode Scanning (Web)

#### **Best Libraries:**
- **QuaggaJS** - Most mature, supports UPC-A/E, EAN-13/8
  - Real-time scanning from camera feed
  - Works on mobile browsers
  - ~30KB gzipped
  
- **ZXing ("Zebra Crossing")** - Google's barcode library
  - Browser version: `@zxing/browser`
  - Supports 1D and 2D barcodes
  - More accurate but heavier (~100KB)

- **Html5-QRCode** - Modern, actively maintained
  - Supports QR and barcodes
  - Good mobile support
  - Built-in UI components

#### **Implementation:**
```javascript
import Quagga from 'quagga';

Quagga.init({
  inputStream: {
    type: "LiveStream",
    target: document.querySelector('#scanner'),
    constraints: {
      facingMode: "environment" // Back camera
    }
  },
  decoder: {
    readers: ["upc_reader", "ean_reader"]
  }
}, (err) => {
  Quagga.start();
});

Quagga.onDetected((result) => {
  const code = result.codeResult.code;
  // Save to favorites
});
```

---

### 2. Camera Access & Face Tracking

#### **WebRTC MediaDevices API:**
```javascript
const stream = await navigator.mediaDevices.getUserMedia({
  video: {
    facingMode: 'user',
    width: { ideal: 1920 },
    height: { ideal: 1080 }
  }
});
```

#### **Face Detection Libraries:**

**A. MediaPipe Face Mesh (Google)**
- **Best choice for measurements**
- 468 3D facial landmarks
- Real-time tracking (60fps)
- Works on mobile browsers
- Free and open source

```javascript
import { FaceMesh } from '@mediapipe/face_mesh';

const faceMesh = new FaceMesh({
  locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`
});

faceMesh.onResults((results) => {
  if (results.multiFaceLandmarks) {
    const landmarks = results.multiFaceLandmarks[0];
    // Calculate PD, seg height, etc.
  }
});
```

**B. TensorFlow.js Face Landmarks Detection**
- Alternative to MediaPipe
- More control over model
- Slightly heavier

**C. WebGazer.js**
- Eye tracking focused
- Good for pupil distance
- Calibration required

---

### 3. iPhone LiDAR Access

#### **Current State (2026):**

**WebXR Device API:**
- Standard for AR/VR in browsers
- **Supports depth sensing on iOS 16+**
- Requires user permission

```javascript
// Check for depth sensing support
const session = await navigator.xr.requestSession('immersive-ar', {
  requiredFeatures: ['depth-sensing'],
  depthSensing: {
    usagePreference: ['cpu-optimized'],
    dataFormatPreference: ['luminance-alpha']
  }
});

session.requestAnimationFrame((time, frame) => {
  const depthInfo = frame.getDepthInformation(referenceSpace);
  // Use depth data for precise measurements
});
```

**Limitations:**
- Only works in immersive AR mode (fullscreen)
- Requires HTTPS
- iOS Safari 15.4+ only
- User must grant camera + motion permissions

**Fallback:**
- Use computer vision for depth estimation without LiDAR
- MediaPipe provides reasonable depth from monocular camera

---

### 4. Optical Measurements

#### **PD (Pupillary Distance):**
```javascript
// Using MediaPipe landmarks
function calculatePD(landmarks) {
  // Right pupil: landmark 468
  // Left pupil: landmark 473
  const rightPupil = landmarks[468];
  const leftPupil = landmarks[473];
  
  // Calculate pixel distance
  const pixelDistance = Math.sqrt(
    Math.pow(rightPupil.x - leftPupil.x, 2) +
    Math.pow(rightPupil.y - leftPupil.y, 2)
  );
  
  // Convert to mm using reference object or calibration
  const pdMm = pixelDistance * calibrationFactor;
  return pdMm;
}
```

**Calibration Methods:**
1. **Credit card reference** - Known width (85.6mm)
2. **QR code with known size**
3. **User's existing glasses PD**
4. **LiDAR depth for scale**

#### **Seg Height / OC Height:**
```javascript
function calculateSegHeight(landmarks) {
  // Pupil center
  const pupil = landmarks[468];
  
  // Bottom of frame (user positions marker)
  const frameBottom = userMarkedPoint;
  
  // Vertical distance in mm
  const segHeightMm = (frameBottom.y - pupil.y) * calibrationFactor;
  return segHeightMm;
}
```

**Frame Detection:**
- User places physical markers on frame
- Or: AI detects frame edges (requires training)
- Or: User manually traces frame outline

---

## Implementation Plan

### **Phase 1: UPC Scanner & Favorites (Week 1-2)**

#### Components:
1. **`/patient/frame-scanner`** - Public link sent to patient
2. **Frame Scanner Modal** - Camera view with UPC scanning
3. **Favorites List** - Saved frames with details
4. **Frame Database Integration** - Look up frame info by UPC

#### Database Schema:
```sql
CREATE TABLE patient_favorite_frames (
  id UUID PRIMARY KEY,
  patient_id UUID REFERENCES patients(id),
  upc_code VARCHAR(13),
  frame_name VARCHAR(255),
  frame_manufacturer VARCHAR(255),
  frame_model VARCHAR(255),
  frame_color VARCHAR(100),
  scanned_at TIMESTAMP DEFAULT NOW(),
  image_url TEXT,
  notes TEXT
);
```

#### API Endpoints:
- `POST /api/patient/frames/scan` - Save scanned frame
- `GET /api/patient/frames` - Get patient's favorites
- `DELETE /api/patient/frames/:id` - Remove favorite
- `GET /api/frames/lookup/:upc` - Get frame details from UPC

---

### **Phase 2: Calibration & Basic Measurements (Week 3-4)**

#### Features:
1. **Credit Card Calibration** - User scans credit card for scale
2. **Face Detection** - MediaPipe integration
3. **PD Measurement** - Basic pupil distance
4. **Results Screen** - Display measurements with confidence score

#### Components:
- **`/patient/measurements`** - Measurement tool page
- **Calibration Step** - Guide user to scan reference object
- **Face Capture** - Take photo with detected landmarks
- **Review Screen** - Show measurements, allow retake

---

### **Phase 3: Frame-On Measurements (Week 5-6)**

#### Features:
1. **Frame Detection** - User marks frame corners/edges
2. **Seg Height** - Measure from pupil to frame bottom
3. **OC Height** - Optical center height
4. **Frame Tracing** - AR overlay to guide user

#### UI Flow:
1. Put on glasses
2. Center face in camera
3. Tap to mark frame edges
4. Auto-calculate seg/OC heights
5. Review and save

---

### **Phase 4: LiDAR Enhancement (Week 7-8)**

#### Features:
1. **WebXR Integration** - AR mode for iPhone
2. **3D Face Mesh** - Enhanced with depth data
3. **Precise Measurements** - Sub-millimeter accuracy
4. **Face Shape Analysis** - Recommend frames based on face

#### Fallback Strategy:
- Detect if LiDAR available → use WebXR
- If not → use MediaPipe monocular depth estimation
- Always show confidence score

---

## Technical Architecture

### **Frontend:**
```
/src/pages/patient/
  FrameScanner.jsx         - UPC scanning page
  Measurements.jsx          - Measurement tool page
  FavoriteFrames.jsx        - View saved frames

/src/components/patient/
  UPCScanner.jsx           - QuaggaJS wrapper
  FaceCapture.jsx          - MediaPipe camera
  CalibrationGuide.jsx     - Step-by-step calibration
  MeasurementOverlay.jsx   - AR landmarks display
  FrameMarkers.jsx         - Mark frame edges
  LiDARScanner.jsx         - WebXR integration

/src/lib/services/
  frame-scanner-service.ts  - UPC lookup & database
  measurement-service.ts    - PD/seg/OC calculations
  calibration-service.ts    - Scale factor management
  lidar-service.ts          - WebXR depth sensing
```

### **Backend APIs:**
```
/api/patient/
  frame-scan.js            - Save scanned UPC
  frames.js                - CRUD for favorites
  measurements.js          - Save measurement results

/api/frames/
  lookup.js                - UPC → frame details
  catalog.js               - Browse available frames
```

---

## Database Schema

```sql
-- Patient favorite frames
CREATE TABLE patient_favorite_frames (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES patients(id),
  company_id UUID REFERENCES companies(id),
  upc_code VARCHAR(13) NOT NULL,
  frame_name VARCHAR(255),
  frame_manufacturer VARCHAR(255),
  frame_model VARCHAR(255),
  frame_color VARCHAR(100),
  frame_size VARCHAR(50),
  scanned_at TIMESTAMP DEFAULT NOW(),
  image_url TEXT,
  notes TEXT,
  is_purchased BOOLEAN DEFAULT FALSE,
  UNIQUE(patient_id, upc_code)
);

-- Patient measurements
CREATE TABLE patient_measurements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES patients(id),
  company_id UUID REFERENCES companies(id),
  measured_at TIMESTAMP DEFAULT NOW(),
  
  -- Measurements in mm
  pd_right DECIMAL(4,1),
  pd_left DECIMAL(4,1),
  pd_total DECIMAL(4,1),
  seg_height_right DECIMAL(4,1),
  seg_height_left DECIMAL(4,1),
  oc_height_right DECIMAL(4,1),
  oc_height_left DECIMAL(4,1),
  
  -- Frame info if wearing during measurement
  frame_id UUID REFERENCES patient_favorite_frames(id),
  
  -- Metadata
  measurement_method VARCHAR(50), -- 'camera', 'lidar', 'manual'
  calibration_factor DECIMAL(8,4),
  confidence_score DECIMAL(3,2), -- 0.00 - 1.00
  device_type VARCHAR(100),
  has_lidar BOOLEAN,
  
  -- Raw data
  face_landmarks JSONB,
  frame_markers JSONB,
  image_url TEXT,
  
  -- Validation
  verified_by_staff UUID REFERENCES staff(id),
  verified_at TIMESTAMP,
  notes TEXT
);

-- Frame catalog (for UPC lookup)
CREATE TABLE frame_catalog (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  upc_code VARCHAR(13) UNIQUE NOT NULL,
  manufacturer VARCHAR(255),
  brand VARCHAR(255),
  model_name VARCHAR(255),
  model_number VARCHAR(100),
  color_name VARCHAR(100),
  color_code VARCHAR(50),
  
  -- Dimensions
  lens_width INTEGER,
  bridge_width INTEGER,
  temple_length INTEGER,
  frame_width INTEGER,
  
  -- Details
  material VARCHAR(100),
  frame_type VARCHAR(50), -- 'full-rim', 'semi-rimless', 'rimless'
  shape VARCHAR(50), -- 'rectangle', 'oval', 'round', 'cat-eye'
  
  -- Pricing
  wholesale_price DECIMAL(10,2),
  retail_price DECIMAL(10,2),
  
  -- Media
  image_url TEXT,
  additional_images JSONB,
  
  -- Metadata
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

---

## Patient Communication Flow

### **1. Send Link to Patient:**
```javascript
// In PatientReadinessCenter
const sendFrameScannerLink = async (patientId) => {
  const token = generatePatientToken(patientId);
  const link = `${window.location.origin}/patient/frames?token=${token}`;
  
  await CommunicationService.sendSMS(patient.phone, 
    `Hi ${patient.firstName}! Try our Frame Finder: ${link}\n` +
    `Scan frames you like and take measurements from home!`
  );
};
```

### **2. Patient Landing Page:**
- No login required (token-based)
- Mobile-optimized
- Clear instructions
- Privacy notice

### **3. Results Shared with Office:**
- Real-time updates in PRC
- Staff can review measurements
- Approve or request retake
- Add to patient chart

---

## UI/UX Design

### **Frame Scanner Screen:**
```
┌─────────────────────────────┐
│  Frame Finder              │
│                            │
│  ┌─────────────────────┐  │
│  │                     │  │
│  │   [CAMERA VIEW]     │  │
│  │                     │  │
│  │   "Point camera at  │  │
│  │    barcode on       │  │
│  │    frame arm"       │  │
│  │                     │  │
│  └─────────────────────┘  │
│                            │
│  [═════════] 3 Frames     │
│   Scanned                  │
│                            │
│  [View My Favorites]       │
└─────────────────────────────┘
```

### **Measurement Screen:**
```
┌─────────────────────────────┐
│  Take Measurements         │
│                            │
│  Step 1: Calibration       │
│  ✓ Credit card scanned     │
│                            │
│  Step 2: Face Photo        │
│  ┌─────────────────────┐  │
│  │                     │  │
│  │   [YOUR FACE]       │  │
│  │   ●────────●        │  │
│  │   │        │        │  │
│  │   │   👃   │        │  │
│  │                     │  │
│  └─────────────────────┘  │
│                            │
│  PD: 63.5mm ✓             │
│  Confidence: 95%           │
│                            │
│  [Retake] [Save]          │
└─────────────────────────────┘
```

---

## Security & Privacy

### **Patient Token:**
```javascript
// Generate time-limited token
const token = jwt.sign(
  { patientId, companyId, type: 'frame-scanner' },
  process.env.PATIENT_TOKEN_SECRET,
  { expiresIn: '7d' }
);
```

### **Data Privacy:**
- Images deleted after processing (optional keep with consent)
- Measurements encrypted at rest
- HIPAA compliant storage
- Patient can delete data anytime

### **Permissions:**
```javascript
// Request camera access
const stream = await navigator.mediaDevices.getUserMedia({
  video: {
    facingMode: 'user',
    width: { ideal: 1920 },
    height: { ideal: 1080 }
  }
});

// Request motion/LiDAR (iOS)
if (typeof DeviceMotionEvent !== 'undefined' && 
    typeof DeviceMotionEvent.requestPermission === 'function') {
  const permission = await DeviceMotionEvent.requestPermission();
}
```

---

## Dependencies

### **NPM Packages:**
```json
{
  "dependencies": {
    "@mediapipe/face_mesh": "^0.4.1",
    "quagga": "^0.12.1",
    "@tensorflow/tfjs": "^4.15.0",
    "three": "^0.160.0",
    "jsonwebtoken": "^9.0.2"
  }
}
```

### **Browser Requirements:**
- Modern browser with WebRTC support
- Camera access
- iOS 15.4+ for LiDAR (optional)
- HTTPS required

---

## Testing Strategy

### **Accuracy Validation:**
1. **Control Group** - Professional measurements vs app
2. **Target Accuracy:**
   - PD: ±1mm acceptable, ±0.5mm target
   - Seg Height: ±2mm acceptable, ±1mm target
3. **Sample Size** - 100+ patients across demographics

### **Device Testing:**
- iPhone 12 Pro+ (LiDAR)
- iPhone 11 and below (no LiDAR)
- Android flagship
- Android mid-range
- iPad

### **Edge Cases:**
- Poor lighting
- Glasses with tint
- Asymmetric faces
- Children vs adults
- Various skin tones

---

## Rollout Plan

### **Phase 1 (Weeks 1-2): MVP**
- UPC scanning only
- Manual favorites list
- No measurements yet
- Beta test with 10 patients

### **Phase 2 (Weeks 3-4): Basic Measurements**
- Add PD measurement
- Calibration required
- Staff review required
- Expand to 50 patients

### **Phase 3 (Weeks 5-6): Frame-On Measurements**
- Seg/OC height
- Frame detection
- Confidence scores
- 100+ patients

### **Phase 4 (Weeks 7-8): LiDAR Polish**
- WebXR for iPhone Pro users
- Enhanced accuracy
- Face shape analysis
- Full launch

---

## Success Metrics

### **Engagement:**
- % of patients who use link
- Frames scanned per patient
- Measurement completion rate

### **Accuracy:**
- Measurements within ±1mm of professional
- Staff approval rate
- Retake rate

### **Business Impact:**
- Increased frame sales
- Reduced in-office measurement time
- Patient satisfaction scores
- Conversion rate (scan → purchase)

---

## Future Enhancements

### **Virtual Try-On:**
- AR overlay of frames on face
- See how frames look before buying
- Use 3D face mesh + frame models

### **AI Frame Recommendations:**
- Analyze face shape
- Recommend flattering styles
- Match to inventory

### **Frame Fit Analysis:**
- Predict if frame will fit
- Recommend size adjustments
- Alert if measurements outside range

### **Social Sharing:**
- Share favorites with family/friends
- Get feedback on frame choices
- Instagram/Snapchat integration

---

## Cost Estimate

### **Development (8 weeks):**
- Senior Dev: $150/hr × 320hr = $48,000
- Design: $100/hr × 40hr = $4,000
- **Total:** ~$52,000

### **Infrastructure (Monthly):**
- Media storage: $50/mo
- API calls: $20/mo
- **Total:** ~$70/mo

### **ROI:**
- If 10% of patients use it
- Average 3 frames scanned per patient
- 20% conversion rate
- $200 margin per frame
- **Revenue:** Significant increase in frame sales
