/**
 * Test script to prove staging endpoints work without VPN
 */
import https from 'https';

const EPM_CLIENT_ID = 'ef-productmgmt-test-client';
const EPM_CLIENT_SECRET = 'VD24uag29VepKKeG1zuSMXKuXg6Q9bXEvCM3csm9cb3sX84GCLh7P20UUdFucToB';
const TENANT_UID = '12345678-1234-1234-1234-123456789012';
const OAUTH_HOST = 'login-uswest2.integration.eyefinity.com';

const EPM_SCOPES = [
  'auth_epm',
  'ef.pm_pe_patient_rx',
  'ef.pm_pe_resource',
  'ef.pm_pe_insurance',
  'ef.pm_pe_appointment',
  'ef.pm_pe_office_recallreport',
  'ef.pm_pe_staff',
  'ef.pm_pe_office',
  'ef.pm_pe_company',
  'ef.pm_pe_order',
  'ef.pm_pe_provider',
  'ef.pm_pe_patient',
].join(' ');

function makeRequest(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          if (res.statusCode >= 400) {
            reject(new Error(`HTTP ${res.statusCode}: ${data}`));
          } else {
            resolve({ status: res.statusCode, data: JSON.parse(data) });
          }
        } catch (e) {
          reject(new Error(`Parse error: ${data}`));
        }
      });
    });
    
    req.on('error', reject);
    req.setTimeout(10000, () => {
      req.destroy();
      reject(new Error('Request timeout after 10s'));
    });
    
    if (postData) req.write(postData);
    req.end();
  });
}

async function testStagingEndpoints() {
  console.log('🔧 Testing Staging Endpoints (No VPN Required)\n');
  console.log('━'.repeat(60));
  
  try {
    // Step 1: Client Credentials
    console.log('\n1️⃣  Getting Client Credentials Token...');
    console.log(`   Host: ${OAUTH_HOST}`);
    
    const credentials = Buffer.from(`${EPM_CLIENT_ID}:${EPM_CLIENT_SECRET}`).toString('base64');
    const ccPostData = `grant_type=client_credentials&scope=${encodeURIComponent(EPM_SCOPES)}`;
    
    const ccResult = await makeRequest({
      hostname: OAUTH_HOST,
      port: 443,
      path: '/as/token.oauth2',
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(ccPostData),
      },
    }, ccPostData);
    
    const ccToken = ccResult.data.access_token || ccResult.data.accesstoken;
    console.log(`   ✅ Success! Got token (${ccToken.substring(0, 20)}...)`);
    
    // Step 2: Token Exchange
    console.log('\n2️⃣  Exchanging for EPM Token...');
    
    const exchangePostData = new URLSearchParams({
      'grant_type': 'urn:ietf:params:oauth:grant-type:token-exchange',
      'subject_token': ccToken,
      'subject_token_type': 'urn:ietf:params:oauth:token-type:access_token',
      'scope': EPM_SCOPES,
      'resource': 'https://VspEpmToken',
    }).toString();
    
    const exchangeResult = await makeRequest({
      hostname: OAUTH_HOST,
      port: 443,
      path: '/as/token.oauth2',
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(exchangePostData),
        'tenantuid': TENANT_UID,
      },
    }, exchangePostData);
    
    const epmToken = exchangeResult.data.access_token || exchangeResult.data.accesstoken;
    console.log(`   ✅ Success! Got EPM token (${epmToken.substring(0, 20)}...)`);
    
    // Step 3: Test API Call
    console.log('\n3️⃣  Testing API Call to api-integration.eyefinity.com...');
    console.log('   GET /al-pe/v2offices?page=1&pageSize=5');
    
    const apiResult = await makeRequest({
      hostname: 'api-integration.eyefinity.com',
      port: 443,
      path: '/al-pe/v2offices?page=1&pageSize=5',
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${epmToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    });
    
    const offices = apiResult.data;
    console.log(`   ✅ Success! Retrieved ${offices.length} offices`);
    console.log(`\n   First office: ${offices[0]?.officeName || 'N/A'}`);
    
    console.log('\n━'.repeat(60));
    console.log('✅ ALL TESTS PASSED - Staging endpoints work without VPN!');
    console.log('━'.repeat(60));
    console.log('\n📝 Update Vercel environment variable:');
    console.log('   EYEFINITY_API_URL=https://api-integration.eyefinity.com');
    console.log('   OAUTH_HOST=login-uswest2.staging.eyefinity.com\n');
    
  } catch (error) {
    console.error('\n❌ Test failed:', error.message);
    console.log('\n━'.repeat(60));
    process.exit(1);
  }
}

testStagingEndpoints();
