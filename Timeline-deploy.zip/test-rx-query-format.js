#!/usr/bin/env node

/**
 * Test RX API with query parameter format: /rx?id={legacyId}
 * User confirmed this format works!
 */

console.log('🔥 TESTING RX API - QUERY PARAMETER FORMAT');
console.log('════════════════════════════════════════════════════════════════════════');

const testIds = [
  '1166950', // User's specific ID
  '1080416', // Previous example
  '1166951', // Variation
];

const formatValue = (value) => {
  if (value === null || value === undefined) return '⚪ null';
  if (value === '') return '⚪ empty';
  return value;
};

const displayRxData = (rxItems, legacyId) => {
  console.log(`\n💊 RX DATA FOR ID ${legacyId} (${rxItems.length} items):`);
  console.log('═'.repeat(80));
  
  if (rxItems.length > 0) {
    rxItems.slice(0, 5).forEach((rx, i) => {
      console.log(`\n📋 Prescription ${i + 1}:`);
      console.log('─'.repeat(60));
      console.log(`   RX Number................: ${formatValue(rx.RxNumber)}`);
      console.log(`   Date Prescribed..........: ${formatValue(rx.DatePrescribed)}`);
      console.log(`   Product Type.............: ${formatValue(rx.Product)}`);
      console.log(`   Status...................: ${formatValue(rx.Status)}`);
      console.log(`   Provider.................: ${formatValue(rx.ProviderName)}`);
      console.log(`   OD Sphere................: ${formatValue(rx.OdSphere)}`);
      console.log(`   OD Cylinder..............: ${formatValue(rx.OdCylinder)}`);
      console.log(`   OD Axis..................: ${formatValue(rx.OdAxis)}`);
      console.log(`   OS Sphere................: ${formatValue(rx.OsSphere)}`);
      console.log(`   OS Cylinder..............: ${formatValue(rx.OsCylinder)}`);
      console.log(`   OS Axis..................: ${formatValue(rx.OsAxis)}`);
      console.log(`   Add Power................: ${formatValue(rx.AddPower)}`);
      console.log(`   PD.......................: ${formatValue(rx.PupillaryDistance || rx.PD)}`);
      console.log(`   Expiration Date..........: ${formatValue(rx.ExpirationDate)}`);
      console.log(`   Notes....................: ${formatValue(rx.Notes)}`);
    });
    
    if (rxItems.length > 5) {
      console.log(`\n   ... and ${rxItems.length - 5} more prescriptions`);
    }
    
    // Show RX summary stats
    console.log(`\n📊 RX SUMMARY:`);
    console.log(`   Total Prescriptions: ${rxItems.length}`);
    
    const statuses = rxItems.reduce((acc, rx) => {
      const status = rx.Status || 'Unknown';
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {});
    
    console.log(`   Status Distribution:`);
    Object.entries(statuses).forEach(([status, count]) => {
      console.log(`     - ${status}: ${count}`);
    });
    
    const providers = [...new Set(rxItems.map(rx => rx.ProviderName).filter(Boolean))];
    if (providers.length > 0) {
      console.log(`   Providers: ${providers.join(', ')}`);
    }
    
    return true;
  } else {
    console.log('   📭 No prescriptions found for this patient');
    return false;
  }
};

const testRxQueryFormat = async (legacyId) => {
  try {
    console.log(`\n🧪 Testing RX Query Format: /rx?id=${legacyId}`);
    
    const url = `https://patientcare-teal.vercel.app/api/eyefinity/rx?id=${legacyId}&page=1&pageSize=500`;
    console.log(`   URL: ${url}`);
    
    const startTime = Date.now();
    const response = await fetch(url);
    const duration = Date.now() - startTime;
    
    console.log(`   Status: ${response.status} ${response.statusText} (${duration}ms)`);
    
    if (response.ok) {
      const data = await response.json();
      const rxItems = data.items || data || [];
      
      console.log(`   🎉 SUCCESS! RX endpoint works with query format!`);
      
      const hasRxData = displayRxData(rxItems, legacyId);
      
      return { 
        success: true, 
        legacyId, 
        rxCount: rxItems.length, 
        hasData: hasRxData,
        data: data,
        duration 
      };
    } else {
      console.log(`   ❌ Failed: ${response.status}`);
      
      if (response.status === 400) {
        const text = await response.text();
        console.log(`   Error details: ${text.substring(0, 200)}`);
      }
      
      return { 
        success: false, 
        legacyId, 
        status: response.status,
        duration 
      };
    }
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
    return { 
      success: false, 
      legacyId, 
      error: error.message 
    };
  }
};

const runRxQueryTests = async () => {
  console.log('\n🚀 TESTING RX QUERY PARAMETER FORMAT');
  console.log('User says this format works - let\'s find it!');
  console.log('═'.repeat(80));
  
  const results = [];
  
  for (let i = 0; i < testIds.length; i++) {
    const legacyId = testIds[i];
    const result = await testRxQueryFormat(legacyId);
    results.push(result);
    
    if (i < testIds.length - 1) {
      console.log('\n' + '─'.repeat(100));
    }
  }
  
  console.log('\n\n🎯 TEST RESULTS SUMMARY:');
  console.log('═'.repeat(80));
  
  const successful = results.filter(r => r.success);
  const withData = results.filter(r => r.success && r.hasData);
  
  console.log(`\n📊 QUERY FORMAT RESULTS (/rx?id={legacyId}):`);
  console.log(`   ✅ Successful: ${successful.length}/${results.length}`);
  console.log(`   📦 With RX Data: ${withData.length}/${results.length}`);
  
  if (successful.length > 0) {
    console.log(`\n✅ WORKING ENDPOINTS:`);
    successful.forEach(r => {
      const dataStatus = r.hasData ? `${r.rxCount} prescriptions` : 'empty';
      console.log(`   ✅ /rx?id=${r.legacyId} - ${dataStatus}`);
    });
  }
  
  if (withData.length > 0) {
    console.log(`\n🎉 RX ENDPOINT FOUND AND WORKING!`);
    console.log(`   Format: /api/eyefinity/rx?id={legacyId}`);
    console.log(`   User was RIGHT - this format works!`);
    
    const workingResult = withData[0];
    console.log(`\n💡 NEXT STEPS:`);
    console.log(`   1. Update EyefinityService.getPatientRx to use /rx?id={legacyId} format`);
    console.log(`   2. Convert GUID to Legacy ID when needed`);
    console.log(`   3. Test in Patient Readiness Center`);
    
  } else if (successful.length > 0) {
    console.log(`\n✅ RX ENDPOINT WORKS but no data for these patients`);
    console.log(`   Format: /api/eyefinity/rx?id={legacyId}`);
    console.log(`   Need to find patients with RX data`);
    
  } else {
    console.log(`\n❌ RX endpoint still not working with query format`);
    console.log(`   All tested IDs returned errors`);
    console.log(`   May need different API approach or parameters`);
  }
  
  // Test additional variations if initial tests don't work
  if (withData.length === 0) {
    console.log('\n🔄 TRYING ADDITIONAL RX ENDPOINT VARIATIONS...');
    console.log('═'.repeat(80));
    
    const variations = [
      `/api/eyefinity/prescriptions?patientId=${testIds[0]}`,
      `/api/eyefinity/v2prescriptions?patientId=${testIds[0]}`,
      `/api/eyefinity/v2rx?id=${testIds[0]}`,
      `/api/eyefinity/patient-rx?id=${testIds[0]}`,
    ];
    
    for (const endpoint of variations) {
      console.log(`\n🧪 Testing: ${endpoint}`);
      try {
        const response = await fetch(`https://patientcare-teal.vercel.app${endpoint}&page=1&pageSize=10`);
        console.log(`   Status: ${response.status} ${response.statusText}`);
        
        if (response.ok) {
          console.log(`   🎉 FOUND WORKING VARIATION: ${endpoint}`);
          break;
        }
      } catch (error) {
        console.log(`   ❌ Error: ${error.message}`);
      }
    }
  }
};

runRxQueryTests().catch(console.error);
