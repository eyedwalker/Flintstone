#!/usr/bin/env node

/**
 * Exhaustive test of all possible RX endpoint variations
 * User insists this works - let's find the correct format
 */

console.log('🔍 EXHAUSTIVE RX ENDPOINT TESTING');
console.log('════════════════════════════════════════════════════════════════════════');

const testId = '1166950'; // User's confirmed working ID

// Try every possible RX endpoint variation
const endpointVariations = [
  // Basic rx endpoints
  `/api/eyefinity/rx?id=${testId}`,
  `/api/eyefinity/rx?patientId=${testId}`,
  `/api/eyefinity/rx?legacyId=${testId}`,
  `/api/eyefinity/rx/${testId}`,
  
  // V1 patients rx
  `/api/eyefinity/patients/${testId}/rx`,
  `/api/eyefinity/patients/rx?id=${testId}`,
  `/api/eyefinity/patients/rx?patientId=${testId}`,
  
  // V2 patients rx  
  `/api/eyefinity/v2patients/${testId}/rx`,
  `/api/eyefinity/v2patients/rx?id=${testId}`,
  `/api/eyefinity/v2patients/rx?patientId=${testId}`,
  
  // Prescriptions variations
  `/api/eyefinity/prescriptions?id=${testId}`,
  `/api/eyefinity/prescriptions?patientId=${testId}`,
  `/api/eyefinity/prescriptions/${testId}`,
  
  // V2 prescriptions
  `/api/eyefinity/v2prescriptions?id=${testId}`,
  `/api/eyefinity/v2prescriptions?patientId=${testId}`,
  `/api/eyefinity/v2prescriptions/${testId}`,
  
  // Alternative rx formats
  `/api/eyefinity/patient-prescriptions?id=${testId}`,
  `/api/eyefinity/patient-rx?id=${testId}`,
  `/api/eyefinity/rxdata?id=${testId}`,
  `/api/eyefinity/v2rx?id=${testId}`,
  
  // Medical record variations
  `/api/eyefinity/medical/rx?patientId=${testId}`,
  `/api/eyefinity/clinical/rx?patientId=${testId}`,
  
  // Without /al-pe prefix (direct API)
  `https://api-sandbox.eyefinity.com/al-pe/rx?id=${testId}`,
  `https://api-sandbox.eyefinity.com/al-pe/patients/${testId}/rx`,
  `https://api-sandbox.eyefinity.com/al-pe/v2patients/${testId}/rx`,
  
  // Try with different parameter names
  `/api/eyefinity/rx?patient_id=${testId}`,
  `/api/eyefinity/rx?legacy_id=${testId}`,
  `/api/eyefinity/rx?pid=${testId}`,
  `/api/eyefinity/rx?clientId=${testId}`,
];

const testEndpoint = async (endpoint, index, total) => {
  try {
    console.log(`\n[${(index + 1).toString().padStart(2, '0')}/${total}] Testing: ${endpoint}`);
    
    let url;
    if (endpoint.startsWith('https://')) {
      url = endpoint + '&page=1&pageSize=100';
    } else {
      url = `https://patientcare-teal.vercel.app${endpoint}${endpoint.includes('?') ? '&' : '?'}page=1&pageSize=100`;
    }
    
    console.log(`   Full URL: ${url}`);
    
    const response = await fetch(url);
    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    if (response.ok) {
      const data = await response.json();
      const itemCount = data.items?.length || (Array.isArray(data) ? data.length : 0);
      
      console.log(`   🎉 SUCCESS! Found ${itemCount} items`);
      
      if (itemCount > 0) {
        console.log(`   📋 Sample data keys: ${Object.keys(data.items?.[0] || data[0] || {}).slice(0, 6).join(', ')}`);
        
        return {
          success: true,
          endpoint,
          itemCount,
          hasData: true,
          data
        };
      } else {
        console.log(`   ✅ Endpoint works but no data`);
        return {
          success: true,
          endpoint,
          itemCount: 0,
          hasData: false,
          data
        };
      }
    } else if (response.status === 400) {
      const text = await response.text();
      console.log(`   ⚠️  Bad Request: ${text.substring(0, 100)}`);
      return { success: false, endpoint, status: 400, error: text.substring(0, 200) };
    } else if (response.status === 401) {
      console.log(`   🔐 Unauthorized - may need authentication`);
      return { success: false, endpoint, status: 401 };
    } else {
      console.log(`   ❌ Failed: ${response.status}`);
      return { success: false, endpoint, status: response.status };
    }
    
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
    return { success: false, endpoint, error: error.message };
  }
};

const runExhaustiveTest = async () => {
  console.log(`\n🚀 Testing ${endpointVariations.length} RX endpoint variations with ID: ${testId}`);
  console.log('═'.repeat(80));
  
  const results = [];
  
  for (let i = 0; i < endpointVariations.length; i++) {
    const result = await testEndpoint(endpointVariations[i], i, endpointVariations.length);
    results.push(result);
    
    // If we find a working endpoint with data, highlight it immediately
    if (result.success && result.hasData) {
      console.log('\n🎊 BREAKTHROUGH! FOUND WORKING RX ENDPOINT!');
      console.log('═'.repeat(80));
      console.log(`✅ Working Endpoint: ${result.endpoint}`);
      console.log(`📊 Data Count: ${result.itemCount} items`);
      console.log('═'.repeat(80));
    }
    
    console.log('─'.repeat(60));
  }
  
  console.log('\n\n🎯 COMPREHENSIVE RESULTS:');
  console.log('═'.repeat(80));
  
  const successful = results.filter(r => r.success);
  const withData = results.filter(r => r.success && r.hasData);
  const badRequest = results.filter(r => r.status === 400);
  const unauthorized = results.filter(r => r.status === 401);
  
  console.log(`\n📊 ENDPOINT TEST SUMMARY:`);
  console.log(`   Total Tested: ${results.length}`);
  console.log(`   ✅ Successful (200): ${successful.length}`);
  console.log(`   📦 With RX Data: ${withData.length}`);
  console.log(`   ⚠️  Bad Request (400): ${badRequest.length}`);
  console.log(`   🔐 Unauthorized (401): ${unauthorized.length}`);
  console.log(`   ❌ Not Found (404): ${results.length - successful.length - badRequest.length - unauthorized.length}`);
  
  if (withData.length > 0) {
    console.log(`\n🎉 WORKING RX ENDPOINTS WITH DATA:`);
    withData.forEach(r => {
      console.log(`   🏆 ${r.endpoint} - ${r.itemCount} prescriptions`);
    });
    
    console.log(`\n💡 UPDATE EYEFINITY SERVICE:`);
    const bestEndpoint = withData[0];
    console.log(`   Use endpoint: ${bestEndpoint.endpoint}`);
    console.log(`   This format successfully returns RX data!`);
    
  } else if (successful.length > 0) {
    console.log(`\n✅ WORKING ENDPOINTS (but no data):`);
    successful.forEach(r => {
      console.log(`   ✅ ${r.endpoint} - works but empty`);
    });
    
  } else if (badRequest.length > 0) {
    console.log(`\n⚠️  BAD REQUEST ENDPOINTS (may need different parameters):`);
    badRequest.slice(0, 3).forEach(r => {
      console.log(`   ⚠️  ${r.endpoint}`);
      console.log(`       Error: ${r.error?.substring(0, 100) || 'Bad Request'}`);
    });
    
  } else if (unauthorized.length > 0) {
    console.log(`\n🔐 UNAUTHORIZED ENDPOINTS (authentication issue):`);
    unauthorized.slice(0, 3).forEach(r => {
      console.log(`   🔐 ${r.endpoint}`);
    });
    
  } else {
    console.log(`\n❌ NO WORKING RX ENDPOINTS FOUND`);
    console.log(`   All ${results.length} endpoint variations returned 404`);
    console.log(`   RX data may not be available in current API setup`);
  }
  
  // Special note if user insists it should work
  if (withData.length === 0) {
    console.log(`\n🤔 USER FEEDBACK NEEDED:`);
    console.log(`   You mentioned seeing RX endpoints work before.`);
    console.log(`   Can you provide:`);
    console.log(`   - Exact working URL you've seen`);
    console.log(`   - Different patient ID that has RX data`);
    console.log(`   - Different API base URL or environment`);
  }
};

runExhaustiveTest().catch(console.error);
