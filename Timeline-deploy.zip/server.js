/**
 * Express Server for Eyefinity PRC
 *
 * Wraps Vercel serverless API routes into a single Express server.
 * Serves the Vite build as static files.
 *
 * Vercel handler signature: export default function handler(req, res)
 * This is directly compatible with Express middleware.
 */

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import compression from 'compression';
import cors from 'cors';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 4000;
const distDir = path.join(__dirname, 'dist');

// Middleware
app.use(compression());
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

/**
 * Auth middleware — validates Bearer token from Redis sessions.
 * Skips public routes (auth, health, webhooks, patient forms, CORS preflight).
 */
const PUBLIC_PREFIXES = [
  '/api/auth/',
  '/api/webhooks/',
  '/api/patient/',
  '/api/forms/',
  '/api/voice/ai-call-response',
  '/api/voice/send-link',
  '/health',
];

async function authMiddleware(req, res, next) {
  // Skip OPTIONS (CORS preflight)
  if (req.method === 'OPTIONS') return next();

  // Skip non-API routes (static files, SPA)
  if (!req.path.startsWith('/api/')) return next();

  // Skip public routes
  if (PUBLIC_PREFIXES.some(p => req.path.startsWith(p))) return next();

  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.slice(7);
  try {
    const { kv } = await import('./api/_lib/kv.js');
    const session = await kv.get(`session:${token}`);
    if (!session) {
      return res.status(401).json({ error: 'Invalid or expired session' });
    }
    req.user = session;
    next();
  } catch (err) {
    console.error('[Auth Middleware] Error:', err.message);
    return res.status(500).json({ error: 'Auth service unavailable' });
  }
}

app.use(authMiddleware);

/**
 * Auto-discover and mount Vercel API routes.
 * Converts file paths to Express routes:
 *   api/auth/login.js        → /api/auth/login
 *   api/patients/[id].js     → /api/patients/:id
 *   api/eyefinity/[...path].js → /api/eyefinity/{*path} (catch-all)
 *   api/tasks/index.js       → /api/tasks
 */
async function mountApiRoutes() {
  const apiDir = path.join(__dirname, 'api');
  const routes = [];

  function scanDir(dir, prefix = '') {
    if (!fs.existsSync(dir)) return;
    const entries = fs.readdirSync(dir, { withFileTypes: true });

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);

      // Skip _lib directories (shared utilities, not routes)
      if (entry.name.startsWith('_')) continue;

      if (entry.isDirectory()) {
        scanDir(fullPath, `${prefix}/${entry.name}`);
      } else if (entry.name.endsWith('.js') || entry.name.endsWith('.mjs')) {
        let routeName = entry.name.replace(/\.(js|mjs)$/, '');
        let routePath;
        let priority = 0; // lower = mounted first (more specific)
        let catchAllParam = null;

        if (routeName === 'index') {
          routePath = prefix || '/';
        } else if (routeName.startsWith('[...')) {
          // Catch-all: [...path].js → Express 5 named wildcard
          const paramName = routeName.slice(4, -1); // extract 'path' from '[...path]'
          routePath = `${prefix}/{*${paramName}}`;
          priority = 100; // mount last (least specific)
          catchAllParam = paramName;
        } else if (routeName.startsWith('[') && routeName.endsWith(']')) {
          // Dynamic: [id].js → :id
          const paramName = routeName.slice(1, -1);
          routePath = `${prefix}/:${paramName}`;
          priority = 50; // mount after static routes
        } else {
          routePath = `${prefix}/${routeName}`;
        }

        routes.push({ routePath, fullPath, priority, catchAllParam });
      }
    }
  }

  scanDir(apiDir);

  // Sort by priority (static routes first, then dynamic, then catch-all)
  routes.sort((a, b) => a.priority - b.priority);

  let mounted = 0;
  for (const { routePath, fullPath, catchAllParam: catchAll } of routes) {
    try {
      const mod = await import(fullPath);
      const handler = mod.default;

      if (typeof handler === 'function') {
        const expressPath = `/api${routePath}`;
        app.all(expressPath, async (req, res, next) => {
          try {
            // Vercel compatibility: map Express params to req.query
            // Express 5 makes req.query immutable, so we must replace the entire object
            if (Object.keys(req.params).length > 0) {
              const mergedQuery = { ...req.query };
              for (const [key, val] of Object.entries(req.params)) {
                if (catchAll && key === catchAll) {
                  // Catch-all param — Vercel expects '...path' key with array value
                  mergedQuery[`...${key}`] = Array.isArray(val) ? val : typeof val === 'string' ? val.split('/').filter(Boolean) : [];
                } else if (typeof val === 'string') {
                  mergedQuery[key] = val;
                }
              }
              Object.defineProperty(req, 'query', { value: mergedQuery, writable: true, configurable: true });
            }
            await handler(req, res);
          } catch (err) {
            console.error(`[API Error] ${expressPath}:`, err.message);
            if (!res.headersSent) {
              res.status(500).json({ error: 'Internal server error', message: err.message });
            }
          }
        });
        mounted++;
      }
    } catch (err) {
      console.warn(`[Skip] Could not load ${routePath}: ${err.message}`);
    }
  }

  console.log(`Mounted ${mounted} API routes`);
}

// Start server
async function start() {
  try {
    // 1. Mount API routes FIRST (so they take priority)
    await mountApiRoutes();

    // 2. Then serve static files from Vite build
    app.use(express.static(distDir));

    // 3. SPA fallback LAST — serve index.html for all non-API, non-static routes
    app.get('{*splat}', (req, res) => {
      if (req.path.startsWith('/api/')) {
        return res.status(404).json({ error: 'API route not found' });
      }
      res.sendFile(path.join(distDir, 'index.html'));
    });

    app.listen(PORT, '0.0.0.0', () => {
      console.log(`Eyefinity PRC server running on port ${PORT}`);
      console.log(`Static files from: ${distDir}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

start();
