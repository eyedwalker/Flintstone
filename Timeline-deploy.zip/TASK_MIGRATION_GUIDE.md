# Task System Migration Guide

## ✅ Phase 2 Complete - API-Based Task System

The task management system has been successfully consolidated from a dual-system architecture (localStorage + API) to a single unified API-based system.

---

## 🎯 What Changed

### Before (Dual Systems)
- **System A**: localStorage tasks (used by CheckoutTaskModal)
- **System B**: API tasks (used by PatientReadinessCenter)
- **Problem**: Tasks created in one system were invisible to the other

### After (Unified System)
- **Single source**: All tasks now use the API backend
- **Consistent**: Tasks created anywhere appear everywhere
- **Reliable**: No more untitled or orphaned tasks

---

## 🚀 Migration Steps for Production

### Step 1: Deploy to Production
Changes are already pushed to `main` branch. Vercel will auto-deploy.

### Step 2: Wait for Deployment
Allow **30 seconds** for Vercel deployment to complete.

### Step 3: Hard Refresh Application
Press **Cmd+Shift+R** (Mac) or **Ctrl+Shift+F5** (Windows) to clear cache.

### Step 4: Preview Migration
Open browser console (F12) and run:

```javascript
taskMigration.preview()
```

This shows:
- Number of tasks in localStorage
- Tasks by status and category
- Sample tasks that will be migrated

### Step 5: Run Migration
If preview looks correct, migrate tasks:

```javascript
await taskMigration.migrate()
```

Expected output:
```
🔄 Starting task migration from localStorage to API...
Found X tasks in localStorage
✓ Migrated: Task 1 (id-123)
✓ Migrated: Task 2 (id-456)
...
📊 Migration Summary:
   Total tasks: X
   Migrated: X
   Failed: 0
✅ Migration completed successfully!
```

### Step 6: Verify API Tasks
1. Go to **Patient Readiness Center**
2. Check that all tasks appear in the task list
3. Verify task details (title, status, priority, due date)
4. Test creating a new task - should appear immediately

### Step 7: Test Checkout Flow
1. Go to **Patient Journey Board**
2. Complete a patient checkout
3. Add checkout tasks (follow-up, insurance claim, etc.)
4. Verify tasks appear in Patient Readiness Center

### Step 8: Clear localStorage (Optional)
After confirming all tasks migrated successfully:

```javascript
taskMigration.clear()
```

This permanently removes localStorage tasks. Only do this after verifying API tasks are correct!

---

## 🧪 Testing Checklist

### Task Creation
- [ ] Create task from Patient Readiness Center
- [ ] Create task from checkout flow
- [ ] Both tasks appear in task list
- [ ] Task titles are not "Untitled"
- [ ] Task details are correct

### Task Editing
- [ ] Click to edit task
- [ ] Button shows "Save Task" (not "Create Task")
- [ ] Changes save successfully
- [ ] Updated task reflects changes

### Task Validation
- [ ] Cannot save task with empty title
- [ ] Cannot save task with < 3 characters
- [ ] Error messages display correctly

### Task Cleanup
- [ ] Run `taskCleanup.cleanup()` in console
- [ ] Untitled tasks removed
- [ ] Orphaned tasks removed
- [ ] Old completed tasks removed

---

## 🔧 Console Utilities Available

### Task Migration
```javascript
// Preview what will be migrated
taskMigration.preview()

// Migrate localStorage to API
await taskMigration.migrate()

// Clear localStorage after migration
taskMigration.clear()
```

### Task Cleanup
```javascript
// Preview what will be cleaned
taskCleanup.preview()

// Clean untitled/orphaned/old tasks
taskCleanup.cleanup()

// Debug task data
taskCleanup.debug()

// Delete all tasks (caution!)
taskCleanup.clearAll()
```

---

## 📋 What's Different Now

### CheckoutTaskModal
**Old Behavior**:
- Created tasks in localStorage
- Tasks only visible if browser localStorage was accessible
- Could create untitled tasks

**New Behavior**:
- Creates tasks via API
- Tasks immediately visible in all views
- Validates title before creating
- Shows error if API call fails

### PatientReadinessCenter
**Old Behavior**:
- Only showed API tasks
- Couldn't see checkout tasks if they were in localStorage

**New Behavior**:
- Shows all tasks from API
- Includes checkout tasks
- Consistent view across all users

---

## ⚠️ Troubleshooting

### Migration Failed
**Error**: `Failed to migrate: [task title]`

**Solution**:
1. Check network connectivity
2. Verify API is running (`/api/tasks` returns 200)
3. Check browser console for detailed error
4. Re-run migration for failed tasks

### Tasks Not Appearing
**Problem**: Created task doesn't show in list

**Solution**:
1. Hard refresh the page (Cmd+Shift+R)
2. Check console for errors
3. Verify task was created: `await TaskService.fetchTasks()`
4. Check task status filter (tasks may be filtered out)

### Button Shows "Create" When Editing
**Problem**: Button text doesn't change when editing

**Solution**:
1. Clear browser cache
2. Hard refresh
3. Verify Phase 1 fix was deployed
4. Check `editingTaskId` is set when editing

### API Errors
**Error**: `Task API error (400)` or `Task API error (500)`

**Solution**:
1. Check Redis is running (API uses Redis for storage)
2. Check environment variables are set
3. Review API logs in Vercel dashboard
4. Verify request payload is valid

---

## 🎓 For Developers

### Task Data Model
```typescript
interface Task {
  id: string;
  title: string;                    // Required, min 3 chars
  description?: string;
  status: 'pending' | 'in_progress' | 'completed' | 'blocked';
  priority: 'low' | 'normal' | 'high' | 'urgent';
  category?: string;                // e.g., 'medical', 'insurance'
  channel?: string;                 // e.g., 'internal', 'appointment_followup'
  dueAt?: string;                   // ISO date string
  assignee?: string;
  assignedToOffice?: string;
  metadata?: {
    patientId?: string;
    patientName?: string;
    journeyId?: string;
    [key: string]: any;
  };
  source?: {
    type: string;
    journeyId?: string;
    patientId?: string;
    [key: string]: any;
  };
  createdAt: string;
  updatedAt: string;
}
```

### API Endpoints
```
GET    /api/tasks              - List all tasks
GET    /api/tasks?status=X     - Filter by status
POST   /api/tasks              - Create task
PATCH  /api/tasks/:id          - Update task
DELETE /api/tasks              - Clear all tasks (admin only)
```

### Creating Tasks Programmatically
```javascript
import { TaskService } from './services/taskService';

// Create task
const result = await TaskService.createTask({
  title: 'Follow-up Appointment',
  description: 'Schedule 1-week follow-up',
  status: 'pending',
  priority: 'normal',
  category: 'medical',
  dueAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
  metadata: {
    patientId: 'patient-123',
    journeyId: 'journey-456'
  }
});

// Update task
await TaskService.updateTask(result.task.id, {
  status: 'completed'
});
```

### Adding New Task Templates
Edit `CheckoutTaskModal.jsx` and add to `DEFAULT_TEMPLATES`:

```javascript
{
  id: 'new-template',
  category: TaskCategory.MEDICAL,
  title: 'New Template',
  description: 'Description here',
  defaultPriority: TaskPriority.MEDIUM,
  defaultDueDays: 7
}
```

---

## 📊 Migration Statistics

After running migration, you'll see:
- **Total tasks migrated**: Count of tasks moved from localStorage to API
- **Migration time**: How long the migration took
- **Success rate**: Percentage of successful migrations
- **Errors**: Any tasks that failed to migrate

Keep these statistics for reference and audit purposes.

---

## 🔮 Future Enhancements

### Planned (Not Yet Implemented)
- Task assignment notifications via email/SMS
- Task templates management UI
- Task analytics dashboard
- Bulk task operations (complete multiple, reassign, etc.)
- Task recurrence (weekly follow-ups, etc.)
- Task dependencies (task B requires task A completion)

---

## 📞 Support

### Issues or Questions?
1. Check this migration guide
2. Review `TASK_SYSTEM_REVIEW.md` for architecture details
3. Run console utilities to debug
4. Check browser console for errors
5. Review API logs in Vercel dashboard

### Rollback Plan
If migration causes issues:
1. Revert to previous commit
2. Deploy previous version
3. localStorage tasks will still be intact
4. Report issue for investigation

---

## ✅ Success Criteria

Migration is complete when:
- ✅ All localStorage tasks migrated to API
- ✅ New tasks created in both flows appear in all views
- ✅ No untitled tasks appear
- ✅ Task editing shows "Save Task" button
- ✅ All validation rules working
- ✅ No console errors
- ✅ Zero data loss

---

## 📅 Migration History

- **Phase 1** (Feb 2, 2026): Fixed button text, added validation, created cleanup utilities
- **Phase 2** (Feb 3, 2026): Migrated CheckoutTaskModal to API, created migration utility, added unit tests

---

## 🎉 Benefits of New System

1. **Single Source of Truth**: All tasks in one place
2. **Multi-User**: Tasks visible across all users/devices
3. **Reliable**: No browser-specific data loss
4. **Validated**: Proper title validation and error handling
5. **Testable**: Comprehensive unit test coverage
6. **Maintainable**: One system to maintain instead of two
7. **Scalable**: API can handle more features (notifications, analytics, etc.)
