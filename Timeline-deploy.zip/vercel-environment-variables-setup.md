# 🔧 Vercel Environment Variables Setup

## 🚨 CRITICAL: Your AI system isn't working because environment variables are missing from Vercel

## 📋 Step-by-Step Instructions:

### 1. Go to Vercel Dashboard
- Visit: https://vercel.com/dashboard
- Select your **patientcare-teal** project

### 2. Navigate to Environment Variables
- Click **Settings** tab
- Click **Environment Variables** in the sidebar

### 3. Add These Required Variables

**Copy these EXACT values from your .env file:**

#### AI Communication Features
```
ENABLE_AI_SMS_REPLY=true
ENABLE_AI_VOICE_ANSWER=true
ENABLE_AI_EMAIL_REPLY=true
```

#### Anthropic API (Claude AI)
```
ANTHROPIC_API_KEY=sk-ant-api03-[your-key-from-.env-file]
```

#### Twilio Configuration
```
TWILIO_ACCOUNT_SID=AC4f1eff3c432ecd8a1a0552b6d4549c07
TWILIO_AUTH_TOKEN=[your-auth-token-from-.env-file]
TWILIO_PHONE_NUMBER=+15806336937
```

#### ElevenLabs Voice AI
```
ELEVENLABS_API_KEY=[your-elevenlabs-key-from-.env-file]
```

#### Email Configuration
```
SMTP_HOST=smtp.gmail.com
SMTP_USERNAME=eyedwalker@gmail.com
SMTP_PASSWORD=[your-smtp-password-from-.env-file]
```

#### Production Domain
```
NEXT_PUBLIC_APP_URL=https://patientcare-teal.vercel.app
VITE_APP_URL=https://patientcare-teal.vercel.app
```

### 4. Environment Selection
- Set **Environment** to: `Production, Preview, Development` (all three)
- This ensures variables work in all deployments

### 5. After Adding All Variables
- Click **Save** for each variable
- Vercel will automatically redeploy your application

## 🧪 Testing After Setup

### Test SMS (should now reply with AI):
Send SMS to: **+15806336937**
- "What are your office hours?"
- "Do you accept VSP insurance?"
- "I need to schedule an appointment"

**Expected Response:** Intelligent AI reply with specific practice information

### Test Voice (should now answer):
Call: **+15806336937**
- Should hear: "Good morning/afternoon, thank you for calling..."
- Try saying: "I need to schedule an eye exam"
- Should get AI response with appointment options

## ⚠️ Important Notes

1. **Get Values from .env File**: Use the EXACT values from your local `.env` file
2. **Don't Include Quotes**: Add values without quotes in Vercel UI
3. **Case Sensitive**: Variable names must match exactly
4. **Redeploy Automatic**: Vercel redeploys automatically when you save variables

## 🔍 Verification

After adding variables, test this endpoint:
```
curl -X POST "https://patientcare-teal.vercel.app/api/webhooks/twilio-sms" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "From=+12142085261&To=+15806336937&Body=test&MessageSid=test123&AccountSid=AC4f1eff3c432ecd8a1a0552b6d4549c07"
```

Should return TwiML response instead of empty `<Response></Response>`

## 🎉 Success Indicators

✅ SMS replies with practice information (hours, insurance, etc.)
✅ Voice calls answered with AI greeting
✅ Webhook test endpoints return proper responses
✅ AI responses include Vision Care Center details

Your comprehensive AI communication system will be fully operational once these environment variables are added to Vercel!
