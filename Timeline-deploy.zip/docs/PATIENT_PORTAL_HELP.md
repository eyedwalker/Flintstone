# Patient Portal — Help Guide

---

## Table of Contents

1. [Accessing the Patient Portal](#1-accessing-the-patient-portal)
2. [Dashboard](#2-dashboard)
3. [Wait Time Tracker](#3-wait-time-tracker)
4. [Viewing Your Prescription](#4-viewing-your-prescription)
5. [Billing & Payments](#5-billing--payments)
6. [Recommendations](#6-recommendations)
7. [Frame Scanner](#7-frame-scanner)
8. [Measurements Tool](#8-measurements-tool)
9. [FTC Rx Acknowledgement](#9-ftc-rx-acknowledgement)
10. [Privacy & Security](#10-privacy--security)
11. [Frequently Asked Questions](#11-frequently-asked-questions)
12. [Troubleshooting](#12-troubleshooting)

---

## 1. Accessing the Patient Portal

### How to Log In

You can access the Patient Portal in two ways:

#### Option A: Magic Link (Recommended)
1. You will receive a text message or email with a direct link
2. Click the link to open the portal
3. You are automatically logged in — no password needed

#### Option B: Manual Login
1. Open the Patient Portal URL provided by your eye care office
2. Enter your **Appointment ID** (provided by the office)
3. Enter your **Date of Birth**
4. Click **"Log In"**

### Session Duration

- Your session lasts **24 hours**
- After 24 hours, you will need to log in again
- You can log out at any time from the navigation menu

---

## 2. Dashboard

The Dashboard is your home screen after logging in. It gives you a complete view of your visit.

### What You'll See

- **Welcome Header** — Your name and greeting
- **Visit Phase** — Shows where you are in the process:
  - *Pre-Visit* — Before your appointment
  - *In-Office* — Currently at the office
  - *Post-Visit* — After your appointment
  - *Completed* — Visit finished
- **Current Step** — What's happening right now (e.g., "Pre-Testing")
- **Progress Bar** — Visual percentage of how far through your visit you are
- **Estimated Time** — Approximate time remaining
- **Journey Timeline** — All steps in your visit, color-coded:
  - Green = Completed
  - Blue = In Progress
  - Gray = Upcoming

### Quick Action Cards

At the bottom of the dashboard, you'll find shortcut cards to:
- **Wait Time** — See your current wait
- **Prescription** — View your Rx
- **Billing** — View invoices and pay
- **Recommendations** — Personalized product suggestions

---

## 3. Wait Time Tracker

### What It Shows

- **Your Wait Time** — Displayed in large text (e.g., "15 minutes")
- **Queue Position** — Your place in line (e.g., "#3 in line")
- **Current Status** — What's happening with your visit
- **Auto-Refresh** — Updates automatically every 30 seconds

### When Wait is Zero

If your wait time shows **"You're Ready!"**, it means you're next to be seen.

### While You Wait

Suggested activities are shown:
- Browse frames (opens Frame Scanner)
- View personalized recommendations

---

## 4. Viewing Your Prescription

### Prescription Display

Your prescription is displayed in a clear table format:

| Eye | Sphere (SPH) | Cylinder (CYL) | Axis | Add |
|-----|-------------|----------------|------|-----|
| OD (Right) | Your value | Your value | Your value | Your value |
| OS (Left) | Your value | Your value | Your value | Your value |

**PD (Pupillary Distance)** is shown separately below the table.

### Understanding Your Prescription

Tap on any column header to see an explanation:
- **SPH (Sphere)** — Lens power for nearsightedness (-) or farsightedness (+)
- **CYL (Cylinder)** — Correction for astigmatism
- **Axis** — Angle of astigmatism correction (1-180 degrees)
- **Add** — Additional power for reading (bifocal/progressive)
- **PD** — Distance between your pupils (used for lens centering)

### Expiration Warnings

- **Green** — Your prescription is current
- **Yellow** — Your prescription expires within 90 days
- **Red** — Your prescription has expired

### Prescription History

Scroll down to see your prescription history from the last 5 years, showing how your vision has changed over time.

### Download & Share

- **Download** — Save a PDF copy to your device
- **Share** — Send your prescription via your device's share menu

---

## 5. Billing & Payments

### Viewing Invoices

The billing screen shows:
- **Total Balance** — Total amount you owe
- **Invoice Cards** — Each invoice with:
  - Invoice number
  - Date
  - Status (Paid, Partial, Due, Overdue)
  - Amount due

### Invoice Details

Tap an invoice to see:
- Line items (exam, frames, lenses, contacts, etc.)
- Quantity and price for each item
- Subtotal and amount paid
- Remaining balance

### Making a Payment

1. Tap **"Pay Now"** on an invoice
2. Review the amount
3. Choose a payment method:
   - Apple Pay
   - Google Pay
   - Credit/Debit Card
4. Complete the payment
5. You'll receive a confirmation with receipt

### Downloading Receipts

After payment, you can:
- Download a receipt immediately
- Access past receipts from paid invoices

---

## 6. Recommendations

### Personalized Suggestions

Your care team may provide personalized recommendations for:
- **Products** — Frames, lenses, accessories
- **Services** — Additional treatments, coatings, upgrades
- **Offers** — Special promotions and discounts

### Recommendation Cards

Each recommendation shows:
- Product/service image
- Title and description
- Priority badge ("Highly Recommended" for top picks)
- Action buttons

### Actions

- **Learn More** — Opens more details or the product page
- **Heart** — Save to your favorites
- **Share** — Share with family or friends
- **X** — Dismiss this recommendation

---

## 7. Frame Scanner

### What It Does

The Frame Scanner lets you scan eyeglass frames in the office to save them to your favorites list for easy comparison.

### How to Use It

1. Open the Frame Scanner link (sent to you via text or displayed as QR code)
2. Allow camera access when prompted
3. Point your camera at the barcode on an eyeglass frame
4. The scanner will automatically detect the barcode
5. Frame details appear on screen
6. The frame is saved to your favorites

### Manual Entry

If the camera can't read a barcode:
1. Tap **"Enter Manually"**
2. Type the UPC/SKU number (found on the frame tag)
3. Tap **"Add"**

### Viewing Favorites

- Scroll down to see all your saved frames
- Each frame shows: name, manufacturer, color, size
- Tap the **X** to remove a frame from favorites

### Tips for Best Scanning

- Hold the phone 4-6 inches from the barcode
- Ensure good lighting
- Keep the barcode flat and in focus
- The phone will vibrate when a scan is successful

---

## 8. Measurements Tool

### What It Does

The Measurements Tool uses your device's camera to take precise measurements for custom lens fitting:
- **PD (Pupillary Distance)** — Distance between your pupils
- **Seg Height** — Where your pupils sit relative to the frame
- **Face Geometry** — Face shape and dimensions for frame recommendations

### Step-by-Step Guide

#### Step 1: Introduction
- Read the overview of what will be measured
- The system checks if your device supports LiDAR (iPhone Pro models)
- Tap **"Start Measurements"**

#### Step 2: Calibration
Choose one method:

**Credit Card Method (More Accurate)**
1. Hold a credit card at face level, next to your face
2. Tap the left edge of the card on screen
3. Tap the right edge of the card on screen
4. The system calculates scale using the standard credit card width (85.6mm)

**Auto-Calibrate**
- The system uses your iris diameter as a reference
- Less accurate but requires no props

#### Step 3: Head Movement
Follow the on-screen guides to turn your head:
1. Look straight ahead (neutral)
2. Turn left — hold for 1.5 seconds
3. Return to center
4. Turn right — hold for 1.5 seconds
5. Look up, then down
6. Tilt left, then right
7. Return to center

> **Why?** These movements help the system build a 3D model of your face for more accurate measurements.

#### Step 4: PD Measurement
1. Look directly at the camera
2. Keep your head still
3. The system detects your pupils and calculates the distance
4. A confidence score is displayed
5. You'll see your PD (total, right, and left)

#### Step 5: Frame Measurements
1. Put on your glasses (or the frames you're considering)
2. Look at the camera
3. Tap the bottom edge of the frame on screen
4. You can drag the marker to fine-tune the position
5. Seg height and OC height are calculated

#### Step 6: Results
All your measurements are displayed:
- PD Total, Right, Left (with confidence %)
- Seg Height (right and left)
- OC Height (right and left)
- Face shape classification
- SVG visualization of your face geometry

You can:
- **Save** — Submit measurements for staff review
- **Retake** — Start over if measurements seem off
- **Scan Frames** — Go to the Frame Scanner

### Tips for Accurate Measurements

- Use good lighting (face a window or well-lit area)
- Remove glasses during PD measurement
- Keep your face centered in the camera
- Hold your phone at arm's length, at eye level
- Avoid moving during capture
- Close one eye at a time if needed to verify pupil detection

### Measurement Accuracy

| Method | Expected Accuracy |
|--------|------------------|
| Standard (iris calibration) | ±1mm |
| Credit card calibration | ±0.5mm |
| With LiDAR (iPhone Pro) | ±0.3mm |

---

## 9. FTC Rx Acknowledgement

### What Is This?

Federal law requires you to acknowledge that you received a copy of your eyeglass prescription. This acknowledgement must be captured before you complete your eyewear purchase.

### Signing the Acknowledgement

You may be asked to sign in one of three ways:

#### On a Device (iPad/Tablet)
1. Review the acknowledgement statement
2. Optionally view your prescription details
3. Sign with your finger on the screen (or type your name)
4. Tap **"Confirm Receipt"**

#### Via Text/Email Link
1. You receive a link to the acknowledgement form
2. Open the link on your phone
3. Review and sign
4. Submit

#### Paper Form
1. A printed form is provided
2. Sign with a pen
3. The office uploads the signed copy

### What's Recorded

- Your signature
- Date and time
- Prescription details
- Your IP address (for compliance)
- Retained for **3 years** per FTC requirements

---

## 10. Privacy & Security

### Your Data is Protected

- **No photos stored** — The Measurements Tool only saves geometric data (numbers and shapes), never actual photos of your face
- **Encrypted connections** — All data is transmitted over HTTPS
- **Secure tokens** — Your portal access uses time-limited, encrypted tokens
- **Session expiry** — Sessions automatically expire after 24 hours
- **HIPAA compliant** — All data handling follows healthcare privacy regulations

### Your Rights

- You can request to view all data stored about you
- You can request deletion of your measurement data
- Your prescription data comes from your Eyefinity EHR record
- Payment processing is handled by secure third-party processors (Stripe)

---

## 11. Frequently Asked Questions

### General

**Q: Do I need to create an account?**
A: No. You access the portal via a magic link or appointment ID. No account creation needed.

**Q: Can I access the portal after my visit?**
A: Yes, your session lasts 24 hours. Some features (like recommendations) remain available after your visit.

**Q: Is the portal available on all devices?**
A: Yes. The portal works on smartphones, tablets, and computers. A modern browser is required.

### Measurements

**Q: How accurate are the measurements?**
A: With credit card calibration, measurements are typically within ±0.5mm. Your optician will verify all measurements before ordering lenses.

**Q: Do I need an iPhone Pro for measurements?**
A: No. The measurements work on any device with a camera. iPhone Pro models with LiDAR provide slightly higher accuracy but are not required.

**Q: Why does it ask me to move my head around?**
A: Head movements help the system estimate depth and build a 3D model of your face, which improves measurement accuracy.

**Q: Can I retake measurements?**
A: Yes. You can retake measurements at any step. On the results screen, tap "Retake" to start over.

### Frame Scanner

**Q: Can I scan frames at home?**
A: The scanner is designed for in-office use where frames have barcodes. However, if you have a UPC code, you can enter it manually.

**Q: How long are my favorites saved?**
A: Your favorites are saved permanently and linked to your patient record. The office can see your favorites when helping you choose frames.

### Payments

**Q: Is it safe to pay through the portal?**
A: Yes. Payments are processed through Stripe, a PCI-compliant payment processor. Your card details are never stored by the eye care office.

**Q: Can I get a receipt?**
A: Yes. A receipt is available for download immediately after payment and can be accessed later from paid invoices.

---

## 12. Troubleshooting

### Camera Not Working

- **Check permissions:** Go to your browser settings and ensure camera access is allowed
- **Try a different browser:** Chrome works best on Android; Safari works best on iPhone
- **Check HTTPS:** The URL must start with `https://` for camera to work
- **Close other apps:** Other apps using the camera may block access

### Barcode Not Scanning

- Ensure good lighting
- Hold steady, 4-6 inches from the barcode
- Clean the barcode if dirty or damaged
- Try the **"Enter Manually"** option

### Measurements Seem Wrong

- Ensure proper lighting (natural light is best)
- Remove glasses during PD measurement
- Make sure your face is fully visible in the frame
- Try the credit card calibration method for better accuracy
- Retake measurements if confidence score is below 85%

### Page Not Loading

- Check your internet connection
- Try refreshing the page
- Clear your browser cache
- Your session may have expired — log in again

### Payment Failed

- Verify your card details are correct
- Ensure sufficient funds
- Try a different payment method
- Contact the office for assistance

### Can't Find My Prescription

- Your prescription may not be available until after your exam
- Contact the office to verify your Rx has been entered

### Link Expired

- Measurement and frame scanner links expire after 7 days
- Contact the office to request a new link

---

*Last updated: February 2026*
*Eyefinity Patient Readiness Center — Patient Portal v1.0*
