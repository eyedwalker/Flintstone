# Eyefinity Patient Readiness Center (PRC) — Admin Help & Training Guide

---

## Table of Contents

1. [Getting Started](#1-getting-started)
2. [Navigating the Application](#2-navigating-the-application)
3. [Patient Readiness Center (Journey Board)](#3-patient-readiness-center-journey-board)
4. [Admin Dashboard](#4-admin-dashboard)
5. [User Management](#5-user-management)
6. [Company & Multi-Tenant Setup](#6-company--multi-tenant-setup)
7. [Eyefinity EHR Integration](#7-eyefinity-ehr-integration)
8. [Room Configuration](#8-room-configuration)
9. [Patient Journey Configuration](#9-patient-journey-configuration)
10. [Forms Administration](#10-forms-administration)
11. [Recommendations Engine](#11-recommendations-engine)
12. [AI Knowledge Base](#12-ai-knowledge-base)
13. [AI Communication System](#13-ai-communication-system)
14. [Voice AI Settings](#14-voice-ai-settings)
15. [Escalation Management](#15-escalation-management)
16. [Frame Scanner & Measurements](#16-frame-scanner--measurements)
17. [FTC Compliance (Rx Acknowledgement)](#17-ftc-compliance-rx-acknowledgement)
18. [HIPAA Compliance](#18-hipaa-compliance)
19. [Demo Mode](#19-demo-mode)
20. [Troubleshooting](#20-troubleshooting)

---

## 1. Getting Started

### First-Time Login

When the system is first deployed, a default admin account is created automatically:

- **Email:** `admin@visioncare.local`
- **Password:** `Admin@123456`

> **Important:** You will be required to change this password on first login. Choose a strong password with at least 12 characters, including uppercase, lowercase, numbers, and special characters.

### Login Steps

1. Navigate to the application URL (e.g., `https://your-domain.vercel.app/login`)
2. Enter your email address and password
3. If MFA (Multi-Factor Authentication) is enabled, enter your 6-digit code from your authenticator app
4. You will be redirected to the Patient Readiness Center

### Password Requirements

- Minimum 12 characters
- At least one lowercase letter (a-z)
- At least one uppercase letter (A-Z)
- At least one number (0-9)
- At least one special character (@$!%*?&)

### Account Lockout

After 5 consecutive failed login attempts, your account will be locked for 15 minutes. Contact another admin to reset your password if needed.

---

## 2. Navigating the Application

### Header Bar

The top navigation bar (dark blue) contains:

| Element | Description |
|---------|-------------|
| **Eyefinity PRC** | Logo — click to return to home |
| **DEMO badge** | Orange indicator when Demo Mode is active (click to configure) |
| **Journey Board** | Main patient tracking view |
| **Admin** | Admin dashboard (admin-only) |
| **Recommendations** | Manage product/service recommendations (admin-only) |
| **Forms** | Configure patient forms (admin-only) |
| **Journey Settings** | Customize patient journey steps (admin-only) |
| **AI Knowledge** | Train the AI assistant (admin-only) |
| **AI Test** | Test AI responses (admin-only) |
| **Timeline Creator** | Timeline visualization tool |
| **Company Switcher** | Dropdown to switch between companies (admin-only, multi-company) |
| **Environment Switcher** | Toggle between Sandbox/Staging/Production (admin-only) |
| **User Menu** | Profile, User Management, Voice AI Settings, Logout |

### Secondary Bar

Below the header:
- **Page Title** — "Patient Readiness Center"
- **Office Phone** — Displayed for reference (used for SMS/call testing)
- **Escalations** — Live count of AI escalations requiring attention
- **AI Monitor** — Opens the AI monitoring panel
- **Queue** — Opens the patient queue manager

---

## 3. Patient Readiness Center (Journey Board)

The Journey Board is your main working view. It displays all patients currently in their visit journey.

### Patient Cards

Each patient card shows:
- Patient name and appointment time
- Current journey step (e.g., "Pre-Testing", "Doctor Examination")
- Step status indicators (completed, in-progress, pending)
- Time in current step
- Communication status icons
- Quick action buttons

### Moving Patients Through Steps

1. Click on a patient card to expand their journey
2. Each step shows its status: pending, in-progress, or completed
3. Click **"Start"** to begin a step or **"Complete"** to mark it done
4. The system automatically tracks timing for each step

### Communication Actions

From a patient card, you can:
- **Send SMS** — Text the patient directly
- **Send Email** — Email the patient
- **Make Call** — Initiate an AI-powered voice call
- **Send Link** — Send a patient portal link, frame scanner link, or measurement link

### AI Monitor

Click the **AI Monitor** button to view:
- Active AI conversations
- Sentiment analysis of patient interactions
- Escalations requiring human intervention
- Communication logs (SMS, email, voice)

---

## 4. Admin Dashboard

Access: **Admin** in the navigation bar (admin role required)

### Tabs

#### Overview
- Account and company summary
- Quick stats (offices, staff, providers)
- System health indicators

#### Offices
- List of all offices for the active company
- Click an office to view/edit details
- Import offices from Eyefinity

#### Staff & Providers
- View all staff members and providers
- Import from Eyefinity
- Manage roles and assignments

#### Settings
- Company name and Eyefinity Company ID
- Eyefinity API configuration (OAuth or Static Token)
- Test connection to Eyefinity
- Save/update authentication credentials

---

## 5. User Management

Access: **User Menu → User Management** (admin role required)

### Inviting Users

The system uses invite-only registration:

1. Click **"Invite User"**
2. Enter the user's email address
3. Select their role:
   - **Admin** — Full system access
   - **Manager** — Operational management
   - **Associate** — Basic staff access
4. Click **"Send Invite"**
5. The system generates a registration link (valid for 7 days)
6. Share the link with the user

### Managing Existing Users

- **Change Role:** Click the role dropdown next to a user
- **Reset Password:** Click "Reset" — a temporary password is generated (shown once)
- **Delete User:** Click "Delete" (cannot delete yourself)

### Invite Status

Invites can be:
- **Pending** — Not yet used
- **Used** — Registration completed
- **Expired** — Passed the 7-day window
- **Revoked** — Manually cancelled by an admin

---

## 6. Company & Multi-Tenant Setup

The system supports multiple companies under a single account, each with isolated data.

### Adding a New Company

1. Go to **Admin Dashboard**
2. Click **"Add Company"** or use the Setup Wizard
3. Follow the 4-step process:
   - **Step 1:** Create an account (top-level organization)
   - **Step 2:** Create a company (enter name, Eyefinity Company ID)
   - **Step 3:** Connect to Eyefinity (OAuth or Static Token)
   - **Step 4:** Import data (offices, providers, staff)

### Switching Companies

- Use the **Company Switcher** dropdown in the header
- All views immediately update to show the selected company's data
- Data is fully isolated — no cross-company contamination

### Company Settings

For each company, configure:
- **Name** — Display name
- **Eyefinity Company ID** — Maps to Eyefinity system
- **Authentication Method:**
  - **OAuth** — Auto-refreshing tokens (recommended for cloud environments)
  - **Static Token** — Manual token entry (required for VPN/CI environments)
- **API Base URL** — Eyefinity API endpoint
- **API Path** — Path prefix (e.g., `al-pe`, `api`, `v1`)

---

## 7. Eyefinity EHR Integration

### Authentication Methods

#### OAuth (Recommended)
1. Enter your **EPM Client ID**
2. Enter your **EPM Client Secret**
3. Enter your **Tenant UID**
4. Set the **OAuth Host** (e.g., `api-sandbox.eyefinity.com`)
5. Set the **API Base URL**
6. Click **"Save Settings"** then **"Connect to Eyefinity"**

#### Static Token
1. Select **"Static Access Token"** radio button
2. Enter the **API Base URL** (e.g., `https://pm-ci.eyefinity.com`)
3. Enter the **API Path** (e.g., `al-pe`)
4. Paste your **Access Token**
5. Click **"Save Settings"**

> **Note:** Static tokens do not auto-refresh. You must manually update them before they expire.

### Testing the Connection

1. Go to **Admin → Settings**
2. Click **"Test Connection"**
3. The system will attempt to fetch providers from Eyefinity
4. Success/failure message will be displayed

### Data Sync

The system can import from Eyefinity:
- **Offices** — Office locations and details
- **Providers** — Doctors and their schedules
- **Staff** — Office staff members
- **Patients** — Patient demographics (on-demand)
- **Appointments** — Scheduled appointments
- **Prescriptions** — Rx data (eyeglass, contact lens)

---

## 8. Room Configuration

Access: Click an office in the Admin Dashboard, then configure rooms.

### Adding Rooms

1. Click **"Add Room"**
2. Enter room details:
   - **Name** (e.g., "Exam Room 1")
   - **Short Name** (e.g., "E1")
   - **Type:** Waiting Area, Pre-Testing, Exam Room, Dilation, Optical, Contact Lens, Doctor Office, Dispensary Table, Checkout, Other
   - **Capacity** (default: 1)
   - **Default Duration** (minutes)
   - **Color** (for visual identification)
3. Click **"Save"**

### Room Templates

Load pre-built templates:
- **Small Office** — 7 rooms
- **Medium Office** — 10 rooms
- **Large Office** — 16 rooms

> **Warning:** Loading a template replaces all existing room configurations.

### Editing/Deleting Rooms

- Click the **edit icon** on any room to modify settings
- Click the **delete icon** to remove a room (with confirmation)

---

## 9. Patient Journey Configuration

Access: **Journey Settings** in the navigation bar

### Journey Phases

Patient visits are organized into phases:
1. **Pre-Visit** — Before arriving at the office
2. **In-Office** — While at the office
3. **Post-Visit** — After leaving

### Customizing Steps

Each phase contains configurable steps. For each step you can set:
- **Name** — Display name (e.g., "Check-In", "Pre-Testing")
- **Description** — What happens during this step
- **Default Duration** — Expected time in minutes
- **Required** — Whether the step can be skipped
- **Order** — Position in the sequence
- **Triggers** — Automated actions when step starts/completes

### Step Types Available

- Check-In / Registration
- Insurance Verification
- Medical History Review
- Pre-Testing
- Dilation
- Doctor Examination
- Prescription Discussion
- Frame Selection
- Lens Selection
- Measurements
- Dispensing
- Checkout / Billing

---

## 10. Forms Administration

Access: **Forms** in the navigation bar

### Managing Forms

- View all configured forms
- Create new form templates
- Edit existing forms
- Assign forms to journey steps
- Configure required vs. optional forms

### Form Types

- Patient intake forms
- Medical history questionnaires
- Insurance information
- HIPAA authorization
- FTC Rx acknowledgement
- Custom forms

---

## 11. Recommendations Engine

Access: **Recommendations** in the navigation bar

### Overview

The recommendations engine provides personalized product and service suggestions to patients based on their profile, visit history, and insurance.

### Managing Recommendations

- **Create** new recommendation templates
- **Edit** existing recommendations
- **Set Priority** — Higher priority items appear first (80+ shows "Highly Recommended" badge)
- **Target Audience** — Configure which patient segments see each recommendation
- **Track Performance** — View impression and click analytics

### Recommendation Types

- **Product** — Frames, lenses, accessories
- **Service** — Additional services, add-ons
- **Offer** — Promotions, discounts

### Locations

Recommendations can appear in:
- Patient app feed
- In-office displays
- Post-visit follow-ups

---

## 12. AI Knowledge Base

Access: **AI Knowledge** in the navigation bar

### What It Does

The AI Knowledge Base trains the AI assistant with practice-specific information so it can accurately answer patient questions via SMS, voice calls, and chat.

### Configuring Knowledge

Add information about:
- **Office Hours** — Operating hours for each day
- **Services** — List of services offered with pricing
- **Insurance** — Accepted insurance plans
- **Providers** — Doctor names, specialties, availability
- **Policies** — Cancellation policy, late arrival policy
- **Location** — Address, parking, directions
- **FAQs** — Common patient questions and answers

### Testing

Use the **AI Test** page to send test messages and verify the AI responds correctly with your configured knowledge.

---

## 13. AI Communication System

### Overview

The system uses Claude AI to power intelligent patient communications across multiple channels:

### Channels

| Channel | Technology | Description |
|---------|-----------|-------------|
| **SMS** | Twilio | Two-way AI texting with patients |
| **Voice** | Twilio + ElevenLabs | AI-powered phone calls |
| **Email** | Nodemailer | Automated email communications |

### Outbound Communications

Staff can initiate communications from a patient card:
1. Click the communication icon on a patient card
2. Select channel (SMS, Email, Voice Call)
3. Choose a template or write a custom message
4. Send

### AI-Powered SMS

When patients text the office number:
1. The system looks up the patient by phone number
2. Claude AI generates contextual responses
3. Conversation history is maintained (30-minute window)
4. Actions triggered by keywords (directions, scheduling)

### AI-Powered Voice Calls

Outbound call types:
- **Appointment Reminder** — Automated reminder calls
- **Post-Visit Follow-up** — Check on patient after visit
- **Prescription Ready** — Notify when Rx is ready
- **Recall Reminder** — Annual exam reminders
- **Custom** — Free-form call scripts

### Communication Triggers

Automated communications can be triggered by journey events:
- Journey started
- Step started/completed
- Phase changed (e.g., moved to post-visit)
- Journey completed

### Sentiment Analysis

After each call or SMS conversation, the AI analyzes:
- Customer satisfaction (1-5 scale)
- Emotion detection (happy, neutral, frustrated, angry)
- Whether human escalation is needed
- Key issues identified
- AI performance rating

---

## 14. Voice AI Settings

Access: **User Menu → Voice AI Settings**

### Configurable Options

| Setting | Options | Default |
|---------|---------|---------|
| **Voice** | Emily, Amy, Jessica, Sarah, Rachel, Josh, Adam | Emily |
| **Agent Name** | Any name | Emily |
| **Stability** | 0.0 - 1.0 | 0.3 |
| **Style** | 0.0 - 1.0 | 0.55 |
| **Speed** | 0.5 - 2.0 | 1.15 |
| **Custom Greeting** | Free text | (auto-generated) |

### Tips

- **Stability** controls how consistent the voice sounds. Lower = more expressive, higher = more monotone.
- **Style** controls vocal characteristics. Adjust to match your practice's tone.
- **Speed** 1.0 is normal speed. 1.15 is slightly faster (recommended for phone calls).

---

## 15. Escalation Management

### What Are Escalations?

Escalations are generated when the AI detects a patient interaction that needs human attention:
- Patient is frustrated or angry
- Complex request the AI can't handle
- Emergency or urgent situation
- Patient explicitly requests to speak to a person

### Viewing Escalations

- **Header Bar** — Shows live count of active escalations
- **Escalation Button** — Floating button in bottom-right corner with badge count
- **AI Monitor** — Full escalation details

### Managing Escalations

1. Click on an escalation to view details
2. Read the AI's analysis and recommendation
3. Take action:
   - **Acknowledge** — Mark as seen
   - **Resolve** — Mark as handled
   - **Contact Patient** — Initiate manual communication

### Priority Levels

- **Urgent** (red, pulsing) — Requires immediate attention
- **High** (red) — Should be addressed soon
- **Medium** (orange) — Can be handled when convenient

---

## 16. Frame Scanner & Measurements

### Sending Links to Patients

From the Journey Board:
1. Click on a patient card
2. Click the **"Frame Scanner"** or **"Measurements"** button
3. A secure, time-limited link is generated
4. Send via SMS or display as QR code

### How Frame Scanner Works (Patient Side)

1. Patient opens the link on their phone
2. Camera activates for barcode scanning
3. Patient scans frame UPC barcodes
4. Frames are saved to their favorites list
5. Staff can view the patient's favorites

### How Measurements Work (Patient Side)

1. Patient opens the measurement link
2. 6-step guided process:
   - **Intro** — Explanation and LiDAR detection
   - **Calibration** — Credit card or auto-calibrate
   - **Head Movement** — Guided head turns for 3D modeling
   - **Face Capture** — PD (pupillary distance) measurement
   - **Frame On** — Seg height with glasses on
   - **Results** — All measurements displayed
3. Measurements saved and require staff approval

### Reviewing Measurements

- Measurements appear in the patient's record
- Status starts as **"Pending Approval"**
- Staff can approve, reject, or request re-measurement
- Approved measurements can be used for lens orders

---

## 17. FTC Compliance (Rx Acknowledgement)

### Overview

Federal Trade Commission (FTC) Eyeglass Rule requires patients to acknowledge receipt of their prescription before purchasing eyewear.

### Capturing Acknowledgement

Three methods available:

#### 1. Sign on Device (Recommended)
- Patient signs directly on an iPad, tablet, or computer
- Shows prescription details (expandable)
- Captures digital signature (draw or type)
- Records IP address and timestamp

#### 2. Send Form Remotely
- Sends acknowledgement form to patient via SMS or email
- Patient reviews and signs on their own device
- Automatically recorded when completed

#### 3. Print & Upload
- Print the acknowledgement form
- Patient signs with pen
- Staff uploads the signed document (photo or scan)

### Compliance Records

All acknowledgements include:
- Patient name and exam date
- Prescription details
- Signature (digital or uploaded)
- IP address and timestamp
- Store number and associate name
- **Retained for 3 years** per FTC requirements

---

## 18. HIPAA Compliance

### Authorization Signature

Before accessing patient records, the HIPAA module checks:
- **Valid signature** — Green, proceed normally
- **Expiring soon** (within 30 days) — Yellow warning, renewal button shown
- **Expired** — Red, blocks access until renewed
- **Missing** — Red, requires initial signature capture

### Capturing HIPAA Signature

1. Component presents HIPAA authorization form
2. Patient signs (draw on screen or type name)
3. Staff confirms supervision
4. System records:
   - Signature image/text
   - Device ID and type
   - IP address and user agent
   - Associate name (supervisor)
   - Timestamp

### Signature Validity

- Signatures are valid for **1 year**
- System automatically tracks expiration
- Renewal reminders appear 30 days before expiry

---

## 19. Demo Mode

### What Is Demo Mode?

Demo Mode allows you to test the system with simulated data without affecting real patient records.

### Enabling Demo Mode

1. Click the **DEMO badge** in the header (or navigate to Demo settings)
2. Toggle Demo Mode **ON**
3. Enter a demo email address
4. Configure demo settings:
   - Simulated patient data
   - Mock Eyefinity responses
   - Test communication channels

### Demo Mode Indicators

- Orange **DEMO** badge in the header
- Demo email displayed next to badge
- All data actions are simulated

### Disabling Demo Mode

1. Click the **DEMO badge**
2. Toggle Demo Mode **OFF**
3. System returns to live data

---

## 20. Troubleshooting

### Common Issues

#### "Connection to Eyefinity Failed"
- Verify your API credentials in Admin → Settings
- Check that the API Base URL is correct
- For VPN environments, ensure you're connected to VPN
- For static tokens, verify the token hasn't expired

#### "Patient Not Found"
- Check that the patient exists in Eyefinity
- Verify the Eyefinity Company ID is correct
- Try searching by different criteria (phone, name, DOB)

#### "Camera Not Working" (Frame Scanner/Measurements)
- Ensure HTTPS is being used (camera requires secure context)
- Check browser permissions for camera access
- Try a different browser (Chrome recommended)
- On iOS, use Safari for best camera compatibility

#### "AI Not Responding"
- Verify the Anthropic API key is configured
- Check the AI Knowledge Base has been populated
- Review the AI Monitor for error messages

#### "SMS/Voice Not Working"
- Verify Twilio credentials are configured
- Check that the Twilio phone number is active
- Ensure the patient's phone number is in valid format

#### Account Locked
- Wait 15 minutes for automatic unlock
- Contact another admin to reset your password
- Check for unauthorized login attempts

### Getting Help

If you encounter issues not covered here:
1. Check the browser console for error messages (F12 → Console)
2. Contact your system administrator
3. Review the deployment documentation for environment-specific issues

---

*Last updated: February 2026*
*Eyefinity Patient Readiness Center v1.0*
