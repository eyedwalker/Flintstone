# System Architecture & Developer Guide

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Technology Stack](#2-technology-stack)
3. [Project Structure](#3-project-structure)
4. [Frontend Architecture](#4-frontend-architecture)
5. [Backend Architecture (API)](#5-backend-architecture-api)
6. [Database Architecture](#6-database-architecture)
7. [Authentication System](#7-authentication-system)
8. [Multi-Tenant Architecture](#8-multi-tenant-architecture)
9. [AI & Communication Services](#9-ai--communication-services)
10. [Frame Scanner & Measurements](#10-frame-scanner--measurements)
11. [Eyefinity EHR Integration](#11-eyefinity-ehr-integration)
12. [Key Services Reference](#12-key-services-reference)
13. [API Endpoints Reference](#13-api-endpoints-reference)
14. [Data Flow Diagrams](#14-data-flow-diagrams)
15. [Development Workflow](#15-development-workflow)

---

## 1. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLIENTS                                   │
│  ┌──────────┐  ┌──────────────┐  ┌───────────────┐             │
│  │ Admin UI │  │ Patient App  │  │ Frame Scanner │             │
│  │ (React)  │  │   (React)    │  │ /Measurements │             │
│  └────┬─────┘  └──────┬───────┘  └───────┬───────┘             │
└───────┼────────────────┼─────────────────┼──────────────────────┘
        │                │                 │
        ▼                ▼                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                    VERCEL EDGE NETWORK                           │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │              Serverless API Functions (/api/*)            │   │
│  │  ┌────────┐ ┌──────┐ ┌───────────┐ ┌──────────────────┐ │   │
│  │  │  Auth  │ │ CRUD │ │ Eyefinity │ │ AI/Communication │ │   │
│  │  │        │ │      │ │   Proxy   │ │   (Claude/Twilio) │ │   │
│  │  └───┬────┘ └──┬───┘ └─────┬─────┘ └────────┬─────────┘ │   │
│  └──────┼─────────┼───────────┼────────────────┼────────────┘   │
└─────────┼─────────┼───────────┼────────────────┼────────────────┘
          │         │           │                │
          ▼         ▼           ▼                ▼
┌────────────┐ ┌─────────┐ ┌───────────┐ ┌──────────────────┐
│ Vercel KV  │ │Supabase │ │ Eyefinity │ │ External APIs    │
│  (Redis)   │ │(Postgres)│ │   EHR     │ │ Anthropic/Twilio │
│ Auth/Tasks │ │ App Data │ │ Patient   │ │ ElevenLabs       │
└────────────┘ └─────────┘ └───────────┘ └──────────────────┘
```

### Key Design Decisions

- **Serverless-first:** All backend logic runs as Vercel serverless functions
- **Dual database:** Vercel KV (Redis) for auth/sessions, Supabase (PostgreSQL) for business data
- **Multi-tenant:** Company-level data isolation with tenant context throughout the stack
- **EHR integration:** Proxy pattern for Eyefinity API calls with token management
- **AI-native:** Claude AI integrated for SMS, voice, and sentiment analysis

---

## 2. Technology Stack

### Frontend
| Technology | Version | Purpose |
|-----------|---------|---------|
| React | 18.3.1 | UI framework |
| React Router | 7.12.0 | Client-side routing |
| Vite | 6.0.3 | Build tool and dev server |
| Tailwind CSS | 3.4.16 | Utility-first styling |
| Lucide React | 0.468.0 | Icon library |
| Three.js | 0.182.0 | 3D visualization |

### Backend
| Technology | Version | Purpose |
|-----------|---------|---------|
| Node.js | (Vercel runtime) | Server runtime |
| Vercel Serverless | — | API hosting |
| PostgreSQL | (Supabase) | Primary database |
| Redis | (Vercel KV / Upstash) | Auth, sessions, caching |

### AI & Communication
| Technology | Version | Purpose |
|-----------|---------|---------|
| Anthropic SDK | 0.27.3 | Claude AI integration |
| Twilio | 4.23.0 | SMS and voice calls |
| ElevenLabs | 2.33.0 | Voice synthesis (TTS) |
| Nodemailer | 7.0.12 | Email delivery |

### Specialized
| Technology | Version | Purpose |
|-----------|---------|---------|
| MediaPipe Face Mesh | 0.4.1 | Facial landmark detection |
| Quagga | 0.12.1 | Barcode scanning |
| bcryptjs | 3.0.3 | Password hashing |
| jsonwebtoken | 9.0.3 | JWT token handling |
| PapaParse | 5.5.3 | CSV parsing |
| xlsx | 0.18.5 | Excel file handling |

---

## 3. Project Structure

```
Timeline/
├── api/                          # Vercel serverless functions
│   ├── _lib/                     # Shared utilities & middleware
│   ├── ai/                       # AI endpoints (analyze-sentiment)
│   ├── appointments/             # Appointment CRUD
│   ├── auth/                     # Authentication (login, register, invite, etc.)
│   ├── checkin/                  # Mobile check-in
│   ├── communications/           # SMS, email, voice endpoints
│   ├── data/                     # Data import/export
│   ├── db/                       # Database operations
│   ├── eyefinity/                # EHR proxy (patients, Rx, offices)
│   ├── forms/                    # Form submission handling
│   ├── offices/                  # Office management
│   ├── patient/                  # Patient-facing endpoints (frame-scan, measurements)
│   ├── patients/                 # Staff-facing patient CRUD
│   ├── sync/                     # Data synchronization
│   ├── tasks/                    # Task queue (cron-runner)
│   ├── voice/                    # Voice/Twilio endpoints (20+ files)
│   └── webhooks/                 # Twilio SMS webhook
├── src/                          # Frontend source
│   ├── App.jsx                   # Main app component
│   ├── main.jsx                  # Entry point with routing
│   ├── index.css                 # Global styles
│   ├── components/               # React components
│   │   ├── admin/                # Admin dashboard, settings, user mgmt
│   │   ├── ai-chat/              # AI chat interface
│   │   ├── communication/        # Escalation triggers, queue popup
│   │   ├── forms/                # Form components
│   │   ├── ftc/                  # FTC compliance (Rx acknowledgement, consent)
│   │   ├── hipaa/                # HIPAA compliance (signature, warnings)
│   │   ├── id-documents/         # Document verification
│   │   ├── layout/               # Header, navigation
│   │   ├── patient-journey/      # Journey board, step cards
│   │   ├── recommendations/      # Recommendation engine UI
│   │   ├── rooms/                # Room configuration
│   │   ├── tasks/                # Task management
│   │   ├── ui/                   # Reusable primitives
│   │   └── verification/         # Identity verification
│   ├── contexts/                 # React Contexts
│   │   ├── AuthContext.jsx       # Authentication state
│   │   └── CompanyContext.jsx    # Multi-tenant company state
│   ├── lib/                      # Libraries & utilities
│   │   ├── accessors/            # Database accessor classes
│   │   ├── api/                  # API client functions
│   │   ├── config/               # Feature flags, configuration
│   │   ├── database/             # Database connection utilities
│   │   ├── db/                   # Database connection (pg pool)
│   │   ├── services/             # Business logic services
│   │   ├── types/                # TypeScript type definitions
│   │   └── utils/                # General utilities
│   ├── pages/                    # Page-level route components
│   │   ├── auth/                 # Login, Register pages
│   │   └── patient/              # FrameScanner, Measurements
│   ├── patient-app/              # Separate patient portal
│   │   ├── layouts/              # Patient app layout
│   │   └── pages/                # Dashboard, Rx, Billing, Wait, Recs
│   ├── services/                 # Core services
│   │   ├── ai/                   # AI service layer
│   │   └── voice/                # Voice service layer
│   └── data/                     # Static data, form templates
├── docs/                         # Documentation (this directory)
├── scripts/                      # Build/deploy scripts
├── tests/                        # Test directory
├── vercel.json                   # Vercel configuration
├── vite.config.js                # Vite build configuration
├── tailwind.config.js            # Tailwind CSS configuration
├── postcss.config.js             # PostCSS configuration
└── package.json                  # Dependencies and scripts
```

---

## 4. Frontend Architecture

### Routing (main.jsx)

The app uses React Router v7 with these route groups:

```
/login                  → LoginPage
/register               → RegisterPage
/journey                → Journey Board (main PRC view)
/admin                  → Admin Dashboard
/recommendations-admin  → Recommendations Admin
/forms-admin            → Forms Admin
/journey-admin          → Journey Settings
/ai-knowledge-base      → AI Knowledge Base
/ai-test                → AI Test Page
/user-management        → User Management
/timeline               → Timeline Creator
/patient/*              → Patient App (nested routes)
/frame-scanner          → Frame Scanner (token-protected)
/measurements           → Measurements Tool (token-protected)
```

### Context Providers

```jsx
<AuthProvider>           // Authentication state (user, login, logout, roles)
  <CompanyProvider>      // Multi-tenant company context (activeCompany, switchCompany)
    <RouterProvider>     // React Router
      <App />
    </RouterProvider>
  </CompanyProvider>
</AuthProvider>
```

### AuthContext

Provides:
- `currentUser` — Current logged-in user object
- `login(email, password)` — Authenticate user
- `logout()` — End session
- `isAdmin` — Boolean for admin role check
- `isAuthenticated` — Boolean for auth status

### CompanyContext

Provides:
- `activeCompany` — Currently selected company object
- `companies` — Array of all companies
- `switchCompany(companyId)` — Change active company
- Persists selection in `localStorage` key `activeCompanyId`

### Component Organization

Components follow a feature-based organization:

```
components/
├── admin/          → Admin-only UI (dashboard, settings, wizards)
├── communication/  → Escalation triggers, queue popups
├── ftc/            → FTC compliance forms
├── hipaa/          → HIPAA signature capture
├── patient-journey/→ Journey board, patient cards, step management
├── rooms/          → Room configuration admin
├── ui/             → Reusable: buttons, modals, inputs, signatures
```

---

## 5. Backend Architecture (API)

### Serverless Function Pattern

Each API file exports a default handler:

```javascript
export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  // Route by method
  if (req.method === 'GET') { /* ... */ }
  if (req.method === 'POST') { /* ... */ }
}
```

### Shared Libraries (`api/_lib/`)

- Database connection utilities
- Authentication middleware
- CORS helpers
- Error handling

### Accessors Pattern

Database operations use an accessor pattern:

```typescript
// src/lib/accessors/PatientAccessor.ts
class PatientAccessorClass {
  async getById(id: string) { /* SQL query */ }
  async getAll(companyId: string) { /* SQL query with tenant filter */ }
  async create(data: PatientData) { /* INSERT */ }
  async update(id: string, data: Partial<PatientData>) { /* UPDATE */ }
  async delete(id: string) { /* DELETE */ }
}
export const patientAccessor = new PatientAccessorClass();
```

Key accessors:
- `CompanyAccessor` — Company CRUD
- `PatientAccessor` — Patient CRUD
- `OfficeAccessor` — Office management
- `StaffAccessor` — Staff management
- `PatientMeasurementsAccessor` — Measurement records
- `PatientFaceProfileAccessor` — Face geometry data
- `PatientFavoriteFramesAccessor` — Frame favorites

---

## 6. Database Architecture

### Supabase (PostgreSQL)

Primary business data store:

```
accounts
├── id (UUID, PK)
├── name
├── created_at, updated_at

companies
├── id (UUID, PK)
├── account_id (FK → accounts)
├── name
├── eyefinity_company_id
├── eyefinity_api_key, eyefinity_api_secret
├── oauth_token, oauth_refresh_token, oauth_token_expires_at
├── tenant_uid, oauth_host, api_base_url, api_path
├── twilio_account_sid, twilio_auth_token, twilio_phone_number
├── settings (JSONB)

offices
├── id (UUID, PK)
├── company_id (FK → companies)
├── name, address, phone

staff
├── id (UUID, PK)
├── company_id (FK → companies)
├── office_id (FK → offices)
├── name, role, email

patient_measurements
├── id (UUID, PK)
├── patient_id, company_id
├── pd_total, pd_right, pd_left (DECIMAL)
├── seg_height_right, seg_height_left (DECIMAL)
├── oc_height_right, oc_height_left (DECIMAL)
├── calibration_factor, confidence_score
├── has_lidar, device_type
├── face_landmarks (JSONB)
├── status ('pending_approval', 'approved', 'rejected')
├── measured_at

patient_face_profiles
├── id (UUID, PK)
├── patient_id, company_id
├── face_width, face_height, jaw_width, cheekbone_width, forehead_width
├── face_shape, face_shape_confidence
├── pd_total, pd_right, pd_left
├── outline_points (JSONB)
├── face_svg (TEXT)
├── recommended_frame_widths, recommended_bridge_widths (JSONB)

patient_favorite_frames
├── id (UUID, PK)
├── patient_id, company_id
├── upc_code
├── frame_name, frame_manufacturer, frame_model, frame_color, frame_size
├── image_url, notes
├── is_purchased
├── UNIQUE(patient_id, upc_code)

frame_catalog
├── id (UUID, PK)
├── upc_code (UNIQUE)
├── manufacturer, brand, model_name, model_number
├── color_name, color_code
├── lens_width, bridge_width, temple_length, frame_width
├── material, frame_type, shape
├── wholesale_price, retail_price
├── image_url, additional_images (JSONB)

head_movement_calibration
├── id (UUID, PK)
├── patient_id, company_id, measurement_id
├── movement_sequence (JSONB)
├── depth_map (JSONB)
├── quality_score
├── has_3d_data
```

### Vercel KV (Redis)

Authentication and session store:

```
Key Pattern              │ Value Type │ TTL      │ Purpose
─────────────────────────┼────────────┼──────────┼──────────────────
user:{email}             │ Hash       │ None     │ User record
users:all                │ Set        │ None     │ All user emails
session:{token}          │ Hash       │ 8 hours  │ Active session
refresh:{refreshToken}   │ Hash       │ 7 days   │ Refresh token
mfa:{mfaToken}           │ Hash       │ 5 min    │ MFA pending
invite:{token}           │ Hash       │ 7 days   │ User invitation
invites:all              │ Set        │ None     │ All invite tokens
```

---

## 7. Authentication System

### Flow Diagram

```
Client                          Server (API)                    Vercel KV
  │                                │                               │
  │── POST /api/auth/login ───────>│                               │
  │   { email, password }          │── GET user:{email} ──────────>│
  │                                │<── User hash ─────────────────│
  │                                │                               │
  │                                │── bcrypt.compare() ──>        │
  │                                │                               │
  │                                │── SET session:{token} ───────>│ (8h TTL)
  │                                │── SET refresh:{token} ───────>│ (7d TTL)
  │                                │                               │
  │<── { user, session } ─────────│                               │
  │                                │                               │
  │── Bearer {token} ────────────>│── GET session:{token} ───────>│
  │                                │<── Session data ──────────────│
  │<── { user } ──────────────────│                               │
```

### Token Lifecycle

| Token Type | TTL | Storage Key | Purpose |
|-----------|-----|-------------|---------|
| Session Token | 8 hours | `session:{token}` | API authentication |
| Refresh Token | 7 days | `refresh:{token}` | Session renewal |
| MFA Token | 5 minutes | `mfa:{token}` | MFA verification |
| Invite Token | 7 days | `invite:{token}` | User registration |
| Patient Token (JWT) | 7 days | (self-contained) | Frame scanner / measurements |

### Security Features

- **Password hashing:** bcryptjs with 12 salt rounds
- **Account lockout:** 5 failed attempts → 15-minute lock
- **Refresh token rotation:** Old token deleted on refresh
- **MFA support:** TOTP (Google Authenticator compatible)
- **Invite-only registration:** No self-signup

---

## 8. Multi-Tenant Architecture

### Isolation Layers

```
┌─────────────────────────────────────────┐
│ UI Layer                                 │
│ CompanyContext → activeCompany           │
│ All API calls include companyId          │
├─────────────────────────────────────────┤
│ API Layer                                │
│ Validate companyId on every request     │
│ Eyefinity proxy routes to correct tenant│
├─────────────────────────────────────────┤
│ Database Layer                           │
│ WHERE company_id = ? on all queries     │
│ Foreign keys enforce referential integrity│
└─────────────────────────────────────────┘
```

### Company Authentication to Eyefinity

Two methods per company:

**OAuth (auto-refresh):**
```
company.eyefinity_api_key    → Client ID
company.eyefinity_api_secret → Client Secret
company.tenant_uid           → Tenant UID
company.oauth_host           → OAuth server
company.oauth_token          → Access token (auto-managed)
company.oauth_refresh_token  → Refresh token
```

**Static Token:**
```
company.oauth_token          → Bearer token (manually set)
company.api_base_url         → API base URL
company.api_path             → API path prefix
```

---

## 9. AI & Communication Services

### Claude AI Integration

**Model used:** `claude-3-5-haiku-20241022` (optimized for speed/cost)

**Use cases:**
1. **SMS Responses** — AI-powered two-way texting (`api/webhooks/twilio-sms.js`)
2. **Voice Call Scripts** — Dynamic conversation during phone calls (`api/voice/ai-call-response.js`)
3. **Sentiment Analysis** — Post-call/SMS analysis (`api/ai/analyze-sentiment.js`)

**SMS Flow:**
```
Patient texts → Twilio webhook → /api/webhooks/twilio-sms
  → Lookup patient by phone
  → Load conversation history (in-memory, 30min TTL)
  → Claude generates response (system prompt with practice knowledge)
  → Twilio sends reply
  → Handle actions (directions, scheduling links)
```

**Sentiment Analysis Output:**
```json
{
  "satisfaction": 4,
  "emotion": "satisfied",
  "escalationNeeded": false,
  "keyIssues": [],
  "aiPerformance": 4,
  "summary": "Positive interaction"
}
```

### Voice System

**Architecture:**
```
Staff initiates call
  → POST /api/voice/ai-outbound-call
    → Twilio creates call
    → Call connects → TwiML from /api/voice/outbound-twiml
    → Speech recognition (Deepgram via Twilio)
    → AI response via /api/voice/ai-call-response
    → ElevenLabs TTS → audio stream
    → Loop until conversation ends
    → POST /api/voice/call-complete
    → Sentiment analysis
```

**Voice Endpoints:**
| Endpoint | Purpose |
|----------|---------|
| `ai-outbound-call` | Initiate outbound call |
| `ai-call-response` | Generate AI response during call |
| `inbound-call` | Handle incoming calls |
| `handle-call` | TwiML call flow controller |
| `elevenlabs-tts` | Text-to-speech conversion |
| `elevenlabs-call` | Direct ElevenLabs call |
| `generate-audio` | Generate audio files |
| `book-appointment` | Voice-driven booking |
| `call-complete` | Post-call processing |
| `call-logs` | Retrieve call history |
| `settings` | Voice configuration |
| `send-link` | SMS link during call |

### Communication Service Layer

```typescript
// Frontend: src/lib/services/unified-communication-service.ts
UnifiedCommunicationService
  .sendSMS({ to, message, patientId, patientName, sentBy })
  .sendEmail({ to, subject, body, patientId, patientName, sentBy })
  .makeCall({ to, message, patientId, patientName, calledBy })
```

Falls back to demo mode when Twilio/SES is not configured.

### Journey Communication Triggers

Automated communications fire on journey events:

| Event | Trigger | Example |
|-------|---------|---------|
| `journey_started` | Welcome message | "Welcome! Your visit is starting." |
| `step_started` | Step notification | "Pre-testing is beginning." |
| `phase_changed` | Phase transition | "Your exam is complete!" |
| `journey_completed` | Follow-up | "Thank you for visiting!" |

---

## 10. Frame Scanner & Measurements

### Frame Scanner Service

```typescript
// src/lib/services/frame-scanner-service.ts
FrameScannerService
  .generatePatientToken(patientId, companyId)  → JWT (7-day)
  .verifyPatientToken(token)                    → { patientId, companyId }
  .lookupFrame(upcCode)                         → FrameCatalog
  .scanFrame(upcCode, patientId, companyId)     → ScanResult
  .getFavorites(patientId, companyId)            → PatientFavoriteFrame[]
  .removeFavorite(favoriteId)                    → boolean
```

### Measurement Service

```typescript
// src/lib/services/measurement-service.ts
MeasurementService
  .calibrateWithCreditCard(leftX, rightX, imageWidth)   → CalibrationResult
  .calibrateWithIris(landmarks, imageWidth)              → CalibrationResult
  .calculatePD(landmarks, calibration, w, h)             → PDResult
  .calculateSegHeight(landmarks, frameY, cal, w, h)      → SegHeightResult
  .extractFaceGeometry(landmarks, cal, w, h)             → FaceGeometry
  .generateFaceSVG(geometry, pdResult)                   → string (SVG)
```

### Head Movement Service

```javascript
// src/lib/services/head-movement-service.js
HeadMovementService
  .calculateHeadPose(landmarks)              → { yaw, pitch, roll }
  .recordFrame(landmarks, sequence, type)    → void
  .calculateDepthMap(sequence)               → { depthMap, referenceFrame }
  .calculateEnhancedPD(landmarks, depth, cal)→ EnhancedPDResult
```

### MediaPipe Landmarks Reference

| Landmark | Index | Purpose |
|----------|-------|---------|
| Left Iris Center | 468 | PD measurement |
| Right Iris Center | 473 | PD measurement |
| Nose Bridge | 6 | Monocular PD reference |
| Forehead Top | 10 | Face height |
| Chin Bottom | 152 | Face height |
| Left Cheekbone | 234 | Face width |
| Right Cheekbone | 454 | Face width |
| Face Oval | 10,338,297... (36 pts) | Face outline SVG |

---

## 11. Eyefinity EHR Integration

### Proxy Architecture

```
Frontend → /api/eyefinity/* → Eyefinity API
              │
              ├── Resolve company credentials
              ├── Handle OAuth token refresh
              ├── Append tenant headers
              └── Proxy request with auth
```

### Key Proxy Endpoints

| Local Path | Eyefinity Path | Purpose |
|-----------|---------------|---------|
| `/api/eyefinity/v2patients` | `/v2/Patients` | Patient search |
| `/api/eyefinity/v2patients/[id]` | `/v2/Patients/{id}` | Patient detail |
| `/api/eyefinity/offices` | `/Offices` | Office list |
| `/api/eyefinity/providers` | `/Providers` | Provider list |
| `/api/eyefinity/staff` | `/Staff` | Staff list |
| `/api/eyefinity/rx` | `/Rx/Orders` | Prescription data |

### Eyefinity Integration Service

```typescript
// src/lib/services/eyefinity-integration-service.ts
EyefinityIntegrationService
  .testConnection(company)        → boolean
  .syncOffices(company)           → SyncResult
  .syncProviders(company)         → SyncResult
  .syncStaff(company)             → SyncResult
  .fullSync(company)              → { offices, providers, staff }
  .getPatientRx(patientId)        → RxData
  .getPatientOrders(patientId)    → OrderData[]
```

---

## 12. Key Services Reference

### Frontend Services

| Service | Location | Purpose |
|---------|----------|---------|
| `PatientAppService` | `src/lib/services/patient-app-service.ts` | Patient portal auth, journey, billing |
| `PatientJourneyService` | `src/lib/services/patient-journey-service.ts` | Journey data access |
| `EyefinityService` | `src/lib/services/eyefinity-service.ts` | Eyefinity API client |
| `EyefinityIntegrationService` | `src/lib/services/eyefinity-integration-service.ts` | Data sync |
| `FrameScannerService` | `src/lib/services/frame-scanner-service.ts` | Frame scanning |
| `MeasurementService` | `src/lib/services/measurement-service.ts` | PD/seg calculations |
| `HeadMovementService` | `src/lib/services/head-movement-service.js` | 3D head tracking |
| `LiDARService` | `src/lib/services/lidar-service.ts` | WebXR depth sensing |
| `UnifiedCommunicationService` | `src/lib/services/unified-communication-service.ts` | SMS/email/voice |
| `AICommunicationOrchestrator` | `src/lib/services/ai-communication-orchestrator.ts` | AI comm config |
| `JourneyCommunicationTrigger` | `src/lib/services/journey-communication-trigger.ts` | Auto triggers |
| `RecommendationService` | `src/lib/services/recommendation-service.ts` | Product recs |
| `FtcComplianceService` | `src/lib/services/ftc-compliance-service.ts` | FTC records |
| `HipaaComplianceService` | `src/lib/services/hipaa-compliance-service.ts` | HIPAA tracking |
| `OfficeRoomsService` | `src/lib/services/office-rooms-service.ts` | Room management |
| `DemoModeService` | `src/services/demoModeService.ts` | Demo mode controls |
| `CommunicationService` | `src/services/communicationService.ts` | Legacy comms |

### AI Services

| Service | Location | Purpose |
|---------|----------|---------|
| `UnifiedAIResponseService` | `src/services/ai/unified-ai-response-service.ts` | Central AI response |
| `NLUService` | `src/services/ai/nlu-service.ts` | Natural language understanding |
| `SMSEvaluationService` | `src/services/ai/sms-evaluation-service.ts` | SMS quality scoring |
| `CallEvaluationService` | `src/services/ai/call-evaluation-service.ts` | Call quality scoring |
| `AIPersona` | `src/services/ai/ai-persona.ts` | AI character config |
| `ToolRegistry` | `src/services/ai/tool-registry.ts` | AI tool definitions |

---

## 13. API Endpoints Reference

### Authentication (`/api/auth/`)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/auth/login` | None | Login with email/password |
| GET | `/api/auth/session` | Bearer | Validate session |
| POST | `/api/auth/session` | Bearer | Refresh session |
| DELETE | `/api/auth/session` | Bearer | Logout |
| POST | `/api/auth/register` | Invite token | Register new user |
| POST | `/api/auth/invite` | Admin | Create invitation |
| GET | `/api/auth/invite` | Admin | List invitations |
| DELETE | `/api/auth/invite` | Admin | Revoke invitation |
| GET | `/api/auth/users` | Admin | List users |
| PUT | `/api/auth/users` | Admin | Update user role |
| DELETE | `/api/auth/users` | Admin | Delete user |
| POST | `/api/auth/init` | None | Initialize default admin |

### Patients (`/api/patients/`)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/patients` | Bearer | List patients |
| POST | `/api/patients` | Bearer | Create patient |
| GET | `/api/patients/[id]` | Bearer | Get patient by ID |
| PUT | `/api/patients/[id]` | Bearer | Update patient |
| DELETE | `/api/patients/[id]` | Bearer | Delete patient |

### Patient Self-Service (`/api/patient/`)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/patient/frame-scan` | JWT token | Scan UPC barcode |
| GET | `/api/patient/favorites` | JWT token | Get favorite frames |
| DELETE | `/api/patient/favorites` | JWT token | Remove favorite |
| POST | `/api/patient/measurements` | JWT token | Save measurements |
| GET | `/api/patient/measurements` | JWT token | Get measurements |

### Eyefinity Proxy (`/api/eyefinity/`)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/eyefinity/v2patients` | Bearer | Search patients |
| GET | `/api/eyefinity/v2patients/[id]` | Bearer | Get patient |
| GET | `/api/eyefinity/offices` | Bearer | List offices |
| GET | `/api/eyefinity/providers` | Bearer | List providers |
| GET | `/api/eyefinity/staff` | Bearer | List staff |

### Communications (`/api/communications/`)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/communications/sms` | Bearer | Send SMS |
| POST | `/api/communications/send-email` | Bearer | Send email |
| POST | `/api/communications/send-invite` | Bearer | Send patient invite |

### Voice (`/api/voice/`)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/voice/ai-outbound-call` | Bearer | Initiate AI call |
| POST | `/api/voice/ai-call-response` | None (Twilio) | AI response during call |
| POST | `/api/voice/inbound-call` | None (Twilio) | Handle inbound |
| GET/POST | `/api/voice/settings` | Bearer | Voice settings |
| POST | `/api/voice/elevenlabs-tts` | Bearer | Text-to-speech |
| POST | `/api/voice/book-appointment` | None (Twilio) | Voice booking |
| POST | `/api/voice/call-complete` | None (Twilio) | Post-call processing |
| GET | `/api/voice/call-logs` | Bearer | Call history |

### AI (`/api/ai/`)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/ai/analyze-sentiment` | Bearer | Analyze conversation sentiment |

### Webhooks (`/api/webhooks/`)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/webhooks/twilio-sms` | Twilio SID | Inbound SMS handler |

### Check-In (`/api/checkin/`)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/checkin/verify` | None | Verify patient for check-in |

---

## 14. Data Flow Diagrams

### Patient Visit Flow

```
1. Patient receives appointment link (SMS/Email)
        │
        ▼
2. Patient logs into portal (Appointment ID + DOB)
        │
        ▼
3. Patient completes pre-visit tasks:
   ├── HIPAA signature
   ├── Medical history forms
   └── Insurance verification
        │
        ▼
4. Patient arrives → Check-in (verify identity)
        │
        ▼
5. Journey Board tracks progress:
   ├── Pre-Testing → Exam Room → Doctor
   ├── Real-time wait time updates
   └── AI communications at each step
        │
        ▼
6. Post-exam:
   ├── Rx generated in Eyefinity
   ├── FTC acknowledgement captured
   ├── Frame scanning (optional)
   └── Measurements (optional)
        │
        ▼
7. Checkout:
   ├── Billing generated
   ├── Payment processed
   └── Follow-up scheduled
        │
        ▼
8. Post-visit:
   ├── AI follow-up call/text
   ├── Satisfaction survey
   └── Recall scheduling
```

### Measurement Data Flow

```
Patient Device                     Server                      Database
     │                               │                            │
     │── Camera captures face ──>    │                            │
     │── MediaPipe detects 478       │                            │
     │   landmarks locally           │                            │
     │                               │                            │
     │── Calibration (credit card    │                            │
     │   or iris) → pixels/mm        │                            │
     │                               │                            │
     │── Head movements recorded     │                            │
     │   (8 poses, 5 FPS)            │                            │
     │                               │                            │
     │── PD calculated locally       │                            │
     │── Seg height calculated       │                            │
     │── Face geometry extracted     │                            │
     │── SVG generated (no photos)   │                            │
     │                               │                            │
     │── POST /api/patient/          │                            │
     │   measurements ──────────────>│── Save to                  │
     │   { pd, seg, face_geometry,   │   patient_measurements ──>│
     │     depth_map, svg }          │── Save to                  │
     │                               │   patient_face_profiles ─>│
     │                               │── Calculate frame recs ──>│
     │<── { success, measurement } ──│                            │
```

---

## 15. Development Workflow

### Local Development

```bash
# Install dependencies
npm install

# Start dev server
npm run dev
# → Vite dev server at http://localhost:5173

# Build for production
npm run build
# → Output to dist/

# Preview production build
npm run preview
```

### Environment Variables

Create a `.env` file in the project root:

```env
# Supabase
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key

# Vercel KV (Redis)
KV_URL=redis://...
KV_REST_API_URL=https://...
KV_REST_API_TOKEN=...

# Eyefinity (per-company, stored in DB)
# These are fallback defaults
EPM_CLIENT_ID=
EPM_CLIENT_SECRET=
TENANT_UID=
OAUTH_HOST=

# AI
ANTHROPIC_API_KEY=sk-ant-...

# Twilio
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_PHONE_NUMBER=

# ElevenLabs
ELEVENLABS_API_KEY=
ELEVENLABS_VOICE_NAME=emily

# Patient Tokens
PATIENT_TOKEN_SECRET=your-secret-key

# App URL
VITE_APP_URL=https://your-domain.vercel.app
```

### Deployment

The project deploys to Vercel:

1. Push to `main` branch → automatic deployment
2. Vercel builds with `vite build`
3. API functions deployed as serverless endpoints
4. Environment variables configured in Vercel dashboard

### Vercel Configuration

```json
// vercel.json
{
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
```

### Testing

Ad-hoc test scripts are in the project root (`test-*.js`). Run with:

```bash
node test-eyefinity-proxy.js
node test-ai-communications.js
```

A formal test framework (in `tests/` directory) is in development.

---

*Last updated: February 2026*
*Eyefinity Patient Readiness Center — Developer Guide v1.0*
