# Deployment & Configuration Guide

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Environment Setup](#2-environment-setup)
3. [Vercel Deployment](#3-vercel-deployment)
4. [Database Setup (Supabase)](#4-database-setup-supabase)
5. [Vercel KV (Redis) Setup](#5-vercel-kv-redis-setup)
6. [Eyefinity EHR Configuration](#6-eyefinity-ehr-configuration)
7. [AI Services Configuration](#7-ai-services-configuration)
8. [Communication Services (Twilio)](#8-communication-services-twilio)
9. [Voice AI (ElevenLabs)](#9-voice-ai-elevenlabs)
10. [Environment Variables Reference](#10-environment-variables-reference)
11. [First-Time Setup Checklist](#11-first-time-setup-checklist)
12. [Multi-Environment Strategy](#12-multi-environment-strategy)
13. [Monitoring & Maintenance](#13-monitoring--maintenance)
14. [Security Checklist](#14-security-checklist)
15. [Troubleshooting Deployment Issues](#15-troubleshooting-deployment-issues)

---

## 1. Prerequisites

### Required Accounts

| Service | Purpose | Required? |
|---------|---------|-----------|
| [Vercel](https://vercel.com) | Hosting & serverless functions | Yes |
| [Supabase](https://supabase.com) | PostgreSQL database | Yes |
| [Anthropic](https://console.anthropic.com) | Claude AI API | Yes (for AI features) |
| [Twilio](https://twilio.com) | SMS & Voice | Yes (for communications) |
| [ElevenLabs](https://elevenlabs.io) | Voice synthesis | Optional (for AI voice) |
| Eyefinity EHR | Patient data | Yes (for EHR integration) |

### Development Tools

- Node.js 18+ (recommended: 20 LTS)
- npm 9+
- Git
- Vercel CLI (`npm i -g vercel`)

---

## 2. Environment Setup

### Local Development

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd Timeline
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Create environment file:**
   ```bash
   cp .env.example .env
   # Edit .env with your values (see Section 10 for full reference)
   ```

4. **Start development server:**
   ```bash
   npm run dev
   ```
   The app will be available at `http://localhost:5173`

5. **Test API functions locally:**
   ```bash
   vercel dev
   ```
   This runs the Vercel dev server with serverless function support.

### Build for Production

```bash
npm run build
```

Output is generated in the `dist/` directory.

---

## 3. Vercel Deployment

### Initial Setup

1. **Connect your repository to Vercel:**
   - Go to [vercel.com/new](https://vercel.com/new)
   - Import your Git repository
   - Vercel auto-detects the Vite framework

2. **Configure build settings:**
   | Setting | Value |
   |---------|-------|
   | Framework Preset | Vite |
   | Build Command | `vite build` |
   | Output Directory | `dist` |
   | Install Command | `npm install` |

3. **Set environment variables:**
   - Go to Project Settings → Environment Variables
   - Add all required variables (see Section 10)
   - Ensure variables are set for the correct environments (Production, Preview, Development)

4. **Deploy:**
   ```bash
   vercel --prod
   ```

### Automatic Deployments

- Push to `main` → Production deployment
- Push to other branches → Preview deployment
- Pull requests get automatic preview URLs

### Custom Domain

1. Go to Project Settings → Domains
2. Add your custom domain
3. Configure DNS as instructed by Vercel
4. SSL is automatically provisioned

---

## 4. Database Setup (Supabase)

### Create a Supabase Project

1. Go to [supabase.com](https://supabase.com) and create a new project
2. Note your project URL and anon key

### Run Database Migrations

Execute the following SQL to create required tables:

```sql
-- Accounts (top-level organizations)
CREATE TABLE IF NOT EXISTS accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Companies (tenants)
CREATE TABLE IF NOT EXISTS companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id UUID REFERENCES accounts(id),
  name TEXT NOT NULL,
  eyefinity_company_id TEXT,
  eyefinity_base_url TEXT,
  eyefinity_api_key TEXT,
  eyefinity_api_secret TEXT,
  tenant_uid TEXT,
  oauth_host TEXT DEFAULT 'pm-ci.eyefinity.com',
  api_base_url TEXT DEFAULT 'https://pm-ci.eyefinity.com',
  api_path TEXT DEFAULT 'al-pe',
  oauth_token TEXT,
  oauth_refresh_token TEXT,
  oauth_token_expires_at TIMESTAMPTZ,
  twilio_account_sid TEXT,
  twilio_auth_token TEXT,
  twilio_phone_number TEXT,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Offices
CREATE TABLE IF NOT EXISTS offices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID REFERENCES companies(id),
  eyefinity_office_id TEXT,
  name TEXT NOT NULL,
  address TEXT,
  city TEXT,
  state TEXT,
  zip TEXT,
  phone TEXT,
  email TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Staff
CREATE TABLE IF NOT EXISTS staff (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID REFERENCES companies(id),
  office_id UUID REFERENCES offices(id),
  eyefinity_staff_id TEXT,
  name TEXT NOT NULL,
  role TEXT,
  email TEXT,
  phone TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Frame Catalog
CREATE TABLE IF NOT EXISTS frame_catalog (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  upc_code VARCHAR(13) UNIQUE,
  manufacturer TEXT,
  brand TEXT,
  model_name TEXT,
  model_number TEXT,
  color_name TEXT,
  color_code TEXT,
  lens_width INTEGER,
  bridge_width INTEGER,
  temple_length INTEGER,
  frame_width INTEGER,
  material TEXT,
  frame_type TEXT,
  shape TEXT,
  wholesale_price DECIMAL(10,2),
  retail_price DECIMAL(10,2),
  image_url TEXT,
  additional_images JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Patient Favorite Frames
CREATE TABLE IF NOT EXISTS patient_favorite_frames (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL,
  company_id UUID REFERENCES companies(id),
  upc_code VARCHAR(13) NOT NULL,
  frame_name TEXT,
  frame_manufacturer TEXT,
  frame_model TEXT,
  frame_color TEXT,
  frame_size TEXT,
  image_url TEXT,
  notes TEXT,
  is_purchased BOOLEAN DEFAULT FALSE,
  scanned_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(patient_id, upc_code)
);

-- Patient Measurements
CREATE TABLE IF NOT EXISTS patient_measurements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL,
  company_id UUID REFERENCES companies(id),
  measured_at TIMESTAMPTZ DEFAULT NOW(),
  pd_total DECIMAL(4,1),
  pd_right DECIMAL(4,1),
  pd_left DECIMAL(4,1),
  seg_height_right DECIMAL(4,1),
  seg_height_left DECIMAL(4,1),
  oc_height_right DECIMAL(4,1),
  oc_height_left DECIMAL(4,1),
  measurement_method VARCHAR(50),
  calibration_factor DECIMAL(8,4),
  confidence_score DECIMAL(3,2),
  device_type VARCHAR(100),
  has_lidar BOOLEAN DEFAULT FALSE,
  face_landmarks JSONB,
  frame_markers JSONB,
  calibration_data JSONB,
  image_url TEXT,
  status VARCHAR(20) DEFAULT 'pending_approval',
  is_approved BOOLEAN DEFAULT FALSE,
  verified_by_staff UUID,
  verified_at TIMESTAMPTZ,
  notes TEXT
);

-- Patient Face Profiles
CREATE TABLE IF NOT EXISTS patient_face_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL,
  company_id UUID REFERENCES companies(id),
  face_width DECIMAL(5,1),
  face_height DECIMAL(5,1),
  jaw_width DECIMAL(5,1),
  cheekbone_width DECIMAL(5,1),
  forehead_width DECIMAL(5,1),
  face_shape VARCHAR(20),
  face_shape_confidence DECIMAL(3,2),
  pd_total DECIMAL(4,1),
  pd_right DECIMAL(4,1),
  pd_left DECIMAL(4,1),
  outline_points JSONB,
  face_svg TEXT,
  measurement_id UUID REFERENCES patient_measurements(id),
  recommended_frame_widths JSONB,
  recommended_bridge_widths JSONB,
  recommended_temple_lengths JSONB,
  is_active BOOLEAN DEFAULT TRUE,
  source VARCHAR(50) DEFAULT 'self_service',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Head Movement Calibration
CREATE TABLE IF NOT EXISTS head_movement_calibration (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL,
  company_id UUID REFERENCES companies(id),
  measurement_id UUID REFERENCES patient_measurements(id),
  movement_sequence JSONB,
  depth_map JSONB,
  reference_frame JSONB,
  quality_score DECIMAL(3,2),
  has_3d_data BOOLEAN DEFAULT FALSE,
  frame_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_companies_account ON companies(account_id);
CREATE INDEX IF NOT EXISTS idx_offices_company ON offices(company_id);
CREATE INDEX IF NOT EXISTS idx_staff_company ON staff(company_id);
CREATE INDEX IF NOT EXISTS idx_measurements_patient ON patient_measurements(patient_id);
CREATE INDEX IF NOT EXISTS idx_favorites_patient ON patient_favorite_frames(patient_id);
CREATE INDEX IF NOT EXISTS idx_face_profiles_patient ON patient_face_profiles(patient_id);
CREATE INDEX IF NOT EXISTS idx_head_movement_measurement ON head_movement_calibration(measurement_id);
```

### Configure Supabase Environment Variables

Add to Vercel:
```
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=eyJ...your-anon-key
```

---

## 5. Vercel KV (Redis) Setup

### Enable Vercel KV

1. Go to your Vercel project dashboard
2. Navigate to **Storage** tab
3. Click **Create Database** → **KV**
4. Select your region
5. Environment variables are automatically added:
   - `KV_URL`
   - `KV_REST_API_URL`
   - `KV_REST_API_TOKEN`
   - `KV_REST_API_READ_ONLY_TOKEN`

### Alternative: Upstash Redis

If not using Vercel KV:
1. Create a database at [upstash.com](https://upstash.com)
2. Add the Redis URL to your environment:
   ```
   KV_URL=redis://default:...@your-redis.upstash.io:6379
   ```

---

## 6. Eyefinity EHR Configuration

### OAuth Setup (Cloud Environments)

For Sandbox and Staging environments:

```env
EPM_CLIENT_ID=your-client-id
EPM_CLIENT_SECRET=your-client-secret
TENANT_UID=your-tenant-uid
OAUTH_HOST=api-sandbox.eyefinity.com
EYEFINITY_API_URL=https://api-sandbox.eyefinity.com
```

### Static Token Setup (VPN/Integration Environments)

For environments behind a VPN that Vercel cannot reach:

1. Generate a token from the Eyefinity environment
2. In the app, go to **Admin → Settings**
3. Select **"Static Access Token"**
4. Enter the API Base URL (e.g., `https://pm-ci.eyefinity.com`)
5. Enter the API Path (e.g., `al-pe`)
6. Paste the access token
7. Click **"Save Settings"**

### Environment Matrix

| Environment | VPN Required | Auth Method | Auto-Refresh |
|------------|-------------|-------------|--------------|
| Sandbox | No | OAuth | Yes |
| Staging | No | OAuth | Yes |
| Integration (CI) | Yes | Static Token | No |
| Production | No | OAuth | Yes |

---

## 7. AI Services Configuration

### Anthropic (Claude AI)

1. Get an API key from [console.anthropic.com](https://console.anthropic.com)
2. Add to environment:
   ```env
   ANTHROPIC_API_KEY=sk-ant-api03-...
   ```

The system uses `claude-3-5-haiku-20241022` for:
- SMS response generation
- Voice call conversation
- Sentiment analysis
- Patient communication

---

## 8. Communication Services (Twilio)

### Twilio Setup

1. Create a Twilio account at [twilio.com](https://twilio.com)
2. Purchase a phone number with SMS and Voice capabilities
3. Add credentials:
   ```env
   TWILIO_ACCOUNT_SID=AC...
   TWILIO_AUTH_TOKEN=...
   TWILIO_PHONE_NUMBER=+15551234567
   ```

### Configure Webhooks

In the Twilio Console:

1. Go to **Phone Numbers → Manage → Active Numbers**
2. Click your number
3. Under **Messaging**:
   - "A Message Comes In" → **Webhook**
   - URL: `https://your-domain.vercel.app/api/webhooks/twilio-sms`
   - Method: **POST**
4. Under **Voice & Fax**:
   - "A Call Comes In" → **Webhook**
   - URL: `https://your-domain.vercel.app/api/voice/inbound-call`
   - Method: **POST**

---

## 9. Voice AI (ElevenLabs)

### ElevenLabs Setup (Optional)

1. Create an account at [elevenlabs.io](https://elevenlabs.io)
2. Get your API key
3. Add to environment:
   ```env
   ELEVENLABS_API_KEY=...
   ELEVENLABS_VOICE_NAME=emily
   ```

### Available Voices

| Name | Gender | Style |
|------|--------|-------|
| emily | Female | Professional, warm |
| amy | Female | Friendly, casual |
| jessica | Female | Clear, articulate |
| sarah | Female | Calm, reassuring |
| rachel | Female | Energetic |
| josh | Male | Professional |
| adam | Male | Deep, authoritative |

---

## 10. Environment Variables Reference

### Required Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `SUPABASE_URL` | Supabase project URL | `https://xyz.supabase.co` |
| `SUPABASE_ANON_KEY` | Supabase anonymous key | `eyJ...` |
| `KV_URL` | Redis connection URL | `redis://...` |
| `KV_REST_API_URL` | Vercel KV REST URL | `https://...` |
| `KV_REST_API_TOKEN` | Vercel KV token | `...` |
| `PATIENT_TOKEN_SECRET` | JWT signing secret for patient tokens | `your-secret-key-min-32-chars` |
| `VITE_APP_URL` | Public app URL | `https://your-app.vercel.app` |

### AI & Communication Variables

| Variable | Description | Required For |
|----------|-------------|-------------|
| `ANTHROPIC_API_KEY` | Claude AI API key | AI features |
| `TWILIO_ACCOUNT_SID` | Twilio Account SID | SMS/Voice |
| `TWILIO_AUTH_TOKEN` | Twilio Auth Token | SMS/Voice |
| `TWILIO_PHONE_NUMBER` | Twilio phone number | SMS/Voice |
| `ELEVENLABS_API_KEY` | ElevenLabs API key | Voice synthesis |
| `ELEVENLABS_VOICE_NAME` | Default voice name | Voice synthesis |

### Eyefinity Variables (Defaults)

| Variable | Description | Default |
|----------|-------------|---------|
| `EPM_CLIENT_ID` | Eyefinity OAuth Client ID | (per company) |
| `EPM_CLIENT_SECRET` | Eyefinity OAuth Client Secret | (per company) |
| `TENANT_UID` | Eyefinity Tenant UID | (per company) |
| `OAUTH_HOST` | OAuth server hostname | `pm-ci.eyefinity.com` |
| `EYEFINITY_API_URL` | Eyefinity API base URL | `https://pm-ci.eyefinity.com` |

### Task System Variables

| Variable | Description |
|----------|-------------|
| `TASK_CRON_SECRET` | Secret for cron job authentication |

### Client-Side Variables (VITE_ prefix)

| Variable | Description |
|----------|-------------|
| `VITE_APP_URL` | Public app URL |
| `VITE_API_BASE_URL` | API base URL (usually same as app URL) |
| `VITE_TWILIO_ACCOUNT_SID` | Twilio SID (for client-side feature detection) |

> **Note:** Only variables prefixed with `VITE_` are exposed to the frontend. All others are server-side only.

---

## 11. First-Time Setup Checklist

### Step 1: Infrastructure
- [ ] Create Vercel project and connect Git repository
- [ ] Create Supabase project
- [ ] Enable Vercel KV
- [ ] Set all required environment variables

### Step 2: Database
- [ ] Run SQL migrations (Section 4)
- [ ] Verify tables created in Supabase dashboard

### Step 3: Deploy
- [ ] Push code to trigger deployment
- [ ] Verify deployment succeeds
- [ ] Access the deployed URL

### Step 4: Initial Login
- [ ] Navigate to `/login`
- [ ] Login with default credentials:
  - Email: `admin@visioncare.local`
  - Password: `Admin@123456`
- [ ] Change password immediately when prompted

### Step 5: Company Setup
- [ ] Go to Admin Dashboard
- [ ] Run the Setup Wizard
- [ ] Create your account and company
- [ ] Connect to Eyefinity (OAuth or Static Token)
- [ ] Import offices, providers, and staff

### Step 6: Communication Setup
- [ ] Configure Twilio webhooks (Section 8)
- [ ] Test SMS sending from a patient card
- [ ] Test voice call if ElevenLabs is configured

### Step 7: AI Configuration
- [ ] Populate the AI Knowledge Base with practice information
- [ ] Test AI responses using the AI Test page
- [ ] Verify sentiment analysis on test conversations

### Step 8: Invite Staff
- [ ] Go to User Management
- [ ] Send invitations to staff members
- [ ] Assign appropriate roles (admin, manager, associate)

---

## 12. Multi-Environment Strategy

### Recommended Setup

| Environment | Branch | Vercel | Eyefinity | Purpose |
|------------|--------|--------|-----------|---------|
| Development | feature/* | Preview | Sandbox | Active development |
| Staging | staging | Preview | Staging | Pre-production testing |
| Production | main | Production | Production | Live environment |

### Environment-Specific Variables

Use Vercel's environment scoping:
- **Production** — Live API keys, production Eyefinity
- **Preview** — Test API keys, sandbox Eyefinity
- **Development** — Local/test API keys

### Switching Environments in the App

Admin users can use the **Environment Switcher** in the header to toggle between Eyefinity environments without redeployment. This changes the API routing, not the deployment environment.

---

## 13. Monitoring & Maintenance

### Vercel Dashboard

- **Functions** tab — Monitor serverless function performance
- **Logs** tab — View real-time application logs
- **Analytics** tab — Traffic and performance metrics

### Key Metrics to Watch

| Metric | Healthy Range | Action if Exceeded |
|--------|--------------|-------------------|
| Function duration | < 10s | Optimize or increase timeout |
| Error rate | < 1% | Check logs for patterns |
| KV operations | < 10,000/day (free tier) | Upgrade plan |
| Supabase connections | < pool limit | Check for connection leaks |

### Scheduled Tasks

The cron runner (`/api/tasks/cron-runner`) executes every 5 minutes:
- Processes scheduled communications
- Moves delayed tasks to active queue
- Cleans up expired sessions

Configure in `vercel.json`:
```json
{
  "crons": [
    {
      "path": "/api/tasks/cron-runner",
      "schedule": "*/5 * * * *"
    }
  ]
}
```

### Database Maintenance

- **Supabase**: Auto-managed backups
- **Vercel KV**: Automatic session cleanup via TTL
- **Manually clean**: Expired invites, old measurement data

---

## 14. Security Checklist

### Before Going Live

- [ ] Change default admin password
- [ ] Set strong `PATIENT_TOKEN_SECRET` (32+ characters)
- [ ] Enable MFA for admin accounts
- [ ] Verify CORS configuration in API endpoints
- [ ] Ensure all API keys are in Vercel env vars (not in code)
- [ ] Review Supabase Row Level Security policies
- [ ] Test account lockout mechanism
- [ ] Verify session expiry works correctly
- [ ] Confirm HTTPS is enforced (Vercel handles this)

### Ongoing Security

- [ ] Rotate API keys quarterly
- [ ] Review user access lists monthly
- [ ] Monitor for unusual login patterns
- [ ] Update dependencies for security patches
- [ ] Review Twilio webhook security
- [ ] Audit HIPAA compliance records

### Data Protection

- **Patient photos**: Never stored — only geometric data (SVG outlines, measurements)
- **Passwords**: bcrypt-hashed with 12 salt rounds
- **Sessions**: Auto-expire after 8 hours
- **Patient tokens**: JWT with 7-day expiry
- **FTC records**: Retained 3 years per regulation
- **HIPAA signatures**: 1-year validity with audit trail

---

## 15. Troubleshooting Deployment Issues

### Build Fails

**"Module not found" errors:**
```bash
# Ensure all dependencies are installed
npm install
# Check for missing peer dependencies
npm ls
```

**TypeScript errors:**
The project uses JSX with TypeScript types. Ensure `vite-env.d.ts` exists and Vite config includes the React plugin.

### API Functions Not Working

**500 errors on API calls:**
1. Check Vercel function logs
2. Verify environment variables are set
3. Ensure database connection string is correct
4. Check for cold-start timeouts (increase function duration limit)

**CORS errors:**
All API functions should include CORS headers. If a new endpoint is missing them, add:
```javascript
res.setHeader('Access-Control-Allow-Origin', '*');
res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
if (req.method === 'OPTIONS') return res.status(200).end();
```

### Database Connection Issues

**"Connection refused":**
- Verify `SUPABASE_URL` is correct
- Check Supabase project is not paused (free tier pauses after inactivity)
- Verify network access settings in Supabase

**"Too many connections":**
- The serverless architecture can exhaust connection pools
- Use Supabase connection pooling (port 6543 instead of 5432)
- Ensure connections are properly closed

### Authentication Issues

**"Default admin not created":**
- Hit the `/api/auth/init` endpoint manually
- Check Vercel KV is connected and accessible

**"Token expired" immediately after login:**
- Check server time is synchronized
- Verify KV_URL is correct
- Check KV storage quotas

### Eyefinity Integration Issues

**"OAuth token refresh failed":**
- Verify client credentials in company settings
- Check OAuth host is accessible from Vercel
- For VPN environments, switch to static tokens

**"Connection timeout":**
- VPN-only environments cannot be reached from Vercel
- Use static token authentication instead
- Consider a proxy server within the VPN

### Camera/Measurement Issues

**"Camera not starting":**
- HTTPS is required (camera API requires secure context)
- Check browser permissions
- Verify `getUserMedia` is available (requires modern browser)
- On iOS, only Safari supports camera access in web apps

**"MediaPipe not loading":**
- Check CDN availability: `https://unpkg.com/@mediapipe/face_mesh@0.4.1633559619/`
- May be blocked by corporate firewalls
- Consider self-hosting MediaPipe assets

---

*Last updated: February 2026*
*Eyefinity Patient Readiness Center — Deployment Guide v1.0*
