#!/usr/bin/env node

/**
 * Test all patient API endpoints including the fixed RX/Orders and new Communication Methods
 */

const testPatientId = 'ecab1a6c-5aba-457a-870a-2743822de084';

console.log('🧪 TESTING ALL PATIENT API ENDPOINTS\n');
console.log(`Patient ID: ${testPatientId}\n`);

const endpoints = [
  {
    name: 'Patient Details',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testPatientId}`,
    description: 'Basic patient information',
    expectedStatus: 200
  },
  {
    name: 'Patient RX (FIXED)',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testPatientId}/rx?page=1&pageSize=100`,
    description: 'Patient prescriptions using GUID with v2patients endpoint',
    expectedStatus: 200
  },
  {
    name: 'Patient Orders (FIXED)', 
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2orders?patientId=${testPatientId}&fromStatusChangedDate=2020-01-01&toStatusChangedDate=2026-01-27&page=1&pageSize=100`,
    description: 'Patient orders using v2orders with GUID query parameter',
    expectedStatus: 200
  },
  {
    name: 'Communication Methods (NEW)',
    url: `https://patientcare-teal.vercel.app/api/eyefinity/v2patients/${testPatientId}/communicationmethods`,
    description: 'Patient communication preferences and methods',
    expectedStatus: 200
  }
];

const testEndpoint = async (endpoint) => {
  try {
    console.log(`\n🔍 ${endpoint.name}:`);
    console.log(`   Description: ${endpoint.description}`);
    console.log(`   URL: ${endpoint.url}`);
    
    const startTime = Date.now();
    const response = await fetch(endpoint.url);
    const duration = Date.now() - startTime;
    
    console.log(`   Status: ${response.status} (${duration}ms)`);
    console.log(`   Expected: ${endpoint.expectedStatus}`);
    
    if (response.status === endpoint.expectedStatus) {
      try {
        const data = await response.json();
        
        if (endpoint.name.includes('RX')) {
          const itemCount = data.items?.length || 0;
          console.log(`   ✅ SUCCESS - RX Items: ${itemCount}`);
          if (data.items && data.items.length > 0) {
            console.log(`   Sample RX keys: ${Object.keys(data.items[0]).slice(0, 6).join(', ')}`);
          }
        } else if (endpoint.name.includes('Orders')) {
          const itemCount = data.items?.length || 0;
          console.log(`   ✅ SUCCESS - Order Items: ${itemCount}`);
          if (data.items && data.items.length > 0) {
            console.log(`   Sample Order keys: ${Object.keys(data.items[0]).slice(0, 6).join(', ')}`);
          }
        } else if (endpoint.name.includes('Communication')) {
          console.log(`   ✅ SUCCESS - Communication Methods`);
          if (data.Methods) {
            console.log(`   Communication Methods: ${data.Methods.length} found`);
            console.log(`   Primary Phone: ${data.PrimaryPhone || 'N/A'}`);
            console.log(`   Email: ${data.Email || 'N/A'}`);
            console.log(`   Preferred Language: ${data.PreferredLanguage || 'N/A'}`);
          }
        } else {
          const itemCount = data.items?.length || (Array.isArray(data) ? data.length : 'N/A');
          console.log(`   ✅ SUCCESS - Items: ${itemCount}`);
        }
        
        return { status: 'SUCCESS', data, duration };
      } catch (e) {
        console.log(`   ✅ SUCCESS - Response received`);
        return { status: 'SUCCESS', duration };
      }
    } else if (response.status === 404) {
      console.log(`   ❌ NOT FOUND - Endpoint may not exist or need different parameters`);
      return { status: 'NOT_FOUND', duration };
    } else if (response.status === 400) {
      const text = await response.text();
      console.log(`   ⚠️  BAD REQUEST - Parameter issue`);
      console.log(`   Response: ${text.substring(0, 100)}`);
      return { status: 'BAD_REQUEST', duration, error: text };
    } else if (response.status === 401) {
      console.log(`   🔐 UNAUTHORIZED - Authentication issue`);
      return { status: 'UNAUTHORIZED', duration };
    } else {
      console.log(`   ⚠️  ERROR ${response.status}`);
      const text = await response.text();
      console.log(`   Response: ${text.substring(0, 100)}`);
      return { status: `ERROR_${response.status}`, duration, error: text };
    }
    
  } catch (error) {
    console.log(`   ❌ FETCH ERROR: ${error.message}`);
    return { status: 'FETCH_ERROR', error: error.message };
  }
};

const runTests = async () => {
  console.log('🔧 COMPREHENSIVE PATIENT API TEST:');
  console.log('═══════════════════════════════════════════');
  
  const results = {};
  
  for (const endpoint of endpoints) {
    results[endpoint.name] = await testEndpoint(endpoint);
  }
  
  console.log('\n📊 TEST RESULTS SUMMARY:');
  console.log('═══════════════════════════════════════════');
  
  const categories = {
    working: [],
    broken: [],
    missing: []
  };
  
  Object.entries(results).forEach(([name, result]) => {
    if (result.status === 'SUCCESS') {
      categories.working.push(name);
      console.log(`✅ ${name}: ${result.status}`);
    } else if (result.status === 'NOT_FOUND') {
      categories.missing.push(name);
      console.log(`❌ ${name}: ${result.status}`);
    } else {
      categories.broken.push(name);
      console.log(`⚠️  ${name}: ${result.status}`);
    }
  });
  
  console.log('\n🎯 FINAL SUMMARY:');
  console.log('═════════════════');
  console.log(`✅ Working APIs: ${categories.working.length}`);
  categories.working.forEach(name => console.log(`   - ${name}`));
  
  if (categories.missing.length > 0) {
    console.log(`\n❌ Missing APIs: ${categories.missing.length}`);
    categories.missing.forEach(name => console.log(`   - ${name}`));
  }
  
  if (categories.broken.length > 0) {
    console.log(`\n⚠️  Broken APIs: ${categories.broken.length}`);
    categories.broken.forEach(name => console.log(`   - ${name}`));
  }
  
  console.log(`\n📈 Success Rate: ${categories.working.length}/${endpoints.length} (${Math.round(categories.working.length/endpoints.length*100)}%)`);
};

runTests().catch(console.error);
